/**
*
* MODULE FILE NAME: DownloadUtils.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        29 apr 2018
*
* AUTHORS:      francesca
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 29 apr 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions.downloadManagement;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.DownloadLogic;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

// TODO: Auto-generated Javadoc
/**
 * The Class DownloadUtils.
 *
 * @author francesca
 */
public class DownloadUtils {

	/** The dwl mng. */
	DownloadManagement dwlMng = new DownloadManagement();

	/**
	 * Check if contains delete dwl related to ps.
	 *
	 * @param onlyDeleteDwlForSto the only delete dwl for sto
	 * @param packet              the packet
	 * @return the download
	 */
	public Download checkIfContainsDeleteDwlRelatedToPs(List<Download> onlyDeleteDwlForSto, PacketStore packet) {
		// create an instance of download
		Download downloadRelatedToPs = null;

		// iterate over the download of type delete
		for (int i = 0; i < onlyDeleteDwlForSto.size(); i++) {
			// if the download has same polarization of the packet store
			// given
			// as input
			if (onlyDeleteDwlForSto.get(i).getPol().compareTo(packet.getPolarization()) == 0) {
				// set the returned download with the current one
				downloadRelatedToPs = onlyDeleteDwlForSto.get(i);
			}
		}
		return downloadRelatedToPs;
	}

	/**
	 * Gets the all download planned on vis on link except pt.
	 *
	 * @param dwlTreeMap the dwl tree map
	 * @param currentVis the current vis
	 * @return the all download planned on vis on link except pt
	 */
	// public List<IDownload>
	// getAllDownloadPlannedOnVisOnLinkExceptPt(TreeMap<String, TreeMap<String,
	// TreeMap<Long, IDownload>>> dwlTreeMap, Visibility currentVis, String
	// link)
	// {
	// // create an empty list of IDownloads
	// List<IDownload> allDwlOnVis = new ArrayList<>();
	// String contactCounterForVis =
	// DownloadManagement.concatVisId(currentVis.getSatelliteId(), currentVis);
	//
	// // iterate over all the elements in treemap related to the current vis
	// for (Map.Entry<String, TreeMap<Long, IDownload>> elementsInTreeMap :
	// dwlTreeMap.get(contactCounterForVis).entrySet())
	// {
	// // if the elements are related to the needed link (L1 or L2)
	// if (elementsInTreeMap.getKey() == link)
	// {
	//
	// TreeMap<Long, IDownload> allDownloadsOnLink =
	// elementsInTreeMap.getValue();
	//
	// // iterate over all the elements related to this link
	// for (Map.Entry<Long, IDownload> allDwl : allDownloadsOnLink.entrySet())
	// {
	// // if the i-esim element is a download
	// if (allDwl.getValue().getTypeOfDwl().compareTo(DownloadLogic.DWL) == 0)
	// {
	// // add it to the returned list
	// allDwlOnVis.add(allDwl.getValue());
	// }
	// }
	// }
	// }
	// return allDwlOnVis;
	// }

	public List<IDownload> getAllDownloadPlannedOnVis(
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap, Visibility currentVis) {
		// create an empty list of IDownloads
		List<IDownload> allDwlOnVis = new ArrayList<>();
		String contactCounterForVis = DownloadManagement.concatVisId(currentVis.getSatelliteId(), currentVis);

		if (dwlTreeMap.get(contactCounterForVis) != null) {
			// iterate over all the elements in treemap related to the current
			// vis
			for (Map.Entry<String, TreeMap<Long, IDownload>> elementsInTreeMap : dwlTreeMap.get(contactCounterForVis)
					.entrySet()) {

				TreeMap<Long, IDownload> allDownloadsOnLink = elementsInTreeMap.getValue();

				// itera//te over all the elements related to this link
				for (Map.Entry<Long, IDownload> allDwl : allDownloadsOnLink.entrySet()) {
					// add it to the returned list

					if ((allDwl.getValue().getTypeOfDwl().compareTo(DownloadLogic.DWL) == 0)
							&& (allDwl.getValue().getRelatedToTask() != null)
							&& (allDwl.getValue().isReallyPlanned())) {
						allDwlOnVis.add(allDwl.getValue());
					}
				}
			}
		}
		return allDwlOnVis;
	}

	/**
	 * Gets the all vis from A date.
	 *
	 * @param afterDate      the after date
	 * @param acq            the acq
	 * @param relatedPartner the related partner
	 * @param droolsParams   the drools params
	 * @return the all vis from A date
	 */
	public TreeMap<String, Visibility> getAllVisFromADate(Date afterDate, Acquisition acq, Partner relatedPartner,
			DroolsParameters droolsParams) {
		DownloadUtils dwlUtils = new DownloadUtils();
		TreeMap<String, Visibility> allVisibilitiesAfterADate = new TreeMap<>();
		List<Visibility> visAssociatedToDto = new ArrayList<>();
		// get all the external stations
		List<Visibility> allExternal = dwlUtils.getAllExternalVisibilities(droolsParams.getAllVisibilities());

		if ((relatedPartner.getAllVisForPartner() == null) || relatedPartner.getAllVisForPartner().isEmpty()) {
			// use the visibilities of the catalog
			visAssociatedToDto = droolsParams.getAllVisibilities();// droolsParams.getSatWithId(satId).getVisibilityList();
		}
		// if the partner has visibilities associated
		else {
			// get the visibilities associatd to the partner
			visAssociatedToDto = dwlUtils.getAllVisibilitiesFromid(droolsParams.getAllVisibilities(),
					relatedPartner.getAllVisForPartner());

			// add the external stations to the visibilities associated to
			// the partner
			visAssociatedToDto = dwlUtils.addAllExternal(visAssociatedToDto, allExternal);
		}

		List<Visibility> visAssociatedToDtoForMh = filterVisForMh(visAssociatedToDto, droolsParams.getCurrentMH());

		allVisibilitiesAfterADate = filterVisGetOnlyValid(visAssociatedToDtoForMh, acq, relatedPartner);

		if (allVisibilitiesAfterADate.isEmpty()) {
			addBackUpStation(acq, allVisibilitiesAfterADate, droolsParams.getAllVisibilities());
		}
		return allVisibilitiesAfterADate;
	}

	/**
	 * Filter vis get only valid.
	 *
	 * @param allVis the all vis
	 * @param acq    the acq
	 * @param p      the p
	 * @return the tree map
	 */
	protected TreeMap<String, Visibility> filterVisGetOnlyValid(List<Visibility> allVis, Acquisition acq, Partner p) {
		TreeMap<String, Visibility> allVisibilitiesAfterADate = new TreeMap<>();
		for (int i = 0; i < allVis.size(); i++) {
			if (allVis.get(i).getSatelliteId().equalsIgnoreCase(acq.getSatelliteId())
					&& (allVis.get(i).getEndTime().getTime() >= acq.getStartTime().getTime())) {
				String associatedPartnerId = p.getPartnerId();
				if (allVis.get(i).isExternal() || (allVis.get(i).getOwnerId() == null)
						|| associatedPartnerId.equalsIgnoreCase(allVis.get(i).getOwnerId())) {

					allVisibilitiesAfterADate.put(visKey(allVis.get(i)), allVis.get(i));
				}
			}
		}
		// DroolsParameters.getLogger().debug("Filtered (only valid): " +
		// allVisibilitiesAfterADate);

		return allVisibilitiesAfterADate;
	}

	/**
	 * Adds the back up station.
	 *
	 * @param acq                       the acq
	 * @param allVisibilitiesAfterADate the all visibilities after A date
	 * @param listVis                   the list vis
	 */
	private void addBackUpStation(Acquisition acq, TreeMap<String, Visibility> allVisibilitiesAfterADate,
			List<Visibility> listVis) {
		//get the logger
		Logger logger = DroolsParameters.getLogger();

		logger.info("try to add backup stations ");
		
		//initialize th cont
		int cont = 0;
		
		//if there are backup 
		//stations setted 
		if ((acq.getBackupVis() != null) && !acq.getBackupVis().isEmpty()) {
			
			//iterate over all 
			//the visibilities
			for (int i = 0; i < listVis.size(); i++) {
				// extract the visibility
				Visibility vis = listVis.get(i);
				
				//if the visibility is a valid one
				if (vis.getSatelliteId().equalsIgnoreCase(acq.getSatelliteId())
						&& (vis.getEndTime().getTime() >= acq.getStartTime().getTime())) {
					//iterate over the backup list of visibilities
					for (int j = 0; j < acq.getBackupVis().size(); j++) {
						
						//get the visibility id
						String visId = acq.getBackupVis().get(j);
						if ((vis.getAcqStatId().equalsIgnoreCase(visId))) {
							vis.setBackUp(true);
							logger.info("added : " + visKey(vis) + " as backup station");
							//add he visibility to the list
							//of vis that must be returned
							allVisibilitiesAfterADate.put(visKey(vis), vis);
							cont++;
						}
					}

				}
			}
			if (cont == 0) {
				logger.info("backup stations list is empty.");
			}
		} else {
			logger.debug("backup stations list is empty.");
		}
	}

	/**
	 * Vis key.
	 *
	 * @param vis the vis
	 * @return the string
	 */
	protected String visKey(Visibility vis) {
		return vis.getStartTime().getTime() + "_" + vis.getContactCounter() + "_" + vis.getAcqStatId() + "_"
				+ vis.getSatelliteId();
	}

	/**
	 * Only delete dwl.
	 *
	 * @param allDwlAssociatedToSto the all dwl associated to sto
	 * @return the list
	 */
	public List<Download> getOnlyDeleteDwl(List<Download> allDwlAssociatedToSto) {
		// create an empty list of download
		List<Download> allDeleteDwl = new ArrayList<>();

		// iterate over all the downloads related to the current acq
		for (int i = 0; i < allDwlAssociatedToSto.size(); i++) {
			// if the i-esim download is of type DELETE
			if (allDwlAssociatedToSto.get(i).getPacketStoreStrategy().compareTo(DownlinkStrategy.DELETE) == 0) {
				// add it to the returned list
				allDeleteDwl.add(allDwlAssociatedToSto.get(i));
			}
		}
		return allDeleteDwl;
	}

	/**
	 * Find all vis in overlap with date.
	 *
	 * @param start           the start
	 * @param end             the end
	 * @param allVisibilities the all visibilities
	 * @param satId           the sat id
	 * @return the list
	 */
	public List<Visibility> findAllVisInOverlapWithDate(Date start, Date end, List<Visibility> allVisibilities,
			String satId) {

		// create an empty list of visibilities
		List<Visibility> allOverlappedVis = new ArrayList<>();

		// iterate over all the visibilities
		for (int i = 0; i < allVisibilities.size(); i++) {
			// extract the i-esim visibility
			Visibility currentVis = allVisibilities.get(i);

			// if there is overlap and the visibility is associated on the
			// satelliteId given as input
			if (currentVis.getSatelliteId().contains(satId) && (currentVis.getStartTime().getTime() <= end.getTime())
					&& (currentVis.getEndTime().getTime() >= start.getTime())) {
				// add the visibility to the returned list
				allOverlappedVis.add(currentVis);
			}
		}
		return allOverlappedVis;
	}

	/**
	 * Extract all partners relative to acq.
	 *
	 * @param userInfo     the user info
	 * @param droolsParams the drools params
	 * @return the list
	 */
	public List<Partner> extractAllPartnersRelativeToAcq(List<UserInfo> userInfo, DroolsParameters droolsParams) {
		// create an empty list of partners
		List<Partner> onlyPartnersRelativeToAcq = new ArrayList<>();

		// get all the partners
		List<Partner> allPartners = droolsParams.getAllPartners();

		// iterate over all the partners
		for (int i = 0; i < allPartners.size(); i++) {
			// iterate over all the partners related to the current acq
			for (int j = 0; j < userInfo.size(); j++) {
				// if the partner inside the userInfo has the same id of the
				// i-esim partner
				if (userInfo.get(j).getOwnerId().equalsIgnoreCase(allPartners.get(i).getPartnerId())) {
					// add it to the list that must be returned from the method
					onlyPartnersRelativeToAcq.add(allPartners.get(i));
				}
			}
		}
		return onlyPartnersRelativeToAcq;
	}

	/**
	 * Gets the only dwl for pol.
	 *
	 * @param localDownloads the local downloads
	 * @param hh             the hh
	 * @return the only dwl for pol
	 */
	public List<Task> getOnlyDwlForPol(List<Task> localDownloads, Polarization hh) {
		// create an empty list of downloads
		List<Task> dwlbasedOnPol = new ArrayList<>();

		// iterate over all the downloads passed as input
		for (int i = 0; i < localDownloads.size(); i++) {
			// extract the i-esim download
			Download dwl = (Download) localDownloads.get(i);

			// if the polarization is the same of the one given as input
			if (dwl.getPol().equals(hh)) {
				// add it to the list created above
				dwlbasedOnPol.add(dwl);
			}
		}
		return dwlbasedOnPol;
	}

	/**
	 * Find next pt on same vis and same link.
	 *
	 * @param startTime       the start time
	 * @param satId           the sat id
	 * @param currentVis      the current vis
	 * @param maxLink         the max link
	 * @param downloadTreeMap the download tree map
	 * @return the date
	 */
	protected List<Date> findNextPtOnSameVisAndSameLink(Date startTime, String satId, Visibility currentVis,
			String maxLink, TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap) {
		List<Date> startAndStopNextPt = new ArrayList<>();

		String contactCounterForVis = DownloadManagement.concatVisId(currentVis.getSatelliteId(), currentVis);

		// if the visibility is not empty (still stored in download treemap)
		if (downloadTreeMap.containsKey(contactCounterForVis)) {

			TreeMap<String, TreeMap<Long, IDownload>> downloadForCurrentVis = downloadTreeMap.get(contactCounterForVis);

			// if there are elements associated with the link given as input
			if (downloadForCurrentVis.containsKey(maxLink)) {

				TreeMap<Long, IDownload> allDwlOnLink = downloadForCurrentVis.get(maxLink);

				// get the portion of map from the startTime given as input and
				// the endtime of the visibility

				if (startTime.getTime() <= currentVis.getEndTime().getTime()) {
					SortedMap<Long, IDownload> onlyNextElements = null;
					if (startTime.getTime() < currentVis.getAvailableStartTime(maxLink).getTime()) {
						onlyNextElements = allDwlOnLink.subMap(currentVis.getAvailableStartTime(maxLink).getTime(),
								currentVis.getEndTime().getTime());
					} else {
						onlyNextElements = allDwlOnLink.subMap(startTime.getTime(), currentVis.getEndTime().getTime());
					}

					// iretare over the extracted elements
					for (Map.Entry<Long, IDownload> onlyNext : onlyNextElements.entrySet()) {
						// if the i-esim element is a passthrough or a paw
						// if
						// (onlyNext.getValue().getTypeOfDwl().equals(DownloadLogic.PT)
						// ||
						// onlyNext.getValue().getTypeOfDwl().equals(DownloadLogic.PAW)
						// || (onlyNext.getValue().isReallyPlanned() == false))
						// {
						// if the start time isn't in overlap with current
						// interval (start and stop)
						if (onlyNext.getValue().getStartTime().getTime() >= startTime.getTime()) {
							// memorize the start and stop of current
							// element
							startAndStopNextPt.add(onlyNext.getValue().getStartTime());
							startAndStopNextPt.add(onlyNext.getValue().getStopTime());
							break;
						}
						// }
					}
				}

			}
		}

		// if there isn't a next passthrough or paw, fill the returned element
		// with the end time of the visibility
		if (startAndStopNextPt.isEmpty()) {
			startAndStopNextPt.add(currentVis.getEndTime());
			startAndStopNextPt.add(currentVis.getEndTime());
		}
		return startAndStopNextPt;
	}

	/**
	 * Find if there are another download for same ps on same vis.
	 *
	 * @param forAcq         the for acq
	 * @param pol            the pol
	 * @param initialPs      the initial ps
	 * @param currentVis     the current vis
	 * @param localDownloads the local downloads
	 * @return the download
	 */
	protected Download findIfThereAreAnotherDownloadForSamePsOnSameVis(String forAcq, Polarization pol, int initialPs,
			Visibility currentVis, List<Task> localDownloads) {
		Download anotherDwlOnSameVis = null;
		// iterate over all the downloads given as input
		for (int i = 0; i < localDownloads.size(); i++) {
			// extract the i-esim download
			Download currentDwl = (Download) localDownloads.get(i);
			// if the download is related to the current acq
			if ((currentDwl.getRelatedTask() != null) && currentDwl.getRelatedTask().equalsIgnoreCase(forAcq)) {
				String uniqueKeyVisCurrentAcq = DownloadManagement.concatVisId(currentVis.getSatelliteId(), currentVis);

				String uniqueKeyVisDownload = this.dwlMng.concatVisIdFromDownload(currentDwl);
				// is the download is planned on the same vis of the current one
				if (uniqueKeyVisDownload.equalsIgnoreCase(uniqueKeyVisCurrentAcq)) {
					// if the polarization is the same of the current download
					if (currentDwl.getPol().compareTo(pol) == 0) {
						// if the initial sector are consistent
						if (currentDwl.getInitialSector() == initialPs) {
							// there is another download on same wis
							anotherDwlOnSameVis = currentDwl;
							break;
						}
					}
				}
			}
		}
		return anotherDwlOnSameVis;
	}

	/**
	 * Find if there are part of download on external station.
	 *
	 * @param taskId              the task id
	 * @param pol                 the pol
	 * @param partnerId           the partner id
	 * @param catalogVisibilities the catalog visibilities
	 * @param localDownloads      the local downloads
	 * @return true, if successful
	 */
	public boolean findIfThereArePartOfDownloadOnExternalStation(String taskId, Polarization pol, String partnerId,
			List<Visibility> catalogVisibilities, List<Task> localDownloads) {
		boolean otherDwlOnExternalStation = false;

		// iterate over all the download given as input
		for (int i = 0; i < localDownloads.size(); i++) {
			// extract the i-esim download
			Download currentDwl = (Download) localDownloads.get(i);

			// if the download is related to the partner and the polatization is
			// the same of the one given as input
			if (currentDwl.getUgsOwnerList().contains(partnerId) && currentDwl.getPol().equals(pol)
					&& currentDwl.getRelatedTask().equals(taskId)) {
				Visibility visRelatedToDwl = null;

				// iterate over the visibilities given as input
				for (int j = 0; j < catalogVisibilities.size(); j++) {
					// if there is a match between contact counter
					if (catalogVisibilities.get(j).getContactCounter() == (currentDwl.getContactCounter())) {
						// get the current vis
						visRelatedToDwl = catalogVisibilities.get(j);

						// if is external
						if (visRelatedToDwl.isExternal()) {
							// return true
							otherDwlOnExternalStation = true;
						}
						break;
					}
				}
			}
		}
		return otherDwlOnExternalStation;
	}

	/**
	 * Description : a method created to sort the visibilities passed as parameter
	 * according to start time.
	 *
	 * @param visibilityAssociated the visibility associated
	 * @param acq                  the acq
	 */
	public void sortVisibilityList(List<Visibility> visibilityAssociated, Acquisition acq) {
		// create a new Comparator
		Collections.sort(visibilityAssociated, new Comparator<Visibility>() {

			@Override
			// given two visibilities
			public int compare(Visibility vis1, Visibility vis2) {
				// compare and sort them
				// by startTime
				return vis1.getStartTime().compareTo(vis2.getStartTime());
			}
		});

		// filter over the visibilities
		for (int i = 0; i < visibilityAssociated.size(); i++) {
			Visibility vis = visibilityAssociated.get(i);

			// if the vibility is not relevant for the acq
			if (vis.getEndTime().getTime() < acq.getEndTime().getTime()) {
				// remove the i-esim element
				visibilityAssociated.remove(i);

				// decrement the index
				i--;
			}
		}
	}

	/**
	 * Gets the all pt.
	 *
	 * @param sessionId the session id
	 * @param satId     the sat id
	 * @return the all pt
	 */
	public List<PassThrough> getAllPt(String sessionId, String satId) {
		List<PassThrough> returnedPt = new ArrayList<>();

		// , int sessionInstance,
		// String sessionIdConcat =
		// DroolsParameters.concatenateSession(sessionId,
		// sessionInstance);

		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionId);

		QueryResults allManWithId = kie.getQueryResults("getAllPt", satId);
		if (allManWithId.size() > 1) {
			for (QueryResultsRow ptList : allManWithId) {
				PassThrough pt = (PassThrough) ptList.get("$pt");
				returnedPt.add(pt);

			}
		}
		return returnedPt;
	}

	/**
	 * Sort tasks by start time.
	 *
	 * @param downloadsAssociated the downloads associated
	 */
	public static void sortTasksByStartTime(List<Task> downloadsAssociated) {
		// create a new Comparator
		Collections.sort(downloadsAssociated, new Comparator<Task>() {

			@Override
			/*
			 * given two tasks
			 * 
			 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
			 */
			public int compare(Task dwl1, Task dwl2) {
				// compare and sort them by startTime
				return dwl1.getStartTime().compareTo(dwl2.getStartTime());
			}
		});
	}

	/**
	 * Sort download by start time.
	 *
	 * @param downloadsAssociated the downloads associated
	 */
	public static void sortDownloadByStartTime(List<Download> downloadsAssociated) {
		// create a new Comparator
		Collections.sort(downloadsAssociated, new Comparator<Task>() {

			@Override
			/*
			 * given two Downloads sort them by startTime
			 */
			public int compare(Task dwl1, Task dwl2) {
				// compare and sort them by startTime
				return dwl1.getStartTime().compareTo(dwl2.getStartTime());
			}
		});
	}

	/**
	 * Gets the all external visibilities.
	 *
	 * @param allVisibilities the all visibilities
	 * @return the all external visibilities
	 */
	public List<Visibility> getAllExternalVisibilities(List<Visibility> allVisibilities) {
		// create an empty arrayList of visibility to memorize all the external
		// vis
		List<Visibility> allExternalVis = new ArrayList<>();

		// iterate over all the visibilities given as input
		for (int i = 0; i < allVisibilities.size(); i++) {
			// if the i-esim visibility is flagged as external
			if (allVisibilities.get(i).isExternal()) {
				// add to the list created above
				allExternalVis.add(allVisibilities.get(i));
			}
		}
		return allExternalVis;
	}

	/**
	 * Adds the all external.
	 *
	 * @param visAssociatedToDto the vis associated to dto
	 * @param allExternal        the all external
	 * @return the list
	 */
	public List<Visibility> addAllExternal(List<Visibility> visAssociatedToDto, List<Visibility> allExternal) {
		// if there are visibilities associated to the dto
		if ((visAssociatedToDto != null) && !visAssociatedToDto.isEmpty()) {
			// iterate over the external
			for (int i = 0; i < allExternal.size(); i++) {
				// if the list of visibilities associated doens't contains the
				// i-esim external
				if (!visAssociatedToDto.contains(allExternal.get(i))) {
					// add the i-esim external
					visAssociatedToDto.add(allExternal.get(i));
				}
			}
		}

		// no visibilities associated to the dto
		else {
			// add all external
			visAssociatedToDto.addAll(allExternal);
		}
		return visAssociatedToDto;
	}

	/**
	 * Filter vis for mh.
	 *
	 * @param visAssociatedToDto the vis associated to dto
	 * @param currentMH          the current MH
	 * @return the list
	 */
	public List<Visibility> filterVisForMh(List<Visibility> visAssociatedToDto, MissionHorizon currentMH) {
		List<Visibility> filteredVis = new ArrayList<>();

		// iterate over the visibilities
		// associated to dto
		for (int i = 0; i < visAssociatedToDto.size(); i++) {
			filteredVis.add(visAssociatedToDto.get(i));
		}

		// iterate over the visibilities
		// given as input
		for (int i = 0; i < filteredVis.size(); i++) {
			// if the vis isn't included into the current mh
			boolean overlap = (filteredVis.get(i).getEndTime().getTime() > currentMH.getStart().getTime())
					&& (filteredVis.get(i).getStartTime().getTime() <= currentMH.getStop().getTime());
			if (!overlap) {
				// remove from the list
				filteredVis.remove(i);
				i--;
			}
		}
		return filteredVis;
	}

	/*
	 * public PriorityQueue restorePriorityQueueOfRelatedAmount(TreeMap<String,
	 * PriorityQueue> downloadPriority, Download currentIdwl, HashMap<String,
	 * Acquisition> allAcq, int choice) { PriorityQueue priority = new
	 * PriorityQueue(); DroolsQueries dq = new DroolsQueries(); // get the amount of
	 * sectors that must be restored int amountOfSectorToRestore =
	 * currentIdwl.getDownloadedSize();
	 *
	 * Logger logger = DroolsParameters.getLogger();
	 *
	 * // get polarization to restore Polarization relatedToPol =
	 * currentIdwl.getPol();
	 *
	 * // get all partners related to the current download List<String>
	 * allPartnersNeedRestore = currentIdwl.getUgsOwnerList();
	 *
	 * Acquisition acq = dq.getAcqWithIdFromHashMap(allAcq,
	 * currentIdwl.getRelatedTask()); String priorityKey =
	 * this.dwlMng.getPriorityKey(acq);
	 *
	 * // if exists an element into the priority queque related to the current //
	 * download if ((downloadPriority != null) && (downloadPriority.get(priorityKey)
	 * != null)) { // extract the element priority = (PriorityQueue)
	 * DroolsUtils.deepClone(downloadPriority.get(priorityKey));
	 *
	 * HashMap<String, SectorAndVisForPartner> sectors =
	 * priority.getSectorsNeededForPartners();
	 *
	 * logger.debug("RESTORE for element : " + priorityKey);
	 * logger.debug("RESTORE for dwl : " + currentIdwl);
	 *
	 * logger.debug("RESTORE for partners : " + allPartnersNeedRestore);
	 *
	 * for (int i = 0; i < allPartnersNeedRestore.size(); i++) { String
	 * currentPartner = allPartnersNeedRestore.get(i); // if the partner has pending
	 * sectors to download if (sectors.containsKey(currentPartner)) { if
	 * (sectors.get(currentPartner).getSectorsForPartner().get(0).getPol().
	 * compareTo(currentIdwl.getPol()) == 0) { logger.debug("for pol " +
	 * sectors.get(currentPartner).getSectorsForPartner().get(0).getPol()); int
	 * sizeBeforeIncrement =
	 * sectors.get(currentPartner).getSectorsForPartner().get(0).getResidualSize ();
	 *
	 * // re-increment the amount of the download into the // priority queue if
	 * (choice == 1) { logger.debug("RESTORE sizeBeforeIncrement : " +
	 * sizeBeforeIncrement);
	 *
	 * sizeBeforeIncrement = sizeBeforeIncrement + amountOfSectorToRestore;
	 * logger.debug("RESTORE sizeAfterIncrement : " + sizeBeforeIncrement);
	 *
	 * }
	 *
	 * sectors.get(currentPartner).getSectorsForPartner().get(0).setResidualSize
	 * (sizeBeforeIncrement); } else { logger.debug("for pol " +
	 * sectors.get(currentPartner).getSectorsForPartner().get(1).getPol());
	 *
	 * int sizeBeforeIncrement =
	 * sectors.get(currentPartner).getSectorsForPartner().get(1).getResidualSize ();
	 *
	 * // re-increment the amount of the download into the // priority queue if
	 * (choice == 1) { logger.debug("RESTORE sizeBeforeIncrement : " +
	 * sizeBeforeIncrement);
	 *
	 * sizeBeforeIncrement = sizeBeforeIncrement + amountOfSectorToRestore;
	 * logger.debug("RESTORE sizeAfterIncrement : " + sizeBeforeIncrement);
	 *
	 * }
	 *
	 * sectors.get(currentPartner).getSectorsForPartner().get(1).setResidualSize
	 * (sizeBeforeIncrement); } } // if the partner hasn't sectors to download else
	 * { // create a new element List<SizeOfSectorDwl> newSectors = new
	 * ArrayList<>();
	 *
	 * SizeOfSectorDwl newSizeSectors = new SizeOfSectorDwl(amountOfSectorToRestore,
	 * amountOfSectorToRestore, relatedToPol); List<String> allVisForPartner = new
	 * ArrayList<>(); newSectors.add(newSizeSectors);
	 *
	 * SectorAndVisForPartner sectorsForPartner = new
	 * SectorAndVisForPartner(allVisForPartner, newSectors);
	 * sectors.put(currentPartner, sectorsForPartner); }
	 *
	 * } } // if not exists an element into the priority queque -> create it! else {
	 * // create HashMap<String, SectorAndVisForPartner> partnersStillNeedssectors =
	 * new HashMap<>();
	 *
	 * priority = new PriorityQueue(); priority.setPol(currentIdwl.getPol()); //
	 * priority.setRelatedAcq(currentIdwl.getRelatedTask().getI);
	 * priority.setSectorsNeededForPartners(partnersStillNeedssectors);
	 * priority.setRelatedAcq(acq); SizeOfSectorDwl residualSectors = new
	 * SizeOfSectorDwl(amountOfSectorToRestore, amountOfSectorToRestore,
	 * relatedToPol); residualSectors.setEffectiveSize(amountOfSectorToRestore);
	 * HashMap<String, SectorAndVisForPartner> sectorsNeededForPartners = new
	 * HashMap<>();
	 *
	 * for (int j = 0; j < currentIdwl.getUgsOwnerList().size(); j++) { String
	 * partnerId = currentIdwl.getUgsOwnerList().get(j); List<SizeOfSectorDwl>
	 * newSectors = new ArrayList<>(); List<String> allVisForPartner = new
	 * ArrayList<>(); SizeOfSectorDwl newSizeSectors = new
	 * SizeOfSectorDwl(amountOfSectorToRestore, amountOfSectorToRestore,
	 * relatedToPol); newSectors.add(newSizeSectors); SectorAndVisForPartner
	 * sectorsForPartner = new SectorAndVisForPartner(allVisForPartner, newSectors);
	 * sectorsNeededForPartners.put(partnerId, sectorsForPartner); }
	 * priority.setSectorsNeededForPartners(sectorsNeededForPartners);
	 *
	 * } return priority; }
	 *
	 */

	/**
	 * Gets the all visibilities fromid.
	 *
	 * @param allVisibilities  the all visibilities
	 * @param allVisForPartner the all vis for partner
	 * @return the all visibilities fromid
	 */
	public List<Visibility> getAllVisibilitiesFromid(List<Visibility> allVisibilities, List<String> allVisForPartner) {
		List<Visibility> allAssociatedVis = new ArrayList<>();
		for (int i = 0; i < allVisForPartner.size(); i++) {
			String visId = allVisForPartner.get(i);
			for (int j = 0; j < allVisibilities.size(); j++) {
				if (allVisibilities.get(j).getAcqStatId().equals(visId)) {
					allAssociatedVis.add(allVisibilities.get(j));
				}
			}
		}
		return allAssociatedVis;
	}

	/**
	 * Gets the relative vis.
	 *
	 * @param currentDwl   the current dwl
	 * @param droolsParams the drools params
	 * @return the relative vis
	 */
	public static Visibility getRelativeVis(Download currentDwl, DroolsParameters droolsParams) {
		Visibility vis = null;
		List<Visibility> allVis = droolsParams.getAllVisibilities();
		for (int i = 0; i < allVis.size(); i++) {
			Visibility currentVis = allVis.get(i);
			if (currentVis.getAcqStatId().equalsIgnoreCase(currentDwl.getAcqStatId())
					&& currentVis.getContactCounter() == currentDwl.getContactCounter()
					&& currentVis.getSatelliteId().equalsIgnoreCase(currentDwl.getSatelliteId())) {
				vis = currentVis;
				break;
			}
		}
		return vis;
	}

}
