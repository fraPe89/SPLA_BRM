/**
*
* MODULE FILE NAME:	PRMode.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		23 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 23 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum PRMode.
 *
 * @author francesca
 */
public enum PRMode {

	/** The Standard. */
	Standard,

	/** The di2s. */
	DI2S,

	/** The Theatre. */
	Theatre,

	/** The Exp. */
	Exp
}
