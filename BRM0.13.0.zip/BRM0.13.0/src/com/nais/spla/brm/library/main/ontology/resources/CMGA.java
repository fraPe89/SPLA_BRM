/**
 *
 * MODULE FILE NAME: CMGA.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resources;

import java.util.HashMap;
import java.util.Map;

/**
 * The Class CMGA.
 */
public class CMGA {

	/** The cmga id. */
	private String cmgaId;

	/** The w acc. */
	private double wAcc;

	/** The t acc. */
	private double tAcc;

	/** The w plat. */
	private double wPlat;

	/** The w rest. */
	private double wRest;

	/** The satellite id. */
	private String satelliteId;

	/** This is set at true when the CMGA is in operative mode. */
	private boolean operative;

	/** The all powers for orbit. */
	private Map<Double, Double> allPowersForOrbit = null;

	/**
	 * Instantiates a new cmga.
	 *
	 * @param cmgaId      the cmga id
	 * @param wAcc        the w acc
	 * @param tAcc        the t acc
	 * @param wPlat       the w plat
	 * @param wRest       the w rest
	 * @param operative   the operative
	 * @param satelliteId the satellite id
	 */
	public CMGA(String cmgaId, double wAcc, double tAcc, double wPlat, double wRest, boolean operative,
			String satelliteId) {
		super();
		this.cmgaId = cmgaId;
		this.wAcc = wAcc;
		this.tAcc = tAcc;
		this.wPlat = wPlat;
		this.wRest = wRest;
		this.operative = operative;
		this.satelliteId = satelliteId;
		this.allPowersForOrbit = new HashMap<>();
	}

	/**
	 * Instantiates a new cmga.
	 */
	public CMGA() {
		super();
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() {/**
								 * toString del metodo
								 */
		return "CMGA [cmgaId=" + this.cmgaId + ", wAcc=" + this.wAcc + ", tAcc=" + this.tAcc + ", wPlat=" + this.wPlat
				+ ", wRest=" + this.wRest + ", satelliteId=" + this.satelliteId + ", operative=" + this.operative
				+ ", allPowersForOrbit=" + this.allPowersForOrbit + "]";
	}

	/**
	 * Gets the cmga id.
	 *
	 * @return the cmga id
	 */
	public String getCmgaId() {
		return this.cmgaId;
	}

	/**
	 * Sets the cmga id.
	 *
	 * @param cmgaId the new cmga id
	 */
	public void setCmgaId(String cmgaId) {
		this.cmgaId = cmgaId;
	}

	/**
	 * Gets the w acc.
	 *
	 * @return the w acc
	 */
	public double getwAcc() {
		return this.wAcc;
	}

	/**
	 * Sets the w acc.
	 *
	 * @param wAcc the new w acc
	 */
	public void setwAcc(double wAcc) {
		this.wAcc = wAcc;
	}

	/**
	 * Gets the t acc.
	 *
	 * @return the t acc
	 */
	public double gettAcc() {
		return this.tAcc;
	}

	/**
	 * Sets the t acc.
	 *
	 * @param tAcc the new t acc
	 */
	public void settAcc(double tAcc) {
		this.tAcc = tAcc;
	}

	/**
	 * Gets the w plat.
	 *
	 * @return the w plat
	 */
	public double getwPlat() {
		return this.wPlat;
	}

	/**
	 * Sets the w plat.
	 *
	 * @param wPlat the new w plat
	 */
	public void setwPlat(double wPlat) {
		this.wPlat = wPlat;
	}

	/**
	 * Gets the w rest.
	 *
	 * @return the w rest
	 */
	public double getwRest() {
		return this.wRest;
	}

	/**
	 * Sets the w rest.
	 *
	 * @param wRest the new w rest
	 */
	public void setwRest(double wRest) {
		this.wRest = wRest;
	}

	/**
	 * Checks if is operative.
	 *
	 * @return true, if is operative
	 */
	public boolean isOperative() {
		return this.operative;
	}

	/**
	 * Sets the operative.
	 *
	 * @param operative the new operative
	 */
	public void setOperative(boolean operative) {
		this.operative = operative;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Sets the satellite id.
	 *
	 * @param satelliteId the new satellite id
	 */
	public void setSatelliteId(String satelliteId) {
		this.satelliteId = satelliteId;
	}

	/**
	 * Gets the all powers for orbit.
	 *
	 * @return the all powers for orbit
	 */
	public Map<Double, Double> getAllPowersForOrbit() {
		return this.allPowersForOrbit;
	}

	/**
	 * Sets the all powers for orbit.
	 *
	 * @param allPowersForOrbit the all powers for orbit
	 */
	public void setAllPowersForOrbit(Map<Double, Double> allPowersForOrbit) {
		this.allPowersForOrbit = allPowersForOrbit;
	}

	/**
	 * Adds the all powers for orbit.
	 *
	 * @param orbit the orbit
	 * @param power the power
	 */
	public void addAllPowersForOrbit(double orbit, double power) {
		this.allPowersForOrbit.put(orbit, power);
	}
}
