/**
 *
 * MODULE FILE NAME: TypeOfAcquisition.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum TypeOfAcquisition.
 *
 * @author fpedrola
 */
public enum TypeOfAcquisition {

	/** The spotlight 1a. */
	SPOTLIGHT_1A,
	/** The spotlight 1b. */
	SPOTLIGHT_1B,
	/** The spotlight 1 msor. */
	SPOTLIGHT_1_MSOR,
	/** The spotlight 1 exp. */
	SPOTLIGHT_1_EXP,
	/** The spotlight 2 mos. */
	SPOTLIGHT_2_MOS,
	/** The spotlight 2a. */
	SPOTLIGHT_2A,
	/** The spotlight 2b. */
	SPOTLIGHT_2B,
	/** The spotlight 2c. */
	SPOTLIGHT_2C,
	/** The spotlight 2 msos. */
	SPOTLIGHT_2_MSOS,
	/** The spotlight 2s. */
	SPOTLIGHT_2S,
	/** The spotlight 2 exp. */
	SPOTLIGHT_2_EXP,
	/** The spotlight 2 msjn. */
	SPOTLIGHT_2_MSJN,
	/** The stripmap. */
	STRIPMAP,
	/** The pingpong. */
	PINGPONG,
	/** The quadpol. */
	QUADPOL,
	/** The scansar 1. */
	SCANSAR_1,
	/** The scansar 2. */
	SCANSAR_2,
	/** The trcal. */
	TRCAL,
	/** The poc2048. */
	POC2048,
	/** The bite. */
	BITE
}
