/**
*
* MODULE FILE NAME: Satellite.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resources;

import java.util.ArrayList;
import java.util.List;

import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;

/**
 * The Class Satellite.
 */
public class Satellite {

	/** The satellite id. */
	private String satelliteId;

	/** The satellite name. */
	private String satelliteName;

	/** The initial look side. */
	private String initialLookSide;

	/** The left looking available. */
	private boolean leftLookingAvailable = true;

	/** The visibility list. */
	private List<Visibility> visibilityList = new ArrayList<>();

	/** The satellite properties. */
	private SatelliteProperties satelliteProperties = new SatelliteProperties();

	/**
	 * Instantiates a new satellite.
	 *
	 * @param satelliteId                the satellite id
	 * @param satelliteName              the satellite name
	 * @param pdht                       the pdht
	 * @param platformActivityWindowList the platform activity window list
	 * @param visibilityList             the visibility list
	 * @param initialLookSide            the initial look side
	 */
	public Satellite(String satelliteId, String satelliteName, PDHT pdht, List<PAW> platformActivityWindowList,
			List<Visibility> visibilityList, String initialLookSide) {

		this.satelliteId = satelliteId;
		this.satelliteName = satelliteName;
		this.visibilityList = visibilityList;
		this.leftLookingAvailable = true;
		this.initialLookSide = initialLookSide;
	}

	/**
	 * Gets the initial look side.
	 *
	 * @return the initialLookSide
	 */
	public String getInitialLookSide() {
		return this.initialLookSide;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	// private List<Eclipse> eclipseList;

	/**
	 * Sets the initial look side.
	 *
	 * @param initialLookSide the initialLookSide to set
	 */
	public void setInitialLookSide(String initialLookSide) {
		this.initialLookSide = initialLookSide;
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() {
		/**
		 * toString del metodo
		 */
		return "Satellite [satelliteId=" + this.satelliteId + ", satelliteName=" + this.satelliteName
				+ " initialLookSide=" + this.initialLookSide + "]";
	}

	/**
	 * Gets the satellite properties.
	 *
	 * @return the satellite properties
	 */
	public SatelliteProperties getSatelliteProperties() {
		return this.satelliteProperties;
	}

	/**
	 * Sets the satellite properties.
	 *
	 * @param satelliteProperties the new satellite properties
	 */
	public void setSatelliteProperties(SatelliteProperties satelliteProperties) {
		this.satelliteProperties = satelliteProperties;
	}

	/**
	 * Gets the visibility list.
	 *
	 * @return the visibility list
	 */
	public List<Visibility> getVisibilityList() {
		return this.visibilityList;
	}

	/**
	 * Sets the visibility list.
	 *
	 * @param visibilityList the new visibility list
	 */
	public void setVisibilityList(List<Visibility> visibilityList) {
		this.visibilityList = visibilityList;
	}

	/**
	 * Checks if is left looking available.
	 *
	 * @return the leftLookingAvailable
	 */
	public boolean isLeftLookingAvailable() {
		return this.leftLookingAvailable;
	}

	/**
	 * Sets the left looking available.
	 *
	 * @param leftLookingAvailable the leftLookingAvailable to set
	 */
	public void setLeftLookingAvailable(boolean leftLookingAvailable) {
		this.leftLookingAvailable = leftLookingAvailable;
	}

}
