/**
*
* MODULE FILE NAME:	ManeuverManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		20 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 20 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.ManeuverUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PlanningResources;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

// TODO: Auto-generated Javadoc
/**
 * The Class ManeuverManagement.
 *
 * @author fpedrola
 */
public class ManeuverManagement {

	/** An instance of drools utils class. */
	DroolsUtils du = new DroolsUtils();

	/** An instance of cmga management class. */
	CMGAManeuverManagement cmgaMng = new CMGAManeuverManagement();

	/** The left mng. */
	LeftAttitudeProfileManagement leftMng = new LeftAttitudeProfileManagement();

	/** The man utils. */
	ManeuverUtils manUtils = new ManeuverUtils();

	/**
	 * Creates the man with prev.
	 *
	 * @param prev              the prev
	 * @param curr              the curr
	 * @param involvedMan       the involved man
	 * @param sessionId         the session id
	 * @param sessionInstance   the session instance
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @return the maneuver resources
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public ManeuverResources createManWithPrev(Acquisition prev, Acquisition curr, List<Maneuver> involvedMan,
			String sessionId, int sessionInstance, DroolsParameters droolsParams, ResourceFunctions resourceFunctions)
			throws Exception {
		// create a new object of ManeuverResources
		ManeuverResources manRes = new ManeuverResources();

		// logger.debug("MANEUVER_MANAGEMENT_WITH_PREV for acq : " + curr);
		String sessionIdConcat = DroolsParameters.concatenateSession(sessionId, sessionInstance);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);

		// get all the rejected acq
		HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");

		// set te satellite id to the new object
		manRes.setSatId(curr.getSatelliteId());

		// if exists a previous acquisition
		if (prev != null) {
			manRes = manWithPrevExistPrevious(prev, curr, involvedMan, droolsParams, resourceFunctions, sessionIdConcat,
					1);
		}

		// doesn't exists a previous acq, check the consistence with the initial
		// lookside of the satellite
		else {
			manRes = manWithPrevNotExistPrevious(curr, involvedMan, droolsParams, resourceFunctions, sessionIdConcat,
					true);
		}

		if (!manRes.isPossible()) {
			// logger.debug("MANEUVER_MANAGEMENT_WITH_PREV invalid check :
			// removing acq that need a maneuver : " + curr);
			rejected.put(curr.getId(), curr);
			curr.setRejected(true);
			kie.update(kie.getFactHandle(curr), curr);
		} else {
			curr.setRejected(false);
			curr.getReasonOfReject().clear();
			manRes.getOldMans().addAll(involvedMan);
		}
		return manRes;
	}

	/**
	 * Man with prev not exist previous.
	 *
	 * @param curr              the curr
	 * @param involvedMan       the involved man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param sessionIdConcat   the session id concat
	 * @param withPrevious      the with previous
	 * @return the maneuver resources
	 */
	@SuppressWarnings("unchecked")
	private ManeuverResources manWithPrevNotExistPrevious(Acquisition curr, List<Maneuver> involvedMan,
			DroolsParameters droolsParams, ResourceFunctions resourceFunctions, String sessionIdConcat,
			boolean withPrevious) {
		long impossibleBeforeDate = droolsParams.getCurrentMH().getStart().getTime();

		if (!withPrevious) {
			impossibleBeforeDate = droolsParams.getCurrentMH().getStop().getTime();
		}
		// get the initial lookSide of the satellite related to the current acq
		String initialLookSide = droolsParams.getSatWithId(curr.getSatelliteId()).getInitialLookSide();

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);

		// get all the rejected acq
		HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");

		// create a new instance of ManeuverResources
		ManeuverResources manRes = new ManeuverResources();

		// set the satellite Id
		manRes.setSatId(curr.getSatelliteId());

		// if the check is with the previous maneuver
		if (withPrevious) {
			// if the initial lookSide is different from the lookSide of the
			// current acq -> plan a maneuver
			if (!curr.getLookSide().equalsIgnoreCase(initialLookSide)) {
				boolean fromLeft = false;
				if (curr.getLookSide().equalsIgnoreCase("right")) {
					fromLeft = true;
				}
				// try to plan a maneuver between the mhStart and the current
				// acquisition
				manRes = createManBetweenAcqAndInterval(
						droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
						impossibleBeforeDate, curr, manRes, droolsParams, resourceFunctions, fromLeft, 0);

				if (!manRes.isPossible()) {
					// curr.addReasonOfReject(36,
					// ReasonOfReject.leftAttitudeModeViolation,
					// "Left Attitude Constrains Violation", 0, 0, null);
					rejected.put(curr.getId(), curr);
					curr.setRejected(true);
					// logger.debug("MANEUVER_MANAGEMENT_WITH_PREV ACQ rejected
					// : " + curr.getId()+ "because : impossible to create a
					// man");
					kie.update(kie.getFactHandle(curr), curr);
				}
			}
			// otherwhise if the acquisition is a left one
			else if (curr.getLookSide().equalsIgnoreCase("left")) {
				// compute the gap between start time of mh and starttime of the
				// current left acquisition
				double gap = (curr.getStartTime().getTime() - droolsParams.getCurrentMH().getStart().getTime()) / 60000;

				// if the gap is enought
				if (gap > droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties()
						.getMaxTimeBetweenTwoLeftAcquisitions()) {
					// create a contermaneuver
					// manRes = createContermaneuver(null, curr, droolsParams,
					// resourceFunctions, manRes);
					manRes = createManBetweenAcqAndInterval(
							droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							impossibleBeforeDate, curr, manRes, droolsParams, resourceFunctions, true, 0);
					if (manRes.getNewMans().size() > 0) {
						manRes.getNewMans().get(0).setAcq1Id("mhStart");
						manRes.getNewMans().get(0).setIdTask(
								manRes.getNewMans().get(0).getAcq1Id() + "_" + manRes.getNewMans().get(0).getAcq2Id());
						manRes.getNewMans().get(0).setRightToLeftFlag(false);
					}
					// impossibleBeforeDate = curr.getStartTime().getTime();

					manRes = createManBetweenAcqAndInterval(
							droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							impossibleBeforeDate, curr, manRes, droolsParams, resourceFunctions, false, 0);

				}

			}
		}
		// not exist a next acquisition
		else {
			// compute the gap between current acq and the end of the current
			// mission horizon
			double gap = (droolsParams.getCurrentMH().getStop().getTime() - curr.getEndTime().getTime()) / 1000;

			// if the lookside is left and the gap is enought to permform at
			// least a cmg maneuver
			if (curr.getLookSide().equalsIgnoreCase("left")) {
				if (gap > droolsParams.getTimeForManeuverCmga()) {

					// create a man how possible closer to the current left
					// acquisition
					manRes = createManBetweenAcqAndInterval(
							droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							impossibleBeforeDate, curr, manRes, droolsParams, resourceFunctions, true, 0);

					// if manRes is possible
					if (manRes.isPossible()) {
						// remove the reason of reject and mark the acquisition as not rejected
						curr.getReasonOfReject().clear();
						curr.setRejected(false);
					} else {
						// curr.addReasonOfReject(36,
						// ReasonOfReject.leftAttitudeModeViolation, "Left
						// Attitude
						// Constrains Violation", 0, 0, null);
						rejected.put(curr.getId(), curr);
						curr.setRejected(true);
					}
				}
				// TODO : Alberto da conversazione telefonica del 14/05 chiedeva
				// di
				// implementare la funzionalit� per la quale il satellite non
				// rimanga in left se alla fine del mh non ha abbastanza tempo
				// per effettuare una contromanovra right -> implementato e
				// testato ma commentato

//                else
//                {
//                    manRes.setPossible(false);
//                    curr.addReasonOfReject(36, ReasonOfReject.noTimeForAManeuver, "No Time for a Maneuver", 0, 0, null);
//                    rejected.put(curr.getId(), curr);
//                    curr.setRejected(true);
//                    // logger.debug("MANEUVER_MANAGEMENT_WITH_PREV ACQ
//                    // rejected : " + curr.getId()+ "because :
//                    // leftAttitudeModeViolation");
//                    kie.update(kie.getFactHandle(curr), curr);
//                }
			}

		}
		return manRes;
	}

	/**
	 * Man with prev exist previous.
	 *
	 * @param prev              the prev
	 * @param curr              the curr
	 * @param involvedMan       the involved man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param sessionIdConcat   the session id concat
	 * @param isPrev            the is prev
	 * @return the maneuver resources
	 */
	private ManeuverResources manWithPrevExistPrevious(Acquisition prev, Acquisition curr, List<Maneuver> involvedMan,
			DroolsParameters droolsParams, ResourceFunctions resourceFunctions, String sessionIdConcat, int isPrev) {
		/*
		 * initialize the acceptance of the left management check to true
		 */
		boolean profileAccepted = true;

		/*
		 * initialize the acquisition to check
		 */
		Acquisition acqToheck = null;

		/*
		 * if the check is with previous
		 */
		if (isPrev == 1) {

			acqToheck = curr;
		} else {
			acqToheck = prev;
		}
		// get the current logger
		Logger logger = DroolsParameters.getLogger();

		// initialize the boolean variable to check if the maneuver is
		boolean manInPrevMhCannotBeCancelled = false;

		// get all the valid acquisitions
		TreeMap<Long, EnergyAssociatedToTask> essFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(curr.getSatelliteId());
		boolean doneCheckLeft = false;
		// get all the silents
		TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions
				.getSilentFunctionAssociatedToSat(curr.getSatelliteId());

		// get all the maneuvers
		TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(curr.getSatelliteId());

		// initialize the impossible date to the current mh start time
		long impossibleBeforeDate = droolsParams.getCurrentMH().getStart().getTime();

		// create a new instance of maneuver resources
		ManeuverResources manRes = new ManeuverResources();
		manRes.setSatId(curr.getSatelliteId());
		//
		if ((prev.getReferredEquivalentDto() != null) && (curr.getReferredEquivalentDto() != null)
				&& (prev.getReferredEquivalentDto() == curr.getReferredEquivalentDto())) {
			logger.debug(
					"MANEUVER_MANAGEMENT_WITH_PREV current acq and previous one are referred to the same equivalent dto, nothing  to do .");
		} else {

			logger.debug("MANEUVER_MANAGEMENT_WITH_PREV : there is a prev acq : " + prev.getIdTask() + ", startTime : "
					+ prev.getStartTime());

			// if there are involved man
			if (involvedMan.size() > 0) {

				// iterate over them
				for (int i = 0; i < involvedMan.size(); i++) {

					// extract i-esim man
					Maneuver manExtracted = involvedMan.get(i);
					logger.debug("MANEUVER_MANAGEMENT_WITH_PREV found man  : " + manExtracted);

					// if the man isreferred to previous mission horizon
					if (manExtracted.getStartTime().getTime() < droolsParams.getCurrentMH().getStart().getTime()) {

						// set it as impossible to remove
						manInPrevMhCannotBeCancelled = true;

					}
					// else if isn't a pitch
					else if (!manExtracted.getType().toString().startsWith("Pitch")) {
						// add to the list of old man that must be removed
						manRes.getOldMans().add(manExtracted);

						// remove from structure
						allMan.remove(manExtracted.getStartTime().getTime());

						// flag as rejected
						manExtracted.setRejected(true);
					}
				}
			}

			// if current and next have different lookside
			if (!curr.getLookSide().equalsIgnoreCase(prev.getLookSide())) {
				// logger.debug("MANEUVER_MANAGEMENT_WITH_PREV : different
				// lookSide -> plan maneuver classic case ");
				if (prev.getStartTime().getTime() < droolsParams.getCurrentMH().getStart().getTime()) {
					if (!manInPrevMhCannotBeCancelled && !curr.getLookSide()
							.equalsIgnoreCase(droolsParams.getSatWithId(curr.getSatelliteId()).getInitialLookSide())) {
						boolean fromLeft = false;
						if (droolsParams.getSatWithId(curr.getSatelliteId()).getInitialLookSide()
								.equalsIgnoreCase("left")) {
							fromLeft = true;
						}
						// set the delimiter before it is impossible to perform a maneuver
						impossibleBeforeDate = droolsParams.getCurrentMH().getStart().getTime();

						// invoke the algo o create a man between interval
						manRes = createManBetweenAcqAndInterval(
								droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties()
										.isStartWithRw(),
								impossibleBeforeDate, curr, manRes, droolsParams, resourceFunctions, fromLeft, 0);
					}
				} else {
					boolean fromLeft = true;
					if (curr.getLookSide().equalsIgnoreCase("left")) {
						fromLeft = false;
					}
					// invoke the algo o create a man between interval
					manRes = createManBetweenAcq(
							droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							prev, curr, manRes, droolsParams, resourceFunctions, 0, fromLeft, false);
				}
			} else if (curr.getLookSide().equalsIgnoreCase("left")) {
				logger.debug(
						"MANEUVER_MANAGEMENT_WITH_PREV : both in left, check if the left attitude profile is valid...");
				// compute the gap
				long gapBetweenLeftAndLeft = curr.getStartTime().getTime() - prev.getEndTime().getTime();
				logger.debug("gap between left and left :" + (gapBetweenLeftAndLeft / 60000));
				logger.debug("check versus maxTimeBetweenTwoLeftAcquisitions : "
						+ droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties()
								.getMaxTimeBetweenTwoLeftAcquisitions());

				// if the time is enougth to came back in right
				if ((gapBetweenLeftAndLeft / 60000) > droolsParams.getSatWithId(curr.getSatelliteId())
						.getSatelliteProperties().getMaxTimeBetweenTwoLeftAcquisitions()) {

					// create contermaneuver from left to right nd from right to left again
					manRes = createContermaneuver(prev, curr, droolsParams, resourceFunctions, manRes);
					logger.debug("MAN RES : " + manRes);
					if (manRes.isPossible()) {
						logger.debug(
								"REMOVE_ACQ_RULE_CheckIfNeedAManeuverWithNext________________ :Repairing action remove reason of reject ! :"
										+ curr);
						acqToheck.getReasonOfReject().clear();
						acqToheck.setRejected(false);
						for (int i = 0; i < manRes.getOldMans().size(); i++) {
							allMan.remove(manRes.getOldMans().get(i).getStartTime().getTime());
						}

						for (int i = 0; i < manRes.getNewMans().size(); i++) {
							allMan.put(manRes.getNewMans().get(i).getStartTime().getTime(), manRes.getNewMans().get(i));
						}

						logger.debug("MANEUVER_MANAGEMENT_WITH_PREV : check leftattitude");

						// invok the algo to check the left attitude
						profileAccepted = this.leftMng.computeMaxTimeLeftAlgo(acqToheck, droolsParams, allMan,
								essFunction, silentFunction, "MANEUVER_MANAGEMENT_WITH_PREV");

						// if the left attitude is valid
						if (profileAccepted) {
							// remov the reason of reject for the acq
							acqToheck.getReasonOfReject().clear();
							acqToheck.setRejected(false);
						}
						// if is invalid
						else {
							// mark as impossile
							manRes.setPossible(false);
							// REMOVE CONTERMAN AND TRY WITH A SINGLE PLATEAU
							logger.debug("REMOVE CONTERMAN AND TRY WITH A SINGLE PLATEAU");

							// if the maxtime in left period is valid
							if ((gapBetweenLeftAndLeft / 60000) < droolsParams.getSatWithId(curr.getSatelliteId())
									.getSatelliteProperties().getMaxTimeInAllTheLeftPeriod()) {
								// iterate over the man just created
								for (int i = 0; i < manRes.getNewMans().size(); i++) {
									// remove them from structure
									allMan.remove(manRes.getNewMans().get(i).getStartTime().getTime());
								}
								// check the left attitude
								profileAccepted = this.leftMng.computeMaxTimeLeftAlgo(acqToheck, droolsParams, allMan,
										essFunction, silentFunction, "MANEUVER_MANAGEMENT_WITH_PREV");
								if (profileAccepted) {
									acqToheck.getReasonOfReject().clear();
									acqToheck.setRejected(false);
									manRes.getNewMans().clear();
									manRes.setPossible(true);
								} else {
									if (isPrev > 0) {
										manRes.setPossible(true);
										profileAccepted = true;
									}
								}
								doneCheckLeft = true;
							}

						}
					}

				}
			} else {
				logger.debug("MANEUVER_MANAGEMENT_WITH_PREV : both in right, nothing to do");
			}

			// if man Res is valid
			if (manRes != null) {
				if (manRes.isPossible() && !doneCheckLeft) {
					for (int i = 0; i < manRes.getOldMans().size(); i++) {
						// remove from structyure
						allMan.remove(manRes.getOldMans().get(i).getStartTime().getTime());
					}

					// for all new man
					for (int i = 0; i < manRes.getNewMans().size(); i++) {
						// insert into the structyure
						allMan.put(manRes.getNewMans().get(i).getStartTime().getTime(), manRes.getNewMans().get(i));
					}
					logger.debug("MANEUVER_MANAGEMENT_WITH_PREV : check leftattitude");
					profileAccepted = this.leftMng.computeMaxTimeLeftAlgo(acqToheck, droolsParams, allMan, essFunction,
							silentFunction, "MANEUVER_MANAGEMENT_WITH_PREV");
				}
				if (profileAccepted && manRes.isPossible()) {
					acqToheck.getReasonOfReject().clear();
					acqToheck.setRejected(false);
				}
				// else
				// {
				// curr.addReasonOfReject(36,
				// ReasonOfReject.leftAttitudeModeViolation, "Left Attitude
				// Constrains Violation", 0, 0, null);
				// rejected.put(curr.getId(), curr);
				// curr.setRejected(true);
				// kie.update(kie.getFactHandle(curr), curr);
				// }
			}

		}
		return manRes;
	}

	/**
	 * Creates the man with next.
	 *
	 * @param curr              the curr
	 * @param next              the next
	 * @param involvedMan       the involved man
	 * @param sessionId         the session id
	 * @param sessionInstance   the session instance
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @return the maneuver resources
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public ManeuverResources createManWithNext(Acquisition curr, Acquisition next, List<Maneuver> involvedMan,
			String sessionId, int sessionInstance, DroolsParameters droolsParams, ResourceFunctions resourceFunctions)
			throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		logger.debug("MANEUVER_MANAGEMENT_WITH_NEXT for acq : " + curr);

		// get the current session
		String sessionIdConcat = DroolsParameters.concatenateSession(sessionId, sessionInstance);

		// get the related kieSession
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);

		// initialize the maneuverResources
		ManeuverResources manRes = new ManeuverResources();

		// set the satelliteId
		manRes.setSatId(curr.getSatelliteId());

		// get the treemap of maneuvers
		TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(curr.getSatelliteId());
		logger.debug("MANEUVER_MANAGEMENT_WITH_NEXT allMan size : " + allMan.size());
		logger.debug("MANEUVER_MANAGEMENT_WITH_NEXT allMan : " + allMan);

		// get the rejected elements
		HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");

		// if there is a next acquisition
		if (next != null) {
			manRes = manWithPrevExistPrevious(curr, next, involvedMan, droolsParams, resourceFunctions, sessionIdConcat,
					0);
		} else {
			// doesn't exists a previous acq, check the consistence with the
			// initial
			// lookside of the satellite
			manRes = manWithPrevNotExistPrevious(curr, involvedMan, droolsParams, resourceFunctions, sessionIdConcat,
					false);
		}

		if (!manRes.isPossible()) {
			// logger.debug("MANEUVER_MANAGEMENT_WITH_PREV invalid check :
			// removing acq that need a maneuver : " + curr);
			rejected.put(curr.getId(), curr);
			curr.setRejected(true);
			kie.update(kie.getFactHandle(curr), curr);
		} else {
			curr.setRejected(false);
			curr.getReasonOfReject().clear();
			manRes.getOldMans().addAll(involvedMan);
		}
		logger.debug("MANEUVER_MANAGEMENT_WITH_NEXT manRes " + manRes);
		manRes.setSatId(curr.getSatelliteId());
		return manRes;
	}

	/**
	 * Check if overlap DLO or paw.
	 *
	 * @param prevOrNext   the prev or next
	 * @param current      the curren acquisition to check
	 * @param toDate       the to date
	 * @param droolsParams the drools params
	 * @return the tree map
	 */
	protected TreeMap<Date, Date> checkIfOverlapDLOOrPaw(Acquisition prevOrNext, Acquisition current, Date toDate,
			DroolsParameters droolsParams) {
		TaskPlanned taskPlanned = new TaskPlanned();

		// get the tranquillization time
		double tranquillizationTime = droolsParams.getTranquillizationTime() * 1000;

		// extract the satellite id
		String satId = this.manUtils.getSatId(current, prevOrNext);

		// create an empty DateResource
		DateResource dateRes = new DateResource();

		// create an empty TreeMap to memorize the start and the stop time of a
		// valid interval for the maneuver
		TreeMap<Date, Date> startStopOverlap = new TreeMap<>();

		// start valid time for the maneuver
		Date startCheck = null;

		// end valid time for the maneuver
		Date endCheck = null;

		// create an empty list of visibility
		List<Visibility> allVisInOverlap = new ArrayList<>();

		// create an empty list of paw
		List<PAW> allPawInOverlap = new ArrayList<>();

		// if prevOrNext is not null,
		// we are in case of one acquisition versus
		// another one
		if (prevOrNext != null) {
			// prevOrNext is previous to the current acq
			// startCheck = prevOrNext stopTime endCheck = prevOrNext startTime
			if (prevOrNext.getStartTime().before(current.getStartTime())) {
				// set as start the end time of the previous acq
				startCheck = prevOrNext.getEndTime();

				// set as end the current acq start time
				endCheck = new Date((long) (current.getStartTime().getTime() - tranquillizationTime));

				// use the right margin (from right to left) as end for the
				// maneuver
				dateRes.setEnd(true);

				// if the previous acq is left
				if (prevOrNext.getLookSide().equalsIgnoreCase("left")) {
					// use the left margin as start for the maneuver
					dateRes.setEnd(false);
				}

				// if the prev acquisition is before
				if (prevOrNext.getStartTime().getTime() < droolsParams.getCurrentMH().getStart().getTime()) {
					// set as start the end time of the previous acq
					startCheck = droolsParams.getCurrentMH().getStart();
				}
			} else
			// prevOrNext is next to the current acq startCheck = current
			// stopTime endCheck = prevOrNext startTime
			{
				// set as start the end time of the current acq
				startCheck = current.getEndTime();

				// set as end the current acq start time
				endCheck = new Date((long) (prevOrNext.getStartTime().getTime() - tranquillizationTime));

				// use the left margin as start for the maneuver
				dateRes.setEnd(false);

				// if the next acq is left
				if (prevOrNext.getLookSide().equalsIgnoreCase("left")) {
					// use the right margin (from right to left) as end for the
					// maneuver
					dateRes.setEnd(true);
				}
			}

		}
		// in this case we are checking the case
		// Acq versus hpSegment or mission horizon start/stop
		else {

			if (toDate.before(current.getStartTime())) {
				// set the start check with the limit date
				startCheck = toDate;

				// set the endCheck with the current start time
				endCheck = new Date((long) (current.getStartTime().getTime() - tranquillizationTime));

				// mark as default
				dateRes.setEnd(false);

				// if the acq has left lookside
				if (current.getLookSide().equalsIgnoreCase("left")) {
					// starts from end
					dateRes.setEnd(true);
				}
			}
			// date is after current
			else {
				// set the start check
				startCheck = current.getEndTime();

				// set the end check
				endCheck = new Date((long) (toDate.getTime() - tranquillizationTime));

				// if the delimiter has the same time of che current acq end
				// time
				if (toDate.getTime() == current.getEndTime().getTime()) {
					// set the end with the mh stop time
					endCheck = new Date(
							(long) (droolsParams.getCurrentMH().getStop().getTime() - tranquillizationTime));
				}

				// starts from end
				dateRes.setEnd(true);

				// if the acq has left lookside
				if (current.getLookSide().equalsIgnoreCase("left")) {
					// starts from start
					dateRes.setEnd(false);
				}
			}
		}

		// get all visibilities in overlap with interval
		allVisInOverlap = taskPlanned.getAllVisOverlapInterval(droolsParams, startCheck, endCheck, satId);
		// logger.debug("only vis in overlap : " + allVisInOverlap);

		// get all paws in overlap with interval
		allPawInOverlap = taskPlanned.getAllPawOverlapInterval(droolsParams, startCheck, endCheck, satId);
		// logger.debug("only paw in overlap : " + allPawInOverlap);

		// merge these two set
		List<PlanningResources> visAndPawInOverlap = this.manUtils.mergeListOverlappedElements(allVisInOverlap,
				allPawInOverlap);

		// if there are visibilities/paw in overlap
		if (!visAndPawInOverlap.isEmpty()) {
			// return a list of valid period where fit the new maneuver
			startStopOverlap = processOverlappedVis(startCheck, endCheck, visAndPawInOverlap, droolsParams);
		}
		// no visibilities/paw in overlap
		else {
			if ((endCheck.getTime() - startCheck.getTime()) >= (droolsParams.getTimeForManeuverCmga() * 1000)) {
				startStopOverlap.put(startCheck, endCheck);
			}

		}

		// if (startStopOverlap.size() > 0)
		// {
		// boolean ascending =
		// this.manUtils.computeAscendingOrDiscending(current, prevOrNext,
		// toDate);
		// dateRes = this.manUtils.findElement(dateRes, startStopOverlap,
		// satProp.isStartWithRw(), droolsParams.getTimeForManeuverRW(),
		// droolsParams.getTimeForManeuverCmga(), ascending);
		// }
		// else
		// {
		// // logger.debug("interval all covered by PAW / DLO or is too
		// // short");
		// dateRes.setStart(null);
		// dateRes.setStop(null);
		// }
		return startStopOverlap;
	}

	/**
	 * Process overlapped vis.
	 *
	 * @param from            the from
	 * @param to              the to
	 * @param allVisInOverlap the all vis in overlap
	 * @param droolsParams    the drools params
	 * @return the tree map
	 */
	public TreeMap<Date, Date> processOverlappedVis(Date from, Date to, List<PlanningResources> allVisInOverlap,
			DroolsParameters droolsParams) {
		Logger logger = DroolsParameters.getLogger();
		logger.debug("interval start : " + from);
		logger.debug("interval end : " + to);

		long timeForCMGA = (long) (droolsParams.getTimeForManeuverCmga() + droolsParams.getTranquillizationTime());
		long timeToCheck = timeForCMGA;

		// logger.debug("time for rw : " + droolsParams.getTimeForManeuverRW());
		// logger.debug("tanquill time : " +
		// droolsParams.getTranquillizationTime());

		// logger.debug("time for cmga : " +
		// droolsParams.getTimeForManeuverCmga());

		this.manUtils.sortOverlappedElementList(allVisInOverlap);
		TreeMap<Date, Date> startAndStop = new TreeMap<>();
		Date stopTimePrevElement = allVisInOverlap.get(0).getEndTime();

		// logger.debug("from vis : " + allVisInOverlap.get(0));
		// logger.debug("with start : " + startTimePrevElement + "and stop : " +
		// stopTimePrevElement);

		long validInterval = 0;

		// if startTime of resource in overlap is next to the start of check
		if (allVisInOverlap.get(0).getStartTime().getTime() >= from.getTime()) {
			validInterval = (allVisInOverlap.get(0).getStartTime().getTime() - from.getTime()) / 1000;
			this.manUtils.addGapToListIfIsValid(timeToCheck, startAndStop, from, validInterval);
		}

		if (allVisInOverlap.size() > 1) {
			for (int i = 1; i < allVisInOverlap.size(); i++) {
				Date startTimeNextElement = allVisInOverlap.get(i).getStartTime();
				// logger.debug("versus vis : " + allVisInOverlap.get(i));
				if (startTimeNextElement.getTime() > stopTimePrevElement.getTime()) {
					// there is a slot possibly not in overlap
					long possiblyTime = (startTimeNextElement.getTime() - stopTimePrevElement.getTime()) / 1000;
					// logger.debug("valid interval : " + possiblyTime);
					this.manUtils.addGapToListIfIsValid(timeToCheck, startAndStop, stopTimePrevElement, possiblyTime);
				} else {
					// logger.debug("elements totally in overlap, no empty
					// spaces");
				}
				stopTimePrevElement = allVisInOverlap.get(i).getEndTime();
				// logger.debug("from vis : " + allVisInOverlap.get(i));

			}

		}
		if (stopTimePrevElement.getTime() < to.getTime()) {
			validInterval = (to.getTime() - stopTimePrevElement.getTime()) / 1000;
			// logger.debug("valid interval : " + validInterval);
			this.manUtils.addGapToListIfIsValid(timeToCheck, startAndStop, stopTimePrevElement, validInterval);
		}

		logger.debug("startAndStop : " + startAndStop);
		return startAndStop;
	}

	/**
	 * Creates the man.
	 *
	 * @param startWithRw                 the start with rw
	 * @param impossibleBeforeOrAfterDate the impossible before or after date
	 * @param current                     the current
	 * @param manRes                      the man res
	 * @param droolsParams                the drools params
	 * @param resourceFunc                the resource func
	 * @param fromLeft                    the from left
	 * @param cont                        the cont to take in account the number of
	 *                                    try to create a man : 0 = first try (no
	 *                                    fail on rw and on cmg) 1 = second try
	 *                                    (there is a fail on rw or on cmg
	 *                                    (maneuvers barrells) 2 = no more try
	 *                                    (there is a fail on both rw and cmg)
	 * @return the maneuver resources
	 */

	public ManeuverResources createManBetweenAcqAndInterval(boolean startWithRw, long impossibleBeforeOrAfterDate,
			Acquisition current, ManeuverResources manRes, DroolsParameters droolsParams,
			ResourceFunctions resourceFunc, boolean fromLeft, int cont) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		logger.debug("createManBetweenAcqAndInterval");

		// get the time necesssary to perform a rw maneuver
		long timeForRw = droolsParams.getTimeForManeuverRW();

		// get the time necessary to perform a cmga maneuver
		long timeForCmga = droolsParams.getTimeForManeuverCmga();

		// initialize the gap variable
		long gap = 99999;

		// initialize the lower/higher border
		// before/after which is impossible to perform a maneuver
		Date impossibleFrom = null;

		// if the Date before or after is impossible to plan a new maneuver is
		// setted
		if (impossibleBeforeOrAfterDate > -1) {
			// store it inside the impossibleFrom variable
			impossibleFrom = new Date(impossibleBeforeOrAfterDate);
			// logger.debug("impossible from " + impossibleFrom);
		}

		// get the satellite id
		String satId = current.getSatelliteId();
		// logger.debug("sat id " + satId);

		// extract the maneuver function
		// associated with the current satellite
		TreeMap<Long, Maneuver> allMan = resourceFunc.getManeuverFunctionAssociatedToSat(satId);

		// create an instance of data
		// resources to store all the informations
		// about new maneuvers
		DateResource dateRes = new DateResource();

		// if it is still possible to create a maneuver (no previous try or only
		// one fail)
		if (cont < 2) {
			Maneuver newMan = null;

			TreeMap<Date, Date> availableDates = checkIfOverlapDLOOrPaw(null, current, impossibleFrom, droolsParams);

			if (availableDates.size() > 0) {
				dateRes = this.manUtils.findElement(dateRes, availableDates,
						droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
						droolsParams.getTimeForManeuverRW(), droolsParams.getTimeForManeuverCmga(), fromLeft);
			}

			// logger.debug("available time " + dateRes);
			if ((dateRes.getStart() != null) && (dateRes.getStop() != null)) {
				gap = (dateRes.getStop().getTime() - dateRes.getStart().getTime()) / 1000;
				// logger.debug("startTime for man : " + dateRes);
				if (startWithRw) {
					// logger.debug("first choice of maneuver is rw !");
					if (gap < (timeForRw + droolsParams.getTranquillizationTime())) {
						// logger.debug("impossible to start with rw, not enough
						// time !");
						if (gap < (timeForCmga + droolsParams.getTranquillizationTime())) {
							// logger.debug("impossible also with cmga, not
							// enough time !");
							manRes.setPossible(false);
							List<String> allElementsInvolved = new ArrayList<>();
							allElementsInvolved.add(current.getIdTask());
							current.addReasonOfReject(9, ReasonOfReject.noTimeForAManeuver,
									"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
						} else {
							// logger.debug("try with cmga !");
							if (dateRes.getStart().getTime() > current.getStartTime().getTime()) {
								newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, current, null, droolsParams);
							} else {
								newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, null, current, droolsParams);
							}
						}
					} else {
						// logger.debug("try with rw !");
						newMan = tryToPlanRwManWithDate(dateRes, current, impossibleBeforeOrAfterDate, timeForRw,
								droolsParams, fromLeft);
					}
				} else {
					// logger.debug("first choice of maneuver is cmga !");
					if (gap < (timeForCmga + droolsParams.getTranquillizationTime())) {
						// logger.debug("impossible with both cmga or rw, not
						// enough time !");
						List<String> allElementsInvolved = new ArrayList<>();
						allElementsInvolved.add(current.getIdTask());
						current.addReasonOfReject(9, ReasonOfReject.noTimeForAManeuver,
								"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
					} else {
						// logger.debug("try with cmga !");
						if (dateRes.getStart().getTime() > current.getStartTime().getTime()) {
							newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, current, null, droolsParams);
						} else {
							newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, null, current, droolsParams);
						}
					}
				}

				// insert the new man into the manRes slot, if there isn't
				if (newMan != null) {
					// mark as possible
					manRes.setPossible(true);

					if (allMan != null && allMan.get(newMan.getStartTime().getTime()) != null) {
						Maneuver oldManWithSameStart = allMan.get(newMan.getStartTime().getTime());
						oldManWithSameStart.setRejected(true);
						manRes.getOldMans().add(oldManWithSameStart);
					}

					// insert the new maneuver inside the manRes structure
					this.manUtils.insertNeManInmanRes(newMan, manRes);

					// set the satellite id
					manRes.setSatId(newMan.getSatelliteId());

					// insert the new man inside the treemap
					allMan.put(newMan.getStartTime().getTime(), newMan);

					// logger.debug("check if limit on total maneuver is
					// reached");

					// check if is available for total number of maneuvers
					boolean possible = checkIfManIsAvailable(newMan, current, droolsParams, resourceFunc,
							Actuator.total, ReasonOfReject.maxNumberOfTotalManeuverReached);

					// available -> continue with specific number of maneuvers
					if (possible) {
						Actuator manToCheck = null;
						ReasonOfReject reason = null;
						if (newMan.getActuator().compareTo(Actuator.ReactionWheels) == 0) {
							manToCheck = Actuator.ReactionWheels;
							reason = ReasonOfReject.maxNumberOfRWManeuverReached;
						} else {
							manToCheck = Actuator.CMGA;
							reason = ReasonOfReject.maxNumberOfCMGAManeuverReached;
						}
						// logger.debug("check if limit on " + manToCheck + "
						// maneuver is reached");

						possible = checkIfManIsAvailable(newMan, current, droolsParams, resourceFunc, manToCheck,
								reason);
						if (!possible) {
							if (cont == 1) {
								manRes.setPossible(false);
								current.setRejected(true);
							}
							allMan.remove(newMan.getStartTime().getTime());

							manRes.getNewMans().remove(newMan);
							boolean tryWithOtherTypeOfMan = startWithRw;
							if (startWithRw == true) {
								tryWithOtherTypeOfMan = false;
							} else {
								tryWithOtherTypeOfMan = true;
							}
							// logger.debug("limit for " + manToCheck + " man
							// reached -> try with " + secondChoice);
							cont++;
							manRes = createManBetweenAcqAndInterval(tryWithOtherTypeOfMan, impossibleBeforeOrAfterDate,
									current, manRes, droolsParams, resourceFunc, fromLeft, cont);
						} else {
							current.getReasonOfReject().clear();
							current.setRejected(false);
							this.manUtils.insertNeManInmanRes(newMan, manRes);
						}
					} else {
						if (cont == 1) {
							manRes.setPossible(false);
							current.setRejected(true);
						}
						allMan.remove(newMan.getStartTime().getTime());

						manRes.getNewMans().remove(newMan);
						boolean tryWithOtherTypeOfMan = startWithRw;
						if (startWithRw == true) {
							tryWithOtherTypeOfMan = false;
						} else {
							tryWithOtherTypeOfMan = true;
						}
						// logger.debug("limit for " + manToCheck + " man
						// reached -> try with " + secondChoice);
						cont++;
						manRes = createManBetweenAcqAndInterval(tryWithOtherTypeOfMan, impossibleBeforeOrAfterDate,
								current, manRes, droolsParams, resourceFunc, fromLeft, cont);

					}
				} else {
					manRes.setPossible(false);
				}

			} else {
				manRes.setPossible(false);
				// logger.debug("impossible because all overlapped with dlo or
				// no interval");
				List<String> allElementsInvolved = new ArrayList<>();
				allElementsInvolved.add(current.getIdTask());
				DroolsParameters.getLastAcq().addReasonOfReject(10, ReasonOfReject.maneuverOverlapDloOrPaw,
						"Maneuver Overlap DLO", 0, 0, allElementsInvolved);
				DroolsParameters.getLastAcq().setRejected(true);
			}

		}

		// it is impossible to create a maneuver with both rw and cmg
		else {
			// logger.debug("impossible to perform a maneuver !");
			// set the returned manRes to impossible
			manRes.setPossible(false);
		}
		return manRes;
	}

	/**
	 * Creates the man between acq.
	 *
	 * @param startWithRw        the start with rw
	 * @param prev               the prev
	 * @param current            the current
	 * @param manRes             the man res
	 * @param droolsParams       the drools params
	 * @param resourceFunc       the resource func
	 * @param cont               the cont
	 * @param leftToLeft         the left to left
	 * @param repairingForRemove the repairing for remove
	 * @return the maneuver resources
	 */
	public ManeuverResources createManBetweenAcq(boolean startWithRw, Acquisition prev, Acquisition current,
			ManeuverResources manRes, DroolsParameters droolsParams, ResourceFunctions resourceFunc, int cont,
			boolean leftToLeft, boolean repairingForRemove) {
		// set that default reason of maneuver to classic maneuver (no
		// conterman)
		boolean contermaneuver = false;
		if (prev.getLookSide().equalsIgnoreCase(current.getLookSide()) && prev.getLookSide().equalsIgnoreCase("left")) {
			contermaneuver = true;
		}

		// initialize the gap
		long gap = 99999;

		// initialize the date before or after that is impossible to plan the
		// maneuver
		Date impossibleFrom = null;

		// initialize the logger
		Logger logger = DroolsParameters.getLogger();

		// logger.debug("createManBetweenAcq");

		// extract the satellite id
		String satId = this.manUtils.getSatId(prev, current);

		// receive the maneuver hashmap related to the current satellite
		TreeMap<Long, Maneuver> allMan = resourceFunc.getManeuverFunctionAssociatedToSat(satId);

		// initialize the DateResource where will be stored the start and stop
		// time of the interval where will be placed the maneuver
		DateResource dateRes = new DateResource();

		// this function is called max 2 times, 1 for each maneuver type . In
		// case the first maneuver type failed for some reason, this function is
		// invoked with the other man type as repairing action
		if (cont < 2) {
			// initialize the new maneuver
			Maneuver newMan = null;

			// get the time for a rw
			long timeForRw = droolsParams.getTimeForManeuverRW();

			// get the time for a cmga
			long timeForCmga = droolsParams.getTimeForManeuverCmga();

			// compute the gap between current and previous acq
			gap = (current.getStartTime().getTime() - prev.getEndTime().getTime()) / 1000;

			// if previous acq is before the current mission horizon start time
			if (prev.getStartTime().getTime() < droolsParams.getCurrentMH().getStart().getTime()) {
				// update the gap considering only the time between current acq
				// and mh start time
				gap = (current.getStartTime().getTime() - droolsParams.getCurrentMH().getStart().getTime()) / 1000;
			}

			// if the first choice is rw
			if (startWithRw) {
				// logger.debug("first choice of maneuver is rw !");

				// if the gap is not enough to plan a rw
				if (gap < (timeForRw + droolsParams.getTranquillizationTime())) {
					// logger.debug("impossible to start with rw, not enough
					// time !");
					// if the gap is not enough also for a cmga
					if (gap < (timeForCmga + droolsParams.getTranquillizationTime())) {
						// logger.debug("impossible also with cmga, not enough
						// time !");
						// mark the manResource as impossible
						manRes.setPossible(false);

						// inizialize a list of involved elements
						List<String> allElementsInvolved = new ArrayList<>();

						// add prev and current to the list of involved elements
						allElementsInvolved.add(prev.getIdTask());
						allElementsInvolved.add(current.getIdTask());

						// mark the last acq as rejected for no time for a
						// maneuver
						DroolsParameters.getLastAcq().addReasonOfReject(9, ReasonOfReject.noTimeForAManeuver,
								"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
					}
					// the gap is not enough for a
					// rw but is sufficient for a
					// cmga
					else {
						// logger.debug("try with cmga !");

						TreeMap<Date, Date> availableDates = checkIfOverlapDLOOrPaw(prev, current, impossibleFrom,
								droolsParams);

						if (availableDates.size() > 0) {
							dateRes = this.manUtils.findElement(dateRes, availableDates,
									droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties()
											.isStartWithRw(),
									droolsParams.getTimeForManeuverRW(), droolsParams.getTimeForManeuverCmga(),
									leftToLeft);
							
							newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, prev, current, droolsParams);

						}
//TODO : removed for coverage
//						if ((dateRes.getStart() != null) && (dateRes.getStop() != null)) {
//							newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, prev, current, droolsParams);
//						} 
					else {
							manRes.setPossible(false);
							List<String> allElementsInvolved = new ArrayList<>();
							allElementsInvolved.add(prev.getIdTask());
							allElementsInvolved.add(current.getIdTask());
							DroolsParameters.getLastAcq().addReasonOfReject(9, ReasonOfReject.maneuverOverlapDloOrPaw,
									"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
						}
					}
				} else {
					logger.debug("try with rw !");
					TreeMap<Date, Date> availableDates = checkIfOverlapDLOOrPaw(prev, current, impossibleFrom,
							droolsParams);
					if (availableDates.size() > 0) {
						dateRes = this.manUtils.findElement(dateRes, availableDates,
								droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties()
										.isStartWithRw(),
								droolsParams.getTimeForManeuverRW(), droolsParams.getTimeForManeuverCmga(), leftToLeft);
					} else {
						manRes.setPossible(false);
						manRes.setPossible(false);
						List<String> allElementsInvolved = new ArrayList<>();
						allElementsInvolved.add(prev.getIdTask());
						allElementsInvolved.add(current.getIdTask());
						DroolsParameters.getLastAcq().addReasonOfReject(9, ReasonOfReject.maneuverOverlapDloOrPaw,
								"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
						DroolsParameters.getLastAcq().setRejected(true);
					}
					if ((dateRes.getStart() != null) && (dateRes.getStop() != null)) {
						newMan = tryToPlanRwMan(dateRes, prev, current, timeForRw, droolsParams);
					} else {
						if (!contermaneuver) {
							manRes.setPossible(false);
							List<String> allElementsInvolved = new ArrayList<>();
							allElementsInvolved.add(prev.getIdTask());
							allElementsInvolved.add(current.getIdTask());
							DroolsParameters.getLastAcq().addReasonOfReject(9, ReasonOfReject.maneuverOverlapDloOrPaw,
									"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
							DroolsParameters.getLastAcq().setRejected(true);
						}
					}
				}
			} else {
				// logger.debug("first choice of maneuver is cmga !");
				if (gap < (timeForCmga + droolsParams.getTranquillizationTime())) {
					logger.debug("impossible with both cmga or rw, not enough time !");
					List<String> allElementsInvolved = new ArrayList<>();
					allElementsInvolved.add(prev.getIdTask());
					allElementsInvolved.add(current.getIdTask());
					DroolsParameters.getLastAcq().addReasonOfReject(9, ReasonOfReject.noTimeForAManeuver,
							"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
				} else {
					logger.debug("try with cmga !");
					TreeMap<Date, Date> availableDate = checkIfOverlapDLOOrPaw(prev, current, impossibleFrom,
							droolsParams);
					if (availableDate.size() > 0) {
						dateRes = this.manUtils.findElement(dateRes, availableDate,
								droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties()
										.isStartWithRw(),
								droolsParams.getTimeForManeuverRW(), droolsParams.getTimeForManeuverCmga(), leftToLeft);
					}
					if ((dateRes.getStart() != null) && (dateRes.getStop() != null)) {
						newMan = this.cmgaMng.tryWithCmgaMan(dateRes, satId, prev, current, droolsParams);
					} else {
						if (!contermaneuver) {
							manRes.setPossible(false);
							List<String> allElementsInvolved = new ArrayList<>();
							allElementsInvolved.add(prev.getIdTask());
							allElementsInvolved.add(current.getIdTask());
							DroolsParameters.getLastAcq().addReasonOfReject(9, ReasonOfReject.maneuverOverlapDloOrPaw,
									"Insufficient Time For Maneuver", 0, 0, allElementsInvolved);
						}
					}
				}
			}

			// insert the new man into
			// the manRes slot, if there isn't
			if (newMan != null) {
				boolean found = false;
				if (manRes.getNewMans().size() > 0) {
					for (int i = 0; i < manRes.getNewMans().size(); i++) {
						if (manRes.getNewMans().get(i).equals(newMan)) {
							found = true;
						}
					}
					if (!found) {
						manRes.getNewMans().add(newMan);
					}
				} else {
					manRes.getNewMans().add(newMan);
				}
				manRes.setSatId(newMan.getSatelliteId());

				allMan.put(newMan.getStartTime().getTime(), newMan);

				logger.debug("check if limit on total maneuver is reached");

				// check if the man is available for total number of maneuvers
				boolean possible = checkIfManIsAvailable(newMan, current, droolsParams, resourceFunc, Actuator.total,
						ReasonOfReject.maxNumberOfTotalManeuverReached);

				// is available
				if (possible) {
					logger.debug("limit on total maneuver is NOT reached");

					Actuator manToCheck = null;
					ReasonOfReject reason = null;
					if (newMan.getActuator().compareTo(Actuator.ReactionWheels) == 0) {
						manToCheck = Actuator.ReactionWheels;
						reason = ReasonOfReject.maxNumberOfRWManeuverReached;
					} else {
						manToCheck = Actuator.CMGA;
						reason = ReasonOfReject.maxNumberOfCMGAManeuverReached;
					}

					logger.debug("check if limit on " + manToCheck + " maneuver is reached");

					// check if the man is available for the type of maneuver
					// specific of the just created man
					possible = checkIfManIsAvailable(newMan, current, droolsParams, resourceFunc, manToCheck, reason);
					if (!possible) {
						logger.debug("limit on " + manToCheck + "maneuver is reached");

						if (cont == 1) {
							manRes.setPossible(false);
							DroolsParameters.getLastAcq().setRejected(true);
						}
						logger.debug("MAN RES AFTER INVALID MAX NUMBER MAN: " + allMan);
						allMan.remove(newMan.getStartTime().getTime());
						allMan.remove(newMan.getStartTime().getTime());

						logger.debug("MAN RES AFTER REMOVE INVALID MAX NUMBER MAN: " + allMan);

						this.manUtils.clearManRes(manRes);
						boolean tryWithOtherTypeOfMan = startWithRw;
						if (startWithRw == true) {
							tryWithOtherTypeOfMan = false;
						} else {
							tryWithOtherTypeOfMan = true;
						}

						cont++;
						manRes = createManBetweenAcq(tryWithOtherTypeOfMan, prev, current, manRes, droolsParams,
								resourceFunc, cont, leftToLeft, repairingForRemove);
					} else {
						logger.debug("limit on " + manToCheck + "maneuver is NOT reached");

						prev.getReasonOfReject().clear();
						prev.setRejected(false);

						current.getReasonOfReject().clear();
						current.setRejected(false);

						manRes.setPossible(true);
					}

				} else {
					manRes.setPossible(false);
				}

			} else {
				logger.debug("impossible to perform a maneuver !");
				manRes.setPossible(false);
			}
		} else {
			// logger.debug("impossible to perform a maneuver !");
			manRes.setPossible(false);
		}
		return manRes;
	}

	/**
	 * Creates the contermaneuver.
	 *
	 * @param prev              the prev
	 * @param curr              the curr
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param manRes            the man res
	 * @return the maneuver resources
	 */
	public ManeuverResources createContermaneuver(Acquisition prev, Acquisition curr, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions, ManeuverResources manRes) {
		// initialize the satellite id
		String satId = null;

		// initialize the available start time for the maneuver with the mh
		// start time
		long prevEndTime = droolsParams.getCurrentMH().getStart().getTime();

		// initialize the available end time for the maneuver with the mh end
		// time
		long currStartTime = droolsParams.getCurrentMH().getStop().getTime();
		long impossibleBeforeOrAfterADate = prevEndTime;
		int typeOfAction = 0;
		Acquisition acqToCheck = null;
		if ((prev != null) && (curr != null)) {
			satId = curr.getSatelliteId();
			prevEndTime = prev.getEndTime().getTime();
			currStartTime = curr.getStartTime().getTime();
			typeOfAction = 0;
			impossibleBeforeOrAfterADate = curr.getStartTime().getTime();
			acqToCheck = prev;
		}
		// only curr is null
		else if (curr == null) {
			prevEndTime = prev.getEndTime().getTime();
			satId = prev.getSatelliteId();
			// typeOfAction = 1;
			impossibleBeforeOrAfterADate = droolsParams.getCurrentMH().getStop().getTime();
			acqToCheck = prev;

		}
		// only prev is null,
		else {
			currStartTime = curr.getStartTime().getTime();
			satId = curr.getSatelliteId();
			// typeOfAction = 2;
			satId = curr.getSatelliteId();
			impossibleBeforeOrAfterADate = droolsParams.getCurrentMH().getStart().getTime();
			acqToCheck = curr;

		}

		long gap = currStartTime - prevEndTime;

		SatelliteProperties satProp = droolsParams.getSatWithId(satId).getSatelliteProperties();

		if ((gap / 1000) > (droolsParams.getTimeForManeuverRW() * 2)) {

			manRes = createManBetweenAcqAndInterval(satProp.isStartWithRw(), impossibleBeforeOrAfterADate, acqToCheck,
					manRes, droolsParams, resourceFunctions, true, 0);

			// logger.debug("CheckIfNeedAManeuverWithPrev________________ :
			// manResAfterFirstMan " + manRes);
			if (manRes.isPossible()) {
				if (typeOfAction != 1) {
					manRes = createManBetweenAcqAndInterval(satProp.isStartWithRw(),
							manRes.getNewMans().get(0).getEndTime().getTime(), curr, manRes, droolsParams,
							resourceFunctions, false, 0);
					// logger.debug("CheckIfNeedAManeuverWithPrev________________
					// : manResAfterFirstMan " + manRes);
					if (!manRes.isPossible()) {
						// logger.debug("CheckIfNeedAManeuverWithPrev________________
						// :error when creating the second contermaneuver ");
					}
				}

			}
		} else {
			if ((prev != null) && (curr != null)) {
				manRes = createManBetweenAcqAndInterval(satProp.isStartWithRw(), curr.getEndTime().getTime(), curr,
						manRes, droolsParams, resourceFunctions, true, 0);
			}
		}
		return manRes;
	}

	/**
	 * Try to plan rw man.
	 *
	 * @param dateRes      the date res
	 * @param prev         the prev
	 * @param current      the current
	 * @param timeForRw    the time for rw
	 * @param droolsParams the drools params
	 * @return the maneuver
	 */
	public Maneuver tryToPlanRwMan(DateResource dateRes, Acquisition prev, Acquisition current, long timeForRw,
			DroolsParameters droolsParams) {
		// extract the saellite id
		String satelliteId = this.manUtils.getSatId(prev, current);
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// initialize the id of the prev acq to x
		String prevId = "x";

		// initialize the id of the next acq to x
		String currentId = "x";
		long startTimeAsLong = dateRes.getStart().getTime();
		long endTimeAsLong = startTimeAsLong + (timeForRw * 1000);

		// if the man is to a left acq
		// and the interval is
		// before the current acq
		if (current.getLookSide().equalsIgnoreCase("left") && dateRes.getStop().before(current.getStartTime())) {

			// set thedateRes as descending order
			dateRes.setEnd(true);
		}

		// create a new man
		Maneuver manRw = new Maneuver();

		// initialize the lookside
		manRw.setRightToLeftFlag(true);

		if (dateRes.isEnd()) {
			// compute the end time
			endTimeAsLong = (dateRes.getStop().getTime());
			// compute the start time
			startTimeAsLong = endTimeAsLong - (timeForRw * 1000);
		}
		Date startTimeMan = null;
		Date endTimeMan = null;

		manRw = new Maneuver();
		// set the correct id for prev
		prevId = prev.getIdTask();

		// set the correct id for curr
		currentId = current.getIdTask();

		// if the man is a L2R
		if (current.getLookSide().equalsIgnoreCase("right")) {
			// set the corrent lookide
			if (current.getStartTime().before(prev.getStartTime())) {
				// R2L
				manRw.setRightToLeftFlag(true);

			} else {
				// L2R
				manRw.setRightToLeftFlag(false);

			}
			// set the end time
			endTimeMan = new Date(endTimeAsLong);
			// set the start time
			startTimeMan = new Date(startTimeAsLong);
		} else // current is left
		{
			if (current.getStartTime().before(prev.getStartTime())) {
				manRw.setRightToLeftFlag(false);
			} else {
				manRw.setRightToLeftFlag(true);
			}
			endTimeMan = new Date(endTimeAsLong);
			startTimeMan = new Date(startTimeAsLong);
		}
		// set the correct id for prev
		manRw.setAcq1Id(prevId);
		// set the correct id for next
		manRw.setAcq2Id(currentId);

		// set the startTime
		manRw.setStartTime(startTimeMan);

		// set the endTime
		manRw.setEndTime(endTimeMan);

		// set the satelliteId
		manRw.setSatelliteId(satelliteId);

		// set the actuator
		manRw.setActuator(Actuator.ReactionWheels);

		// set the maneuver type
		manRw.setType(ManeuverType.RollSlew);

		// set the globl id
		manRw.setIdTask(manRw.getAcq1Id() + "_" + manRw.getAcq2Id());
		logger.debug("try to create a man rw : " + manRw);

		return manRw;
	}

	/**
	 * Try to plan rw man with date.
	 *
	 * @param dateRes      the date res
	 * @param current      the current
	 * @param date         the date
	 * @param timeForRw    the time for rw
	 * @param droolsParams the drools params
	 * @param fromLeft     the from left
	 * @return the maneuver
	 */
	public Maneuver tryToPlanRwManWithDate(DateResource dateRes, Acquisition current, long date, long timeForRw,
			DroolsParameters droolsParams, boolean fromLeft) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the tranquillization time
		double tranqTime = droolsParams.getTranquillizationTime();

		// get the id of the prev acq
		String prevId = "x";

		// get the id of the next acq
		String currentId = "x";

		// set the start time
		long startTimeAsLong = dateRes.getStart().getTime();

		// set the end time
		long endTimeAsLong = startTimeAsLong + (timeForRw * 1000);

		// set the satellite id
		String satelliteId = current.getSatelliteId();

		// create a new maneuver
		Maneuver manRw = new Maneuver();

		// set it as R2L as default
		manRw.setRightToLeftFlag(true);

		// if is not a Left2Right
		if (!fromLeft) {

			// compute the endTime
			endTimeAsLong = (long) (dateRes.getStop().getTime() - (tranqTime * 1000));

			// compute the startTime
			startTimeAsLong = endTimeAsLong - (timeForRw * 1000);
		}

		// if current is before the date given as input
		if (current.getStartTime().before(new Date(date))) {
			prevId = current.getIdTask();
			currentId = "x";
			if (current.getLookSide().equalsIgnoreCase("left")) {
				manRw.setRightToLeftFlag(false);
			} else {
				manRw.setRightToLeftFlag(true);
			}
		}
		// if current is after the date given as input
		else {
			prevId = "x";
			currentId = current.getIdTask();
			if (current.getLookSide().equalsIgnoreCase("left")) {
				manRw.setRightToLeftFlag(true);
			} else {
				manRw.setRightToLeftFlag(false);
			}
		}

		// set the id of the prev acq
		manRw.setAcq1Id(prevId);
		// set the id of the next acq
		manRw.setAcq2Id(currentId);
		// set the startTime
		manRw.setStartTime(new Date(startTimeAsLong));
		// set the endTime
		manRw.setEndTime(new Date(endTimeAsLong));

		// set the satllite id
		manRw.setSatelliteId(satelliteId);

		// set the actuator
		manRw.setActuator(Actuator.ReactionWheels);

		// set the maneuverType
		manRw.setType(ManeuverType.RollSlew);

		// set the idTask
		manRw.setIdTask(manRw.getAcq1Id() + "_" + manRw.getAcq2Id());
		logger.debug("try to create a man rw : " + manRw);
		return manRw;
	}

	/**
	 * Calculate local max maneuver.
	 *
	 * @param localStart         the local start
	 * @param localEnd           the local end
	 * @param allmanRelatedToSat the allman related to sat
	 * @param logger             the logger
	 * @param checkToPerform     the check to perform
	 * @return the array list
	 */
	public int calculateLocalMaxManeuver(long localStart, long localEnd, TreeMap<Long, Maneuver> allmanRelatedToSat,
			Logger logger, Actuator checkToPerform) {
		int maxMan = 0;
		// Logger logger1 = DroolsParameters.getLogger();
		boolean insert = false;
		NavigableMap<Long, Maneuver> subMap = allmanRelatedToSat.subMap(localStart, true, localEnd, true);
		Object previousKey = allmanRelatedToSat.lowerKey(localStart);

		if (previousKey != null) {
			Maneuver possibleBorderlineMan = allmanRelatedToSat.lowerEntry(localStart).getValue();
			insert = this.manUtils.checkBorderlineCaseStart(possibleBorderlineMan, localStart, true);
			if (insert) {
				if (possibleBorderlineMan.getActuator().equals(checkToPerform)
						|| checkToPerform.equals(Actuator.total)) {
					// logger.debug("MANEUVER_RULE_ found man borderline: " +
					// possibleBorderlineMan);
					maxMan = maxMan + 1;
				}
			}
		}

		for (Map.Entry<Long, Maneuver> entry : subMap.entrySet()) {
			Maneuver manExtracted = entry.getValue();
			if (manExtracted.getActuator().equals(checkToPerform) || checkToPerform.equals(Actuator.total)) {
				// logger.debug("MANEUVER_RULE_ found man : " + manExtracted);
				maxMan = maxMan + 1;
			}
		}
		// logger.debug("MANEUVER_RULE_ in interval from : " + new
		// Date(localStart) + " to : " + new Date(localEnd)+ " there are :" +
		// maxMan + " maneuvers");
		return maxMan;
	}

	/**
	 * Check if man is available.
	 *
	 * @param justCreatedMan the just created man
	 * @param currentSession the current session
	 * @param droolsParams   the drools params
	 * @param resourceFunc   the resource func
	 * @param checkToPerform the check to perform
	 * @return true, if successful
	 */

	public boolean checkManeuversBarrels(Maneuver justCreatedMan, String currentSession, DroolsParameters droolsParams,
			ResourceFunctions resourceFunc, Actuator checkToPerform) {
		ReasonOfReject reason = ReasonOfReject.maxNumberOfTotalManeuverReached;
		Acquisition lastAcq = DroolsParameters.getLastAcqForSession().get(currentSession);

		boolean checkOnTotal = checkIfManIsAvailable(justCreatedMan, lastAcq, droolsParams, resourceFunc,
				Actuator.total, reason);
		if (checkOnTotal) {
			if (checkToPerform.equals(Actuator.CMGA)) {
				reason = ReasonOfReject.maxNumberOfCMGAManeuverReached;
			} else {
				reason = ReasonOfReject.maxNumberOfRWManeuverReached;
			}
			checkOnTotal = checkIfManIsAvailable(justCreatedMan, lastAcq, droolsParams, resourceFunc, checkToPerform,
					reason);
		}
		return checkOnTotal;
	}

	/**
	 * Check if man is available.
	 *
	 * @param justCreatedMan the just created man
	 * @param current        the current
	 * @param droolsParams   the drools params
	 * @param resourceFunc   the resource func
	 * @param checkToPerform the check to perform
	 * @param reason         the reason
	 * @return true, if successful
	 */
	// (acq1,allManRelatedTOSat,droolsParams,"CMGA");
	public boolean checkIfManIsAvailable(Maneuver justCreatedMan, Acquisition current, DroolsParameters droolsParams,
			ResourceFunctions resourceFunc, Actuator checkToPerform, ReasonOfReject reason) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		List<String> elementsInvolvedInReject = new ArrayList<>();

		// initialize the boolean variable to true
		boolean possible = true;

		// get the satellite id
		String satId = justCreatedMan.getSatelliteId();

		// get the treemap with all the maneuvers for the current satellite
		TreeMap<Long, Maneuver> allManRelatedToSat = resourceFunc.getManeuverFunctionAssociatedToSat(satId);

		// get the treemap with all the acquisitions for the current satellite
		TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunc.getEssFunctionAssociatedToSat(satId);

		// get the satellite properties related to the current satellite
		SatelliteProperties satProp = droolsParams.getSatWithId(satId).getSatelliteProperties();

		// iterate over the check on orbits defined on the configuration file
		for (Map.Entry<Double, ResourceMaxValue> checkOnSingleOrbit : satProp.getAllChecksOnOrbits().entrySet()) {
			// extract the i-esim orbit
			double orbit = checkOnSingleOrbit.getKey();

			// initialize the max number of maneuvers to zero
			int maxNumMan = 0;
			logger.debug("MANEUVER_RULE_ orbit to check :" + orbit);

			// if the check that must be performed is for cmga maneuvers
			if (checkToPerform.compareTo(Actuator.CMGA) == 0) {
				// get the max number of cmga on the current orbit to check
				maxNumMan = checkOnSingleOrbit.getValue().getMaxManeuversCMGA();
				logger.debug("MANEUVER_RULE_ max number of cmga : " + maxNumMan);
			}
			// if the check that must be performed is for rw maneuvers
			else if (checkToPerform.compareTo(Actuator.ReactionWheels) == 0) {
				// get the max number of rw on the current orbit to check
				maxNumMan = checkOnSingleOrbit.getValue().getMaxManeuversRW();
				logger.debug("MANEUVER_RULE_ max number of rw : " + maxNumMan);
			}
			// if the check that must be performed is for total maneuvers
			else {
				// get the max number of total maneuvers on the current orbit to
				// check
				maxNumMan = checkOnSingleOrbit.getValue().getMaxManeuvers();
				logger.debug("MANEUVER_RULE_ max number of man tot : " + maxNumMan);
			}
			// logger.debug("MANEUVER_RULE_ max number of man :" + maxNumMan + "
			// for checkToPerform : " + checkToPerform);

			// if the max number is -1 this check must be skipped, otherwise
			// must be checked
			if (maxNumMan > -1) {
				int slidingWindCount = 0;
				long slidingWindowToCheck = (long) (orbit * droolsParams.getMinutesForOrbit() * 60000);
				long from = justCreatedMan.getStartTime().getTime();
				long to = justCreatedMan.getStartTime().getTime() + slidingWindowToCheck;
				// logger.debug("MANEUVER_RULE_ sliding windows to check from :"
				// + new Date(from));
				// logger.debug("MANEUVER_RULE_ sliding windows to check to :" +
				// new Date(to));
				int localMax = calculateLocalMaxManeuver(from, to, allManRelatedToSat, logger, checkToPerform);
				if (localMax > maxNumMan) {
					logger.debug("MANEUVER_RULE_ max number reached :");
					List<Maneuver> allManInInterval = this.manUtils.allManInInterval(from, to, allManRelatedToSat);
					elementsInvolvedInReject = this.du.getAllElementsInvolvedWithManInInterval(allManInInterval,
							checkToPerform);
					// System.out.println(DroolsParameters.getLastAcq());
					DroolsParameters.getLastAcq().addReasonOfReject(1, reason, "System Conflict", orbit,
							slidingWindCount, elementsInvolvedInReject);
					possible = false;
				}

				slidingWindCount++;

				Map<Long, Maneuver> subMap = allManRelatedToSat.subMap(from, true, to, true);
				for (Map.Entry<Long, Maneuver> elementOfMap : subMap.entrySet()) {
					Maneuver manExtracted = elementOfMap.getValue();
					logger.debug("MANEUVER_RULE_ man in interval : " + manExtracted);
					long localStart = manExtracted.getEndTime().getTime() - slidingWindowToCheck;
					long localEnd = manExtracted.getEndTime().getTime();
					// logger.debug("MANEUVER_RULE_ sub sliding window start :"
					// + new Date(localStart));

					localMax = calculateLocalMaxManeuver(localStart, localEnd, allManRelatedToSat, logger,
							checkToPerform);
					if (localMax > maxNumMan) {
						logger.debug("MANEUVER_RULE_ reached max numer of man:" + checkToPerform);
						elementsInvolvedInReject.addAll(this.du.getAllElementsInvolved(localStart, localEnd, allAcq));

						if (reason.equals(ReasonOfReject.maxNumberOfRWManeuverReached)) {
							DroolsParameters.getLastAcq().addReasonOfReject(1, reason, "System Conflict", orbit,
									slidingWindCount, elementsInvolvedInReject);
						} else if (reason.equals(ReasonOfReject.maxNumberOfCMGAManeuverReached)) {
							DroolsParameters.getLastAcq().addReasonOfReject(1, reason, "System Conflict", orbit,
									slidingWindCount, elementsInvolvedInReject);
						} else {
							DroolsParameters.getLastAcq().addReasonOfReject(1, reason, "System Conflict", orbit,
									slidingWindCount, elementsInvolvedInReject);
						}
						possible = false;
					}
					slidingWindCount++;
				}
			} else {
				logger.debug("SKIPPED for current check");
			}
		}
		return possible;
	}

}
