
package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class TheatreManagement.
 */
public class TheatreManagement {

	/**
	 * Convert element inside theatre in acq.
	 *
	 * @param equivDto the equiv dto
	 * @return the list
	 */
	public List<Acquisition> convertElementInsideTheatreInAcq(EquivalentDTO equivDto) {

		// create an empty list of acquisitions
		List<Acquisition> allAcqInsideTheatre = new ArrayList<>();
		DroolsUtils du = new DroolsUtils();

		// iterate over the elements inside the equivalent dto
		for (int i = 0; i < equivDto.getAllDtoInEquivalentDto().size(); i++) {
			// logger.debug("THEATRE OPERATION : checking on element : " +
			// equivDto.getAllDtoInEquivalentDto().get(i));

			// extract the i-esim element
			DTO currentElement = equivDto.getAllDtoInEquivalentDto().get(i);

			// create the relative acq
			Acquisition relatedAcq = du.fromDtoToAcq(currentElement);

			// add the just created acquisition to the list of performed acq
			allAcqInsideTheatre.add(relatedAcq);
		}
		return allAcqInsideTheatre;
	}

	/**
	 * Check if theatre is consistent for max duration.
	 *
	 * @param allacq                the allacq
	 * @param maxdurationSensorMode the maxduration sensor mode
	 * @return true, if successful
	 */
	public boolean checkIfTheatreIsConsistentForMaxDuration(List<Acquisition> allacq,
			Map<TypeOfAcquisition, Double> maxdurationSensorMode) {

		// initialize the consistent to true
		boolean isConsistent = true;

		// get the number of acq
		int numbOfAcq = allacq.size();

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// iterate over all the acq
		for (int i = 0; i < allacq.size(); i++) {

			// extract the max duration of sensor mode from the map
			long maxDurationAllowed = (long) (maxdurationSensorMode.get(allacq.get(i).getSensorMode()) * 1000);

			// if the duration of dto exceeds the max duration of sensor
			// mode
			if ((allacq.get(i).getEndTime().getTime() - allacq.get(i).getStartTime().getTime()) > maxDurationAllowed) {
				// add the new reason of reject to the acquisition
				allacq.get(i).addReasonOfReject(4, ReasonOfReject.exceededSensorModeMaxDuration,
						"Maximum Sensor Mode Duration Reached", 0, 0, null);

				// decrement the number of acq
				numbOfAcq--;
			} else {
				logger.debug("THEATRE OPERATION : duration is valid.");
			}
		}

		// if there was at least a decrement
		if (numbOfAcq < allacq.size()) {

			// mark as inconsistent
			isConsistent = false;
		}
		return isConsistent;
	}

	/**
	 * Check if theatre is consistent for overlap.
	 *
	 * @param allacq the allacq
	 * @return true, if successful
	 */
	public boolean checkIfTheatreIsConsistentForOverlap(List<Acquisition> allacq) {
		Logger logger = DroolsParameters.getLogger();

		// initialize consistent to true
		boolean isConsistent = true;

		// count the number of acquisitions
		int countAcqElements = allacq.size();

		// iterate over the acquisitions
		for (int i = 0; i < allacq.size(); i++) {

			// extract the i-esim acq
			Acquisition currentElement = allacq.get(i);

			// is is consistent
			if (isConsistent) {

				// iterate over all the acq inside the theatre

				for (int j = 0; j < allacq.size(); j++) {
					// extract the i-esim acq
					Acquisition elementToMatch = allacq.get(j);

					// if the current element is different from the external one
					if (!elementToMatch.getIdTask().equals(currentElement.getIdTask())) {

						// if there is overlap between different elements inside
						// the equivalent dto
						if ((elementToMatch.getStartTime().getTime() <= currentElement.getEndTime().getTime())
								&& (elementToMatch.getEndTime().getTime() >= currentElement.getStartTime().getTime())) {
							logger.info("THEATRE OPERATION : elementToMatch " + elementToMatch);
							logger.info("THEATRE OPERATION : currentElement " + currentElement);

							// overlap
							countAcqElements--;
							// logger.debug("THEATRE OPERATION : overlap between
							// internal elements of theatre");

							// set the dto under test as rejected
							currentElement.setRejected(true);
							currentElement.addReasonOfReject(7, ReasonOfReject.acqOverlapWithAcquisition,
									"Acquisition Overlap With Another Acquisition", 0, 0,
									new ArrayList<>(Arrays.asList(elementToMatch.getIdTask())));

							rejectAllDtoInEquivalent(allacq, 20, ReasonOfReject.theatreInternallyInconsistent,
									"Inconsistent Theatre");
							countAcqElements = 0;
							break;
						}
					}
					// if at least an element is inconsistent
					if (countAcqElements < allacq.size()) {

						// mark as unconsistent
						isConsistent = false;
						logger.info("THEATRE OPERATION : overlap between internal elements of theatre");
						break;
					}
				}
			}
		}
		if (isConsistent) {
			logger.info("THEATRE OPERATION : no overlap detected between internal elements of theatre");
		}
		return isConsistent;
	}

	/**
	 * Reject all dto in equivalent.
	 *
	 * @param allAcqInTheatre the all acq in theatre
	 * @param id              the id
	 * @param reason          the reason
	 * @param descr           the descr
	 */
	public void rejectAllDtoInEquivalent(List<Acquisition> allAcqInTheatre, int id, ReasonOfReject reason,
			String descr) {

		// iterate over the dto into the equivalent dxto
		for (int i = 0; i < allAcqInTheatre.size(); i++) {
			// mark the i-esim dto as rejected
			allAcqInTheatre.get(i).setRejected(true);

			// add to the i-esim dto the reason of reject given in input
			allAcqInTheatre.get(i).addReasonOfReject(id, reason, descr, 0, 0, null);

		}
	}

	/**
	 * Sort theatre dto.
	 *
	 * @param allDtoInEquivalentDto the all dto in equivalent dto
	 * @return the tree map
	 */
	public static TreeMap<Long, DTO> sortTheatreDto(List<DTO> allDtoInEquivalentDto) {
		// create an empty treemp for sorted elements
		TreeMap<Long, DTO> sortedElements = new TreeMap<>();
		Collections.sort(allDtoInEquivalentDto, new Comparator<DTO>() {

			@Override
			/*
			 * given two tasks sort them by start time
			 * 
			 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
			 */
			public int compare(DTO dto1, DTO dto2) {
				// compare and sort them by startTime
				return dto1.getStartTime().compareTo(dto2.getStartTime());
			}
		});

		// iterate over all the elements inside equiv dto
		for (int i = 0; i < allDtoInEquivalentDto.size(); i++) {
			// add to the treemap
			sortedElements.put(allDtoInEquivalentDto.get(i).getStartTime().getTime(), allDtoInEquivalentDto.get(i));
		}

		return sortedElements;
	}

}
