/**
*
restore
* MODULE FILE NAME:	bicManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		18 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import org.slf4j.Logger;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class BicManagement.
 *
 * @author fpedrola
 */
public class BicManagement {

	/** The bic utils. */
	private BicUtils bicUtils = new BicUtils();

	/**
	 * Check bic and neo bic for acq.
	 *
	 * @param droolsParams the drools params
	 * @param acq          the acq
	 * @param equivDto     the equiv dto
	 * @param allAcq       the all acq
	 * @param manTreemap   the man treemap
	 * @return the list
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public List<Partner> checkBicAndNeoBicForAcq(DroolsParameters droolsParams, Acquisition acq, EquivalentDTO equivDto,
			TreeMap<Long, EnergyAssociatedToTask> allAcq, TreeMap<Long, Maneuver> manTreemap) throws Exception {
		// create the default reason of reject
		ReasonOfReject reason = ReasonOfReject.neoBicNotAvailable;

		// variable to check if the acquisition is involved in a theatre
		boolean isTheatre = false;

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get all partners
		List<Partner> listOfPartner = droolsParams.getAllPartners();

		// create a clone of the original list of partners
		List<Partner> localListOfPartner = (List<Partner>) DroolsUtils.deepClone(listOfPartner);

		// as default set the dtoInEquivalentDto = 1, if
		// it is involved in a theatre this number is updated
		int numberOfDtoInEquivDto = 1;

		// if there is an involved equivalent Dto
		if (equivDto != null) {
			// if the type of the equivalent is theatre
			if (equivDto.getEquivType().equals(PRMode.Theatre)) {
				isTheatre = true;
				// update the numberOfDtoInEquivDto variable with
				// the effective number of dto inside the theatre
				numberOfDtoInEquivDto = equivDto.getAllDtoInEquivalentDto().size();
				logger.info(
						"DECREMENT_BIC_RULE_ perform theatre, number of dto inside theatre : " + numberOfDtoInEquivDto);
			}
		}

		// create a variable to check the
		// partners associated to acq that not have enough bic
		List<Partner> allPartnersWithInvalidBic = new ArrayList<>();
		boolean possible = true;

		// if there aren't partners associated with acq
		if (acq.getUserInfo().size() == 0) {
			possible = false;
		}
		// iterate over the partners associated
		while (acq.getUserInfo().size() > 0) {
			// get the number of partners linked to the acq
			int numberOfPartners = acq.getUserInfo().size();

			// compute the bic for each partner
			double bicForEachPartner = acq.getImageBIC() / numberOfPartners;

			// as default, check if partners have the
			// total left extra bic, so
			// in case of reject of the current
			// acquisition (if it is a train of
			// acquisitions) the other acquisitions
			// will not paid more than the
			// max left extra bic
			if (acq.getLookSide().equalsIgnoreCase("left")) {
				logger.info("DECREMENT_BIC_RULE_ is a left acquisition , with extra cost left : "
						+ droolsParams.getExtraCostLeft() + " to imageBic of acq : " + acq.getImageBIC());

				// add the extra cost left
				bicForEachPartner = (acq.getImageBIC()) / numberOfPartners;
			}
			// if the acq is a theatre
			if (isTheatre) {
				// add the extra cost theatre
				bicForEachPartner = bicForEachPartner
						- (((numberOfDtoInEquivDto - 1) * (equivDto.getExtraCostPitch())) / numberOfDtoInEquivDto);
				logger.info("DECREMENT_BIC_RULE_ perform theatre, with extra cost theatre : " + bicForEachPartner);
			}

			// logger.info("bic for each partner : " + bicForEachPartner);

			try {
				firstCheckOnBic(acq, allPartnersWithInvalidBic, logger, localListOfPartner, bicForEachPartner);
			} catch (Exception e) {
				e.printStackTrace();
			}

			// if there aren't others partners
			if (acq.getUserInfo().size() > 0) {
				// set the reason of reject with bicNotAvailable
				reason = ReasonOfReject.bicNotAvailable;
			}

			secondCheckOnBic(acq, allPartnersWithInvalidBic, logger, localListOfPartner, bicForEachPartner);

			// if at least a partner has invalid bic/neo bic , the amount of bic
			// has to be recomputed.
			if (acq.getUserInfo().size() < numberOfPartners) {
				// if there are others partners associated
				if (acq.getUserInfo().size() > 0) {
					// logger.info("DECREMENT_BIC_RULE_ restore original list
					// of partner without debts or loan performed in the
					// previous invalid session");

					// make a deep clone of the list of partners
					localListOfPartner = (List<Partner>) DroolsUtils.deepClone(listOfPartner);

					// compute the bic that are requested for each partner
					bicForEachPartner = acq.getImageBIC() / acq.getUserInfo().size();
				}
				// the acquisition has no partners associated
				else {
					// set possible = false , acq will be rejected
					possible = false;
				}
			} else {
				// set possible = true and exit from the cycle
				possible = true;
				break;
			}
		}
		if (possible) {
			// the pre check is valid, now invoke the method for really
			// decrement the bic for all the valid partners
			decrementBicAndNeoBic(acq, droolsParams, equivDto, isTheatre, allAcq, manTreemap, false, true);
		} else {
			// something wrong, clear all the user info for this acq
			acq.getUserInfo().clear();

			// invoke the method to find the acq related to the rejected
			// partners
			List<String> otherAcqOfPartners = findAllAcqRelatedToRejectedPartners(allPartnersWithInvalidBic, allAcq);

			// add the reason NoBic/noNeoBic to the reason of reject linked to
			// the acquisition

			acq.addReasonOfReject(1, reason, "System Conflict", 0, 0, otherAcqOfPartners);

			// set the acquisition as rejected
			acq.setRejected(true);
		}
		return allPartnersWithInvalidBic;
	}

	/**
	 * Seconf filter on bic.
	 *
	 * @param acq                       the acq
	 * @param allPartnersWithInvalidBic the all partners with invalid bic
	 * @param logger                    the logger
	 * @param localListOfPartner        the local list of partner
	 * @param bicForEachPartner         the bic for each partner
	 */
	private void secondCheckOnBic(Acquisition acq, List<Partner> allPartnersWithInvalidBic, Logger logger,
			List<Partner> localListOfPartner, double bicForEachPartner) {
		// second filter for bic
		for (int i = 0; i < acq.getUserInfo().size(); i++) {
			// get the partner id related to the userInfo object
			String partnerId = acq.getUserInfo().get(i).getOwnerId();

			// get the relative partner
			Partner partner = this.bicUtils.findPartnerInList(partnerId, localListOfPartner);

			// if the partner has not enough bic to perform the acq
			if ((partner.getUsedBIC() + bicForEachPartner) > partner.getMaxBICAvailable()) {
				// get the residual own bic that he can use
				double ownBicUsedForCurrentAcq = partner.getMaxBICAvailable() - partner.getUsedBIC();

				// initialize the loan
				double loan = 0;

				// if it hasn't residual bic to use
				if (ownBicUsedForCurrentAcq < 0) {
					// set it to zero
					ownBicUsedForCurrentAcq = 0;

					// request as loan the total amount of bic relative
					// to the acq
					loan = bicForEachPartner;
				}
				// if it has reasidual bic
				else {
					// get as loan the rest of bic
					loan = bicForEachPartner - ownBicUsedForCurrentAcq;
				}

				// invoke the function to choose a partner for loan
				Map<Partner, Double> partnersChoosenForLoan = getPartnerForLoan(logger, loan, partner,
						localListOfPartner);
				if (partnersChoosenForLoan.isEmpty()) {
					acq.getUserInfo().remove(i);
					// logger.info("DECREMENT_BIC_RULE_ remove partner
					// " + partner.getPartnerId() + " because : no
					// partners available for loan");

					// add the partner to the list of invslid elements
					allPartnersWithInvalidBic.add(partner);

					// decrement the index
					i--;
				}
			}
		}
	}

	/**
	 * First check on bic.
	 *
	 * @param acq                       the acq
	 * @param allPartnersWithInvalidBic the all partners with invalid bic
	 * @param logger                    the logger
	 * @param localListOfPartner        the local list of partner
	 * @param bicForEachPartner         the bic for each partner
	 * @throws Exception the exception
	 */
	private void firstCheckOnBic(Acquisition acq, List<Partner> allPartnersWithInvalidBic, Logger logger,
			List<Partner> localListOfPartner, double bicForEachPartner) throws Exception {

		// first filter for neo bic
		for (int i = 0; i < acq.getUserInfo().size(); i++) {
			// extract the partner id
			String partnerId = acq.getUserInfo().get(i).getOwnerId();
			Partner partner;

			// find partner associated with this id
			partner = this.bicUtils.findPartnerInList(partnerId, localListOfPartner);

			// if the acquisition is a neo
			if (acq.isNeo()) {
				logger.info("DECREMENT_BIC_RULE_ partner used neo bic :" + partner.getUsedNeoBic());
				logger.info("DECREMENT_BIC_RULE_ bic for img for partner : " + bicForEachPartner);
				logger.info("DECREMENT_BIC_RULE_ max neo bic : " + partner.getMaxNEOBicAvailable());

				// if the partner hasn't enough bic
				if ((partner.getUsedNeoBic() + bicForEachPartner) > partner.getMaxNEOBicAvailable()) {
					// remove it from the user info
					acq.getUserInfo().remove(i);
					logger.info(
							"DECREMENT_BIC_RULE_ remove partner " + partner.getPartnerId() + " because : no neo bic ");

					// add it to the list of invalid partners
					allPartnersWithInvalidBic.add(partner);
					i--;

					// exit from cycle
					break;
				}
			}
		}
	}

	/**
	 * Find all acq related to rejected partners.
	 *
	 * @param allPartnersWithInvalidBic the all partners with invalid bic
	 * @param allAcq                    the all acq
	 * @return the list
	 */
	public List<String> findAllAcqRelatedToRejectedPartners(List<Partner> allPartnersWithInvalidBic,
			TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		// create an empty list that will contains all the acquisitions'id of
		// the partners that haven't a valid number of bic
		List<String> onlyAcqRelatedToInvalidDto = new ArrayList<>();

		// iterate over all the acquisitions
		for (Map.Entry<Long, EnergyAssociatedToTask> elements : allAcq.entrySet()) {
			// extract i-esim acq
			Acquisition acq = (Acquisition) elements.getValue().getTask();

			// initialize the variable that detect if a partner related to the
			// current acq under analysis is found
			boolean foundPartners = false;

			// iterate over the list of partners that haven't bic
			for (int i = 0; i < allPartnersWithInvalidBic.size(); i++) {
				// iterare over the user info linked to the current acq
				for (int j = 0; j < acq.getUserInfo().size(); j++) {
					// if the user info list contain the id of the i.esim
					// partner
					if (acq.getUserInfo().get(j).getOwnerId()
							.equalsIgnoreCase(allPartnersWithInvalidBic.get(i).getPartnerId())) {
						// set the variable to true
						foundPartners = true;
						break;
					}
				}
			}

			// if at least a partner with invalid bic is associated with acq
			if (foundPartners) {
				// add the acq to the list of acquisitions returned by the
				// method
				onlyAcqRelatedToInvalidDto.add(acq.getId());
			}
		}
		return onlyAcqRelatedToInvalidDto;
	}

	/**
	 * Check bic and neo bic for acq di 2 s.
	 *
	 * @param droolsParams        the drools params
	 * @param dto                 the dto
	 * @param partner             the partner
	 * @param bicForImgForPartner the bic for img for partner
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public boolean checkBicAndNeoBicForAcqDi2s(DroolsParameters droolsParams, DTO dto, Partner partner,
			double bicForImgForPartner) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create a deep clone with all the informations about partners (to not
		// impact the original list)
		List<Partner> localListOfPartner = (List<Partner>) DroolsUtils.deepClone(droolsParams.getAllPartners());

		// set that is possible to decrement bic, as default
		boolean possible = true;

		// if the dto is of type neo
		if (dto.isNeoAvailable()) {
			logger.info("DECREMENT_BIC_RULE_DI2S bic for img for partner : " + bicForImgForPartner);

			// if the partner has not enought neo bic
			if ((partner.getUsedNeoBic() + bicForImgForPartner) > partner.getMaxNEOBicAvailable()) {
				// set that is impossible to perform the acq
				possible = false;
			}
		}

		// if is possible
		if (possible) {
			// if the partner is correctly loaded
			if (partner != null) {
				// if the partner needs a loan to perform the acq
				if ((partner.getUsedBIC() + bicForImgForPartner) > partner.getMaxBICAvailable()) {
					// get the residual available bic for partner
					double ownBicUsedForCurrentAcq = partner.getMaxBICAvailable() - partner.getUsedBIC();

					// initialize the loan
					double loan = 0;

					// if residual is zero or less
					if (ownBicUsedForCurrentAcq <= 0) {
						// set it to zero
						ownBicUsedForCurrentAcq = 0;

						// all the amount of bic will be as loan
						loan = bicForImgForPartner;
					}
					// partners has residual bic
					else {
						// compute the loan as difference between imageBic and
						// residual
						loan = bicForImgForPartner - ownBicUsedForCurrentAcq;
					}

					// get all the possible partners to satisfy the loan
					Map<Partner, Double> partnersChoosenForLoan = getPartnerForLoan(logger, loan, partner,
							localListOfPartner);

					// if the returned map is empty
					if (partnersChoosenForLoan.isEmpty()) {
						// mark the request as impossible to perform
						possible = false;
					}
				}
			} else {
				logger.error("DECREMENT_BIC_RULE_DI2S Error : cannot found a partner with this id");
			}
		}
		return possible;
	}

	/**
	 * this method is used for decrement the bic (and neo bic if the acquisition is
	 * neo) to the master and the slave of a di2s acquisition.
	 *
	 * @param acq          the acq
	 * @param droolsParams the drools params
	 * @param allAcq       the all acq
	 * @param manTreemap   the man treemap
	 * @param equivDto     the equiv dto
	 * @throws Exception the exception
	 */
	public void decrementBicDi2s(Acquisition acq, DroolsParameters droolsParams,
			TreeMap<Long, EnergyAssociatedToTask> allAcq, TreeMap<Long, Maneuver> manTreemap, EquivalentDTO equivDto)
			throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create a new map for the acquisitions
		HashMap<String, Acquisition> allAcqInInterval = new HashMap<>();

		logger.info("028_DECREMENT_BIC_DI2S_ for acq : " + acq);

		// create an hashMap where will be stored the potential partner that can
		// give a loan to the partner under analysis
		Map<Partner, Double> partnersChoosenForLoan = new HashMap<>();

		// extract the slave id from the di2sInfo linked to the acquisition
		String slaveId = acq.getDi2sInfo().getPartnerId();

		// get all the partners
		List<Partner> allPartners = droolsParams.getAllPartners();

		Partner master = this.bicUtils.findPartnerInList(acq.getUserInfo().get(0).getOwnerId(), allPartners);

		logger.info("028_DECREMENT_BIC_DI2S_ partner master " + master);

		Partner slave = this.bicUtils.findPartnerInList(slaveId, allPartners);
		logger.info("028_DECREMENT_BIC_DI2S_ partner slave " + slave);

		// get the amount of bic that are requested to master and slave to
		// processing the di2s image

		double percentBicMaster = droolsParams.getPercentBicDi2sMasterMSOR();
		double percentBicSlave = droolsParams.getPercentBicDi2sSlaveMSOR();

		// if the acq is a SPOTLIGHT_2_MSOS
		if (acq.getSensorMode().equals(TypeOfAcquisition.SPOTLIGHT_2_MSOS)) {
			// extract the master's percentage of bic
			percentBicMaster = droolsParams.getPercentBicDi2sMasterMSOS();

			// extract the slave's percentage of bic
			percentBicSlave = droolsParams.getPercentBicDi2sSlaveMSOS();
		}

		// compute the image bic
		// for master and slave
		double imageBicMaster = (acq.getImageBIC() / 100) * percentBicMaster;
		double imageBicSlave = (acq.getImageBIC() / 100) * percentBicSlave;
		double extraCostLeft = droolsParams.getExtraCostLeft();

		// if the acq is in left asset
		if (acq.getLookSide().equalsIgnoreCase("left")) {

			NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = new TreeMap<>();

			// logger.info("print all maneuvers : " + manTreemap);
			LeftAttitudeProfileManagement leftMng = new LeftAttitudeProfileManagement();

			// detect the left period where the acq is included
			DateResource startAndStopLeftPeriod = leftMng.detectActualLeftPeriod(logger, acq, manTreemap,
					droolsParams.getCurrentMH(), 0);

			// get the submap with all the acquisition that are inside the left
			// period
			allAcqIdInInternal = allAcq.subMap(startAndStopLeftPeriod.getStart().getTime(), true,
					startAndStopLeftPeriod.getStop().getTime(), true);

			// iterate over the submap
			for (Map.Entry<Long, EnergyAssociatedToTask> elements : allAcqIdInInternal.entrySet()) {
				// extract the i.esim acq
				Acquisition currentAcq = (Acquisition) elements.getValue().getTask();

				// add to the map of acq
				allAcqInInterval.put(currentAcq.getIdTask(), currentAcq);
			}

			extraCostLeft = (droolsParams.getExtraCostLeft() / allAcqInInterval.size());
			System.out.println(extraCostLeft);
			// add the extra cost left
			imageBicMaster = (((acq.getImageBIC() - droolsParams.getExtraCostLeft()) + extraCostLeft) / 100)
					* percentBicMaster;
			imageBicSlave = (((acq.getImageBIC() - droolsParams.getExtraCostLeft()) + extraCostLeft) / 100)
					* percentBicSlave;

		}

		/*
		 * create a list of partner for master and slave
		 */
		List<Partner> masterAndSlave = new ArrayList<>(Arrays.asList(master, slave));

		// iterate over the partners associated to the di2s
		for (int i = 0; i < masterAndSlave.size(); i++) {
			// extract the partner
			Partner partner = masterAndSlave.get(i);
			double imageBic = imageBicMaster;

			/*
			 * if the partner is the slave
			 */
			if (i > 0) {
				/*
				 * get the image bic inherent the slave
				 */
				imageBic = imageBicSlave;
			}
			double loan = 0;

			/*
			 * if the partner doesn't have enough bic, he need a loan
			 */
			if ((partner.getUsedBIC() + imageBic) > partner.getMaxBICAvailable()) {
				// logger.info("DECREMENT_BIC_RULE_DI2S Partner need a loan to
				// process the acq ");
				/*
				 * get the residual amount of bic that the partner can use to perform this
				 * acquisition
				 */
				double ownBicUsedForCurrentAcq = partner.getMaxBICAvailable() - partner.getUsedBIC();

				/**
				 * if there aren't residual bic, the loan will be for the total amount of the
				 * bic relative to the image
				 */
				if (ownBicUsedForCurrentAcq < 0) {
					/*
					 * partner's bic are zero
					 */
					ownBicUsedForCurrentAcq = 0;
					// logger.info("DECREMENT_BIC_RULE_DI2S own bic used for
					// acq : " + ownBicUsedForCurrentAcq);
					/*
					 * loan is the total amount of bic related to the image
					 */
					loan = imageBic;
				}
				/*
				 * the partner can use part of his bic to perform the acquisition
				 */
				else {
					// logger.info("DECREMENT_BIC_RULE_DI2S own bic used for
					// acq : " + ownBicUsedForCurrentAcq);
					/*
					 * the loan is the bic related to the image - the residual bic of the partner
					 */
					loan = imageBic - ownBicUsedForCurrentAcq;
				}

				partnersChoosenForLoan = getPartnerForLoan(logger, loan, partner, allPartners);
				/*
				 * decrement the bic and memorize the loan
				 */
				decrement_BIC_Associated_To_Partners(logger, acq, loan, partner, partnersChoosenForLoan);
			}

			/*
			 * update the used bic for partner
			 */
			double usedBIC = partner.getUsedBIC() + (imageBic - loan);
			logger.info("DECREMENT_BIC_RULE_ updated used bic :" + usedBIC);

			// set the used bic with the new value just computed
			partner.setUsedBIC(usedBIC);

			// add the acq to the list of acq performed by the partner if it
			// isn't included yet
			if (!partner.getAcqPerformed().contains(acq.getId())) {
				partner.getAcqPerformed().add(acq.getId());
			}

			// if the acquisition is neo
			if (acq.isNeo()) {
				// set the used neo bic taking in account the image bic
				partner.setUsedNeoBic(partner.getUsedNeoBic() + imageBic);

				logger.info("DECREMENT_BIC_RULE_ updated used neo bic :" + partner.getUsedNeoBic());
			}
		}
		// if the acquisition is a left
		if (acq.getLookSide().equalsIgnoreCase("left")) {

			acq.setExtraLeft(extraCostLeft);
			allAcqInInterval.remove(acq.getIdTask());

			if (allAcqInInterval.size() > 0) {
				logger.info("DECREMENT_BIC_RULE_ update bic left for others acq involved in train left :"
						+ allAcqInInterval);
				for (Map.Entry<String, Acquisition> leftInTrain : allAcqInInterval.entrySet()) {
					Acquisition currentAcq = leftInTrain.getValue();
					logger.info("DECREMENT_BIC_RULE_ other acq id :" + currentAcq.getIdTask() + " and extra left was :"
							+ currentAcq.getExtraLeft());
					double bicToRestore = currentAcq.getExtraLeft() - (currentAcq.getExtraLeft() - extraCostLeft);

					currentAcq.setImageBIC(currentAcq.getImageBIC() - (currentAcq.getExtraLeft() - extraCostLeft));

					logger.info("updated used bic : " + currentAcq.getImageBIC());
					currentAcq.setExtraLeft(extraCostLeft);

					logger.info("updated extra left bic : " + currentAcq.getExtraLeft());

					restoreBicAndLoanToPartner(currentAcq, droolsParams, true, equivDto, true, bicToRestore);
				}
			}
		}
	}

	/**
	 * Decrement bic and neo bic.
	 *
	 * @param acq           the acq
	 * @param droolsParams  the drools params
	 * @param equivDto      the equiv dto
	 * @param isTheatre     the is theatre
	 * @param allAcq        the all acq
	 * @param manTreemap    the man treemap
	 * @param decrementOnly the decrement only
	 * @param firstInsert   the first insert
	 * @throws Exception the exception
	 */
	public void decrementBicAndNeoBic(Acquisition acq, DroolsParameters droolsParams, EquivalentDTO equivDto,
			boolean isTheatre, TreeMap<Long, EnergyAssociatedToTask> allAcq, TreeMap<Long, Maneuver> manTreemap,
			boolean decrementOnly, boolean firstInsert) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		logger.info("DECREMENT_BIC_RULE_ image bic ( + extra left cost if the acq is in left looking ) : "
				+ acq.getImageBIC());

		// create a new map for the acquisitions
		HashMap<String, Acquisition> allAcqInInterval = new HashMap<>();

		// get the image bic of the current acq
		double updatedImageBic = acq.getImageBIC();

		// split the cost between the partners associated with the acq
		double imageBicForEachPartner = acq.getImageBIC() / acq.getUserInfo().size();

		// initialize the cont for the train of left acq (if there are)
		double extraCostLeftSplittedForTrainLeft = 0;

		NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = new TreeMap<>();

		// if the current acq is left
		if (acq.getLookSide().equalsIgnoreCase("left")) {
			// logger.info("print all maneuvers : " + manTreemap);
			LeftAttitudeProfileManagement leftMng = new LeftAttitudeProfileManagement();

			// detect the left period where the acq is included
			DateResource startAndStopLeftPeriod = leftMng.detectActualLeftPeriod(logger, acq, manTreemap,
					droolsParams.getCurrentMH(), 0);

			// get the submap with all the acquisition that are inside the left
			// period
			allAcqIdInInternal = allAcq.subMap(startAndStopLeftPeriod.getStart().getTime(), true,
					startAndStopLeftPeriod.getStop().getTime(), true);

			// iterate over the submap
			for (Map.Entry<Long, EnergyAssociatedToTask> elements : allAcqIdInInternal.entrySet()) {
				// extract the i.esim acq
				Acquisition currentAcq = (Acquisition) elements.getValue().getTask();

				if (currentAcq.getLookSide().equalsIgnoreCase("left")) {
					// add to the map of acq
					allAcqInInterval.put(currentAcq.getIdTask(), currentAcq);
				}
			}

		}

		// if this method is invoked only for the decrement
		if (decrementOnly == false) {
			// if the acquisition is a left
			if (acq.getLookSide().equalsIgnoreCase("left")) {
				// the extra cost must be computed and splitted
				extraCostLeftSplittedForTrainLeft = droolsParams.getExtraCostLeft() / allAcqIdInInternal.size();

				acq.setExtraLeft(extraCostLeftSplittedForTrainLeft);
				updatedImageBic = (acq.getImageBIC() - droolsParams.getExtraCostLeft()) + acq.getExtraLeft();
				allAcqInInterval.remove(acq.getIdTask());
				acq.setImageBIC(updatedImageBic);

				if (firstInsert) {
					if (allAcqInInterval.size() > 0) {
						logger.info("DECREMENT_BIC_RULE_ update bic left for others acq involved in train left :"
								+ allAcqInInterval);
						for (Map.Entry<String, Acquisition> leftInTrain : allAcqInInterval.entrySet()) {
							Acquisition currentAcq = leftInTrain.getValue();

							currentAcq.setImageBIC(currentAcq.getImageBIC()
									- (currentAcq.getExtraLeft() - extraCostLeftSplittedForTrainLeft));

							logger.info("updated used bic : " + currentAcq.getImageBIC());

							currentAcq.setExtraLeft(extraCostLeftSplittedForTrainLeft);

							logger.info("updated extra left bic : " + currentAcq.getExtraLeft());

							restoreBicAndLoanToPartner(currentAcq, droolsParams, true, equivDto, true,
									extraCostLeftSplittedForTrainLeft);
						}
					}
				}
			}

			if (isTheatre) {
				int numberOfDtoInEquivalentDto = equivDto.getAllDtoInEquivalentDto().size();
				double singleExtraCostTheatre = equivDto.getExtraCostPitch() / numberOfDtoInEquivalentDto;

				logger.info("part of theatre that must be added to the current acq "
						+ (equivDto.getExtraCostPitch() / numberOfDtoInEquivalentDto / acq.getUserInfo().size()));

				updatedImageBic = (acq.getImageBIC() - equivDto.getExtraCostPitch()) + singleExtraCostTheatre;
				acq.setImageBIC(updatedImageBic);
			}
		}

		imageBicForEachPartner = acq.getImageBIC() / acq.getUserInfo().size();

		logger.info("DECREMENT_BIC_RULE_ check bic for partner :valid partners are : " + acq.getUserInfo());

		logger.info("DECREMENT_BIC_RULE_ image bic splitted between partners : " + imageBicForEachPartner);

		for (int i = 0; i < acq.getUserInfo().size(); i++) {
			String currentPartnerId = acq.getUserInfo().get(i).getOwnerId();
			Partner currentPartner = null;
			currentPartner = this.bicUtils.findPartnerInList(currentPartnerId, droolsParams.getAllPartners());

			logger.info("DECREMENT_BIC_RULE_ check bic for partner : " + currentPartner.getPartnerId());

			double loan = 0;
			if ((currentPartner.getUsedBIC() + imageBicForEachPartner) > currentPartner.getMaxBICAvailable()) {
				logger.info("DECREMENT_BIC_RULE_ Partner need a loan to process the acq ");
				double ownBicUsedForCurrentAcq = currentPartner.getMaxBICAvailable() - currentPartner.getUsedBIC();

				if (ownBicUsedForCurrentAcq < 0) {
					ownBicUsedForCurrentAcq = 0;
					logger.info("DECREMENT_BIC_RULE_ own bic used for acq : " + ownBicUsedForCurrentAcq);
					loan = imageBicForEachPartner;
				} else {
					logger.info("DECREMENT_BIC_RULE_ own bic used for acq :" + ownBicUsedForCurrentAcq);
					loan = imageBicForEachPartner - ownBicUsedForCurrentAcq;
				}

				Map<Partner, Double> PartnersChoosenForLoan = getPartnerForLoan(logger, loan, currentPartner,
						droolsParams.getAllPartners());

				decrement_BIC_Associated_To_Partners(logger, acq, loan, currentPartner, PartnersChoosenForLoan);
			}

			double usedBIC = currentPartner.getUsedBIC() + (imageBicForEachPartner - loan);

			logger.info("DECREMENT_BIC_RULE_ updated used bic :" + usedBIC + " for partner "
					+ currentPartner.getPartnerId());
			currentPartner.setUsedBIC(usedBIC);

			if (!currentPartner.getAcqPerformed().contains(acq.getId())) {
				currentPartner.getAcqPerformed().add(acq.getId());
			}

			if (acq.isNeo()) {
				currentPartner.setUsedNeoBic(currentPartner.getUsedNeoBic() + imageBicForEachPartner);
				logger.info("DECREMENT_BIC_RULE_ updated used neo bic :" + currentPartner.getUsedNeoBic());
			}

			if (currentPartner.getUsedBIC() < 0) {
				currentPartner.setUsedBIC(0);
			}
		}

	}

	/**
	 * Update bic for other acq in train left.
	 *
	 * @param acq          the acq
	 * @param resFunc      the res func
	 * @param droolsParams the drools params
	 * @param removeAcq    the remove acq
	 * @throws Exception the exception
	 */
	public void updateBicForOtherAcqInTrainLeft(Acquisition acq, ResourceFunctions resFunc,
			DroolsParameters droolsParams, boolean removeAcq) throws Exception {
		Logger logger = DroolsParameters.getLogger();
		LeftAttitudeProfileManagement leftMng = new LeftAttitudeProfileManagement();

		// get all the acquisitions
		TreeMap<Long, EnergyAssociatedToTask> allAcq = resFunc.getEssFunctionAssociatedToSat(acq.getSatelliteId());

		// get all the maneuvers
		TreeMap<Long, Maneuver> manTreemap = resFunc.getManeuverFunctionAssociatedToSat(acq.getSatelliteId());

		// get the interval of left period where is stored the acq
		DateResource startAndStopLeftPeriod = leftMng.detectActualLeftPeriod(logger, acq, manTreemap,
				droolsParams.getCurrentMH(), 0);

		// create a submap in the range of left period
		NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = allAcq.subMap(
				startAndStopLeftPeriod.getStart().getTime(), true, startAndStopLeftPeriod.getStop().getTime(), true);
		if (removeAcq) {
			allAcqIdInInternal.remove(acq.getStartTime().getTime());
		}

		// the extra cost must be computed and splitted
		double extraCostLeftSplittedForTrainLeft = droolsParams.getExtraCostLeft() / allAcqIdInInternal.size();

		// iterate over the elements into the submap
		for (Map.Entry<Long, EnergyAssociatedToTask> elements : allAcqIdInInternal.entrySet()) {
			// extract the i-esim acq
			Acquisition currentAcq = (Acquisition) elements.getValue().getTask();

			if (currentAcq.getLookSide().equalsIgnoreCase("left")) {
				// compute the bic that must be added for the acq
				double bicToAddForAcq = extraCostLeftSplittedForTrainLeft - currentAcq.getExtraLeft();

				// update image bic
				currentAcq.setImageBIC(currentAcq.getImageBIC() + bicToAddForAcq);

				// set extra left
				currentAcq.setExtraLeft(extraCostLeftSplittedForTrainLeft);

				// invoke the function to compute extra amount of bic
				decrementDelta(currentAcq, droolsParams, bicToAddForAcq);
			}
		}
	}

	/**
	 * Decrement delta.
	 *
	 * @param acq              the acq
	 * @param droolsParams     the drools params
	 * @param deltaToIncrement the delta to increment
	 * @throws Exception the exception
	 */
	public void decrementDelta(Acquisition acq, DroolsParameters droolsParams, double deltaToIncrement)
			throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create a list of all partners
		List<Partner> listOfPartner = droolsParams.getAllPartners();

		// get the image bic
		// for each partner
		double imageBicForEachPartner = deltaToIncrement / acq.getUserInfo().size();
		logger.info("image BIC that must be splitted between partners :" + imageBicForEachPartner);
		// bicForMaster
		double bicForMaster = imageBicForEachPartner;
		// bicForSlave
		double bicForSlave = imageBicForEachPartner;

		if ((acq.getPrMode() != null) && (acq.getPrMode().compareTo(PRMode.DI2S) == 0)) {
			logger.info("image BIC that must be splitted between DI2S :" + imageBicForEachPartner);

			if (acq.getSensorMode().compareTo(TypeOfAcquisition.SPOTLIGHT_1_MSOR) == 0) {
				bicForMaster = (deltaToIncrement / 100) * droolsParams.getPercentBicDi2sMasterMSOR();
				bicForSlave = (deltaToIncrement / 100) * droolsParams.getPercentBicDi2sSlaveMSOR();
			} else if (acq.getSensorMode().compareTo(TypeOfAcquisition.SPOTLIGHT_2_MOS) == 0) {
				bicForMaster = (deltaToIncrement / 100) * droolsParams.getPercentBicDi2sMasterMSOS();
				bicForSlave = (deltaToIncrement / 100) * droolsParams.getPercentBicDi2sSlaveMSOR();
			}
			logger.info("image BIC that must be splitted between DI2S bicForMaster:" + bicForMaster);
			logger.info("image BIC that must be splitted between DI2S bicForSlave:" + bicForSlave);

			// extract the id of the related partner
			String masterId = acq.getUserInfo().get(0).getOwnerId();
			Partner master = this.bicUtils.findPartnerInList(masterId, listOfPartner);

			// extract the id of the related partner
			String slaveId = acq.getDi2sInfo().getPartnerId();
			Partner slave = this.bicUtils.findPartnerInList(slaveId, listOfPartner);

			logger.info("image BIC that must be splitted between DI2S Partner slave:" + slave);
			logger.info("image BIC that must be splitted between DI2S Partner master:" + master);
			logger.info("decrementForPartner :");

			if (master == slave) {
				decrementForPartner(master, deltaToIncrement, logger, acq, listOfPartner);
			} else {
				decrementForPartner(master, bicForMaster, logger, acq, listOfPartner);
				decrementForPartner(slave, bicForSlave, logger, acq, listOfPartner);
			}

		} else {
			// iterate over the user
			// info associated with the acq
			for (int i = 0; i < acq.getUserInfo().size(); i++) {
				// extract the id of the related partner
				String currentPartnerId = acq.getUserInfo().get(i).getOwnerId();
				Partner currentPartner = null;

				// get the linked partner
				currentPartner = this.bicUtils.findPartnerInList(currentPartnerId, listOfPartner);
				logger.info("decrementForPartner :");

				decrementForPartner(currentPartner, imageBicForEachPartner, logger, acq, listOfPartner);

			}
		}

	}

	/**
	 * Decrement for partner.
	 *
	 * @param currentPartner         the current partner
	 * @param imageBicForEachPartner the image bic for each partner
	 * @param logger                 the logger
	 * @param acq                    the acq
	 * @param listOfPartner          the list of partner
	 */
	private void decrementForPartner(Partner currentPartner, double imageBicForEachPartner, Logger logger,
			Acquisition acq, List<Partner> listOfPartner) {

		// initialize the loan
		double loan = 0;

		// if the delta bic needs a loan to be accepted
		if ((currentPartner.getUsedBIC() + imageBicForEachPartner) > currentPartner.getMaxBICAvailable()) {

			// get the part of available bic of the partner
			double ownBicUsedForCurrentAcq = currentPartner.getMaxBICAvailable() - currentPartner.getUsedBIC();

			// if the partner hasn't bic available
			if (ownBicUsedForCurrentAcq < 0) {
				ownBicUsedForCurrentAcq = 0;
				logger.info("DECREMENT_BIC_RULE_ own bic used for acq :" + ownBicUsedForCurrentAcq);

				// the loan is for the total delta bic
				loan = imageBicForEachPartner;
			}
			// if the partner has bic available
			else {
				logger.info("DECREMENT_BIC_RULE_ own bic used for acq :" + ownBicUsedForCurrentAcq);

				// the loan is the difference between the bic of the partner and
				// the total delta
				loan = imageBicForEachPartner - ownBicUsedForCurrentAcq;
			}

			// invoke the function to search a valid partner/s for the loan
			Map<Partner, Double> PartnersChoosenForLoan = getPartnerForLoan(logger, loan, currentPartner,
					listOfPartner);

			// decrement bic
			decrement_BIC_Associated_To_Partners(logger, acq, loan, currentPartner, PartnersChoosenForLoan);
		}
		// compute used bic
		double usedBIC = currentPartner.getUsedBIC() + (imageBicForEachPartner - loan);
		logger.info(
				"DECREMENT_BIC_RULE_ updated used bic :" + usedBIC + " for partner " + currentPartner.getPartnerId());
		// update used bic
		currentPartner.setUsedBIC(usedBIC);

		// if the list of acq performed doesn't contains the current one
		if (!currentPartner.getAcqPerformed().contains(acq.getId())) {
			// add it
			currentPartner.getAcqPerformed().add(acq.getId());
		}
		// if the acq is neo
		if (acq.isNeo()) {
			// update also neo bic
			currentPartner.setUsedNeoBic(currentPartner.getUsedNeoBic() + imageBicForEachPartner);
			logger.info("DECREMENT_BIC_RULE_ updated used neo bic :" + currentPartner.getUsedNeoBic());
		}
	}

	/**
	 * Decrement BI C associated to partners.
	 *
	 * @param logger                 the logger
	 * @param acq                    the acq
	 * @param loan                   the loan
	 * @param partnerAssociated      the partner associated
	 * @param PartnersChoosenForLoan the partners choosen for loan
	 */
	public void decrement_BIC_Associated_To_Partners(Logger logger, Acquisition acq, double loan,
			Partner partnerAssociated, Map<Partner, Double> PartnersChoosenForLoan) {
		// iterate over the partner choosen for loan
		for (Map.Entry<Partner, Double> entry : PartnersChoosenForLoan.entrySet()) {
			// get the i-esim partner
			Partner giveLoan = entry.getKey();

			// if is a donation
			if (entry.getKey().getDonation().contains(partnerAssociated.getPartnerId())) {
				// extract the credit card
				CreditCard credit = new CreditCard(partnerAssociated.getPartnerId(), entry.getValue(), acq.getId());

				// mark as donation
				credit.setDonation(true);

				// add it to the list of credits
				giveLoan.getGivenLoan().add(credit);

				// create a debit card
				DebitCard debit = new DebitCard(giveLoan.getPartnerId(), entry.getValue(), acq.getId());

				// mark as donation
				debit.setDonation(true);

				// add it to the list of debits
				partnerAssociated.getLoanList().add(debit);
			}
			// if isn't a donation
			else {
				// add the credit card
				giveLoan.getGivenLoan()
						.add(new CreditCard(partnerAssociated.getPartnerId(), entry.getValue(), acq.getId()));

				// add the debit card
				partnerAssociated.getLoanList()
						.add(new DebitCard(giveLoan.getPartnerId(), entry.getValue(), acq.getId()));
			}
			// update the used bic
			giveLoan.setUsedBIC(giveLoan.getUsedBIC() + entry.getValue());

			logger.info("DECREMENT_BIC_RULE_ updated partner that give loan : " + giveLoan);
			logger.info("DECREMENT_BIC_RULE_ updated partner that need a loan " + partnerAssociated);
		}
	}

	/**
	 * Gets the partner for loan.
	 *
	 * @param logger      the logger
	 * @param loan        the loan
	 * @param Partnerp    the partnerp
	 * @param allPartners the all partners
	 * @return the partner for loan
	 */
	public Map<Partner, Double> getPartnerForLoan(Logger logger, double loan, Partner Partnerp,
			List<Partner> allPartners) {
		// order partners by bic available
		this.bicUtils.sortPartnersForMaxBICAvailable(allPartners);

		// initialize the map for the partners available for loan
		Map<Partner, Double> choosenPartners = new HashMap<>();

		// initialize the residual loan with the total loan
		double residualLoan = loan;

		logger.info("DECREMENT_BIC_RULE_ total loan :" + loan);
		boolean availableLoan = false;

		// iterate over the partners
		for (int i = 0; i < allPartners.size(); i++) {
			// get the i-esim partner
			Partner p = allPartners.get(i);
			logger.info("DECREMENT_BIC_RULE_ partner :" + p);

			// if the partner has done his schedules
			if (p.isFinished() == true) {
				// if the partner id isn't the sae of who needs the loan
				if (!p.getPartnerId().equalsIgnoreCase(Partnerp.getPartnerId())) {
					// if the partner can give credit to the partner that needs
					// the loan
					if (p.getBorrowingBic().contains(Partnerp.getPartnerId())) {
						// get the bic available
						double BICAvailable = p.getMaxBICAvailable() - p.getUsedBIC();

						// if are positive
						if (BICAvailable > 0) {
							// get the percentage of bic that can be use as
							// credit for other partners
							double maxLoanAvailable = (BICAvailable / 100) * p.getMaxPercLoanBic();
							logger.info("DECREMENT_BIC_RULE_ partner max bic available :" + BICAvailable);
							logger.info("DECREMENT_BIC_RULE_ partner percentage of lent bic :" + p.getMaxPercLoanBic());
							logger.info("DECREMENT_BIC_RULE_ max loan available for partner : " + maxLoanAvailable);

							// if the maxLoanAvailable is not enough to satisfy
							// the loan -> more than 1 creditor
							if (residualLoan > maxLoanAvailable) {
								// update residual loan
								residualLoan = residualLoan - maxLoanAvailable;

								// insert the partner into the map
								choosenPartners.put(p, maxLoanAvailable);
								logger.info("DECREMENT_BIC_RULE_ loan requested to partner : " + maxLoanAvailable);
							}
							// if the maxLoanAvailable is enough to satisfy the
							// loan -> single creditor
							else {
								// insert the partner into the map for the total
								// amount of credit
								choosenPartners.put(p, residualLoan);
								logger.info("DECREMENT_BIC_RULE_ loan  requested to partner : " + residualLoan);

								// reset residual loan
								residualLoan = 0;
							}

							// if there isn't a residual loan
							if (Math.floor(residualLoan) == 0) {
								// set the boolean flag to true
								availableLoan = true;
								logger.info("DECREMENT_BIC_RULE_ bic available with loan");
								break;
							} else {
								logger.info("DECREMENT_BIC_RULE_ residual amount : " + residualLoan);
							}
						}
						// partner has 0 available bic
						else {
							// no residual BIC
							logger.info("DECREMENT_BIC_RULE_ partner " + p.getPartnerId() + "has no residual BIC");
						}
					} else {
						// partner that needs a loan is in blackList for partner
						logger.info("DECREMENT_BIC_RULE_ partner that needs a loan is in blackList for partner "
								+ p.getPartnerId());
					}
				}
			}
			// not yet done his shedule
			else {
				logger.info("DECREMENT_BIC_RULE_ partner " + p.getPartnerId() + "has no finished his acquisitions");
			}
		}
		// if the loan is not available
		if (!availableLoan) {
			// logger.info("DECREMENT_BIC_RULE_ unable to lend BIC");
			// clear the map of partners for loan
			choosenPartners.clear();
		}
		return choosenPartners;
	}

	/**
	 * Initialize BIC.
	 *
	 * @param p the p
	 */
	public void initializeBIC(Partner p) {
		// if partner has debts
		if (!p.getLoanList().isEmpty()) {
			// iterate over the list of debts
			for (int i = 0; i < p.getLoanList().size(); i++) {
				// initialize the part of loan given in this mh to zero
				double loanGivenInThisMH = 0;

				// extract the i-esim debit card
				DebitCard y = p.getLoanList().get(i);

				// mark as previously processed
				y.setPrevious(true);

				// set the part of loan given in this mh
				loanGivenInThisMH = y.getBICBorrowed();

				// decrease the available bic with the amount of the debt
				p.setMaxBICAvailable(p.getMaxBICAvailable() - loanGivenInThisMH);

				// remove the debt from the list
				p.getLoanList().remove(i);

				// decrement the index
				i--;
			}
		}
		if (!p.getGivenLoan().isEmpty()) // if partner has credits
		{
			// iterate over the list of credits
			for (int i = 0; i < p.getGivenLoan().size(); i++) {
				// extract the i-esim credit
				CreditCard z = p.getGivenLoan().get(i);

				// mark as previously processed
				z.setPrevious(true);

				// if is not a donation
				if (z.isDonation() == false) {
					// initialize the part of credit given in this mh to zero
					double loanGivenInThisMH = z.getBICLent();

					// update the bic lent
					z.setBICLent(z.getBICLent() - loanGivenInThisMH);

					// increase the available bic with the amount of the credit
					p.setMaxBICAvailable(p.getMaxBICAvailable() - loanGivenInThisMH);

					// remove the credit from the list
					p.getGivenLoan().remove(i);

					// decrement the index
					i--;
				}
			}
		}
		p.setNewBicSetup(false);
	}

	/**
	 * All linked partners for IDUGS.
	 *
	 * @param acq          the acq
	 * @param droolsParams the drools params
	 * @return true, if successful
	 */
	public boolean allLinkedPartnersForIDUGS(Acquisition acq, DroolsParameters droolsParams) {
		// initialize the return value to false
		boolean allForIDUGS = false;

		// if the acquisition has partners associated
		if (acq.getUserInfo().size() > 0) {
			// initialize the con with the number of associated partners
			int cont = acq.getUserInfo().size();

			// iterate over the associated partners
			for (int i = 0; i < acq.getUserInfo().size(); i++) {
				// extract the i-esim user info
				UserInfo user = acq.getUserInfo().get(i);

				// if the partner is associated with IDUGS ugsId
				if ((user.getUgsId() != null) && user.getUgsId().equalsIgnoreCase(droolsParams.getIdugsid())) {
					// decrement the cont
					cont--;
				}
			}

			// if all the partners associated to the acq are linked to IDUGS
			// station
			if (cont == 0) {
				// set the returned value to true
				allForIDUGS = true;
			}
		}

		return allForIDUGS;
	}

	/**
	 * Restore bic and loan to partner.
	 *
	 * @param acq                  the acq
	 * @param droolsParams         the drools params
	 * @param restoreOnlyExtraCost the restore only extra cost
	 * @param equivDto             the equiv dto
	 * @param trainLeft            the train left
	 * @param restoreTrain         the restore train
	 * @throws Exception the exception
	 */
	public void restoreBicAndLoanToPartner(Acquisition acq, DroolsParameters droolsParams, boolean restoreOnlyExtraCost,
			EquivalentDTO equivDto, boolean trainLeft, double restoreTrain) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get all the partners
		List<Partner> allPartners = droolsParams.getAllPartners();
		double bicToRestore = 0;

		// if the method is not invoked only for restore extra cost
		if (!restoreOnlyExtraCost) {
			// compute bic to restore
			bicToRestore = acq.getImageBIC() / acq.getUserInfo().size();

		}
		// method is invoked only for restore extra cost
		else {
			if (trainLeft) {

				bicToRestore = restoreTrain / acq.getUserInfo().size();
			} else {
				// bic to restore are only relative to bicToRestore
				// bicToRestore = extraCostLeft / acq.getUserInfo().size();
				bicToRestore = acq.getExtraLeft() / acq.getUserInfo().size();
			}
		}

		if (bicToRestore > 0) {
			// invoke the function that allow the restore of bic
			restoreBicToAllPartnersLinkedToAcq(acq, bicToRestore, allPartners, logger, restoreOnlyExtraCost);

		}

	}

	/**
	 * Restore bic for prev and next.
	 *
	 * @param acq               the acq
	 * @param sessionId         the session id
	 * @param currentInstance   the current instance
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @throws Exception the exception
	 */
	public void restoreBicForPrevAndNext(Acquisition acq, String sessionId, int currentInstance,
			DroolsParameters droolsParams, ResourceFunctions resourceFunctions) throws Exception {
		// get the ess function related to the current sat
		TreeMap<Long, EnergyAssociatedToTask> essFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(acq.getSatelliteId());

		// create a previous acq
		Acquisition prev = null;

		// create a next acq
		Acquisition next = null;

		// extract the previous acq id
		Object prevAcqId = essFunction.lowerKey(acq.getStartTime().getTime());

		// extract the next acq id
		Object nextAcqId = essFunction.higherKey(acq.getStartTime().getTime());

		// create a new instance of BicManagement
		BicManagement bicManagement = new BicManagement();

		// if exists a previous acq
		if (prevAcqId != null) {
			// extract it
			prev = (Acquisition) essFunction.get(prevAcqId).getTask();

			// if the previous acq has a left lookside
			if (prev.getLookSide().equalsIgnoreCase("left")) {
				// ipdate his train, if needed
				bicManagement.updateBicForOtherAcqInTrainLeft(prev, resourceFunctions, droolsParams, false);
			}
		}

		// if exists a next acq
		if (nextAcqId != null) {
			// extract it
			next = (Acquisition) essFunction.get(nextAcqId).getTask();

			// if the previous acq has a left lookside
			if (next.getLookSide().equalsIgnoreCase("left")) {
				// ipdate his train, if needed
				bicManagement.updateBicForOtherAcqInTrainLeft(next, resourceFunctions, droolsParams, false);
			}
		}

	}

	/**
	 * Restore bic to all partners linked to acq.
	 *
	 * @param acq                  the acq
	 * @param bicToRestore         the bic to restore
	 * @param allPartners          the all partners
	 * @param logger               the logger
	 * @param restoreOnlyExtraCost the restore only extra cost
	 * @throws Exception the exception
	 */
	private void restoreBicToAllPartnersLinkedToAcq(Acquisition acq, double bicToRestore, List<Partner> allPartners,
			Logger logger, boolean restoreOnlyExtraCost) throws Exception {
		// iterate over the user info linked to the acq
		if ((acq.getUserInfo() != null) && (acq.getUserInfo().size() > 0)) {
			for (int i = 0; i < acq.getUserInfo().size(); i++) {
				// get the i-esim partner id
				String partnerId = acq.getUserInfo().get(i).getOwnerId();
				// get the Partner associated with this id
				Partner partner = this.bicUtils.findPartnerInList(partnerId, allPartners);

				// if there is a partner associated
				if (partner != null) {

					logger.info("for partner :" + partner);
					// if the partner has the current acq as acq performed
					if (partner.getAcqPerformed().contains(acq.getId())) {
						logger.info("DECREMENT_BIC_RULE_ bic to restore :" + bicToRestore);
						logger.info("DECREMENT_BIC_RULE_ RESTORE BIC TO :" + partner);
						logger.info("DECREMENT_BIC_RULE_ used bic before update: " + partner.getUsedBIC());

						double totalLoan = 0;

						// iterate over the loan list of the partner
						for (int j = 0; j < partner.getLoanList().size(); j++) {

							if (totalLoan < bicToRestore) {
								// get the i-esim debit
								DebitCard debit = partner.getLoanList().get(j);

								// if the debit is relative to the acq under
								// check
								if (debit.getForAcq().equals(acq.getId())) {
									logger.info("DECREMENT_BIC_RULE_ there is a loan for this acq !");
									logger.info("DECREMENT_BIC_RULE_ restore debit to :" + debit.getCreditor());

									// iterate over all the partners
									for (int k = 0; k < allPartners.size(); k++) {
										// find the creditorId of the debit
										if (allPartners.get(k).getPartnerId().equals(debit.getCreditor())) {
											// find the associated partner
											// (creditor)
											Partner creditor = allPartners.get(k);
											logger.info("DECREMENT_BIC_RULE_partner to give back loan : " + creditor);

											// max amount that can be restored
											// to
											// the creditor is the loan
											double localRestore = debit.getBICBorrowed();

											// if the loan is more than the bic
											// that
											// must be restored
											if ((totalLoan + debit.getBICBorrowed()) > bicToRestore) {
												// restore only the difference
												localRestore = bicToRestore - totalLoan;
											}

											// increment the total loan
											totalLoan = totalLoan + localRestore;

											// update the bic used from the
											// creditor
											double updatedUsedBicCreditor = creditor.getUsedBIC() - localRestore;

											// update the loan
											debit.setBICBorrowed(debit.getBICBorrowed() - localRestore);

											// if the loan is done
											if (debit.getBICBorrowed() == 0) {
												// remove the loan from the list
												partner.getLoanList().remove(j);

												// decrement the index
												j--;
											}

											// if with the restore the creditor
											// has
											// a negative use bic
											if (updatedUsedBicCreditor < 0) {
												// force them to zero
												updatedUsedBicCreditor = 0;
											}

											// set the updated used bic for the
											// creditor
											creditor.setUsedBIC(updatedUsedBicCreditor);

											// iterate over the loans of the
											// creditor
											for (int w = 0; w < creditor.getGivenLoan().size(); w++) {
												// if there is a match with the
												// current acq in the list
												if (creditor.getGivenLoan().get(w).getDebitor()
														.equals(partner.getPartnerId())
														&& creditor.getGivenLoan().get(w).getForAcq()
																.equals(acq.getId())) {
													// if the debt is no longer
													// available
													if (((debit.getBICBorrowed() - localRestore) == 0)
															|| (debit.getBICBorrowed() == 0)) {
														// remove it from the
														// creditor list
														creditor.getGivenLoan().remove(w);

														// decrement the index
														w--;
													}
													// if the debt is more than
													// zero
													else {
														// upate the amount of
														// the
														// debt
														creditor.getGivenLoan().get(w)
																.setBICLent(creditor.getGivenLoan().get(w).getBICLent()
																		- localRestore);
													}
												}
											}

											// if the debt is no longer
											// available (
											// = 0)
											if ((debit.getBICBorrowed() - localRestore) == 0) {
												// remove it from the debitor
												// list
												partner.getLoanList().remove(j);

												// decrement the index
												j--;
											}
										}
									}
								}
							}
						}
						// if the acquisition is a NEO
						if (acq.isNeo()) {
							logger.info("DECREMENT_BIC_RULE_ NEO BIC BEFORE RESTORE " + partner.getUsedNeoBic());
							logger.info("DECREMENT_BIC_RULE_ BIC to restore " + bicToRestore);

							// update the neo bic decremented the amount of the
							// size
							// of bicToRestore
							double updatedNeoBic = partner.getUsedNeoBic() - bicToRestore;

							// if the neo bic associated with partner has a
							// negative
							// amount
							if (updatedNeoBic < 0) {
								// force it to zero
								updatedNeoBic = 0;
							}
							// update used neo bic
							partner.setUsedNeoBic(updatedNeoBic);
							logger.info("DECREMENT_BIC_RULE_ NEO BIC AFTER RESTORE " + partner.getUsedNeoBic());
						}

						double updatedUsedBic = 0;

						// compute the used bic
						updatedUsedBic = partner.getUsedBIC() - (bicToRestore - totalLoan);

						// if user bic are less then zero
						if (updatedUsedBic < 0) {
							// force to zero
							updatedUsedBic = 0;
						}

						logger.info("DECREMENT_BIC_RULE_ updated used bic are :" + updatedUsedBic);

						// set the user bic to the master
						partner.setUsedBIC(updatedUsedBic);
						logger.info("DECREMENT_BIC_RULE_ partner updated used bic :" + partner);

						// if the method is not invoked only for the restore of
						// extra cost
						if (restoreOnlyExtraCost == false) {
							// iterate over the acq performed by the partner
							for (int j = 0; j < partner.getAcqPerformed().size(); j++) {
								// if there is a match
								if (partner.getAcqPerformed().get(j).equalsIgnoreCase(acq.getId())) {
									// remove the rejected acq
									partner.getAcqPerformed().remove(j);

									// decrement the index
									j--;
									logger.info(
											"DECREMENT_BIC_RULE_ acq is removed from the list of performed acq for partner :"
													+ partner);
								}
							}
						}
//
//                        // invoke the function to extract the ar from the id of
//                        // the dto
//                        String dtoArId = FunctionUtils.extractArFromDto(acq.getId(), DroolsParameters.getSplitChar());
//
//                        if (acq.isRemoveArId() == true)
//                        {
//
//                        }
					}
					// the acq was rejected before the decrement of bic
					else {
						// no bic to restore
						logger.info(
								"DECREMENT_BIC_RULE_ no bic to restore, the acq was rejected before the decrement of bic "
										+ acq);
					}
				}
				// if the partner doesn't exist
				else {
					// no partner found
					logger.info("DECREMENT_BIC_RULE_ no partner found " + acq);
				}
			}
		}
	}

	/**
	 * Restore bic and loan for theatre.
	 *
	 * @param equivalentDtoId         the equivalent dto id
	 * @param allAcqInvolvedInTheatre the all acq involved in theatre
	 * @param extraCostTheatre        the extra cost theatre
	 * @param droolsParams            the drools params
	 * @throws Exception the exception
	 */
	public void restoreBicAndLoanForTheatre(String equivalentDtoId, List<Acquisition> allAcqInvolvedInTheatre,
			double extraCostTheatre, DroolsParameters droolsParams) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		logger.info("RESTORE BIC THEATRE : for equivalentDto : " + equivalentDtoId);

		// get all the partners
		List<Partner> allPartners = droolsParams.getAllPartners();

		double bicToRestore = 0;

		// split the extra cost for theatre between all the acq involved in it
		bicToRestore = extraCostTheatre / allAcqInvolvedInTheatre.size();

		logger.info("RESTORE_BIC THEATRE : extra cost theatre (" + extraCostTheatre + ") splitted between acq : "
				+ bicToRestore);

		// iterate over all the acquisitions involved in theatre
		for (int i = 0; i < allAcqInvolvedInTheatre.size(); i++) {
			// extract the i-esim acq
			Acquisition acq = allAcqInvolvedInTheatre.get(i);

			// compute bic to restore
			double restore = bicToRestore / acq.getUserInfo().size();

			// invoke the function that allow the restore of bic
			restoreBicToAllPartnersLinkedToAcq(acq, restore, allPartners, logger, true);

		}

	}

}
