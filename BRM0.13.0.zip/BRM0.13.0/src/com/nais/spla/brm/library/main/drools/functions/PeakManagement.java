/**
   *
   * MODULE FILE NAME: PeakManagement.java
   *
   * MODULE TYPE:      Class definition
   *
   * FUNCTION:     <Functional description of the DDC>
   *
   * PURPOSE:
   *
   * CREATION DATE:        18 set 2017
   *
   * AUTHORS:      fpedrola
   *
   * DESIGN ISSUE:     1.0
   *
   * INTERFACES:
   *
   * SUBORDINATES:
   *
   * MODIFICATION HISTORY:
   *
   *  Date            |  Name      | New ver.    | Description
   * -----------------+------------+-------------+-------------------------------
   * 18 feb 2017          | fpedrola    | 1.0         | first issue
   * -----------------+------------+-------------+-------------------------------
   *
   */

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.BicHpPeakOrbit;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class PeakManagement.
 */
public class PeakManagement {

	LeftAttitudeProfileManagement leftMng = new LeftAttitudeProfileManagement();

	/**
	 * Violated peak hp bic in function.
	 *
	 * @param acquisition            the acquisition
	 * @param droolsParams           the drools params
	 * @param bicHpPeakOrbitFunction the bic hp peak orbit function
	 * @param sat                    the sat
	 * @param toDelete               the to delete
	 * @param onlyReport             the only report
	 * @return true, if successful
	 */
	public boolean violatedPeakHpBicInFunction(Acquisition acquisition, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions, Satellite sat, boolean toDelete, boolean onlyReport) {

		TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunction = resourceFunctions
				.getBicHpPeakOrbitAssociatedToSat(acquisition.getSatelliteId());

		// declare a boolean variable to check if the peak function is violated
		// or not
		boolean violated = false;

		// get the minutes for orbit
		int minutesForOrbit = droolsParams.getMinutesForOrbit();

		int upperBoundPeak = sat.getSatelliteProperties().getUpperBoundPeakOrbit();

		// declare a double variable to check the threhold reached
		int returnedThresholdTot = 0;

		// the start time of the acquisition is the first point to insert in
		// the
		// map
		long start_head = acquisition.getStartTime().getTime();

		// the end time of the acquisition is the second point to insert in
		// the
		// map
		long end_head = acquisition.getEndTime().getTime();

		// the start time of the acquisition after an orbit is the third
		// point
		// to insert in the map
		long start_tail = acquisition.getStartTime().getTime() + (minutesForOrbit * 60000);

		// the end time of the acquisition after an orbit is the fourth
		// point to
		// insert in the map
		long end_tail = acquisition.getEndTime().getTime() + (minutesForOrbit * 60000);

		// if this boolean flag is true it means that the method is used
		// only to
		// delete the points related to the acq passed as input
		if (toDelete == true) {
			// invoke the method for delete the acq from the function
			removeFromFunction(droolsParams, acquisition, resourceFunctions, bicHpPeakOrbitFunction, start_head,
					end_head, start_tail, end_tail, upperBoundPeak);

		} else {
			System.out.println("inserting acq : " + acquisition);

			System.out.println("inserting acq with image bic : " + acquisition.getImageBIC());
			// set the interval start of the window to check
			long intervalStart = start_head;

			// set the interval end of the window to check
			long intervalEnd = end_tail;

			TreeMap<Long, Maneuver> manTreemap = resourceFunctions
					.getManeuverFunctionAssociatedToSat(acquisition.getSatelliteId());
			TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions
					.getEssFunctionAssociatedToSat(acquisition.getSatelliteId());

			if (acquisition.getLookSide().equalsIgnoreCase("left")) {
				// find the train of left acquisitions where this acq is located
				// (if any)
				DateResource leftPeriod = this.leftMng.detectActualLeftPeriod(DroolsParameters.getLogger(), acquisition,
						manTreemap, droolsParams.getCurrentMH(), droolsParams.getSatWithId(acquisition.getSatelliteId())
								.getSatelliteProperties().getPercentManLeftC2());

				// create a submap in the range of left period
				NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = allAcq
						.subMap(leftPeriod.getStart().getTime(), true, leftPeriod.getStop().getTime(), true);

				TreeMap<Long, Acquisition> onlyHpAcquisitions = new TreeMap<>();
				// get only the left acquisitions that are HP
				for (Map.Entry<Long, EnergyAssociatedToTask> onlyHp : allAcqIdInInternal.entrySet()) {
					Acquisition currentAcq = (Acquisition) onlyHp.getValue().getTask();
					if (currentAcq.getPrType().compareTo(PRType.HP) == 0) {

						// insert these new points into the map
						bicHpPeakOrbitFunction.put(currentAcq.getStartTime().getTime(),
								new BicHpPeakOrbit("sh", currentAcq.getImageBIC(), currentAcq.getId()));
						bicHpPeakOrbitFunction.put(currentAcq.getEndTime().getTime(),
								new BicHpPeakOrbit("eh", currentAcq.getImageBIC(), currentAcq.getId()));
						bicHpPeakOrbitFunction.put(currentAcq.getStartTime().getTime() + (minutesForOrbit * 60000),
								new BicHpPeakOrbit("st", currentAcq.getImageBIC(), currentAcq.getId()));
						bicHpPeakOrbitFunction.put(currentAcq.getEndTime().getTime() + (minutesForOrbit * 60000),
								new BicHpPeakOrbit("et", currentAcq.getImageBIC(), currentAcq.getId()));

						onlyHpAcquisitions.put(currentAcq.getStartTime().getTime(), currentAcq);
					}
				}

				if (!onlyHpAcquisitions.isEmpty()) {
					DroolsParameters.getLogger().debug(
							"update from " + onlyHpAcquisitions.get(onlyHpAcquisitions.firstKey()).getStartTime());
					DroolsParameters.getLogger().debug(
							"update to " + onlyHpAcquisitions.get(onlyHpAcquisitions.lastKey()).getEndTime().getTime());

					// find the first one acquisition of the train
					intervalStart = onlyHpAcquisitions.get(onlyHpAcquisitions.firstKey()).getStartTime().getTime();
					intervalEnd = onlyHpAcquisitions.get(onlyHpAcquisitions.lastKey()).getEndTime().getTime()
							+ (minutesForOrbit * 60000);
				}

			} else {

				// insert these new points into the map
				bicHpPeakOrbitFunction.put(start_head,
						new BicHpPeakOrbit("sh", acquisition.getImageBIC(), acquisition.getId()));
				bicHpPeakOrbitFunction.put(end_head,
						new BicHpPeakOrbit("eh", acquisition.getImageBIC(), acquisition.getId()));
				bicHpPeakOrbitFunction.put(start_tail,
						new BicHpPeakOrbit("st", acquisition.getImageBIC(), acquisition.getId()));
				bicHpPeakOrbitFunction.put(end_tail,
						new BicHpPeakOrbit("et", acquisition.getImageBIC(), acquisition.getId()));

			}

			// update the maps with the new points
			returnedThresholdTot = updateMap(droolsParams, acquisition, intervalStart, intervalEnd, upperBoundPeak,
					bicHpPeakOrbitFunction);

			// if the peak threshold is reached
			if (returnedThresholdTot > 0) {
				// logger.debug("PEAK RULE : reached peak threshold!");
				// remove the elements from the function
				removeFromFunction(droolsParams, acquisition, resourceFunctions, bicHpPeakOrbitFunction, start_head,
						end_head, start_tail, end_tail, upperBoundPeak);
				violated = true;
			} else {
				// check on daily sliding window
				boolean overhead = overheadOnDailySlidingWindow(acquisition, droolsParams, bicHpPeakOrbitFunction, sat,
						onlyReport);

				// if there are more than configured peaks in a day
				if (overhead) {
					acquisition.addReasonOfReject(34, ReasonOfReject.maxPeaksReached, "Peak Orbit Exceeded In A Day", 0,
							0, null);
					// remove the elements from the function
					removeFromFunction(droolsParams, acquisition, resourceFunctions, bicHpPeakOrbitFunction, start_head,
							end_head, start_tail, end_tail, upperBoundPeak);

					// reject the acquisition under check
					violated = true;
				}
			}
		}
		return violated;
	}

	/**
	 * function for check if there is an overhead on daily sliding window.
	 *
	 * @param acquisition           the acquisition
	 * @param droolsParams          the drools params
	 * @param bicHpPeakOrbitFuncion the bic hp peak orbit funcion
	 * @param sat                   the sat
	 * @param onlyReport            the only report
	 * @return true, if successful
	 */
	public boolean overheadOnDailySlidingWindow(Acquisition acquisition, DroolsParameters droolsParams,
			TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFuncion, Satellite sat, boolean onlyReport) {

		// get the minutes for orbit
		int minutesForOrbit = droolsParams.getMinutesForOrbit();

		int maxPeakAllowedInADay = sat.getSatelliteProperties().getMaxNumberDailyPeak();
		int lowerBoundPeak = sat.getSatelliteProperties().getLowerBoundPeakOrbit();
		int upperBoundPeak = sat.getSatelliteProperties().getUpperBoundPeakOrbit();

		// the check starts at the start of the acquisition under analysis
		long startCheck = (acquisition.getStartTime().getTime());

		// the check ends after a day starting from the start time of the
		// acquisition under analysis
		long stopCheck = (long) (acquisition.getStartTime().getTime() + (minutesForOrbit * 14.85 * 60000));

		long orbitDuration = minutesForOrbit * 60000;

		//// logger.debug("PEAK RULE : start check : " + new Date(startCheck));
		//// logger.debug("PEAK RULE : stop check : " + new Date(stopCheck));
		boolean overheadDailyPeak = false;

		// this variable is used to take in account the number of peak orbits
		// founded in a day
		int numberOfDailyPeak = 0;

		// extract all the elements from the start to the end of the check
		SortedMap<Long, BicHpPeakOrbit> subMap = bicHpPeakOrbitFuncion.subMap(startCheck, true, stopCheck, true);

		// iterate over the extracted elements
		for (Map.Entry<Long, BicHpPeakOrbit> elementsInSubMap : subMap.entrySet()) {
			long currentElementKey = elementsInSubMap.getKey();

			// extract the i-esim element
			BicHpPeakOrbit currentElementValue = elementsInSubMap.getValue();

			// the check starts a day before the start time of the extracted
			// element
			startCheck = (long) (elementsInSubMap.getKey() - (minutesForOrbit * 14.85 * 60000));
			stopCheck = elementsInSubMap.getKey();

			// extract all the elements from the start to the end of the local
			// check
			SortedMap<Long, BicHpPeakOrbit> localSubMap = bicHpPeakOrbitFuncion.subMap(startCheck, true, stopCheck,
					true);

			// get the number of peaks founded in a day
			numberOfDailyPeak = computePeakOrbitInInterval(localSubMap, orbitDuration, overheadDailyPeak,
					currentElementKey, currentElementValue, bicHpPeakOrbitFuncion, lowerBoundPeak, upperBoundPeak,
					minutesForOrbit);

			// logger.debug("PEAK RULE : daily peaks found : " +
			// numberOfDailyPeak);

			// if the daily threshold is reached
			if (numberOfDailyPeak > maxPeakAllowedInADay) {
				// set the boolean variable to true
				overheadDailyPeak = true;

				// exit from the cycle
				break;
			}
		}
		return overheadDailyPeak;
	}

	/**
	 * Compute peak orbit in interval.
	 *
	 * @param localSubMap           the local sub map
	 * @param orbitDuration         the orbit duration
	 * @param overheadDailyPeak     the overhead daily peak
	 * @param currentElementKey     the current element key
	 * @param elementInSubMap       the element in sub map
	 * @param bicHpPeakOrbitFuncion the bic hp peak orbit funcion
	 * @param lowerBoundPeak        the lower bound peak
	 * @param upperBoundPeak        the upper bound peak
	 * @param minutesForOrbit       the minutes for orbit
	 * @return the int
	 */
	private int computePeakOrbitInInterval(SortedMap<Long, BicHpPeakOrbit> localSubMap, long orbitDuration,
			boolean overheadDailyPeak, long currentElementKey, BicHpPeakOrbit elementInSubMap,
			TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFuncion, int lowerBoundPeak, int upperBoundPeak,
			int minutesForOrbit) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// initialize number of peak orbits
		int numberOfDailyPeak = 0;
		int cont = 0;
		boolean inPeak = false;

		// initalize start and end of peak
		Date startOfPeak = null;
		Date endOfPeak = null;
		long startPeakAsLong = 0;
		double totalBic = 0;
		int numberOfLocalPeak = 0;

		for (Map.Entry<Long, BicHpPeakOrbit> elementsInLocalSubMap : localSubMap.entrySet()) {
			// extract the i-esim element inside the function
			BicHpPeakOrbit currentElement = elementsInLocalSubMap.getValue();

			// if is an "end head" element
			// (the point where we increment the
			// peak function with the amount
			// of bic related to the acquisition
			// under analysis
			if (currentElement.getType().equalsIgnoreCase("eh")) {
				// increment the total bic
				totalBic = totalBic + currentElement.getBicHp();
				// logger.trace("PEAK RULE : element checked : " +
				// currentElement.getAcqId() + " with bic :" +
				// currentElement.getBicHp() + " type :" +
				// currentElement.getType());
				// logger.trace("PEAK RULE : increment total bic of " +
				// currentElement.getBicHp() + ", total is: " + totalBic);
			}

			// if is an "end tail" element (the point where we decrement the
			// peak function of the amount of bic related to the acquisition
			// under analysis

			else if (currentElement.getType().equalsIgnoreCase("et")) {
				// decrement the total bic
				totalBic = totalBic - currentElement.getBicHp();
				// logger.trace("PEAK RULE : element checked : " +
				// currentElement.getAcqId() + " with bic :" +
				// currentElement.getBicHp() + " type :" +
				// currentElement.getType());
				// logger.trace("PEAK RULE : decrement total bic of " +
				// currentElement.getBicHp() + ", total is: " + totalBic);
			}

			/*
			 * otherwise, continue to next element
			 */
			else if (currentElement.getType().equalsIgnoreCase("sh")
					|| currentElement.getType().equalsIgnoreCase("st")) {
				continue;
			}

			// logger.trace("PEAK RULE : actual bic : " + totalBic);

			// if the updated total bic are in interval defined as peak orbit
			if ((totalBic >= lowerBoundPeak) && (totalBic < upperBoundPeak)) {
				// set the variable inPeak as true
				inPeak = true;

				// if cont = 0 means that we are
				// entering in peak with this acq,
				// before there wasn't a peak situation
				if (cont == 0) {
					// logger.trace("PEAK RULE : starts of peak orbit detected
					// at " + new Date(elementsInLocalSubMap.getKey()));

					long previousStartTime = getPreviousSh(bicHpPeakOrbitFuncion, elementsInLocalSubMap);

					// logger.trace("PEAK RULE : previous element in map : " +
					// new Date(previousStartTime));

					// compute the previous total bic
					double previousBicValue = totalBic - (currentElement.getBicHp());
					// logger.trace("PEAK RULE : previous bic : " +
					// previousBicValue);

					// compute the gap
					long gap = elementsInLocalSubMap.getKey() - previousStartTime;

					// compute the start of peak as long
					startPeakAsLong = (long) ((gap / (totalBic - previousBicValue))
							* (lowerBoundPeak - previousBicValue));

					// and as Date
					startOfPeak = new Date(previousStartTime + startPeakAsLong);
					// logger.trace("PEAK RULE : real start of peak : " +
					// startOfPeak);
					cont++;
					numberOfDailyPeak++;
				} else {
					// more than maximum allowed for peak
					if (totalBic > upperBoundPeak) {
						// logger.trace("PEAK RULE : error : more than maximum
						// allowed for peak !");

						// set the overhead to true
						overheadDailyPeak = true;
						break;
					}
				}
			}
			// was in peak and now come
			// back in a safe state
			if (inPeak && (totalBic < lowerBoundPeak)) {
				logger.trace("PEAK RULE : end of peak orbit " + new Date(elementsInLocalSubMap.getKey()));

				// set the boolean varable to false
				inPeak = false;

				// compute the previous start time
				long previousStartTime = bicHpPeakOrbitFuncion.lowerEntry(elementsInLocalSubMap.getKey()).getKey();
				logger.trace("PEAK RULE : previous start : " + new Date(previousStartTime));

				endOfPeak = new Date(elementsInLocalSubMap.getKey());
				// logger.trace("PEAK RULE : end of peak : " + endOfPeak);

				// if the duration of peak is more than 2 continuative orbits
				if ((endOfPeak.getTime() - startOfPeak.getTime()) > (2 * minutesForOrbit * 60000)) {
					// unvalid the peak check
					numberOfDailyPeak = 100;
					// logger.debug("PEAK RULE : more than 2 peak for day");
				}
				// else if is between 1 orbit and 2
				else if (((endOfPeak.getTime() - startOfPeak.getTime()) > (minutesForOrbit * 60000))
						&& ((endOfPeak.getTime() - startOfPeak.getTime()) < (2 * minutesForOrbit * 60000))) {
					// increment the number of peaks
					numberOfLocalPeak++;
				}
				numberOfDailyPeak = numberOfDailyPeak + numberOfLocalPeak;
			}
		}
		return numberOfDailyPeak;
	}

	/**
	 * Gets the previous sh.
	 *
	 * @param bicHpPeakOrbitFuncion the bic hp peak orbit funcion
	 * @param elementsInLocalSubMap the elements in local sub map
	 * @return the previous sh
	 */
	private long getPreviousSh(TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFuncion,
			Entry<Long, BicHpPeakOrbit> elementsInLocalSubMap) {
		long prevStartTime = 0;

		// initialize boolean to false
		boolean found = false;

		// get previous element
		Entry<Long, BicHpPeakOrbit> prevElement = bicHpPeakOrbitFuncion.lowerEntry(elementsInLocalSubMap.getKey());

		// iterate till while the boolean variable is false
		while (!found) {
			// if previous element is sh
			if (prevElement.getValue().getType().equals("sh")) {
				found = true;
			}
			// if not
			else {
				// get previous element
				prevElement = bicHpPeakOrbitFuncion.lowerEntry(prevElement.getKey());
			}
			// get the start time of prev element
			prevStartTime = prevElement.getKey();
		}
		return prevStartTime;
	}

	/**
	 * Removes the acquisition from the peak function.
	 *
	 * @param droolsParams   the drools params
	 * @param acq            the acq
	 * @param hashMapEss     the hash map ess
	 * @param start_head     the start head
	 * @param end_head       the end head
	 * @param start_tail     the start tail
	 * @param end_tail       the end tail
	 * @param upperBoundPeak the upper bound peak
	 */
	public void removeFromFunction(DroolsParameters droolsParams, Acquisition acq, ResourceFunctions resFunc,
			TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunction, Long start_head, Long end_head, Long start_tail,
			Long end_tail, int upperBoundPeak) {
		int minutesForOrbit = droolsParams.getMinutesForOrbit();
		TreeMap<Long, BicHpPeakOrbit> hashMapEss = resFunc.getBicHpPeakOrbitAssociatedToSat(acq.getSatelliteId());
		TreeMap<Long, Maneuver> manTreemap = resFunc.getManeuverFunctionAssociatedToSat(acq.getSatelliteId());
		TreeMap<Long, EnergyAssociatedToTask> allAcq = resFunc.getEssFunctionAssociatedToSat(acq.getSatelliteId());

		// if there is an instance on the peak
		// function associated with the acq
		// that must be removed
		if (hashMapEss.containsKey(start_head)) {
			// remove all the elements
			// related to the acq
			hashMapEss.remove(start_head);
			hashMapEss.remove(end_head);
			hashMapEss.remove(start_tail);
			hashMapEss.remove(end_tail);

			if (acq.getLookSide().equalsIgnoreCase("left")) {
				// find the train of left acquisitions where this acq is located
				// (if any)
				DateResource leftPeriod = this.leftMng.detectActualLeftPeriod(DroolsParameters.getLogger(), acq,
						manTreemap, droolsParams.getCurrentMH(),
						droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties().getPercentManLeftC2());

				// create a submap in the range of left period
				NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = allAcq
						.subMap(leftPeriod.getStart().getTime(), true, leftPeriod.getStop().getTime(), true);

				TreeMap<Long, Acquisition> onlyHpAcquisitions = new TreeMap<>();
				// get only the left acquisitions that are HP
				for (Map.Entry<Long, EnergyAssociatedToTask> onlyHp : allAcqIdInInternal.entrySet()) {
					Acquisition currentAcq = (Acquisition) onlyHp.getValue().getTask();
					if ((currentAcq.getPrType().compareTo(PRType.HP) == 0)
							&& !currentAcq.getIdTask().equalsIgnoreCase(acq.getIdTask())) {

						// insert these new points into the map
						bicHpPeakOrbitFunction.put(currentAcq.getStartTime().getTime(),
								new BicHpPeakOrbit("sh", currentAcq.getImageBIC(), currentAcq.getId()));
						bicHpPeakOrbitFunction.put(currentAcq.getEndTime().getTime(),
								new BicHpPeakOrbit("eh", currentAcq.getImageBIC(), currentAcq.getId()));
						bicHpPeakOrbitFunction.put(currentAcq.getStartTime().getTime() + (minutesForOrbit * 60000),
								new BicHpPeakOrbit("st", currentAcq.getImageBIC(), currentAcq.getId()));
						bicHpPeakOrbitFunction.put(currentAcq.getEndTime().getTime() + (minutesForOrbit * 60000),
								new BicHpPeakOrbit("et", currentAcq.getImageBIC(), currentAcq.getId()));

						onlyHpAcquisitions.put(currentAcq.getStartTime().getTime(), currentAcq);
					}
				}

				if (!onlyHpAcquisitions.isEmpty()) {
					DroolsParameters.getLogger().debug(
							"update from " + onlyHpAcquisitions.get(onlyHpAcquisitions.firstKey()).getStartTime());
					DroolsParameters.getLogger().debug(
							"update to " + onlyHpAcquisitions.get(onlyHpAcquisitions.lastKey()).getEndTime().getTime());

					// find the first one acquisition of the train
					start_head = onlyHpAcquisitions.get(onlyHpAcquisitions.firstKey()).getStartTime().getTime();
					end_tail = onlyHpAcquisitions.get(onlyHpAcquisitions.lastKey()).getEndTime().getTime()
							+ (minutesForOrbit * 60000);
				}

			}

			// update the peak function
			updateMap(droolsParams, acq, start_head, end_tail, upperBoundPeak, hashMapEss);
		}
	}

	/**
	 * Update map.
	 *
	 * @param droolsParams   the drools params
	 * @param acq            the acq
	 * @param by             the by
	 * @param to             the to
	 * @param upperBoundPeak the upper bound peak
	 * @param hashMapEss     the hash map ess
	 * @return the int
	 */
	public int updateMap(DroolsParameters droolsParams, Acquisition acq, Long by, Long to, int upperBoundPeak,
			TreeMap<Long, BicHpPeakOrbit> hashMapEss) {

		// initialize orbit threshold
		int orbitThresholdTot = 0;
		int tot = 0;

		// get the submap
		SortedMap<Long, BicHpPeakOrbit> subMap = hashMapEss.subMap(by, true, to, true);

		// create an empty list of elements involved id
		List<String> elementsInvolved = new ArrayList<>();

		// iterate over the submap
		for (Map.Entry<Long, BicHpPeakOrbit> entry : subMap.entrySet()) {
			// extract the key
			Long key = entry.getKey();

			// extract the value
			BicHpPeakOrbit value = entry.getValue();

			// update the bic total
			tot = updateBicTotal(droolsParams, acq, key, value, hashMapEss, upperBoundPeak, elementsInvolved);

			// increment the orbit threshold
			orbitThresholdTot = orbitThresholdTot + tot;
		}
		return orbitThresholdTot;
	}

	/**
	 * Update ess total.
	 *
	 * @param droolsParams     the drools params
	 * @param acq              the acq
	 * @param timeAsLong       the time as long
	 * @param valueToUpload    the value to upload
	 * @param hashMapBic       the hash map bic
	 * @param upperBoundPeak   the upper bound peak
	 * @param elementsInvolved the elements involved
	 * @return the int
	 */
	public int updateBicTotal(DroolsParameters droolsParams, Acquisition acq, Long timeAsLong,
			BicHpPeakOrbit valueToUpload, TreeMap<Long, BicHpPeakOrbit> hashMapBic, int upperBoundPeak,
			List<String> elementsInvolved) {
		Logger logger = DroolsParameters.getLogger();
		// this value is setted to 1 if and only
		// if is exceeded the upper bound
		// value for a peak orbit
		int moreThanMaxPeakThreshold = 0;
		String type = valueToUpload.getType();
		double bicHp = valueToUpload.getBicHp();

		// get the bic related to previous acquisition, if exists
		double totalBic = receivePreviousElement(timeAsLong, hashMapBic);

		if (!elementsInvolved.contains(valueToUpload.getAcqId())) {
			elementsInvolved.add(valueToUpload.getAcqId());
		}
		/*
		 * if the current element is an end head, increment the bic with the bic related
		 * to the acquisition
		 */
		if (type.equals("eh")) {
			totalBic = totalBic + bicHp;
		}

		/*
		 * if the current element is an end tail, decrement the bic of the bic related
		 * to the acquisition
		 */
		if (type.equals("et")) {
			totalBic = totalBic - bicHp;
		}

		// there is a violation
		// on the max value for peak
		if (totalBic > upperBoundPeak) {
			moreThanMaxPeakThreshold = 1;
			logger.debug("exceed the max value allowed for peak (more than upperbound)");

			// add reason of reject
			acq.addReasonOfReject(39, ReasonOfReject.moreThanUpperBoundPeaksBic,
					"The Bic In A Peak Orbit Exceeds The Upper Bound Value", 0, 0, elementsInvolved);

		}
		// no violation, check passed
		else {
			// set the total ess
			valueToUpload.setTotalEss(totalBic);

			// insert in treeap
			hashMapBic.put(timeAsLong, valueToUpload);
		}
		return moreThanMaxPeakThreshold;
	}

	/**
	 * Receive previous element.
	 *
	 * @param currentKey the startTime of the acquisition under analysis
	 * @param hashMapBic the hash map bic
	 * @return the double
	 */
	public Double receivePreviousElement(Long currentKey, TreeMap<Long, BicHpPeakOrbit> hashMapBic) {
		double bicassociatedToPrevElement = 0;
		// extract the previous element of the currentKey, if exist
		Object previousEssKey = hashMapBic.lowerKey(currentKey);

		// if exists a previous element
		if (previousEssKey != null) {
			// extract the related object
			BicHpPeakOrbit previous = hashMapBic.get(previousEssKey);

			// set the returned variable with the bic associated with previous
			// element
			bicassociatedToPrevElement = previous.getTotalEss();
		}

		return bicassociatedToPrevElement;
	}
}
