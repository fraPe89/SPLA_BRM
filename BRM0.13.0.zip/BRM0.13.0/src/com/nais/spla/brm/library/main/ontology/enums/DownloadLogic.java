/**
 *
 * MODULE FILE NAME: DownloadLogic.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum DownloadLogic.
 */
public enum DownloadLogic {

	/** The pt. */
	PT,

	/** The paw. */
	PAW,

	/** The dwl. */
	DWL,

	/** The gps. */
	GPS
}
