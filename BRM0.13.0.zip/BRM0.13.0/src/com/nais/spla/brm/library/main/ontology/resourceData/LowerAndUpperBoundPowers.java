/**
*
* MODULE FILE NAME:	LowerAndUpperBoundPowers.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		29 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 29 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;

/**
 * The Class LowerAndUpperBoundPowers.
 *
 * @author francesca
 */
public class LowerAndUpperBoundPowers {

	/** The sensor mode. */
	private TypeOfAcquisition sensorMode;

	/** The lower bound. */
	private boolean lowerBound;

	/** The power associated. */
	private double powerAssociated;

	/**
	 * Instantiates a new lower and upper bound powers.
	 *
	 * @param sensorMode      the sensor mode
	 * @param lowerBound      the lower bound
	 * @param powerAssociated the power associated
	 */
	public LowerAndUpperBoundPowers(TypeOfAcquisition sensorMode, boolean lowerBound, double powerAssociated) {
		super();
		this.sensorMode = sensorMode;
		this.lowerBound = lowerBound;
		this.powerAssociated = powerAssociated;
	}

	/**
	 * Gets the sensor mode.
	 *
	 * @return the sensorMode
	 */
	public TypeOfAcquisition getSensorMode() {
		return this.sensorMode;
	}

	/**
	 * Checks if is lower bound.
	 *
	 * @return the lowerBound
	 */
	public boolean isLowerBound() {
		return this.lowerBound;
	}

	/**
	 * Gets the power associated.
	 *
	 * @return the powerAssociated
	 */
	public double getPowerAssociated() {
		return this.powerAssociated;
	}

}
