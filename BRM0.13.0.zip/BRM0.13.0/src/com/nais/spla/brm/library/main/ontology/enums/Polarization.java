/**
*
* MODULE FILE NAME:	Polarization.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		22 giu 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 22 giu 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum Polarization.
 *
 * @author fpedrola
 */
public enum Polarization {

	/** The hh. */
	HH,

	/** The vv. */
	VV,

	/** The hv. */
	HV,

	/** The vh. */
	VH,

	/** The hv hv. */
	HV_HV,

	/** The hv vh. */
	HV_VH,

	/** The vh hv. */
	VH_HV,

	/** The vh vh. */
	VH_VH,

	/** The hh hh. */
	HH_HH,

	/** The vv vv. */
	VV_VV,

	/** The hh vv. */
	HH_VV,

	/** The h h. */
	H_H,

	/** The v v. */
	V_V,

	/** The v h. */
	V_H,

	/** The h v. */
	H_V
}
