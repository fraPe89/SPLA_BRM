/**
 *
 * MODULE FILE NAME: DateResource.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.Date;

/**
 * The Class DateResource.
 */
public class DateResource {

	/** The start. */
	private Date start;

	/** The stop. */
	private Date stop;

	/** The is end. */
	private boolean isEnd;

	/**
	 * Instantiates a new date resource.
	 */
	public DateResource() {
		super();
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DateResource [start=" + this.start + ", stop=" + this.stop + "]";
	}

	/**
	 * Gets the stop.
	 *
	 * @return the stop
	 */
	public Date getStop() {
		return this.stop;
	}

	/**
	 * Sets the stop.
	 *
	 * @param stop the new stop
	 */
	public void setStop(Date stop) {
		this.stop = stop;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public Date getStart() {
		return this.start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the new start
	 */
	public void setStart(Date start) {
		this.start = start;
	}

	/**
	 * Checks if is end.
	 *
	 * @return true, if is end
	 */
	public boolean isEnd() {
		return this.isEnd;
	}

	/**
	 * Sets the end.
	 *
	 * @param isEnd the new end
	 */
	public void setEnd(boolean isEnd) {
		this.isEnd = isEnd;
	}
}
