/**
 *
 * MODULE FILE NAME: CmgaResources.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.utils;

/**
 * The Class CmgaResources.
 */
public class CmgaResources {

	/** The t plat. */
	private double tPlat;

	/** The t ramp. */
	private double tRamp;

	/** The t rest. */
	private double tRest;

	/**
	 * Instantiates a new cmga resources.
	 */
	public CmgaResources() {
		super();
	}

	/**
	 * Instantiates a new cmga resources.
	 *
	 * @param tPlat the t plat
	 * @param tRamp the t ramp
	 * @param tRest the t rest
	 */
	public CmgaResources(double tPlat, double tRamp, double tRest) {
		super();

		// set the tPlat
		this.tPlat = tPlat;

		// set the tRamp
		this.tRamp = tRamp;

		// set the tRest
		this.tRest = tRest;
	}

	/**
	 * Gets the t plat.
	 *
	 * @return the t plat
	 */
	public double gettPlat() {
		return this.tPlat;
	}

	/**
	 * Sets the t plat.
	 *
	 * @param tPlat the new t plat
	 */
	public void settPlat(double tPlat) {
		this.tPlat = tPlat;
	}

	/**
	 * Gets the t ramp.
	 *
	 * @return the t ramp
	 */
	public double getTRamp() {
		return this.tRamp;
	}

	/**
	 * Sets the t ramp.
	 *
	 * @param tRamp the new t ramp
	 */
	public void setTRamp(double tRamp) {
		this.tRamp = tRamp;
	}

	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "CmgaResources [tPlat=" + this.tPlat + ", tRamp=" + this.tRamp + ", tRest=" + this.tRest + "]";
	}

	/**
	 * Gets the t rest.
	 *
	 * @return the t rest
	 */
	public double gettRest() {
		return this.tRest;
	}

	/**
	 * Sets the t rest.
	 *
	 * @param tRest the new t rest
	 */
	public void settRest(double tRest) {
		this.tRest = tRest;
	}

}
