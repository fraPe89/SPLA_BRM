/**
*
* MODULE FILE NAME: Storage.java
*
* MODULE TYPE:      <Class definition>
*
* FUNCTION:         <Functional description of the DDC>
*
* PURPOSE:          <List of SR>
*
* CREATION DATE:    <17-NOV-2016>
*
* AUTHORS:          Tommaso Grenga, Francesca Pedrola
*
* DESIGN ISSUE:     0.1
*
* INTERFACES:       <prototype and list of input/output parameters>
*
* SUBORDINATES:     <list of functions called by this DDC>
*
* MODIFICATION HISTORY:
*
*             Date          |  Name      |   New ver.     | Description
* --------------------------+------------+----------------+-------------------------------
* <DD-MMM-YYYY>             | <name>     |<Ver>.<Rel>     | <reasons of changes>
* --------------------------+------------+----------------+-------------------------------
*
* PROCESSING
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;

// TODO: Auto-generated Javadoc
/**
 * This class models the task associated with an image storage.
 */
@SuppressWarnings("serial")
public class Storage extends Task {

	/** The packet store size H. */
	private int packetStoreSizeH = 0;

	/** The packet store size V. */
	private int packetStoreSizeV = 0;

	/** The ugs id. */
	private String ugsId = null;

	/** The related acq id. */
	private String relatedAcqId;

	/** The pol. */
	private Polarization pol;

	/** The packets associated. */
	private List<PacketStore> packetsAssociated;

	/**
	 * Instantiates a new storage.
	 */
	public Storage() {
		super();
	}

	/**
	 * Instantiates a new storage.
	 *
	 * @param id              the id
	 * @param numberOfSectors the number of sectors
	 * @param startTime       the start time
	 * @param endTime         the end time
	 * @param pol             the pol
	 */
	public Storage(String id, int numberOfSectors, Date startTime, Date endTime, Polarization pol) {
		super.setIdTask(id);
		super.setTaskType(TaskType.STORE);
		super.setStartTime(startTime);
		super.setEndTime(endTime);
		super.setPreviousMh(false);
		super.setPreviousSession(false);
		this.pol = pol;
		this.packetStoreSizeH = 0;
		this.packetStoreSizeV = 0;
		this.packetsAssociated = new ArrayList<>();
	}

	/**
	 * Instantiates a new storage.
	 *
	 * @param id               the id
	 * @param packetStoreSizeV the packet store size V
	 * @param packetStoreSizeH the packet store size H
	 * @param startTime        the start time
	 * @param endTime          the end time
	 * @param pol              the pol
	 */
	public Storage(String id, int packetStoreSizeV, int packetStoreSizeH, Date startTime, Date endTime,
			Polarization pol) {
		super.setIdTask(id);
		super.setTaskType(TaskType.STORE);
		super.setStartTime(startTime);
		super.setEndTime(endTime);
		super.setPreviousSession(false);
		super.setPreviousMh(false);
		this.pol = pol;
		this.packetStoreSizeH = packetStoreSizeH;
		this.packetStoreSizeV = packetStoreSizeV;
	}

	/**
	 * Gets the ugs id.
	 *
	 * @return the ugsId
	 */
	public String getUgsId() {
		return this.ugsId;
	}

	/**
	 * Sets the ugs id.
	 *
	 * @param ugsId the ugsId to set
	 */
	public void setUgsId(String ugsId) {
		this.ugsId = ugsId;
	}

	/** 
	 * return the end time of the storage
	 * @return the storage end time
	 */
	@Override
	public Date getEndTime() {
		return super.getEndTime();
	}

	/**
	 * Gets the id task.
	 *
	 * @return the id
	 */
	@Override
	public String getIdTask() {
		return super.getIdTask();
	}

	/**
	 * Gets the number of sectors.
	 *
	 * @param pol the pol
	 * @return the numberOfSectors
	 */
	public int getNumberOfSectors(Polarization pol) {
		int returnedPackets = 0;
		//if the polarization is HH
		if (pol.equals(Polarization.HH)) {
			returnedPackets = this.packetStoreSizeH;
		} 
		//if the polarization is VV
		else if (pol.equals(Polarization.VV)) {
			returnedPackets = this.packetStoreSizeV;
		} 
		//else add both sie H and V
		else {
			returnedPackets = this.packetStoreSizeV + this.packetStoreSizeH;
		}
		return returnedPackets;
	}

	/**
	 * Gets the packets store.
	 *
	 * @param pol the pol
	 * @return the packets store
	 */
	public PacketStore getPacketsStore(Polarization pol) {
		PacketStore ps = null;
		for (int i = 0; i < this.packetsAssociated.size(); i++) {
			if (this.packetsAssociated.get(i).getPolarization().compareTo(pol) == 0) {
				ps = this.packetsAssociated.get(i);
			}
		}
		return ps;
	}

	/**
	 * Gets the packets associated.
	 *
	 * @return the packets associated
	 */
	public List<PacketStore> getPacketsAssociated() {
		return this.packetsAssociated;
	}

	/**
	 * Gets the pol.
	 *
	 * @return the pol
	 */
	public Polarization getPol() {
		return this.pol;
	}

	/** 
	 * return the task type of the storage
	 * @return the task type
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/** 
	 * set the task type to STORE
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}

	/**
	 * Gets the related acq id.
	 *
	 * @return the relatedAcqId
	 */
	public String getRelatedAcqId() {
		return this.relatedAcqId;
	}

	/**
	 *  
	 * get the startTime of the task.
	 *
	 * @return the startTime
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}


	/**
	 * Gets the packet store size H.
	 *
	 * @return the packet store size H
	 */
	public int getPacketStoreSizeH() {
		return this.packetStoreSizeH;
	}

	/**
	 * Sets the packet store size H.
	 *
	 * @param packetStoreSizeH the new packet store size H
	 */
	public void setPacketStoreSizeH(int packetStoreSizeH) {
		this.packetStoreSizeH = packetStoreSizeH;
	}

	/**
	 * Gets the packet store size V.
	 *
	 * @return the packet store size V
	 */
	public int getPacketStoreSizeV() {
		return this.packetStoreSizeV;
	}

	/**
	 * Sets the packet store size V.
	 *
	 * @param packetStoreSizeV the new packet store size V
	 */
	public void setPacketStoreSizeV(int packetStoreSizeV) {
		this.packetStoreSizeV = packetStoreSizeV;
	}

	/**
	 * Sets the packets associated.
	 *
	 * @param packetsAssociated the new packets associated
	 */
	public void setPacketsAssociated(List<PacketStore> packetsAssociated) {
		this.packetsAssociated = packetsAssociated;
	}

	/**
	 * Sets the pol.
	 *
	 * @param pol the new pol
	 */
	public void setPol(Polarization pol) {
		this.pol = pol;
	}

	/**
	 * Sets the related acq id.
	 *
	 * @param relatedAcqId the relatedAcqId to set
	 */
	public void setRelatedAcqId(String relatedAcqId) {
		this.relatedAcqId = relatedAcqId;
	}

	/**
	 *  
	 * get the task mark type.
	 *
	 * @return the task mark
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/**
	 *  
	 * set the taskMark type.
	 *
	 * @param taskMark the new task mark
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Storage [packetStoreSizeH=" + this.packetStoreSizeH + ", packetStoreSizeV=" + this.packetStoreSizeV
				+ ", ugsId=" + this.ugsId + ", relatedAcqId=" + this.relatedAcqId + ", pol=" + this.pol
				+ ", packetsAssociated=" + this.packetsAssociated + ", getStartTime()=" + getStartTime()
				+ ", getEndTime()=" + getEndTime() + ", getPacketStoreSizeH()=" + getPacketStoreSizeH()
				+ ", getPacketStoreSizeV()=" + getPacketStoreSizeV() + ", getDi2sInfo()=" + getDi2sInfo() + "]";
	}

}
