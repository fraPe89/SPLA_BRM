/**
 *
 * MODULE FILE NAME: RampCMGA.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.tasks;

import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;

/**
 * The Class RampCMGA.
 */
@SuppressWarnings("serial")
public class RampCMGA extends Task {
	/** The ramp up. */
	// is true when the Ramp is of type "up", false if is "down"
	private boolean rampUp;

	/**
	 *
	 */
	public RampCMGA() {
		super();

	}

	/**
	 * Instantiates a new ramp CMGA.
	 *
	 * @param idTask    the id task
	 * @param startTime the start time
	 * @param rampUp    the ramp up
	 */
	public RampCMGA(String idTask, Date startTime, boolean rampUp) {
		super();
		// set the id of the task
		super.setIdTask(idTask);

		// set the task type
		super.setTaskType(TaskType.RAMP);

		// set the start time
		super.setStartTime(startTime);

		// set if is a ramp up or down
		this.rampUp = rampUp;
	}

	/**
	 * Instantiates a new ramp CMGA.
	 *
	 * @param idTask      the id task
	 * @param startTime   the start time
	 * @param rampUp      the ramp up
	 * @param satelliteId the satellite id
	 */
	public RampCMGA(String idTask, Date startTime, Date endTime, boolean rampUp, String satelliteId) {
		super();
		// set the id of the task
		super.setIdTask(idTask);

		// set the task type
		super.setTaskType(TaskType.RAMP);

		// set the start time
		super.setStartTime(startTime);

		// set if is a ramp up or down
		this.rampUp = rampUp;

		// set the end time
		super.setEndTime(endTime);

		// set the satellite id
		super.setSatelliteId(satelliteId);
	}

	/** 
	 * get the start time of the ramp
	 * @return the ramp start time
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/** 
	 * set the start time of the ramp
	 * @return the ramp start time
	 */
	@Override
	public void setStartTime(Date startTime) {
		super.setStartTime(startTime);
	}

	/**
	 * Checks if is ramp up.
	 *
	 * @return true, if is ramp up
	 */
	public boolean isRampUp() {
		return this.rampUp;
	}

	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "RampCMGA [rampUp=" + this.rampUp + ", getStartTime()=" + getStartTime() + ", getSatelliteId()="
				+ getSatelliteId() + ", getEndTime()=" + getEndTime() + "]";
	}

	/** 
	 * get the task mark
	 * @return the task mark
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/** 
	 * get the task type
	 * @return the task type
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/** 
	 * set the correct task type to RAMPCMGA
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}

	/** 
	 * set the task mark 
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/** 
	 * set the task id
	 */
	@Override
	public void setIdTask(String idTask) {
		super.setIdTask(idTask);
	}

	/** 
	 * set the satellite id
	 */
	@Override
	public void setSatelliteId(String satelliteId) {
		super.setSatelliteId(satelliteId);
	}

	/** 
	 * get the satellite id
	 * @return the satellite id
	 */
	@Override
	public String getSatelliteId() {
		return super.getSatelliteId();
	}

	/** 
	 * get the task id
	 * @return the task id
	 */
	@Override
	public String getIdTask() {
		return super.getIdTask();
	}
}
