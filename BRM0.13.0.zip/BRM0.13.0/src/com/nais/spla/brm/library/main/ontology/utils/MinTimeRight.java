/**
 *
 * MODULE FILE NAME: MinTimeRight.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.utils;

/**
 * The Class MinTimeRight.
 */
public class MinTimeRight {

	/** The total ess LR. */
	private double totalEssLR;

	/** The only ess L. */
	private double onlyEssL;

	/** The time in right. */
	private double timeInRight;

	/**
	 * Instantiates a new min time right.
	 *
	 * @param totalEssLR  the total ess LR
	 * @param onlyEssL    the only ess L
	 * @param timeInRight the time in right
	 */
	public MinTimeRight(double totalEssLR, double onlyEssL, double timeInRight) {
		super();

		// set the total ess LR
		this.totalEssLR = totalEssLR;

		// set the total ess L
		this.onlyEssL = onlyEssL;

		// set the total time in right
		this.timeInRight = timeInRight;
	}

	/**
	 * Instantiates a new min time right.
	 */
	public MinTimeRight() {
		super();
	}

	/**
	 * Gets the total ess LR.
	 *
	 * @return the total ess LR
	 */
	public double getTotalEssLR() {
		return this.totalEssLR;
	}

	/**
	 * Sets the total ess LR.
	 *
	 * @param totalEssLR the new total ess LR
	 */
	public void setTotalEssLR(double totalEssLR) {
		this.totalEssLR = totalEssLR;
	}

	/**
	 * Gets the only ess L.
	 *
	 * @return the only ess L
	 */
	public double getOnlyEssL() {
		return this.onlyEssL;
	}

	/**
	 * Sets the only ess L.
	 *
	 * @param onlyEssL the new only ess L
	 */
	public void setOnlyEssL(double onlyEssL) {
		this.onlyEssL = onlyEssL;
	}

	/**
	 * Gets the time in right.
	 *
	 * @return the time in right
	 */
	public double getTimeInRight() {
		return this.timeInRight;
	}

	/**
	 * Sets the time in right.
	 *
	 * @param timeInRight the new time in right
	 */
	public void setTimeInRight(double timeInRight) {
		this.timeInRight = timeInRight;
	}

	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "[totalEssLR=" + this.totalEssLR + ", onlyEssL=" + this.onlyEssL + ", timeInRight=" + this.timeInRight
				+ "]";
	}

}
