/**
*
* MODULE FILE NAME: PdhtManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.DownloadLogic;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SectorAndVisForPartner;
import com.nais.spla.brm.library.main.ontology.resourceData.SizeOfSectorDwl;
//import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
//import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.PsPolarization;

// TODO: Auto-generated Javadoc
/**
 * The Class PdhtManagement.
 *
 * @author fpedrola
 */
public class PdhtManagement {

	/** The queries. */
	DroolsQueries queries = new DroolsQueries();

	/** The bic utils. */
	BicUtils bicUtils = new BicUtils();

	/**
	 * Creates the new storage.
	 *
	 * @param acq          the acq
	 * @param droolsParams the drools params
	 * @return the storage
	 */
	public Storage createNewStorage(Acquisition acq, DroolsParameters droolsParams) {
		// variable to check if the size is valid
		boolean validSize = false;

		// initialize a storage
		Storage sto = null;

		// check if the size of the acquisition given as input is valid
		validSize = checkIfSizeIsValid(acq);

		// if is valid
		if (validSize) {
			// compute the number of sectors as double for both polarizations
			Double sectorsH = java.lang.Math.ceil(acq.getSizeH());
			Double sectorsV = java.lang.Math.ceil(acq.getSizeV());

			// convert in int
			int numberOfSectorsH = sectorsH.intValue();
			int numberOfSectorsV = sectorsV.intValue();

			// create a new storage
			sto = new Storage(acq.getId(), numberOfSectorsV, numberOfSectorsH, acq.getStartTime(), acq.getEndTime(),
					acq.getPolarization());

			Calendar cal = Calendar.getInstance();
			System.out.println(DroolsUtils.getDateInMilliseconds(acq.getStartTime()));

			cal.setTime(DroolsUtils.getDateInMilliseconds(acq.getStartTime()));
			cal.add(Calendar.MILLISECOND, -droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
					.getMinimumTimeBetweenStorageAndAcq());
			System.out.println(DroolsUtils.getDateInMilliseconds(cal.getTime()));
			System.out.println(droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
					.getMinimumTimeBetweenStorageAndAcq());

			sto.setStartTime(DroolsUtils.getDateInMilliseconds(cal.getTime()));
			// set the satellite id
			sto.setSatelliteId(acq.getSatelliteId());

			// set the linked acquisition id
			sto.setRelatedAcqId(acq.getId());

			// set the ugs id
			sto.setUgsId(acq.getUserInfo().get(0).getUgsId());

			// set the polarization
			sto.setPol(acq.getPolarization());

			// if the acquisition is a di2s
			if (acq.getDi2sInfo() != null) {
				// linked the equivalent dto to the storage
				sto.setReferredEquivalentDto(acq.getReferredEquivalentDto());

				// add the di2s info
				sto.setDi2sInfo(acq.getDi2sInfo());
			}
		}
		return sto;
	}

	/**
	 * Check if size of an acquisition is valid.
	 *
	 * @param acq the acq
	 * @return true, if the size is correctly setted
	 */
	public boolean checkIfSizeIsValid(Acquisition acq) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		String polarization = acq.getPolarization().toString();
		polarization = polarization.replaceAll("_", "");

		// set as default that the size is valid
		boolean validSize = true;

		// if both sizes are empty
		if ((acq.getSizeH() == 0) && (acq.getSizeV() == 0)) {
			// invalid size
			validSize = false;
			logger.error("invalid size : " + acq);

			logger.error("invalid size of acq : both H and V are equal to zero.");
		}
		// if at least a size is populated
		else {
			// if is a double polarization
			if (polarization.contains("HV") || polarization.contains("VH")) {
				// if one of the polarization are at zero
				if (((acq.getSizeH() == 0) && (acq.getSizeV() > 0))
						|| ((acq.getSizeH() > 0) && (acq.getSizeV() == 0))) {
					// invalid size
					validSize = false;
					logger.error("invalid size of acq : with dual pol one of the size (h or v) are equal to zero.");
				}
			}
			// if is an H polarization
			else if (polarization.contains("HH")) {
				// if the size V is not zero
				if (acq.getSizeV() > 0) {
					// invalid size
					validSize = false;
					logger.error("invalid size of acq :with single pol HH there is a not empty size V");
				}
				// if the size H is zero
				if (acq.getSizeH() == 0) {
					// invalid size
					validSize = false;
					logger.error("invalid size of acq :with single pol HH there is a empty size H");
				}
			}
			// if is a V polarization
			else {
				// if the size V is zero
				if (acq.getSizeV() == 0) {
					// invalid size
					validSize = false;
					logger.error("invalid size of acq :with single pol VV there is a empty size V");
				}
				// if the size H is not zero
				if (acq.getSizeH() > 0) {
					// invalid size
					validSize = false;
					logger.error("invalid size of acq :with single pol VV there is a not empty size H");
				}
			}
		}
		// return the boolean
		return validSize;
	}

	/**
	 * Restore priority queue.
	 *
	 * @param downloadPriority the download priority
	 */

	public void restorePriorityQueue(TreeMap<String, PriorityQueue> downloadPriority) {
		boolean notEmptyDwlPriority = ((downloadPriority != null) && !downloadPriority.isEmpty());
		// if there are elements inside the treemap
		if (notEmptyDwlPriority) {
			// iterate over these elements extracting
			// the map of priority queue
			for (Map.Entry<String, PriorityQueue> elementsinDwlPriority : downloadPriority.entrySet()) {
				// for every element inside the map
				for (Map.Entry<String, SectorAndVisForPartner> sectorsForPartner : elementsinDwlPriority.getValue()
						.getSectorsNeededForPartners().entrySet()) {
					// get the residual sector for the current partner
					for (int i = 0; i < sectorsForPartner.getValue().getSectorsForPartner().size(); i++) {
						// restore residual size with the total size
						sectorsForPartner.getValue().getSectorsForPartner().get(i).setResidualSize(
								sectorsForPartner.getValue().getSectorsForPartner().get(i).getTotalSize());
					}
				}
			}
		}
	}

	/**
	 * Insert in priority queue.
	 *
	 * @param acqToCheck       the acq to check
	 * @param stoRelatedToAcq  the sto related to acq
	 * @param downloadPriority the download priority
	 * @param droolsParams     the drools params
	 * @return the priority queue
	 */
	public PriorityQueue insertInPriorityQueue(Acquisition acqToCheck, Storage stoRelatedToAcq,
			TreeMap<String, PriorityQueue> downloadPriority, DroolsParameters droolsParams) {
		DownloadManagement dwlMng = new DownloadManagement();
		Logger logger = DroolsParameters.getLogger();
		logger.debug("try to insert into priority map");
		PriorityQueue newElement = new PriorityQueue();
		newElement = createNewPriorityQueueElement(acqToCheck, droolsParams, stoRelatedToAcq);

		String downloadKey = dwlMng.getPriorityKey(acqToCheck);

		newElement.setPriority(downloadKey);

		logger.debug("INSERTED acq " + acqToCheck.getIdTask() + " into priority map with id " + downloadKey);

		// insert into download priority
		downloadPriority.put(downloadKey, newElement);

		return newElement;
	}

	/**
	 * Creates the new priority queue element.
	 *
	 * @param acqToCheck the acq to check
	 * @param droolsParams the drools params
	 * @param stoRelatedToAcq the sto related to acq
	 * @return the priority queue
	 */
	public PriorityQueue createNewPriorityQueueElement(Acquisition acqToCheck, DroolsParameters droolsParams,
			Storage stoRelatedToAcq) {
		DownloadManagement dwlMng = new DownloadManagement();

		PriorityQueue newElement = new PriorityQueue();

		try {
			String priorityKey = dwlMng.getPriorityKey(acqToCheck);
			newElement.setPriority(priorityKey);

			// link the priority element with the acq
			newElement.setRelatedAcq(acqToCheck);

			// set the polarization
			newElement.setPol(acqToCheck.getPolarization());

			/*
			 * if the acquisition is a DI2s
			 */
			if (acqToCheck.getDi2sInfo() != null) {
				String slaveId = acqToCheck.getDi2sInfo().getPartnerId();

				Partner partner = this.bicUtils.findPartnerInList(slaveId, droolsParams.getAllPartners());

				acqToCheck.addSlave(partner);
				// get the equivalent dto
			}

			// create an hashmap for the secgtors need for every partner
			HashMap<String, SectorAndVisForPartner> partnersNeedsSecorts = new HashMap<>();

			// iterate over the user info linked with the acquisition
			for (int i = 0; i < acqToCheck.getUserInfo().size(); i++) {
				// extract gthe partner id
				String partnerId = acqToCheck.getUserInfo().get(i).getOwnerId();
				List<SizeOfSectorDwl> sectorsToDwl = computeSizeOfSectors(acqToCheck, stoRelatedToAcq);

				SectorAndVisForPartner sectors = new SectorAndVisForPartner(
						acqToCheck.getUserInfo().get(i).getAcquisitionStationIdList(), sectorsToDwl);
				partnersNeedsSecorts.put(partnerId, sectors);
			}

			// set the sectors for each partner
			newElement.setSectorsNeededForPartners(partnersNeedsSecorts);

			// logger.debug(" new element in priority : " +
			// newElement.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newElement;
	}

	/**
	 * Compute size of sectors.
	 *
	 * @param acqToCheck the acq to check
	 * @param stoRelatedToAcq the sto related to acq
	 * @return the list
	 */
	private List<SizeOfSectorDwl> computeSizeOfSectors(Acquisition acqToCheck, Storage stoRelatedToAcq) {
		List<SizeOfSectorDwl> sectorsDwl = new ArrayList<>();

		String polarization = acqToCheck.getPolarization().toString();
		polarization = polarization.replaceAll("_", "");

		// if is a double polarization HV
		if (polarization.contains("HV")) {
			// create an object of SizeOfSectorDwl for H
			SizeOfSectorDwl sizeRelatedToPartnerH = new SizeOfSectorDwl(stoRelatedToAcq.getPacketStoreSizeH(),
					stoRelatedToAcq.getPacketStoreSizeH(), Polarization.HH);

			// create an object of SizeOfSectorDwl for V
			SizeOfSectorDwl sizeRelatedToPartnerV = new SizeOfSectorDwl(stoRelatedToAcq.getPacketStoreSizeV(),
					stoRelatedToAcq.getPacketStoreSizeV(), Polarization.VV);

			sectorsDwl.add(sizeRelatedToPartnerH);
			sectorsDwl.add(sizeRelatedToPartnerV);

		}
		// if is a double polarization VH
		else if (polarization.contains("VH")) {
			// create an object of SizeOfSectorDwl for H
			SizeOfSectorDwl sizeRelatedToPartnerV = new SizeOfSectorDwl(stoRelatedToAcq.getPacketStoreSizeV(),
					stoRelatedToAcq.getPacketStoreSizeV(), Polarization.VV);

			// create an object of SizeOfSectorDwl for V
			SizeOfSectorDwl sizeRelatedToPartnerH = new SizeOfSectorDwl(stoRelatedToAcq.getPacketStoreSizeH(),
					stoRelatedToAcq.getPacketStoreSizeH(), Polarization.HH);
			sectorsDwl.add(sizeRelatedToPartnerV);
			sectorsDwl.add(sizeRelatedToPartnerH);
		}
		// if is a single polarization HH
		else if (polarization.contains("HH") || polarization.contains("H")) {

			SizeOfSectorDwl sizeRelatedToPartnerH = new SizeOfSectorDwl(stoRelatedToAcq.getPacketStoreSizeH(),
					stoRelatedToAcq.getPacketStoreSizeH(), Polarization.HH);
			sectorsDwl.add(sizeRelatedToPartnerH);
		}

		// if is a single polarization VV
		else if (polarization.contains("VV") || polarization.contains("V")) {

			// create an object of SizeOfSectorDwl for V
			SizeOfSectorDwl sizeRelatedToPartnerV = new SizeOfSectorDwl(stoRelatedToAcq.getPacketStoreSizeV(),
					stoRelatedToAcq.getPacketStoreSizeV(), Polarization.VV);
			sectorsDwl.add(sizeRelatedToPartnerV);

		}

		return sectorsDwl;
	}

	/**
	 * Check pdht overload.
	 *
	 * @param allStoAndDwlToUpdate the all sto and dwl to update
	 * @param localPdhtFunction    the local pdht function
	 * @param droolsParams         the drools params
	 * @param allProcessedSto the all processed sto
	 * @return true, if successful
	 */
	public long checkPdhtOverload(List<Task> allStoAndDwlToUpdate, TreeMap<Long, ComplexPdht> localPdhtFunction,
			DroolsParameters droolsParams, TreeMap<String, Storage> allProcessedSto) {
		// extract the logger
		Logger logger = DroolsParameters.getLogger();

		// create a return variable and set it with the value -1 as default
		long returnedPdhtOverhead = -1;

		// sort element by start time
		DownloadUtils.sortTasksByStartTime(allStoAndDwlToUpdate);

		// iterate over the ordered elements
		for (int i = 0; i < allStoAndDwlToUpdate.size(); i++) {
			// extract the i-esim element
			Task currentTask = allStoAndDwlToUpdate.get(i);

			// if the task is a storage
			if (currentTask instanceof Storage) {

				// convert the task in a storage
				Storage currentSto = (Storage) currentTask;
				// logger.debug("found a storage :" +
				// currentSto.getIdTask());
				boolean possibleToStoreInPdht = true;
				if (!currentSto.isPreviousMh()) {
					// try to insert the storage in the PDHT
					possibleToStoreInPdht = insertStoInPDHT(localPdhtFunction, currentSto);

					// the storage fails because there isn't enough space in
					// PDHT
					if (!possibleToStoreInPdht) {
						// set as time of overhead the start time of the
						// task
						// that
						// caused the fail
						returnedPdhtOverhead = currentTask.getStartTime().getTime();
						logger.debug("this storage overload the pdht -> rejection");
						break;
					}
					// no detected overhead pdht -> continue
					// else
					// {
					// logger.debug("this storage is correctly inserted into
					// the pdht ->
					// "+localPdhtFunction.get(currentSto.getStartTime().getTime()));
					// }
				}

			}

			// if the task is a download
			else if (currentTask instanceof Download) {

				// convert the task in a download
				Download currentDwl = (Download) currentTask;
				// logger.debug("found a download :" +
				// currentDwl.getIdTask() +
				// " prevProc : "+ currentDwl.isPreviouslyProcessed());

				// if the download is a delete type
				if (currentDwl.getPacketStoreStrategy().compareTo(DownlinkStrategy.DELETE) == 0) {

					// get the associated storage
					Storage relatedSto = this.queries.getStoWithGivenid(allProcessedSto, currentDwl.getRelatedTask());

					// set the information relative to the memory module
					// used by
					// the storage
					Map<MemoryModule, Long> plannedOnMemMod = new HashMap<>();

					// iterate over the packet stores associated
					for (int j = 0; j < relatedSto.getPacketsAssociated().size(); j++) {
						// if the i-esim packet store is relevant to the
						// current
						// polarization of the dwl
						if (relatedSto.getPacketsAssociated().get(j).getPolarization().equals(currentDwl.getPol())) {
							// get the memory modules of this packet store
							plannedOnMemMod = relatedSto.getPacketsAssociated().get(j).getPlannedOnMemModule();
						}
					}

					// associate the list of memory modules used to the
					// download
					currentDwl.setPlannedOnMemModule(plannedOnMemMod);

					// reincrement the pdht of the amount used for the
					// storage
					// and free the memory modules associated
					restoreAmountToPdht(currentDwl, localPdhtFunction, currentDwl.getPlannedOnMemModule());
				}
			}
		}
		return returnedPdhtOverhead;
	}

	/**
	 * Restore amount to pdht.
	 *
	 * @param currentDwl        the current dwl
	 * @param localPdhtFunction the local pdht function
	 * @param plannedOnMem      the planned on mem
	 */
	public void restoreAmountToPdht(Download currentDwl, TreeMap<Long, ComplexPdht> localPdhtFunction,
			Map<MemoryModule, Long> plannedOnMem) {
		// create an empty object of pdht
		PDHT pdhtAfterRestore = null;

		// if the download is not previously processeed (of previous mission
		// horizon)
		if (!currentDwl.isPreviousMh()) {
			// get the previous instance
			pdhtAfterRestore = (PDHT) DroolsUtils
					.deepClone(localPdhtFunction.floorEntry(currentDwl.getStartTime().getTime()).getValue().getPdht());
			// logger.debug("prev PDHT time "+new
			// Date(localPdhtFunction.floorEntry(currentDwl.getStartTime().getTime()).getKey()));
			//
			// logger.debug("prev PDHT "+pdhtAfterRestore);
			// iterate over the memory modules
			for (int i = 0; i < pdhtAfterRestore.getMMList().size(); i++) {
				// iterate over the memory modules used for the current download
				for (Map.Entry<MemoryModule, Long> sectorsOnModules : plannedOnMem.entrySet()) {
					// if there is a match between memory modules
					if (pdhtAfterRestore.getMMList().get(i).getId()
							.equalsIgnoreCase(sectorsOnModules.getKey().getId())) {
						// restore the free sectors
						pdhtAfterRestore.getMMList().get(i).setFreeSectors(
								pdhtAfterRestore.getMMList().get(i).getFreeSectors() + sectorsOnModules.getValue());
					}
				}
			}
			// insert the updated pdht into the pdht function
			localPdhtFunction.put(currentDwl.getStartTime().getTime(), new ComplexPdht(pdhtAfterRestore));
			//
			// logger.debug("updated pdht "+pdhtAfterRestore);
		}
	}

	/**
	 * Insert sto in PDHT.
	 *
	 * @param PDHTFunction       the PDHT function
	 * @param sto                the sto
	 * @return the list
	 */
	public boolean insertStoInPDHT(TreeMap<Long, ComplexPdht> PDHTFunction, Storage sto) {
		Logger logger = DroolsParameters.getLogger();

		// get the previous state
		PDHT prevPdht = PDHTFunction.floorEntry(sto.getStartTime().getTime()).getValue().getPdht();
		// logger.debug("prev pdht at Time :"+new
		// Date(PDHTFunction.floorEntry(sto.getStartTime().getTime()).getKey()));
		//
		// logger.debug("prev pdht :"+prevPdht);
		// initialize the boolean variable to check the correct store on pdht to
		// false
		boolean storedOnPdht = false;
		int residualSector = 0;

		// clone the previous instance of pdht
		PDHT previousAtPrevTime = (PDHT) DroolsUtils.deepClone(prevPdht);

		// create an empty list of packet store
		List<PacketStore> packetsAssociated = new ArrayList<>();

		// create an empty list of memory module
		ArrayList<MemoryModule> allModules = new ArrayList<>();

		// get the polarization
		Polarization[] pol = populatePolarization(sto.getPol());

		// create an array of fillFactors
		Double[] fillFactors = { (1.0 / 3.0), (2.0 / 3.0), 1.0 };

		// logger.debug("previous pdht : " + previousAtPrevTime);
		// insert in the list of memory modules all the memory modules related
		// to the previous state of pdht
		allModules.addAll(previousAtPrevTime.getMMList());

		// order memory modules by residual size
		sortMemoryModules(allModules);

		// create an empty list of memory modules capacity
		Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<>();

		// iterate over the fill factors
		for (int i = 0; i < fillFactors.length; i++) {
			// initialize residual sector
			residualSector = 0;

			// if the first polarization is HH
			if (pol[0] == Polarization.HH) {
				// set the residual sector with the size of sector H
				residualSector = sto.getPacketStoreSizeH();
			}

			// if the first polarization is VV
			else {
				// set the residual sector with the size of sector V
				residualSector = sto.getPacketStoreSizeV();
			}

			// logger.debug("residual sector : " + residualSector);

			// clear the memory modules
			modulesCapacity.clear();

			// iterate over all the memory modules
			for (int j = 0; j < allModules.size(); j++) {
				// set the i-esim memory module as unused
				allModules.get(j).setInUse(false);
			}

			// try to allocate the storage on memory modules
			boolean possible = useMemoryModules(sto, modulesCapacity, fillFactors[i], allModules, residualSector,
					pol[0]);

			// if is possible for the first polarization and there is also a
			// second polarization (double)
			if (possible && (pol.length == 2)) {
				// if the second polarization is HH
				if (pol[1] == Polarization.HH) {
					// set the residual sectors for H
					residualSector = sto.getPacketStoreSizeH();
				}
				// if the second polarization is VV
				else {
					// set the residual sectors for V
					residualSector = sto.getPacketStoreSizeV();
				}

				// try to allocate the storage on memory modules
				possible = useMemoryModules(sto, modulesCapacity, fillFactors[i], allModules, residualSector, pol[1]);
			}
			// if the memory modules are correctly decremented
			if (possible) {
				// create associated packet stores
				packetsAssociated = checkAndCreatePS(PDHTFunction, allModules, sto, modulesCapacity);
				break;
			}
			// if is impossible
			else {
				// use next fill factor
				continue;
			}
		}

		// if there aren't valid packets stores associated
		boolean notValidPackets = ((packetsAssociated == null) || packetsAssociated.isEmpty());

		// if there aren't valid packets stores associated
		if (notValidPackets) {
			// set the boolean variable to false
			storedOnPdht = false;
			logger.debug("impossible to create storage");

		}
		// if the packets are valid
		else {
			// set the packets associated with the ones just created
			sto.setPacketsAssociated(packetsAssociated);
			// logger.debug("creating new Storage : " + sto);
			// set the boolean variable to true
			storedOnPdht = true;
		}
		return storedOnPdht;
	}

	/**
	 * Use memory modules.
	 *
	 * @param sto             the sto
	 * @param modulesCapacity the modules capacity
	 * @param fillFactor      the fill factor
	 * @param allModules      the all modules
	 * @param residualSector  the residual sector
	 * @param pol             the pol
	 * @return true, if successful
	 */
	private boolean useMemoryModules(Storage sto, Map<MemoryModule, PsPolarization> modulesCapacity, double fillFactor,
			List<MemoryModule> allModules, int residualSector, Polarization pol) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		logger.trace("TRY TO ALLOCATE MEMORY MODULE FOR POLARIZATION : " + pol);
		// logger.debug("try with fill factor " + fillFactor);

		// initialize the boolean variable to check if the memory module is
		// available to false
		boolean available = false;

		// order memory modules by residual size (from empties to fullest)
		sortMemoryModules(allModules);

		// iterate over the memory modules
		for (int j = 0; j < allModules.size(); j++) {
			// extract the i-esim memory module
			MemoryModule currentModule = allModules.get(j);
			logger.trace("emptiest memory module :" + currentModule);

			// the memory module is not used and has residual sector
			if (!currentModule.isInUse() && (currentModule.getFreeSectors() > 0)) {
				// mark as in use
				currentModule.setInUse(true);

				// compute the number of usable sectors
				int usableSectors = (int) Math.floor(currentModule.getFreeSectors() * fillFactor/* fillFactors[i] */);

				// if the usable sectors are more or equals than the residual
				// sector of storage -> residual on single memory module
				if (usableSectors >= residualSector) {
					// create a new PsPolarization
					PsPolarization psPol = new PsPolarization(residualSector, pol);

					// insert the current module into the map of used modules
					modulesCapacity.put(currentModule, psPol);

					// decrement the residual sector
					residualSector = 0;

					// exit
					break;
				}
				// if the usable sectors are less than the residual sector of
				// storage -> residual on more than one memory module
				else {
					// create a new PsPolarization
					PsPolarization psPol = new PsPolarization(usableSectors, pol);

					// insert the current module into the map of used modules
					modulesCapacity.put(currentModule, psPol);

					// decrement the residual sector of the size of usable
					// sectors
					residualSector = residualSector - usableSectors;
				}
			}
		}
		// if there aren't residual sectors
		if (residualSector == 0) {
			// mark the boolean variable to true
			available = true;
		}
		return available;
	}

	/**
	 * Check and create PS.
	 *
	 * @param PDHTFunction    the PDHT function
	 * @param allModules      the all modules
	 * @param sto             the sto
	 * @param modulesCapacity the modules capacity
	 * @return the list
	 */
	public List<PacketStore> checkAndCreatePS(TreeMap<Long, ComplexPdht> PDHTFunction, List<MemoryModule> allModules,
			Storage sto, Map<MemoryModule, PsPolarization> modulesCapacity) {
		// get the previous pdht function
		PDHT previousPDHT = PDHTFunction.floorEntry(sto.getStartTime().getTime()).getValue().getPdht();

		// create an empty list of packet stores
		List<PacketStore> packetsAssociatedToSto = new ArrayList<>();

		// create an empty list of memory modules
		List<MemoryModule> allMemoryModulesName = new ArrayList<>();

		// iterate over the memory module list of the previous pdht
		for (int i = 0; i < previousPDHT.getMMList().size(); i++) {
			// add the i-esim memory module to the empty list of memory module
			allMemoryModulesName.add(previousPDHT.getMMList().get(i));
		}

		// invoke the function to create packet store
		packetsAssociatedToSto = createPS_and_decrement_memoryModules(sto, modulesCapacity, allMemoryModulesName);

		// if there are packet stores returned by the function
		if (packetsAssociatedToSto != null) {
			// effective decrement the packet stores
			computeDecrementOnMemoryModules(sto, packetsAssociatedToSto, PDHTFunction, allModules, modulesCapacity,
					previousPDHT);
		}

		return packetsAssociatedToSto;
	}

	/**
	 * Compute decrement on memory modules.
	 *
	 * @param sto             the sto
	 * @param allPacketStores the all packet stores
	 * @param PDHTFunction    the PDHT function
	 * @param allModules      the all modules
	 * @param modulesCapacity the modules capacity
	 * @param previousPDHT    the previous PDHT
	 */
	public void computeDecrementOnMemoryModules(Storage sto, List<PacketStore> allPacketStores,
			TreeMap<Long, ComplexPdht> PDHTFunction, List<MemoryModule> allModules,
			Map<MemoryModule, PsPolarization> modulesCapacity, PDHT previousPDHT) {
		// create an empty list of memory modules
		ArrayList<MemoryModule> updatedMemoryModules = new ArrayList<>();

		// iterate over the memory modules given in input
		for (int i = 0; i < allModules.size(); i++) {
			// initialize the variable to check if the memory module is inside
			// the map of memory modules decremented for download to false
			boolean isInMap = false;

			// extract the i-esim memory module
			MemoryModule mem = allModules.get(i);

			// iterate over the map of memory modules used for the download
			for (Map.Entry<MemoryModule, PsPolarization> entry : modulesCapacity.entrySet()) {
				// extract the j-esim memory module
				MemoryModule extracted = entry.getKey();

				// if there is a match between memory modules
				if (mem.getId().equals(extracted.getId())) {
					// insert into the list with the decremented value
					updatedMemoryModules.add(extracted);

					// mark the boolean variable to true
					isInMap = true;
				}
			}
			// if the j-esim memory module wasn't used for the download
			if (isInMap == false) {
				// insert into the list with the not decremented value
				updatedMemoryModules.add(mem);
			}
		}
		// create a new instance of PDHT
		PDHT updatedPDHT = new PDHT();

		// make a clone of the previous state of PDHT
		updatedPDHT = (PDHT) DroolsUtils.deepClone(previousPDHT);

		// set the memory modules list with thelist just computed
		updatedPDHT.setMMList(updatedMemoryModules);

		// insert into PDHT treeMap
		PDHTFunction.put(sto.getStartTime().getTime(), new ComplexPdht(updatedPDHT));
	}

	/**
	 * Creates the P S and decrement memory modules.
	 *
	 * @param sto               the sto
	 * @param modulesCapacity   the modules capacity
	 * @param memoryModulesName the memory modules name
	 * @return the list
	 */
	public List<PacketStore> createPS_and_decrement_memoryModules(Storage sto,
			Map<MemoryModule, PsPolarization> modulesCapacity, List<MemoryModule> memoryModulesName) {
		// get the polarization relative to the packet store as array
		Polarization[] allPolarizations = populatePolarization(sto.getPol());

		// create an empty list of packets associated with the storage
		List<PacketStore> packetsAssociatedToSto = new ArrayList<>();

		// initialize the cont for packet stores (at least 1 ps for storages
		// (single pol), max 2 (double pol)
		long contPs1 = 0;
		long contPs2 = 0;

		// initialize the packet stores (worst case, 2 packet stores
		PacketStore packet1 = new PacketStore(sto.getIdTask());
		PacketStore packet2 = new PacketStore(sto.getIdTask());

		// iterate over the memory modules used for the storage
		for (Map.Entry<MemoryModule, PsPolarization> entry : modulesCapacity.entrySet()) {
			// extract the i-esim memory module
			MemoryModule mem = entry.getKey();

			// extract the polarization
			Polarization pol = entry.getValue().getPol();

			// update the sectors planned
			long sectorsPlanned = entry.getValue().getSectorUsedForPs();

			// compute the new capacity of memory module with the decrement of
			// the sectors used for the storage
			long newCapacity = mem.getFreeSectors() - sectorsPlanned;

			// mark the memory module as in use
			mem.setInUse(true);

			// update the free sectors of memory module with the new capacity
			mem.setFreeSectors(newCapacity);

			// if the polarization is HH
			if (pol.equals(Polarization.HH)) {
				// increment the cont of sectors used for polarization H with
				// the amount used with the current memory module
				contPs1 = contPs1 + sectorsPlanned;

				// add the current memory module to the packet store reserved
				// for polarization H
				packet1.addMemoryModuleToPS(mem, sectorsPlanned);

				// set the polarization
				packet1.setPolarization(pol);

				// if it's all done for the polarization H (cont == number of
				// sectors H)
				if (contPs1 == sto.getNumberOfSectors(pol)) {

					// set the used sectors
					packet1.setUsedSectors(sto.getNumberOfSectors(pol));

					// reset the residual sectors
					packet1.setResidualSectors(0);

					// add the packet store at the storage
					packetsAssociatedToSto.add(packet1);
				}
			}
			// if the polarization is VV
			else if (pol.equals(Polarization.VV)) {
				// increment the cont of sectors used for polarization V with
				// the amount used with the current memory module
				contPs2 = contPs2 + sectorsPlanned;

				// add the current memory module to the packet store reserved
				// for polarization V
				packet2.addMemoryModuleToPS(mem, sectorsPlanned);

				// set the polarization
				packet2.setPolarization(pol);

				// if it's all done for the polarization V (cont == number of
				// sectors V)
				if (contPs2 == sto.getNumberOfSectors(pol)) {

					// set the used sectors
					packet2.setUsedSectors(sto.getNumberOfSectors(pol));

					// reset the residual sectors
					packet2.setResidualSectors(0);

					// add the packet store at the storage
					packetsAssociatedToSto.add(packet2);
				}
			}

		}

		// if the storage is in single polarization
		if (allPolarizations.length == 1) {
			if (packet1.getPolarization() != null) {
				// add also the first packet
				completePacketStoreWithOthersMM(packet1, memoryModulesName);
			}
			if (packet2.getPolarization() != null) {
				// add also the first packet
				completePacketStoreWithOthersMM(packet2, memoryModulesName);
			}
		}

		// if the storage is in dual polarization
		else {
			// add both packets
			completePacketStoreWithOthersMM(packet1, memoryModulesName);
			completePacketStoreWithOthersMM(packet2, memoryModulesName);
		}
		return packetsAssociatedToSto;
	}

	/**
	 * Update pdht till end.
	 *
	 * @param currentSession the current session
	 * @param currentInstance the current instance
	 * @param currentAcq the current acq
	 * @param cancelFrom the cancel from
	 * @param droolsParams the drools params
	 * @param satId the sat id
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public boolean updatePdhtTillEnd(String currentSession, int currentInstance, Acquisition currentAcq,
			Date cancelFrom, DroolsParameters droolsParams, String satId) throws Exception {
		// concatenate the current session instance
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// boolean variable used to detect if there is a overload of pdht
		boolean insertedInPdht = true;

		boolean prevProcessedAcqInsertedInQueue = true;
		// extract the logger
		Logger logger = DroolsParameters.getLogger();
		try {

			logger.info("-------------method update pdht--------------");
			logger.info("for acq : " + currentAcq.getIdTask() + " is prev proc : " + currentAcq.isPreviousMh());

			// create an empty instance for the storage associated to the
			// acquisition
			Storage stoRelatedToAcq = null;

			// create an instance of DownloadManagement
			DownloadManagement dwlMng = new DownloadManagement();

			// extract the current kieSession
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

			// get the resourceFunctions with all the resources used for the
			// accepted elements
			ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
			//// System.out.println(kieSession.getGlobal("rejected"));

			TreeMap<Long, EnergyAssociatedToTask> hashMapEss = resFunc.getEssFunctionAssociatedToSat(satId);
			// create an empty pdhtFunction
			TreeMap<Long, ComplexPdht> localPdhtFunction = new TreeMap<>();

			// create an empty priorityQueue function
			TreeMap<String, PriorityQueue> downloadPriority = null;
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = resFunc
					.getDownloadsAssociatedToSat(satId);
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMapBeforeInsert = null;

			// extract all the processed storages
			TreeMap<String, Storage> allProcessedSto = resFunc.getStoragesAssociatedToSat(satId);

			TreeMap<String, Download> allDwls = dwlMng.getAllFromTreeMap(satId, droolsParams, downloadTreeMap,
					DownloadLogic.DWL);

			satId = currentAcq.getSatelliteId();

			// make a deepClone of the pdht function
			localPdhtFunction = resFunc.getPDHTFunctionAssociatedToSat(satId);
			TreeMap<Long, ComplexPdht> localPdhtFunctionBackup = (TreeMap<Long, ComplexPdht>) DroolsUtils
					.deepClone(localPdhtFunction);

			// make a deepClone of the download priority structure
			downloadPriority = resFunc.getDownloadPriorityQueueForSat(satId);

			// get all the downloads before the insert of the new element
			downloadTreeMapBeforeInsert = resFunc.getDownloadsAssociatedToSat(satId);

			// make a deepClone of the list of downloads
			downloadTreeMap = (TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>) DroolsUtils
					.deepClone(downloadTreeMapBeforeInsert);

			// if the current Acq is in init plan (inserted in previous session)
			if (currentAcq.isPreviousMh()) {
				DroolsQueries dq = new DroolsQueries();

				// get the storage previously inserted relative to the current
				// acq
				stoRelatedToAcq = dq.getStoWithGivenid(allProcessedSto, currentAcq.getId());

				logger.trace("associated sto  : " + stoRelatedToAcq);

				// get the downloads relative to the storage, if they exist
				List<Download> relatedDwl = dq.getAllDwlRelatedToSto(droolsParams, stoRelatedToAcq.getIdTask(),
						allDwls);

				// check if are needed others downloads for the current session
				prevProcessedAcqInsertedInQueue = dwlMng.initPlanDownload(currentAcq, stoRelatedToAcq, relatedDwl,
						droolsParams, downloadPriority);
			} else
			// if this is the first time that the current acq is inserted
			{
				// create a new storage associated with the acq to check
				stoRelatedToAcq = createNewStorage(currentAcq, droolsParams);

				logger.trace("try to insert the storage in the pdht");

				if (stoRelatedToAcq != null) {
					// check if it's possible to insert the storage inside the
					// pdht
					insertedInPdht = insertStoInPDHT(localPdhtFunction, stoRelatedToAcq);
				}

			}

			// if the insert had a failure
			if (!insertedInPdht) {
				// pdht saturated at time of the new inserted storage, related
				// acq
				// is rejected
				logger.info("the pdht is overloaded at time of the insert this new acquisition -> rejected ");

				// collect all the elements involved from the start of mission
				// horizon till the start time of current acq
				List<String> elementsInvolved = new ArrayList<>();

				// get a subMap of the elements involved
				NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = hashMapEss.subMap(
						droolsParams.getCurrentMH().getStart().getTime(), true, currentAcq.getStartTime().getTime(),
						false);

				// iterate over all this elements
				for (Map.Entry<Long, EnergyAssociatedToTask> elements : allAcqIdInInternal.entrySet()) {
					// extract the i-esim acquisition
					Acquisition acq = (Acquisition) elements.getValue().getTask();

					// add it's id to the list of string of elements involved
					elementsInvolved.add(acq.getIdTask());
				}

				// mark the current acq as rejected
				currentAcq.setRejected(true);
				insertedInPdht = false;

				// add the reason of reject "noSpaceInPdht"
				currentAcq.addReasonOfReject(21, ReasonOfReject.noSpaceInPdht, "No Space In PDHT", 0, 0,
						elementsInvolved);

				// get the rejected elements from Drools globals
				Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) kieSession.getGlobal("rejected");

				// add the current acq to the list of rejected elements
				rejectedElements.put(currentAcq.getIdTask(), currentAcq);
				logger.info("retracting acq because there is no space in pdht");

				// retract the current acquisition
				DroolsOperations.retractSingleAcq(droolsParams, currentAcq.getIdTask(), currentSession, currentInstance,
						null);
			} else {
				if (currentAcq.isPreviousSession()) {
					logger.info("inserted acq that was in a PREVIOUS Session");

					insertInPriorityQueue(currentAcq, stoRelatedToAcq, downloadPriority, droolsParams);

					TreeMap<String, Storage> allStorages = resFunc
							.getStoragesAssociatedToSat(currentAcq.getSatelliteId());

					allStorages.put(currentAcq.getIdTask(), stoRelatedToAcq);
				} else {
					// not pdht overloaded
					logger.info("not pdht overloaded:");

					// create an empty list of storages and downloads
					List<Task> allCreatedDwlsAndSto = new ArrayList<>();

					// if the list of storages doesn't contains current storage
					// (new
					// insert)
					if (allProcessedSto.get(stoRelatedToAcq.getIdTask()) == null) {
						// add it to the list
						allProcessedSto.put(stoRelatedToAcq.getIdTask(), stoRelatedToAcq);
					}

					// remove all downloads from visibilities
					// except PT and paw
					// exclusion ( and related dummies)
					if (prevProcessedAcqInsertedInQueue) {
						dwlMng.clearDownloadMapAndPriorityQueue(satId, droolsParams, downloadTreeMapBeforeInsert,
								resFunc, downloadPriority);
						// insert the storage into the priority queue
						insertInPriorityQueue(currentAcq, stoRelatedToAcq, downloadPriority, droolsParams);

						// insertedInPdht = replanDownloads(satId, droolsParams, downloadTreeMap,
						// resFunc,downloadPriority);
						List<Task> allCreatedDwl = dwlMng.processDownloadFromPriorityQueue(allCreatedDwlsAndSto,
								downloadPriority, droolsParams, downloadTreeMapBeforeInsert, resFunc, satId);

						for (int i = 0; i < allCreatedDwl.size(); i++) {
							System.out.println(allCreatedDwl.get(i));
						}

//                        if (allCreatedDwl.size() > 0)
//                        {
//                            // add the downloads just created to the list
//                            allCreatedDwlsAndSto.addAll(allCreatedDwl);
//                        }

						// add also all the storages
						allCreatedDwlsAndSto.addAll(allProcessedSto.values());

						allCreatedDwlsAndSto = DroolsOperations.filterTasksForMhList(allCreatedDwlsAndSto,
								droolsParams);
						// remove from pdht functions all elements till the end of the mh
						localPdhtFunction.subMap(droolsParams.getCurrentMH().getStart().getTime() + 1000, false,
								droolsParams.getCurrentMH().getStop().getTime(), true).clear();

						// check if the pdth is overloaded not for the current
						// inserted
						// storage but for next storages

						//// System.out.println("check for pdht overload at next
						//// time");
						long overloadAtTime = checkPdhtOverload(allCreatedDwlsAndSto, localPdhtFunction, droolsParams,
								allProcessedSto);

						// pdht overloaded -> reject last acquisition
						if (overloadAtTime > -1) {
							logger.info(
									"the pdht is overload x time later the insert of this new acquisition -> rejected ");
							// create an empty list of involved elements
							List<String> elementsInvolved = new ArrayList<>();

							// get all the acquisition involved between start
							// time of mh and the moment when the pdht is
							// overloaded
							NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal = hashMapEss.subMap(
									droolsParams.getCurrentMH().getStart().getTime(), true, overloadAtTime, true);

							// iterate over this elements
							for (Map.Entry<Long, EnergyAssociatedToTask> elements : allAcqIdInInternal.entrySet()) {
								// extract the relative acquisition
								Acquisition acq = (Acquisition) elements.getValue().getTask();

								// add it's id to the list of involved elements
								elementsInvolved.add(acq.getIdTask());
							}

							// mark the last acquisition as rejected
							currentAcq.setRejected(true);

							// add the correct reason of reject
							currentAcq.addReasonOfReject(21, ReasonOfReject.noSpaceInPdht, "No Space In PDHT", 0, 0,
									elementsInvolved);

							// get the global variable where are stored all the
							// rejected acquisitions
							Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) kieSession
									.getGlobal("rejected");

							// add the last acq (the rejected one)
							rejectedElements.put(currentAcq.getIdTask(), currentAcq);

							insertedInPdht = false;

							String stoKeyToRem = null;
							// iterate over all processed storages
							for (Map.Entry<String, Storage> allStorages : allProcessedSto.entrySet()) {
								// if the current storage is related to the acq
								// under analysis
								if (allStorages.getValue().getIdTask().equalsIgnoreCase(currentAcq.getIdTask())) {
									stoKeyToRem = allStorages.getKey();
									break;
									// remove it
								}
							}

							if (stoKeyToRem != null) {
								allProcessedSto.remove(stoKeyToRem);

							}

							logger.info("retracting acq because there is no space in pdht");

							// retract acquisition because there is no space in
							// pdht
							DroolsOperations.retractSingleAcq(droolsParams, currentAcq.getIdTask(), currentSession,
									currentInstance, null);

							// restore the map of the downloads as was before
							// the insert
							resFunc.setDownloadsAssociatedToSat(satId, downloadTreeMap);

							localPdhtFunction = (TreeMap<Long, ComplexPdht>) DroolsUtils
									.deepClone(localPdhtFunctionBackup);
						} else {
							logger.info("all done for the current session");
							// update download function with the just planned
							// downloads
							resFunc.setDownloadsAssociatedToSat(satId, downloadTreeMapBeforeInsert);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
		}

		return insertedInPdht;
	}

	/**
	 * Populate polarization.
	 *
	 * @param pol the pol
	 * @return the polarization[]
	 */
	public static Polarization[] populatePolarization(Polarization pol) {
		// create a new array of Polarizations
		Polarization[] allPolarizations;

		String polarization = pol.toString().replaceAll("_", "");
		boolean doublePolHV = polarization.startsWith("HV") || polarization.contains("HHVV")
				|| polarization.contains("HVHV");
		boolean doublePolVH = polarization.startsWith("VH") || polarization.contains("VVHH")
				|| polarization.contains("VHHV");
		boolean doublePolHH = polarization.startsWith("HHHH");
		boolean doublePolVV = polarization.startsWith("VVVV");

		boolean singlePolH = polarization.contains("H");

		// if the polarization is HV
		if (doublePolHV) {
			// initialize the array with a size of 2
			allPolarizations = new Polarization[2];

			// make the first slot as polarization H
			allPolarizations[0] = Polarization.HH;

			// make the second slot as polarization V
			allPolarizations[1] = Polarization.VV;
		}
		// if the polarization is VH
		else if (doublePolVH) {
			// initialize the array with a size of 2
			allPolarizations = new Polarization[2];

			// make the first slot as polarization V
			allPolarizations[0] = Polarization.VV;

			// make the second slot as polarization H
			allPolarizations[1] = Polarization.HH;
		} else if (doublePolHH) {
			// initialize the array with a size of 2
			allPolarizations = new Polarization[2];

			// make the first slot as polarization H
			allPolarizations[0] = Polarization.HH;

			// make the second slot as polarization H
			allPolarizations[1] = Polarization.HH;
		} else if (doublePolVV) {
			// initialize the array with a size of 2
			allPolarizations = new Polarization[2];

			// make the first slot as polarization V
			allPolarizations[0] = Polarization.VV;

			// make the second slot as polarization V
			allPolarizations[1] = Polarization.VV;
		}
		// else if the polarization is H
		else if (singlePolH) {
			// initialize the array with a size of 1
			allPolarizations = new Polarization[1];

			// make the first slot as polarization H
			allPolarizations[0] = Polarization.HH;
		}
		// else if the polarization is V
		else {
			// initialize the array with a size of 1
			allPolarizations = new Polarization[1];

			// make the first slot as polarization V
			allPolarizations[0] = Polarization.VV;
		}
		return allPolarizations;

	}

	/**
	 * Complete packet store with others MM. copying the list in input and removing
	 * all and only the memory modules used for the current storage, the residual
	 * memory modules will be the ones don't impacted by the storage
	 *
	 * @param packet            the packet
	 * @param memoryModulesName the memory modules name
	 */
	@SuppressWarnings("unchecked")
	public void completePacketStoreWithOthersMM(PacketStore packet, List<MemoryModule> memoryModulesName) {
		// create a new list based on a copy of the list of memory modules given
		// as input
		List<MemoryModule> allMemModule = (List<MemoryModule>) DroolsUtils.deepClone(memoryModulesName);

		// iterate over only the memory modules used for the storage
		for (Map.Entry<MemoryModule, Long> memModAssociated : packet.getPlannedOnMemModule().entrySet()) {
			// iterate over all the memory modules
			for (int i = 0; i < allMemModule.size(); i++) {
				// if there is a match
				if (allMemModule.get(i).getId().equalsIgnoreCase(memModAssociated.getKey().getId())) {
					// remove the memory module from the cloned list
					allMemModule.remove(i);

					// decrement the index
					i--;
				}
			}
		}

		// if there are memory modules don't used for the storage
		if (!allMemModule.isEmpty()) {
			// iterate over them
			for (int i = 0; i < allMemModule.size(); i++) {
				// add to the packet store with an amount of decrement of zero
				packet.addMemoryModuleToPS(allMemModule.get(i), 0);
			}
		}
	}

	/**
	 * Sort memory modules.
	 *
	 * @param allModules the all modules
	 */
	private void sortMemoryModules(List<MemoryModule> allModules) {
		// use the Collection.sort to compare memory modules
		Collections.sort(allModules, new Comparator<MemoryModule>() {

			@Override
			public int compare(MemoryModule mem2, MemoryModule mem1) {
				// order memory modules by freeSectors
				return (int) (mem1.getFreeSectors() - (mem2.getFreeSectors()));
			}
		});
	}

	/*
	 * public void retractForNoSpacePdht(Acquisition currentAcq, TreeMap<String,
	 * Storage> allProcessedSto, long overloadAtTime, TreeMap<Long,
	 * EnergyAssociatedToTask> hashMapEss, Map<String, Acquisition>
	 * rejectedElements, DroolsParameters droolsParams, String currentSession, int
	 * currentInstance) {
	 * 
	 * Logger logger = DroolsParameters.getLogger(); // create an empty list of
	 * involved elements List<String> elementsInvolved = new ArrayList<>();
	 * 
	 * if (droolsParams.getCurrentMH().getStart().getTime() < overloadAtTime) {
	 * NavigableMap<Long, EnergyAssociatedToTask> allAcqIdInInternal =
	 * hashMapEss.subMap(droolsParams.getCurrentMH().getStart().getTime(), true,
	 * overloadAtTime, true);
	 * 
	 * // iterate over this elements for (Map.Entry<Long, EnergyAssociatedToTask>
	 * elements : allAcqIdInInternal.entrySet()) { // extract the relative
	 * acquisition Acquisition acq = (Acquisition) elements.getValue().getTask();
	 * 
	 * // add it's id to the list of involved elements
	 * elementsInvolved.add(acq.getIdTask()); } } else {
	 * logger.debug("retractForNoSpacePdht startTime : " +
	 * droolsParams.getCurrentMH()); logger.debug("retractForNoSpacePdht endTime: "
	 * + new Date(overloadAtTime));
	 * 
	 * }
	 * 
	 * // mark the last acquisition as rejected currentAcq.setRejected(true);
	 * 
	 * // add the correct reason of reject currentAcq.addReasonOfReject(21,
	 * ReasonOfReject.noSpaceInPdht, "No Space In PDHT", 0, 0, elementsInvolved);
	 * 
	 * // add the last acq (the rejected one)
	 * rejectedElements.put(currentAcq.getIdTask(), currentAcq);
	 * 
	 * // retract acquisition because there // is no space in pdht DroolsOperations
	 * droolsOp = new DroolsOperations(); droolsOp.retractSingleAcq(droolsParams,
	 * currentAcq.getIdTask(), currentSession, currentInstance, null);
	 * 
	 * if (allProcessedSto.get(currentAcq.getIdTask()) != null) {
	 * allProcessedSto.remove(currentAcq.getIdTask()); } }
	 */

}
