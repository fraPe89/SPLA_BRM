/**
*
* MODULE FILE NAME: PDHT.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resources;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class PDHT.
 */
@SuppressWarnings("serial")
public class PDHT implements Serializable {

	/** The satellite id. */
	private String satelliteId;

	/** The free memory. */
	private long freeMemory;

	/** The MM list. */
	// private long singleCapacity;
	private List<MemoryModule> MMList;

	/** The mm1. */
	private MemoryModule MM1;

	/** The mm2. */
	private MemoryModule MM2;

	/** The mm3. */
	private MemoryModule MM3;

	/** The mm4. */
	private MemoryModule MM4;

	/** The mm5. */
	private MemoryModule MM5;

	/** The mm6. */
	private MemoryModule MM6;

	/**
	 * Instantiates a new pdht.
	 */
	public PDHT() {
		super();
	}

	/**
	 * Instantiates a new pdht.
	 *
	 * @param pdhtId          the pdht id
	 * @param pdhtName        the pdht name
	 * @param satelliteId     the satellite id
	 * @param freeMemory      the free memory
	 * @param modulesCapacity the modules capacity
	 */
	public PDHT(String pdhtId, String pdhtName, String satelliteId, long freeMemory, List<Long> modulesCapacity) {
		// set the satellite id
		this.satelliteId = satelliteId;

		// set the free memory
		this.freeMemory = freeMemory;

		// create 6 new memory modules
		this.MM1 = new MemoryModule("MM1", 8191);
		this.MM2 = new MemoryModule("MM2", 8191);
		this.MM3 = new MemoryModule("MM3", 8191);
		this.MM4 = new MemoryModule("MM4", 8191);
		this.MM5 = new MemoryModule("MM5", 8191);
		this.MM6 = new MemoryModule("MM6", 8191);

		// add them to th list of
		// memory modules
		this.MMList = new ArrayList<>(Arrays.asList(this.MM1, this.MM2, this.MM3, this.MM4, this.MM5, this.MM6));

		// set the capacity
		setCapacity(modulesCapacity);

		// set all memory modules as unused
		restoreAllModules();
	}

	/**
	 * return the MemoryModule with the id given as input.
	 *
	 * @param id the id of the memory module we are searching for
	 * @return the MemoryModule with the id given as input
	 */
	public MemoryModule getMemoryModuleWithId(String id) {
		// initialize the memorymodule to return
		MemoryModule returnedMem = null;
		// if it is referred to memoryModule 1
		if (id.contains("1")) {
			// return the mmeory module 1
			returnedMem = this.MM1;
		} // if it is referred to memoryModule 2
		else if (id.contains("2")) {
			returnedMem = this.MM2;
		} // if it is referred to memoryModule 3
		else if (id.contains("3")) {
			returnedMem = this.MM3;
		} // if it is referred to memoryModule 4
		else if (id.contains("4")) {
			returnedMem = this.MM4;
		} // if it is referred to memoryModule 5
		else if (id.contains("5")) {
			returnedMem = this.MM5;
		} // if it is referred to memoryModule 6
		else if (id.contains("6")) {
			returnedMem = this.MM6;
		}
		return returnedMem;
	}

	/**
	 * Gets the free memory.
	 *
	 * @return the free memory
	 */
	public long getFreeMemory() {
		// initialize the total free memory
		this.freeMemory = 0;
		// iterate over the memory modules list
		for (int i = 0; i < this.MMList.size(); i++) {
			// increment the total free memory of the free sectors of each
			// memory module
			this.freeMemory = this.freeMemory + this.MMList.get(i).getFreeSectors();
		}
		return this.freeMemory;
	}

	/**
	 * Gets the MM list.
	 *
	 * @return the MM list
	 */
	public List<MemoryModule> getMMList() {
		return this.MMList;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Restore all modules.
	 */
	public void restoreAllModules() {
		// iterate over the memory modules list
		for (int i = 0; i < this.MMList.size(); i++) {
			// set the i-esim memory module as not used
			this.MMList.get(i).setInUse(false);
		}
	}

	/**
	 * Sets the capacity.
	 *
	 * @param modulesCapacity the new capacity
	 */
	public void setCapacity(List<Long> modulesCapacity) {
		// if there isn't a valid capacity in input
		if ((modulesCapacity == null) || modulesCapacity.isEmpty()) {
			// iterate over the memory modules list
			for (int i = 0; i < this.MMList.size(); i++) {
				// set as free setor for the i-esim memory module the total free
				// memory / the number of memory modules
				this.MMList.get(i).setFreeSectors((long) java.lang.Math.floor(this.freeMemory / 6));
			}
		}
		// if the capacity is valid
		else {
			// iterate over the memory modules list
			for (int i = 0; i < this.MMList.size(); i++) {
				// set the i-esim capacity as free sectors of the i-esim memory
				// module
				this.MMList.get(i).setFreeSectors(modulesCapacity.get(i));
			}
		}
	}

	/**
	 * Sets the free memory.
	 *
	 * @param freeMemory the new free memory
	 */
	public void setFreeMemory(long freeMemory) {
		this.freeMemory = freeMemory;
	}

	/**
	 * Sets the MM list.
	 *
	 * @param mMList the new MM list
	 */
	public void setMMList(List<MemoryModule> mMList) {
		// set the memory modules list
		this.MMList = mMList;

		// iterate over the modules
		for (int i = 0; i < mMList.size(); i++) {

			// extract the current module
			MemoryModule currMemMod = mMList.get(i);
			// if is referred to the module 1
			if (currMemMod.getId().contains("1")) {

				// set it with the current value
				this.MM1 = currMemMod;
				// if is referred to the module 2
			} else if (currMemMod.getId().contains("2")) {
				this.MM2 = currMemMod;
				// if is referred to the module 3
			} else if (currMemMod.getId().contains("3")) {
				this.MM3 = currMemMod;
				// if is referred to the module 4
			} else if (currMemMod.getId().contains("4")) {
				this.MM4 = currMemMod;
				// if is referred to the module 5
			} else if (currMemMod.getId().contains("5")) {
				this.MM5 = currMemMod;
			} else {
				// if is referred to the module 6
				this.MM6 = currMemMod;
			}
		}

	}

	/**
	 * return the toString of the PDHT.
	 *
	 * @return the toString with all the properties of the current pdht
	 */
	@Override
	public String toString() {
		/*
		 * return the toString of the PDHT
		 *
		 * return the toString with all the properties of the current pdht
		 */
		StringBuffer buff = new StringBuffer();
		buff.append("----PDHT----- \n");
		buff.append("----for satellite : " + this.satelliteId + "-----\n");
		for (int i = 0; i < this.MMList.size(); i++) {
			MemoryModule mm = this.MMList.get(i);
			buff.append("MM_number=" + mm.getId() + "\n");
			buff.append("MM_Capacity=" + mm.getFreeSectors() + "\n");
		}
		return buff.toString();
	}
}
