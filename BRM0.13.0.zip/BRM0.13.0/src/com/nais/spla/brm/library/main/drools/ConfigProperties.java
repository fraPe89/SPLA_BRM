/**
*
* MODULE FILE NAME: ConfigProperties.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import com.nais.spla.brm.library.main.exception.ConfigurationException;

// TODO: Auto-generated Javadoc
/**
 * The Class ConfigProperties.
 *
 * @author fpedrola
 */
public class ConfigProperties {

	/** The properies instance needed to read values from property files. */
	private final Properties prop;

	/**
	 * Instantiates a new config properties.
	 */
	public ConfigProperties() {
		// return a new Property
		this.prop = new Properties();
	}

	/**
	 * Gets the properties by name.
	 *
	 * @param propName the prop name
	 * @return the properties by name
	 * @throws ConfigurationException the configuration exception
	 */
	public String getPropertiesByName(String propName) throws NullPointerException {
		// get the property with the name passed as input, if exists
		String value = this.prop.getProperty(propName, null);

		// check if the returned value is not null
		checkNullValue(value, propName + " not configurated");

		// return the value
		return value;
	}

	/**
	 * Check if the just found value is correctly configured.
	 *
	 * @param value        the value
	 * @param errorMessage the error message
	 * @throws ConfigurationException 
	 */

	public void checkNullValue(final String value, String errorMessage) {
		// if the value is not correctly configured
		if (value == null){
			// invoke a configuration exception with the errorMessage passed as
			// input

			throw new NullPointerException(errorMessage);
			}
	}

	/**
	 * Inits the environment.
	 *
	 * @param configFilePath the config file path
	 * @throws ConfigurationException the configuration exception
	 */
	public void init(String configFilePath) throws ConfigurationException {
		// invoke the method that reads the properties from the file given as
		// input parameter
		loadPropertiesFile(configFilePath);
	}

	/**
	 * Load properties file.
	 *
	 * @param propertiesFilePath the properties file path
	 * @throws ConfigurationException the configuration exception
	 */
	public void loadPropertiesFile(String propertiesFilePath) throws ConfigurationException {
		// create an InputStream to represent an input stream of bytes
		InputStream input = null;
		try {
			// opening a connection to the file given as input (path)
			input = new FileInputStream(propertiesFilePath);

			// reads a property list (key and element pairs) from the input byte
			// stream
			this.prop.load(input);

			// closes this input stream and releases any system resources
			// associated with the stream.
			input.close();
		} catch (Exception e) {
			// if the file is not found or is corrupt, it cause an exception
			throw new ConfigurationException(" read " + propertiesFilePath + " Failed");
		}
	}

}
