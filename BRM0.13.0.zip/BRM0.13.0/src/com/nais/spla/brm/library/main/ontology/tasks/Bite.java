/**
*
* MODULE FILE NAME:	Bite.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		04 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 04 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.tasks;

/**
 * The Class Bite.
 *
 * @author francesca
 */
@SuppressWarnings("serial")
public class Bite extends Task {

	/** The module selection flag. */
	private int moduleSelectionFlag;

	/** The module id. */
	private String moduleId;

	/** The filler word. */
	private String fillerWord;

	/** The packet store id. */
	private String packetStoreId;

	/**
	 * Gets the module selection flag.
	 *
	 * @return the moduleSelectionFlag
	 */
	public int getModuleSelectionFlag() {
		return this.moduleSelectionFlag;
	}

	/**
	 * Sets the module selection flag.
	 *
	 * @param moduleSelectionFlag the moduleSelectionFlag to set
	 */
	public void setModuleSelectionFlag(int moduleSelectionFlag) {
		this.moduleSelectionFlag = moduleSelectionFlag;
	}

	/**
	 * Instantiates a new bite.
	 */
	public Bite() {
		super();
	}

	/**
	 * Instantiates a new bite.
	 *
	 * @param moduleSelectionFlag the module selection flag
	 * @param moduleId            the module id
	 * @param fillerWord          the filler word
	 * @param packetStoreId       the packet store id
	 */
	public Bite(int moduleSelectionFlag, String moduleId, String fillerWord, String packetStoreId) {
		super();

		this.moduleSelectionFlag = moduleSelectionFlag;

		// set the impacted memory module
		this.moduleId = moduleId;

		// et the filler word
		this.fillerWord = fillerWord;
		this.packetStoreId = packetStoreId;
	}

	/**
	 * Gets the module id.
	 *
	 * @return the moduleId
	 */
	public String getModuleId() {
		return this.moduleId;
	}

	/**
	 * Sets the module id.
	 *
	 * @param moduleId the moduleId to set
	 */
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	/**
	 * Gets the filler word.
	 *
	 * @return the fillerWord
	 */
	public String getFillerWord() {
		return this.fillerWord;
	}

	/**
	 * Sets the filler word.
	 *
	 * @param fillerWord the fillerWord to set
	 */
	public void setFillerWord(String fillerWord) {
		this.fillerWord = fillerWord;
	}

	/**
	 * Gets the packet store id.
	 *
	 * @return the packetStoreId
	 */
	public String getPacketStoreId() {
		return this.packetStoreId;
	}

	/**
	 * Sets the packet store id.
	 *
	 * @param packetStoreId the packetStoreId to set
	 */
	public void setPacketStoreId(String packetStoreId) {
		this.packetStoreId = packetStoreId;
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() { /**
								 * toString del metodo
								 */
		return "Bite [moduleSelectionFlag=" + this.moduleSelectionFlag + ", moduleId=" + this.moduleId + ", fillerWord="
				+ this.fillerWord + ", packetStoreId=" + this.packetStoreId + "]";
	}

}
