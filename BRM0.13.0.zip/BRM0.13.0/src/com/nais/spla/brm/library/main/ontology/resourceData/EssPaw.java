/**
*
* MODULE FILE NAME:	EssPaw.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		02 set 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 02 set 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;

/**
 * The Class EssPaw.
 *
 * @author francesca
 */
public class EssPaw {

	/** The paw. */
	private PAWType paw;

	/** The ess paw. */
	private double essPaw;

	/**
	 * Instantiates a new ess paw.
	 *
	 * @param paw    the paw
	 * @param essPaw the ess paw
	 */
	public EssPaw(PAWType paw, double essPaw) {
		super();
		this.paw = paw;
		this.essPaw = essPaw;
	}

	/**
	 * Gets the paw.
	 *
	 * @return the paw
	 */
	public PAWType getPaw() {
		return this.paw;
	}

	/**
	 * Gets the ess paw.
	 *
	 * @return the essPaw
	 */
	public double getEssPaw() {
		return this.essPaw;
	}

}
