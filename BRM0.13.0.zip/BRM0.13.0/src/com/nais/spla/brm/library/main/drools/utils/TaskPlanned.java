/**
*
* MODULE FILE NAME:	TaskPlanned.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		12 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 12 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;

/**
 * The Class TaskPlanned.
 *
 * @author francesca
 */
public class TaskPlanned {

	/**
	 * Receive all downloads.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the list
	 */
	public List<Download> receiveAllDownloads(String sessionId, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		String sessionInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// create an empty list of Download
		List<Download> allDown = new ArrayList<>();

		// get the current kie session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get the resource function invoking the Drools globals
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		// get all the downloads planned for the satellite with the id given as
		// input
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
				.getDownloadsAssociatedToSat(satId);
		logger.debug("download treemap sat : " + satId + " is : " + dwlTreeMap);

		// add all the standard dwl to the list
		allDown.addAll(resFunc.getDownloadAssociatedToSat(satId));

		// add also gps data
		allDown.addAll(DownloadManagement.getAllDwlFromTreeMapGPS(satId, droolsParams, dwlTreeMap));
		logger.debug("all DWL  : " + allDown);
		return allDown;
	}

	/**
	 * Receive all store aux.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the list
	 */
	public List<StoreAUX> receiveAllStoreAux(String currentSession, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// create an empty list of storeAux
		List<StoreAUX> allStoAux = new ArrayList<>();

		// get the current kie session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get the resource functions invoking the Drools globals
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		// receive all store aux from resourceFunctions
		allStoAux = resFunc.getAllStoAuxForSatellite(satId);
		return allStoAux;
	}

	/**
	 * Receive all maneuvers.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the list
	 */
	public List<Maneuver> receiveAllManeuvers(String currentSession, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// create an empty list of maneuvers
		List<Maneuver> allMan = new ArrayList<>();

		// get the current kie session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// invoke the drools query to extract all the object of type maneuver
		// for the satellite with the id given as input
		QueryResults resultsMan = kieSession.getQueryResults("getObjectsOfManeuver", satId);

		// iterate over the results
		for (QueryResultsRow row : resultsMan) {
			// extract the maneuver
			Maneuver man = (Maneuver) row.get("$allMan");

			// add to the list
			allMan.add(man);
		}
		return allMan;
	}

	/**
	 * Receive all cmg axis for sat.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the list
	 */
	public List<CMGAxis> receiveAllCmgAxisForSat(String session, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		// create an empty list of cmgAxis
		List<CMGAxis> allCmgAxis = new ArrayList<>();

		String sessionInstance = DroolsParameters.concatenateSession(session, currentInstance);
		// get the current kie session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// invoke the drools query to extract all the object of type cmgAxis for
		// the satellite with the id given as input
		QueryResults resultsMan = kieSession.getQueryResults("getAllCmgAxis", satId);

		// iterate over the results
		for (QueryResultsRow row : resultsMan) {
			// cast the i-esim result to a cmgAxis object
			CMGAxis currentCmgAxis = (CMGAxis) row.get("$axis");

			// add it to the list
			allCmgAxis.add(currentCmgAxis);
		}
		return allCmgAxis;
	}

	/**
	 * Receive all ramps.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the list
	 */
	public List<RampCMGA> receiveAllRamps(String currentSession, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// crete an empty list of rmps
		List<RampCMGA> allRamp = new ArrayList<>();

		// get the current kie session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// invoke the drools query to extract all the object of type ramp for
		// the satellite with the id given as input
		QueryResults resultsRamps = kieSession.getQueryResults("getObjectsOfRamps", satId);

		// iterate over the rsults
		for (QueryResultsRow row : resultsRamps) {
			// extract the i-esim ramp
			RampCMGA ramp = (RampCMGA) row.get("$allRamps");

			// add to the list
			allRamp.add(ramp);
		}
		return allRamp;
	}

	/**
	 * Gets the all paw overlap interval.
	 *
	 * @param droolsParams the drools params
	 * @param startCheck   the start check
	 * @param endCheck     the end check
	 * @param satelliteId  the satellite id
	 * @return the all paw overlap interval
	 */
	public List<PAW> getAllPawOverlapInterval(DroolsParameters droolsParams, Date startCheck, Date endCheck,
			String satelliteId) {
		// create an empty list of paws
		List<PAW> allPawInInterval = new ArrayList<>();

		// iterate over all the paws
		for (int i = 0; i < droolsParams.getAllPAWS().size(); i++) {
			// extrat the i-esim paw
			PAW currentPaw = droolsParams.getAllPAWS().get(i);

			// if the current paw is in overlap with the interval given as input
			if ((currentPaw.getStartTime().getTime() <= endCheck.getTime())
					&& (currentPaw.getEndTime().getTime() >= startCheck.getTime())
					&& currentPaw.getSatelliteId().equalsIgnoreCase(satelliteId)) {
				// add it to the list
				allPawInInterval.add(currentPaw);
			}
		}
		return allPawInInterval;
	}

	/**
	 * Gets the all vis overlap interval.
	 *
	 * @param droolsParams the drools params
	 * @param startCheck   the start check
	 * @param endCheck     the end check
	 * @param satelliteId  the satellite id
	 * @return the all vis overlap interval
	 */
	public List<Visibility> getAllVisOverlapInterval(DroolsParameters droolsParams, Date startCheck, Date endCheck,
			String satelliteId) {
		// create an empty list of visibilities
		List<Visibility> allVisInInterval = new ArrayList<>();

		// iterate over all the visibilities
		for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {
			// extract the i-esim visibility
			Visibility currentVis = droolsParams.getAllVisibilities().get(i);

			// if is in overlap with the period given as input
			if ((currentVis.getStartTime().getTime() <= endCheck.getTime())
					&& (currentVis.getEndTime().getTime() >= startCheck.getTime())
					&& currentVis.getSatelliteId().equalsIgnoreCase(satelliteId)) {
				// add it to the list
				allVisInInterval.add(currentVis);
			}
		}
		return allVisInInterval;
	}

	/**
	 * Receive all silent.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the list
	 */
	public List<Silent> receiveAllSilent(String currentSession, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		List<Silent> allSilents = new ArrayList<>();

		// get the current kie session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// invoke the drools query to extract all the object of type silent for
		// the satellite with the id given as input
		QueryResults resultsDown = kieSession.getQueryResults("getObjectsOfSilent", satId);

		// iterate over the results
		for (QueryResultsRow row : resultsDown) {
			// extract the i-esim silent
			Silent sil = (Silent) row.get("$allSil");

			// add to the list
			allSilents.add(sil);
		}
		return allSilents;
	}

	/**
	 * Receive all acquisitions as map.
	 *
	 * @param droolsParams the drools params
	 * @param satId        the sat id
	 * @return the map
	 */
	public Map<String, Acquisition> receiveAllAcquisitionsAsMap(String sessionId, int currentInstance,
			DroolsParameters droolsParams, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create a map whre will be stored all the performed acq
		Map<String, Acquisition> allAcq = null;
		logger.debug("receive all acquisitions method ");

		// if the current session is a valid one
		if (SessionHandler.getKieSessionsMap().containsKey(sessionInstance)) {
			allAcq = new HashMap<>();

			// get the current kie session
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

			// get the current kie session
			QueryResults resultsAcq = kieSession.getQueryResults("getObjectsOfAcquisition", satId);

			// iterate over the results
			for (QueryResultsRow row : resultsAcq) {
				// extract the i-esim acquisition
				Acquisition acq = (Acquisition) row.get("$allAcq");
				logger.debug("found acq : " + acq);

				// add to the list
				allAcq.put(acq.getId(), acq);
			}
		}
		logger.debug("returned acq map : " + allAcq);

		return allAcq;
	}
}
