/**
*
* MODULE FILE NAME:	SetResources.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		17 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 17 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.functions.GPSDownloadManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.ontology.resourceData.BicHpPeakOrbit;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class SetResources.
 *
 * @author francesca
 */
public class SetResources {

	/**
	 * Sets the satellites.
	 *
	 * @param droolsParams the drools params
	 * @param kie          the kie
	 * @param satProp1     the sat prop 1
	 * @param satProp2     the sat prop 2
	 */
	protected void setSatellites(DroolsParameters droolsParams, KieSession kie, SatelliteProperties satProp1,
			SatelliteProperties satProp2) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// iterate over all the satellites
		for (int i = 0; i < droolsParams.getAllSat().size(); i++) {
			// extract i-esim satellite
			Satellite currentSat = droolsParams.getAllSat().get(i);

			// filter all the visibilities taken only the ones relative to
			// the current satellite
			currentSat.setVisibilityList(
					EnvironmentUtils.getAllVisForSat(droolsParams.getAllVisibilities(), currentSat.getSatelliteId()));

			// if the satellite is the first of the constellation
			if (currentSat.getSatelliteId().contains("1")) {
				// add the satProperties to sat1
				currentSat.setSatelliteProperties(satProp1);
				logger.debug("get satellite properties sat 1 " + currentSat.getSatelliteProperties());
			} else {
				// add the satProperties to sat2
				currentSat.setSatelliteProperties(satProp2);
				logger.debug("get satellite properties sat 2 " + currentSat.getSatelliteProperties());

			}

			// insert the satellite inside the Drools engine
			kie.insert(currentSat);
		}
	}

	/**
	 * Sets the paws.
	 *
	 * @param droolsParams the drools params
	 * @param kie          the kie
	 * @param resFunc      the res func
	 * @param satProp1     the sat prop 1
	 * @param satProp2     the sat prop 2
	 */
	protected void setPaws(DroolsParameters droolsParams, KieSession kie, ResourceFunctions resFunc,
			SatelliteProperties satProp1, SatelliteProperties satProp2) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the DownloadManagement to avoid the downloads over the paw
		DownloadManagement dwlMng = new DownloadManagement();

		// if the list of paw is valid
		if ((droolsParams.getAllPAWS() != null) && (!droolsParams.getAllPAWS().isEmpty())) {
			// iterate over them
			for (int i = 0; i < droolsParams.getAllPAWS().size(); i++) {
				// extract the i-esim paw
				PAW currentPaw = droolsParams.getAllPAWS().get(i);

				// get the map of downloads relative to the satellite relative
				// to the current paw
				TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlForSar = resFunc
						.getDownloadsAssociatedToSat(currentPaw.getSatelliteId());

				// create an empty list of visibilities
				List<Visibility> allVisInOverlap = new ArrayList<>();

				// iterate over the visibilities
				for (int j = 0; j < droolsParams.getAllVisibilities().size(); j++) {
					// extract the j-esim visibility
					Visibility currentVis = droolsParams.getAllVisibilities().get(j);

					// if the vis is related to the current satellite and is in
					// overlap with the current paw
					if ((currentVis.getStartTime().getTime() < currentPaw.getEndTime().getTime())
							&& (currentVis.getEndTime().getTime() > currentPaw.getStartTime().getTime())) {
						// overlap
						allVisInOverlap.add(currentVis);
					}
				}

				// if there are visibilities in overlap
				if (allVisInOverlap.size() > 0) {
					logger.debug("inserting paw in dwl treemap because overlap with visibilities");
					// create a dummy tasks to avoid downloads on paw
					Task dummyTaskForPaw = new Task();

					// set start time of dummy task with the start time of paw
					dummyTaskForPaw.setStartTime(currentPaw.getStartTime());

					// set end time of dummy task with the end time of paw
					dummyTaskForPaw.setEndTime(currentPaw.getEndTime());

					// set satellite id with the satellite id of the current paw
					dummyTaskForPaw.setSatelliteId(currentPaw.getSatelliteId());

					// insert the dummy task into the download structure
					dwlMng.insertInIDownloadStructure(dummyTaskForPaw, allVisInOverlap, dwlForSar);
				}

				// insert the paw into the Drools engine
				kie.insert(droolsParams.getAllPAWS().get(i));
			}
		} else {
			// there isn't a valid list of paws
			logger.debug("paw list is null or empty.");
		}
	}

	/**
	 * Sets the pdht.
	 *
	 * @param droolsParams the new pdht
	 * @param kie          the kie
	 */
	protected void setPDHT(DroolsParameters droolsParams, KieSession kie) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// if the list of PDHT is valid
		if ((droolsParams.getAllPDHT() != null) && (!droolsParams.getAllPDHT().isEmpty())) {
			// iterate over the pdht list
			for (int i = 0; i < droolsParams.getAllPDHT().size(); i++) {
				// insert the pdht into the Drools engine
				kie.insert(droolsParams.getAllPDHT().get(i));
			}
		} else {
			// there isn't a valid list of pdht
			logger.debug("pdht list is null or empty.");
		}
	}

	/**
	 * Sets the visibilities.
	 *
	 * @param droolsParams the drools params
	 * @param resFunc      the res func
	 * @param kie          the kie
	 */
	protected void setVisibilities(DroolsParameters droolsParams, ResourceFunctions resFunc, KieSession kie) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// if the visibilities list is not empty
		if ((!droolsParams.getAllVisibilities().isEmpty())) {
			// create an instance of GPSDownloadManagement
			GPSDownloadManagement gpsMng = new GPSDownloadManagement();

			// create a list for all the Pratica di mare visibilities
			HashMap<String, Visibility> allPdrVisibilities1 = new HashMap<>();

			// create a list for all the Pratica di mare visibilities
			HashMap<String, Visibility> allPdrVisibilities2 = new HashMap<>();

			// create a list for all the external visibilities
			HashMap<String, Visibility> allExternalVisibilities1 = new HashMap<>();

			// create a list for all the external visibilities
			HashMap<String, Visibility> allExternalVisibilities2 = new HashMap<>();

			// create a list for all the backup stations visibilities
			HashMap<String, Visibility> allBackUpStations1 = new HashMap<>();

			// create a list for all the backup stations visibilities
			HashMap<String, Visibility> allBackUpStations2 = new HashMap<>();

			DownloadUtils dwlUtils = new DownloadUtils();
			List<Visibility> allVis = droolsParams.getAllVisibilities();

			allVis = GPSDownloadManagement.resizeVisForPaw(droolsParams.getAllVisibilities(),
					droolsParams.getAllPAWS());
			allVis = dwlUtils.filterVisForMh(allVis, droolsParams.getCurrentMH());

			// iterate over all the visibilities
			for (int i = 0; i < allVis.size(); i++) {
				// extract the i-esim visibility
				Visibility vis = allVis.get(i);

				// truncate vis if is overlap with mh
				if ((vis.getStartTime().getTime() < droolsParams.getCurrentMH().getStart().getTime())
						&& (vis.getEndTime().getTime() > droolsParams.getCurrentMH().getStart().getTime())) {
					// set the start time of the visibility with the current mh start time
					vis.setStartTime(droolsParams.getCurrentMH().getStart());

					// update also the available start time of L1 and L2
					vis.setAvailableStartTimeL1(droolsParams.getCurrentMH().getStart());
					vis.setAvailableStartTimeL2(droolsParams.getCurrentMH().getStart());
				}

				if (vis.getStartTime().getTime() >= droolsParams.getCurrentMH().getStart().getTime()) {
					// if the visibility is of Pratica di mare
					if (vis.getAcqStatId().startsWith(droolsParams.getPraticaDiMareId())) {
						if (vis.getSatelliteId().contains("1")) {
							// add to the list of pratica di mare visibilities
							allPdrVisibilities1
									.put(vis.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis), vis);
						} else {
							// add to the list of pratica di mare visibilities
							allPdrVisibilities2
									.put(vis.getStartTime().getTime() + DownloadManagement.concatVisId("2", vis), vis);

						}

					}

					// if the visibility is external
					else {
						if (vis.isExternal() || vis.getOwnerId() == null) {
							if (vis.getSatelliteId().contains("1")) {
								// add to the list of external ones
								allExternalVisibilities1.put(
										vis.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis), vis);

							} else {
								// add to the list of external ones
								allExternalVisibilities2.put(
										vis.getStartTime().getTime() + DownloadManagement.concatVisId("2", vis), vis);

							}
						}
						if (vis.getAcqStatId().startsWith(droolsParams.getMateraId())) {
							logger.debug(
									"add vis as backup station for gps : Matera id :" + droolsParams.getMateraId());
							if (vis.getSatelliteId().contains("1")) {
								// add to the list of external ones
								allBackUpStations1.put(
										vis.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis), vis);

							} else {
								// add to the list of external ones
								allBackUpStations2.put(
										vis.getStartTime().getTime() + DownloadManagement.concatVisId("2", vis), vis);

							}
						}

					}
					// droolsParams.getAllVisibilities().add(vis);

					// insert the visibility inside the Drools engine
					kie.insert(vis);
				}

			}

			int cont = 0;

			if ((droolsParams.getDisableGPS() != null) && droolsParams.getDisableGPS().equalsIgnoreCase("0")) {
				if ((allPdrVisibilities1.size() == 0) && (allExternalVisibilities1.size() == 0)) {
					// plan GPS only on backupStations
					logger.debug("PLAN GPS ON BACKUP STATIONS FOR SAT 1");

					// plan gps for external stations for the second satellite
					gpsMng.planGpsSectorsForCurrentVis(cont, allBackUpStations1, droolsParams.getAllPAWS(),
							droolsParams, true, resFunc, "1");

				} else {
					// plan gps for external stations for the first satellite
					gpsMng.planGpsSectorsForCurrentVis(cont, allExternalVisibilities1, droolsParams.getAllPAWS(),
							droolsParams, true, resFunc, "1");

					// plan gps for PDM stations for the first satellite
					gpsMng.planGpsSectorsForCurrentVis(cont, allPdrVisibilities1, droolsParams.getAllPAWS(),
							droolsParams, false, resFunc, "1");

				}

				if ((allPdrVisibilities2.size() == 0) && (allExternalVisibilities2.size() == 0)) {
					// plan GPS only on backupStations
					logger.debug("PLAN GPS ON BACKUP STATIONS FOR SAT 2");

					// plan gps for external stations for the second satellite
					gpsMng.planGpsSectorsForCurrentVis(cont, allBackUpStations2, droolsParams.getAllPAWS(),
							droolsParams, true, resFunc, "2");

				} else {
					// plan gps for external stations for the second satellite
					gpsMng.planGpsSectorsForCurrentVis(cont, allExternalVisibilities2, droolsParams.getAllPAWS(),
							droolsParams, true, resFunc, "2");

					// plan gps for PDM stations for the second satellite
					gpsMng.planGpsSectorsForCurrentVis(cont, allPdrVisibilities2, droolsParams.getAllPAWS(),
							droolsParams, false, resFunc, "2");
				}
			}
		} else {
			// there isn't a valid list of visibilities
			logger.debug("visibility list is null or empty.");
		}
	}

	/**
	 * Populate resource functions.
	 *
	 * @param resourceFunctions the resource functions
	 * @param droolsParams      the drools params
	 */
	public void populateResourceFunctions(ResourceFunctions resourceFunctions, DroolsParameters droolsParams) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// setting resources for maneuvers
		TreeMap<Long, Maneuver> allManSat1 = new TreeMap<>();
		TreeMap<Long, Maneuver> allManSat2 = new TreeMap<>();
		// for sat1
		resourceFunctions.setAllManeuversSat1(allManSat1);
		// for sat2
		resourceFunctions.setAllManeuversSat2(allManSat2);

		// setting resources for silents
		TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1 = new TreeMap<>();
		TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat2 = new TreeMap<>();
		// for sat1
		resourceFunctions.setSilentFunctionSat1(silentFunctionSat1);
		// for sat2
		resourceFunctions.setSilentFunctionSat2(silentFunctionSat2);

		// setting resources for acquisitions and energies
		TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = new TreeMap<>();
		TreeMap<Long, EnergyAssociatedToTask> essFunctionSat2 = new TreeMap<>();
		resourceFunctions.setEssFunctionSat1(essFunctionSat1);
		resourceFunctions.setEssFunctionSat2(essFunctionSat2);

		/*
		 * setting bic hp resources for peak orbits
		 */
		TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunctionSat1 = new TreeMap<>();
		TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunctionSat2 = new TreeMap<>();

		// for sat 1
		resourceFunctions.setBicHpPeakOrbitFunctionSat1(bicHpPeakOrbitFunctionSat1);
		// for sat 2
		resourceFunctions.setBicHpPeakOrbitFunctionSat2(bicHpPeakOrbitFunctionSat2);

		// setting ramp resources for cmga maneuvers
		TreeMap<Long, RampCMGA> allRampsSat1 = new TreeMap<>();
		TreeMap<Long, RampCMGA> allRampsSat2 = new TreeMap<>();

		// for sat 1
		resourceFunctions.setAllRampsSat1(allRampsSat1);
		// for sat 2
		resourceFunctions.setAllRampsSat2(allRampsSat2);

		// setting dwl resources for planned downloads
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat1 = new TreeMap<>();
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat2 = new TreeMap<>();

		// for sat 1
		resourceFunctions.setDwlTreeMapSat1(dwlTreeMapSat1);
		// for sat 2
		resourceFunctions.setDwlTreeMapSat2(dwlTreeMapSat2);

		// setting priority resources for the acquisition that are waiting for a
		// download
		TreeMap<String, PriorityQueue> downloadPriorityQueueSat1 = new TreeMap<>();
		TreeMap<String, PriorityQueue> downloadPriorityQueueSat2 = new TreeMap<>();

		// for sat 1
		resourceFunctions.setDownloadPriorityQueueSat1(downloadPriorityQueueSat1);
		// for sat 2
		resourceFunctions.setDownloadPriorityQueueSat2(downloadPriorityQueueSat2);

		// setting PDHT resources
		TreeMap<Long, ComplexPdht> PDHTFunctionSat1 = new TreeMap<>();
		TreeMap<Long, ComplexPdht> PDHTFunctionSat2 = new TreeMap<>();

		// inserting the initial values of pdht at start time inside the
		// function
		for (int i = 0; i < droolsParams.getAllPDHT().size(); i++) {
			// if the i-esim satellite is sat1
			if (droolsParams.getAllPDHT().get(i).getSatelliteId().contains("1")) {
				// set it's pdht with the value at mission horizon start time
				PDHTFunctionSat1.put(droolsParams.getCurrentMH().getStart().getTime(),
						new ComplexPdht(droolsParams.getAllPDHT().get(i)));
			}
			// if the i-esim satellite is sat2
			else if (droolsParams.getAllPDHT().get(i).getSatelliteId().contains("2")) {
				// set it's pdht with the value at mission horizon start time
				PDHTFunctionSat2.put(droolsParams.getCurrentMH().getStart().getTime(),
						new ComplexPdht(droolsParams.getAllPDHT().get(i)));
			}
			logger.debug("POPULATE RESOURCES_ inserted the pdht at time : " + droolsParams.getCurrentMH().getStart()
					+ " with value : " + droolsParams.getAllPDHT().get(i) + " for sat : "
					+ droolsParams.getAllPDHT().get(i).getSatelliteId());
		}
		// set the pdht function for sat1
		resourceFunctions.setPDHTTemporalFunctionSat1(PDHTFunctionSat1);

		// set the pdht function for sat2
		resourceFunctions.setPDHTTemporalFunctionSat2(PDHTFunctionSat2);
	}

	/**
	 * Sets the satellites unavailability.
	 *
	 * @param droolsParams the new satellites unavailability
	 * @param kie          the kie
	 */
	protected void setSatellitesUnavailability(DroolsParameters droolsParams, KieSession kie) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// if the list of satellite unavailabilities is not empty
		if ((droolsParams.getSatelliteState() != null) && (!droolsParams.getSatelliteState().isEmpty())) {
			// iterate over the list
			for (int i = 0; i < droolsParams.getSatelliteState().size(); i++) {
				// insert the i-esim unavailability into the Drools engine
				kie.insert(droolsParams.getSatelliteState().get(i));
			}
		} else {
			// there isn't a valid list of unavailabilities
			logger.debug("satellite state list is null or empty.");
		}

	}

	/**
	 * Sets the partners.
	 *
	 * @param droolsParams the new partners
	 * @param kie          the kie
	 */
	protected void setPartners(DroolsParameters droolsParams, KieSession kie) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// if the list of partners is not empty
		if ((droolsParams.getAllPartners() != null) && (!droolsParams.getAllPartners().isEmpty())) {
			// iterate over the partners
			for (int i = 0; i < droolsParams.getAllPartners().size(); i++) {
				// insert the i.-esim partner into Drools engine
				kie.insert(droolsParams.getAllPartners().get(i));
			}
		} else {
			// there isn't a valid list of partners
			logger.debug("partner list is null or empty.");
		}
	}

	/**
	 * Sets the eclipses.
	 *
	 * @param droolsParams the new eclipses
	 * @param kie          the kie
	 */
	protected void setEclipses(DroolsParameters droolsParams, KieSession kie) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// if the list of eclipses is valid
		if ((droolsParams.getAllEclipses() != null) && (!droolsParams.getAllEclipses().isEmpty())) {
			// iterate over the list of eclipses
			for (int i = 0; i < droolsParams.getAllEclipses().size(); i++) {
				// insert the i-esim eclipse in drools engine
				kie.insert(droolsParams.getAllEclipses().get(i));
			}
		} else {
			// there isn't a valid list of eclipses
			logger.debug("eclipse list is null or empty.");
		}
	}
}
