/**
 *
 * MODULE FILE NAME: Di2sInfo.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;

/**
 * The Class Di2sInfo.
 */
public class Di2sInfo implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The ugs id. */
	private String ugsId;

	/** The dto id relative to the slave. */
	private String relativeSlaveId;

	/** The id relative to the master. */
	private String relativeMasterId;

	/** The partner id. */
	private String partnerId;

	/** The slave dto. */
	private DTO slaveDto = null;

	/** The rejected. */
	private boolean rejected = false;

	/**
	 * Checks if is rejected.
	 *
	 * @return the rejected
	 */
	public boolean isRejected() {
		return this.rejected;
	}

	/**
	 * Sets the rejected.
	 *
	 * @param rejected the rejected to set
	 */
	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}

	/**
	 * Instantiates a new di2s info.
	 */
	public Di2sInfo() {
		super();
	}

	/**
	 * Instantiates a new di 2 s info.
	 *
	 * @param relativeSlaveId  the relative slave id
	 * @param relativeMasterId the relative master id
	 * @param ugsId            the ugs id
	 */
	public Di2sInfo(String relativeSlaveId, String relativeMasterId, String ugsId) {
		super();
		this.setRelativeSlaveId(relativeSlaveId);
		this.relativeMasterId = relativeMasterId;
		this.ugsId = ugsId;
	}

	/**
	 * Gets the ugs id.
	 *
	 * @return the ugs id
	 */
	public String getUgsId() {
		return this.ugsId;
	}

	/**
	 * Sets the ugs id.
	 *
	 * @param ugsId the new ugs id
	 */
	public void setUgsId(String ugsId) {
		this.ugsId = ugsId;
	}

	/**
	 * Gets the partner id.
	 *
	 * @return the partner id
	 */
	public String getPartnerId() {
		return this.partnerId;
	}

	/**
	 * Sets the partner id.
	 *
	 * @param partnerId the new partner id
	 */
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	/**
	 * Gets the slave dto.
	 *
	 * @return the slaveDto
	 */
	public DTO getSlaveDto() {
		return this.slaveDto;
	}

	/**
	 * Sets the slave dto.
	 *
	 * @param slaveDto the slaveDto to set
	 */
	public void setSlaveDto(DTO slaveDto) {
		this.slaveDto = slaveDto;
	}

	/**
	 * Gets the relative master id.
	 *
	 * @return the relativeMasterId
	 */
	public String getRelativeMasterId() {
		return this.relativeMasterId;
	}

	/**
	 * Sets the relative master id.
	 *
	 * @param relativeMasterId the relativeMasterId to set
	 */
	public void setRelativeMasterId(String relativeMasterId) {
		this.relativeMasterId = relativeMasterId;
	}

	/**
	 * Gets the relative slave id.
	 *
	 * @return the relativeSlaveId
	 */
	public String getRelativeSlaveId() {
		return this.relativeSlaveId;
	}

	/**
	 * Sets the relative slave id.
	 *
	 * @param relativeSlaveId the relativeSlaveId to set
	 */
	public void setRelativeSlaveId(String relativeSlaveId) {
		this.relativeSlaveId = relativeSlaveId;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the Di2sInfo
	 */
	@Override
	public String toString() {
		return "Di2sInfo [ugsId=" + this.ugsId + ", relativeSlaveId=" + this.relativeSlaveId + ", relativeMasterId="
				+ this.relativeMasterId + ", partnerId=" + this.partnerId + ", slaveDto=" + this.slaveDto
				+ ", rejected=" + this.rejected + "]";
	}

}
