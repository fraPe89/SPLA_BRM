/**
 *
 * MODULE FILE NAME: OrbitResources.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.Date;

/**
 * The Class OrbitResources.
 */
public class OrbitResources {

	/** The start. */
	private Date start;

	/** The stop. */
	private Date stop;

	/** The ess right. */
	private double essRight;

	/** The ess left. */
	private double essLeft;

	/** The time in left. */
	private double timeInLeft;

	/** The time in right. */
	private double timeInRight;

	/**
	 * Instantiates a new orbit resources.
	 *
	 * @param essRight    the ess right
	 * @param essLeft     the ess left
	 * @param timeInLeft  the time in left
	 * @param timeInRight the time in right
	 * @param start       the start
	 * @param stop        the stop
	 */
	public OrbitResources(double essRight, double essLeft, double timeInLeft, double timeInRight, Date start,
			Date stop) {
		super();
		this.essRight = essRight;
		this.essLeft = essLeft;
		this.timeInLeft = timeInLeft;
		this.setTimeInRight(timeInRight);
		this.start = start;
		this.setStop(stop);
	}

	/**
	 * Instantiates a new orbit resources.
	 */
	public OrbitResources() {
		super();

	}

	/**
	 * Gets the ess right.
	 *
	 * @return the ess right
	 */
	public double getEssRight() {
		return this.essRight;
	}

	/**
	 * Gets the ess left.
	 *
	 * @return the ess left
	 */
	public double getEssLeft() {
		return this.essLeft;
	}

	/**
	 * Gets the time in left.
	 *
	 * @return the time in left
	 */
	public double getTimeInLeft() {
		return this.timeInLeft;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public Date getStart() {
		return this.start;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the new start
	 */
	public void setStart(Date start) {
		this.start = start;
	}

	/**
	 * Gets the stop.
	 *
	 * @return the stop
	 */
	public Date getStop() {
		return this.stop;
	}

	/**
	 * Sets the stop.
	 *
	 * @param stop the new stop
	 */
	public void setStop(Date stop) {
		this.stop = stop;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the OrbotResources
	 */
	@Override
	public String toString() {
		return "OrbitResources [start=" + this.start + ", stop=" + this.stop + ", essRight=" + this.essRight
				+ ", essLeft=" + this.essLeft + ", timeInLeft=" + this.timeInLeft + ", timeInRight=" + this.timeInRight
				+ "]";
	}

	/**
	 * Gets the time in right.
	 *
	 * @return the time in right
	 */
	public double getTimeInRight() {
		return this.timeInRight;
	}

	/**
	 * Sets the time in right.
	 *
	 * @param timeInRight the new time in right
	 */
	public void setTimeInRight(double timeInRight) {
		this.timeInRight = timeInRight;
	}

}
