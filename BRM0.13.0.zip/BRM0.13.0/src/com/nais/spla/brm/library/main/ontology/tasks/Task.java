/**
*
* MODULE FILE NAME: Task.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 feb 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 feb 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;

// TODO: Auto-generated Javadoc
/**
 * The Class Task.
 */
@SuppressWarnings("serial")
public class Task implements Serializable {

	/** The id task. */
	private String idTask;

	/** The start time. */
	private Date startTime;

	/** The end time. */
	private Date endTime;

	/** The satellite id. */
	private String satelliteId;

	/** The task type. */
	private TaskType taskType;

	/** The related task id. */
	private String relatedTask;

	/** The time performance. */
	private boolean timePerformance = false;

	/** The task mark. */
	private TaskMarkType taskMark;

	/** The removable flag. */
	private boolean removableFlag = true;

	// set it to true if the dto is inserted into Drools as element processed
	/** The previous session. */
	// and accepted in a previous session
	private boolean previousSession = false;

	/** The previously processed. */
	private boolean previousMh = false;

	/** The decrement Bic. */
	private boolean decrementBic = true;

	/** The referred equiv dto. */
	private String referredEquivalentDto = null;

	/** The prec id. */
	private ArrayList<String> precId = null;

	/** this value is setted to true if the dto is a dummy dto. */
	private boolean isDummy = false;

	/** The rejected. */
	private boolean rejected = false;

	/** The di 2 s info. */
	private Di2sInfo di2sInfo = null;

	/** The associated bite. */
	private Bite associatedBite = null;

	/** The reason of reject. */
	private List<ReasonOfRejectElement> reasonOfReject;

	/**
	 * Instantiates a new task.
	 */
	public Task() {
		super();
		this.decrementBic = true;

		// initialize the removable flag to false
		this.removableFlag = true;

		// initialize the rejected flag to false
		this.rejected = false;

		// initialize the dummy flag to false
		this.isDummy = false;
		this.di2sInfo = null;
		setPrecId(new ArrayList<String>());
		this.setReasonOfReject(new ArrayList<ReasonOfRejectElement>());

	}

	/**
	 * Gets the task type.
	 *
	 * @return the task type
	 */
	public TaskType getTaskType() {
		return this.taskType;
	}

	/**
	 * Sets the task type.
	 *
	 * @param taskType the new task type
	 */
	public void setTaskType(TaskType taskType) {
		this.taskType = taskType;
	}

	/**
	 * Gets the task mark.
	 *
	 * @return the task mark
	 */
	public TaskMarkType getTaskMark() {
		return this.taskMark;
	}

	/**
	 * Sets the task mark.
	 *
	 * @param taskMark the new task mark
	 */
	public void setTaskMark(TaskMarkType taskMark) {
		this.taskMark = taskMark;
	}

	/**
	 * Gets the end time.
	 *
	 * @return the end time
	 */
	public Date getEndTime() {
		return DroolsUtils.getDateInMilliseconds(this.endTime);
	}

	/**
	 * Gets the id task.
	 *
	 * @return the id task
	 */
	public String getIdTask() {
		return this.idTask;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Gets the start time.
	 *
	 * @return the start time
	 */
	public Date getStartTime() {
		return DroolsUtils.getDateInMilliseconds(this.startTime);
	}

	/**
	 * Sets the end time.
	 *
	 * @param endime the new end time
	 */
	public void setEndTime(Date endime) {
		this.endTime = DroolsUtils.getDateInMilliseconds(endime);
	}

	/**
	 * Sets the id task.
	 *
	 * @param idTask the new id task
	 */
	public void setIdTask(String idTask) {
		this.idTask = idTask;
	}

	/**
	 * Sets the satellite id.
	 *
	 * @param satelliteId the new satellite id
	 */
	public void setSatelliteId(String satelliteId) {
		this.satelliteId = satelliteId;
	}

	/**
	 * Sets the start time.
	 *
	 * @param starTime the new start time
	 */
	public void setStartTime(Date starTime) {
		this.startTime = DroolsUtils.getDateInMilliseconds(starTime);
	}

	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "Task [idTask=" + this.idTask + ", startTime=" + this.startTime + ", endTime=" + this.endTime
				+ ", satelliteId=" + this.satelliteId + ", prevMh =" + this.previousMh + ", prevSession ="
				+ this.previousSession + "]";
	}

	/**
	 * Checks if is removable flag.
	 *
	 * @return true, if is removable flag
	 */
	public boolean isRemovableFlag() {
		return this.removableFlag;
	}

	/**
	 * Sets the removable flag.
	 *
	 * @param removableFlag the new removable flag
	 */
	public void setRemovableFlag(boolean removableFlag) {
		this.removableFlag = removableFlag;
	}

	/**
	 * Gets the referred equiv dto.
	 *
	 * @return the referred equiv dto
	 */
	public String getReferredEquivalentDto() {
		return this.referredEquivalentDto;
	}

	/**
	 * Sets the referred equiv dto.
	 *
	 * @param referredEquivalentDto the new referred equivalent dto
	 */
	public void setReferredEquivalentDto(String referredEquivalentDto) {
		this.referredEquivalentDto = referredEquivalentDto;
	}

	/**
	 * Gets the prec id.
	 *
	 * @return the prec id
	 */
	public ArrayList<String> getPrecId() {
		return this.precId;
	}

	/**
	 * Sets the prec id.
	 *
	 * @param precId the new prec id
	 */
	public void setPrecId(ArrayList<String> precId) {
		this.precId = precId;
	}

	/**
	 * Checks if is rejected.
	 *
	 * @return true, if is rejected
	 */
	public boolean isRejected() {
		return this.rejected;
	}

	/**
	 * Sets the rejected.
	 *
	 * @param rejected the new rejected
	 */
	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}

	/**
	 * Gets the di 2 s info.
	 *
	 * @return the di 2 s info
	 */
	public Di2sInfo getDi2sInfo() {
		return this.di2sInfo;
	}

	/**
	 * Sets the di 2 s info.
	 *
	 * @param di2sInfo the new di 2 s info
	 */
	public void setDi2sInfo(Di2sInfo di2sInfo) {
		this.di2sInfo = di2sInfo;
	}

	/**
	 * Checks if is dummy.
	 *
	 * @return true, if is dummy
	 */
	public boolean isDummy() {
		return this.isDummy;
	}

	/**
	 * Sets the dummy.
	 *
	 * @param isDummy the new dummy
	 */
	public void setDummy(boolean isDummy) {
		this.isDummy = isDummy;
	}

	/**
	 * Gets the associated bite.
	 *
	 * @return the associatedBite
	 */
	public Bite getAssociatedBite() {
		return this.associatedBite;
	}

	/**
	 * Sets the associated bite.
	 *
	 * @param associatedBite the associatedBite to set
	 */
	public void setAssociatedBite(Bite associatedBite) {
		this.associatedBite = associatedBite;
	}

	/**
	 * Gets the reason of reject.
	 *
	 * @return the reason of reject
	 */
	public List<ReasonOfRejectElement> getReasonOfReject() {
		return this.reasonOfReject;
	}

	/**
	 * Sets the reason of reject.
	 *
	 * @param reasonOfReject the new reason of reject
	 */
	public void setReasonOfReject(List<ReasonOfRejectElement> reasonOfReject) {
		this.reasonOfReject = reasonOfReject;
	}

	/**
	 * Checks if is decrement bic.
	 *
	 * @return true, if is decrement bic
	 */
	public boolean isDecrementBic() {
		return this.decrementBic;
	}

	/**
	 * Sets the decrement bic.
	 *
	 * @param decrementBic the new decrement bic
	 */
	public void setDecrementBic(boolean decrementBic) {
		this.decrementBic = decrementBic;
	}

	/**
	 * Gets the related task.
	 *
	 * @return the related task
	 */
	public String getRelatedTask() {
		return this.relatedTask;
	}

	/**
	 * Sets the related task id.
	 *
	 * @param relatedTask the new related task id
	 */
	public void setRelatedTaskId(String relatedTask) {
		this.relatedTask = relatedTask;
	}

	/**
	 * Checks if is time performance.
	 *
	 * @return true, if is time performance
	 */
	public boolean isTimePerformance() {
		return this.timePerformance;
	}

	/**
	 * Sets the time performance.
	 *
	 * @param timePerformance the new time performance
	 */
	public void setTimePerformance(boolean timePerformance) {
		this.timePerformance = timePerformance;
	}

	/**
	 * Checks if is previous session.
	 *
	 * @return true, if is previous session
	 */
	public boolean isPreviousSession() {
		return this.previousSession;
	}

	/**
	 * Sets the previous session.
	 *
	 * @param previousSession the new previous session
	 */
	public void setPreviousSession(boolean previousSession) {
		this.previousSession = previousSession;
	}

	/**
	 * Checks if is previous mh.
	 *
	 * @return true, if is previous mh
	 */
	public boolean isPreviousMh() {
		return this.previousMh;
	}

	/**
	 * Sets the previous mh.
	 *
	 * @param previousMh the new previous mh
	 */
	public void setPreviousMh(boolean previousMh) {
		this.previousMh = previousMh;
	}

}
