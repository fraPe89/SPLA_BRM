/**
 *
 * MODULE FILE NAME: SizeOfSectorDwl.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;

/**
 * The Class SizeOfSectorDwl.
 */
public class SizeOfSectorDwl implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** The start in prev mh. */
	private boolean startInPrevMh = false;

	/** The effective size. */
	private int effectiveSize;

	/** The total size. */
	private int totalSize = 0;

	/** The residual size. */
	private int residualSize;

	/** The pol. */
	private Polarization pol;

	/**
	 * Instantiates a new size of sector dwl.
	 *
	 * @param totalSize    the total size
	 * @param residualSize the residual size
	 * @param pol          the pol
	 */
	public SizeOfSectorDwl(int totalSize, int residualSize, Polarization pol) {
		super();
		this.effectiveSize = totalSize;
		this.startInPrevMh = false;
		this.totalSize = totalSize;
		this.residualSize = residualSize;
		this.setPol(pol);
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the userInfo
	 */
	@Override
	public String toString() {
		return "SizeOfSectorDwl [totalSize=" + this.totalSize + ", residualSize=" + this.residualSize + ", pol="
				+ this.pol + "]";
	}

	/**
	 * Gets the total size.
	 *
	 * @return the total size
	 */
	public int getTotalSize() {
		return this.totalSize;
	}

	/**
	 * Gets the residual size.
	 *
	 * @return the residual size
	 */
	public int getResidualSize() {
		return this.residualSize;
	}

	/**
	 * Sets the residual size.
	 *
	 * @param residualSize the new residual size
	 */
	public void setResidualSize(int residualSize) {
		this.residualSize = residualSize;
	}

	/**
	 * Gets the pol.
	 *
	 * @return the pol
	 */
	public Polarization getPol() {
		return this.pol;
	}

	/**
	 * Sets the pol.
	 *
	 * @param pol the pol to set
	 */
	public void setPol(Polarization pol) {
		this.pol = pol;
	}

	/**
	 * Gets the effective size.
	 *
	 * @return the effectiveSize
	 */
	public int getEffectiveSize() {
		return this.effectiveSize;
	}

	/**
	 * Sets the effective size.
	 *
	 * @param effectiveSize the effectiveSize to set
	 */
	public void setEffectiveSize(int effectiveSize) {
		this.effectiveSize = effectiveSize;
	}

	/**
	 * Checks if is start in prev mh.
	 *
	 * @return the startInPrevMh
	 */
	public boolean isStartInPrevMh() {
		return this.startInPrevMh;
	}

	/**
	 * Sets the start in prev mh.
	 *
	 * @param startInPrevMh the startInPrevMh to set
	 */
	public void setStartInPrevMh(boolean startInPrevMh) {
		this.startInPrevMh = startInPrevMh;
	}
}
