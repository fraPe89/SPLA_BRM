/**
*
* MODULE FILE NAME:	ReasonOfReject.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		15 mag 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 15 mag 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum ReasonOfReject.
 *
 * @author fpedrola
 */
public enum ReasonOfReject {
	systemConflict,

	internallyInconsistent,

	/** The outside MHDTO. */
	outsideMHDTO,

	/** The smoothing ess unranked. */
	smoothingEssUnranked,

	/** The cannot perform sat left acq. */
	cannotPerformSatLeftAcq,

	/** The theatre internally inconsistent. */
	theatreInternallyInconsistent,

	/** The invalid DTO size. */
	invalidDTOSize,

	/** The cannot perform bite. */
	cannotPerformBite,

	/** The no time for A maneuver. */
	noTimeForAManeuver,

	/** The max num theatre reached. */
	maxNumTheatreReached,

	/** The deleted for VU. */
	deletedForVU,

	/** The deleted for LMP. */
	deletedForLMP,

	/** The cannot perform experimental. */
	cannotPerformExperimental,

	/** The deleted for di 2 s. */
	deletedForDi2s,

	cannotPerformDi2s,

	/** The theatre overlap acquisition. */
	theatreOverlapAcquisition,

	/** The sensor mode not allowed. */
	sensorModeNotAllowed,

	/** The cannot perform calibration. */
	cannotPerformCalibration,

	/** The cannot perform stereopair. */
	cannotPerformStereopair,

	/** The no time for axes reconf. */
	noTimeForAxesReconf,

	/** The min distance violation. */
	minDistanceViolation,

	/** The left attitude mode violation. */
	leftAttitudeModeViolation,

	/** The more than left attitude time threshold. */
	moreThanLeftAttitudeTimeThreshold,

	/** The CMG formula violation. */
	CMGFormulaViolation,

	/** The reached orbit threshold. */
	reachedOrbitThreshold,

	/** The reached orbit threshold in eclipse. */
	reachedOrbitThresholdInEclipse,

	/** The bic not available. */
	bicNotAvailable,

	/** The acq overlap with acquisition. */
	acqOverlapWithAcquisition,

	/** The satellite unavailability. */
	satelliteUnavailability,

	/** The no space in pdht. */
	noSpaceInPdht,

	/** The cannot perform pass through. */
	cannotPerformPassThrough,

	/** The pass through overlap acq. */
	passThroughOverlapAcq,

	/** The maneuver overlap with acquisition. */
	maneuverOverlapWithAcquisition,

	/** The deleted by csps. */
	deletedByCsps,

	/** The acq overlap PAW. */
	acqOverlapPAW,

	/** The acq partial overlap PAW. */
	acqPartialOverlapPAW,

	/** The acq overlap hp exclusion segment. */
	acqOverlapHpExclusionSegment,

	/** The acq inconsistent with paw. */
	acqInconsistentWithPaw,

	/** The no energy for silent. */
	noEnergyForSilent,

	/** The no energy for silent in eclipse. */
	noEnergyForSilentInEclipse,

	/** The max number pr type. */
	maxNumberPrType,

	/** The ess left more than threshold. */
	essLeftMoreThanThreshold,

	/** The exceeded sensor mode max duration. */
	exceededSensorModeMaxDuration,

	/** The neo bic not available. */
	neoBicNotAvailable,

	/** The max peaks reached. */
	maxPeaksReached,

	/** The acq overlap theatre. */
	acqOverlapTheatre,

	/** The Hp fixed orbit limit reached. */
	HpFixedOrbitLimitReached,

	/** The acq overlap with pass through. */
	acqOverlapWithPassThrough,

	/** The max number of total maneuver reached. */
	maxNumberOfTotalManeuverReached,

	/** The max number of CMGA maneuver reached. */
	maxNumberOfCMGAManeuverReached,

	/** The max number of RW maneuver reached. */
	maxNumberOfRWManeuverReached,

	/** The acq partial overlap hp exclusion segment. */
	acqPartialOverlapHpExclusionSegment,

	/** The more than upper bound peaks bic. */
	moreThanUpperBoundPeaksBic,

	/** The maneuver overlap dlo or paw. */
	maneuverOverlapDloOrPaw
}
