/**
 *
 * MODULE FILE NAME: ManeuverResources.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.ArrayList;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;

/**
 * The Class ManeuverResources.
 */
public class ManeuverResources {

	/** The possible. */
	private boolean possible;

	/** The old mans. */
	private List<Maneuver> oldMans;

	/** The old rumps. */
	private List<RampCMGA> oldRumps;

	/** The new mans. */
	private List<Maneuver> newMans;

	/** The new rumps. */
	private List<RampCMGA> newRumps;

	/** The sat id. */
	private String satId;

	/**
	 * Instantiates a new maneuver resources.
	 */
	public ManeuverResources() {
		super();
		this.possible = true;
		this.oldMans = new ArrayList<>();
		this.oldRumps = new ArrayList<>();
		this.newMans = new ArrayList<>();
		this.newRumps = new ArrayList<>();
	}

	/**
	 * Checks if is possible.
	 *
	 * @return true, if is possible
	 */
	public boolean isPossible() {
		return this.possible;
	}

	/**
	 * Sets the possible.
	 *
	 * @param possible the new possible
	 */
	public void setPossible(boolean possible) {
		this.possible = possible;
	}

	/**
	 * Gets the old mans.
	 *
	 * @return the old mans
	 */
	public List<Maneuver> getOldMans() {
		return this.oldMans;
	}

	/**
	 * Sets the old mans.
	 *
	 * @param oldMans the new old mans
	 */
	public void setOldMans(List<Maneuver> oldMans) {
		this.oldMans = oldMans;
	}

	/**
	 * Gets the old rumps.
	 *
	 * @return the old rumps
	 */
	public List<RampCMGA> getOldRumps() {
		return this.oldRumps;
	}

	/**
	 * Sets the old rumps.
	 *
	 * @param oldRumps the new old rumps
	 */
	public void setOldRumps(List<RampCMGA> oldRumps) {
		this.oldRumps = oldRumps;
	}

	/**
	 * Gets the new mans.
	 *
	 * @return the new mans
	 */
	public List<Maneuver> getNewMans() {
		return this.newMans;
	}

	/**
	 * Sets the new mans.
	 *
	 * @param newMans the new new mans
	 */
	public void setNewMans(List<Maneuver> newMans) {
		this.newMans = newMans;
	}

	/**
	 * Gets the new rumps.
	 *
	 * @return the new rumps
	 */
	public List<RampCMGA> getNewRumps() {
		return this.newRumps;
	}

	/**
	 * Sets the new rumps.
	 *
	 * @param newRumps the new new rumps
	 */
	public void setNewRumps(List<RampCMGA> newRumps) {
		this.newRumps = newRumps;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the maneuverResources
	 */
	@Override
	public String toString() {
		return "ManeuverResources [possible=" + this.possible + ", oldMans=" + this.oldMans + ", oldRumps="
				+ this.oldRumps + ", newMans=" + this.newMans + ", newRumps=" + this.newRumps + "]";
	}

	/**
	 * Gets the sat id.
	 *
	 * @return the sat id
	 */
	public String getSatId() {
		return this.satId;
	}

	/**
	 * Sets the sat id.
	 *
	 * @param satId the new sat id
	 */
	public void setSatId(String satId) {
		this.satId = satId;
	}

}
