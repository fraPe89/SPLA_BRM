/**
 *
 * MODULE FILE NAME: BicHpPeakOrbit.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

// TODO: Auto-generated Javadoc
/**
 * The Class BicHpPeakOrbit.
 */
public class BicHpPeakOrbit {

	/** The type. */
	private String type;

	/** The bic hp. */
	private double bicHp;

	/** The acq id. */
	private String acqId;

	/** The total ess. */
	private double totalEss;

	/**
	 * Instantiates a new bic hp peak orbit.
	 *
	 * @param type  the type
	 * @param bicHp the bic hp
	 * @param acqId the acq id
	 */
	public BicHpPeakOrbit(String type, double bicHp, String acqId) {
		super();
		this.type = type;
		this.bicHp = bicHp;
		this.acqId = acqId;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "BicHpPeakOrbit [type=" + this.type + ", bicHp=" + this.bicHp + ", acqId=" + this.acqId + ", totalEss="
				+ this.totalEss + "]";
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Gets the bic hp.
	 *
	 * @return the bic hp
	 */
	public double getBicHp() {
		return this.bicHp;
	}

	/**
	 * Gets the acq id.
	 *
	 * @return the acq id
	 */
	public String getAcqId() {
		return this.acqId;
	}

	/**
	 * Gets the total ess.
	 *
	 * @return the total ess
	 */
	public double getTotalEss() {
		return this.totalEss;
	}

	/**
	 * Sets the total ess.
	 *
	 * @param totalEss the new total ess
	 */
	public void setTotalEss(double totalEss) {
		this.totalEss = totalEss;
	}

}
