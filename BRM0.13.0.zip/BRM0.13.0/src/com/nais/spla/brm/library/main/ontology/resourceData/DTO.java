/**
*
* MODULE FILE NAME: DTO.java
*
* MODULE TYPE:      <Class definition>
*
* FUNCTION:         <Functional description of the DDC>
*
* PURPOSE:          <List of SR>
*
* CREATION DATE:    <17-NOV-2016>
*
* AUTHORS:          Francesca Pedrola
*
* DESIGN ISSUE:     0.1
*
* INTERFACES:       <prototype and list of input/output parameters>
*
* SUBORDINATES:     <list of functions called by this DDC>
*
* MODIFICATION HISTORY:
*
*             Date          |  Name      |   New ver.     | Description
* --------------------------+------------+----------------+-------------------------------
* <DD-MMM-YYYY>             | <name>     |<Ver>.<Rel>     | <reasons of changes>
* --------------------------+------------+----------------+-------------------------------
*
* PROCESSING
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;

// TODO: Auto-generated Javadoc
/**
 * This class models the task associated with a Data Take Opportunity (DTO).
 */
@SuppressWarnings("serial")
public class DTO implements Serializable {

	/** The key. */
	private long key;

	/** The dto id. */
	private String dtoId;

	/** The priority. */
	private int priority;

	/** date that identifies the start time of the dto. */
	private Date startTime;

	/** date that identifies the end time of the dto. */
	private Date endTime;

	/** String that identifies the lookside of the dto. */
	private String lookSide;

	/** The size of H polarization. */
	private int sizeH;

	/** The size of V polarization. */
	private int sizeV;

	/** The satellite id. */
	private String satelliteId;

	/** The sensor mode. */
	private TypeOfAcquisition sensorMode;

	/** The pol. */
	private Polarization pol;

	/** The time performance. */
	private boolean timePerformance = false;

	/** The image BIC. */
	private double imageBIC;

	/** The ar ID. */
	private String arID;

	/** The pr type. */
	private PRType prType;

	/** The pr mode. */
	private PRMode prMode;

	/** The task mark. */
	private TaskMarkType taskMark;

	/** The neo available. */
	private boolean neoAvailable;

	/** The di 2 s. */
	private boolean di2s;

	/** The revolution number. */
	private int revolutionNumber;

	/** The interleaved channel. */
	private int interleavedChannel;

	/** The preferred vis. */
	private List<String> preferredVis = null;

	/** The backup vis. */
	private List<String> backupVis = null;

	/** The partners associated to dto. */
	private List<UserInfo> userInfo;

	/** The is pt available. */
	private boolean isPtAvailable;

	/** The replaced request list id. */
	private List<String> replacedRequestListId = null;

	/** The is stereopair. */
	private boolean isStereopair;

	/** The linked dto id. */
	private String linkedDtoId;

	/** The referred equivalent dto. */
	private String referredEquivalentDto;

	/** The rejected. */
	private boolean rejected = false;

	/** The reason of reject. */
	private ReasonOfReject reasonOfReject;

	// set it to true if the dto is inserted into Drools as element processed
	/** The previous session. */
	// and accepted in a previous session
	private boolean previousSession = false;

	/** The previously processed. */
	private boolean previousMh = false;

	/**
	 * Checks if is previous mh.
	 *
	 * @return true, if is previous mh
	 */
	public boolean isPreviousMh() {
		return this.previousMh;
	}

	/**
	 * Sets the previous mh.
	 *
	 * @param previousMh the new previous mh
	 */
	public void setPreviousMh(boolean previousMh) {
		this.previousMh = previousMh;
	}

	/** The decrement Bic. */
	private boolean decrementBic = true;

	/** The associated bite. */
	private Bite associatedBite = null;

	/**
	 * parameterized Constructor.
	 *
	 * @param dtoId       the dto id
	 * @param startTime   the start time
	 * @param endTime     the end time
	 * @param lookSide    the look side
	 * @param satelliteId the satellite id
	 * @param sensorMode  the sensor mode
	 * @param pol         the pol
	 */
	public DTO(String dtoId, Date startTime, Date endTime, String lookSide, String satelliteId,
			TypeOfAcquisition sensorMode, Polarization pol) {
		this.setDecrementBic(true);
		this.dtoId = dtoId;
		this.startTime = startTime;
		this.satelliteId = satelliteId;
		this.endTime = endTime;
		this.lookSide = lookSide;
		this.sensorMode = sensorMode;
		this.pol = pol;
		this.sizeH = 0;
		this.sizeV = 0;
		this.prType = PRType.HP;
		this.neoAvailable = false;
		this.di2s = false;
		this.isPtAvailable = false;
		this.preferredVis = new ArrayList<>();
		this.backupVis = new ArrayList<>();
		this.revolutionNumber = 0;
		this.previousSession = false;
		this.previousMh = false;
		this.setUserInfo(null);
	}

	/**
	 * Instantiates a new dto.
	 */
	public DTO() {

		super();
	}

	/**
	 * Sets the look side.
	 *
	 * @param lookSide the lookSide to set
	 */
	public void setLookSide(String lookSide) {
		this.lookSide = lookSide;
	}

	/**
	 * Sets the dto id.
	 *
	 * @param dtoId the new dto id
	 */
	public void setDtoId(String dtoId) {
		this.dtoId = dtoId;
	}

	/**
	 * Gets the ar ID.
	 *
	 * @return the ar ID
	 */
	public String getArID() {
		return this.arID;
	}

	/**
	 * Gets the dto id.
	 *
	 * @return the dto id
	 */
	public String getDtoId() {
		return this.dtoId;
	}

	/**
	 * Gets the end time.
	 *
	 * @return the end time (when the DTO ends)
	 */
	public Date getEndTime() {
		return this.endTime;
	}

	/**
	 * Gets the image BIC.
	 *
	 * @return the image BIC
	 */
	public double getImageBIC() {
		return this.imageBIC;
	}

	/**
	 * Gets the key.
	 *
	 * @return the key
	 */
	public long getKey() {
		return this.key;
	}

	/**
	 * Gets the look side.
	 *
	 * @return the look side of the DTO
	 */
	public String getLookSide() {
		return this.lookSide;
	}

	/**
	 * Gets the pol.
	 *
	 * @return the pol
	 */
	public Polarization getPol() {
		return this.pol;
	}

	/**
	 * Gets the pr type.
	 *
	 * @return the pr type
	 */
	public PRType getPrType() {
		return this.prType;
	}

	/**
	 * Gets the revolution number.
	 *
	 * @return the revolution number
	 */
	public int getRevolutionNumber() {
		return this.revolutionNumber;
	}

	/**
	 * Gets the sensor mode.
	 *
	 * @return the sensor mode
	 */
	public TypeOfAcquisition getSensorMode() {
		return this.sensorMode;
	}

	/**
	 * Gets the start time.
	 *
	 * @return the start time (when the dto begins)
	 */
	public Date getStartTime() {
		return this.startTime;
	}

	/**
	 * Checks if is neo available.
	 *
	 * @return true, if is neo available
	 */
	public boolean isNeoAvailable() {
		return this.neoAvailable;
	}

	/**
	 * Sets the ar ID.
	 *
	 * @param arID the new ar ID
	 */
	public void setArID(String arID) {
		this.arID = arID;
	}

	/**
	 * Sets the image BIC.
	 *
	 * @param imageBIC the new image BIC
	 */
	public void setImageBIC(double imageBIC) {
		this.imageBIC = imageBIC;
	}

	/**
	 * Sets the key.
	 *
	 * @param key the new key
	 */
	public void setKey(long key) {
		this.key = key;
	}

	/**
	 * Sets the neo available.
	 *
	 * @param neoAvailable the new neo available
	 */
	public void setNeoAvailable(boolean neoAvailable) {
		this.neoAvailable = neoAvailable;
	}

	/**
	 * Sets the pol.
	 *
	 * @param pol the new pol
	 */
	public void setPol(Polarization pol) {
		this.pol = pol;
	}

	/**
	 * Sets the pr type.
	 *
	 * @param prType the new pr type
	 */
	public void setPrType(PRType prType) {
		this.prType = prType;
	}

	/**
	 * Sets the revolution number.
	 *
	 * @param revolutionNumber the new revolution number
	 */
	public void setRevolutionNumber(int revolutionNumber) {
		this.revolutionNumber = revolutionNumber;
	}

	/**
	 * Sets the sensor mode.
	 *
	 * @param sensorMode the new sensor mode
	 */
	public void setSensorMode(TypeOfAcquisition sensorMode) {
		this.sensorMode = sensorMode;
	}

	/**
	 * Gets the size H.
	 *
	 * @return the size H
	 */
	public int getSizeH() {
		return this.sizeH;
	}

	/**
	 * Sets the size H.
	 *
	 * @param sizeH the new size H
	 */
	public void setSizeH(int sizeH) {
		this.sizeH = sizeH;
	}

	/**
	 * Gets the size V.
	 *
	 * @return the size V
	 */
	public int getSizeV() {
		return this.sizeV;
	}

	/**
	 * Sets the size V.
	 *
	 * @param sizeV the new size V
	 */
	public void setSizeV(int sizeV) {
		this.sizeV = sizeV;
	}

	/**
	 * Checks if is pt available.
	 *
	 * @return true, if is pt available
	 */
	public boolean isPtAvailable() {
		return this.isPtAvailable;
	}

	/**
	 * Sets the pt available.
	 *
	 * @param isPtAvailable the new pt available
	 */
	public void setPtAvailable(boolean isPtAvailable) {
		this.isPtAvailable = isPtAvailable;
	}

	/**
	 * Gets the referred equivalent dto.
	 *
	 * @return the referred equivalent dto
	 */
	public String getReferredEquivalentDto() {
		return this.referredEquivalentDto;
	}

	/**
	 * Sets the referred equivalent dto.
	 *
	 * @param referredEquivalentDto the new referred equivalent dto
	 */
	public void setReferredEquivalentDto(String referredEquivalentDto) {
		this.referredEquivalentDto = referredEquivalentDto;
	}

	/**
	 * Gets the task mark.
	 *
	 * @return the task mark
	 */
	public TaskMarkType getTaskMark() {
		return this.taskMark;
	}

	/**
	 * Sets the task mark.
	 *
	 * @param taskMark the new task mark
	 */
	public void setTaskMark(TaskMarkType taskMark) {
		this.taskMark = taskMark;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Sets the satellite id.s
	 *
	 * @param satelliteId the new satellite id
	 */
	public void setSatelliteId(String satelliteId) {
		this.satelliteId = satelliteId;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return this.priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * Checks if is di 2 s.
	 *
	 * @return true, if is di 2 s
	 */
	public boolean isDi2s() {
		return this.di2s;
	}

	/**
	 * Sets the di 2 s.
	 *
	 * @param di2s the new di 2 s
	 */
	public void setDi2s(boolean di2s) {
		this.di2s = di2s;
	}

	/**
	 * Gets the user info.
	 *
	 * @return the user info
	 */
	public List<UserInfo> getUserInfo() {
		return this.userInfo;
	}

	/**
	 * Sets the user info.
	 *
	 * @param userInfo the new user info
	 */
	public void setUserInfo(List<UserInfo> userInfo) {
		this.userInfo = userInfo;
	}

	/**
	 * Sets the start time.
	 *
	 * @param startTime the new start time
	 */
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * Sets the end time.
	 *
	 * @param endTime the new end time
	 */
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	/**
	 * Gets the preferred vis.
	 *
	 * @return the preferredVis
	 */
	public List<String> getPreferredVis() {
		return this.preferredVis;
	}

	/**
	 * Sets the preferred vis.
	 *
	 * @param preferredVis the preferredVis to set
	 */
	public void setPreferredVis(List<String> preferredVis) {
		this.preferredVis = preferredVis;
	}

	/**
	 * Checks if is rejected.
	 *
	 * @return the rejected
	 */
	public boolean isRejected() {
		return this.rejected;
	}

	/**
	 * Sets the rejected.
	 *
	 * @param rejected the rejected to set
	 */
	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}

	/**
	 * Gets the pr mode.
	 *
	 * @return the prMode
	 */
	public PRMode getPrMode() {
		return this.prMode;
	}

	/**
	 * Sets the pr mode.
	 *
	 * @param prMode the prMode to set
	 */
	public void setPrMode(PRMode prMode) {
		this.prMode = prMode;
	}

	/**
	 * Gets the interleaved channel.
	 *
	 * @return the interleavedChannel
	 */
	public int getInterleavedChannel() {
		return this.interleavedChannel;
	}

	/**
	 * Sets the interleaved channel.
	 *
	 * @param interleavedChannel the interleavedChannel to set
	 */
	public void setInterleavedChannel(int interleavedChannel) {
		this.interleavedChannel = interleavedChannel;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		/*
		 * toString del metodo 
		 * che restituise tutte 
		 * le caratterstiche del 
		 * DTO instanziato
		 */
		return "DTO [key=" + this.key + ", dtoId=" + this.dtoId + ", priority=" + this.priority + ", startTime="
				+ this.startTime + ", endTime=" + this.endTime + ", lookSide=" + this.lookSide + ", sizeH=" + this.sizeH
				+ ", sizeV=" + this.sizeV + ", satelliteId=" + this.satelliteId + ", sensorMode=" + this.sensorMode
				+ ", pol=" + this.pol + ", imageBIC=" + this.imageBIC + ", arID=" + this.arID + ", prType="
				+ this.prType + ", prMode=" + this.prMode + ", taskMark=" + this.taskMark + ", neoAvailable="
				+ this.neoAvailable + ", di2s=" + this.di2s + ", revolutionNumber=" + this.revolutionNumber
				+ ", interleavedChannel=" + this.interleavedChannel + ", preferredVis=" + this.preferredVis
				+ ", userInfo=" + this.userInfo + ", isPtAvailable=" + this.isPtAvailable + ", referredEquivalentDto="
				+ this.referredEquivalentDto + ", rejected=" + this.rejected + ", previousSession ="
				+ this.previousSession + " , previousMh =" + this.previousMh + "]";
	}

	/**
	 * Gets the reason of reject.
	 *
	 * @return the reasonOfReject
	 */
	public ReasonOfReject getReasonOfReject() {
		return this.reasonOfReject;
	}

	/**
	 * Sets the reason of reject.
	 *
	 * @param reasonOfReject the reasonOfReject to set
	 */
	public void setReasonOfReject(ReasonOfReject reasonOfReject) {
		this.reasonOfReject = reasonOfReject;
	}

	/**
	 * Gets the linked dto id.
	 *
	 * @return the linkedDtoId
	 */
	public String getLinkedDtoId() {
		return this.linkedDtoId;
	}

	/**
	 * Sets the linked dto id.
	 *
	 * @param linkedDtoId the linkedDtoId to set
	 */
	public void setLinkedDtoId(String linkedDtoId) {
		this.linkedDtoId = linkedDtoId;
	}

	/**
	 * Checks if is stereopair.
	 *
	 * @return the isStereopair
	 */
	public boolean isStereopair() {
		return this.isStereopair;
	}

	/**
	 * Sets the stereopair.
	 *
	 * @param isStereopair the isStereopair to set
	 */
	public void setStereopair(boolean isStereopair) {
		this.isStereopair = isStereopair;
	}

	/**
	 * Gets the associated bite.
	 *
	 * @return the associatedBite
	 */
	public Bite getAssociatedBite() {
		return this.associatedBite;
	}

	/**
	 * Sets the associated bite.
	 *
	 * @param associatedBite the associatedBite to set
	 */
	public void setAssociatedBite(Bite associatedBite) {
		this.associatedBite = associatedBite;
	}

	/**
	 * Gets the replaced request list id.
	 *
	 * @return the replacedRequestListId
	 */
	public List<String> getReplacedRequestListId() {
		return this.replacedRequestListId;
	}

	/**
	 * Sets the replaced request list id.
	 *
	 * @param replacedRequestListId the replacedRequestListId to set
	 */
	public void setReplacedRequestListId(List<String> replacedRequestListId) {
		this.replacedRequestListId = replacedRequestListId;
	}

	/**
	 * Checks if is decrement bic.
	 *
	 * @return true, if is decrement bic
	 */
	public boolean isDecrementBic() {
		return this.decrementBic;
	}

	/**
	 * Sets the decrement bic.
	 *
	 * @param decrementBic the new decrement bic
	 */
	public void setDecrementBic(boolean decrementBic) {
		this.decrementBic = decrementBic;
	}

	/**
	 * Checks if is time performance.
	 *
	 * @return true, if is time performance
	 */
	public boolean isTimePerformance() {
		return this.timePerformance;
	}

	/**
	 * Sets the time performance.
	 *
	 * @param timePerformance the new time performance
	 */
	public void setTimePerformance(boolean timePerformance) {
		this.timePerformance = timePerformance;
	}

	/**
	 * Gets the backup vis.
	 *
	 * @return the backup vis
	 */
	public List<String> getBackupVis() {
		return this.backupVis;
	}

	/**
	 * Sets the backup vis.
	 *
	 * @param backupVis the new backup vis
	 */
	public void setBackupVis(List<String> backupVis) {
		this.backupVis = backupVis;
	}

	/**
	 * Checks if is previous session.
	 *
	 * @return true, if is previous session
	 */
	public boolean isPreviousSession() {
		return this.previousSession;
	}

	/**
	 * Sets the previous session.
	 *
	 * @param previousSession the new previous session
	 */
	public void setPreviousSession(boolean previousSession) {
		this.previousSession = previousSession;
	}

}
