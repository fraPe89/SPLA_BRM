
/**
*
* MODULE FILE NAME:	Silent.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		05 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 05 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;

/**
 * The Class Silent.
 *
 * @author fpedrola
 */
@SuppressWarnings("serial")
public class Silent extends Task {

	/** The associated acq. */
	private String associatedAcq;

	/** The energy. */
	private double energy;

	/** The loan from ess. */
	private double loanFromEss;

	/**
	 * Instantiates a new silent.
	 */
	public Silent() {
		super();

	}

	/**
	 * Instantiates a new silent.
	 *
	 * @param associatedAcq the associated acq
	 * @param energy        the energy
	 */
	public Silent(String associatedAcq, double energy) {
		super();
		// set the task type
		super.setTaskType(TaskType.SILENT);

		// set the associated acq
		this.associatedAcq = associatedAcq;

		// set the related energy
		this.energy = energy;
	}

	/**
	 * Instantiates a new silent.
	 *
	 * @param associatedAcq the associated acq
	 * @param startTime     the start time
	 * @param endTime       the end time
	 * @param energy        the energy
	 */
	public Silent(String associatedAcq, Date startTime, Date endTime, double energy) {
		super();

		// set the idTask
		super.setIdTask(associatedAcq);

		// set the task type
		this.setTaskType(TaskType.SILENT);

		// link the associated acq
		this.associatedAcq = associatedAcq;

		// set the start time
		this.setStartTime(startTime);

		// set the stop time
		this.setEndTime(endTime);

		// set the energy
		this.energy = energy;
	}

	/**
	 * Gets the associated acq.
	 *
	 * @return the associated acq
	 */
	public String getAssociatedAcq() {
		return this.associatedAcq;
	}

	/**
	 *  
	 * return the end time of the silent.
	 *
	 * @return the silent end time
	 */
	@Override
	public Date getEndTime() {
		return super.getEndTime();
	}

	/**
	 * Gets the energy.
	 *
	 * @return the energy
	 */
	public double getEnergy() {
		return this.energy;
	}
	
	/**
	 * Gets the loan from ess.
	 *
	 * @return the loan from ess
	 */
	public double getLoanFromEss() {
		return this.loanFromEss;
	}

	/**
	 *  
	 * get the task type.
	 *
	 * @return the task type of the silent
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/**
	 *  
	 * set the task type.
	 *
	 * @param taskType the new task type
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}

	/**
	 *  
	 * get the satellite id .
	 *
	 * @return the satellite id
	 */
	@Override
	public String getSatelliteId() {
		return super.getSatelliteId();
	}

	/**
	 *  
	 * return the start time of the silent.
	 *
	 * @return the silent startTime
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/**
	 *  
	 *  set the end time of the silent.
	 *
	 * @param end the new end time
	 */
	@Override
	public void setEndTime(Date end) {
		super.setEndTime(end);
	}

	/**
	 * Sets the loan from ess.
	 *
	 * @param loanFromEss the new loan from ess
	 */
	public void setLoanFromEss(double loanFromEss) {
		this.loanFromEss = loanFromEss;
	}

	/**
	 *  
	 * set the satellite id.
	 *
	 * @param satelliteId the new satellite id
	 */
	@Override
	public void setSatelliteId(String satelliteId) {
		super.setSatelliteId(satelliteId);
	}

	/**
	 *  
	 * set the start time of the silent.
	 *
	 * @param start the new start time
	 */
	@Override
	public void setStartTime(Date start) {
		super.setStartTime(start);
	}

	/**
	 *  
	 * return the taskMark
	 * return the task mark.
	 *
	 * @return the task mark
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/**
	 *  
	 * set the task id.
	 *
	 * @param idTask the new id task
	 */
	@Override
	public void setIdTask(String idTask) {
		super.setIdTask(idTask);
	}

	/**
	 *  
	 * return the id of the task.
	 *
	 * @return the task id
	 */
	@Override
	public String getIdTask() {
		return super.getIdTask();
	}

	/**
	 *  
	 * set the task mark.
	 *
	 * @param taskMark the new task mark
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Silent [associatedAcq=" + this.associatedAcq + ", energy=" + this.energy + ", loanFromEss="
				+ this.loanFromEss + ", getStartTime()=" + getStartTime() + ", getEndTime()=" + getEndTime() + "]";
	}

}
