/**
*
* MODULE FILE NAME: DroolsEnvironment.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.ReleaseId;
import org.kie.api.builder.model.KieBaseModel;
import org.kie.api.builder.model.KieModuleModel;
import org.kie.api.builder.model.KieSessionModel;
import org.kie.api.conf.EqualityBehaviorOption;
import org.kie.api.conf.EventProcessingOption;
import org.kie.api.io.Resource;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.conf.ClockTypeOption;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.functions.BicManagement;
import com.nais.spla.brm.library.main.drools.functions.CMGAManeuverManagement;
import com.nais.spla.brm.library.main.drools.functions.CMGAxisReconfigManagement;
import com.nais.spla.brm.library.main.drools.functions.EclipseManagement;
import com.nais.spla.brm.library.main.drools.functions.EssEnergyManagement;
import com.nais.spla.brm.library.main.drools.functions.HpOrbitalExclusionManagement;
import com.nais.spla.brm.library.main.drools.functions.LeftAttitudeProfileManagement;
import com.nais.spla.brm.library.main.drools.functions.ManeuverManagement;
import com.nais.spla.brm.library.main.drools.functions.PassThroughManagement;
import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
import com.nais.spla.brm.library.main.drools.functions.PeakManagement;
import com.nais.spla.brm.library.main.drools.functions.SilentManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.EnvironmentUtils;
import com.nais.spla.brm.library.main.drools.utils.SetResources;
import com.nais.spla.brm.library.main.exception.ConfigurationException;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.LowerAndUpperBoundPowers;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ConfigMaps;
import com.nais.spla.brm.library.main.ontology.utils.MinTimeRight;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

/**
 * The Class DroolsEnvironment.
 */
public class DroolsEnvironment {

	/** The du. */
	DroolsUtils du = null;

	EnvironmentUtils envUtils = null;

	/** The current session. */
	static int currentSession = 0;

	/** The Constant SPLA_HOME. */
	public static final String SPLA_HOME = "SPLA_HOME";

	/** The Constant SPLA_ENV. */
	public static final String SPLA_ENV = "SPLA_ENV";

	/** The Constant CONFIG_FILENAME. */
	private static final String CONFIG_FILENAME = "brm.properties";

	/** The Constant MAX_DURATION_SENSOR_MODE_CONFIG_FILENAME. */
	private static final String MAX_DURATION_SENSOR_MODE_CONFIG_FILENAME = "sensor_mode_max_duration.properties";

	/** The Constant CONFIG_FILENAME. */
	private static final String MAX_TIME_LEFT_FILENAME = "maxTimeLeft.txt";

	/** The Constant POWER_SENSOR_MODE_CONFIG_FILENAME. */
	private static final String POWER_SENSOR_MODE_CONFIG_FILENAME = "sensor_mode_power.properties";

	/** The Constant POWER_SENSOR_MODE_CONFIG_FILENAME. */
	private static final String FIRST_SATELLITE_CONFIG_FILENAME = "sat1.properties";

	/** The Constant POWER_SENSOR_MODE_CONFIG_FILENAME. */
	private static final String SECOND_SATELLITE_CONFIG_FILENAME = "sat2.properties";

	/** The Constant MIN_DISTANCE_CONFIG_FILENAME. */
	private static final String MIN_DISTANCE_CONFIG_FILENAME = "minimum_distances_acquisition.properties";

	/** The Constant T_STANDARD_CONFIG_FILENAME. */
	private static final String T_STANDARD_CONFIG_FILENAME = "tStandard.properties";

	/** The Constant T_THRESHOLD_CONFIG_FILENAME. */
	private static final String T_THRESHOLD_CONFIG_FILENAME = "tThreshold.properties";

	/** The Constant CONFIG_FILENAME. */
	private static final String CONFIG_CMGA_FILENAME = "cmgProperties.properties";

	// private static final String REASON_OF_REJECT_FILENAME =
	// "reasonOfReject.properties";
	//
	// private static final String ESS_PAW_FILENAME =
	// "essPawConsumption.properties";
	//
	// private static final String MANEUVER_PAW_FILENAME =
	// "maneuverPawConsumption.properties";

	/** The kie cont. */
	private KieContainer kieCont = null;

	/** The powers sensor mode. */
	private Map<TypeOfAcquisition, Double> powersSensorMode = null;

	/** The max duration sensor mode. */
	private Map<TypeOfAcquisition, Double> maxDurationSensorMode = null;

	/** The t standard map. */
	private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tStandardMap = null;

	/** The t threshold map. */
	private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tThresholdMap = null;

	/** The min distance map. */
	private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap = null;

	// private Map<ReasonOfReject, ComplexReason> reasonOfRejectMap = null;

	/** The satellite properties related to the satellite 1 */
	private SatelliteProperties satProp1 = null;

	/** The satellite properties related to the satellite 2. */
	private SatelliteProperties satProp2 = null;

	/** The spla path. */
	private String splaPath;

	/** The spla env. */
	private String splaEnv;

	/** The complete path. */
	private String completePath;

	/** The module name. */
	private final String moduleName;

	/** The prop. */
	private final Properties prop;

	/** The max duration sensor mode prop. */
	private final Properties maxDurationSensorModeProp;

	/** The power sensor mode prop. */
	private final Properties powerSensorModeProp;

	/** The T standard prop. */
	private final Properties TStandardProp;

	/** The t threshold prop. */
	private final Properties tThresholdProp;

	/** The min distance prop. */
	private final Properties minDistanceProp;

	// private final Properties reasonOfRejectProp;

	/** The CMGA properties. */
	private final Properties cmgaProp;

	/** The sat 1 prop. */
	private final Properties sat1Prop;

	/** The sat 2 prop. */
	private final Properties sat2Prop;

	/** The config maps. */
	private ConfigMaps configMaps;

	/**
	 * Instantiates a new drools environment.
	 *
	 * @param moduleName the module name
	 */
	public DroolsEnvironment(String moduleName) {
		this.du = new DroolsUtils();

		// the path where are stored all the configuration files
		this.splaPath = null;

		// the variable that indicate the type of environment
		this.splaEnv = null;

		// initialize the EnvironmentUtils
		this.envUtils = new EnvironmentUtils();

		// set the moduleName
		this.moduleName = moduleName;

		// initialize the configurationMap with all the values defined for
		// sensormodes
		this.configMaps = new ConfigMaps();

		// initialize the satellite properties relative to the two satellites
		this.satProp1 = new SatelliteProperties();
		this.satProp2 = new SatelliteProperties();

		// create all the properties
		this.prop = new Properties();

		// create the properties for powers of every sensor mode
		this.powerSensorModeProp = new Properties();

		// create the properties for the max durations of every sensor mode
		this.maxDurationSensorModeProp = new Properties();

		// create the properties for the standard distance between sensor mode
		// (for the computation of silent)
		this.TStandardProp = new Properties();

		// create the properties for the threshold distance between sensor mode
		// (for the computation of silent)
		this.tThresholdProp = new Properties();

		// create the properties for the minimum distance between sensor mode
		// (for the computation of silent)
		this.minDistanceProp = new Properties();

		// create the properties for the properties associated with the cmg
		// units
		this.cmgaProp = new Properties();

		// create the properties for the variables relative to the first
		// satellite
		this.sat1Prop = new Properties();

		// create the properties for the variables relative to the second
		// satellite
		this.sat2Prop = new Properties();

		// this.reasonOfRejectProp = new Properties();
		// create the map for all the sensor mode powers
		this.powersSensorMode = new HashMap<>();

		// create the map for all the max durations of sensor mode
		this.maxDurationSensorMode = new HashMap<>();

		// create the map for all the standard times for sensor modes
		this.tStandardMap = new HashMap<>();

		// create the map for all the threshold times for sensor modes
		this.tThresholdMap = new HashMap<>();

		// create the map for all the min distances times between sensor modes
		this.minDistanceMap = new HashMap<>();

		// this.reasonOfRejectMap = new HashMap<>();
	}

	/**
	 * Sets the up fixed orbit hp map.
	 *
	 * @param droolsParams the new up fixed orbit hp map
	 * @throws ConfigurationException 
	 */
	public void setUpFixedOrbitHpMap(DroolsParameters droolsParams, DroolsOperations droolsOperations) throws ConfigurationException {
		// create an hashmap to memorize the hpFixedOrbit (used only for test)
		Map<String, Map<Integer, Double>> maxHpBicFixedOrbit = new HashMap<>();

		// define the path of properties file
		String MAX_HP_BIC_FOR_FIXED_ORBIT = "maxHpForFixedOrbit.properties";

		// define a new Properties to store the values taken from file
		Properties maxHpForFixedOrbitProp = new Properties();


			// setup the local repository
			String localRepo = droolsParams.getLocalRepo();

			// set the boolean variable to true only for this method ( for test
			// ), externally the fixed orbit map is received from DPL
			boolean useLocalPath = false;

			// load the properties using the local path
			this.envUtils.loadPropertiesFile(MAX_HP_BIC_FOR_FIXED_ORBIT, maxHpForFixedOrbitProp, localRepo,
					this.completePath, this.moduleName, useLocalPath);

			// populate the map with the properties taken above
			droolsOperations.getDroolsEnvironment().populateFixedOrbitMap(maxHpBicFixedOrbit, maxHpForFixedOrbitProp);

			// set the droolsParams with the map just created
			droolsParams.setMaxHpBicFixedOrbit(maxHpBicFixedOrbit);

	}

	/**
	 * Concatene path.
	 *
	 * @param path the path
	 * @param name the name
	 * @return the string
	 */
	public static String concatenePath(String path, String name) {
		// initialize the string that must be returned from this method with the
		// path given as input
		String tmp = path;

		// check the last part of path to see if ends with the \ char
		if (!path.endsWith(File.separator)) {
			// if not, add it
			tmp += File.separator;
		}
		if (path.contains("config")) {
			// concatenate the filename
			tmp += name;
		} else {
			// concatenate the filename
			tmp += name + File.separator + "config";
		}
		return tmp;
	}

	/**
	 * Compose complete module path.
	 */
	public String composeCompleteModulePath() {
		// invoke the function for compose the file path
		return concatenePath(this.splaPath, this.moduleName);
	}

	/**
	 * Creates the kie container.
	 *
	 * @param sessionId        the session id
	 * @param numberOfSessions the number of sessions
	 * @param droolsParams     the drools params
	 * @return the kie container
	 */
	public KieContainer createKieContainer(String sessionId, int numberOfSessions, DroolsParameters droolsParams) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// check if the session is a valid one, otherwise catch the exception
		// sessionId = this.envUtils.checkSessionId(sessionId);

		// get the current kieService
		KieServices kieServices = KieServices.Factory.get();

		// create a new kieModule
		KieModuleModel kieModuleModel = kieServices.newKieModuleModel();

		// create an abstract kieBase
		KieBaseModel kieBaseModel = kieModuleModel.newKieBaseModel("KBase").setDefault(true)
				.setEqualsBehavior(EqualityBehaviorOption.EQUALITY)
				.setEventProcessingMode(EventProcessingOption.STREAM);

		// iterate over the number of session of Drools that we want load
		for (int i = 0; i < numberOfSessions; i++) {
			String kieNameId = "KS_" + sessionId + "_" + i;
			// create a SessionStateful so changes in the facts while executing
			// rules are triggered by the rule engine.
			kieBaseModel.newKieSessionModel(kieNameId).setType(KieSessionModel.KieSessionType.STATEFUL)
					.setClockType(ClockTypeOption.get("realtime"));
		}

		// creates a new KieFileSystem used to programmatically define the
		// resources composing a KieModule
		KieFileSystem kFileSystem = kieServices.newKieFileSystem();

		try {
			// create a File instance with the path where is stored the drl file
			// with the rules, taken from the configuration file
			File file = new File(droolsParams.getDrlRulesFile());

			// create a Resource for the IO operations and set the type to DRL
			Resource resource = kieServices.getResources().newFileSystemResource(file)
					.setResourceType(ResourceType.DRL);

			// adds the given Resource to this KieFileSystem
			kFileSystem.write(resource);

			// adds the given kmodule.xml file to this KieFileSystem
			kFileSystem.writeKModuleXML(kieModuleModel.toXML());

			// creates a new KieBuilder to build the KieModule contained in the
			// given KieFileSystem
			KieBuilder kbuilder = kieServices.newKieBuilder(kFileSystem);

			// builds all the KieBases contained in the KieModule for which this
			// KieBuilder has been created
			kbuilder.buildAll();


			// returns the default ReleaseId used to identify a KieModule in
			// this
			// KieRepository if the user didn't explicitly provide one
			ReleaseId releaseId = kieServices.getRepository().getDefaultReleaseId();

			// creates a new KieContainer wrapping the KieModule with the given
			// ReleaseId
			this.kieCont = kieServices.newKieContainer(releaseId);
		} catch (Exception e1) {
			logger.debug("ERROR :" + e1.getMessage());
		}

		return this.kieCont;
	}

	/**
	 * Gets the kie cont.
	 *
	 * @return the kie cont
	 */
	public KieContainer getKieCont() {
		return this.kieCont;
	}

	/**
	 * Gets the log file properties.
	 *
	 * @return the log file properties
	 * @throws ConfigurationException the configuration exception
	 */
	public String getLogFileProperties() throws ConfigurationException {
		// return the log file properties
		return this.envUtils.getPropertiesByName("log4j.filePath", this.prop, null, this.splaEnv);
	}

	/**
	 * Inits the.
	 *
	 * @param droolsParams           the drools params
	 * @param pathforTest            the pathfor test
	 * @param useTestPropertiesFiles the use test properties files
	 * @throws ConfigurationException the configuration exception
	 */
	public void init(DroolsParameters droolsParams, String pathforTest, boolean useTestPropertiesFiles)
			throws ConfigurationException {
		// invoke the function to read the spla home
		readSplaHome();

		// invoke the function to read the spla environment
		readSplaEnv();
		this.completePath = composeCompleteModulePath();

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// load the properties related to brmProperties
		logger.debug("BRM_INIT : loading file : " + CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(CONFIG_FILENAME, this.prop, pathforTest, this.completePath, this.moduleName,
				useTestPropertiesFiles);

	}

	/**
	 * Inits the.
	 *
	 * @param droolsParams           the drools params
	 * @param pathforTest            the pathfor test
	 * @param useTestPropertiesFiles the use test properties files
	 * @throws ConfigurationException the configuration exception
	 */
	public void configure(DroolsParameters droolsParams, String pathforTest, boolean useTestPropertiesFiles)
			throws ConfigurationException {
		// invoke the function to read the spla home
		readSplaHome();

		// invoke the function to read the spla environment
		readSplaEnv();
		this.completePath = composeCompleteModulePath();

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// load the properties related to maxDuration of sensor mode
		logger.debug("BRM_INIT : loading file : " + MAX_DURATION_SENSOR_MODE_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(MAX_DURATION_SENSOR_MODE_CONFIG_FILENAME, this.maxDurationSensorModeProp,
				pathforTest, this.completePath, this.moduleName, useTestPropertiesFiles);

		// load the properties related to
		// power related to sensor mode
		logger.debug("BRM_INIT : loading file : " + POWER_SENSOR_MODE_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(POWER_SENSOR_MODE_CONFIG_FILENAME, this.powerSensorModeProp, pathforTest,
				this.completePath, this.moduleName, useTestPropertiesFiles);

		// load the properties related to
		// min distance between sensor mode
		logger.debug("BRM_INIT : loading file : " + MIN_DISTANCE_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(MIN_DISTANCE_CONFIG_FILENAME, this.minDistanceProp, pathforTest,
				this.completePath, this.moduleName, useTestPropertiesFiles);

		// load the properties related to
		// standard distance between sensor mode
		logger.debug("BRM_INIT : loading file : " + T_STANDARD_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(T_STANDARD_CONFIG_FILENAME, this.TStandardProp, pathforTest, this.completePath,
				this.moduleName, useTestPropertiesFiles);

		// load the properties related to
		// threshold distance between sensor mode
		logger.debug("BRM_INIT : loading file : " + T_THRESHOLD_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(T_THRESHOLD_CONFIG_FILENAME, this.tThresholdProp, pathforTest,
				this.completePath, this.moduleName, useTestPropertiesFiles);

		// load the properties related to power of cmga
		logger.debug("BRM_INIT : loading file : " + CONFIG_CMGA_FILENAME);
		this.envUtils.loadPropertiesFile(CONFIG_CMGA_FILENAME, this.cmgaProp, pathforTest, this.completePath,
				this.moduleName, useTestPropertiesFiles);

		// // load the properties related to power of cmga
		// logger.debug("BRM_INIT : loading file : " +
		// REASON_OF_REJECT_FILENAME);
		// this.envUtils.loadPropertiesFile(REASON_OF_REJECT_FILENAME,
		// this.reasonOfRejectProp, pathforTest, this.completePath,
		// this.moduleName, useTestPropertiesFiles);

		// load the properties related to first satellite properties
		logger.debug("BRM_INIT : loading file : " + FIRST_SATELLITE_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(FIRST_SATELLITE_CONFIG_FILENAME, this.sat1Prop, pathforTest, this.completePath,
				this.moduleName, useTestPropertiesFiles);

		// load the properties related to second satellite properties
		logger.debug("BRM_INIT : loading file : " + SECOND_SATELLITE_CONFIG_FILENAME);
		this.envUtils.loadPropertiesFile(SECOND_SATELLITE_CONFIG_FILENAME, this.sat2Prop, pathforTest,
				this.completePath, this.moduleName, useTestPropertiesFiles);

		// populate the map of powers of sensor mode with properties received
		// above
		populateMapSensorMode(this.powersSensorMode, droolsParams, this.powerSensorModeProp, false);

		// populate the map of max duration of sensor mode with properties
		// received above
		populateMapSensorMode(this.maxDurationSensorMode, droolsParams, this.maxDurationSensorModeProp, true);

		// populateReasonOfRejectMap(this.reasonOfRejectMap,
		// this.reasonOfRejectProp);

		// populate the map of min distance
		populateMap(this.minDistanceMap, this.minDistanceProp);

		// populate the map of standard distance
		populateMap(this.tStandardMap, this.TStandardProp);

		// populate the map of threshold distance
		populateMap(this.tThresholdMap, this.tThresholdProp);

		// set all the maps in the container of all the configuration maps
		this.configMaps.settStandardmap(this.tStandardMap);
		this.configMaps.setMinDistanceMap(this.minDistanceMap);
		this.configMaps.setPowerSensorMode(this.powersSensorMode);
		this.configMaps.settThresholdMap(this.tThresholdMap);
		this.configMaps.setMaxDurationSensorMode(this.maxDurationSensorMode);

		// populate all the droolsParameters
		populateDroolsParameters(droolsParams);

		// populate the satellite properties for both sat
		populateSatelliteProperties(DroolsParameters.getLogger(), droolsParams.getMinutesForOrbit(), this.satProp1,
				this.sat1Prop, FIRST_SATELLITE_CONFIG_FILENAME);

		populateSatelliteProperties(DroolsParameters.getLogger(), droolsParams.getMinutesForOrbit(), this.satProp2,
				this.sat2Prop, SECOND_SATELLITE_CONFIG_FILENAME);

		// populate the powers of cmg units
		populateCMGUnit(droolsParams, this.cmgaProp);

		// for test, this variable is true to allow the use of local drl path,
		// for debug
		if (useTestPropertiesFiles) {
			logger.debug("BRM_INIT : use drl file : config/droolsRules.drl");

			// override the path with the local path
			droolsParams.setDrlRulesFile("config/droolsRules.drl");
		}
	}

	/**
	 * @param reasonOfRejectMap2
	 * @param reasonOfRejectProp2
	 * @param droolsParams
	 */
	/*
	 * private void populateReasonOfRejectMap(Map<ReasonOfReject, ComplexReason>
	 * reasonOfRejectMap, Properties reasonOfRejectProp) { ReasonOfReject[]
	 * allReasons = ReasonOfReject.values(); try { // iterate over all the sensor
	 * modes for (int i = 0; i < ReasonOfReject.values().length; i++) { // get the
	 * properties String value;
	 *
	 * value = this.envUtils.getPropertiesByName(allReasons[i].toString(),
	 * reasonOfRejectProp, null, this.splaEnv).trim();
	 *
	 * System.out.println("property associated with reason : " + value); // parse as
	 * double String[] valuesAssociated = value.split(",");
	 *
	 * System.out.println("valuesAssociated 0" + valuesAssociated[0]);
	 * System.out.println("valuesAssociated 1" + valuesAssociated[1]);
	 *
	 * int id = Integer.parseInt(valuesAssociated[0].trim()); String descr =
	 * valuesAssociated[1].trim();
	 *
	 * // insert into maxDuration structure reasonOfRejectMap.put(allReasons[i], new
	 * ComplexReason(allReasons[i], id, descr));
	 *
	 * } DroolsParameters.setReasonOfRejectMap(reasonOfRejectMap); } catch
	 * (ConfigurationException e) { e.printStackTrace(); } }
	 */
	/**
	 * Populate satellite properties.
	 *
	 * @param logger              the logger
	 * @param minutesForOrbit     the minutes for orbit
	 * @param satelliteConstraint the satellite constraint
	 * @param satProperties       the sat properties
	 * @throws ConfigurationException
	 */
	private void populateSatelliteProperties(Logger logger, int minutesForOrbit,
			SatelliteProperties satelliteConstraint, Properties satProperties, String config_file)
			throws ConfigurationException {
		// define the number of orbits to check
		String numberOfOrbits = null;

		// define the values of threshold (one for each number or orbit defined
		// in the variable above) if it is -1 means that the control on the
		// relative orbit must be skipped
		String valuesOfThreshold = null;

		// define the values of threshold (one for each number or orbit defined
		// in the variable above)
		String valuesOfSilent = null;

		// define the values of max number of total maneuver (both cmga and rw)
		// (one for each number or orbit defined in the variable above)
		String valuesOfTotalManeuvers = null;

		// define the values of max number of rw maneuver (one for each number
		// or orbit defined in the variable above)
		String valuesOfTotalManeuversRW = null;

		// define the values of max number of cmga maneuver (one for each number
		// or orbit defined in the variable above)
		String valuesOfTotalManeuversCMGA = null;

		// define the values of minTimeInEclipse (one for each number or orbit
		// defined in the variable above)
		String valuesOfMinEclipse = null;

		// define the values of power relative to cmga
		// (one for each number or orbit defined in
		// the variable above)
		String valuesOfPowerCMGAUnit = null;

		// create a treemap for the time in left management
		TreeMap<Double, List<MinTimeRight>> maxTimeLeft = new TreeMap<>();

		// get the path where is stored the file
		String propertiesFilePath = concatenePath(this.completePath, MAX_TIME_LEFT_FILENAME);

		// read the property file of max left time
		this.envUtils.readFileOfMaxLeftTime(maxTimeLeft, propertiesFilePath);

		// create a map that will congtains all the check that must be performed
		// on orbits
		Map<Double, ResourceMaxValue> allChecksOnOrbits = new HashMap<>();
		logger.debug("BRM is populating all configuration parameters.");

		// if the property startTypeOfMan is set with 1
		if (this.envUtils.getPropertiesByName("startTypeOfMan", satProperties, config_file, this.splaEnv).trim()
				.equals("1")) {
			// start type of maneuver is rw
			satelliteConstraint.setStartWithRw(true);
		} else {
			// start type of maneuver is cmga
			satelliteConstraint.setStartWithRw(false);
		}

		// get the number of orbits to check
		numberOfOrbits = this.envUtils.getPropertiesByName("checkOnNumberOfOrbits", satProperties, config_file,
				this.splaEnv);

		// get the max values of threshold to check for each orbit defined
		// above
		valuesOfThreshold = this.envUtils.getPropertiesByName("checkThresholdMaxValues", satProperties, config_file,
				this.splaEnv);

		// get the max values of silent to check for each orbit defined
		// above
		valuesOfSilent = this.envUtils.getPropertiesByName("checkSilentMaxValues", satProperties, config_file,
				this.splaEnv);

		// get the max values of maneuvers to check for each orbit defined
		// above
		valuesOfTotalManeuvers = this.envUtils.getPropertiesByName("checkMaxNumberManeuvers", satProperties,
				config_file, this.splaEnv);
		valuesOfTotalManeuversRW = this.envUtils.getPropertiesByName("checkMaxNumberManeuversRW", satProperties,
				config_file, this.splaEnv);
		valuesOfTotalManeuversCMGA = this.envUtils.getPropertiesByName("checkMaxNumberManeuversCMGA", satProperties,
				config_file, this.splaEnv);

		// get the min time that let be consider an orbit of eclipse
		valuesOfMinEclipse = this.envUtils.getPropertiesByName("minTempEclipse", satProperties, config_file,
				this.splaEnv);

		// get all the types of paw that are excluded from storeAux
		// computation
		String allTypeOfPawExcludedFromStoreAux = this.envUtils
				.getPropertiesByName("typeOfPawAvoidStoreAux", satProperties, config_file, this.splaEnv).trim();

		this.envUtils.processTypeOfPawExcludedFromStoreAux(allTypeOfPawExcludedFromStoreAux, satelliteConstraint);
		satelliteConstraint.setSatId(
				this.envUtils.getPropertiesByName("satelliteId", satProperties, config_file, this.splaEnv).trim());

		satelliteConstraint.setMinTimeDownloadDelay(Integer.parseInt(this.envUtils
				.getPropertiesByName("minTimeDownloadDelay", satProperties, config_file, this.splaEnv).trim()));

		// get and set the max number of daily peaks
		satelliteConstraint.setMaxNumberDailyPeak(Integer.parseInt(this.envUtils
				.getPropertiesByName("maxNumberDailyPeak", satProperties, config_file, this.splaEnv).trim()));

		// get and set the period that must be considered for the smoothing
		// of ess (for unranked, expressed in minutes)
		satelliteConstraint.setPeriodBeforeEndOfMhForSmoothingUnranked(
				Double.parseDouble(this.envUtils.getPropertiesByName("periodBeforeEndOfMhForSmoothingUnranked",
						satProperties, config_file, this.splaEnv).trim()));

		// get and set the minimum time that must have a download
		satelliteConstraint.setMinPercDownloadOnVis(Double.parseDouble(this.envUtils
				.getPropertiesByName("minPercDownloadOnVis", satProperties, config_file, this.splaEnv).trim()));

		// get and set the percentage of time that a maneuver must be
		// considered as left (the complement time is right)
		satelliteConstraint.setPercentManLeftC2(Double.parseDouble(this.envUtils
				.getPropertiesByName("percentManLeftC2", satProperties, config_file, this.splaEnv).trim()));

		// get and set the wizardLink data rate for the download
		satelliteConstraint.setWizardLinkDataRate(Integer.parseInt(this.envUtils
				.getPropertiesByName("wizardLinkDataRate", satProperties, config_file, this.splaEnv).trim()));

		// get and set the wizardLink data rate for the download
		satelliteConstraint.setUseExtraSectorsPt(Integer.parseInt(this.envUtils
				.getPropertiesByName("useExtraSectorPassThrough", satProperties, config_file, this.splaEnv).trim()));

		// get and set the wizardLink data rate for the download
		satelliteConstraint.setMaxAvailableBufferSizePt(Integer.parseInt(this.envUtils
				.getPropertiesByName("maxAvailableBufferSizePt", satProperties, config_file, this.splaEnv).trim()));

		// get and set the wizardLink data rate for the download
		satelliteConstraint.setMaxAvailableBufferSizeGps(Integer.parseInt(this.envUtils
				.getPropertiesByName("maxAvailableBufferSizeGps", satProperties, config_file, this.splaEnv).trim()));

		// get and set the wizardLink data rate for the download
		satelliteConstraint.setNumberOfSectorsShiftPt(Integer.parseInt(this.envUtils
				.getPropertiesByName("numberOfSectorsShiftPt", satProperties, config_file, this.splaEnv).trim()));

		// get and set the axes reconfiguration time
		satelliteConstraint.setAxesReconfigurationTime(Double.parseDouble(this.envUtils
				.getPropertiesByName("axesReconfigurationTime", satProperties, config_file, this.splaEnv).trim()));

		// get and set the variable that allow the inclusion or not of the
		// silent in left attitude computation
		satelliteConstraint.setIncludeSilentInLeftAttitudeFormulaC1(Integer.parseInt(this.envUtils
				.getPropertiesByName("includeSilentInLeftAttitudeFormulaC1", satProperties, config_file, this.splaEnv)
				.trim()));

		satelliteConstraint.setWaitTimeBetweenRampAndCmg(Double.parseDouble(this.envUtils
				.getPropertiesByName("waitTimeBetweenRampAndCmg", satProperties, config_file, this.splaEnv).trim()));

		satelliteConstraint.setMaxNumberOfPacketStore(Integer.parseInt(this.envUtils
				.getPropertiesByName("maxNumberOfPacketStore", satProperties, config_file, this.splaEnv).trim()));

		// set the max number of switch that the pdht can perform
		satelliteConstraint.setMaxNumberOfSwitchesPDHT(Integer.parseInt(this.envUtils
				.getPropertiesByName("maxNumberOfSwitchesPDHT", satProperties, config_file, this.splaEnv).trim()));

		// set the max cumulative time of pdht
		satelliteConstraint.setMaxCumulativeTimePDHT(Double.parseDouble(this.envUtils
				.getPropertiesByName("maxCumulativeTimePDHT", satProperties, config_file, this.splaEnv).trim()));

		// set the max continuative time of pdht
		satelliteConstraint.setMaxContinuativeTimePDHT(Double.parseDouble(this.envUtils
				.getPropertiesByName("maxContinuativeTimePDHT", satProperties, config_file, this.splaEnv).trim()));

		// set the max time tha the satellite is allowed to stay in left
		// period
		satelliteConstraint.setMaxTimeInAllTheLeftPeriod(Double.parseDouble(this.envUtils
				.getPropertiesByName("maxTimeInAllTheLeftPeriod", satProperties, config_file, this.splaEnv).trim()));

		// set the max time that pass between two left
		// acquisitions without use the contermaneuver
		satelliteConstraint.setMaxTimeBetweenTwoLeftAcquisitions(Double.parseDouble(this.envUtils
				.getPropertiesByName("maxTimeBetweenTwoLeftAcquisitions", satProperties, config_file, this.splaEnv)
				.trim()));

		// set the percentate that an orbit must have to has been declared
		// in eclipse
		satelliteConstraint.setPercentEffectiveEclipse(Double.parseDouble(this.envUtils
				.getPropertiesByName("percentEffectiveEclipse", satProperties, config_file, this.splaEnv).trim()));

		// set the time before and after the effective eclipse time that
		// must be included in eclipse period
		satelliteConstraint.setTimeBeforeAndAfterEclipse(Double.parseDouble(this.envUtils
				.getPropertiesByName("timeBeforeAndAfterEclipse", satProperties, config_file, this.splaEnv).trim()));

		// set the dimension of a single sector of memory module of the PDHT
		satelliteConstraint.setSingleSectorDimension(Integer.parseInt(this.envUtils
				.getPropertiesByName("singleSectorDimension", satProperties, config_file, this.splaEnv).trim()));

		// set the rate for the conversion from acquisition size and
		// downlink size
		satelliteConstraint.setDownlinkPerChannel(Double.parseDouble(this.envUtils
				.getPropertiesByName("downlinkPerChannel", satProperties, config_file, this.splaEnv).trim()));

		// set the default time that the satellite must stay in right asset
		// after a left period if there isn't a valid match in the table of
		// left period
		satelliteConstraint.setDefaultMinTimeRight(Double.parseDouble(this.envUtils
				.getPropertiesByName("defaultMinTimeRight", satProperties, config_file, this.splaEnv).trim()));
		satelliteConstraint.setMaxEssInLeftPeriod(Double.parseDouble(this.envUtils
				.getPropertiesByName("maxEssInLeftPeriod", satProperties, config_file, this.splaEnv).trim()));
		satelliteConstraint.setMaxPercEclipseAvailable(Double.parseDouble(this.envUtils
				.getPropertiesByName("maxPercEclipseAvailable", satProperties, config_file, this.splaEnv).trim()));
		satelliteConstraint.setSilentFactor(Double.parseDouble(
				this.envUtils.getPropertiesByName("silentFactor", satProperties, config_file, this.splaEnv).trim()));
		satelliteConstraint.setUpperBoundPeakOrbit(Integer.parseInt(this.envUtils
				.getPropertiesByName("upperBoundPeakOrbit", satProperties, config_file, this.splaEnv).trim()));
		satelliteConstraint.setLowerBoundPeakOrbit(Integer.parseInt(this.envUtils
				.getPropertiesByName("lowerBoundPeakOrbit", satProperties, config_file, this.splaEnv).trim()));

		satelliteConstraint.setMinimumTimeBetweenStorageAndAcq(Integer.parseInt(this.envUtils
				.getPropertiesByName("minimumTimeBetweenStorageAndAcq", satProperties, config_file, this.splaEnv)
				.trim()));
		satelliteConstraint.setMinimumDistanceBetweenTasks(Integer.parseInt(this.envUtils
				.getPropertiesByName("minimumDistanceBetweenTasks", satProperties, config_file, this.splaEnv).trim()));

		allChecksOnOrbits = populateMapCheckOnOrbits(minutesForOrbit, numberOfOrbits, valuesOfThreshold, valuesOfSilent,
				valuesOfTotalManeuvers, valuesOfTotalManeuversRW, valuesOfTotalManeuversCMGA, valuesOfMinEclipse,
				valuesOfPowerCMGAUnit);
		satelliteConstraint.setMaxTheatreOnADay(Integer.parseInt(this.envUtils
				.getPropertiesByName("maxTheatreOnADay", satProperties, config_file, this.splaEnv).trim()));
		logger.debug("all check on orbits : " + allChecksOnOrbits);

		// set all check on orbits for the satellite under check
		satelliteConstraint.setAllChecksOnOrbits(allChecksOnOrbits);

	}

	/**
	 * Populate CMG unit.
	 *
	 * @param droolsParams the drools params
	 * @param cmgaProp     the cmga prop
	 */
	public void populateCMGUnit(DroolsParameters droolsParams, Properties cmgaProp) {
		// get an Enumeration for the properties of cmga
		Enumeration<?> e = cmgaProp.propertyNames();

		// extract the orbit to check in the
		// reserved file for cmg properties

		// String orbits = cmgaProp.getProperty(this.splaEnv + ".orbitToCheck");
		String orbits = cmgaProp.getProperty("orbitToCheck");

		// split them using the "," char as split char
		String[] orbitValues = orbits.split(",");

		// get the length of check on orbit
		int cont = orbitValues.length;

		// initialize the arrays for each
		// cmg with the size computed above
		String[] powerCmg1 = new String[cont];
		String[] powerCmg2 = new String[cont];
		String[] powerCmg3 = new String[cont];
		String[] powerCmg4 = new String[cont];
		String[] powerCmg5 = new String[cont];
		String[] powerCmg6 = new String[cont];

		// initialize the arrays with the
		// double powers for each cmg
		Double orbitsCheck[] = new Double[cont];
		Double powerCmg1Check[] = new Double[cont];
		Double powerCmg2Check[] = new Double[cont];
		Double powerCmg3Check[] = new Double[cont];
		Double powerCmg4Check[] = new Double[cont];
		Double powerCmg5Check[] = new Double[cont];
		Double powerCmg6Check[] = new Double[cont];

		// if there are associated powers
		while (e.hasMoreElements()) {
			// get the key
			String key = (String) e.nextElement();

			// if the value is related to sat1
			if (key.contains("sat1")) {
				// if the value is related to the first cmg
				if (key.contains("cmg1")) {
					// get all the related powers
					String power1 = cmgaProp.getProperty(key);

					// insert them in the relative array splitted by ","
					powerCmg1 = power1.split(",");
				}
				// if the value is related to the second cmg
				else if (key.contains("cmg2")) {
					// get all the related powers
					String power2 = cmgaProp.getProperty(key);

					// insert them in the relative array splitted by ","
					powerCmg2 = power2.split(",");
				}
				// if the value is related to the third cmg
				else if (key.contains("cmg3")) {
					// get all the related powers
					String power3 = cmgaProp.getProperty(key);

					// insert them in the relative array splitted by ","
					powerCmg3 = power3.split(",");
				}
			}
			// if the value is related to sat2
			else if (key.contains("sat2")) {
				// if the value is related to the first cmg
				if (key.contains("cmg1")) {
					// get all the related powers
					String power4 = cmgaProp.getProperty(key);

					// insert them in the relative array splitted by ","
					powerCmg4 = power4.split(",");
				}
				// if the value is related to the second cmg
				else if (key.contains("cmg2")) {
					// get all the related powers
					String power5 = cmgaProp.getProperty(key);

					// insert them in the relative array splitted by ","
					powerCmg5 = power5.split(",");
				}
				// if the value is related to the third cmg
				else if (key.contains("cmg3")) {
					// get all the related powers
					String power6 = cmgaProp.getProperty(key);

					// insert them in the relative array splitted by ","
					powerCmg6 = power6.split(",");
				}
			}
		}

		// iterate over all the checks on orbits
		for (int i = 0; i < orbitValues.length; i++) {
			// populate the arrays with all
			// the powers parsed as double
			orbitsCheck[i] = Double.parseDouble(orbitValues[i].trim());
			powerCmg1Check[i] = Double.parseDouble(powerCmg1[i].trim());
			powerCmg2Check[i] = Double.parseDouble(powerCmg2[i].trim());
			powerCmg3Check[i] = Double.parseDouble(powerCmg3[i].trim());
			powerCmg4Check[i] = Double.parseDouble(powerCmg4[i].trim());
			powerCmg5Check[i] = Double.parseDouble(powerCmg5[i].trim());
			powerCmg6Check[i] = Double.parseDouble(powerCmg6[i].trim());

			// extract from droolsParameters the cmga based on id of the
			// satellite and id of the cmga and add to it the powers just
			// computed
			droolsParams.getCmgaWithId(droolsParams.getAllCMGA(), "1", "1").addAllPowersForOrbit(orbitsCheck[i],
					powerCmg1Check[i]);
			droolsParams.getCmgaWithId(droolsParams.getAllCMGA(), "2", "1").addAllPowersForOrbit(orbitsCheck[i],
					powerCmg2Check[i]);
			droolsParams.getCmgaWithId(droolsParams.getAllCMGA(), "3", "1").addAllPowersForOrbit(orbitsCheck[i],
					powerCmg3Check[i]);
			droolsParams.getCmgaWithId(droolsParams.getAllCMGA(), "1", "2").addAllPowersForOrbit(orbitsCheck[i],
					powerCmg4Check[i]);
			droolsParams.getCmgaWithId(droolsParams.getAllCMGA(), "2", "2").addAllPowersForOrbit(orbitsCheck[i],
					powerCmg5Check[i]);
			droolsParams.getCmgaWithId(droolsParams.getAllCMGA(), "3", "2").addAllPowersForOrbit(orbitsCheck[i],
					powerCmg6Check[i]);
		}
	}

	/**
	 * Populate drools parameters.
	 *
	 * @param droolsParams the drools params
	 */
	public void populateDroolsParameters(DroolsParameters droolsParams) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create an empty treemap for the time in right between the time in
		// left
		TreeMap<Double, List<MinTimeRight>> maxTimeLeft = new TreeMap<>();

		// get the path where is stored the file with maxTimeinLeft properties
		String propertiesFilePath = concatenePath(this.completePath, MAX_TIME_LEFT_FILENAME);

		// read the file and populate the treemap
		this.envUtils.readFileOfMaxLeftTime(maxTimeLeft, propertiesFilePath);
		logger.debug("BRM is populating all configuration parameters.");
		try {
			// set the treemap into the droolsParameters
			droolsParams.setMinTimeRight(maxTimeLeft);

			// get the percentage of bic reserved to master for MSOS
			// acquisitions
			double percentBicMaster = Double
					.parseDouble(this.envUtils.getPropertiesByName("percentBicReservedToDi2sMaster_MSOS", this.prop,
							CONFIG_FILENAME, this.splaEnv).trim());

			droolsParams.setPercentBicDi2sMasterMSOS(percentBicMaster);


			double percentBicSlave = 0;

			// the percentage reserved to slave is the complement of the
			// percentage reserved to master
			percentBicSlave = 100 - droolsParams.getPercentBicDi2sMasterMSOS();

			// set both
			droolsParams.setPercentBicDi2sSlaveMSOS(percentBicSlave);

			// get the percentage of bic reserved to master for MSOR
			// acquisitions
			percentBicMaster = Double
					.parseDouble(this.envUtils.getPropertiesByName("percentBicReservedToDi2sMaster_MSOR", this.prop,
							CONFIG_FILENAME, this.splaEnv).trim());

			droolsParams.setPercentBicDi2sMasterMSOR(percentBicMaster);

			// the percentage reserved to slave is the complement of the
			// percentage reserved to master
			percentBicSlave = 100 - droolsParams.getPercentBicDi2sMasterMSOR();

			// set both
			droolsParams.setPercentBicDi2sSlaveMSOR(percentBicSlave);

			// set the local repository
			String localRepo = this.envUtils
					.getPropertiesByName("testConfigPath", this.prop, CONFIG_FILENAME, this.splaEnv).trim();
			droolsParams.setLocalRepo(localRepo);
			// set log4j file
			droolsParams.setLog4jFile(this.envUtils
					.getPropertiesByName("log4j.filePath", this.prop, CONFIG_FILENAME, this.splaEnv).trim());

			// set tranquillization time
			droolsParams.setTranquillizationTime(Double.parseDouble(this.envUtils
					.getPropertiesByName("tranquillizationTime", this.prop, CONFIG_FILENAME, this.splaEnv)));

			// set the drl file path
			droolsParams.setDrlRulesFile(this.envUtils
					.getPropertiesByName("drlRules.filePath", this.prop, CONFIG_FILENAME, this.splaEnv).trim());

			// set the responce file
			droolsParams.setResponceFile(this.envUtils
					.getPropertiesByName("responce.filePath", this.prop, CONFIG_FILENAME, this.splaEnv).trim());

			// set the time for a maneuver rw
			droolsParams.setTimeForManeuverRW(Integer.parseInt(
					this.envUtils.getPropertiesByName("timeForManeuverRw", this.prop, CONFIG_FILENAME, this.splaEnv)));
			// sedt the id for idugs
			droolsParams.setIdugsid(
					this.envUtils.getPropertiesByName("IDUGS_id", this.prop, CONFIG_FILENAME, this.splaEnv));

			// set the time for a maneuver cmga
			droolsParams.setTimeForManeuverCmga(Integer.parseInt(this.envUtils
					.getPropertiesByName("timeForManeuverCmga", this.prop, CONFIG_FILENAME, this.splaEnv)));

			droolsParams.setDisableGPS(
					this.envUtils.getPropertiesByName("disableGPS", this.prop, CONFIG_FILENAME, this.splaEnv).trim());
			// set the number of satellite
			droolsParams.setNumberOfSatellites(Integer.parseInt(
					this.envUtils.getPropertiesByName("numberOfSatellites", this.prop, CONFIG_FILENAME, this.splaEnv)));

			// set the minutes for orbit
			droolsParams.setMinutesForOrbit(Integer.parseInt(
					this.envUtils.getPropertiesByName("minutesForOrbit", this.prop, CONFIG_FILENAME, this.splaEnv)));

			// set the disableLeft
			String disableLeft = this.envUtils
					.getPropertiesByName("disableLeftAttitude", this.prop, CONFIG_FILENAME, this.splaEnv).trim();

			droolsParams.setDisableCheckLeftAttitude(disableLeft);

			// set the number of session
			droolsParams.setNumberOfSessions(Integer.parseInt(this.envUtils
					.getPropertiesByName("numberOfSessions", this.prop, CONFIG_FILENAME, this.splaEnv).trim()));

			// set the id of pratica di mare station
			droolsParams.setPraticaDiMareId(this.envUtils
					.getPropertiesByName("praticaDiMareId", this.prop, CONFIG_FILENAME, this.splaEnv).trim());

			// set the id of pratica di mare station
			droolsParams.setMateraId(
					this.envUtils.getPropertiesByName("materaId", this.prop, CONFIG_FILENAME, this.splaEnv).trim());

			// set the packet store id for GPS on external stations
			droolsParams.setGPSreservedpacketStore(this.envUtils
					.getPropertiesByName("GPSreservedpacketStore", this.prop, CONFIG_FILENAME, this.splaEnv).trim());

			// set the packet store id that is the complement for the GPS on
			// external stations
			droolsParams.setGpsAlwaysPlannedOnLink(this.envUtils
					.getPropertiesByName("gpsAlwaysPlannedOnLink", this.prop, CONFIG_FILENAME, this.splaEnv).trim());
			droolsParams.setSpaceWireForGps(Double.parseDouble(this.envUtils
					.getPropertiesByName("spaceWireForGps", this.prop, CONFIG_FILENAME, this.splaEnv).trim()));
			droolsParams.setRefd1_DI2S(Double.parseDouble(
					this.envUtils.getPropertiesByName("refd1_DI2S", this.prop, CONFIG_FILENAME, this.splaEnv).trim()));
			droolsParams.setRefd2_DI2S(Double.parseDouble(
					this.envUtils.getPropertiesByName("refd2_DI2S", this.prop, CONFIG_FILENAME, this.splaEnv).trim()));

		} catch (Exception e) {
			logger.debug("exception :" + e.getMessage());
		}
	}

	/**
	 * Populate fixed orbit map.
	 *
	 * @param map      the map
	 * @param property the property
	 * @throws ConfigurationException the configuration exception
	 */
	public void populateFixedOrbitMap(Map<String, Map<Integer, Double>> map, Properties property)
			throws ConfigurationException {
		// initialize the property name
		String propName = null;

		// initialize the property value
		String value = null;
		double valueInDouble = 0d;
		Map<Integer, Double> fixedOrbit = new HashMap<>();

		// iterate over all the fixed orbits
		for (int i = 0; i < 237; i++) {
			// get the i-esim fixed orbit
			propName = "" + i + "";

			// extract the relative value
			value = this.envUtils.getPropertiesByName(propName, property, null, this.splaEnv).trim();

			// parse as double
			valueInDouble = Double.parseDouble(value);

			// insert into the fixed orbit treemap
			fixedOrbit.put(i, valueInDouble);
		}

		map.put("SAT_1", fixedOrbit);
		map.put("SAT_2", fixedOrbit);

	}

	/**
	 * Populate map.
	 *
	 * @param map      the map
	 * @param property the property
	 * @throws ConfigurationException the configuration exception
	 */
	private void populateMap(Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> map, Properties property)
			throws ConfigurationException {
		// get all types of sensor mode
		TypeOfAcquisition allTypes[] = TypeOfAcquisition.values();

		// initialize property name
		String propName = null;

		// initialize property value
		String value = null;
		double valueInDouble = 0d;

		// iterate over all the sensor modes
		for (int i = 0; i < TypeOfAcquisition.values().length; i++) {
			Map<TypeOfAcquisition, Double> subMap = new HashMap<>();

			// iterate over all the types of sensor modes
			for (int j = 0; j < TypeOfAcquisition.values().length; j++) {
				// concatenate the property name, with the
				// union of both sensor mode under analysis
				propName = allTypes[i] + "_" + allTypes[j];

				// get the relative property
				value = this.envUtils.getPropertiesByName(propName, property, null, this.splaEnv).trim();

				// cast in double value
				valueInDouble = Double.parseDouble(value);

				// insert in structure
				subMap.put(allTypes[j], valueInDouble);
			}
			map.put(allTypes[i], subMap);
		}
	}

	/**
	 * Populate map check on orbits.
	 *
	 * @param minutesForSingleOrbit  the minutes for single orbit
	 * @param numberOfOrbits         the number of orbits
	 * @param valuesOfThreshold      the values of threshold
	 * @param valuesOfSilent         the values of silent
	 * @param valuesOfTotalManeuvers the values of total maneuvers
	 * @param valuesOfManeuversRW    the values of maneuvers RW
	 * @param valuesOfManeuversCMGA  the values of maneuvers CMGA
	 * @param valueOfMinTimeEclipse  the value of min time eclipse
	 * @param valuesOfPowerCMGAUnit  the values of power CMGA unit
	 * @return the map
	 */
	private Map<Double, ResourceMaxValue> populateMapCheckOnOrbits(int minutesForSingleOrbit, String numberOfOrbits,
			String valuesOfThreshold, String valuesOfSilent, String valuesOfTotalManeuvers, String valuesOfManeuversRW,
			String valuesOfManeuversCMGA, String valueOfMinTimeEclipse, String valuesOfPowerCMGAUnit) {
		// extract the logger
		Logger logger = DroolsParameters.getLogger();

		// create a map for all the checks on
		// orbits that will be checked
		Map<Double, ResourceMaxValue> allCheckOnOrbits = new HashMap<>();

		// get the values of each quantity
		// that must be controlled,
		// splitted by the char ","
		String[] orbits = numberOfOrbits.split(",");
		String[] thresholds = valuesOfThreshold.split(",");
		String[] silents = valuesOfSilent.split(",");
		String[] minTimeEclipse = valueOfMinTimeEclipse.split(",");
		String[] totalManeuvers = valuesOfTotalManeuvers.split(",");
		String[] totalManeuversRW = valuesOfManeuversRW.split(",");
		String[] totalManeuversCMGA = valuesOfManeuversCMGA.split(",");

		// if the file is well formed (for each
		// orbit to check there are the
		// relative values for every parameter
		// that must be checked)
		if ((orbits.length == thresholds.length) && (orbits.length == silents.length)
				&& (orbits.length == totalManeuvers.length) && (orbits.length == totalManeuversRW.length)
				&& (orbits.length == totalManeuversCMGA.length)) {
			// get the orbits
			double[] orbitsValues = this.envUtils.computeOrbitValues(minutesForSingleOrbit, orbits);

			// initialize all the other arrays with the sized of the arrays of
			// orbits
			double[] thresholdValues = new double[orbits.length];
			double[] silentValues = new double[orbits.length];
			long[] minTimeEclipseValues = new long[orbits.length];
			int[] totalManValues = new int[orbits.length];
			int[] totalManValuesRW = new int[orbits.length];
			int[] totalManValuesCMGA = new int[orbits.length];

			// iterate over the orbit to check
			for (int i = 0; i < orbits.length; i++) {
				// insert the i-esim orbit value
				orbitsValues[i] = Double.parseDouble(orbits[i].trim());

				// insert the i-esim threshold value for the current orbit
				thresholdValues[i] = Double.parseDouble(thresholds[i].trim());

				// insert the i-esim min time eclipse value for the current
				// orbit
				minTimeEclipseValues[i] = Long.parseLong(minTimeEclipse[i].trim());

				// insert the i-esim silent threshold value for the current
				// orbit
				silentValues[i] = Double.parseDouble(silents[i].trim());

				// insert the i-esim total man value for the current orbit
				totalManValues[i] = Integer.parseInt(totalManeuvers[i].trim());

				// insert the i-esim man rw value for the current orbit
				totalManValuesRW[i] = Integer.parseInt(totalManeuversRW[i].trim());

				// insert the i-esim man cmga value for the current orbit
				totalManValuesCMGA[i] = Integer.parseInt(totalManeuversCMGA[i].trim());

				// wrap all into the ResourceMaxValue object
				ResourceMaxValue valuesAssociated = new ResourceMaxValue(minutesForSingleOrbit, silentValues[i],
						thresholdValues[i], totalManValues[i], totalManValuesRW[i], totalManValuesCMGA[i],
						minTimeEclipseValues[i]);

				// insert the ResourceMaxValue into the map of orbits
				allCheckOnOrbits.put(orbitsValues[i], valuesAssociated);
			}
		} else {
			// print the exception on logger
			logger.error("cannot find a valid match for the check that must be performed");

			// cannot find a valid match
			new Exception("cannot find a valid match");
		}
		return allCheckOnOrbits;
	}

	/**
	 * Populate map sensor mode.
	 *
	 * @param maxDurationSensorMode the max duration sensor mode
	 * @param droolsParams          the drools params
	 * @param powerSensorModeProp   the power sensor mode prop
	 * @param maxDuration           the max duration
	 * @throws ConfigurationException the configuration exception
	 */
	private void populateMapSensorMode(Map<TypeOfAcquisition, Double> maxDurationSensorMode,
			DroolsParameters droolsParams, Properties powerSensorModeProp, boolean maxDuration)
			throws ConfigurationException {
		// get all type of sensor mode
		TypeOfAcquisition allTypes[] = TypeOfAcquisition.values();
		String value = null;

		// set the default value as 0
		double valueInDouble = 0d;

		// if we are using this function to populate the maxPower for sensor
		// mode and not the max duration of sensor mode
		if (!maxDuration) {
			// iterate over all types of sensor mode
			for (int i = 0; i < TypeOfAcquisition.values().length; i++) {
				// is the i-esim sensor mode is a special one (these special
				// types have more than one power associated)
				if ((allTypes[i].equals(TypeOfAcquisition.SPOTLIGHT_1_MSOR))
						|| allTypes[i].equals(TypeOfAcquisition.SPOTLIGHT_2_MSOS)
						|| (allTypes[i].equals(TypeOfAcquisition.SPOTLIGHT_2_MSJN))) {
					// get the max value of power
					value = this.envUtils
							.getPropertiesByName(allTypes[i].toString(), powerSensorModeProp, null, this.splaEnv)
							.trim();

					// split this values into single value
					String[] powersAssociatedAsString = value.split(",");
					double powerAssociated = 0;

					// iterate over this splitted values
					for (int j = 0; j < powersAssociatedAsString.length; j++) {
						// parse to double the power
						powerAssociated = Double.parseDouble(powersAssociatedAsString[j]);

						// if we are managing the lowerBound value
						if (j == 0) {
							LowerAndUpperBoundPowers lowerBoundPower = new LowerAndUpperBoundPowers(allTypes[i], true,
									powerAssociated);
							droolsParams.getPowersWithULvalues().add(lowerBoundPower);
						}
						// if we are managing the upper bound value
						else {
							LowerAndUpperBoundPowers upperBoundPower = new LowerAndUpperBoundPowers(allTypes[i], false,
									powerAssociated);
							droolsParams.getPowersWithULvalues().add(upperBoundPower);
						}
					}
					// insert into maxDuration structure
					maxDurationSensorMode.put(allTypes[i], powerAssociated);
				}
				// is the i-esim sensor mode isn't a special one
				else {
					// simple case : get the property from file relative to the
					// current sensor mode
					value = this.envUtils
							.getPropertiesByName(allTypes[i].toString(), powerSensorModeProp, null, this.splaEnv)
							.trim();

					// parse to double the power
					valueInDouble = Double.parseDouble(value);

					// insert into maxDuration structure
					maxDurationSensorMode.put(allTypes[i], valueInDouble);
				}
			}
			droolsParams.setPowersSensorMode(maxDurationSensorMode);
		}
		// if we are populating the maxDruration structure
		else {
			// iterate over all the sensor modes
			for (int i = 0; i < TypeOfAcquisition.values().length; i++) {
				// get the properties
				value = this.envUtils
						.getPropertiesByName(allTypes[i].toString(), powerSensorModeProp, null, this.splaEnv).trim();

				// parse as double
				valueInDouble = Double.parseDouble(value);

				// insert into maxDuration structure
				maxDurationSensorMode.put(allTypes[i], valueInDouble);
			}
		}
	}

	/**
	 * Read spla env.
	 *
	 * @throws ConfigurationException the configuration exception
	 */
	public String readSplaEnv() throws ConfigurationException {
		// get the spla environment
		this.splaEnv = System.getenv(SPLA_ENV);

		// check if is null
		this.envUtils.checkNullValue(this.splaEnv, "Environment variables " + SPLA_ENV + " not set.");
		return this.splaEnv;
	}

	/**
	 * Read spla home.
	 *
	 * @throws ConfigurationException the configuration exception
	 */
	private void readSplaHome() throws ConfigurationException {
		// get the spla home
		this.splaPath = System.getenv(SPLA_HOME);

		// check if is null
		this.envUtils.checkNullValue(this.splaPath, "Environment variables " + SPLA_HOME + " not set.");
	}

	/**
	 * Sets the up session.
	 *
	 * @param sessionId         the session id
	 * @param typeOfSession     the type of session
	 * @param droolsParams      the drools params
	 * @param currentKieSession the current kie session
	 * @param isLmpOrVu         the is lmp or vu
	 * @param charToSplit       the char to split
	 */
	public void setUpSession(String sessionId, DroolsParameters droolsParams, int currentKieSession,
			SessionType sessionType, String charToSplit) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		String sessionIdName = DroolsParameters.concatenateSession(sessionId, currentKieSession);

		logger.debug("***********session id :" + sessionId);
		logger.debug("***********session instance :" + currentKieSession);

		// if the currentKieSession is a valid one
		if (currentKieSession < droolsParams.getNumberOfSessions()) {
			// set the current session with the currentKieSession given as input
			// DroolsParameters.setCurrentSession(sessionIdName);

			// create an empty list of accepted elements
			List<String> accepted = new ArrayList<>();
			HashMap<String, Acquisition> allAccepted = new HashMap<>();
			// check if the sessionId is valid
			// sessionId = this.envUtils.checkSessionId(sessionId);

			// set the split char given from CSPS
			droolsParams.setSplitChar(charToSplit);
			try {
				// create an empty list of rejected elements for the current
				// session
				Map<String, Task> rejected = new HashMap<>();
				List<Task> deletedtasks = new ArrayList<>();

				// initialize the report where will be writed all the dto
				// ordered by priority
				List<String> report = new ArrayList<>();

				// initialize a ResourceFunctions object
				ResourceFunctions resourceFunctions = new ResourceFunctions();
				SetResources setRes = new SetResources();
				// invoke the function to insert all the resources in
				setRes.populateResourceFunctions(resourceFunctions, droolsParams);

				logger.debug("**** creating a new drools instance " + sessionIdName);
				String newSessionName = "KS_" + sessionIdName;
				// create a new session with the id given as parameter
				KieSession kie = this.getKieCont().newKieSession(newSessionName);

				// setup the debug listeners
				// kie.addEventListener(new DebugAgendaEventListener());
				// kie.addEventListener(new DebugRuleRuntimeEventListener());

				// create an HpOrbitalExclusionManagement obkect
				HpOrbitalExclusionManagement hpExcl = new HpOrbitalExclusionManagement();

				// iterate over all satellites
				for (int j = 0; j < droolsParams.getAllSat().size(); j++) {
					// extract i-esim sat id
					String satId = droolsParams.getAllSat().get(j).getSatelliteId();

					// check if there are hpSegment for the current satellite
					// for the current mission horizon
					List<HPExclusion> hpExclusionValid = hpExcl.checkIfThereAreElementsInInterval(
							droolsParams.getCurrentMH(), droolsParams.getHpExclusionList(), satId,
							droolsParams.getTimeForManeuverCmga());

					// get the structure to store the hpExclusion relative to
					// the current satellite
					TreeMap<Long, HPExclusion> treeMapHpExcl = resourceFunctions.getHpExclAssociatedToSat(satId);
					logger.debug("list of valid hp segment :" + hpExclusionValid);

					// if there are hpSegments valid
					if ((hpExclusionValid != null) && !hpExclusionValid.isEmpty()) {
						// iterate over them
						for (int k = 0; k < hpExclusionValid.size(); k++) {
							// insert into drools
							kie.insert(hpExclusionValid.get(k));
							logger.debug("inserting hp segment in treemap :" + hpExclusionValid.get(k));

							// insert into the structure declared above
							treeMapHpExcl.put(hpExclusionValid.get(k).getStartTime().getTime(),
									hpExclusionValid.get(k));
							logger.debug("updated treeMap :" + treeMapHpExcl);
						}
					}
				}

				// setup the audit logging
				// the global variables are declared at the start of the drl
				// file of the rules and are used to share information among the
				// rules

				kie.setGlobal("droolsParams", droolsParams);
				kie.setGlobal("sessionInstance", currentKieSession);
				kie.setGlobal("sessionId", sessionId);
				// set the report with the dto ordered by priority
				kie.setGlobal("report", report);

				kie.setGlobal("allAccepted", allAccepted);

				// set the boolean variable that indicate if the session is of
				// type veryUrgent or not
				kie.setGlobal("sessionType", sessionType);
				boolean isLmpOrVu = false;

				if (sessionType.compareTo(SessionType.urgent) == 0) {
					isLmpOrVu = true;
				}
				kie.setGlobal("isLmpOrVu", isLmpOrVu);

				// set the variable that collect all the rejected dto and the
				// reason of reject
				kie.setGlobal("rejected", rejected);

				// set the variable that collect all the accepted dto
				kie.setGlobal("accepted", accepted);

				kie.setGlobal("du", new DroolsUtils());
				kie.setGlobal("deletedTasks", deletedtasks);

				// setUp all the functions and management class
				kie.setGlobal("peakMng", new PeakManagement());

				kie.setGlobal("dwlUtils", new DownloadUtils());
				kie.setGlobal("resourceFunctions", resourceFunctions);
				kie.setGlobal("silentManagement", new SilentManagement());
				kie.setGlobal("bicManagement", new BicManagement());
				kie.setGlobal("eclipseManagement", new EclipseManagement());
				kie.setGlobal("maneuverManagement", new ManeuverManagement());
				kie.setGlobal("ptManagement", new PassThroughManagement());
				kie.setGlobal("cmgaManagement", new CMGAManeuverManagement());
				kie.setGlobal("leftAttitudeManagement", new LeftAttitudeProfileManagement());
				kie.setGlobal("cmgAxisReconfManagement", new CMGAxisReconfigManagement());
				kie.setGlobal("pdhtManagement", new PdhtManagement());
				kie.setGlobal("downloadManagement", new DownloadManagement());
				kie.setGlobal("essManagement", new EssEnergyManagement());

				// set the logger as global variable
				kie.setGlobal("logger", DroolsParameters.getLogger());

				// set the current mission horizon
				kie.setGlobal("currentMH", droolsParams.getCurrentMH());

				// set the map with the values in distance between sensor modes
				kie.setGlobal("maxDurationSensorMode", this.maxDurationSensorMode);
				kie.setGlobal("powersSensorMode", this.powersSensorMode);
				kie.setGlobal("configMaps", this.configMaps);
				kie.setGlobal("minDistanceMap", this.minDistanceMap);
				kie.setGlobal("tThresholdMap", this.tThresholdMap);
				kie.setGlobal("tStandardMap", this.tStandardMap);

				resourceFunctions.getDownloadPriorityQueueSat1().clear();
				resourceFunctions.getDownloadPriorityQueueSat2().clear();

				// invoke the function to set all resources
				this.envUtils.setAllResources(droolsParams, resourceFunctions, kie, this.satProp1, this.satProp2);

				// insert into the map the session just created
				SessionHandler.getKieSessionsMap().put(sessionIdName, kie);
			} catch (Exception e) {
				e.printStackTrace();
				// log the exception
				logger.error("Exception founded : " + e);
			}
		} else {
			// there isn't a valid session
			logger.error("there isn't a valid sessionId");
		}

	}

}
