/**
*
* MODULE FILE NAME:	ComplexReason.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		08 set 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 08 set 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;

/**
 * The Class ComplexReason.
 *
 * @author francesca
 */
public class ComplexReason {
	// TODO decommentare e testare excludeUnremovableTasks
	// TODO rimuovere tutti gli assert di testTheatre
	// TODO rendere controlli CMG atomici da controlli sulle regole
	// TODO eseguire test di classe testDownloadRules
	// TODO eseguire test initPlan2 (buono per download retain, bug su download
	// e bug su manovra iniziale (dto5 planned ma rigettato -> test buono x
	// CMGA)
	// TODO popolare test hpExclusion con tutti i casi d'uso
	// TODO reinserire logica reasonOfReject da file
	// TODO reinserire logica essPaw da file
	// TODO creare logica number of maneuver in PAw da file
	// TODO gestire solo percentuale di acq borderline
	// TODO mettere report max ess usate x sliding window max
	// TODO verificare formula CMGA
	// TODO inserire tempo configurato tra download e download
	// TODO ripristinare algoritmo x processamento dei BITE
	// TODO ripristinare algoritmo x update pdht a fronte di un aggiornamento
	// dal centro di controllo
	// TODO fare check anche indietro x ess

	/** The reason. */
	private ReasonOfReject reason;

	/** The id. */
	private int id;

	/** The reason description. */
	private String reasonDescription;

	/**
	 * Instantiates a new complex reason.
	 *
	 * @param reason            the reason
	 * @param id                the id
	 * @param reasonDescription the reason description
	 */
	public ComplexReason(ReasonOfReject reason, int id, String reasonDescription) {
		super();
		this.reason = reason;
		this.id = id;
		this.reasonDescription = reasonDescription;
	}

	/**
	 * Gets the reason.
	 *
	 * @return the reason
	 */
	public ReasonOfReject getReason() {
		return this.reason;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * Gets the reason description.
	 *
	 * @return the reasonDescription
	 */
	public String getReasonDescription() {
		return this.reasonDescription;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "ComplexReason [reason=" + this.reason + ", id=" + this.id + ", reasonDescription="
				+ this.reasonDescription + "]";
	}

}
