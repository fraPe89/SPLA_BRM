/**
*
* MODULE FILE NAME: DroolsQueries.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;

import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

// TODO: Auto-generated Javadoc
/**
 * The Class DroolsQueries.
 */
public class DroolsQueries {

	/**
	 * Find partner in list.
	 *
	 * @param partnerId   the partner id
	 * @param allPartners the all partners
	 * @return the partner
	 */
	public Partner findPartnerInList(String partnerId, List<Partner> allPartners) {
		// create a partner
		Partner partnerExtracted = null;
		// iterate over all the partners
		for (int z = 0; z < allPartners.size(); z++) {
			/*
			 * if the i-esim partner has the same id of the id given as input
			 */
			if (allPartners.get(z).getPartnerId().equalsIgnoreCase(partnerId)) {
				// set the i-esim partner as the returned one
				partnerExtracted = allPartners.get(z);
				break;
			}
		}
		return partnerExtracted;
	}

	/**
	 * Gets all the acquisitions inserted in Drools.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools parameters
	 * @param satId           the sat id
	 * @return the list of all the acquisitions correctly planned
	 */
	public List<Acquisition> getAllAcquisitions(String sessionId, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);

		// create an empty list of acquisitions
		List<Acquisition> allAcq = new ArrayList<>();

		// invoke the Drools query to extract all the acquisitions from the
		// session for the satellite passed as input
		QueryResults queryResults = kie.getQueryResults("getObjectsOfAcquisition", satId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// extract the i-esim acquisition
			Acquisition acq = (Acquisition) iterator.next().get("$allAcq");

			// add it to the list previously created
			allAcq.add(acq);
		}
		return allAcq;
	}

	/**
	 * Gets the all maneuvers inserted in Drools for a satellite given as input.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools parameters
	 * @param satId           the sat id
	 * @return the list of all the maneuvers correctly planned
	 */
	public List<Maneuver> getAllManeuvers(String sessionId, int currentInstance, DroolsParameters droolsParams,
			String satId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create an empty list of maneuvers
		List<Maneuver> allMan = new ArrayList<>();

		// invoke the Drools query to extract all the maneuvers from the session
		// for the satellite passed as input
		QueryResults queryResults = kie.getQueryResults("getObjectsOfManeuver", satId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// extract the i-esim maneuver
			Maneuver man = (Maneuver) iterator.next().get("$allMan");

			// add it to the list previously created
			allMan.add(man);
		}
		return allMan;
	}

	/**
	 * extract the equivalent dto from the session with the id passed as input.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param equivDtoId      the equiv dto id
	 * @return the equiv dto with id
	 */
	public EquivalentDTO getEquivDtoWithId(String sessionId, int currentInstance, DroolsParameters droolsParams,
			String equivDtoId) {
		// create an equivalentDto
		EquivalentDTO equivDto = null;

		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// invoke the Drools query to extract the equivalent dto from the
		// session with the id passed as input
		QueryResults queryResults = kie.getQueryResults("getEquivDtoWithId", equivDtoId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// extract the equivalentDto
			equivDto = (EquivalentDTO) iterator.next().get("$equivDto");
		}
		return equivDto;
	}

	/**
	 * Gets the all dwl and pt in interval.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param startCheck      the start check
	 * @param endCheck        the end check
	 * @param satId           the sat id
	 * @return the all dwl and pt in interval
	 */
	public List<Task> getAllDwlAndPtInInterval(String sessionId, int currentInstance, DroolsParameters droolsParams,
			Date startCheck, Date endCheck, String satId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create an empty list of tasks to memorize all the downloads and
		// Passthrought that will be extracted from the current session
		List<Task> allDwlOrPtInInterval = new ArrayList<>();

		// invoke the Drools query to extract the tasks of type Download and
		// Passthrough that overlap the date passed as input
		QueryResults queryResults = kie.getQueryResults("allDownloadsAndPtOverlapInterval", startCheck, endCheck,
				satId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// extract the i-esim task
			Task dwlOrpT = (Task) iterator.next().get("$dwl");

			// add it to the list previously created
			allDwlOrPtInInterval.add(dwlOrpT);
		}
		return allDwlOrPtInInterval;
	}

	/**
	 * Gets the all dwl related to sto.
	 *
	 * @param droolsParams the drools params
	 * @param stoId        the sto id
	 * @param allDwls      the all dwls
	 * @return the all dwl related to sto
	 */
	public List<Download> getAllDwlRelatedToSto(DroolsParameters droolsParams, String stoId,
			TreeMap<String, Download> allDwls) {
		// create an empty list of tasks to
		// memorize all the downloads and
		// Passthrought that will be extracted
		// from the current session
		List<Download> allDwlRelatedToSto = new ArrayList<>();

		// iterte over all the downloads
		for (Map.Entry<String, Download> alLDwlAsMap : allDwls.entrySet()) {
			// get the current download
			Download dwl = alLDwlAsMap.getValue();

			if (dwl.getIdTask().equalsIgnoreCase(stoId)) {
				// add it to the list previously created
				allDwlRelatedToSto.add(dwl);
			}

		}
		return allDwlRelatedToSto;
	}

	/**
	 * invoke the Drools query to extract the acquisition (if exists) with the id
	 * passed as input.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param acqId           the acq id to search
	 * @return the acq with the searched id
	 */
	@SuppressWarnings("unchecked")
	public Acquisition getAcqWithId(String sessionId, int currentInstance, String acqId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create a new acquisition
		Acquisition returnedAcq = null;

		// invoke the Drools query to extract the acquisition (if exists) with
		// the id passed as input
		HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) kie.getGlobal("allAccepted");

		// if there is a match
		if (allAccepted.get(acqId) != null) {
			// set the acq with the one extracted from drools
			returnedAcq = allAccepted.get(acqId);
		}
		return returnedAcq;
	}

	/**
	 * Gets the acq with id from hash map.
	 *
	 * @param allAcq the all acq
	 * @param acqId  the acq id
	 * @return the acq with id from hash map
	 */
	public Acquisition getAcqWithIdFromHashMap(HashMap<String, Acquisition> allAcq, String acqId) {
		// create a new acquisition
		Acquisition returnedAcq = null;
		// if there is a match
		if ((allAcq != null) && !allAcq.isEmpty() && (allAcq.get(acqId) != null)) {
			// set the acq with the one extracted from drools
			returnedAcq = allAcq.get(acqId);
		}
		return returnedAcq;
	}

	/**
	 * Gets the all accepted acq.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @return the all accepted acq
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String, Acquisition> getAllAcceptedAcq(String sessionId, int currentInstance) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);

		// invoke the Drools query to extract the acquisition (if exists) with
		// the id passed as input
		HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) kie.getGlobal("allAccepted");

		return allAccepted;
	}

	/**
	 * Gets the all task related to equivalent dto.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param equivDtoId      the equiv dto id
	 * @return the all task related to equivalent dto
	 */
	public List<Task> getAllTaskRelatedToEquivalentDto(String sessionId, int currentInstance,
			DroolsParameters droolsParams, String equivDtoId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create an empty list of tasks to collect all the tasks relative to
		// the equivalentDto with the id passed as input
		List<Task> returnedTasks = new ArrayList<>();

		// invoke the Drools query to extract all the tasks relative to the
		// equivalentDto with the id passed as input
		QueryResults queryResults = kie.getQueryResults("getAllTasksRelatedToEquivalentDto", equivDtoId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// extract the i-esim element
			Task task = (Task) iterator.next().get("$allTasksRelatedToEquivDto");

			// add the task to the list
			returnedTasks.add(task);
		}
		return returnedTasks;
	}

	/**
	 * Gets the acq with given id.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools parameters
	 * @param start           the start
	 * @param stop            the stop
	 * @param satId           the sat id
	 * @return the acq with the searched id
	 */
	public List<String> getAllAcquisitionInInterval(String sessionId, int currentInstance,
			DroolsParameters droolsParams, Date start, Date stop, String satId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create an empty list of String to collect the id of all the
		// acquisition founded in interval
		List<String> returnedAcq = new ArrayList<>();

		// invoke the Drools query to extract all the acquisition that are
		// inside the interval
		QueryResults queryResults = kie.getQueryResults("allAcqInInterval", start, stop, satId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// extract the i-esim element
			Acquisition acq = (Acquisition) iterator.next().get("$acq");

			// add it to the list of acquisitions
			returnedAcq.add(acq.getId());
		}
		return returnedAcq;
	}

	/**
	 * Gets the sto with givenid.
	 *
	 * @param sessionId        the session id
	 * @param currentInstance  the current instance
	 * @param droolsParams     the drools params
	 * @param revolutionNumber the revolution number
	 * @return the sto with givenid
	 */
	/*
	 * public Storage getStoWithGivenid(List<Task> alldwlAndSto, DroolsParameters
	 * droolsParams, String stoId) { // create an empty storage Storage returnedSto
	 * = null; System.out.println("searching alldwlAndSto  "+alldwlAndSto);
	 *
	 * System.out.println("searching storage for "+stoId); // iterate over all the
	 * downloads and storages passed as input for (int i = 0; i <
	 * alldwlAndSto.size(); i++) { // if the i-esim task is of type storage if
	 * (alldwlAndSto.get(i).getTaskType().equals(TaskType.STORE)) { // if the id of
	 * the i-esim storage is the same of the one passed // as input if
	 * (alldwlAndSto.get(i).getIdTask().equalsIgnoreCase(stoId)) { // set the
	 * storage that must be returned with the current // one returnedSto = (Storage)
	 * alldwlAndSto.get(i); break; } } } return returnedSto; }
	 */

	/**
	 * Gets the sto with givenid.
	 *
	 * @param droolsParams the drools params
	 * @param stoId        the sto id
	 * @return the sto with givenid
	 */
	/*
	 * public Storage getStoWithGivenid(String sessionId, int currentInstance,
	 * DroolsParameters droolsParams, String stoId) { String sessionIdInstance =
	 * DroolsParameters.concatenateSession(sessionId, currentInstance);
	 *
	 * // get the current active session KieSession kie =
	 * SessionHandler.getKieSessionsMap().get(sessionIdInstance); // create an empty
	 * storage Storage returnedSto = null;
	 *
	 * // invoke the Drools query to extract (if present) the storage with the // id
	 * passed as input QueryResults queryResults =
	 * kie.getQueryResults("sto with given id", stoId); Iterator<QueryResultsRow>
	 * iterator = queryResults.iterator();
	 *
	 * // iterate over results while (iterator.hasNext()) { // set the returned
	 * storage with the current one returnedSto = (Storage)
	 * iterator.next().get("$sto"); break; } return returnedSto; }
	 */

	/**
	 * Gets the all acq on same fixed orbit.
	 *
	 * @param droolsParams     the drools params
	 * @param revolutionNumber the revolution number
	 * @return the all acq on same fixed orbit
	 */
	public List<Acquisition> getAllAcqOnSameFixedOrbit(String sessionId, int currentInstance,
			DroolsParameters droolsParams, int revolutionNumber) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create an empty list of acquisitions
		List<Acquisition> allAcqOnOrbit = new ArrayList<>();

		// invoke the query to extract the acq that has impact on the fixed
		// orbit passed as input
		QueryResults queryResults = kie.getQueryResults("getAllAcqOnSameOrbit", revolutionNumber);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over results
		while (iterator.hasNext()) {
			// extract i-esim acquisition
			Acquisition acq = (Acquisition) iterator.next().get("$acq");
			// add it to the list that must be returned
			allAcqOnOrbit.add(acq);
		}
		return allAcqOnOrbit;
	}

	/**
	 * Invoke the query to extract all the storages and downloads that starts after
	 * the date passed as input and impact on the satellite with the id passed as
	 * input.
	 *
	 * @param startSearch  the start search
	 * @param endSearch    the end search
	 * @param allDwlAndSto the all dwl and sto
	 * @return the all storages and downloads after date
	 */
	public List<Task> getAllStoragesAndDownloadsInInterval(long startSearch, long endSearch, List<Task> allDwlAndSto) {
		// create an empty list of tasks
		List<Task> allAcceptedTasks = new ArrayList<>();

		// iterate over results
		for (int i = 0; i < allDwlAndSto.size(); i++) {
			// exdtract i-esim task
			Task task = allDwlAndSto.get(i);

			// if the task is inside the interval defined in input
			if ((task.getStartTime().getTime() < endSearch) && (task.getEndTime().getTime() > startSearch)) {
				// add it to the list of returned elements
				allAcceptedTasks.add(task);
			}
		}
		return allAcceptedTasks;
	}

	/**
	 * Gets the all accepted tasks.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return the all accepted tasks
	 */
	public List<Task> getAllAcceptedTasks(String sessionId, int currentInstance, DroolsParameters droolsParams) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// create an empty list of tasks
		List<Task> allAcceptedTasks = new ArrayList<>();

		// invoke the drools query to receive all the accepted tasks
		QueryResults queryResults = kie.getQueryResults("getAllAcceptedTasks");
		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// convert the i-sim result into a task
			Task task = (Task) iterator.next().get("$task");

			// add it to the list
			allAcceptedTasks.add(task);
		}
		// iterate over the tasks
		for (int i = 0; i < allAcceptedTasks.size(); i++) {
			// orint them on console
			// System.out.println(allAcceptedTasks.get(i) + "\n");
		}
		return allAcceptedTasks;
	}

	/**
	 * Gets the all vis overlap or after date.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param startCheck      the start check
	 * @param satelliteId     the satellite id
	 * @return the all vis overlap or after date
	 */
	public List<Visibility> getAllVisOverlapOrAfterDate(String sessionId, int currentInstance,
			DroolsParameters droolsParams, Date startCheck, String satelliteId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
		// reate an empty list of visibilities
		List<Visibility> receiveVis = new ArrayList<>();

		// get the results of the drools query to receive all the visibilities
		// that are overlapped or after a date, for a given satellite id
		QueryResults queryResults = kie.getQueryResults("allVisOverlapOrAfterDate", startCheck, satelliteId);
		Iterator<QueryResultsRow> iterator = queryResults.iterator();
		// iterate over the results
		while (iterator.hasNext()) {
			// extract the i-esim result and convert it to a visibility
			Visibility vis = (Visibility) iterator.next().get("$vis");

			// add it to the list
			receiveVis.add(vis);
		}
		return receiveVis;
	}

	/**
	 * Gets the all vis overlap interval.
	 *
	 * @param droolsParams the drools params
	 * @param startCheck   the start check
	 * @param endCheck     the end check
	 * @param satelliteId  the satellite id
	 * @return the all vis overlap interval
	 */
	public List<Visibility> getAllVisOverlapInterval(DroolsParameters droolsParams, Date startCheck, Date endCheck,
			String satelliteId) {
		// create an empty list of visibilities
		List<Visibility> allVisInInterval = new ArrayList<>();

		// iterate over all the visibilities
		for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {
			// extract the i-esim visibility
			Visibility currentVis = droolsParams.getAllVisibilities().get(i);

			// if the visibility is in overlap with given interval and is
			// related to the given satellite id
			if ((currentVis.getStartTime().getTime() <= endCheck.getTime())
					&& (currentVis.getEndTime().getTime() >= startCheck.getTime())
					&& currentVis.getSatelliteId().equalsIgnoreCase(satelliteId)) {
				// add it to the returned list
				allVisInInterval.add(currentVis);
			}
		}
		return allVisInInterval;
	}

	/**
	 * Gets the all paw overlap interval.
	 *
	 * @param droolsParams the drools params
	 * @param startCheck   the start check
	 * @param endCheck     the end check
	 * @param satelliteId  the satellite id
	 * @return the all paw overlap interval
	 */
	public List<PAW> getAllPawOverlapInterval(DroolsParameters droolsParams, Date startCheck, Date endCheck,
			String satelliteId) {
		// create an empty list of paw
		List<PAW> allPawInInterval = new ArrayList<>();

		// iterate over all the paws
		for (int i = 0; i < droolsParams.getAllPAWS().size(); i++) {
			// extract the i-esim paw
			PAW currentPaw = droolsParams.getAllPAWS().get(i);

			// if the paw is in overlap with interval given as input
			if ((currentPaw.getStartTime().getTime() <= endCheck.getTime())
					&& (currentPaw.getEndTime().getTime() >= startCheck.getTime())
					&& currentPaw.getSatelliteId().equalsIgnoreCase(satelliteId)) {
				// add it to the list
				allPawInInterval.add(currentPaw);
			}
		}
		return allPawInInterval;
	}

	/**
	 * Gets the related di 2 s info.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param dtoId           the dto id
	 * @return the related di 2 s info
	 */
	public Di2sInfo getRelatedDi2sInfo(String sessionId, int currentInstance, DroolsParameters droolsParams,
			String dtoId) {
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current active session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);

		// initialize a di2s object that will be returned from method
		Di2sInfo di2s = null;

		// execute the drools query to receive the di2sInfo linked with the
		// dtoId given as parameter
		QueryResults queryResults = kie.getQueryResults("getDi2sInfoAssociatedToDto", dtoId);

		Iterator<QueryResultsRow> iterator = queryResults.iterator();

		// iterate over the results
		while (iterator.hasNext()) {
			// convert the result in a di2s object
			di2s = (Di2sInfo) iterator.next().get("$di2sInfo");
		}
		return di2s;
	}

	/**
	 * Gets the sto with givenid.
	 *
	 * @param allProcessedSto the all processed sto
	 * @param id              the id
	 * @return the sto with givenid
	 */
	public Storage getStoWithGivenid(TreeMap<String, Storage> allProcessedSto, String id) {

		// initialize the storage
		Storage storage = null;

		// if the treemap is not null and not empty
		if ((allProcessedSto != null) && !allProcessedSto.isEmpty() && (allProcessedSto.get(id) != null)) {
			storage = allProcessedSto.get(id);
		}
		return storage;
	}

}