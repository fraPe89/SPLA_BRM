/**
*
* MODULE FILE NAME: Visibility.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.Date;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class Visibility.
 */
public class Visibility extends PlanningResources implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The visibility id. */
	private long contactCounter;

	/** The satellite id. */
	private String satelliteId;

	/** The owner id. */
	private String ownerId;

	/** The acq stat id. */
	private String acqStatId;

	/** The available start time L 1. */
	private Date availableStartTimeL1;

	/** The available start time L 2. */
	private Date availableStartTimeL2;

	/** The is external. */
	private boolean isExternal;

	/** The is back up. */
	private boolean isBackUp = false;

	/**
	 * Instantiates a new visibility.
	 *
	 * @param contactCounter the contact counter
	 * @param satelliteId    the satellite id
	 * @param acqStatId      the acq stat id
	 * @param ownerId        the owner id
	 * @param startTime      the start time
	 * @param endTime        the end time
	 */
	public Visibility(long contactCounter, String satelliteId, String acqStatId, String ownerId, Date startTime,
			Date endTime) {
		this.contactCounter = contactCounter;
		this.satelliteId = satelliteId;
		this.acqStatId = acqStatId;
		this.ownerId = ownerId;
		this.isExternal = false;
		super.setStartTime(startTime);
		super.setEndTime(endTime);
		this.availableStartTimeL1 = startTime;
		this.availableStartTimeL2 = startTime;
	}

	/**
	 * Gets the available start time.
	 *
	 * @param link the link
	 * @return the available start time
	 */
	public Date getAvailableStartTime(String link) {
		// initialize a date that must be returned
		Date returnedDate = null;

		// if we need the avaiable start time of sat1
		if (link.contains("1")) {
			// return the associated date
			returnedDate = this.availableStartTimeL1;
		}
		// if we need the avaiable start time of sat2
		else if (link.contains("2")) {
			// return the associated date
			returnedDate = this.availableStartTimeL2;
		}
		return DroolsUtils.getDateInMilliseconds(returnedDate);
	}

	/**
	 * Gets the acq stat id.
	 *
	 * @return the acq stat id
	 */
	public String getAcqStatId() {
		return this.acqStatId;
	}

	/**
	 * Sets the satellite id.
	 *
	 * @param satelliteId the new satellite id
	 */
	@Override
	public void setSatelliteId(String satelliteId) {
		this.satelliteId = satelliteId;
	}

	/**
	 * Gets the link more empty.
	 *
	 * @return the link more empty
	 */
	public String getLinkMoreEmpty() {
		// set the link 1 as more empty (as default)
		String maxLink = "1";

		// if the link 2 is emptiest than link 1
		if (this.availableStartTimeL1.getTime() > this.availableStartTimeL2.getTime()) {
			// return the link 2
			maxLink = "2";
		}
		return maxLink;
	}

	/**
	 * Gets the link more empty.
	 *
	 * @param size1 the size 1
	 * @param size2 the size 2
	 * @return the link more empty
	 */
	public String getLinkMoreEmptyBasedOnSize(double size1, double size2) {
		// set the link 1 as more empty (as default)
		String linkMoreEmpty = "1";

		// if the link 2 is emptiest than link 1
		if (size2 < size1) {
			// return the link 2
			linkMoreEmpty = "2";
		}
		return linkMoreEmpty;
	}

	/**
	 * Gets the owner id.
	 *
	 * @return the ownerId
	 */
	public String getOwnerId() {
		return this.ownerId;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	@Override
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Sets the available start time.
	 *
	 * @return the available start time L 1
	 */
	public Date getAvailableStartTimeL1() {
		return this.availableStartTimeL1;
	}

	/**
	 * Gets the available start time L 2.
	 *
	 * @return the available start time L 2
	 */
	public Date getAvailableStartTimeL2() {
		return this.availableStartTimeL2;
	}

	/**
	 * Sets the available start time L 1.
	 *
	 * @param availableStartTimeL1 the new available start time L 1
	 */
	public void setAvailableStartTimeL1(Date availableStartTimeL1) {
		this.availableStartTimeL1 = availableStartTimeL1;
	}

	/**
	 * Sets the available start time L 2.
	 *
	 * @param availableStartTimeL2 the new available start time L 2
	 */
	public void setAvailableStartTimeL2(Date availableStartTimeL2) {
		this.availableStartTimeL2 = availableStartTimeL2;
	}

	/**
	 * Sets the available start time.
	 *
	 * @param link                      the link
	 * @param updatedAvailableStartTime the updated available start time
	 */
	public void setAvailableStartTime(String link, Date updatedAvailableStartTime) {
		// if we need the available start time for sat1
		if (link.contains("1")) {
			// set the input date as relative to sat1
			this.availableStartTimeL1 = updatedAvailableStartTime;
		}
		// if we need the available start time for sat2
		else if (link.contains("2")) {
			// set the input date as relative to sat2
			this.availableStartTimeL2 = updatedAvailableStartTime;
		}
	}

	/**
	 * Checks if is external.
	 *
	 * @return true, if is external
	 */
	public boolean isExternal() {
		return this.isExternal;
	}

	/**
	 * Sets the external.
	 *
	 * @param isExternal the new external
	 */
	public void setExternal(boolean isExternal) {
		this.isExternal = isExternal;
	}

	/**
	 * Gets the contact counter.
	 *
	 * @return the contact counter
	 */
	public long getContactCounter() {
		return this.contactCounter;
	}

	/**
	 * @return the startTime
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/**
	 * @return the endtime
	 */
	@Override
	public Date getEndTime() {
		return super.getEndTime();
	}

	/**
	 * toString del metodo.
	 *
	 * @return the string
	 */
	@Override
	public String toString() { /**
								 * toString del metodo
								 */
		return "Visibility [contactCounter=" + this.contactCounter + ", satelliteId=" + this.satelliteId + ", ownerId="
				+ this.ownerId + ", acqStatId=" + this.acqStatId + ",\n startTime="
				+ DroolsUtils.getDateInMilliseconds(this.getStartTime()) + ", endTime :"
				+ DroolsUtils.getDateInMilliseconds(this.getEndTime()) + "\n availableStartTimeL1="
				+ this.availableStartTimeL1 + ",\n availableStartTimeL2=" + this.availableStartTimeL2 + ", isExternal="
				+ this.isExternal + "]";

		// this is the string
		// with all the informations about the visibility
	}

	/**
	 * Sets the acq stat id.
	 *
	 * @param acqStatId the new acq stat id
	 */
	public void setAcqStatId(String acqStatId) {
		this.acqStatId = acqStatId;
	}

	/**
	 * Checks if is back up.
	 *
	 * @return true, if is back up
	 */
	public boolean isBackUp() {
		return this.isBackUp;
	}

	/**
	 * Sets the back up.
	 *
	 * @param isBackUp the new back up
	 */
	public void setBackUp(boolean isBackUp) {
		this.isBackUp = isBackUp;
	}

}
