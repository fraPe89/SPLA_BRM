/**
*
* MODULE FILE NAME:	FunctionUtils.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		18 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.nais.spla.brm.library.main.drools.rules.DtoToAcqRule;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.ElementsInvolvedOnOrbit;

/**
 * The Class FunctionUtils.
 *
 * @author francesca
 */
public class FunctionUtils {

	/**
	 * Extract ar from dto.
	 *
	 * @param id        the id
	 * @param splitChar the split char
	 * @return the string
	 */
	public static String extractArFromDto(String id, String splitChar) {
		// initialize the ar
		String ar = null;

		// get the substring from the
		// first splitChar to the end
		String subP_Pr_ar_String = id.substring(id.indexOf(splitChar) + 1, id.length());

		// get the index of the start of the ar
		int initialArPos = subP_Pr_ar_String.indexOf(splitChar) + 1;
		String ar_String = subP_Pr_ar_String.substring(initialArPos, subP_Pr_ar_String.length());

		// get the index of the end of the ar
		int finalArPos = ar_String.indexOf(splitChar);
		if (finalArPos >= 0) {
			ar = ar_String.substring(0, finalArPos);
		}
		return ar;
	}

	/**
	 * Extract pr from dto.
	 *
	 * @param id        the id
	 * @param splitChar the split char
	 * @return the string
	 */
	public static String extractPrFromDto(String id, String splitChar) {
		// initialize the pr
		String pr = null;

		// get the substring from the first
		// char of the pr to the end
		String subP_Pr_ar_String = id.substring(id.indexOf(splitChar) + 1, id.length());
		int startPrPos = id.indexOf(splitChar) + 1;
		int finalPrPos = subP_Pr_ar_String.indexOf(splitChar);

		// extract the effective pr
		pr = id.substring(id.indexOf(splitChar) + 1, startPrPos + finalPrPos);
		return pr;
	}

	/**
	 * Rank up down.
	 *
	 * @param acq    the acq
	 * @param rankUp the rank up
	 * @return the string
	 */
	public String rankUpDown(HashMap<String, Acquisition> allAccepted, Acquisition acq, boolean rankUp,
			Map<String, Acquisition> allRejectedAcq) {

		// initialize the selected rank to null
		String selectedRank = null;

		// get all the acquisitions involved in reject of current acq
		List<String> acqInvolved = getAllAcqInvolvedInReject(acq.getId(), allRejectedAcq);

		// convert the id of the acquisitions
		List<Acquisition> allAcqRelatedToPartner = getOnlyAcquisitionsRelatedToPartner(allAccepted, acq, acqInvolved,
				allRejectedAcq);
		// logger.debug("list of acquisition involved in reject :" +
		// allAcqRelatedToPartner);

		// if there are acquisitions in overlap
		if ((allAcqRelatedToPartner != null) && !allAcqRelatedToPartner.isEmpty()) {
			// sort acquisitions by priority
			sortAcqByPriority(allAcqRelatedToPartner);
			// logger.debug("list of acquisition ordered by priority :" +
			// allAcqRelatedToPartner);

			// if is requested a rank up
			if (rankUp) {
				// get the highest priority element
				selectedRank = allAcqRelatedToPartner.get(0).getIdTask();
				// logger.debug("get the highest rank acq :" + selectedRank);
			}
			// if is requested a rank down
			else {
				// get the lowest priority element
				selectedRank = allAcqRelatedToPartner.get(allAcqRelatedToPartner.size() - 1).getIdTask();
				// logger.debug("get the lowest rank acq :" + selectedRank);
			}
		}
		// return the choosen element id
		return selectedRank;
	}

	/**
	 * Gets the all acq involved in reject.
	 *
	 * @param acqId the acq id
	 * @return the all acq involved in reject
	 */
	public List<String> getAllAcqInvolvedInReject(String acqId, Map<String, Acquisition> rejected) {
		// create an empty list for the id of elements involved
		List<String> acqInvolved = new ArrayList<>();

		// create an empty Acquisition
		Acquisition acq = null;

		// if into the map there is the id of the acquisition given as input
		if (rejected.get(acqId) != null) {
			// extract the relative acq
			acq = rejected.get(acqId);

			// iterate over the reason of reject linked with the acquisition
			for (int i = 0; i < acq.getReasonOfReject().size(); i++) {
				// if there are elements involved
				if (acq.getReasonOfReject().get(i).getElementsInvolved() != null) {
					// iterate over the map of involved elements on orbit (the
					// orbit is the key of the map)
					for (Map.Entry<Double, List<ElementsInvolvedOnOrbit>> elementsInvolvedIterator : acq
							.getReasonOfReject().get(i).getElementsInvolved().entrySet()) {
						List<ElementsInvolvedOnOrbit> elementsInvolvedOnOrbit = elementsInvolvedIterator.getValue();

						// iterate over the sliding window impacted in reject
						// cause
						for (int j = 0; j < elementsInvolvedOnOrbit.size(); j++) {
							// for each sliding window extract the elements in
							// overlap
							List<String> potentialAcqInvolved = elementsInvolvedOnOrbit.get(j).getElementsInvolved();

							// invoke the function to add the id at the list of
							// elements involved
							addAcquisition(acqInvolved, potentialAcqInvolved);
						}
					}
				}
			}
		}

		return acqInvolved;
	}

	/**
	 * Adds the acquisition.
	 *
	 * @param acqInvolved          the acq involved
	 * @param potentialAcqInvolved the potential acq involved
	 */
	private void addAcquisition(List<String> acqInvolved, List<String> potentialAcqInvolved) {
		// if there is at least an element in the list of potential Acq involved
		if ((potentialAcqInvolved != null) && !potentialAcqInvolved.isEmpty()) {
			// iterate over the list
			for (int i = 0; i < potentialAcqInvolved.size(); i++) {
				// if there isn't a match
				if (!(acqInvolved.contains((potentialAcqInvolved.get(i))))) {
					// add to the list
					acqInvolved.add(potentialAcqInvolved.get(i));
				}
			}
		}
	}

	/**
	 * Sort acq by priority.
	 *
	 * @param acqList the acq list
	 */
	public void sortAcqByPriority(List<Acquisition> acqList) {
		// create a new Comparator
		Collections.sort(acqList, new Comparator<Acquisition>() {

			@Override
			// given two tasks
			public int compare(Acquisition acq1, Acquisition acq2) {
				// compare and sort them by startTime
				// return acq1.getPriority() - (acq2.getPriority());

				int change = 0;
				if (acq1.getPrType().compareTo(acq2.getPrType()) == 0) {
					// same prType
					// -> order by priority
					int priorityAcq1 = acq1.getPriority();
					int priorityAcq2 = acq2.getPriority();
					change = priorityAcq1 - priorityAcq2;
				} else {
					// different prType
					// -> order by prType
					int pointsAcq1 = DtoToAcqRule.setPrTypePoints(acq1);
					int pointsAcq2 = DtoToAcqRule.setPrTypePoints(acq2);
					change = pointsAcq1 - pointsAcq2;
				}
				return change;
			}
		});
	}

	/**
	 * Gets the only acquisitions related to partner.
	 *
	 * @param acq         the acq
	 * @param acqInvolved the acq involved
	 * @return the only acquisitions related to partner
	 */
	private List<Acquisition> getOnlyAcquisitionsRelatedToPartner(HashMap<String, Acquisition> allAccepted,
			Acquisition acq, List<String> acqInvolved, Map<String, Acquisition> allRejectedAcq) {
		// create an empty list of acquisitions
		List<Acquisition> onlyValidAcq = new ArrayList<>();

		// get all the id of the partners involved with the rejected acquisition
		List<String> allPartnersOfRejectedAcq = getPartnerInvolved(acq);

		// iterate over the acquisitions involved in the cause of reject
		for (int i = 0; i < acqInvolved.size(); i++) {
			// if there is an associated acq
			if (allAccepted.containsKey(acqInvolved.get(i))) {
				// get all the id of the partners involved with this acquisition
				List<String> allPartnersWithCurrentAcq = getPartnerInvolved(allAccepted.get(acqInvolved.get(i)));

				// iterate over the partners involved in the rejected one
				for (int j = 0; j < allPartnersOfRejectedAcq.size(); j++) {
					// if the partner's list of the current acquisition contains
					// at least one partner of the rejected one
					if (allPartnersWithCurrentAcq.contains(allPartnersOfRejectedAcq.get(j))) {
						// add the current acq to the list of valid acq
						if (!onlyValidAcq.contains(allAccepted.get(acqInvolved.get(i)))) {
							onlyValidAcq.add(allAccepted.get(acqInvolved.get(i)));
						}
					}
				}
			}
		}
		return onlyValidAcq;
	}

	/**
	 * Gets the partner involved.
	 *
	 * @param acq the acq
	 * @return the partner involved
	 */
	public List<String> getPartnerInvolved(Acquisition acq) {
		// initialize an empty list of string that will contains all the
		// partners id involved with the acq
		List<String> allPartnersInvolved = new ArrayList<>();

		// iterate over the userInfo linked to the acq
		for (int i = 0; i < acq.getUserInfo().size(); i++) {
			// add the id of the partner
			allPartnersInvolved.add(acq.getUserInfo().get(i).getOwnerId());
		}
		return allPartnersInvolved;
	}

}
