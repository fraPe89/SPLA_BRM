/**
 *
 * MODULE FILE NAME:	GPSDownloadManagement.java
 *
 * MODULE TYPE:		Class definition
 *
 * FUNCTION:		<Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:		06 mag 2018
 *
 * AUTHORS:		francesca
 *
 * DESIGN ISSUE:		1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 06 mag 2018          | francesca    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PlanningResources;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;

// TODO: Auto-generated Javadoc
/**
 * The Class GPSDownloadManagement.
 *
 * @author francesca
 */
public class GPSDownloadManagement {

	/** The dwl utils. */
	DownloadManagement dwlMng = new DownloadManagement();

	/**
	 * Plan gps sectors for current vis.
	 *
	 * @param cont                    the cont
	 * @param allExternalVisibilities the all external visibilities
	 * @param allPAWS                 the all PAWS
	 * @param droolsParams            the drools params
	 * @param external                the external
	 * @param resFuncs                the res funcs
	 * @param satId                   the sat id
	 * @return the int
	 */
	public int planGpsSectorsForCurrentVis(int cont, HashMap<String, Visibility> allExternalVisibilities,
			List<PAW> allPAWS, DroolsParameters droolsParams, boolean external, ResourceFunctions resFuncs,
			String satId) {
		// initialize the ps
		String currentPs = droolsParams.getGPSreservedpacketStore();

		// extract the treemap of treemap with
		// all the downloads for satellite
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlForSatellite = resFuncs
				.getDownloadsAssociatedToSat(satId);

		int lastAvailablePosition = getLastPositionOnBuffer(external, droolsParams, dwlForSatellite, satId);
		System.out.println(lastAvailablePosition);
		if (!allExternalVisibilities.isEmpty()) {
			// create an empty list of dlo and paw
			TreeMap<String, PlanningResources> allDloAndPaw = new TreeMap<>();

			// get the logger
			Logger logger = DroolsParameters.getLogger();

			// set as previous element the mission horizon start time (as
			// default)
			long previousElement = droolsParams.getCurrentMH().getStart().getTime();
			logger.debug("CREATE GPS : getting all visibilities and paws");
			logger.debug("CREATE GPS : previousElement start time : " + new Date(previousElement));
			boolean enableFlag = true;

			// initialize downloadSize
			double downloadSize = 0;

			// initialize gapWithPrevious
			long gapWithPrevious = 0;

			TreeMap<String, Visibility> filteredVis = resizeVisForPaw(allExternalVisibilities, allPAWS);

			// insert all the visibilities
			// inside the treemap
			for (Map.Entry<String, Visibility> allVis : filteredVis.entrySet()) {

				// if the i-esim visibility is relative to the current sat id
				// given as input
				if (allVis.getValue().getSatelliteId().contains(satId)) {
					// add it to the map
					allDloAndPaw.put(allVis.getValue().getStartTime().getTime()
							+ allVis.getValue().getEndTime().getTime() + "VIS", allVis.getValue());

				}
			}

			/*
			 * insert all the visibilities inside the treemap, with start and stop to detect
			 * when must be created the interrups for GPS
			 */

			for (int i = 0; i < allPAWS.size(); i++) {
				/*
				 * for all the type of paw different from STTOCCULTATION
				 */
				// logger.debug("CREATE GPS : check for paw :" +
				// allPAWS.get(i));
				List<PAWType> pawExcludedFromStoreAux = droolsParams.getSatWithId(satId).getSatelliteProperties()
						.getPawExclusionList();

				if (!pawExcludedFromStoreAux.contains(allPAWS.get(i).getType())
						&& allPAWS.get(i).getSatelliteId().contains(satId)) {
					/*
					 * add the start and the stop of the paw to the list of elements
					 */
					// logger.debug("CREATE GPS : adding paw " + allPAWS.get(i)
					// + " to the list of elements that must be processed");
					allDloAndPaw.put(
							allPAWS.get(i).getStartTime().getTime() + allPAWS.get(i).getEndTime().getTime() + "PAW1",
							allPAWS.get(i));
					allDloAndPaw.put(
							allPAWS.get(i).getStartTime().getTime() + allPAWS.get(i).getEndTime().getTime() + "PAW2",
							allPAWS.get(i));
				}
			}

			/*
			 * iterate over all the ordered elements (both paw and dlo)
			 */
			for (Map.Entry<String, PlanningResources> orderedElements : allDloAndPaw.entrySet()) {
				String resource = orderedElements.getKey();
				PlanningResources element = orderedElements.getValue();
				long resourceAtTime = 0;

				if (resource.contains("PAW1") || resource.contains("VIS")) {
					resourceAtTime = element.getStartTime().getTime();
				} else {
					resourceAtTime = element.getEndTime().getTime();
				}
				// logger.debug("CREATE GPS : current Element start time : " +
				// new Date(resourceAtTime));

				PlanningResources currentRes = orderedElements.getValue();
				if (currentRes instanceof Visibility) {
					Visibility currentVis = (Visibility) currentRes;

					/*
					 * create a space on vis for GPS data downloads
					 */
					gapWithPrevious = resourceAtTime - previousElement;

					// compute the downloaded size MB
					downloadSize = (droolsParams.getSpaceWireForGps() / 8.0) * (gapWithPrevious / 1000.0);
					logger.debug("CREATE GPS : downloadSize : " + downloadSize);

					downloadSize = java.lang.Math.ceil(downloadSize);
					if (downloadSize > 0) {
						// create the gps
						lastAvailablePosition = createDownloadGPS(cont, lastAvailablePosition, currentPs, currentVis,
								downloadSize, resFuncs, droolsParams);
					}
					cont++;

					// set the prev element
					previousElement = resourceAtTime;
				} else // there is a paw
				{
					// logger.debug("CREATE GPS : processing paw");
					// get the current paw
					PAW currentPaw = (PAW) currentRes;
					/*
					 * if we are checking the start time of the paw
					 */
					if (resourceAtTime == currentPaw.getStartTime().getTime()) {
						// create a store aux to disable
						// gps download before the paw
						enableFlag = false;
						// currentPs = complementPacketStoreId;

						// compute the backlog
						// backLog = (int) ((spaceWireLink / 8.0) *
						// (gapWithPrevious * 1000.0));

						StoreAUX gpsStoreSwitchOn = CreateTaskManagement.createStoreAux(currentPaw, enableFlag,
								currentPs);
						addStoreAuxForSat(resFuncs, satId, currentPs, gpsStoreSwitchOn);
					} else {
						// create a store aux to enable gps download after a paw

						enableFlag = true;
						StoreAUX gpsStoreSwitchOff = CreateTaskManagement.createStoreAux(currentPaw, enableFlag,
								currentPs);

						addStoreAuxForSat(resFuncs, satId, currentPs, gpsStoreSwitchOff);
					}

				}
			}
		}
		return cont;
	}

	/**
	 * Gets the last position on buffer.
	 *
	 * @param external        the external
	 * @param droolsParams    the drools params
	 * @param dwlForSatellite the dwl for satellite
	 * @param satId           the sat id
	 * @return the last position on buffer
	 */
	private int getLastPositionOnBuffer(boolean external, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlForSatellite, String satId) {
		int lastPosition = 0;
		List<Download> allGpsDownloads = DownloadManagement.getAllDwlFromTreeMapGPS(satId, droolsParams,
				dwlForSatellite);
		if (allGpsDownloads.size() == 0) {
			if (external) {
				lastPosition = droolsParams.getLastPositionGpsExt();
			} else {
				lastPosition = droolsParams.getLastPositionGpsPdm();
			}
		} else {
			lastPosition = DownloadManagement.getLastPositionForGps(droolsParams, allGpsDownloads, external);
		}
		return lastPosition;
	}

	/**
	 * Adds the store aux for sat.
	 *
	 * @param resFuncs         the res funcs
	 * @param satId            the sat id
	 * @param currentPs        the current ps
	 * @param gpsStoreSwitchOn the gps store switch on
	 */
	private void addStoreAuxForSat(ResourceFunctions resFuncs, String satId, String currentPs,
			StoreAUX gpsStoreSwitchOn) {

		// receive all the storeAux
		// plannd for sat with the id given as input
		List<StoreAUX> allStoreAuxForSat = resFuncs.getAllStoAuxForSatellite(satId);

		// iitialize the boolean variable to false
		boolean found = false;

		// iterate over all the storeAux
		for (int i = 0; i < allStoreAuxForSat.size(); i++) {
			// extract the i-esim storeAux
			StoreAUX currentStoreAux = allStoreAuxForSat.get(i);

			if (currentStoreAux.getStartTime().getTime() == gpsStoreSwitchOn.getStartTime().getTime()) {
				// if the ps isn't in the list
				// of packet store id served by the current storeAux
				if (!currentStoreAux.getPacketStoreId().contains(currentPs)) {
					// add it
					currentStoreAux.getPacketStoreId().concat("_" + currentPs);
				}
				// found
				found = true;
				break;
			}
		}
		//f not found
		if (!found) {
			// add the whole gps
			allStoreAuxForSat.add(gpsStoreSwitchOn);
		}
	}

	/**
	 * Resize vis for paw.
	 *
	 * @param allExternalVisibilities the all external visibilities
	 * @param allPAWS                 the all PAWS
	 * @return the list
	 */
	public static List<Visibility> resizeVisForPaw(List<Visibility> allExternalVisibilities, List<PAW> allPAWS) {
		// create an empty treemap of visibilties
		List<Visibility> allFilteredVis = new ArrayList<>();

		// iterate over the visibilities given in input
		for (int i = 0; i < allExternalVisibilities.size(); i++) {
			// extract the i-esim visibility
			Visibility vis = allExternalVisibilities.get(i);

			//            vis.setStartTime(allVis.getValue().getStartTime());
			//            vis.setEndTime(allVis.getValue().getEndTime());
			//            vis.setAvailableStartTime("1", allVis.getValue().getStartTime());
			//            vis.setAvailableStartTime("2", allVis.getValue().getStartTime());

			// detect all the paw that are in overlap with the current visibility
			List<PAW> pawInOverlap = detectOverlapPaw(vis, allPAWS);

			// if there aren't paw in overlap
			if (pawInOverlap.size() == 0) {
				// add vis without modifications
				addVis(vis, allFilteredVis);

			}
			// if there is at least a paw in overlap
			else {
				// iterate over the overlapped paw
				for (int j = 0; j < pawInOverlap.size(); j++) {
					// extract the i-esim paw
					PAW paw = pawInOverlap.get(j);

					if ((paw.getStartTime().getTime() <= vis.getStartTime().getTime())
							&& (paw.getEndTime().getTime() >= vis.getEndTime().getTime())) {
						System.out.println("no need to  add vis -> totally covered by paw");
					} else if ((paw.getStartTime().getTime() <= vis.getStartTime().getTime())
							&& (paw.getEndTime().getTime() < vis.getEndTime().getTime())) {
						System.out.println("paw starts before vis but ends before -> outside start");
						vis.setStartTime(paw.getEndTime());
						vis.setAvailableStartTimeL1(paw.getEndTime());
						vis.setAvailableStartTimeL2(paw.getEndTime());
						addVis(vis, allFilteredVis);

					} else if ((paw.getStartTime().getTime() > vis.getStartTime().getTime())
							&& (paw.getEndTime().getTime() >= vis.getEndTime().getTime())) {
						System.out.println("paw starts after vis but ends before -> outside end");
						vis.setEndTime(paw.getStartTime());
						addVis(vis, allFilteredVis);

					} else {
						System.out.println("paw totally included in vis -> split visibilities");
						Visibility vis1 = (Visibility) DroolsUtils.deepClone(vis);
						vis1.setStartTime(paw.getEndTime());
						vis1.setAvailableStartTimeL1(paw.getEndTime());
						vis1.setAvailableStartTimeL2(paw.getEndTime());

						vis1.setEndTime(vis.getEndTime());

						vis.setEndTime(paw.getStartTime());
						addVis(vis, allFilteredVis);
						addVis(vis1, allFilteredVis);
					}
				}
			}

		}
		return allFilteredVis;
	}

	/**
	 * Resize vis for paw.
	 *
	 * @param allExternalVisibilities the all external visibilities
	 * @param allPAWS                 the all PAWS
	 * @return the tree map
	 */
	public static TreeMap<String, Visibility> resizeVisForPaw(HashMap<String, Visibility> allExternalVisibilities,
			List<PAW> allPAWS) {
		// create an empty treemap of visibilties
		TreeMap<String, Visibility> allFilteredVis = new TreeMap<>();

		// iterate over the visibilities given in input
		for (Map.Entry<String, Visibility> allVis : allExternalVisibilities.entrySet()) {
			// extract the i-esim visibility
			Visibility vis = allVis.getValue();

			//            vis.setStartTime(allVis.getValue().getStartTime());
			//            vis.setEndTime(allVis.getValue().getEndTime());
			//            vis.setAvailableStartTime("1", allVis.getValue().getStartTime());
			//            vis.setAvailableStartTime("2", allVis.getValue().getStartTime());

			// detect all the paw that are in overlap with the current visibility
			List<PAW> pawInOverlap = detectOverlapPaw(allVis.getValue(), allPAWS);

			// if there aren't paw in overlap
			if (pawInOverlap.size() == 0) {
				// add vis without modifications
				addVis(vis, allFilteredVis);

			}
			// if there is at least a paw in overlap
			else {
				// iterate over the overlapped paw
				for (int i = 0; i < pawInOverlap.size(); i++) {
					// extract the i-esim paw
					PAW paw = pawInOverlap.get(i);

					if ((paw.getStartTime().getTime() <= vis.getStartTime().getTime())
							&& (paw.getEndTime().getTime() >= vis.getEndTime().getTime())) {
						System.out.println("no need to  add vis -> totally covered by paw");
					} else if ((paw.getStartTime().getTime() <= vis.getStartTime().getTime())
							&& (paw.getEndTime().getTime() < vis.getEndTime().getTime())) {
						System.out.println("paw starts before vis but ends before -> outside start");
						vis.setStartTime(paw.getEndTime());
						vis.setAvailableStartTimeL1(paw.getEndTime());
						vis.setAvailableStartTimeL2(paw.getEndTime());
						addVis(vis, allFilteredVis);

					} else if ((paw.getStartTime().getTime() > vis.getStartTime().getTime())
							&& (paw.getEndTime().getTime() >= vis.getEndTime().getTime())) {
						System.out.println("paw starts after vis but ends before -> outside end");
						vis.setEndTime(paw.getStartTime());
						addVis(vis, allFilteredVis);

					} else {
						System.out.println("paw totally included in vis -> split visibilities");
						Visibility vis1 = (Visibility) DroolsUtils.deepClone(vis);
						vis1.setStartTime(paw.getEndTime());
						vis1.setAvailableStartTimeL1(paw.getEndTime());
						vis1.setAvailableStartTimeL2(paw.getEndTime());

						vis1.setEndTime(vis.getEndTime());

						vis.setEndTime(paw.getStartTime());
						addVis(vis, allFilteredVis);
						addVis(vis1, allFilteredVis);
					}
				}
			}

		}
		return allFilteredVis;
	}

	/**
	 * Adds the vis.
	 *
	 * @param vis            the vis
	 * @param allFilteredVis the all filtered vis
	 */
	private static void addVis(Visibility vis, TreeMap<String, Visibility> allFilteredVis) {
		if (!allFilteredVis.containsValue(vis)) {
			// add to the list
			allFilteredVis.put(vis.getStartTime() + DownloadManagement.concatVisId(vis.getSatelliteId(), vis), vis);
		}
	}

	/**
	 * Adds the vis.
	 *
	 * @param vis            the vis
	 * @param allFilteredVis the all filtered vis
	 */
	private static void addVis(Visibility vis, List<Visibility> allFilteredVis) {
		if (!allFilteredVis.contains(vis)) {
			// add to the list
			allFilteredVis.add(vis);
		}
	}

	/**
	 * Detect overlap paw.
	 *
	 * @param value   the value
	 * @param allPAWS the all PAWS
	 * @return the list
	 */
	public static List<PAW> detectOverlapPaw(Visibility value, List<PAW> allPAWS) {

		// create an empty list of overlapped paw
		List<PAW> pawInOverlap = new ArrayList<>();

		// iterate over all the paws givn as input
		for (int i = 0; i < allPAWS.size(); i++) {
			// if there is overlap
			if ((allPAWS.get(i).getStartTime().getTime() <= value.getEndTime().getTime())
					&& (allPAWS.get(i).getEndTime().getTime() >= value.getStartTime().getTime())) {
				pawInOverlap.add(allPAWS.get(i));
			}
		}

		return pawInOverlap;
	}

	/**
	 * this method is used for create a download of type GPS.
	 *
	 * @param cont                  the con
	 * @param lastAvailablePosition t
	 * @param packet                the packet
	 * @param currentVis            the current vis
	 * @param downloadSize          the download size
	 * @param resFuncs              the res funcs
	 * @param droolsParams          the drools params
	 * @return the int
	 */
	public static int createDownloadGPS(int cont, int lastAvailablePosition, String packet, Visibility currentVis,
			double downloadSize, ResourceFunctions resFuncs, DroolsParameters droolsParams) {
		DownloadManagement dwlMng = new DownloadManagement();
		// create a new array list of elements in overlap
		List<Visibility> allVisInOverlap = new ArrayList<>(Arrays.asList(currentVis));
		int gpsBufferSize = droolsParams.getSatWithId(currentVis.getSatelliteId()).getSatelliteProperties()
				.getMaxAvailableBufferSizeGps();

		SatelliteProperties satProp = droolsParams.getSatWithId(currentVis.getSatelliteId()).getSatelliteProperties();
		if (java.lang.Math.ceil(downloadSize / satProp.getSingleSectorDimension()) > gpsBufferSize) {

		}

		// extract the treemap of treemap with
		// all the downloads for satellite
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlForSatellite = resFuncs
				.getDownloadsAssociatedToSat(currentVis.getSatelliteId());

		// compute duration of gps
		// long gpsPeriodAsSeconds = (long) ((downloadSize * 8.0) /
		// droolsParams.getSpaceWireForGps());
		long gpsPeriodAsSeconds = (long) (((downloadSize / satProp.getDownlinkPerChannel()) * 8) * 1000);

		// if the gps has a valid duration
		if (gpsPeriodAsSeconds > 0) {
			// set end time of gps
			Date endOfGPSPeriodOnVis = checkLastPeriodAvailableOnVis(gpsPeriodAsSeconds,
					droolsParams.getGpsAlwaysPlannedOnLink(), currentVis, dwlForSatellite);

			/*
			 * long psDurationInMilliSec = (long) (((downloadableSectors) /
			 * (downlinkPerChannel / 8)) 1000);
			 */

			// set start time of gps
			Date startOfGpsPeriodOnVis = new Date(endOfGPSPeriodOnVis.getTime() - (gpsPeriodAsSeconds));

			if (startOfGpsPeriodOnVis.getTime() < currentVis.getStartTime().getTime()) {
				startOfGpsPeriodOnVis = currentVis.getStartTime();
			}
			// create a new download
			Download dwlForGps = new Download(currentVis.getSatelliteId());

			// set the task type
			dwlForGps.setTaskType(TaskType.DOWNLOAD);

			// set the acq station id
			dwlForGps.setAcqStatId(currentVis.getAcqStatId());

			// set the correct link
			boolean plannedOnL2 = false;

			// if the configurable value for
			// where plan the gps is the link2
			if (droolsParams.getGpsAlwaysPlannedOnLink().contains("2")) {
				plannedOnL2 = true;
			}
			// set setIdTask
			dwlForGps.setIdTask("GPS" + cont);

			// setCarrierL2Selection
			dwlForGps.setCarrierL2Selection(plannedOnL2);

			// setContactCounter
			dwlForGps.setContactCounter(currentVis.getContactCounter());

			// setStartTime
			dwlForGps.setStartTime(startOfGpsPeriodOnVis);

			// setPacketStoreStrategy
			dwlForGps.setPacketStoreStrategy(DownlinkStrategy.RETAIN);

			// dummy acquisition
			Acquisition dummyAcq = new Acquisition();
			dummyAcq.setIdTask("GPS" + cont);

			// setRelatedTaskId
			dwlForGps.setRelatedTaskId("GPS" + cont);

			double dwlSize = java.lang.Math.ceil(downloadSize / satProp.getSingleSectorDimension());
			int dwlSizeInt = (int) dwlSize;
			// set the size
			dwlForGps.setDownloadedSize(dwlSizeInt);

			// setEndTime
			dwlForGps.setEndTime(endOfGPSPeriodOnVis);

			// setStartTime
			dwlForGps.setStartTime(startOfGpsPeriodOnVis);

			// setPacketStoreNumber
			dwlForGps.setPacketStoreNumber(Integer.parseInt(packet));

			// setInitialSector
			dwlForGps.setInitialSector(lastAvailablePosition);

			if (lastAvailablePosition + dwlSizeInt > gpsBufferSize) {
				lastAvailablePosition = (lastAvailablePosition + dwlSizeInt) % gpsBufferSize;

			} else {
				lastAvailablePosition = lastAvailablePosition + dwlSizeInt;
			}
			// setFinalSector
			dwlForGps.setFinalSector(lastAvailablePosition);

			System.out.println(dwlForGps);
			// insert into the treemap
			dwlMng.insertInIDownloadStructure(dwlForGps, allVisInOverlap, dwlForSatellite);
		}
		return lastAvailablePosition;
	}

	/**
	 * Check last period available on vis.
	 *
	 * @param durationGps     the duration gps
	 * @param linkForGps      the link for gps
	 * @param currentVis      the current vis
	 * @param dwlForSatellite the dwl for satellite
	 * @return the date
	 */
	public static Date checkLastPeriodAvailableOnVis(long durationGps, String linkForGps, Visibility currentVis,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlForSatellite) {
		Date endTimeGps = currentVis.getEndTime();
		String contactCounterForVis = DownloadManagement.concatVisId(currentVis.getSatelliteId(), currentVis);
		if (dwlForSatellite.containsKey(contactCounterForVis)) {
			/*
			 * it isn't the first time that the visibility is insert in treemap
			 */

			if (dwlForSatellite.get(contactCounterForVis).containsKey(linkForGps)) {
				/*
				 * if isn't the first time that the link is inserted in treemap, add the new dwl
				 * to it
				 */
				TreeMap<Long, IDownload> elementsPlannedOnLink = dwlForSatellite.get(contactCounterForVis)
						.get(linkForGps);

				// if there are others elements on vis
				if (!elementsPlannedOnLink.isEmpty()) {
					// get the last entry point on the current vis
					Long startlastElementOnVis = elementsPlannedOnLink.lastEntry().getKey();
					System.out.println("startlastElementOnVis " + startlastElementOnVis);

					/*
					 * int pos = startlastElementOnVis.indexOf("_"); if (pos>=0) {
					 * startlastElementOnVis = startlastElementOnVis.substring(0,
					 * startlastElementOnVis.indexOf("_")); System.out.println("dateAsLong "+
					 * startlastElementOnVis); } long dateAsLong =
					 * Long.parseLong(startlastElementOnVis);
					 */

					// get the last eplanned element on vis
					IDownload lastElementPlanned = elementsPlannedOnLink.lastEntry().getValue();

					/*
					 * if the last element planned exceeds the duration of the visibility or the gap
					 * between the last element planned and the end of the visibility is not enough
					 * to perform the gps
					 */
					if ((lastElementPlanned.getStopTime().getTime() >= currentVis.getEndTime().getTime())
							|| ((currentVis.getEndTime().getTime()
									- lastElementPlanned.getStopTime().getTime()) < durationGps)) {
						// set as end time the end time of the vis
						endTimeGps = new Date(startlastElementOnVis);
					} else {
						// set as end time the end time of the vis
						endTimeGps = currentVis.getEndTime();
					}
				}
			}
		}
		return endTimeGps;
	}
}
