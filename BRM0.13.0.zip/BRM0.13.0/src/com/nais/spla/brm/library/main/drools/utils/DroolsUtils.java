/**
*
* MODULE FILE NAME:	DroolsUtils.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		09 mag 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 09 mag 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.instrument.IllegalClassFormatException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.SortedMap;
import java.util.TreeMap;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import com.nais.spla.brm.library.main.drools.DroolsEnvironment;
import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SatelliteState;
import com.nais.spla.brm.library.main.ontology.resourceData.SectorAndVisForPartner;
import com.nais.spla.brm.library.main.ontology.resourceData.SizeOfSectorDwl;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.resources.Eclipse;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.InitPlanTasks;

// TODO: Auto-generated Javadoc
/**
 * The Class DroolsUtils.
 *
 * @author fpedrola
 */
public class DroolsUtils {

	/** The stub res. */
	private StubResources stubRes = new StubResources();

	/** The number of dto. */
	private static long numberOfDto;

	/** The all partners. */
	private List<Partner> allPartners = new ArrayList<>();

	/** The formatter. */
	private static SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");

	/** The all polarizations. */
	private Polarization[] allPolarizations = Polarization.values();

	/** The random. */
	private Random random = new Random();

	/**
	 * Creates the eclipse.
	 *
	 * @param start         the start
	 * @param end           the end
	 * @param associatedAcq the associated acq
	 * @param energy        the energy
	 * @return the eclipse
	 * @throws ParseException the parse exception
	 */
	/*
	 *
	 */

	public Silent createSilent(String start, String end, String associatedAcq, double energy) throws ParseException {
		// declare the start and the stop time
		Date startTime = null;
		Date endTime = null;

		// create a new instance of Silent
		Silent newSilent = null;
		// set the start time with the date as string given as input
		startTime = createDate(start);

		// set the end time with the date as string given as input
		endTime = createDate(end);

		if ((startTime != null) && (endTime != null)) {
			// set the silent parameters
			newSilent = new Silent(associatedAcq, startTime, endTime, energy);
		} else {
			throw new ParseException("parse exception :", 0);
		}
		return newSilent;
	}

	/**
	 * Gets the date in milliseconds.
	 *
	 * @param dateToConvert the date to convert
	 * @return the date in milliseconds
	 */
	public static Date getDateInMilliseconds(Date dateToConvert) {
		Date newDate = null;
		if (dateToConvert != null) {
			LocalDateTime local = convertToLocalDate(dateToConvert);
			newDate = convertToDate(local);
		}
		return newDate;
	}

	/**
	 * Convert to local date.
	 *
	 * @param dateToConvert the date to convert
	 * @return the local date time
	 */
	public static LocalDateTime convertToLocalDate(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	/**
	 * Detect if acq is out side mh.
	 *
	 * @param acq the acq
	 * @param mh  the mh
	 * @return true, if successful
	 */
	public boolean detectIfAcqIsOutSideMh(Acquisition acq, MissionHorizon mh) {
		boolean insideMh = false;
		if ((acq.getStartTime().getTime() >= mh.getStart().getTime())
				&& (acq.getStartTime().getTime() <= mh.getStop().getTime())) {
			insideMh = true;
		}
		return insideMh;
	}

	/**
	 * Convert to date.
	 *
	 * @param dateToConvert the date to convert
	 * @return the date
	 */
	public static Date convertToDate(LocalDateTime dateToConvert) {
		return java.sql.Timestamp.valueOf(dateToConvert);
	}

	/**
	 * Split tasks by category.
	 *
	 * @param allPreviousTasks the all previous tasks
	 * @return the inits the plan tasks
	 */
	public InitPlanTasks splitTasksByCategory(List<Task> allPreviousTasks) {
		// initialize an object InitPlanTasks where collect all the previously
		// processed tasks
		InitPlanTasks initPlanTasks = new InitPlanTasks();

		// iterate over the list of tasks given as input
		for (int i = 0; i < allPreviousTasks.size(); i++) {
			// extract the i-esim task
			Task currentTask = allPreviousTasks.get(i);

			// mark as previously processed
			currentTask.setPreviousMh(true);

			// set as unremovable
			currentTask.setRemovableFlag(false);

			// if the task is an acquisition
			if (currentTask instanceof Acquisition) {

				// add to the list of acq
				initPlanTasks.getAllInitAcq().add((Acquisition) currentTask);
			}
			// if is a maneuver
			else if (currentTask instanceof Maneuver) {
				// add to the list of man
				initPlanTasks.getAllInitMan().add((Maneuver) currentTask);
			}
			// if is a storage
			else if (currentTask instanceof Storage) {
				// add to the list of sto
				initPlanTasks.getAllInitSto().add((Storage) currentTask);
			}
			// if is a silent
			else if (currentTask instanceof Silent) {
				// add to the list of sil
				initPlanTasks.getAllInitSil().add((Silent) currentTask);
			}
			// if is a download
			else if (currentTask instanceof Download) {

				// add to the list of dwl
				initPlanTasks.getAllInitDwl().add((Download) currentTask);
			}
			// if is a pt
			else if (currentTask instanceof PassThrough) {
				// add to the list of pt
				initPlanTasks.getAllInitPt().add((PassThrough) currentTask);
			}
			// if is a ramp
			else if (currentTask instanceof RampCMGA) {
				// add to the list of ramps
				initPlanTasks.getAllInitRamp().add((RampCMGA) currentTask);
			}
			// if is a bite
			else if (currentTask instanceof Bite) {
				// add to the list of bite
				initPlanTasks.getAllInitBite().add((Bite) currentTask);
			}
			// if is a storeAux
			else if (currentTask instanceof StoreAUX) {
				// add to the list of storeAux
				initPlanTasks.getAllInitStoreAux().add((StoreAUX) currentTask);
			}
			// if is a cmgAxis
			else if (currentTask instanceof CMGAxis) {
				// add to the list of cmg
				initPlanTasks.getAllInitCmgAxis().add((CMGAxis) currentTask);
			} else {
				// add to the list of cmg
				initPlanTasks.getAllInitEquivDTO().add((EquivalentDTO) currentTask);
			}
		}
		return initPlanTasks;
	}

	/**
	 * Creates the date.
	 *
	 * @param dateAsString the date as string
	 * @return the date
	 */
	public static Date createDate(String dateAsString) {
		// initialize a date
		Date returnedDate = null;
		try {
			if (dateAsString.length() < 20) {
				dateAsString = dateAsString.trim() + ".000";
			}

			// format it
			returnedDate = formatter.parse(dateAsString);
		} catch (ParseException e) {
			// log the exception
			e.printStackTrace();
		}

		return DroolsUtils.getDateInMilliseconds(returnedDate);
	}

	/**
	 * Creates the parametric acquisition.
	 *
	 * @param dtoId       the dto id
	 * @param start       the start
	 * @param end         the end
	 * @param lookSide    the look side
	 * @param satelliteId the satellite id
	 * @return the acquisition
	 */
	public Acquisition createParametricAcquisition(String dtoId, String start, String end, String lookSide,
			String satelliteId) {
		Acquisition newAcq = null;
		Date startTime = null;
		Date endTime = null;
		try {
			startTime = createDate(start);
			endTime = createDate(end);
			Polarization typeOfPolarization = this.allPolarizations[this.random.nextInt(Polarization.values().length)];
			newAcq = new Acquisition(dtoId, startTime, endTime, lookSide, satelliteId, TypeOfAcquisition.STRIPMAP);
			newAcq.setPrType(PRType.HP);
			newAcq.setPolarization(typeOfPolarization);
			newAcq.setPriority(1);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return newAcq;
	}

	/**
	 * Creates the parametric acquisition.
	 *
	 * @param dtoId           the dto id
	 * @param start           the start
	 * @param end             the end
	 * @param satelliteId     the satellite id
	 * @param numberOfSectors the number of sectors
	 * @param storageDuration the storage duration
	 * @param pol             the pol
	 * @return the acquisition
	 */
	public Storage createStorage(String dtoId, String start, String end, String satelliteId, int numberOfSectors,
			double storageDuration, Polarization pol) {
		Date startTime = null;
		Date endTime = null;
		Storage newStorage = null;
		try {
			startTime = createDate(start);
			endTime = createDate(end);
			newStorage = new Storage(dtoId, numberOfSectors, startTime, endTime, pol);
			newStorage.setSatelliteId(satelliteId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newStorage;
	}

	/**
	 * Creates the download.
	 *
	 * @param satelliteId        the satellite id
	 * @param start              the start
	 * @param end                the end
	 * @param strategy           the strategy
	 * @param carrierL2Selection the carrier L 2 selection
	 * @return the download
	 */
	public Download createDownload(String satelliteId, String start, String end, DownlinkStrategy strategy,
			boolean carrierL2Selection) {
		Download dwl = null;
		Date startTime = null;
		Date endTime = null;
		try {
			startTime = createDate(start);
			endTime = createDate(end);
			dwl = new Download(satelliteId);
			dwl.setStartTime(startTime);
			dwl.setEndTime(endTime);
			dwl.setPacketStoreStrategy(strategy);
			dwl.setCarrierL2Selection(carrierL2Selection);
			dwl.setSatelliteId(satelliteId);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return dwl;
	}

	/**
	 * Creates the pass through.
	 *
	 * @param satelliteId the satellite id
	 * @param start       the start
	 * @param end         the end
	 * @return the pass through
	 */
	public PassThrough createPassThrough(String satelliteId, String start, String end) {
		PassThrough pt = null;
		Date startTime = null;
		Date endTime = null;
		try {
			startTime = createDate(start);
			endTime = createDate(end);
			pt = new PassThrough();
			pt.setStartTime(startTime);
			pt.setEndTime(endTime);
			pt.setSatelliteId(satelliteId);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return pt;
	}

	/**
	 * Creates the generic task.
	 *
	 * @param satelliteId the satellite id
	 * @param start       the start
	 * @param end         the end
	 * @return the task
	 */
	public Task createGenericTask(String satelliteId, String start, String end) {
		Task genericTask = null;
		Date startTime = null;
		Date endTime = null;
		try {
			startTime = createDate(start);
			endTime = createDate(end);
			genericTask = new Task();
			genericTask.setStartTime(startTime);
			genericTask.setEndTime(endTime);
			genericTask.setSatelliteId(satelliteId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return genericTask;
	}

	/**
	 * Creates the single dto.
	 *
	 * @param start       the start
	 * @param end         the end
	 * @param lookSide    the look side
	 * @param satelliteId the satellite id
	 * @return the dto
	 */
	public DTO createSingleDto(String start, String end, String lookSide, String satelliteId) {
		// System.out.println("all partners : " + this.allPartners);

		Partner p1 = new Partner("Partner_1", null, 100, 20);
		Partner p2 = new Partner("Partner_3", null, 100, 30);

		DTO newDto = null;
		long incrementalId = getNumberOfDto() + 1;
		// System.out.println("incremental id : " + incrementalId);
		setNumberOfDto(incrementalId);
		Date startTime = null;
		Date endTime = null;
		try {
			if (start != null) {
				startTime = createDate(start);
			}
			if (end != null) {
				endTime = createDate(end);
			}

			if ((startTime != null) && (endTime != null)) {
				Polarization typeOfPolarization = Polarization.HH;// allPolarizations[random.nextInt(Polarization.values().length)];
				newDto = new DTO("100_PR-ITA-001-HP_AR-001_DTO-" + incrementalId, startTime, endTime, lookSide,
						satelliteId, TypeOfAcquisition.PINGPONG, typeOfPolarization);
				newDto.setKey(incrementalId);
				newDto.setPol(Polarization.HH);
				newDto.setPrMode(PRMode.Standard);
				newDto.setSizeH(4000);
				newDto.setPriority((int) incrementalId);
				List<String> acqStatIdList = new ArrayList<>();

				List<UserInfo> userInfoList = new ArrayList<>();
				UserInfo userInfo1 = new UserInfo(acqStatIdList, false, p1.getPartnerId(), p1.getUgsId());
				UserInfo userInfo2 = new UserInfo(acqStatIdList, false, p2.getPartnerId(), p2.getUgsId());
				userInfoList.add(userInfo1);
				userInfoList.add(userInfo2);
				newDto.setUserInfo(userInfoList);
			} else {
				throw new ParseException("parse exception ", 0);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return newDto;
	}

	/**
	 * Sets the number of dto.
	 *
	 * @param cont the new number of dto
	 */
	public static void setNumberOfDto(long cont) {
		numberOfDto = cont;
	}

	/**
	 * Creates the maneuver.
	 *
	 * @param manId       the man id
	 * @param from        the from
	 * @param to          the to
	 * @param start       the start
	 * @param end         the end
	 * @param satelliteId the satellite id
	 * @param type        the type
	 * @return the maneuver
	 */
	public Maneuver createManeuver(String manId, String from, String to, String start, String end, String satelliteId,
			Actuator type) {
		Date startTime = null;
		Date endTime = null;
		Maneuver man = null;
		try {
			startTime = createDate(start);
			endTime = createDate(end);
			man = new Maneuver(from, to, startTime, endTime, satelliteId);
			man.setIdTask(manId);
			man.setActuator(type);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return man;
	}

	/**
	 * Creates the ramp.
	 *
	 * @param start  the start
	 * @param rampUp the ramp up
	 * @return the ramp CMGA
	 */
	public RampCMGA createRamp(String start, boolean rampUp) {
		RampCMGA newRamp = null;

		try {
			Date startTime = null;
			startTime = createDate(start);
			newRamp = new RampCMGA("manId", startTime, rampUp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newRamp;
	}

	/**
	 * Generate list of dto.
	 *
	 * @return the list
	 */

	/**
	 * Gets the number of dto.
	 *
	 * @return the number of dto
	 */
	public static long getNumberOfDto() {
		return numberOfDto;
	}

	/**
	 * Sets the number of dto.
	 */
	public static void addNumberOfDto() {
		numberOfDto++;
	}

	/**
	 * Sets the up drools.
	 *
	 * @param sessionId      the session id
	 * @param droolsParams   the drools params
	 * @param droolsInstance the drools instance
	 * @throws IllegalClassFormatException the illegal class format exception
	 */
	public void setUpDrools(String sessionId, DroolsParameters droolsParams, DroolsOperations droolsInstance)
			throws IllegalClassFormatException {

		DroolsEnvironment droolsEnv = null;

		droolsParams.setDrlRulesFile("config/droolsRules.drl");
		String localRepo = "config/";

		// droolsParams.setDrlRulesFile("C:\\Users\\franc\\git\\BRM\\config\\droolsRules.drl");
		// String localRepo = "C:\\Users\\franc\\git\\BRM\\config";

		boolean usePathForTest = true;

		droolsEnv = droolsInstance.setUpEnvironment(sessionId, droolsParams, localRepo, usePathForTest);
		droolsInstance.setDroolsEnv(droolsEnv);
	}

	/**
	 * Sets the up session.
	 *
	 * @param sessionId         the session id
	 * @param sessionType       the session type
	 * @param droolsParams      the drools params
	 * @param droolsInstance    the drools instance
	 * @param currentKieSession the current kie session
	 * @param charToSplit       the char to split
	 * @return the drools operations
	 */
	public DroolsOperations setUpSession(String sessionId, SessionType sessionType, DroolsParameters droolsParams,
			DroolsOperations droolsInstance, int currentKieSession, String charToSplit) {
		if (droolsInstance != null && droolsInstance.getDroolsEnvironment() != null) {
			droolsInstance.getDroolsEnvironment().setUpSession(sessionId, droolsParams, currentKieSession, sessionType,
					charToSplit);
		} else {
			droolsInstance = null;
		}
		return droolsInstance;
	}

	/**
	 * Check if contains the expected reason.
	 *
	 * @param rejectedElementId the rejected element id
	 * @param rejected          the rejected
	 * @param expectedReason    the expected reason
	 * @return true, if successful
	 */
	public boolean checkIfContainsTheExpectedReason(String rejectedElementId, Map<String, Acquisition> rejected,
			ReasonOfReject expectedReason) {
		boolean found = false;
		if (rejected.get(rejectedElementId) != null) {
			// System.out.println("rejected for this dto : " +
			// rejected.get(rejectedElementId));
			for (int i = 0; i < rejected.get(rejectedElementId).getReasonOfReject().size(); i++) {
				ReasonOfRejectElement reason = rejected.get(rejectedElementId).getReasonOfReject().get(i);
				if (reason.getReason().equals(expectedReason)) {
					found = true;
					break;
				}
			}
		}
		return found;
	}

	/**
	 * Check if contains the reason of reject.
	 *
	 * @param acq            the acq
	 * @param expectedReason the expected reason
	 * @return true, if successful
	 */
	public boolean checkIfContainsTheReasonOfReject(Acquisition acq, ReasonOfReject expectedReason) {
		boolean found = false;
		// System.out.println("rejected for this acq : " +
		// acq.getReasonOfReject());
		for (int i = 0; i < acq.getReasonOfReject().size(); i++) {
			ReasonOfRejectElement reason = acq.getReasonOfReject().get(i);
			if (reason.getReason().equals(expectedReason)) {
				found = true;
				break;
			}
		}
		return found;
	}

	/**
	 * Sets the up session for test.
	 *
	 * @param sessionId         the session id
	 * @param droolsParams      the drools params
	 * @param currentKieSession the current kie session
	 * @param PDHTMaxMemory     the PDHT max memory
	 * @param maxBicForTest     the max bic for test
	 * @param extraCostLeft     the extra cost left
	 * @return the drools operations
	 * @throws ParseException the parse exception
	 */
	public DroolsOperations setUpSessionForTest(String sessionId, DroolsParameters droolsParams, int currentKieSession,
			long PDHTMaxMemory, double maxBicForTest, double extraCostLeft) throws ParseException {
		DroolsOperations droolsInstance = new DroolsOperations();
		sessionId = "testUnitRules";
		currentKieSession = 1;
		Map<String, Map<Integer, Double>> maxHpBicFixedOrbit = new HashMap<>();
		int prTypeMaxNumber = 100;
		// System.out.println("populateFixedMap: " + maxHpBicFixedOrbit);

		/**
		 * create mock object of PDHT for test
		 */
		List<PDHT> allPDHT = new ArrayList<>();
		allPDHT.add(new PDHT("PDHT_1", "PDHT_1_name", "SAT_1", PDHTMaxMemory, null));
		allPDHT.add(new PDHT("PDHT_2", "PDHT_2_name", "SAT_2", PDHTMaxMemory, null));

		/**
		 * create mock object of paws for test
		 */
		PAW paw1 = this.stubRes.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00",
				PAWType.STTOCCULTATION);
		PAW paw2 = this.stubRes.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
		PAW paw3 = this.stubRes.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
		PAW paw4 = this.stubRes.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);

		/**
		 * add them to the list of paw
		 */
		List<PAW> allPawsSat1 = new ArrayList<>();

		allPawsSat1.add(paw1);
		allPawsSat1.add(paw2);

		List<PAW> allPawsSat2 = new ArrayList<>();
		allPawsSat2.add(paw3);
		allPawsSat2.add(paw4);

		List<PAW> allPaws = new ArrayList<>();
		allPaws.addAll(allPawsSat1);
		allPaws.addAll(allPawsSat2);

		/**
		 * create mock object of hpExclusions for test
		 */
		HPExclusion hpExc1 = this.stubRes.createHPExclusion("1", "10/10/2017 06:00:00", "right", "10/10/2017 07:00:00",
				"left", "SAT_1", true, false);
		HPExclusion hpExc2 = this.stubRes.createHPExclusion("1", "25/09/2017 09:00:00", "right", "25/09/2017 09:11:00",
				"left", "SAT_1", true, false);
		HPExclusion hpExc3 = this.stubRes.createHPExclusion("3", "10/09/2017 11:00:00", "right", "10/09/2017 11:12:00",
				"right", "SAT_1", true, false);
		List<HPExclusion> hpExclusionList = new ArrayList<>(Arrays.asList(hpExc1, hpExc2, hpExc3));

		/**
		 * create mock object of visibilities for test
		 */
		Visibility vis1 = this.stubRes.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");
		Visibility vis2 = this.stubRes.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis3 = this.stubRes.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		Visibility vis5 = this.stubRes.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 06:00:00",
				"10/10/2017 06:40:00");
		Visibility vis6 = this.stubRes.createVisibility(5, "SAT_2", "KOR", null, "10/10/2017 08:00:00",
				"10/10/2017 08:20:00");
		Visibility vis7 = this.stubRes.createVisibility(6, "SAT_2", "MAT", null, "10/10/2017 16:10:00",
				"10/10/2017 16:57:00");
		Visibility vis8 = this.stubRes.createVisibility(7, "SAT_2", "KIR", "Partner_1", "10/10/2017 17:50:00",
				"10/10/2017 18:21:00");
		Visibility vis9 = this.stubRes.createVisibility(8, "SAT_1", "PDR", "Partner_2", "10/10/2017 17:50:00",
				"10/10/2017 18:05:00");
		Visibility vis10 = this.stubRes.createVisibility(9, "SAT_1", "PDR", "Partner_2", "10/10/2017 20:00:00",
				"10/10/2017 22:50:00");

		/**
		 * add them to the list of visibilities
		 */
		List<Visibility> allVisibilitiesSat1 = new ArrayList<>();
		List<Visibility> allVisibilitiesSat2 = new ArrayList<>();
		allVisibilitiesSat1.add(vis1);
		allVisibilitiesSat1.add(vis2);
		allVisibilitiesSat1.add(vis3);
		allVisibilitiesSat1.add(vis9);
		allVisibilitiesSat1.add(vis10);

		allVisibilitiesSat2.add(vis5);
		allVisibilitiesSat2.add(vis6);
		allVisibilitiesSat2.add(vis7);
		allVisibilitiesSat2.add(vis8);

		List<Visibility> allVisibilities = new ArrayList<>();
		allVisibilities.addAll(allVisibilitiesSat1);
		allVisibilities.addAll(allVisibilitiesSat2);

		/**
		 * create satellite states associated to satellite
		 */
		SatelliteState satStat1 = this.stubRes.createSatelliteState("SAT_1", "10/10/2017 08:00:00",
				"10/10/2017 08:09:00");
		SatelliteState satStat2 = this.stubRes.createSatelliteState("SAT_1", "10/10/2017 15:15:00",
				"10/10/2017 15:30:00");
		SatelliteState satStat3 = this.stubRes.createSatelliteState("SAT_2", "10/10/2017 18:00:00",
				"10/10/2017 22:00:00");
		SatelliteState satStat4 = this.stubRes.createSatelliteState("SAT_1", "10/10/2017 15:10:00",
				"10/10/2017 15:13:00");
		List<SatelliteState> stateAssociatedToSat = new ArrayList<>();
		stateAssociatedToSat.add(satStat1);
		stateAssociatedToSat.add(satStat2);
		stateAssociatedToSat.add(satStat3);
		stateAssociatedToSat.add(satStat4);

		/*
		 * create a new satellite
		 */
		Satellite sat1 = new Satellite("SAT_1", "satellite_1", allPDHT.get(0), allPawsSat1, allVisibilitiesSat1,
				"right");
		Satellite sat2 = new Satellite("SAT_2", "satellite_2", allPDHT.get(1), allPawsSat2, allVisibilitiesSat2,
				"right");
		sat1.setInitialLookSide("right");
		sat2.setInitialLookSide("right");
		List<Satellite> allSats = new ArrayList<>();
		allSats.add(sat1);
		allSats.add(sat2);

		/*
		 * create all the CMGA related to sat
		 */
		List<CMGA> allCMGA = new ArrayList<>();

		/**
		 * initialize all the powers for the cmga 1
		 */
		double wAccForTestCmg1 = 25; // expressed in watt
		double tAccForTestCmg1 = 180; // expressed in seconds
		double wPlatForTestCmg1 = 25; // expressed in watt
		double wRestForTestCmg1 = 15; // expressed in watt
		/**
		 * initialize all the powers for the cmga 2
		 */
		double wAccForTestCmg2 = 25; // expressed in watt
		double tAccForTestCmg2 = 180; // expressed in seconds
		double wPlatForTestCmg2 = 25; // expressed in watt
		double wRestForTestCmg2 = 15; // expressed in watt
		/**
		 * initialize all the powers or the cmga 3
		 */
		double wAccForTestCmg3 = 5; // expressed in watt
		double tAccForTestCmg3 = 50; // expressed in seconds
		double wPlatForTestCmg3 = 5; // expressed in watt
		double wRestForTestCmg3 = 3; // expressed in watt

		CMGA cmga1 = new CMGA("cmga1", wAccForTestCmg1, tAccForTestCmg1, wPlatForTestCmg1, wRestForTestCmg1, true,
				"SAT_1");
		CMGA cmga2 = new CMGA("cmga2", wAccForTestCmg2, tAccForTestCmg2, wPlatForTestCmg2, wRestForTestCmg2, true,
				"SAT_1");
		CMGA cmga3 = new CMGA("cmga3", wAccForTestCmg3, tAccForTestCmg3, wPlatForTestCmg3, wRestForTestCmg3, false,
				"SAT_1");
		CMGA cmga4 = new CMGA("cmga1", wAccForTestCmg1, tAccForTestCmg1, wPlatForTestCmg1, wRestForTestCmg1, true,
				"SAT_2");
		CMGA cmga5 = new CMGA("cmga2", wAccForTestCmg2, tAccForTestCmg2, wPlatForTestCmg2, wRestForTestCmg2, true,
				"SAT_2");
		CMGA cmga6 = new CMGA("cmga3", wAccForTestCmg3, tAccForTestCmg3, wPlatForTestCmg3, wRestForTestCmg3, false,
				"SAT_2");
		allCMGA.add(cmga1);
		allCMGA.add(cmga2);
		allCMGA.add(cmga3);
		allCMGA.add(cmga4);
		allCMGA.add(cmga5);
		allCMGA.add(cmga6);

		/**
		 * create new eclipses
		 */
		List<Eclipse> allEclipses = new ArrayList<>();
		Eclipse e1 = this.stubRes.createEclipse("10/10/2017 08:00:00", "10/10/2017 08:06:00", "SAT_1");
		Eclipse e2 = this.stubRes.createEclipse("28/10/2017 18:00:00", "28/10/2017 20:00:00", "SAT_1");
		Eclipse e3 = this.stubRes.createEclipse("10/10/2017 10:00:00", "10/10/2017 14:00:00", "SAT_1");
		Eclipse e4 = this.stubRes.createEclipse("10/10/2017 10:00:00", "10/10/2017 14:00:00", "SAT_2");
		Eclipse e5 = this.stubRes.createEclipse("02/10/2017 08:00:00", "02/10/2017 15:00:00", "SAT_2");
		allEclipses.add(e1);
		allEclipses.add(e2);
		allEclipses.add(e3);
		allEclipses.add(e4);
		allEclipses.add(e5);

		/*
		 * create new partners
		 */
		this.allPartners = new ArrayList<>();
		Partner p1 = new Partner("Partner_1", null, maxBicForTest, 20);
		Partner p2 = new Partner("Partner_2", null, maxBicForTest, 30);
		Partner p3 = new Partner("Partner_3", null, maxBicForTest, 40);
		Partner p4 = new Partner("Partner_4", null, maxBicForTest, 50);
		this.allPartners.add(p1);
		this.allPartners.add(p2);
		this.allPartners.add(p3);
		this.allPartners.add(p4);

		/**
		 * create a new mission horizon
		 */
		MissionHorizon currentMH = this.stubRes.createMH("10/10/2017 06:21:00", "10/10/2017 18:21:00");

		/**
		 * set up all the parameters with the mock objects just created
		 */
		droolsInstance.setParameters(droolsParams, allSats, allPDHT, allVisibilities, allPaws, stateAssociatedToSat,
				allCMGA, allEclipses, this.allPartners, currentMH, maxHpBicFixedOrbit, hpExclusionList, prTypeMaxNumber,
				extraCostLeft);

		/**
		 * etUp the drools file
		 */
		droolsParams.setDrlRulesFile("config/droolsRules.drl");
		return droolsInstance;
	}

	/**
	 * Deep clone.
	 *
	 * @param object the object
	 * @return the object
	 */
	public static Object deepClone(Object object) {
		Object returnedObj = null;
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(bais);
			returnedObj = ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnedObj;
	}

	/**
	 * Gets the all elements involved.
	 *
	 * @param localStart the local start
	 * @param localEnd   the local end
	 * @param allAcq     the all acq
	 * @return the all elements involved
	 */
	public List<String> getAllElementsInvolved(long localStart, long localEnd,
			TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		List<String> allAcqInvolved = new ArrayList<>();
		SortedMap<Long, EnergyAssociatedToTask> subMap = allAcq.subMap(localStart, localEnd);
		for (Map.Entry<Long, EnergyAssociatedToTask> subElements : subMap.entrySet()) {
			allAcqInvolved.add(subElements.getValue().getTask().getIdTask());
		}
		return allAcqInvolved;
	}

	/**
	 * Gets the all elements involved with man in interval.
	 *
	 * @param allManInvolved the all man involved
	 * @param checkToPerform the check to perform
	 * @return the all elements involved with man in interval
	 */
	public List<String> getAllElementsInvolvedWithManInInterval(List<Maneuver> allManInvolved,
			Actuator checkToPerform) {
		List<String> allAcqInvolved = new ArrayList<>();
		for (int i = 0; i < allManInvolved.size(); i++) {

			Maneuver currentMan = allManInvolved.get(i);
			if ((currentMan.getActuator().compareTo(checkToPerform) == 0)
					|| (checkToPerform.compareTo(Actuator.total) == 0)) {
				addInvolvedAcq(currentMan, allAcqInvolved);
			}
		}
		return allAcqInvolved;
	}

	/**
	 * Adds the involved acq.
	 *
	 * @param currentMan     the current man
	 * @param allAcqInvolved the all acq involved
	 */
	private void addInvolvedAcq(Maneuver currentMan, List<String> allAcqInvolved) {

		String extractedAcqId = null;

		if (currentMan.isRightToLeftFlag()) {
			if (currentMan.getAcq2Id() != "x") {
				extractedAcqId = currentMan.getAcq2Id();
				if (!allAcqInvolved.contains(extractedAcqId)) {
					allAcqInvolved.add(extractedAcqId);
				}
			}
		} else {
			if (currentMan.getAcq1Id() != "x") {
				extractedAcqId = currentMan.getAcq1Id();
				if (!allAcqInvolved.contains(extractedAcqId)) {
					allAcqInvolved.add(extractedAcqId);
				}
			}
		}
	}

	/**
	 * From dto to acq.
	 *
	 * @param dto the dto
	 * @return the acquisition
	 */
	public Acquisition fromDtoToAcq(DTO dto) {
		// create a new acquisition
		Acquisition acq = new Acquisition(dto.getDtoId(), dto.getStartTime(), dto.getEndTime(), dto.getLookSide(),
				dto.getSatelliteId(), dto.getSensorMode());

		// set the key
		acq.setKey(dto.getKey());

		// set the polrization
		acq.setPolarization(dto.getPol());

		// set the prType
		acq.setPrType(dto.getPrType());

		// set the neo
		acq.setNeo(dto.isNeoAvailable());

		// set the image bic
		acq.setImageBIC(dto.getImageBIC());

		// set the priority
		acq.setPriority(dto.getPriority());

		// set the preferred vis
		acq.setPreferredVis(dto.getPreferredVis());

		// set the userInfo
		acq.setUserInfo(dto.getUserInfo());

		// set the passthrough flag
		acq.setPassThroughFlag(dto.isPtAvailable());

		// set the referred equivalent dto id
		acq.setReferredEquivalentDto(dto.getReferredEquivalentDto());

		// set the revolution number
		acq.setRevolutionNumber(dto.getRevolutionNumber());

		// set the prMode
		acq.setPrMode(dto.getPrMode());
		// set the stereopair
		acq.setStereopair(dto.isStereopair());
		// set the linked dto id
		acq.setLinkedDtoId(dto.getLinkedDtoId());

		// set the interleaved channel
		acq.setInterleavedChannel(dto.getInterleavedChannel());
		acq.setSizeH(dto.getSizeH());
		acq.setSizeV(dto.getSizeV());
		return acq;
	}

	/**
	 * Contains valid tasks.
	 *
	 * @param taskMap the task map
	 * @return true, if successful
	 */
	public boolean containsValidTasks(Map<String, Task> taskMap) {
		boolean containsValidElements = false;
		int validElements = taskMap.size();
		for (Map.Entry<String, Task> allTasks : taskMap.entrySet()) {
			Task currentTask = allTasks.getValue();
			if ((currentTask instanceof StoreAUX) || (currentTask instanceof CMGAxis)
					|| (currentTask instanceof Download)) {
				validElements--;
			}
		}
		if (validElements > 0) {
			containsValidElements = true;
		}
		return containsValidElements;
	}

	/**
	 * Adds the element.
	 *
	 * @param facts        the facts
	 * @param task         the task
	 * @param droolsParams the drools params
	 */
	public void addElement(List<Task> facts, Task task, DroolsParameters droolsParams) {
		if ((task.getStartTime().getTime() >= droolsParams.getCurrentMH().getStart().getTime())
				&& (task.getStartTime().getTime() <= droolsParams.getCurrentMH().getStop().getTime())) {
			facts.add(task);
		}
	}

	/**
	 * From treemap to list.
	 *
	 * @param allTasks the all tasks
	 * @return the list
	 */
	public static List<Task> fromTreemapToList(Map<String, Task> allTasks) {
		List<Task> alltasksAsList = new ArrayList<>();
		for (Map.Entry<String, Task> taskIterator : allTasks.entrySet()) {
			alltasksAsList.add(taskIterator.getValue());
		}
		return alltasksAsList;
	}

	/**
	 * Avoid clone vis.
	 *
	 * @param allVisibilities the all visibilities
	 * @return the list
	 */
	public List<Visibility> avoidCloneVis(List<Visibility> allVisibilities) {
		// ceate an empty list of visibilities
		List<Visibility> allVisibilitiesCopied = new ArrayList<>();

		// create an empty list of visibility key
		List<String> allVisKey = new ArrayList<>();

		// iterate over the visibilities
		for (int i = 0; i < allVisibilities.size(); i++) {
			Visibility vis = allVisibilities.get(i);
			String dwlKey = DownloadManagement.concatVisId(vis.getSatelliteId(), vis);
			if (!allVisKey.contains(dwlKey)) {
				allVisKey.add(dwlKey);
				allVisibilitiesCopied.add(allVisibilities.get(i));
			}
		}
		return allVisibilitiesCopied;
	}

	/**
	 * Gets the partner id from user info.
	 *
	 * @param master the master
	 * @return the partner id from user info
	 */
	public List<String> getPartnerIdFromUserInfo(DTO master) {
		List<String> partnerIdList = new ArrayList<>();
		for (int i = 0; i < master.getUserInfo().size(); i++) {
			String partnerId = master.getUserInfo().get(i).getOwnerId();
			if (!partnerIdList.contains(partnerId)) {
				partnerIdList.add(partnerId);
			}
		}
		return partnerIdList;
	}

	/**
	 * Process retain downloads.
	 *
	 * @param downloadPriorityQueueForSat the download priority queue for sat
	 * @return the list
	 */
	public List<ReportDownloads> processRetainDownloads(TreeMap<String, PriorityQueue> downloadPriorityQueueForSat) {

		// crate an empty list of ReportDownloads
		List<ReportDownloads> reports = new ArrayList<>();

		// iterate over the downloadPriorities
		for (Map.Entry<String, PriorityQueue> priority : downloadPriorityQueueForSat.entrySet()) {

			// create a new ReportDownloads
			ReportDownloads newReport = new ReportDownloads();

			// iterate over the sectors needed for prtners
			for (Map.Entry<String, SectorAndVisForPartner> sectors : priority.getValue().getSectorsNeededForPartners()
					.entrySet()) {

				for (int i = 0; i < sectors.getValue().getSectorsForPartner().size(); i++) {

					// get the sectors to dwl
					SizeOfSectorDwl sizeOfSec = sectors.getValue().getSectorsForPartner().get(i);

					// if there are residual sectors to donloads
					if (sizeOfSec.getResidualSize() > 0) {

						// set the referred acq
						newReport.setForAcq(priority.getValue().getRelatedAcq().getIdTask());
						newReport.getSectorsForPartner()
								.add(sectors.getKey() + "  " + sizeOfSec.getResidualSize() + "  " + sizeOfSec.getPol());
					}
				}
			}
			// if there is a linked acq
			if (newReport.getForAcq() != null) {
				// add the new report to the list
				reports.add(newReport);
			}
		}
		return reports;
	}

	/**
	 * Removes the fact if exist.
	 *
	 * @param factHandle the fact handle
	 * @param kie        the kie
	 */
	public static void removeFactIfExist(FactHandle factHandle, KieSession kie) {
		// if the fact handle is valid so exists an object related to it in
		// Drools
		if (factHandle != null) {
			// remove it from Drools
			kie.delete(factHandle);
		}
	}

}
