/**
*
* MODULE FILE NAME: Maneuver.java
*
* MODULE TYPE:      <Class definition>
*
* FUNCTION:         <Functional description of the DDC>
*
* PURPOSE:          <List of SR>
*p
* CREATION DATE:    <17-NOV-2016>
*
* AUTHORS:          Tommaso Grenga, Francesca Pedrola
*
* DESIGN ISSUE:     0.1
*
* INTERFACES:       <prototype and list of input/output parameters>
*
* SUBORDINATES:     <list of functions called by this DDC>
*
* MODIFICATION HISTORY:
*
*             Date          |  Name      |   New ver.     | Description
* --------------------------+------------+----------------+-------------------------------
* <DD-MMM-YYYY>             | <name>     |<Ver>.<Rel>     | <reasons of changes>
* --------------------------+------------+----------------+-------------------------------
*
* PROCESSING
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.io.Serializable;
import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfManeuver;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;

/**
 * This class models the tasks associated with a maneuver.
 */
@SuppressWarnings("serial")
public class Maneuver extends Task implements Serializable {
	/** The acq 1 id. */
	private String acq1Id;

	/** The acq 2 id. */
	private String acq2Id;

	/** The type. */
	private ManeuverType type;

	/** The actuator. */
	private Actuator actuator;

	/** The right to left flag. */
	private boolean rightToLeftFlag;

	private boolean removePitch = false;

	private boolean forHpSegm;

	/** The reason of man. */
	private ReasonOfManeuver reasonOfMan;

	/**
	 * parameterized Constructor.
	 *
	 * @param acq1Id      the acq 1 id
	 * @param acq2Id      the acq 2 id
	 * @param start       the start
	 * @param end         the end
	 * @param satelliteId the satellite id
	 */

	public Maneuver(String acq1Id, String acq2Id, Date start, Date end, String satelliteId) {
		super();
		// set the id task with the concatenation of the acq1Id and acq2Id
		super.setIdTask(acq1Id + "_" + acq2Id);

		// set the task type
		super.setTaskType(TaskType.MANEUVER);

		// set the first acq impacted for this man
		this.acq1Id = acq1Id;

		// set the second acq impacted for this man
		this.acq2Id = acq2Id;

		// set the start time
		super.setStartTime(start);

		this.removePitch = false;

		// set the stop time
		super.setEndTime(end);

		// initialize the actuator
		this.actuator = Actuator.ReactionWheels;
		this.rightToLeftFlag = false;
		this.forHpSegm = false;
		this.type = ManeuverType.RollSlew;
		this.reasonOfMan = ReasonOfManeuver.acqAcq;
		super.setSatelliteId(satelliteId);
	}

	/**
	 * Instantiates a new maneuver.
	 */
	public Maneuver() {
		super();
		// initialize the actuator
		this.actuator = Actuator.ReactionWheels;

		// set the task type
		super.setTaskType(TaskType.MANEUVER);

		// initialize the reason for the maneuver
		this.reasonOfMan = ReasonOfManeuver.acqAcq;
		this.forHpSegm = false;
	}

	/**
	 * Gets the total id of the man.
	 *
	 * @return the total id given from the concat of the first member and the second member involved in a man
	 */
	public String getTotalId() {
		return super.getIdTask();
	}

	/**
	 * Gets the acq 1 id.
	 *
	 * @return the acq 1 id
	 */
	public String getAcq1Id() {
		return this.acq1Id;
	}

	/**
	 * Gets the acq 2 id.
	 *
	 * @return the acq 2 id
	 */
	public String getAcq2Id() {
		return this.acq2Id;
	}

	/**
	 * Gets the end time.
	 *
	 * @return the end time (when the maneuver ends)
	 */

	@Override
	public Date getEndTime() {
		return super.getEndTime();
	}

	/**
	 * Gets the start time.
	 *
	 * @return the start time (when the maneuver begins)
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/**
	 * Get the taskType of the man.
	 *
	 * @return the taskType of the man
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/**
	 * Sets the task type of the man.
	 *
	 * @param taskType the taskType of the maneuver
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public ManeuverType getType() {
		return this.type;
	}

	/**
	 * Checks if is right to left flag.
	 *
	 * @return true, if is right to left flag
	 */
	public boolean isRightToLeftFlag() {
		return this.rightToLeftFlag;
	}

	/**
	 * Sets the acq 1 id.
	 *
	 * @param acq1Id the acq1Id to set
	 */
	public void setAcq1Id(String acq1Id) {
		this.acq1Id = acq1Id;
	}

	/**
	 * Sets the acq 2 id.
	 *
	 * @param acq2Id the acq2Id to set
	 */
	public void setAcq2Id(String acq2Id) {
		this.acq2Id = acq2Id;
	}

	/**
	 * Sets the start time of the man.
	 *
	 * @param startTime the start time to set
	 */
	@Override
	public void setStartTime(Date startTime) {
		super.setStartTime(startTime);
	}

	/**
	 * Sets the end time of the man.
	 *
	 * @param endTime the end time to set
	 */
	@Override
	public void setEndTime(Date endTime) {
		super.setEndTime(endTime);
	}

	/**
	 * Sets the right to left flag.
	 *
	 * @param rightToLeftFlag the new right to left flag
	 */
	public void setRightToLeftFlag(boolean rightToLeftFlag) {
		this.rightToLeftFlag = rightToLeftFlag;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(ManeuverType type) {
		this.type = type;
	}
	
	/**
	 * Gets the taskMark.
	 *
	 * @return the taskmark of the man
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/**
	 * Sets the task mark of man.
	 *
	 * @param taskMark the taskMark to set
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/**
	 *  
	 * return the toString of the object.
	 *
	 * @return the toString of the maneuver
	 */
	@Override
	public String toString() {
		return "Maneuver [idTask = " + super.getIdTask() + " type=" + this.type + ", actuator = " + this.actuator
				+ ", rightToLeftFlag=" + this.rightToLeftFlag + ", getStartTime()=" + getStartTime() + ", getEndTime()="
				+ getEndTime() + "id1 :" + this.acq1Id + ", id2 :" + this.acq2Id + " ]";
	}

	/**
	 *  
	 * return the taskId of the object.
	 *
	 * @return the taskId of the maneuver
	 */
	@Override
	public String getIdTask() {
		return super.getIdTask();
	}

	/**
	 * Gets the actuator.
	 *
	 * @return the actuator
	 */
	public Actuator getActuator() {
		return this.actuator;
	}

	/**
	 * Sets the actuator.
	 *
	 * @param actuator the new actuator
	 */
	public void setActuator(Actuator actuator) {
		this.actuator = actuator;
	}

	/**
	 * Gets the referred equiv dto.
	 *
	 * @return the referred equiv dto
	 */
	@Override
	public String getReferredEquivalentDto() {
		return super.getReferredEquivalentDto();
	}

	/**
	 * Sets the referred equiv dto.
	 *
	 * @param referredEquivDto the new referred equiv dto
	 */
	@Override
	public void setReferredEquivalentDto(String referredEquivDto) {
		super.setReferredEquivalentDto(referredEquivDto);
	}

	/**
	 * Gets the reason of man.
	 *
	 * @return the reasonOfMan
	 */
	public ReasonOfManeuver getReasonOfMan() {
		return this.reasonOfMan;
	}

	/**
	 * Sets the reason of man.
	 *
	 * @param reasonOfMan the reasonOfMan to set
	 */
	public void setReasonOfMan(ReasonOfManeuver reasonOfMan) {
		this.reasonOfMan = reasonOfMan;
	}

	/**
	 * @return the forHpSegm
	 */
	public boolean isForHpSegm() {
		return this.forHpSegm;
	}

	/**
	 * @param forHpSegm the forHpSegm to set
	 */
	public void setForHpSegm(boolean forHpSegm) {
		this.forHpSegm = forHpSegm;
	}

	/**
	 *  
	 * return the boolean flag that indicate if the maneuver is for remove pitch or not.
	 *
	 * @return the removePitch
	 */
	public boolean isRemovePitch() {
		return this.removePitch;
	}

	/**
	 * Sets the removePitch.
	 *
	 * @param removePitch : true if the man is a pitch one,false otherwise
	 */
	public void setRemovePitch(boolean removePitch) {
		this.removePitch = removePitch;
	}

}
