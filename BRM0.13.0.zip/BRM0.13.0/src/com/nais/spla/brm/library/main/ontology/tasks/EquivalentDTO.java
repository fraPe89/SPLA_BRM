/**
 *
 * MODULE FILE NAME: EquivalentDTO.java
 *
 * MODULE TYPE: Class definition
 *
 * FUNCTION: <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE: 24 lug 2017
 *
 * AUTHORS: fpedrola
 *
 * DESIGN ISSUE: 1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 * Date | Name | New ver. | Description
 * -----------------+------------+-------------+-------------------------------
 * 24 lug 2017 | fpedrola | 1.0 | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.tasks;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;

/**
 * The Class EquivalentDTO.
 */
@SuppressWarnings("serial")
public class EquivalentDTO extends Task {

	/** The equivalent dto id. */
	private String equivalentDtoId;

	/** The start time. */
	private Date startTime;

	/** The end time. */
	private Date endTime;

	/** The man associated. */
	private List<Maneuver> manAssociated;

	/** The all dto in equivalent dto. */
	private List<DTO> allDtoInEquivalentDto;

	/** The di 2 s info. */
	private Di2sInfo di2sInfo;

	/** The equiv type. */
	private PRMode equivType;

	/** The extra cost pitch. */
	private double extraCostPitch = 0;

	/**
	 * Instantiates a new equivalent DTO.
	 */
	public EquivalentDTO() {
		super();
	}

	/**
	 * Sets the start and stop.
	 */
	public void setStartAndStop() {
		// create an empty list of tasks
		List<Task> alltasksRelatedToEquivDto = new ArrayList<>();

		// if there isx at least a maneuver associated to the equivalent dto
		if (this.manAssociated != null) {
			// iterate over the maneuver associated list
			for (int i = 0; i < this.manAssociated.size(); i++) {
				// add them to the list of tasks
				alltasksRelatedToEquivDto.add(this.manAssociated.get(i));
			}
		}

		// iterate over the dto inside the equivalent dto
		for (int i = 0; i < this.allDtoInEquivalentDto.size(); i++) {
			// create a new task
			Task task = new Task();

			// set the start time
			task.setStartTime(this.allDtoInEquivalentDto.get(i).getStartTime());

			// set the stop time
			task.setEndTime(this.allDtoInEquivalentDto.get(i).getEndTime());

			// add the new task to the list
			alltasksRelatedToEquivDto.add(task);
		}

		// invoke the method to sort the tasks for start time
		DownloadUtils.sortTasksByStartTime(alltasksRelatedToEquivDto);

		// set as start time of the equivalent dto the start time of the first
		// task
		this.setStartTime(alltasksRelatedToEquivDto.get(0).getStartTime());

		// set as stop time of the equivalent dto the stop time of the last task
		Date endTimeEquivDto = alltasksRelatedToEquivDto.get(alltasksRelatedToEquivDto.size() - 1).getEndTime();

		// if there are man associated
		if ((this.manAssociated != null) && !this.manAssociated.isEmpty()) {
			// if the last man ends after the last task
			if (this.manAssociated.get(this.manAssociated.size() - 1).getEndTime().getTime() > endTimeEquivDto
					.getTime()) {
				// set as end time of the euivalent dto the end time of the man
				endTimeEquivDto = this.manAssociated.get(this.manAssociated.size() - 1).getEndTime();
			}
		}
		this.setEndTime(endTimeEquivDto);
	}

	/**
	 * Instantiates a new equivalent DTO.
	 *
	 * @param equivalentDtoId the equivalent dto id
	 * @param startTime       the start time
	 * @param endTime         the end time
	 * @param extraCostPitch  the extra cost pitch
	 */
	public EquivalentDTO(String equivalentDtoId, Date startTime, Date endTime, double extraCostPitch) {
		super();
		this.equivalentDtoId = equivalentDtoId;
		this.allDtoInEquivalentDto = new ArrayList<>();
		this.startTime = startTime;
		this.manAssociated = null;
		this.endTime = endTime;
		this.extraCostPitch = extraCostPitch;
	}

	/**
	 * Instantiates a new equivalent DTO.
	 *
	 * @param equivalentDtoId the equivalent dto id
	 * @param startTime       the start time
	 * @param endTime         the end time
	 * @param equivType       the equiv type
	 */
	public EquivalentDTO(String equivalentDtoId, Date startTime, Date endTime, PRMode equivType) {
		super();
		this.equivalentDtoId = equivalentDtoId;
		this.startTime = startTime;
		this.manAssociated = null;
		this.allDtoInEquivalentDto = new ArrayList<>();
		this.endTime = endTime;
		this.equivType = equivType;
	}

	/**
	 * Gets the equivalent dto id.
	 *
	 * @return the equivalent dto id
	 */
	public String getEquivalentDtoId() {
		return this.equivalentDtoId;
	}

	/**
	 * Sets the equivalent dto id.
	 *
	 * @param equivalentDtoId the new equivalent dto id
	 */
	public void setEquivalentDtoId(String equivalentDtoId) {
		this.equivalentDtoId = equivalentDtoId;
	}

	/**
	 * Gets the start time.
	 *
	 * @return the start time
	 */
	@Override
	public Date getStartTime() {
		return this.startTime;
	}

	/**
	 * Sets the start time.
	 *
	 * @param startTime the new start time
	 */
	@Override
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * Gets the end time.
	 *
	 * @return the end time
	 */
	@Override
	public Date getEndTime() {
		return this.endTime;
	}

	/**
	 * Sets the end time.
	 *
	 * @param endTime the new end time
	 */
	@Override
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	/**
	 * Gets the man associated.
	 *
	 * @return the man associated
	 */
	public List<Maneuver> getManAssociated() {
		return this.manAssociated;
	}

	/**
	 * Sets the man associated.
	 *
	 * @param manAssociated the new man associated
	 */
	public void setManAssociated(List<Maneuver> manAssociated) {
		this.manAssociated = manAssociated;
	}

	/**
	 * Gets the all dto in equivalent dto.
	 *
	 * @return the all dto in equivalent dto
	 */
	public List<DTO> getAllDtoInEquivalentDto() {
		return this.allDtoInEquivalentDto;
	}

	/**
	 * Sets the all dto in equivalent dto.
	 *
	 * @param allDtoInEquivalentDto the new all dto in equivalent dto
	 */
	public void setAllDtoInEquivalentDto(List<DTO> allDtoInEquivalentDto) {
		this.allDtoInEquivalentDto = allDtoInEquivalentDto;
	}

	/**
	 * Gets the equiv type.
	 *
	 * @return the equiv type
	 */
	public PRMode getEquivType() {
		return this.equivType;
	}

	/**
	 * Sets the equiv type.
	 *
	 * @param equivType the new equiv type
	 */
	public void setEquivType(PRMode equivType) {
		this.equivType = equivType;
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() { /**
								 * toString del metodo
								 */
		return "EquivalentDTO [equivalentDtoId=" + this.equivalentDtoId + ", startTime=" + this.startTime + ", endTime="
				+ this.endTime + ", manAssociated=" + this.manAssociated + ", allDtoInEquivalentDto="
				+ this.allDtoInEquivalentDto + ", equivType=" + this.equivType + "]";
	}

	/**
	 * Gets the reason of reject.
	 *
	 * @return the reasonOfReject
	 */
	@Override
	public List<ReasonOfRejectElement> getReasonOfReject() {
		return super.getReasonOfReject();
	}

	/**
	 * Reject all dto in equivalent.
	 *
	 * @param reason the reason
	 */
	public void rejectAllDtoInEquivalent(ReasonOfReject reason) {
		// iterate over the dto into the equivalent dxto
		for (int i = 0; i < this.allDtoInEquivalentDto.size(); i++) {
			// mark the i-esim dto as rejected
			this.allDtoInEquivalentDto.get(i).setRejected(true);

			// add to the i-esim dto the reason of reject given in input
			this.allDtoInEquivalentDto.get(i).setReasonOfReject(reason);
		}
	}

	/**
	 * Gets the di 2 s info.
	 *
	 * @return the di2sInfo
	 */
	@Override
	public Di2sInfo getDi2sInfo() {
		return this.di2sInfo;
	}

	/**
	 * Sets the di 2 s info.
	 *
	 * @param di2sInfo the di2sInfo to set
	 */
	@Override
	public void setDi2sInfo(Di2sInfo di2sInfo) {
		this.di2sInfo = di2sInfo;
	}

	/**
	 * Gets the extra cost pitch.
	 *
	 * @return the extraCostPitch
	 */
	public double getExtraCostPitch() {
		return this.extraCostPitch;
	}

	/**
	 * Sets the extra cost pitch.
	 *
	 * @param extraCostPitch the extraCostPitch to set
	 */
	public void setExtraCostPitch(double extraCostPitch) {
		this.extraCostPitch = extraCostPitch;
	}

}
