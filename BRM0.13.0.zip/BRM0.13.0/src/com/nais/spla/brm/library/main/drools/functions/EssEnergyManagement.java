/**
*
* MODULE FILE NAME:	EssEnergyManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		08 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 08 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ElementsTillThreshold;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

// TODO: Auto-generated Javadoc
/**
 * The Class EssEnergyManagement.
 *
 * @author fpedrola
 */
public class EssEnergyManagement {

	/** The eclipse mng. */
	EclipseManagement eclipseMng = new EclipseManagement();

	/**
	 * Check acq function.
	 *
	 * @param droolsParams   the drools params
	 * @param acq            the acq
	 * @param allAcq         the all acq
	 * @param minDistanceMap the min distance map
	 * @return true, if successful
	 */
	public List<String> checkAcqOverlap(DroolsParameters droolsParams, Acquisition acq,
			TreeMap<Long, EnergyAssociatedToTask> allAcq,
			Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap) {

		// create an array list for eventually overlapped acq
		List<String> overlappedElements = new ArrayList<>();

		// initialize prev and next acq
		Acquisition prevAcq = null;
		Acquisition succAcq = null;

		// get the treemap with all the acquisitions
		Map<Long, EnergyAssociatedToTask> subMap = allAcq.subMap(acq.getStartTime().getTime(), true,
				acq.getEndTime().getTime(), true);

		// get the object related to previous acquisition
		Object precKey = allAcq.lowerKey(acq.getStartTime().getTime());

		// if there is a previous acq
		if (precKey != null) {
			// extract previous acq
			prevAcq = (Acquisition) allAcq.get(precKey).getTask();
			// logger.debug("PREVIOUS ACQ : " + prevAcq);
		}

		// get the object related to next acquisition
		Object succKey = allAcq.higherKey(acq.getStartTime().getTime());

		// if there is a next acq
		if (succKey != null) {
			// extract next acq
			succAcq = (Acquisition) allAcq.get(succKey).getTask();
			// logger.debug("NEXT ACQ : " + succAcq);
		}

		// initialize the insertable boolean flag to false
		boolean insertable = false;

		// if there aren't elements in submap
		if (subMap.isEmpty()) {
			// check if there are borderline cases
			overlappedElements = findBorderLineCaseOfOverlap(acq, prevAcq, succAcq, overlappedElements, allAcq,
					minDistanceMap);

			// if no
			if (overlappedElements.size() == 0) {
				// no elements in overlap
				// logger.debug("no elements in overlap ");

				// get prev acq if exist
				if (precKey != null) {
					// get the next element for prev acq
					long memId = prevAcq.getNextElementKey();

					// set the next element of prev with the current acq
					prevAcq.setNextElementKey(acq.getKey());

					// set the next element of current acq with the oldest prev
					// memId
					acq.setNextElementKey(memId);
				}
				// if not exists a previous
				else {
					// get next acq if exist
					if (succKey != null) {
						// et the next element of current acq with the next acq
						// key
						acq.setNextElementKey(succAcq.getKey());
					}
					// otherwise
					else {
						// set the next element to -1
						acq.setNextElementKey(-1);
					}
				}
				insertable = true;
			}
		}
		// founded elements in overlap
		else {
			// set the boolean variable to false
			insertable = false;
			// logger.debug("founded elements in overlap : add them to the
			// list");

			// iterate over overlapped elements
			for (Map.Entry<Long, EnergyAssociatedToTask> elementsInOverlap : subMap.entrySet()) {
				// logger.debug("element in overlap : " +
				// elementsInOverlap.getValue().getTask());

				// add to the list of string the id of the i-esim overlapped
				// element
				overlappedElements.add(elementsInOverlap.getValue().getTask().getIdTask());
			}
			// check if there are borderline cases
			overlappedElements = findBorderLineCaseOfOverlap(acq, prevAcq, succAcq, overlappedElements, allAcq,
					minDistanceMap);

			// set the reason of reject acqOverlapWithAcquisition
			acq.addReasonOfReject(7, ReasonOfReject.acqOverlapWithAcquisition,
					"Acquisition Overlap With Another Acquisition", -1, -1, overlappedElements);
		}
		// if is not insertable
		if (!insertable) {
			// set the reason of reject acqOverlapWithAcquisition
			acq.addReasonOfReject(7, ReasonOfReject.acqOverlapWithAcquisition,
					"Acquisition Overlap With Another Acquisition", 0, 0, overlappedElements);
		}
		return overlappedElements;
	}

	/**
	 * Find border line case of overlap.
	 *
	 * @param acq                the acq
	 * @param prevAcq            the prev acq
	 * @param succAcq            the succ acq
	 * @param overlappedElements the overlapped elements
	 * @param allAcq             the all acq
	 * @param minDistanceMap     the min distance map
	 * @return the list
	 */
	protected List<String> findBorderLineCaseOfOverlap(Acquisition acq, Acquisition prevAcq, Acquisition succAcq,
			List<String> overlappedElements, TreeMap<Long, EnergyAssociatedToTask> allAcq,
			Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap) {
		// initialize the min distance
		double minDistance = 0;

		// if there is a previous acquisition
		if (prevAcq != null) {
			// logger.debug("prev acq : " + prevAcq);

			// extract the min distance between prevAcq and acq
			minDistance = minDistanceMap.get(prevAcq.getSensorMode()).get(acq.getSensorMode());
			// logger.debug("min Distance between prev and current " +
			// minDistance);

			System.out.println("start time acq " + acq.getStartTime().getTime());
			System.out.println("prev stop time acq " + prevAcq.getEndTime().getTime());
			System.out.println("gap " + (acq.getStartTime().getTime() - prevAcq.getEndTime().getTime()));

			// compute the gap
			long gapMs = (acq.getStartTime().getTime() - prevAcq.getEndTime().getTime());
			double d = gapMs;

			double gap = d / 1000;
			// logger.debug("gap between acq " + gap);
			// if elements are in overlap or are too close to each others
			if (prevAcq.getEndTime().after(acq.getStartTime()) || (gap < minDistance)) {
				// logger.debug("overlap/too close with previous : cannot be
				// accepted");

				// add the previous acq to the list of overlapped elements
				insertRejectedElements(overlappedElements, prevAcq.getIdTask());
			}
		}

		// if there is a succAcq acquisition
		if (succAcq != null) {
			// logger.debug("next acq : " + succAcq);

			// extract the min distance between acq and succAcq
			minDistance = minDistanceMap.get(acq.getSensorMode()).get(succAcq.getSensorMode());
			// logger.debug("min Distance between current and next " +
			// minDistance);

			// compute the gap with next
			long gapMs = (succAcq.getStartTime().getTime() - acq.getEndTime().getTime());
			double d = gapMs;

			double gap = d / 1000;
			// if elements are in overlap or are too close to each others
			if (acq.getEndTime().after(succAcq.getStartTime()) || (gap < minDistance)) {
				// logger.debug("overlap/too close with next : cannot be
				// accepted");

				// add the previous acq to the list of overlapped elements
				insertRejectedElements(overlappedElements, succAcq.getIdTask());
			}
		}

		return overlappedElements;
	}

	/**
	 * Insert rejected elements.
	 *
	 * @param overlappedElements the overlapped elements
	 * @param idTask             the id task
	 */
	public void insertRejectedElements(List<String> overlappedElements, String idTask) {
		// if the list of overlapped elements doesn't contains the id given as
		// input
		if (!overlappedElements.contains(idTask)) {
			// add to the list
			overlappedElements.add(idTask);
		}
	}

	/**
	 * Check measurement function.
	 *
	 * @param orbit             the orbit
	 * @param acq               the acq
	 * @param resourceFunctions the resource functions
	 * @param threshold         the threshold
	 * @param droolsParams      the drools params
	 * @param satProp           the sat prop
	 * @return true, if successful
	 */
	public boolean checkMeasurementFunction(double orbit, Acquisition acq, ResourceFunctions resourceFunctions,
			double threshold, DroolsParameters droolsParams, SatelliteProperties satProp) {
		// initialize as orbit in eclipse to false
		boolean overheadEclipsePeriod = false;

		boolean lastOrbitSmoothing = false;

		// compute the duration of a single sliding window
		long slidingWindow = (long) (droolsParams.getMinutesForOrbit() * 60000 * orbit);

		// get the percentage of eclipse
		double percentEclipseAvailable = satProp.getMaxPercEclipseAvailable();

		// get the threshold (decremented in case of eclipse)
		double correctThreshold = getThreshold(acq, threshold, percentEclipseAvailable, lastOrbitSmoothing,
				droolsParams);

		// initialize the reason of reject in case of failure
		ReasonOfReject potentialReasonOfReject = ReasonOfReject.reachedOrbitThreshold;

		// if the threshold is decremented for eclipse
		if (correctThreshold < threshold) {
			// set the reason of reject with the eclipse status
			potentialReasonOfReject = ReasonOfReject.reachedOrbitThresholdInEclipse;

		}

		// initialize the reachedThreshold to false
		boolean reachedThreshold = false;

		// used for take in account the number of sliding window that we are
		// checking
		int cont = 1;
		ElementsTillThreshold returnedThresholdTot = null;

		// get the treemap with all the acquisitions
		TreeMap<Long, EnergyAssociatedToTask> hashMapEss = resourceFunctions
				.getEssFunctionAssociatedToSat(acq.getSatelliteId());

		// get the start of interval as the start time of acq
		long intervalStart = acq.getStartTime().getTime();

		// compute the end time of interval
		long intervalEnd = acq.getStartTime().getTime() + slidingWindow;
		// logger.debug("ESS_THRESHOLD RULE_ check on sliding window : ");

		// logger.debug("ESS_THRESHOLD RULE_ start : " + new
		// Date(intervalStart));
		// logger.debug("ESS_THRESHOLD RULE_ end : " + new Date(intervalEnd));

		// get the threshold tot
		returnedThresholdTot = resourceFunctions.calculateLocalMax(intervalStart, intervalEnd, hashMapEss);
		// logger.debug("ESS_THRESHOLD RULE_ ess in interval : " +
		// returnedThresholdTot.getReachedValue());
		// logger.debug("ESS_THRESHOLD RULE_ elements involved : " +
		// returnedThresholdTot.getElementsChecked());

		boolean isInLastOrbit = isInLastOrbit(acq, droolsParams, satProp, threshold);

		// if exceeds the threshold
		if ((correctThreshold < returnedThresholdTot.getReachedValue()) || overheadEclipsePeriod) {
			// add the reason of reject
			addReasonOfReject(acq, orbit, potentialReasonOfReject, isInLastOrbit, cont,
					returnedThresholdTot.getElementsChecked());

			// reached the threshold
			reachedThreshold = true;
			// logger.debug("ESS_THRESHOLD RULE_ reached orbit threshold on " +
			// orbit + " orbit.\n");
		}

		// get the submap
		Map<Long, EnergyAssociatedToTask> subMap = hashMapEss.subMap(intervalStart, true, intervalEnd, true);

		// iterate over elements
		for (Map.Entry<Long, EnergyAssociatedToTask> elementOfMap : subMap.entrySet()) {
			// get the i-esim acq
			Acquisition acqExtracted = (Acquisition) elementOfMap.getValue().getTask();

			// update the start of check
			long localStart = acqExtracted.getEndTime().getTime() - slidingWindow;
			// update the end of check
			long localEnd = acqExtracted.getEndTime().getTime(); // compute the
																	// total
																	// threshold
			returnedThresholdTot = resourceFunctions.calculateLocalMax(localStart, localEnd, hashMapEss);
			// logger.debug("ESS_THRESHOLD RULE_ ess in interval : " +
			// returnedThresholdTot.getReachedValue());
			// logger.debug("ESS_THRESHOLD RULE_ elements involved : " +
			// returnedThresholdTot.getElementsChecked());

			if ((correctThreshold < returnedThresholdTot.getReachedValue()) || overheadEclipsePeriod) {
				// add the reason of reject
				addReasonOfReject(acq, orbit, potentialReasonOfReject, isInLastOrbit, cont,
						returnedThresholdTot.getElementsChecked());

				// reached the threshold
				reachedThreshold = true;
				// logger.debug("ESS_THRESHOLD RULE_ reached orbit threshold on
				// " + orbit + " orbit.\n");
			}
			// inrement the cont
			cont++;
		}
		return reachedThreshold;
	}

	/**
	 * Adds the reason of reject.
	 *
	 * @param acq                     the acq
	 * @param orbit                   the orbit
	 * @param potentialReasonOfReject the potential reason of reject
	 * @param isInLastOrbit           the is in last orbit
	 * @param slidingWindow           the sliding window
	 * @param elementsChecked         the elements checked
	 */
	public void addReasonOfReject(Acquisition acq, double orbit, ReasonOfReject potentialReasonOfReject,
			boolean isInLastOrbit, int slidingWindow, List<String> elementsChecked) {
		// if the acq is a unranked
		if (acq.getPrType().equals(PRType.UNRANKED_ROUTINE)) {

			if (isInLastOrbit) {
				// set the correct reason of reject
				potentialReasonOfReject = ReasonOfReject.smoothingEssUnranked;

				// add the reason to the acq
				acq.addReasonOfReject(19, potentialReasonOfReject,
						"Reached Equivalent Stripmap Second Threshold With Smoothing ", orbit, slidingWindow,
						elementsChecked);

			} else {
				// set the correct reason of reject
				potentialReasonOfReject = ReasonOfReject.reachedOrbitThreshold;

				// add the reason to the acq
				acq.addReasonOfReject(41, potentialReasonOfReject, "Equivalent Stripmap Second Orbit Threshold Reached",
						orbit, slidingWindow, elementsChecked);

			}
		}
		// if the acq was in eclipse
		else if (potentialReasonOfReject.equals(ReasonOfReject.reachedOrbitThresholdInEclipse)) {
			// add the reason to the acq
			acq.addReasonOfReject(40, potentialReasonOfReject,
					"Equivalent Stripmap Second Orbit Threshold Reached In Eclipse Period", orbit, slidingWindow,
					elementsChecked);

		}
		// simple case threshold
		else {
			// add the reason to the acq
			acq.addReasonOfReject(41, potentialReasonOfReject, "Equivalent Stripmap Second Orbit Threshold Reached",
					orbit, slidingWindow, elementsChecked);
		}
	}

	/**
	 * Gets the threshold.
	 *
	 * @param acq                     the acq
	 * @param threshold               the threshold
	 * @param percentEclipseAvailable the percent eclipse available
	 * @param lastOrbitSmoothing      the last orbit smoothing
	 * @param droolsParams            the drools params
	 * @return the threshold
	 */
	public double getThreshold(Acquisition acq, double threshold, double percentEclipseAvailable,
			boolean lastOrbitSmoothing, DroolsParameters droolsParams) {

		// get the satellite properties related to the current acq
		SatelliteProperties satProp = droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties();

		// aq in eclipse
		if (acq.isInEclipse()) {
			// decrement max threshold
			threshold = (threshold / 100) * (100 - percentEclipseAvailable);
			DroolsParameters.getLogger().debug("ESS_THRESHOLD RULE_ acq is in eclipse, threshold decremented ");
			DroolsParameters.getLogger()
					.debug("ESS_THRESHOLD RULE_ threshold reduced of :  " + percentEclipseAvailable + " %");
			DroolsParameters.getLogger().debug("ESS_THRESHOLD RULE_ updated threshold :  " + threshold);
		}
		// acq is unranked
		if (acq.getPrType().equals(PRType.UNRANKED_ROUTINE)) {
			// compute gap with end time of mission horizon
			long diff = (droolsParams.getCurrentMH().getStop().getTime() - acq.getEndTime().getTime()) / 1000;

			// compute the time till the threshold must be decremented
			long totalSecOfAnOrbit = (long) (satProp.getPeriodBeforeEndOfMhForSmoothingUnranked() * 60);
			// logger.debug("time between end of mh and unranked routine : " +
			// diff + " seconds");
			// logger.debug("minutes per orbit expressed in seconds : " +
			// totalSecOfAnOrbit);

			// if the acq isx in the last period of mh
			if (diff < totalSecOfAnOrbit) {
				// get th percentage of threshold
				double percentToReduce = 100 - ((diff * 100) / totalSecOfAnOrbit);
				// logger.debug("threshold before decrement : " + threshold);
				// logger.debug("the ess threshold will be reduced of : " +
				// percentToReduce + "%");

				// update threshold
				threshold = (threshold / 100) * (100 - percentToReduce);

				lastOrbitSmoothing = true;
				// logger.debug("threshold after decrement : " + threshold);
			}
		}
		return threshold;
	}

	/**
	 * Checks if is in last orbit.
	 *
	 * @param acq          the acq
	 * @param droolsParams the drools params
	 * @param satProp      the sat prop
	 * @param threshold    the threshold
	 * @return true, if is in last orbit
	 */
	private boolean isInLastOrbit(Acquisition acq, DroolsParameters droolsParams, SatelliteProperties satProp,
			double threshold) {
		boolean lastoOrbitSmoothing = false;
		// compute gap with end time of mission horizon
		long diff = (droolsParams.getCurrentMH().getStop().getTime() - acq.getEndTime().getTime()) / 1000;

		// compute the time till the threshold must be decremented
		long totalSecOfAnOrbit = (long) (satProp.getPeriodBeforeEndOfMhForSmoothingUnranked() * 60);
		// logger.debug("time between end of mh and unranked routine : " +
		// diff + " seconds");
		// logger.debug("minutes per orbit expressed in seconds : " +
		// totalSecOfAnOrbit);

		// if the acq isx in the last period of mh
		if (diff < totalSecOfAnOrbit) {
			// get th percentage of threshold
			double percentToReduce = 100 - ((diff * 100) / totalSecOfAnOrbit);
			// logger.debug("threshold before decrement : " + threshold);
			// logger.debug("the ess threshold will be reduced of : " +
			// percentToReduce + "%");

			// update threshold
			threshold = (threshold / 100) * (100 - percentToReduce);

			lastoOrbitSmoothing = true;
			// logger.debug("threshold after decrement : " + threshold);
		}
		return lastoOrbitSmoothing;
	}

	/**
	 * Compute ess.
	 *
	 * @param acq              the acq
	 * @param droolsParams     the drools params
	 * @param powersSensorMode the powers sensor mode
	 * @return the double
	 */
	/*
	 * This method is invoked by the previous one and is responsible for the
	 * calculation of the ess for an acquisition. It loops over the list containing
	 * all the possible types of acquisition by comparing them with the value of the
	 * current one and, when a match occurs, it performs the calculation and returns
	 * it back as output
	 *
	 * @param Acquisition acq the acquisition that we are processing
	 *
	 * @param List<PowerSarMode> allPowers a list of objects that allow to correlate
	 * type of acquisition with their reference values
	 *
	 * @param double referenceSarMode is the reference value in order to perform the
	 * calculation of ess of an acquisition, corresponding to the coefficient of a
	 * StripMap
	 *
	 * @return the value of the ess associated with the acquisition given in input
	 */
	public double computeEss(Acquisition acq, DroolsParameters droolsParams,
			Map<TypeOfAcquisition, Double> powersSensorMode) {
		// set the referred sensor mode with the stripmap one
		double referenceSarMode = powersSensorMode.get(TypeOfAcquisition.STRIPMAP);
		// logger.debug("COMPUTE ESS : the reference sensor mode is STRIPMAP
		// with power : " + referenceSarMode);

		// declare the ess associated to the acq under analysis
		double ess = 0;

		// declare the power associated to the sensor mode linked to the
		// acquisition
		double powerAssociated = 0;

		// compute time duration of the acquisition
		Long duration = (acq.getEndTime().getTime() - acq.getStartTime().getTime()) / 1000;
		// logger.debug("COMPUTE ESS : the duration of the acquisition is : " +
		// duration);

		// extract the sensor mode
		TypeOfAcquisition sensor = acq.getSensorMode();

		// if the acquisition is of type SPOTLIGHT_2_MSOS or SPOTLIGHT_2_MSJN
		if (((sensor.equals(TypeOfAcquisition.SPOTLIGHT_2_MSOS) || (sensor.equals(TypeOfAcquisition.SPOTLIGHT_2_MSJN)))
				&& acq.getPrMode().equals(PRMode.DI2S))) {
			// logger.debug("COMPUTE ESS : special case : compute : " + sensor);
			// logger.debug("COMPUTE ESS : match the duration versus the
			// referred configurable time for SPOTLIGHT_2_MSOS and
			// SPOTLIGHT_2_MSJN");

			// if the duration of the acquisition is lower or equal the referred
			// threshold
			// System.out.println("refd2_DI2S : " +
			// droolsParams.getRefd2_DI2S());
			if (duration <= droolsParams.getRefd2_DI2S()) {
				// set the power with the lower bound value
				powerAssociated = droolsParams.getPowerAssociatedWithSensorModeUL(sensor, true);
				// logger.debug("COMPUTE ESS : special case : duration is lower
				// or equals than referred threshold (" +
				// droolsParams.getRefd2_DI2S() + " s) , use power sensor mode
				// lower bound" + powerAssociated);
			} else {
				// set the power with the upper bound value
				powerAssociated = droolsParams.getPowerAssociatedWithSensorModeUL(sensor, false);
				// logger.debug("COMPUTE ESS : special case : duration is higher
				// than referred threshold (" + droolsParams.getRefd2_DI2S() + "
				// s) , use power sensor mode upper bound" + powerAssociated);
			}
		}

		// if the acquisition is of type SPOTLIGHT_1_MSOR
		else if ((sensor.equals(TypeOfAcquisition.SPOTLIGHT_1_MSOR) && acq.getPrMode().equals(PRMode.DI2S))) {
			// if duration is less then referred Refd1_DI2S
			if (duration <= droolsParams.getRefd1_DI2S()) {
				// get power associated
				powerAssociated = droolsParams.getPowerAssociatedWithSensorModeUL(sensor, true);
				// logger.debug("COMPUTE ESS : special case : duration is lower
				// or equals than referred threshold (" +
				// droolsParams.getRefd1_DI2S() + " s) , use power sensor mode
				// lower bound" + powerAssociated);
			}
			// if duration is more then referred Refd1_DI2S
			else {
				// get power associated
				powerAssociated = droolsParams.getPowerAssociatedWithSensorModeUL(sensor, false);
				// logger.debug("COMPUTE ESS : special case : duration is higher
				// than referred threshold (" + droolsParams.getRefd1_DI2S() + "
				// s) , use power sensor mode upper bound" + powerAssociated);
			}
		}
		// if the acquisition has a simple sensor mode
		else {
			// get power associated
			powerAssociated = powersSensorMode.get(sensor);
			// logger.debug("COMPUTE ESS : simple case, use power sensor mode "
			// + powerAssociated);
		}

		// compute the essx
		ess = (powerAssociated * duration) / referenceSarMode;
		// logger.debug("COMPUTE ESS : computed ess associated to acq " + ess);

		// return the rounded value of ess
		return new BigDecimal(ess).setScale(2, BigDecimal.ROUND_UP).doubleValue();
	}

	/**
	 * Gets the next.
	 *
	 * @param current the current
	 * @param allAcq  the all acq
	 * @return the next
	 */
	public Acquisition getNext(Acquisition current, TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		// declare an acquisition as next acquisition
		Acquisition next = null;

		// get the next element in treemap, if exists
		if (allAcq.higherKey(current.getStartTime().getTime()) != null) {
			// get the next acquisition
			next = (Acquisition) allAcq.get(allAcq.higherKey(current.getStartTime().getTime())).getTask();
		}
		return next;
	}

	/**
	 * Gets the previous.
	 *
	 * @param current the current
	 * @param allAcq  the all acq
	 * @return the previous
	 */
	public Acquisition getPrevious(Acquisition current, TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		// declare an acquisition as previous acquisition
		Acquisition previous = null;

		// get the previous element in treemap, if exists
		Object existPrev = allAcq.lowerKey(current.getStartTime().getTime());

		// if the previous element exists
		if (existPrev != null) {
			// get the previous acquisition
			previous = (Acquisition) allAcq.lowerEntry(current.getStartTime().getTime()).getValue().getTask();
		}
		return previous;
	}

	/**
	 * Update map after remove.
	 *
	 * @param acq    the acq
	 * @param allAcq the all acq
	 */
	public void updateMapAfterRemove(Acquisition acq, TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		// if there is an entry associated with the start time of the acq to
		// remove
		if (allAcq.containsKey(acq.getStartTime().getTime())) {
			// get the reference to the next element
			long memId = acq.getNextElementKey();

			// get the previous element in treemap, if exists
			Object preckey = allAcq.lowerKey(acq.getStartTime().getTime());

			// if the previous element exists
			if (preckey != null) {
				// get the previous acquisition
				Acquisition prevAcq = (Acquisition) allAcq.get(preckey).getTask();

				// set the next element key with the value extracted above
				prevAcq.setNextElementKey(memId);
			}

			// remove the acquisition from the treemap
			allAcq.remove(acq.getStartTime().getTime());
		}
	}

	/**
	 * Sets the correct mark type.
	 *
	 * @param logger        the logger
	 * @param task          the task
	 * @param isLmpOrVu     the is lmp or vu
	 * @param deletedByCsps the deleted by csps
	 * @param deletedTasks  the deleted tasks
	 */
	public void setCorrectMarkType(Logger logger, Task task, boolean isLmpOrVu, boolean deletedByCsps,
			List<Task> deletedTasks) {
		// if the session is of type veryUrgent and the reason is reject from
		// csps
		if (isLmpOrVu && deletedByCsps) {
			// set the task mark to deleted
			task.setTaskMark(TaskMarkType.DELETED);

			// add the current task to the list of deleted tasks
			deletedTasks.add(task);
		}
	}

}
