/**
*
* MODULE FILE NAME: Download.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;

// TODO: Auto-generated Javadoc
//import com.nais.spla.brm.library.main.ontology.enums.PRPriority;

/**
 * The Class Download.
 */
@SuppressWarnings("serial")
public class Download extends Task implements Serializable {

	/** The related task id. */
	private String relatedTaskId;

	/** The packet store strategy. */
	private DownlinkStrategy packetStoreStrategy;

	/** The link. */
	private boolean carrierL2Selection;

	/** The downloaded size. */
	private int downloadedSize;

	/** The priority. */
	private int priority = 1;

	/** The pr type. */
	private PRType prType = null;

	/** The sector shift. */
	private int sectorShift = 0;

	/** The memory modules. */
	private Map<MemoryModule, Long> plannedOnMemModule;

	/** The pol. */
	private Polarization pol;

	/** The initial sector. */
	private int initialSector = 0;

	/** The priority download. */
	private int priorityDownload = 0;

	/** The final sector. */
	private int finalSector = 0;

	/** The univoque vis id. */
	private String univoqueVisId = null;

	/** The for partners. */
	private List<String> ugsOwnerList;

	/** The visibility id. */
	private long contactCounter;

	/** The packet store number. */
	private int packetStoreNumber;

	/** The acq stat id. */
	private String acqStatId = null;

	/**
	 * Instantiates a new download.
	 */
	public Download() {
		super();

	}

	/**
	 * Instantiates a new download.
	 *
	 * @param satelliteId the satellite id
	 */
	public Download(String satelliteId) {
		// set the satellite id
		super.setSatelliteId(satelliteId);

		// set the task type
		super.setTaskType(TaskType.DOWNLOAD);

		// set the ugs owner list
		this.ugsOwnerList = new ArrayList<>();
		super.setDummy(false);
	}

	/**
	 * Gets the downloaded size.
	 *
	 * @return the downloaded size
	 */
	public int getDownloadedSize() {
		return this.downloadedSize;
	}

	/**
	 * Gets the for partners.
	 *
	 * @return the for partners
	 */
	public List<String> getUgsOwnerList() {
		return this.ugsOwnerList;
	}

	/**
	 * Gets the packet store strategy.
	 *
	 * @return the packet store strategy
	 */
	public DownlinkStrategy getPacketStoreStrategy() {
		return this.packetStoreStrategy;
	}

	/**
	 * Gets the related task id.
	 *
	 * @return the related task id
	 */
	@Override
	public String getRelatedTask() {
		return super.getRelatedTask();
	}

	/**
	 * Sets the downloaded size.
	 *
	 * @param downloadedSize the new downloaded size
	 */
	public void setDownloadedSize(int downloadedSize) {
		this.downloadedSize = downloadedSize;
	}


	/**
	 * Sets the for partners.
	 *
	 * @param ugsOwnerList the new ugs owner list
	 */
	public void setUgsOwnerList(List<String> ugsOwnerList) {
		this.ugsOwnerList = ugsOwnerList;
	}

	/**
	 * Sets the packet store strategy.
	 *
	 * @param packetStoreStrategy the new packet store strategy
	 */
	public void setPacketStoreStrategy(DownlinkStrategy packetStoreStrategy) {
		this.packetStoreStrategy = packetStoreStrategy;
	}

	/**
	 * Gets the task mark.
	 *
	 * @return the related task mark
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/**
	 * Sets the task mark of the download
	 *
	 * @param the taskMark of the download
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/**
	 * Gets the related task type.
	 *
	 * @return the related task type
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/**
	 * Sets the related task type.
	 *
	 * @params the related taskType
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}
	
	/**
	 * Sets the related task id.
	 *
	 * @param relatedTask the new related task id
	 */
	@Override
	public void setRelatedTaskId(String relatedTask) {
		this.relatedTaskId = relatedTask;
		super.setRelatedTaskId(relatedTask);
	}

	/**
	 * Gets the related task id.
	 *
	 * @return the related task id
	 */
	public String getRelatedTaskId() {
		return super.getRelatedTask();
	}

	/**
	 * return the toString of the Download
	 *
	 * @return the toString 
	 * with all the properties 
	 * of the current download
	 */
	@Override
	public String toString() {
		/*
		 * return the toString of the Download
		 *
		 * return the toString 
		 * with all the properties 
		 * of the current download
		 */
		return "Download [relatedTaskId=" + this.relatedTaskId + ", startTime :"
				+ DroolsUtils.getDateInMilliseconds(super.getStartTime()) + " stopTime :"
				+ DroolsUtils.getDateInMilliseconds(super.getEndTime()) + ", priority : " + priority
				+ ", packetStore packetStoreStrategy= " + this.packetStoreStrategy + ", carrierL2Selection="
				+ this.carrierL2Selection + ", downloadedSize=" + this.downloadedSize + ", pol=" + this.pol
				+ ", initialSector=" + this.initialSector + ", finalSector=" + this.finalSector + ", ugsOwnerList="
				+ this.ugsOwnerList + ", contactCounter=" + this.contactCounter + ", acqStatId=" + this.acqStatId
				+ ",di2sInfo : " + this.getDi2sInfo() + " ]";
	}

	/**
	 * Checks if is carrier L 2 selection.
	 *
	 * @return true, if is carrier L 2 selection
	 */
	public boolean isCarrierL2Selection() {
		return this.carrierL2Selection;
	}

	/**
	 * Gets the start time of the Download
	 * 
	 * @return the download start time
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/**
	 * Sets the carrier L 2 selection.
	 *
	 * @param carrierL2Selection the new carrier L 2 selection
	 */
	public void setCarrierL2Selection(boolean carrierL2Selection) {
		this.carrierL2Selection = carrierL2Selection;
	}

	/**
	 * Gets the packet store number.
	 *
	 * @return the packet store number
	 */
	public int getPacketStoreNumber() {
		return this.packetStoreNumber;
	}

	/**
	 * Sets the packet store number.
	 *
	 * @param packetStoreNumber the new packet store number
	 */
	public void setPacketStoreNumber(int packetStoreNumber) {
		this.packetStoreNumber = packetStoreNumber;
	}

	/**
	 * Gets the final sector.
	 *
	 * @return the final sector
	 */
	public int getFinalSector() {
		return this.finalSector;
	}

	/**
	 * Sets the final sector.
	 *
	 * @param finalSector the new final sector
	 */
	public void setFinalSector(int finalSector) {
		this.finalSector = finalSector;
	}

	/**
	 * Gets the initial sector.
	 *
	 * @return the initial sector
	 */
	public int getInitialSector() {
		return this.initialSector;
	}

	/**
	 * Sets the initial sector.
	 *
	 * @param initialSector the new initial sector
	 */
	public void setInitialSector(int initialSector) {
		this.initialSector = initialSector;
	}

	/**
	 * Gets the contact counter.
	 *
	 * @return the contact counter
	 */
	public long getContactCounter() {
		return this.contactCounter;
	}

	/**
	 * Sets the contact counter.
	 *
	 * @param contactCounter the new contact counter
	 */
	public void setContactCounter(long contactCounter) {
		this.contactCounter = contactCounter;
	}

	/**
	 * Gets the pol.
	 *
	 * @return the pol
	 */
	public Polarization getPol() {
		return this.pol;
	}

	/**
	 * Sets the pol.
	 *
	 * @param pol the new pol
	 */
	public void setPol(Polarization pol) {
		this.pol = pol;
	}

	/**
	 * Gets the acq stat id.
	 *
	 * @return the acqStatId
	 */
	public String getAcqStatId() {
		return this.acqStatId;
	}

	/**
	 * Sets the acq stat id.
	 *
	 * @param acqStatId the acqStatId to set
	 */
	public void setAcqStatId(String acqStatId) {
		this.acqStatId = acqStatId;
	}

	/**
	 * Gets the planned on mem module.
	 *
	 * @return the plannedOnMemModule
	 */
	public Map<MemoryModule, Long> getPlannedOnMemModule() {
		return this.plannedOnMemModule;
	}

	/**
	 * Sets the planned on mem module.
	 *
	 * @param plannedOnMemModule the plannedOnMemModule to set
	 */
	public void setPlannedOnMemModule(Map<MemoryModule, Long> plannedOnMemModule) {
		this.plannedOnMemModule = plannedOnMemModule;
	}

	/**
	 * Gets the univoque vis id.
	 *
	 * @return the univoque vis id
	 */
	public String getUnivoqueVisId() {
		return this.univoqueVisId;
	}

	/**
	 * Sets the univoque vis id.
	 *
	 * @param univoqueVisId the new univoque vis id
	 */
	public void setUnivoqueVisId(String univoqueVisId) {
		this.univoqueVisId = univoqueVisId;
	}

	/**
	 * Gets the pr type.
	 *
	 * @return the pr type
	 */
	public PRType getPrType() {
		return prType;
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * Gets the priority download.
	 *
	 * @return the priority download
	 */
	public int getPriorityDownload() {
		return priorityDownload;
	}

	/**
	 * Gets the sector shift.
	 *
	 * @return the sector shift
	 */
	public int getSectorShift() {
		return sectorShift;
	}

	/**
	 * Sets the sector shift.
	 *
	 * @param sectorShift the new sector shift
	 */
	public void setSectorShift(int sectorShift) {
		this.sectorShift = sectorShift;
	}

}
