/**
*
* MODULE FILE NAME:	ResourceFunctions.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		06 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 06 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.ontology.resourceData.BicHpPeakOrbit;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ElementsTillThreshold;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

// TODO: Auto-generated Javadoc
/**
 * The Class ResourceFunctions.
 *
 * @author fpedrola
 */
public class ResourceFunctions {

	/** The silent function sat 1. */
	private TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1 = new TreeMap<>();

	/** The silent function sat 2. */
	private TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat2 = new TreeMap<>();

	/** The bic hp peak orbit function sat 1. */
	private TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunctionSat1 = new TreeMap<>();

	/** The bic hp peak orbit function sat 2. */
	private TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunctionSat2 = new TreeMap<>();

	/** The PDHT temporal function sat 1. */
	private TreeMap<Long, ComplexPdht> PDHTTemporalFunctionSat1 = new TreeMap<>();

	/** The PDHT temporal function sat 2. */
	private TreeMap<Long, ComplexPdht> PDHTTemporalFunctionSat2 = new TreeMap<>();

	/** The all maneuvers sat 1. */
	private TreeMap<Long, Maneuver> allManeuversSat1 = new TreeMap<>();

	/** The all maneuvers sat 2. */
	private TreeMap<Long, Maneuver> allManeuversSat2 = new TreeMap<>();

	/** all the rumps for sat 1. */
	private TreeMap<Long, RampCMGA> allRampsSat1 = new TreeMap<>();

	/** all the rumps for sat 2. */
	private TreeMap<Long, RampCMGA> allRampsSat2 = new TreeMap<>();

	/** The all cmg axis rec sat 1. */
	private TreeMap<Long, CMGAxis> allCmgAxisRecSat1 = new TreeMap<>();

	/** The all cmg axis rec sat 2. */
	private TreeMap<Long, CMGAxis> allCmgAxisRecSat2 = new TreeMap<>();

	/** The ess function sat 1. */
	private TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = new TreeMap<>();

	/** The ess function sat 2. */
	private TreeMap<Long, EnergyAssociatedToTask> essFunctionSat2 = new TreeMap<>();

	/** The download priority queue sat 1. */
	private TreeMap<String, PriorityQueue> downloadPriorityQueueSat1 = new TreeMap<>();

	/** The download priority queue sat 2. */
	private TreeMap<String, PriorityQueue> downloadPriorityQueueSat2 = new TreeMap<>();

	/** The download priority queue sat 1. */
	private TreeMap<String, PriorityQueue> downloadPriorityQueueSatInitPlan1 = new TreeMap<>();

	/** The download priority queue sat 2. */
	private TreeMap<String, PriorityQueue> downloadPriorityQueueSatInitPlan2 = new TreeMap<>();

	/** The dwl tree map sat 1. */
	private TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat1 = new TreeMap<>();

	/** The dwl tree map sat 2. */
	private TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat2 = new TreeMap<>();

	/** The all sto aux sat 1. */
	private List<StoreAUX> allStoAuxSat1 = new ArrayList<>();

	/** The all sto aux sat 2. */
	private List<StoreAUX> allStoAuxSat2 = new ArrayList<>();

	/** The all dwl sat 1 as list. */
	private List<Download> allDwlSat1AsList = new ArrayList<>();

	/** The all dwl sat 2 as list. */
	private List<Download> allDwlSat2AsList = new ArrayList<>();

	/** The all hp excl sat 1. */
	private TreeMap<Long, HPExclusion> allHpExclSat1 = new TreeMap<>();

	/** The all hp excl sat 2. */
	private TreeMap<Long, HPExclusion> allHpExclSat2 = new TreeMap<>();

	/** The all sto sat 1. */
	private TreeMap<String, Storage> allStoSat1 = new TreeMap<>();

	/** The all sto sat 2. */
	private TreeMap<String, Storage> allStoSat2 = new TreeMap<>();

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// this method toString
		// allows the print of all
		// the elements memorized
		// into this object
		return "ResourceFunctions [silentFunctionSat1=" + this.silentFunctionSat1 + ", silentFunctionSat2="
				+ this.silentFunctionSat2 + ", PDHTTemporalFunctionSat1=" + this.PDHTTemporalFunctionSat1
				+ ", PDHTTemporalFunctionSat2=" + this.PDHTTemporalFunctionSat2 + ", allManeuversSat1="
				+ this.allManeuversSat1 + ", allManeuversSat2=" + this.allManeuversSat2 + ", allRampsSat1="
				+ this.allRampsSat1 + ", allRampsSat2=" + this.allRampsSat2 + ", essFunctionSat1="
				+ this.essFunctionSat1 + ", essFunctionSat2=" + this.essFunctionSat2 + "]";
	}

	/**
	 * Instantiates a new resource functions.
	 */
	public ResourceFunctions() {
		super();
	}

	/**
	 * Calculate local max.
	 *
	 * @param from           the from
	 * @param to             the to
	 * @param energyFunction the energy function
	 * @return the double
	 */
	public ElementsTillThreshold calculateLocalMax(long from, long to,
			TreeMap<Long, EnergyAssociatedToTask> energyFunction) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// initialize the total variable
		double actualSilentTot = 0;

		// initialize the ElementsTillThreshold to collect all the elements
		// found in interval till the reached threshold
		ElementsTillThreshold elements = null;
		List<String> acqId = new ArrayList<>();

		// get the submap of the map filtered with all and only the values
		// between the start and stop given as input
		NavigableMap<Long, EnergyAssociatedToTask> subMap = energyFunction.subMap(from, true, to, true);

		// check if exist an element before the startCheck given as input
		Object prevKey = energyFunction.lowerKey(from);

		// if exist
		if (prevKey != null) {
			// extract it
			Task prevAcq = energyFunction.get(prevKey).getTask();

			// check if is a borderline case : starts before interval and ends
			// after it
			if (prevAcq.getEndTime().getTime() > from) {
				logger.trace("borderline case added in check:  energy for :" + prevAcq.getIdTask());

				// add it to the list of involved elements
				acqId.add(energyFunction.get(prevKey).getTask().getIdTask());

				// add it's ess to the total count of energy
				actualSilentTot = actualSilentTot + energyFunction.get(prevKey).getEssValue();
				logger.trace("total energy till now :" + actualSilentTot);
			}
		}

		// iterate over all the elements in interval
		for (Map.Entry<Long, EnergyAssociatedToTask> entry : subMap.entrySet()) {
			// get the related energy
			double extractedEnergy = entry.getValue().getEssValue();

			// get the current task
			Task currentTask = entry.getValue().getTask();

			if (currentTask instanceof Acquisition) {
				logger.trace("extracted energy for :" + entry.getValue().getTask().getIdTask() + " is :"
						+ entry.getValue().getEssValue());
			}

			// add it to the list of involved elements
			acqId.add(entry.getValue().getTask().getIdTask());

			// add it's ess to the total count of energy
			actualSilentTot = actualSilentTot + extractedEnergy;
			logger.trace("total energy till now :" + actualSilentTot);

		}
		// populate the ElementsTillThreshold with the total value of used
		// energy and total elements involved
		elements = new ElementsTillThreshold(actualSilentTot, acqId);
		return elements;
	}

	/**
	 * Clear all.
	 */
	public void clearAll() {
		// removing all the maneuvers for both satellites
		this.allManeuversSat1.clear();
		this.allManeuversSat2.clear();

		// removing all the ramps for both satellites
		this.allRampsSat1.clear();
		this.allRampsSat2.clear();

		// removing all the ess energies for both satellites
		this.essFunctionSat1.clear();
		this.essFunctionSat2.clear();

		// removing all the pdht for both satellites
		this.PDHTTemporalFunctionSat1.clear();
		this.PDHTTemporalFunctionSat2.clear();

		// removing all the silents for both satellites
		this.silentFunctionSat1.clear();
		this.silentFunctionSat2.clear();

		// removing all the downloads for both satellites
		this.downloadPriorityQueueSat1.clear();
		this.downloadPriorityQueueSat2.clear();

		// removing all the downloads for both satellites
		this.dwlTreeMapSat1.clear();
		this.dwlTreeMapSat2.clear();
	}

	/**
	 * Gets the all maneuvers sat 1.
	 *
	 * @return the allManeuversSat1
	 */
	public TreeMap<Long, Maneuver> getAllManeuversSat1() {
		return this.allManeuversSat1;
	}

	/**
	 * Gets the all maneuvers sat 2.
	 *
	 * @return the allManeuversSat2
	 */
	public TreeMap<Long, Maneuver> getAllManeuversSat2() {
		return this.allManeuversSat2;
	}

	/**
	 * Gets the ess function associated to sat.
	 *
	 * @param satId the sat id
	 * @return the ess function associated to sat
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getEssFunctionAssociatedToSat(String satId) {
		// create an empty map for the created ess energy related to
		// acquisitions
		TreeMap<Long, EnergyAssociatedToTask> essFunctions = null;

		// if the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			essFunctions = this.essFunctionSat1;
		}
		// if the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			essFunctions = this.essFunctionSat2;
		}
		return essFunctions;
	}

	/**
	 * Gets the storages associated to sat.
	 *
	 * @param satId the sat id
	 * @return the storages associated to sat
	 */
	public TreeMap<String, Storage> getStoragesAssociatedToSat(String satId) {
		// create an empty map for the created storages elements
		TreeMap<String, Storage> allStorages = new TreeMap<>();

		// if the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			allStorages = this.getAllStoSat1();
		}
		// if the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			allStorages = this.getAllStoSat2();
		}
		return allStorages;
	}

	/**
	 * Gets the cmga axis associated to sat.
	 *
	 * @param satId the sat id
	 * @return the cmga axis associated to sat
	 */
	public TreeMap<Long, CMGAxis> getCmgaAxisAssociatedToSat(String satId) {
		// create an empty map for the created cmgAxis elements
		TreeMap<Long, CMGAxis> allCmgAxis = null;

		// if the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			allCmgAxis = this.allCmgAxisRecSat1;
		}
		// if the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			allCmgAxis = this.allCmgAxisRecSat2;
		}
		return allCmgAxis;
	}

	/**
	 * Gets the dwl function associated to sat.
	 *
	 * @param satId the sat id
	 * @return the dwl function associated to sat
	 */
	public TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> getDwlFunctionAssociatedToSat(String satId) {
		// create an empty map for the created download elements
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadfunction = null;

		// if the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			downloadfunction = this.getDwlTreeMapSat1();
		}
		// if the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			downloadfunction = this.getDwlTreeMapSat2();
		}
		return downloadfunction;
	}

	/**
	 * Gets the ess function sat 1.
	 *
	 * @return the ess function sat 1
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getEssFunctionSat1() {
		return this.essFunctionSat1;
	}

	/**
	 * Gets the ess function sat 2.
	 *
	 * @return the ess function sat 2
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getEssFunctionSat2() {
		return this.essFunctionSat2;
	}

	/**
	 * Gets the download priority queue for sat.
	 *
	 * @param satId the sat id
	 * @return the download priority queue for sat
	 */
	public TreeMap<String, PriorityQueue> getDownloadPriorityQueueForSat(String satId) {
		// create an empty map for the created priority elements
		TreeMap<String, PriorityQueue> priorityQueue = null;

		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			priorityQueue = getDownloadPriorityQueueSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			priorityQueue = getDownloadPriorityQueueSat2();
		}
		return priorityQueue;
	}

	/**
	 * Gets the bic hp peak orbit associated to sat.
	 *
	 * @param satId the sat id
	 * @return the bic hp peak orbit associated to sat
	 */
	public TreeMap<Long, BicHpPeakOrbit> getBicHpPeakOrbitAssociatedToSat(String satId) {
		// create an empty map for the created peaks
		TreeMap<Long, BicHpPeakOrbit> essFunctions = null;

		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			essFunctions = this.getBicHpPeakOrbitFunctionSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			essFunctions = this.getBicHpPeakOrbitFunctionSat2();
		}
		return essFunctions;
	}

	/**
	 * Gets the maneuver function associated to sat.
	 *
	 * @param satId the sat id
	 * @return the maneuver function associated to sat
	 */
	public TreeMap<Long, Maneuver> getManeuverFunctionAssociatedToSat(String satId) {
		// create an empty map for the created maneuvers
		TreeMap<Long, Maneuver> manFunctions = null;

		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			manFunctions = this.getAllManeuversSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			manFunctions = this.getAllManeuversSat2();
		}
		return manFunctions;
	}

	/**
	 * Gets the ramp function associated to sat.
	 *
	 * @param satId the sat id
	 * @return the ramp function associated to sat
	 */
	public TreeMap<Long, RampCMGA> getRampFunctionAssociatedToSat(String satId) {
		// create an empty map for the created ramps
		TreeMap<Long, RampCMGA> rampFunctions = null;
		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			rampFunctions = this.getAllRampsSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			rampFunctions = this.getAllRampsSat2();
		}
		return rampFunctions;
	}

	/**
	 * Gets the downloads associated to sat.
	 *
	 * @param satId the sat id
	 * @return the downloads associated to sat
	 */
	public TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> getDownloadsAssociatedToSat(String satId) {
		// create an empty map for the created downloads
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadFunctions = null;
		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			downloadFunctions = this.dwlTreeMapSat1;
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			downloadFunctions = this.dwlTreeMapSat2;
		}
		return downloadFunctions;
	}

	/**
	 * Sets the downloads associated to sat.
	 *
	 * @param satId   the sat id
	 * @param treeMap the tree map
	 */
	public void setDownloadsAssociatedToSat(String satId,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> treeMap) {
		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			this.setDwlTreeMapSat1(treeMap);
		}
		// is the satellite related to the current task is the first
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			this.setDwlTreeMapSat2(treeMap);
		}
	}

	/**
	 * Gets the PDHT function associated to sat.
	 *
	 * @param satId the sat id
	 * @return the PDHT function associated to sat
	 */
	public TreeMap<Long, ComplexPdht> getPDHTFunctionAssociatedToSat(String satId) {
		// create the map that will contains all the photographs of pdht at
		// inserting/removing tasks
		TreeMap<Long, ComplexPdht> PDHTFunctions = null;

		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			PDHTFunctions = this.getPDHTTemporalFunctionSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat1
			PDHTFunctions = this.getPDHTTemporalFunctionSat2();
		}
		return PDHTFunctions;
	}

	/**
	 * Gets the PDHT temporal function sat 1.
	 *
	 * @return the pDHTTemporalFunctionSat1
	 */
	public TreeMap<Long, ComplexPdht> getPDHTTemporalFunctionSat1() {
		return this.PDHTTemporalFunctionSat1;
	}

	/**
	 * Gets the PDHT temporal function sat 2.
	 *
	 * @return the pDHTTemporalFunctionSat2
	 */
	public TreeMap<Long, ComplexPdht> getPDHTTemporalFunctionSat2() {
		return this.PDHTTemporalFunctionSat2;
	}

	/**
	 * Gets the silent function associated to sat.
	 *
	 * @param satId the sat id
	 * @return the silent function associated to sat
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getSilentFunctionAssociatedToSat(String satId) {
		// create an empty map for the energies reserved to silents
		TreeMap<Long, EnergyAssociatedToTask> silentFunctions = null;

		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			silentFunctions = this.getSilentFunctionSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			silentFunctions = this.getSilentFunctionSat2();
		}
		return silentFunctions;
	}

	/**
	 * Gets the download associated to sat.
	 *
	 * @param satelliteId the satellite id
	 * @return the download associated to sat
	 */
	public List<Download> getDownloadAssociatedToSat(String satelliteId) {
		// create an empty map for the energies reserved to silents
		List<Download> dwlRelatedToSat = new ArrayList<>();

		// is the satellite related to the current task is the first
		if (satelliteId.contains("1")) {
			// return the map relative to the sat1
			dwlRelatedToSat = this.getAllDwlSat1AsList();
		}
		// is the satellite related to the current task is the second
		else // if (satelliteId.contains("2"))
		{
			// return the map relative to the sat2
			dwlRelatedToSat = this.getAllDwlSat2AsList();
		}
		return dwlRelatedToSat;
	}

	/**
	 * Gets the hp excl associated to sat.
	 *
	 * @param satelliteId the satellite id
	 * @return the hp excl associated to sat
	 */
	public TreeMap<Long, HPExclusion> getHpExclAssociatedToSat(String satelliteId) {
		// create an empty map for the energies reserved to silents
		TreeMap<Long, HPExclusion> hpExclRelatedToSat = new TreeMap<>();

		// is the satellite related to the current task is the first
		if (satelliteId.contains("1")) {
			// return the map relative to the sat1
			hpExclRelatedToSat = this.getAllHpExclSat1();
		}
		// is the satellite related to the current task is the second
		else // if (satelliteId.contains("2"))
		{
			// return the map relative to the sat2
			hpExclRelatedToSat = this.getAllHpExclSat2();
		}
		return hpExclRelatedToSat;
	}

	/**
	 * Gets the all sto aux for satellite.
	 *
	 * @param satId the sat id
	 * @return the allStoAuxSat1
	 */
	public List<StoreAUX> getAllStoAuxForSatellite(String satId) {
		// create an empty map for the energies reserved to silents
		List<StoreAUX> returnedStoAuxList = this.allStoAuxSat1;

		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			returnedStoAuxList = this.allStoAuxSat1;
		}
		// is the satellite related to the current task is the second
		else // if (satId.contains("2"))
		{
			// return the map relative to the sat2
			returnedStoAuxList = this.allStoAuxSat2;
		}
		return returnedStoAuxList;
	}

	/**
	 * Gets the silent function sat 1.
	 *
	 * @return the silentFunctionSat1
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getSilentFunctionSat1() {
		return this.silentFunctionSat1;
	}

	/**
	 * Gets the silent function sat 2.
	 *
	 * @return the silentFunctionSat2
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getSilentFunctionSat2() {
		return this.silentFunctionSat2;
	}

	/**
	 * Sets the all maneuvers sat 1.
	 *
	 * @param allManeuversSat1 the allManeuversSat1 to set
	 */
	public void setAllManeuversSat1(TreeMap<Long, Maneuver> allManeuversSat1) {
		this.allManeuversSat1 = allManeuversSat1;
	}

	/**
	 * Sets the all maneuvers sat 2.
	 *
	 * @param allManeuversSat2 the allManeuversSat2 to set
	 */
	public void setAllManeuversSat2(TreeMap<Long, Maneuver> allManeuversSat2) {
		this.allManeuversSat2 = allManeuversSat2;
	}

	/**
	 * Sets the ess function sat 1.
	 *
	 * @param essFunctionSat1 the ess function sat 1
	 */
	public void setEssFunctionSat1(TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1) {
		this.essFunctionSat1 = essFunctionSat1;
	}

	/**
	 * Sets the ess function sat 2.
	 *
	 * @param essFunctionSat2 the ess function sat 2
	 */
	public void setEssFunctionSat2(TreeMap<Long, EnergyAssociatedToTask> essFunctionSat2) {
		this.essFunctionSat2 = essFunctionSat2;
	}

	/**
	 * Sets the PDHT temporal function sat 1.
	 *
	 * @param pDHTTemporalFunctionSat1 the pDHTTemporalFunctionSat1 to set
	 */
	public void setPDHTTemporalFunctionSat1(TreeMap<Long, ComplexPdht> pDHTTemporalFunctionSat1) {
		this.PDHTTemporalFunctionSat1 = pDHTTemporalFunctionSat1;
	}

	/**
	 * Sets the PDHT temporal function sat 2.
	 *
	 * @param pDHTTemporalFunctionSat2 the pDHTTemporalFunctionSat2 to set
	 */
	public void setPDHTTemporalFunctionSat2(TreeMap<Long, ComplexPdht> pDHTTemporalFunctionSat2) {
		this.PDHTTemporalFunctionSat2 = pDHTTemporalFunctionSat2;
	}

	/**
	 * Sets the silent function sat 1.
	 *
	 * @param silentFunctionSat1 the silentFunctionSat1 to set
	 */
	public void setSilentFunctionSat1(TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1) {
		this.silentFunctionSat1 = silentFunctionSat1;
	}

	/**
	 * Sets the silent function sat 2.
	 *
	 * @param silentFunctionSat2 the silentFunctionSat2 to set
	 */
	public void setSilentFunctionSat2(TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat2) {
		this.silentFunctionSat2 = silentFunctionSat2;
	}

	/**
	 * Gets the all ramps sat 2.
	 *
	 * @return the all ramps sat 2
	 */
	public TreeMap<Long, RampCMGA> getAllRampsSat2() {
		return this.allRampsSat2;
	}

	/**
	 * Sets the all ramps sat 2.
	 *
	 * @param allRampsSat2 the all ramps sat 2
	 */
	public void setAllRampsSat2(TreeMap<Long, RampCMGA> allRampsSat2) {
		this.allRampsSat2 = allRampsSat2;
	}

	/**
	 * Sets the all ramps sat 1.
	 *
	 * @param allRampsSat1 the all ramps sat 1
	 */
	public void setAllRampsSat1(TreeMap<Long, RampCMGA> allRampsSat1) {
		this.allRampsSat1 = allRampsSat1;
	}

	/**
	 * Gets the all ramps sat 1.
	 *
	 * @return the all ramps sat 1
	 */
	public TreeMap<Long, RampCMGA> getAllRampsSat1() {
		return this.allRampsSat1;
	}

	/**
	 * Gets the bic hp peak orbit function sat 1.
	 *
	 * @return the bic hp peak orbit function sat 1
	 */
	public TreeMap<Long, BicHpPeakOrbit> getBicHpPeakOrbitFunctionSat1() {
		return this.bicHpPeakOrbitFunctionSat1;
	}

	/**
	 * Sets the bic hp peak orbit function sat 1.
	 *
	 * @param bicHpPeakOrbitFunctionSat1 the bic hp peak orbit function sat 1
	 */
	public void setBicHpPeakOrbitFunctionSat1(TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunctionSat1) {
		this.bicHpPeakOrbitFunctionSat1 = bicHpPeakOrbitFunctionSat1;
	}

	/**
	 * Gets the bic hp peak orbit function sat 2.
	 *
	 * @return the bic hp peak orbit function sat 2
	 */
	public TreeMap<Long, BicHpPeakOrbit> getBicHpPeakOrbitFunctionSat2() {
		return this.bicHpPeakOrbitFunctionSat2;
	}

	/**
	 * Sets the bic hp peak orbit function sat 2.
	 *
	 * @param bicHpPeakOrbitFunctionSat2 the bic hp peak orbit function sat 2
	 */
	public void setBicHpPeakOrbitFunctionSat2(TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunctionSat2) {
		this.bicHpPeakOrbitFunctionSat2 = bicHpPeakOrbitFunctionSat2;
	}

	/**
	 * Gets the download priority queue sat 1.
	 *
	 * @return the download priority queue sat 1
	 */
	public TreeMap<String, PriorityQueue> getDownloadPriorityQueueSat1() {
		return this.downloadPriorityQueueSat1;
	}

	/**
	 * Sets the download priority queue sat 1.
	 *
	 * @param downloadPriorityQueueSat1 the download priority queue sat 1
	 */
	public void setDownloadPriorityQueueSat1(TreeMap<String, PriorityQueue> downloadPriorityQueueSat1) {
		this.downloadPriorityQueueSat1 = downloadPriorityQueueSat1;
	}

	/**
	 * Sets the download priority queue for sat.
	 *
	 * @param satId the sat id
	 * @param downloadPriorityQueue the download priority queue
	 */
	public void setDownloadPriorityQueueForSat(String satId, TreeMap<String, PriorityQueue> downloadPriorityQueue) {
		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			this.downloadPriorityQueueSat1 = downloadPriorityQueue;
		} else {
			this.downloadPriorityQueueSat2 = downloadPriorityQueue;
		}
	}

	/**
	 * Gets the download priority queue sat 2.
	 *
	 * @return the download priority queue sat 2
	 */
	public TreeMap<String, PriorityQueue> getDownloadPriorityQueueSat2() {
		return this.downloadPriorityQueueSat2;
	}

	/**
	 * Sets the download priority queue sat 2.
	 *
	 * @param downloadPriorityQueueSat2 the download priority queue sat 2
	 */
	public void setDownloadPriorityQueueSat2(TreeMap<String, PriorityQueue> downloadPriorityQueueSat2) {
		this.downloadPriorityQueueSat2 = downloadPriorityQueueSat2;
	}

	/**
	 * Gets the dwl tree map sat 1.
	 *
	 * @return the dwlTreeMapSat1
	 */
	public TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> getDwlTreeMapSat1() {
		return this.dwlTreeMapSat1;
	}

	/**
	 * Sets the dwl tree map sat 1.
	 *
	 * @param dwlTreeMapSat1 the dwlTreeMapSat1 to set
	 */
	public void setDwlTreeMapSat1(TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat1) {
		this.dwlTreeMapSat1 = dwlTreeMapSat1;
	}

	/**
	 * Gets the dwl tree map sat 2.
	 *
	 * @return the dwlTreeMapSat2
	 */
	public TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> getDwlTreeMapSat2() {
		return this.dwlTreeMapSat2;
	}

	/**
	 * Sets the dwl tree map sat 2.
	 *
	 * @param dwlTreeMapSat2 the dwlTreeMapSat2 to set
	 */
	public void setDwlTreeMapSat2(TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat2) {
		this.dwlTreeMapSat2 = dwlTreeMapSat2;
	}

	/**
	 * Gets the all sto sat 1.
	 *
	 * @return the allStoSat1
	 */
	public TreeMap<String, Storage> getAllStoSat1() {
		return this.allStoSat1;
	}

	/**
	 * Gets the all sto sat 2.
	 *
	 * @return the allStoSat2
	 */
	public TreeMap<String, Storage> getAllStoSat2() {
		return this.allStoSat2;
	}

	/**
	 * Gets the all dwl sat 1 as list.
	 *
	 * @return the allDwlSat1AsList
	 */
	public List<Download> getAllDwlSat1AsList() {
		return this.allDwlSat1AsList;
	}

	/**
	 * Gets the all dwl sat 2 as list.
	 *
	 * @return the allDwlSat2AsList
	 */
	public List<Download> getAllDwlSat2AsList() {
		return this.allDwlSat2AsList;
	}

	/**
	 * Gets the all cmg axis rec sat 1.
	 *
	 * @return the allCmgAxisRecSat1
	 */
	public TreeMap<Long, CMGAxis> getAllCmgAxisRecSat1() {
		return this.allCmgAxisRecSat1;
	}

	/**
	 * Gets the all hp excl sat 1.
	 *
	 * @return the allHpExclSat1
	 */
	public TreeMap<Long, HPExclusion> getAllHpExclSat1() {
		return this.allHpExclSat1;
	}

	/**
	 * Gets the all hp excl sat 2.
	 *
	 * @return the allHpExclSat2
	 */
	public TreeMap<Long, HPExclusion> getAllHpExclSat2() {
		return this.allHpExclSat2;
	}

	/**
	 * Sets the download priority queue sat init plan sat.
	 *
	 * @param satId the sat id
	 * @param dwlPriority the dwl priority
	 */
	public void setDownloadPriorityQueueSatInitPlanSat(String satId, TreeMap<String, PriorityQueue> dwlPriority) {
		// is the satellite related to the current task is the first
		if (satId.contains("1")) {
			// return the map relative to the sat1
			this.downloadPriorityQueueSatInitPlan1 = dwlPriority;
		} else {
			// return the map relative to the sat1
			this.downloadPriorityQueueSatInitPlan2 = dwlPriority;
		}
	}

	/**
	 * Gets the download priority queue sat init plan 1.
	 *
	 * @return the download priority queue sat init plan 1
	 */
	public TreeMap<String, PriorityQueue> getDownloadPriorityQueueSatInitPlan1() {
		return this.downloadPriorityQueueSatInitPlan1;
	}

	/**
	 * Gets the download priority queue sat init plan 2.
	 *
	 * @return the download priority queue sat init plan 2
	 */
	public TreeMap<String, PriorityQueue> getDownloadPriorityQueueSatInitPlan2() {
		return this.downloadPriorityQueueSatInitPlan2;
	}

	/**
	 * Sets the download priority queue sat init plan 2.
	 *
	 * @param downloadPriorityQueueSatInitPlan2 the download priority queue sat init plan 2
	 */
	public void setDownloadPriorityQueueSatInitPlan2(TreeMap<String, PriorityQueue> downloadPriorityQueueSatInitPlan2) {
		this.downloadPriorityQueueSatInitPlan2 = downloadPriorityQueueSatInitPlan2;
	}
}
