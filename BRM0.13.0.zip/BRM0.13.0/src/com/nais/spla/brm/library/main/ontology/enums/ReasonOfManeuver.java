/**
*
* MODULE FILE NAME:	ReasonOfManeuver.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		04 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 04 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum ReasonOfManeuver.
 *
 * @author francesca
 */

public enum ReasonOfManeuver {

	/** The acq acq. */
	acqAcq,

	/** The acq paw. */
	acqPaw,

	/** The acq hp seg. */
	acqHpSeg,

	/** The conter man. */
	conterMan
}
