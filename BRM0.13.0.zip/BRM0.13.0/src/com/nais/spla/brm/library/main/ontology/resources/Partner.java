/**
 *
 * MODULE FILE NAME:	Partner.java
 *
 * MODULE TYPE:		Class definition
 *
 * FUNCTION:		<Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:		30 ago 2017
 *
 * AUTHORS:		fpedrola
 *
 * DESIGN ISSUE:		1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 30 ago 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resources;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;

// TODO: Auto-generated Javadoc
/**
 * The Class Partner.
 *
 * @author fpedrola
 */
@SuppressWarnings("serial")
public class Partner implements Serializable {

	/** The partner id. */
	private String partnerId;

	/** The ugs id. */
	private String ugsId;

	/** The max BIC available. */
	private double maxBICAvailable;

	/** The max NEO bic available. */
	private double maxNEOBicAvailable;

	/** The used BIC. */
	private double usedBIC;

	/** The used Neo BIC. */
	private double usedNeoBic;

	/** The pay offs. */
	private int payOffs;

	/** The max perc loan bic. */
	private double maxPercLoanBic;

	/** The new bic setup. */
	private boolean newBicSetup = false;

	/** The loan list. */
	private List<DebitCard> loanList = null;

	/** The given loan. */
	private List<CreditCard> givenLoan = null;

	/** The cannot give credit. */
	private List<String> borrowingBic = new ArrayList<>();

	/** The donation. */
	private List<String> donation = null;

	/** The finished. */
	private boolean finished = false;

	/** The ar id for partner. */
	private List<String> arIdForPartner = new ArrayList<>();

	/** The acq performed. */
	private List<String> acqPerformed = null;

	/** The all vis for partner. */
	private List<String> allVisForPartner = null;

	/**
	 * Instantiates a new partner.
	 *
	 * @param partnerId       the partner id
	 * @param arIdForPartner  the ar id for partner
	 * @param maxBicAvailable the max bic available
	 * @param maxPercLoanBic  the max perc loan bic
	 */
	public Partner(String partnerId, List<String> arIdForPartner, double maxBicAvailable, double maxPercLoanBic) {
		super();
		this.partnerId = partnerId;
		this.usedBIC = 0;
		this.usedNeoBic = 0;
		this.newBicSetup = false;
		this.maxPercLoanBic = maxPercLoanBic;
		this.loanList = new ArrayList<>();
		this.givenLoan = new ArrayList<>();
		this.borrowingBic = new ArrayList<>();
		this.allVisForPartner = new ArrayList<>();
		this.donation = new ArrayList<>();
		this.finished = false;
		this.maxBICAvailable = maxBicAvailable;
		this.maxNEOBicAvailable = -1;
		this.payOffs = 1;
		this.acqPerformed = new ArrayList<>();
		if (arIdForPartner != null) {
			this.arIdForPartner = arIdForPartner;
		}
	}

	/**
	 * Gets the pay offs.
	 *
	 * @return the payOffs
	 */
	public int getPayOffs() {
		return this.payOffs;
	}

	/**
	 * Sets the partner id.
	 *
	 * @param partnerId the partnerId to set
	 */
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	/**
	 * Gets the acq performed.
	 *
	 * @return the acq performed
	 */
	public List<String> getAcqPerformed() {
		return this.acqPerformed;
	}

	/**
	 * Gets the ar id for partner.
	 *
	 * @return the ar id for partner
	 */
	public List<String> getArIdForPartner() {
		return this.arIdForPartner;
	}

	/**
	 * Gets the donation.
	 *
	 * @return the donation
	 */
	public List<String> getDonation() {
		return this.donation;
	}

	/**
	 * Gets the given loan.
	 *
	 * @return the given loan
	 */
	public List<CreditCard> getGivenLoan() {
		return this.givenLoan;
	}

	/**
	 * Gets the loan list.
	 *
	 * @return the loan list
	 */
	public List<DebitCard> getLoanList() {
		return this.loanList;
	}

	/**
	 * Gets the max BIC available.
	 *
	 * @return the max BIC available
	 */
	public double getMaxBICAvailable() {
		return this.maxBICAvailable;
	}

	/**
	 * Gets the max NEO bic available.
	 *
	 * @return the max NEO bic available
	 */
	public double getMaxNEOBicAvailable() {
		return this.maxNEOBicAvailable;
	}

	/**
	 * Gets the partner id.
	 *
	 * @return the partner id
	 */
	public String getPartnerId() {
		return this.partnerId;
	}

	/**
	 * Gets the used BIC.
	 *
	 * @return the used BIC
	 */
	public double getUsedBIC() {
		return this.usedBIC;
	}

	/**
	 * Gets the used neo bic.
	 *
	 * @return the used neo bic
	 */
	public double getUsedNeoBic() {
		return this.usedNeoBic;
	}

	/**
	 * Checks if is finished.
	 *
	 * @return true, if is finished
	 */
	public boolean isFinished() {
		return this.finished;
	}

	/**
	 * Checks if is new bic setup.
	 *
	 * @return true, if is new bic setup
	 */
	public boolean isNewBicSetup() {
		return this.newBicSetup;
	}

	/**
	 * Sets the acq performed.
	 *
	 * @param acqPerformed the new acq performed
	 */
	public void setAcqPerformed(List<String> acqPerformed) {
		this.acqPerformed = acqPerformed;
	}

	/**
	 * Sets the ar id for partner.
	 *
	 * @param arIdForPartner the new ar id for partner
	 */
	public void setArIdForPartner(List<String> arIdForPartner) {
		this.arIdForPartner = arIdForPartner;
	}

	/**
	 * Sets the donation.
	 *
	 * @param donation the new donation
	 */
	public void setDonation(List<String> donation) {
		this.donation = donation;
	}

	/**
	 * Sets the finished.
	 *
	 * @param finished the new finished
	 */
	public void setFinished(boolean finished) {
		this.finished = finished;
	}

	/**
	 * Sets the given loan.
	 *
	 * @param givenLoan the new given loan
	 */
	public void setGivenLoan(List<CreditCard> givenLoan) {
		this.givenLoan = givenLoan;
	}

	/**
	 * Sets the loan list.
	 *
	 * @param loanList the new loan list
	 */
	public void setLoanList(List<DebitCard> loanList) {
		this.loanList = loanList;
	}

	/**
	 * Sets the max BIC available.
	 *
	 * @param maxBIC the new max BIC available
	 */
	public void setMaxBICAvailable(double maxBIC) {
		this.maxBICAvailable = maxBIC;
	}

	/**
	 * Sets the max NEO bic available.
	 *
	 * @param maxNEOBicAvailable the new max NEO bic available
	 */
	public void setMaxNEOBicAvailable(double maxNEOBicAvailable) {
		this.maxNEOBicAvailable = maxNEOBicAvailable;
	}

	/**
	 * Sets the new bic setup.
	 *
	 * @param newBicSetup the new new bic setup
	 */
	public void setNewBicSetup(boolean newBicSetup) {
		this.newBicSetup = newBicSetup;
	}

	/**
	 * Sets the used BIC.
	 *
	 * @param usBIC the new used BIC
	 */
	public void setUsedBIC(double usBIC) {
		this.usedBIC = usBIC;
	}

	/**
	 * Sets the used neo bic.
	 *
	 * @param usedNeoBic the new used neo bic
	 */
	public void setUsedNeoBic(double usedNeoBic) {
		this.usedNeoBic = usedNeoBic;
	}

	/**
	 * toString del metodo.
	 *
	 * @return the string
	 */
	@Override
	public String toString() { /**
								 * toString del metodo
								 */
		return "Partner [partnerId=" + this.partnerId + ", ugsId=" + this.ugsId + ", maxBICAvailable="
				+ this.maxBICAvailable + ", maxNEOBicAvailable=" + this.maxNEOBicAvailable + ", usedBIC=" + this.usedBIC
				+ ", usedNeoBic=" + this.usedNeoBic + ", payOffs=" + this.payOffs + ", maxPercLoanBic="
				+ this.maxPercLoanBic + ", newBicSetup=" + this.newBicSetup + ", loanList=" + this.loanList
				+ ", givenLoan=" + this.givenLoan + ", borrowingBic=" + this.borrowingBic + ", donation="
				+ this.donation + ", finished=" + this.finished + ", arIdForPartner=" + this.arIdForPartner
				+ ", acqPerformed=" + this.acqPerformed + ", allVisForPartner=" + this.allVisForPartner + "]";
	}

	/**
	 * Gets the max perc loan bic.
	 *
	 * @return the max perc loan bic
	 */
	public double getMaxPercLoanBic() {
		return this.maxPercLoanBic;
	}

	/**
	 * Sets the max perc loan bic.
	 *
	 * @param maxPercLoanBic the new max perc loan bic
	 */
	public void setMaxPercLoanBic(double maxPercLoanBic) {
		this.maxPercLoanBic = maxPercLoanBic;
	}

	/**
	 * Sets the pay offs.
	 *
	 * @param payOffs the new pay offs
	 */
	public void setPayOffs(int payOffs) {
		this.payOffs = payOffs;
	}

	/**
	 * Gets the borrowing bic.
	 *
	 * @return the borrowing bic
	 */
	public List<String> getBorrowingBic() {
		return this.borrowingBic;
	}

	/**
	 * Sets the borrowing bic.
	 *
	 * @param borrowingBic the new borrowing bic
	 */
	public void setBorrowingBic(List<String> borrowingBic) {
		this.borrowingBic = borrowingBic;
	}

	/**
	 * Gets the ugs id.
	 *
	 * @return the ugs id
	 */
	public String getUgsId() {
		return this.ugsId;
	}

	/**
	 * Sets the ugs id.
	 *
	 * @param ugsId the new ugs id
	 */
	public void setUgsId(String ugsId) {
		this.ugsId = ugsId;
	}

	/**
	 * Gets the total loan.
	 *
	 * @return the total loan
	 */
	public double getTotalLoan() {
		// initialize the total loan
		double totalLoan = 0;

		// iterate over the loan list
		for (int i = 0; i < this.loanList.size(); i++) {
			// inrement the total loan with the value of the current loan
			totalLoan = totalLoan + this.loanList.get(i).getBICBorrowed();
		}
		return totalLoan;
	}

	/**
	 * Gets the all vis for partner.
	 *
	 * @return the all vis for partner
	 */
	public List<String> getAllVisForPartner() {
		return this.allVisForPartner;
	}

	/**
	 * Sets the all vis for partner.
	 *
	 * @param allVisForPartner the new all vis for partner
	 */
	public void setAllVisForPartner(List<String> allVisForPartner) {
		this.allVisForPartner = allVisForPartner;
	}

}
