/**
*
* MODULE FILE NAME:	HPExclusion.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		28 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 28 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class HPExclusion.
 *
 * @author francesca
 */
public class HPExclusion extends PlanningResources {

	/** The id. */
	private String hpExclusionListId;

	/** The look side initial. */
	private String startLookSide;

	/** The look side final. */
	private String stopLookSide;

	/** The activation flag. */
	private boolean isEnabled = true;

	/** The activation flag. */
	private boolean isPeriodic = true;

	/**
	 * Instantiates a new HP exclusion.
	 *
	 * @param hpExclusionListId the hp exclusion list id
	 * @param startTime         the start time
	 * @param startLookSide     the start look side
	 * @param endTime           the end time
	 * @param stopLookSide      the stop look side
	 * @param satelliteId       the satellite id
	 * @param isEnabled         the is enabled
	 * @param isPeriodic        the is periodic
	 */
	public HPExclusion(String hpExclusionListId, Date startTime, String startLookSide, Date endTime,
			String stopLookSide, String satelliteId, boolean isEnabled, boolean isPeriodic) {
		super();
		this.hpExclusionListId = hpExclusionListId;
		this.startLookSide = startLookSide;
		this.stopLookSide = stopLookSide;
		this.isEnabled = isEnabled;
		this.isPeriodic = isPeriodic;
		super.setStartTime(startTime);
		super.setEndTime(endTime);
		super.setSatelliteId(satelliteId);
	}

	/**
	 * method to Sring.
	 *
	 * @return the string with all the info about the HPExclusion
	 */
	@Override
	public String toString() {
		return "HPExclusion [hpExclusionListId=" + this.hpExclusionListId + ", startLookSide=" + this.startLookSide
				+ ", stopLookSide=" + this.stopLookSide + ", isEnabled=" + this.isEnabled + ", isPeriodic="
				+ this.isPeriodic + ", getStartTime()=" + getStartTime() + ", getEndTime()=" + getEndTime()
				+ ", getSatelliteId()=" + getSatelliteId() + "]";
	}

	/**
	 * Gets the hp exclusion list id.
	 *
	 * @return the hpExclusionListId
	 */
	public String getHpExclusionListId() {
		return this.hpExclusionListId;
	}

	/**
	 * Sets the hp exclusion list id.
	 *
	 * @param hpExclusionListId the hpExclusionListId to set
	 */
	public void setHpExclusionListId(String hpExclusionListId) {
		this.hpExclusionListId = hpExclusionListId;
	}

	/**
	 * Gets the start look side.
	 *
	 * @return the startLookSide
	 */
	public String getStartLookSide() {
		return this.startLookSide;
	}

	/**
	 * Sets the start look side.
	 *
	 * @param startLookSide the startLookSide to set
	 */
	public void setStartLookSide(String startLookSide) {
		this.startLookSide = startLookSide;
	}

	/**
	 *  
	 * get the satellite id.
	 *
	 * @return the satellite id of the hpExclusion
	 */
	@Override
	public String getSatelliteId() {
		return super.getSatelliteId();
	}

	/**
	 * Gets the stop look side.
	 *
	 * @return the stopLookSide
	 */
	public String getStopLookSide() {
		return this.stopLookSide;
	}

	/**
	 * Sets the stop look side.
	 *
	 * @param stopLookSide the stopLookSide to set
	 */
	public void setStopLookSide(String stopLookSide) {
		this.stopLookSide = stopLookSide;
	}

	/**
	 * Checks if is enabled.
	 *
	 * @return the isEnabled
	 */
	public boolean isEnabled() {
		return this.isEnabled;
	}

	/**
	 * Sets the enabled.
	 *
	 * @param isEnabled the isEnabled to set
	 */
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	/**
	 * Checks if is periodic.
	 *
	 * @return the isPeriodic
	 */
	public boolean isPeriodic() {
		return this.isPeriodic;
	}

	/**
	 * Sets the periodic.
	 *
	 * @param isPeriodic the isPeriodic to set
	 */
	public void setPeriodic(boolean isPeriodic) {
		this.isPeriodic = isPeriodic;
	}
}
