/**
*
* MODULE FILE NAME:	EclipseManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		18 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.Date;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.resources.Eclipse;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * The Class EclipseManagement.
 *
 * @author fpedrola
 */
public class EclipseManagement {

	/**
	 * Calculate amount of eclipse.
	 *
	 * @param startCheck the start check
	 * @param endCheck   the end check
	 * @param eclipse    the eclipse
	 * @return the long
	 */
	protected long calculateAmountOfEclipse(Date startCheck, Date endCheck, Eclipse eclipse) {
		// initialize the amount of orbit in eclipse to zero
		long singleEclipseOnOrbit = 0;
		// get the start time of the eclipse
		long eclipseStart = eclipse.getStartTime().getTime();

		// get the end time of the eclipse
		long eclipseEnd = eclipse.getEndTime().getTime();

		// is the eclipse is in overlap
		// with the interval
		if ((eclipseStart <= endCheck.getTime()) && (eclipseEnd >= startCheck.getTime())) {
			// period to check is totally included in eclipse
			if ((eclipseStart <= startCheck.getTime()) && (eclipseEnd >= endCheck.getTime())) {
				singleEclipseOnOrbit = endCheck.getTime() - startCheck.getTime();
			} else if (eclipseStart <= startCheck.getTime())
			// borderLine -> exceed in start
			{
				singleEclipseOnOrbit = eclipseEnd - startCheck.getTime();
			} else if (eclipseEnd >= endCheck.getTime())
			// borderLine -> exceed in end
			{
				singleEclipseOnOrbit = endCheck.getTime() - eclipseStart;
			} else
			// eclipse is totally included in period to check
			{
				singleEclipseOnOrbit = eclipseEnd - eclipseStart;
			}
		}
		return singleEclipseOnOrbit;
	}

	/**
	 * Gets the overlapped eclipse.
	 *
	 * @param acq         the acq
	 * @param startCheck  the start check
	 * @param endCheck    the end check
	 * @param allEclipses the all eclipses
	 * @return the overlapped eclipse
	 */
	protected Eclipse getOverlappedEclipse(Acquisition acq, Date startCheck, Date endCheck, List<Eclipse> allEclipses) {
		// initialize the eclipse
		Eclipse returnedEclipse = null;

		// iterate over all the eclipses
		for (int i = 0; i < allEclipses.size(); i++) {
			// get the start time of eclipse
			long eclipseStart = allEclipses.get(i).getStartTime().getTime();

			// get the end time of eclipse
			long eclipseEnd = allEclipses.get(i).getEndTime().getTime();

			// if eclipse is in overlap and is referred to the same satellite
			if ((eclipseStart <= endCheck.getTime()) && (eclipseEnd >= startCheck.getTime())
					&& allEclipses.get(i).getSatelliteId().equalsIgnoreCase(acq.getSatelliteId())) {
				// set the returned value
				returnedEclipse = allEclipses.get(i);

				// exit
				break;
			}
		}
		return returnedEclipse;
	}

	/**
	 * Check in interval.
	 *
	 * @param start          the start
	 * @param end            the end
	 * @param allEclipses    the all eclipses
	 * @param minTimeEclipse the min time eclipse
	 * @return true, if successful
	 */
	protected boolean checkInInterval(Date start, Date end, List<Eclipse> allEclipses, double minTimeEclipse) {
		long eclipsesInOrbit = 0;

		// initialize to false
		boolean isInEclipse = false;

		// iterate over the eclipses
		for (int i = 0; i < allEclipses.size(); i++) {
			// extract the i-esim eclipse
			Eclipse e = allEclipses.get(i);

			// invoke the function to compute the amount of eclipse in interval
			// and add to total
			eclipsesInOrbit = eclipsesInOrbit + calculateAmountOfEclipse(start, end, e);

			// if exceed the min time necessary to declare an orbit as affected
			// by eclipse
			if ((eclipsesInOrbit / 1000) >= minTimeEclipse) {
				// mark the orbit as in eclipse
				isInEclipse = true;
				break;
			}
		}
		return isInEclipse;
	}

	/**
	 * Check time eclipse.
	 *
	 * @param startCheck1    the start check 1
	 * @param endCheck1      the end check 1
	 * @param startCheck2    the start check 2
	 * @param endCheck2      the end check 2
	 * @param allEclipses    the all eclipses
	 * @param minTimeEclipse the min time eclipse
	 * @return true, if successful
	 */

	public boolean checkTimeEclipse(Date startCheck1, Date endCheck1, Date startCheck2, Date endCheck2,
			List<Eclipse> allEclipses, double minTimeEclipse) {
		// for each acquisition we will consider the time window in which the
		// acquisition has impact, that is the one that goes from the previous
		// orbit
		// (acquisitionEndTime - singleOrbitPeriod) to the next one
		// (acquisitionStartTime + singleOrbitPeriod), including the acquisition
		// itself
		boolean isInEclipse = false;

		// check if the first interval can be considered as in eclipse
		isInEclipse = checkInInterval(startCheck1, endCheck1, allEclipses, minTimeEclipse);

		// if is not eclipsed
		if (!isInEclipse) {
			// check if the second interval can be considered as in eclipse
			isInEclipse = checkInInterval(startCheck2, endCheck2, allEclipses, minTimeEclipse);
		}
		return isInEclipse;
	}

}
