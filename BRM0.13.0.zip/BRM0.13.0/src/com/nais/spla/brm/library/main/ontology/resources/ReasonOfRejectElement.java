/**
*
* MODULE FILE NAME:	ReasonOfRejectElement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		15 mag 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 15 mag 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resources;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.utils.ElementsInvolvedOnOrbit;

/**
 * The Class ReasonOfRejectElement.
 *
 * @author fpedrola
 */
@SuppressWarnings("serial")
public class ReasonOfRejectElement implements Serializable {

	/** The id. */
	private int id;

	/** The reason. */
	private ReasonOfReject reason;

	/** The description. */
	private String description = null;

	/** The elements involved. */
	private Map<Double, List<ElementsInvolvedOnOrbit>> elementsInvolved = null;

	/**
	 * Instantiates a new reason of reject element.
	 */
	public ReasonOfRejectElement() {
		super();
		this.elementsInvolved = new HashMap<>();
	}

	/**
	 * Instantiates a new reason of reject element.
	 *
	 * @param reason      the reason
	 * @param id          the id
	 * @param description the description
	 */
	public ReasonOfRejectElement(ReasonOfReject reason, int id, String description,
			Map<Double, List<ElementsInvolvedOnOrbit>> elementsInvolved) {
		super();
		this.id = id;
		this.reason = reason;
		this.description = description;
		if (elementsInvolved != null) {
			this.elementsInvolved = elementsInvolved;
		} else {
			this.elementsInvolved = new HashMap<>();
		}
	}

	/**
	 * Gets the reason.
	 *
	 * @return the reason
	 */
	public ReasonOfReject getReason() {
		return this.reason;
	}

	/**
	 * @param reason the reason to set
	 */
	public void setReason(ReasonOfReject reason) {
		this.reason = reason;
	}

	/**
	 * Adds the element involved.
	 *
	 * @param onOrbit                       the on orbit
	 * @param elementsInvolvedOnSingleOrbit the elements involved on single orbit
	 */
	public void addElementInvolved(double onOrbit, ElementsInvolvedOnOrbit elementsInvolvedOnSingleOrbit) {
		// if there is a valid list of elementsInvolved for the same orbit for
		// the same reason
		boolean containOrbit = this.elementsInvolved.containsKey(onOrbit);
		if (containOrbit) {
			// add the new element to the list
			this.elementsInvolved.get(onOrbit).add(elementsInvolvedOnSingleOrbit);
		}
		// there isn't a valid list of elementsInvolved
		else {
			// create a new one
			List<ElementsInvolvedOnOrbit> allElementsInvolved = new ArrayList<>();

			// add the new element to the just created list
			allElementsInvolved.add(elementsInvolvedOnSingleOrbit);

			// add to the list of elementsInvolved
			this.elementsInvolved.put(onOrbit, allElementsInvolved);
		}

	}

	/**
	 * Gets the elements involved.
	 *
	 * @return the elements involved
	 */
	public Map<Double, List<ElementsInvolvedOnOrbit>> getElementsInvolved() {
		return this.elementsInvolved;
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() {
		/**
		 * toString del metodo
		 */
		return "ReasonOfRejectElement [reason=" + this.reason + ", elementsInvolved=" + this.elementsInvolved + "]";
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

}
