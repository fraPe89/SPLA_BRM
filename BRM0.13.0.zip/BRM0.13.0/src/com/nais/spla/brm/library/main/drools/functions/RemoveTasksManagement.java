/**
*
* MODULE FILE NAME:	RemoveTasksManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		15 set 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 15 set 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.ManeuverUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

// TODO: Auto-generated Javadoc
/**
 * The Class RemoveTasksManagement.
 *
 * @author francesca
 */
public class RemoveTasksManagement {

	/** The download management. */
	DownloadManagement downloadManagement = new DownloadManagement();

	/** The ess management. */
	EssEnergyManagement essManagement = new EssEnergyManagement();

	/** The cmga management. */
	CMGAManeuverManagement cmgaManagement = new CMGAManeuverManagement();

	/** The left mng. */
	LeftAttitudeProfileManagement leftMng = new LeftAttitudeProfileManagement();

	/** The logger. */
	// get the logger
	Logger logger = DroolsParameters.getLogger();

	/**
	 * Instantiates a new removes the tasks management.
	 */
	public RemoveTasksManagement() {
		super();

	}

	/**
	 * Removes the download.
	 *
	 * @param resFunc       the res func
	 * @param droolsParams  the drools params
	 * @param acq           the acq
	 * @param isLmpOrVu     the is lmp or vu
	 * @param deletedByCsps the deleted by csps
	 * @param deletedTasks  the deleted tasks
	 */
	public void removeDownload(ResourceFunctions resFunc, DroolsParameters droolsParams, Acquisition acq,
			boolean isLmpOrVu, boolean deletedByCsps, List<Task> deletedTasks) {
		// get the download function related to sat as hashmap
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreemap = resFunc
				.getDwlFunctionAssociatedToSat(acq.getSatelliteId());

		// get the download function related to sat as list
		List<Download> allDwl = this.downloadManagement.getAllDwlFromTreeMap(acq.getSatelliteId(), droolsParams,
				dwlTreemap);

		// get the download priority associated to sat
		TreeMap<String, com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue> downloadPriority = resFunc
				.getDownloadPriorityQueueForSat(acq.getSatelliteId());

		// if the acq was in priority structure for the download
		if (downloadPriority.containsKey(this.downloadManagement.getPriorityKey(acq))) {
			// remove it from the priority
			downloadPriority.remove(this.downloadManagement.getPriorityKey(acq));
		}

		List<Download> downloadRelativeToAcq = new ArrayList<>();

		for (int i = 0; i < allDwl.size(); i++) {
			if (allDwl.get(i).getIdTask() != null) {
				if (allDwl.get(i).getIdTask().equalsIgnoreCase(acq.getIdTask())) {
					Download dwl = allDwl.get(i);
					downloadRelativeToAcq.add(dwl);
					this.essManagement.setCorrectMarkType(DroolsParameters.getLogger(), allDwl.get(i), isLmpOrVu,
							deletedByCsps, deletedTasks);
					allDwl.remove(i);
					i--;
				}
			}
		}

		this.logger.debug("REMOVE DWL ASSOCIATED " + downloadRelativeToAcq);
		if ((downloadRelativeToAcq != null) && !downloadRelativeToAcq.isEmpty()) {
			this.logger.debug("REMOVE FROM DOWNLOAD STRUCTURE ");

			this.downloadManagement.removeFromIDownloadStructure(downloadRelativeToAcq, droolsParams, dwlTreemap);
		}

	}

	/**
	 * Removes the pass through.
	 *
	 * @param acq             the acq
	 * @param pt              the pt
	 * @param droolsParams    the drools params
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param deletedByCsps   the deleted by csps
	 * @param isLmpOrVu       the is lmp or vu
	 * @param deletedTasks    the deleted tasks
	 * @param dwlTreemap      the dwl treemap
	 */
	public void removePassThrough(Acquisition acq, PassThrough pt, DroolsParameters droolsParams, String sessionId,
			int currentInstance, boolean deletedByCsps, boolean isLmpOrVu, List<Task> deletedTasks,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreemap) {
		// extract the ar id for the acq
		String sessionIdConcat = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);

		// if there is an associated passthrough
		if (pt != null) {
			// this.logger.debug("REMOVE_ACQ_RULE_ searching passthrough
			// associated with arid : " + arId);

			this.essManagement.setCorrectMarkType(DroolsParameters.getLogger(), pt, isLmpOrVu, deletedByCsps,
					deletedTasks);
			List<Task> removableElements = new ArrayList<Task>(Arrays.asList(pt));
			// this.logger.debug("found pt " + pt);
			this.downloadManagement.removeFromIDownloadStructurePt(removableElements, droolsParams, dwlTreemap);
			FactHandle factPt = kie.getFactHandle(pt);
			kie.delete(factPt);
		}
	}

	/**
	 * Removes the storage.
	 *
	 * @param acqId         the acq id
	 * @param resultSto     the result sto
	 * @param isLmpOrVu     the is lmp or vu
	 * @param deletedByCsps the deleted by csps
	 * @param deletedTasks  the deleted tasks
	 */
	public void removeStorage(String acqId, TreeMap<String, Storage> resultSto, boolean isLmpOrVu,
			boolean deletedByCsps, List<Task> deletedTasks) {
		Logger logger = DroolsParameters.getLogger();
		logger.debug("REMOVE_ACQ_RULE_ searching storage associated with acq  : " + acqId);
		if (resultSto.get(acqId) != null) {
			logger.debug("REMOVE_ACQ_RULE_ removing storage " + resultSto.get(acqId));
			this.essManagement.setCorrectMarkType(DroolsParameters.getLogger(), resultSto.get(acqId), isLmpOrVu,
					deletedByCsps, deletedTasks);
			resultSto.remove(acqId);
		}
	}

	/**
	 * Removes the maneuver.
	 *
	 * @param satId             the sat id
	 * @param associatedMan     the associated man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param sessionId         the session id
	 * @param currentInstance   the current instance
	 * @param deletedByCsps     the deleted by csps
	 * @param isLmpOrVu         the is lmp or vu
	 * @param deletedTasks      the deleted tasks
	 */
	public void removeManeuver(String satId, List<Maneuver> associatedMan, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions, String sessionId, int currentInstance, boolean deletedByCsps,
			boolean isLmpOrVu, List<Task> deletedTasks) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the current session
		String sessionIdConcat = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// get the kieSession
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);
		// extract the resource function
		ResourceFunctions resFunc = (ResourceFunctions) kie.getGlobal("resourceFunctions");

		// get the cmgAxis structure
		TreeMap<Long, CMGAxis> allCmgAxis = resFunc.getCmgaAxisAssociatedToSat(satId);

		// get the maneuvers structure
		TreeMap<Long, Maneuver> allMan = resFunc.getManeuverFunctionAssociatedToSat(satId);

		// get the ramps structure
		TreeMap<Long, RampCMGA> allRamps = resFunc.getRampFunctionAssociatedToSat(satId);

		// System.out.println(resFunc.getEssFunctionSat1());
		for (int k = 0; k < associatedMan.size(); k++) {
			// crate a new Manresourcs
			ManeuverResources manRes = new ManeuverResources();

			// get the k-esim man
			Maneuver man = associatedMan.get(k);
			String manId = man.getTotalId();
			// logger.debug("REMOVE_ACQ_RULE_ man total id :" + manId);

			List<Long> allCmgAxisToRemove = new ArrayList<>();
			// remove cmgAxis, if present
			for (Map.Entry<Long, CMGAxis> allCmgAxisInMap : allCmgAxis.entrySet()) {
				// het he i-esim cmgAxis
				CMGAxis cmgAxis = allCmgAxisInMap.getValue();

				// if the cmgAxis is related to the current man
				if (cmgAxis.getIdTask().startsWith("_" + manId) || cmgAxis.getIdTask().endsWith("_" + manId + "_")) {
					// add to the list that must be removed
					allCmgAxisToRemove.add(cmgAxis.getStartTime().getTime());

					// get the related fact handle
					FactHandle factAxis = kie.getFactHandle(cmgAxis);
					logger.debug("REMOVE_ACQ_RULE_ AXIS TO REMOVE : " + cmgAxis);

					DroolsUtils.removeFactIfExist(factAxis, kie);

				}

			}
			// if there are elements that must be removed
			if (allCmgAxisToRemove.size() > 0) {
				// iterate over them
				for (int i = 0; i < allCmgAxisToRemove.size(); i++) {
					// remove from the treemap
					allCmgAxis.remove(allCmgAxisToRemove.get(i));
				}
			}

			// set the correct taskmark
			this.essManagement.setCorrectMarkType(DroolsParameters.getLogger(), man, isLmpOrVu, deletedByCsps,
					deletedTasks);

			// if the manuver isn't a pitch one
			if ((man.getType().compareTo(ManeuverType.PitchCPS) != 0) || (man.isRemovePitch() == true)) {
				// remove from treemap
				allMan.remove(man.getStartTime().getTime());

				// get the related fact handle
				FactHandle factMan = kie.getFactHandle(man);

				// if there is a related man in Drools , remove it
				DroolsUtils.removeFactIfExist(factMan, kie);

				logger.debug("MAN TO REMOVE : man correctly deleted ." + man);

			}

			// if the manuver was a CMGA
			if (man.getActuator() == Actuator.CMGA) {
				// if the manuver isn't a pitch one
				if ((man.getType().compareTo(ManeuverType.PitchCPS) != 0) || (man.isRemovePitch() == true)) {
					// get the time for the ramp
					long timeForRump = (long) droolsParams.getMaxTaccForSat(satId);

					// invoke the algo for remove or reduce
					// the ramps related to the cmg
					manRes = this.cmgaManagement.removeOrReduceRump(droolsParams, man, allMan, allRamps, manRes,
							timeForRump);

					// if there are ramps to remove
					if (!manRes.getOldRumps().isEmpty()) {
						// iterate over them
						for (int i = 0; i < manRes.getOldRumps().size(); i++) {
							// extract the i-esim ramp
							RampCMGA ramp = manRes.getOldRumps().get(i);
							this.essManagement.setCorrectMarkType(DroolsParameters.getLogger(), ramp, isLmpOrVu,
									deletedByCsps, deletedTasks);

							// remove from treemAP
							allRamps.remove(ramp.getStartTime().getTime());
							FactHandle factRamp = kie.getFactHandle(ramp);

							// if there is a related man in Drools , remove it
							DroolsUtils.removeFactIfExist(factRamp, kie);

							allRamps.remove(manRes.getOldRumps().get(i).getStartTime().getTime());
							// logger.debug("REMOVE_ACQ_RULE_ retracting rump :"
							// + manRes.getOldRumps().get(i));
							manRes.getOldRumps().remove(i);
							i--;
						}
					}

					// if there are new ramps
					if (!manRes.getNewRumps().isEmpty()) {
						// iterate over them
						for (int i = 0; i < manRes.getNewRumps().size(); i++) {
							// lset the task mark
							manRes.getNewRumps().get(i).setTaskType(TaskType.RAMP);

							// insert in treemap
							allRamps.put(manRes.getNewRumps().get(i).getStartTime().getTime(),
									(manRes.getNewRumps().get(i)));
							kie.insert(manRes.getNewRumps().get(i));
							manRes.getNewRumps().remove(i);
							i--;
						}
					}
				}
			}
		}
	}

	/**
	 * Creates the repairing man between previous and next.
	 *
	 * @param acq               the acq
	 * @param sessionId         the session id
	 * @param currentInstance   the current instance
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @return the maneuver resources
	 * @throws Exception the exception
	 */
	public ManeuverResources createRepairingManBetweenPreviousAndNext(Acquisition acq, String sessionId,
			int currentInstance, DroolsParameters droolsParams, ResourceFunctions resourceFunctions) throws Exception {
		// get the structure with all the acquisitions related to sat
		TreeMap<Long, EnergyAssociatedToTask> essFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(acq.getSatelliteId());

		// get the structure with all the silents related to sat
		TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions
				.getSilentFunctionAssociatedToSat(acq.getSatelliteId());

		// get the structure with all the maneuvers related to sat
		TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(acq.getSatelliteId());

		// create a new instance of ManeuverManagement
		ManeuverManagement maneuverManagement = new ManeuverManagement();

		// create a new instance of ManeuverResources
		ManeuverResources manRes = new ManeuverResources();
		manRes.setPossible(true);
		manRes.setSatId(acq.getSatelliteId());

		// initialize a previous acq
		Acquisition prev = null;

		// initialize a next acq
		Acquisition next = null;

		// find prev acq id, if exists
		Object prevAcqId = essFunction.lowerKey(acq.getStartTime().getTime());

		// find next acq id, if exists
		Object nextAcqId = essFunction.higherKey(acq.getStartTime().getTime());

		// if prev acq id exists
		if (prevAcqId != null) {
			// extract the relative acq
			prev = (Acquisition) essFunction.get(prevAcqId).getTask();
		}

		// if next acq id exists
		if (nextAcqId != null) {
			// extract the relative acq
			next = (Acquisition) essFunction.get(nextAcqId).getTask();
		}

		// if exists both (prev and next)
		if ((prev != null) && (next != null)) {
			// get the maneuver that has the next acq as second member (that
			// arrive to next)
			Maneuver manRelatedToNext = ManeuverUtils.getManWithSecondMemberId(
					resourceFunctions.getManeuverFunctionAssociatedToSat(next.getSatelliteId()), next.getIdTask());

			// get the maneuver that has the prev acq as first member (that
			// starts from prev)
			Maneuver manRelatedToPrev = ManeuverUtils.getManWithFirstMemberId(
					resourceFunctions.getManeuverFunctionAssociatedToSat(prev.getSatelliteId()), prev.getIdTask());

			// if prev and next have OPPOSITE look side
			if (!prev.getLookSide().equalsIgnoreCase(next.getLookSide())) {
				// create a maneuver between them
				manRes = maneuverManagement.createManBetweenAcq(
						droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties().isStartWithRw(), prev,
						next, manRes, droolsParams, resourceFunctions, 0, true, true);

				// if there was a previous man for next
				if (manRelatedToNext != null) {
					// add it to the list of man that must be removed
					manRes.getOldMans().add(manRelatedToNext);
				}

				// if there was a previous man for prev
				if (manRelatedToPrev != null) {
					// add it to the list of man that must be removed
					manRes.getOldMans().add(manRelatedToPrev);
				}

				// insert the new manResources
				// kie.insert(manRes);
			}

			// if prev and next have SAME look side left
			else if (prev.getLookSide().equalsIgnoreCase("left")) {
				// compute gap between previous and next
				long gapBetweenLeftAndLeft = next.getStartTime().getTime() - prev.getEndTime().getTime();

				// if it is more than max time between two left
				if ((gapBetweenLeftAndLeft / 60000) > droolsParams.getSatWithId(acq.getSatelliteId())
						.getSatelliteProperties().getMaxTimeBetweenTwoLeftAcquisitions()) {
					// remove reasons of reject
					prev.getReasonOfReject().clear();
					prev.getReasonOfReject().clear();

					// TODO : testare caso stronzo du treno di left, rimuovo
					// centrale e non ho manovre per tornare in right -> che
					// succede?
					// create a contermaneuver
					manRes = maneuverManagement.createContermaneuver(prev, next, droolsParams, resourceFunctions,
							manRes);

					// if there was a previous man for next
					if (manRelatedToNext != null) {
						// add it to the list of man that must be removed
						manRes.getOldMans().add(manRelatedToNext);
					}

					// if there was a previous man for prev
					if (manRelatedToPrev != null) {
						// add it to the list of man that must be removed
						manRes.getOldMans().add(manRelatedToPrev);
					}
					// kie.insert(manRes);
				}
			} else {

				// if there was a previous man for prev
				if (manRelatedToPrev != null) {
					// add it to the list of man that must be removed
					manRes.getOldMans().add(manRelatedToPrev);
				}
				// if there was a previous man for next
				if (manRelatedToNext != null) {
					// add it to the list of man that must be removed
					manRes.getOldMans().add(manRelatedToNext);
				}

			}
		} else {
			// there is ONLY a next acq
			if (next != null) {
				Maneuver manRelatedToNext = ManeuverUtils.getManWithSecondMemberId(
						resourceFunctions.getManeuverFunctionAssociatedToSat(next.getSatelliteId()), next.getIdTask());

				if (!next.getLookSide()
						.equalsIgnoreCase(droolsParams.getSatWithId(acq.getSatelliteId()).getInitialLookSide())) {
					long initialMh = droolsParams.getCurrentMH().getStart().getTime();
					manRes = maneuverManagement.createManBetweenAcqAndInterval(
							droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							initialMh, next, manRes, droolsParams, resourceFunctions, false, 0);

					if (manRelatedToNext != null) {
						manRes.getOldMans().add(manRelatedToNext);
					}
					// kie.insert(manRes);
				} else if (next.getLookSide().equalsIgnoreCase("left")) {
					long initialMh = droolsParams.getCurrentMH().getStart().getTime();
					manRes = maneuverManagement.createManBetweenAcqAndInterval(
							droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							initialMh, next, manRes, droolsParams, resourceFunctions, false, 0);
					if (manRelatedToNext != null) {
						manRes.getOldMans().add(manRelatedToNext);
					}
					// kie.insert(manRes);
				}
			}

			// there is ONLY a prev acq
			if ((prev != null) && prev.getLookSide().equalsIgnoreCase("left")) {
				Maneuver manRelatedToPrev = ManeuverUtils.getManWithFirstMemberId(
						resourceFunctions.getManeuverFunctionAssociatedToSat(prev.getSatelliteId()), prev.getIdTask());

				boolean profileAccepted = this.leftMng.computeMaxTimeLeftAlgo(prev, droolsParams, allMan, essFunction,
						silentFunction, "REPAIRING MAN");
				if (!profileAccepted) {
					long finalMh = droolsParams.getCurrentMH().getStop().getTime();
					manRes = maneuverManagement.createManBetweenAcqAndInterval(
							droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties().isStartWithRw(),
							finalMh, prev, manRes, droolsParams, resourceFunctions, false, 0);
					if (manRelatedToPrev != null) {
						manRes.getOldMans().add(manRelatedToPrev);
					}
					// kie.insert(manRes);
				}
			}
		}
		return manRes;
	}
}
