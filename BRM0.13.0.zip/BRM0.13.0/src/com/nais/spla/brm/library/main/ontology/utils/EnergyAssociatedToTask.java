/**
*
* MODULE FILE NAME:	EnergyAssociatedToTask.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		08 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 08 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.utils;

import java.io.Serializable;

import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class EnergyAssociatedToTask.
 *
 * @author fpedrola
 */
@SuppressWarnings("serial")
public class EnergyAssociatedToTask implements Serializable {

	/** The task. */
	private Task task;

	/** The ess value. */
	private double essValue;

	/**
	 * @param task the task to set
	 */
	public void setTask(Task task) {
		this.task = task;
	}

	/**
	 * Instantiates a new energy associated to task.
	 *
	 * @param task     the task
	 * @param essValue the ess value
	 */
	public EnergyAssociatedToTask(Task task, double essValue) {
		super();

		// set the task
		this.task = task;

		// set the associated ess energy
		this.essValue = essValue;
	}

	/**
	 * Instantiates a new energy associated to task.
	 */
	public EnergyAssociatedToTask() {
		super();
	}

	/**
	 * Gets the ess value.
	 *
	 * @return the essValue
	 */
	public double getEssValue() {
		return this.essValue;
	}

	/**
	 * Gets the task.
	 *
	 * @return the task
	 */
	public Task getTask() {
		return this.task;
	}

	/**
	 * Sets the ess value.
	 *
	 * @param essValue the essValue to set
	 */
	public void setEssValue(double essValue) {
		this.essValue = essValue;
	}

	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "EnergyAssociatedToTask [task=" + this.task + ", essValue=" + this.essValue + "]";
	}

}
