/**
*
* MODULE FILE NAME:	PAW.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		27 feb 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 27 feb 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;

/**
 * The Class PAW.
 *
 * @author fpedrola
 */
public class PAW extends PlanningResources {

	/** The id. */
	private long activityId;

	/** The satellite id. */
	private String satelliteId;

	/** The type. */
	private PAWType type;

	/**
	 * Instantiates a new paw.
	 *
	 * @param activityId  the activity id
	 * @param satelliteId the satellite id
	 * @param startTime   the start time
	 * @param endTime     the end time
	 */
	public PAW(long activityId, String satelliteId, Date startTime, Date endTime) {
		super();
		this.activityId = activityId;
		this.satelliteId = satelliteId;
		super.setStartTime(startTime);
		super.setEndTime(endTime);
	}

	/**
	 * Gets the end time.
	 *
	 * @return the end time
	 */
	@Override
	public Date getEndTime() {
		return super.getEndTime();
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	@Override
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Gets the start time.
	 *
	 * @return the start time
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/**
	 * Gets the activity id.
	 *
	 * @return the activity id
	 */
	public long getActivityId() {
		return this.activityId;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public PAWType getType() {
		return this.type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the type to set
	 */
	public void setType(PAWType type) {
		this.type = type;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the paw
	 */
	@Override
	public String toString() {
		return "PAW [activityId=" + this.activityId + ", satelliteId=" + this.satelliteId + ", type=" + this.type
				+ ", getSatelliteId()=" + getSatelliteId() + ", getStartTime()=" + getStartTime() + ", getEndTime()="
				+ getEndTime() + "]";
	}

}
