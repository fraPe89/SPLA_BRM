/**
*
* MODULE FILE NAME:	SessionType.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		28 ago 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 28 ago 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum SessionType.
 *
 * @author francesca
 */
public enum SessionType {

	/** The premium. */
	premium,

	/** The routine. */
	routine,

	/** The urgent. */
	urgent
}
