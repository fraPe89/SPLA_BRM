/**
 *
 * MODULE FILE NAME: ComplexPdht.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.Map;

import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;

// TODO: Auto-generated Javadoc
/**
 * The Class ComplexPdht.
 */
public class ComplexPdht implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The pdht. */
	private PDHT pdht;

	/** The old mem mod. */
	private Map<MemoryModule, Long> oldMemMod;

	/**
	 * Instantiates a new complex pdht.
	 *
	 * @param pdht the pdht
	 */
	public ComplexPdht(PDHT pdht) {
		super();
		this.pdht = pdht;
		this.oldMemMod = null;
	}

	/**
	 * Gets the pdht.
	 *
	 * @return the pdht
	 */
	public PDHT getPdht() {
		return this.pdht;
	}
	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "ComplexPdht [pdht=" + this.pdht + ", oldMemMod=" + this.oldMemMod + "]";
	}

}
