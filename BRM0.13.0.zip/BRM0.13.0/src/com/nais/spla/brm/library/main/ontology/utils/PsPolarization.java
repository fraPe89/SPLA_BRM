/**
*
* MODULE FILE NAME:	PsPolarization.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		27 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 27 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.utils;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;

/**
 * The Class PsPolarization.
 *
 * @author fpedrola
 */
public class PsPolarization {

	/** The sector used for ps. */
	private long sectorUsedForPs;

	/** The polarization. */
	// private int polarization;
	private Polarization pol;

	/**
	 * Instantiates a new ps polarization.
	 *
	 * @param sectorUsedForPs the sector used for ps
	 * @param pol             the pol
	 */
	public PsPolarization(long sectorUsedForPs, Polarization pol) {
		super();

		// set the sectors used for the packet store
		this.sectorUsedForPs = sectorUsedForPs;

		// set the polarization of the packet store
		this.pol = pol;
	}

	/**
	 * Instantiates a new ps polarization.
	 */
	public PsPolarization() {
		super();
	}

	/**
	 * Sets the sector used for ps.
	 *
	 * @param sectorUsedForPs the sectorUsedForPs to set
	 */
	public void setSectorUsedForPs(long sectorUsedForPs) {
		this.sectorUsedForPs = sectorUsedForPs;
	}

	/**
	 * Gets the sector used for ps.
	 *
	 * @return the sector used for ps
	 */
	public long getSectorUsedForPs() {
		return this.sectorUsedForPs;
	}

	/**
	 * Gets the pol.
	 *
	 * @return the pol
	 */
	public Polarization getPol() {
		return this.pol;
	}

	/**
	 * Sets the pol.
	 *
	 * @param pol the new pol
	 */
	public void setPol(Polarization pol) {
		this.pol = pol;
	}

}
