/**
*
* MODULE FILE NAME: SatelliteProperties.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

// TODO: Auto-generated Javadoc
/**
 * The Class SatelliteProperties.
 */
public class SatelliteProperties {

	/** The sat id. */
	private String satId = null;

	/** The min time download delay. */
	private int minTimeDownloadDelay = 0;

	/** The minimum time between storage and acq. */
	private int minimumTimeBetweenStorageAndAcq = 0;

	/** The minimum distance between tasks. */
	private int minimumDistanceBetweenTasks = 0;

	// This field indicates if the first choice of maneuver is rw (true) or cmga
	/** The start with rw. */
	// (false).
	private boolean startWithRw = true;

	/** The max number daily peak. */
	// The max number of daily peaks.
	private int maxNumberDailyPeak = 0;

	/** The period before end of mh for smoothing unranked. */
	private double periodBeforeEndOfMhForSmoothingUnranked = 0;

	/** The paw exclusion list. */
	/* the list of Type of Paw that don't need storeAux */
	private List<PAWType> pawExclusionList = new ArrayList<>();

	/** The max available buffer size gps. */
	private int maxAvailableBufferSizeGps = 0;

	/** The max available buffer size pt. */
	private int maxAvailableBufferSizePt = 0;

	/** The number of sectors shift pt. */
	private int numberOfSectorsShiftPt = 0;

	/** The use extra sectors pt. */
	private int useExtraSectorsPt = 0;

	/**
	 * #max number of theatre acquisitions for orbit (orbits are shown in the
	 * variable checkOnNumberOfOrbits, that means that for 1 orbit are allowed only
	 * 2 theatre, for 3 orbits 6...)
	 **/
	private int maxTheatreOnADay = 0;

	/**
	 * coefficient that means that the silent related to acq is included in the
	 * formula (1) or not (0).
	 */
	private int includeSilentInLeftAttitudeFormulaC1 = 0;

	/** The all checks on orbits. */
	private Map<Double, ResourceMaxValue> allChecksOnOrbits = null;

	/** The tranquillization time for maneuvers of type roll. */
	private double tranquillizationTimeRoll = 0;

	/** The tranquillization time for maneuvers of type pitch. */
	private double tranquillizationTimePitch = 0;

	/**
	 * this is the max value allowed for a single peak orbit. If in an orbit period
	 * there are a value of bic upper than this configurable value, #the acquisition
	 * that cause this overload must be rejected.
	 **/
	private int upperBoundPeakOrbit = 0;

	/**
	 * when the total bic over an orbit exceeds this value, the orbit is considered
	 * as peak orbit (peak orbit starts).
	 */
	private int lowerBoundPeakOrbit = 0;

	/** The percent man counted as time in left. */
	private double percentManLeftC2 = 0;

	/**
	 * this value is used to determine the max number of packet stores that can be
	 * simultaneously stored on the pdht.
	 */
	private int maxNumberOfPacketStore = 0;

	/**
	 * this value is used to determine the continuative time over an orbit during
	 * which the PDHT can remain in active state (expressed in minutes).
	 */
	private double maxContinuativeTimePDHT = 0;

	/**
	 * this value is used to determine the cumulative time over an orbit during
	 * which the PDHT can remain in active state (expressed in minutes).
	 */
	private double maxCumulativeTimePDHT = 0;

	/**
	 * time that must be waited between the rump up/down and the CMGA maneuver
	 * (expressed in seconds).
	 */
	private double waitTimeBetweenRampAndCmg = 0;

	/**
	 * this value is used to determine the max number of switches that can be
	 * performed from PDHT during a mission horizon.
	 */
	private int maxNumberOfSwitchesPDHT = 0;

	/**
	 * expressed in seconds, this value indicates the minimum configurable number of
	 * seconds between two manoeuvres of different type performed by the CMGA(pitch
	 * and roll).
	 */
	private double axesReconfigurationTime = 0;

	/**
	 * expressed in minutes, it indicates the minimum time to stay in right in case
	 * of mismatch with the values of the left attitude table.
	 */
	private double defaultMinTimeRight = 0;

	/**
	 * expressed in ess , it indicate the max value of ess that can be used in a
	 * single left period.
	 */
	private double maxEssInLeftPeriod = 0;

	/**
	 * expressed in minutes , it indicates the max time in which the satellite can
	 * remain in left attitude mode (continuative).
	 */
	private double maxTimeInAllTheLeftPeriod = 0;

	/**
	 * expressed in minutes, it indicates the max time which may occour between two
	 * left acquisitions. If there is more time, a contermaneuver must be performed.
	 **/
	private double maxTimeBetweenTwoLeftAcquisitions = 0;

	/**
	 * percentage that indicate the minimum percentuage of storage to let it be
	 * downloaded on the current visibility.
	 */
	private double minPercDownloadOnVis = 0;

	/** data rate of a store allocated on PDHT, expressed in mbps *. */
	private double wizardLinkDataRate = 0;

	/** dimension of a single sector of the visibility (expressed in MB). */
	private int singleSectorDimension = 0;

	/**
	 * if 1, the rule to retract elements for the logic of shutter control is
	 * activated.
	 */
	private int activateUrgentRule = 0;

	/**
	 * data rate used to compute the capacity of the Visibility. Expressed in mbps
	 **/
	private double downlinkPerChannel = 0;

	/**
	 * this value is used to determine how much all resources are decreased when an
	 * eclipse occurs (percentage).
	 */
	private double maxPercEclipseAvailable = 0;

	/**
	 * configurable value that express the max energy that can be used in the
	 * effective eclipse period (percentage).
	 */
	private double percentEffectiveEclipse = 0;

	/**
	 * configurable time margin before and after eclipse that must be considered in
	 * eclipse (expressed in seconds).
	 */
	private double timeBeforeAndAfterEclipse = 0;

	/** The silent factor. */
	private double silentFactor = 0;

	/** The all vis for sat. */
	private List<Visibility> allVisForSat = null;

	/**
	 * Gets the sat id.
	 *
	 * @return the sat id
	 */
	public String getSatId() {
		return this.satId;
	}

	/**
	 * Sets the sat id.
	 *
	 * @param satId the new sat id
	 */
	public void setSatId(String satId) {
		this.satId = satId;
	}

	/**
	 * Gets the paw exclusion list.
	 *
	 * @return the pawExclusionList
	 */
	public List<PAWType> getPawExclusionList() {
		return this.pawExclusionList;
	}

	/**
	 * Sets the paw exclusion list.
	 *
	 * @param pawExclusionList the pawExclusionList to set
	 */
	public void setPawExclusionList(List<PAWType> pawExclusionList) {
		this.pawExclusionList = pawExclusionList;
	}

	/**
	 * Checks if is start with rw.
	 *
	 * @return true, if is start with rw
	 */
	public boolean isStartWithRw() {
		return this.startWithRw;
	}

	/**
	 * Sets the start with rw.
	 *
	 * @param startWithRw the new start with rw
	 */
	public void setStartWithRw(boolean startWithRw) {
		this.startWithRw = startWithRw;
	}

	/**
	 * Gets the max number daily peak.
	 *
	 * @return the max number daily peak
	 */
	public int getMaxNumberDailyPeak() {
		return this.maxNumberDailyPeak;
	}

	/**
	 * Sets the max number daily peak.
	 *
	 * @param maxNumberDailyPeak the new max number daily peak
	 */
	public void setMaxNumberDailyPeak(int maxNumberDailyPeak) {
		this.maxNumberDailyPeak = maxNumberDailyPeak;
	}

	/**
	 * Gets the default min time right.
	 *
	 * @return the default min time right
	 */
	public double getDefaultMinTimeRight() {
		return this.defaultMinTimeRight;
	}

	/**
	 * Sets the default min time right.
	 *
	 * @param defaultMinTimeRight the new default min time right
	 */
	public void setDefaultMinTimeRight(double defaultMinTimeRight) {
		this.defaultMinTimeRight = defaultMinTimeRight;
	}

	/**
	 * Gets the max ess in left period.
	 *
	 * @return the max ess in left period
	 */
	public double getMaxEssInLeftPeriod() {
		return this.maxEssInLeftPeriod;
	}

	/**
	 * Sets the max ess in left period.
	 *
	 * @param maxEssInLeftPeriod the new max ess in left period
	 */
	public void setMaxEssInLeftPeriod(double maxEssInLeftPeriod) {
		this.maxEssInLeftPeriod = maxEssInLeftPeriod;
	}

	/**
	 * Gets the min perc download on vis.
	 *
	 * @return the min perc download on vis
	 */
	public double getMinPercDownloadOnVis() {
		return this.minPercDownloadOnVis;
	}

	/**
	 * Sets the min perc download on vis.
	 *
	 * @param minPercDownloadOnVis the new min perc download on vis
	 */
	public void setMinPercDownloadOnVis(double minPercDownloadOnVis) {
		this.minPercDownloadOnVis = minPercDownloadOnVis;
	}

	/**
	 * Gets the wizard link data rate.
	 *
	 * @return the wizard link data rate
	 */
	public double getWizardLinkDataRate() {
		return this.wizardLinkDataRate;
	}

	/**
	 * Sets the wizard link data rate.
	 *
	 * @param wizardLinkDataRate the new wizard link data rate
	 */
	public void setWizardLinkDataRate(double wizardLinkDataRate) {
		this.wizardLinkDataRate = wizardLinkDataRate;
	}

	/**
	 * Gets the single sector dimension.
	 *
	 * @return the single sector dimension
	 */
	public int getSingleSectorDimension() {
		return this.singleSectorDimension;
	}

	/**
	 * Sets the single sector dimension.
	 *
	 * @param singleSectorDimension the new single sector dimension
	 */
	public void setSingleSectorDimension(int singleSectorDimension) {
		this.singleSectorDimension = singleSectorDimension;
	}

	/**
	 * Gets the downlink per channel.
	 *
	 * @return the downlink per channel
	 */
	public double getDownlinkPerChannel() {
		return this.downlinkPerChannel;
	}

	/**
	 * Sets the downlink per channel.
	 *
	 * @param downlinkPerChannel the new downlink per channel
	 */
	public void setDownlinkPerChannel(double downlinkPerChannel) {
		this.downlinkPerChannel = downlinkPerChannel;
	}

	/**
	 * Gets the all checks on orbits.
	 *
	 * @return the all checks on orbits
	 */
	public Map<Double, ResourceMaxValue> getAllChecksOnOrbits() {
		return this.allChecksOnOrbits;
	}

	/**
	 * Sets the all checks on orbits.
	 *
	 * @param allChecksOnOrbits the all checks on orbits
	 */
	public void setAllChecksOnOrbits(Map<Double, ResourceMaxValue> allChecksOnOrbits) {
		this.allChecksOnOrbits = allChecksOnOrbits;
		// System.out.println("ALL check on orbits : " +
		// this.allChecksOnOrbits);
	}

	/**
	 * Instantiates a new satellite properties.
	 */
	public SatelliteProperties() {
		super();
		this.allChecksOnOrbits = new HashMap<>();
		this.allVisForSat = new ArrayList<>();
	}

	/**
	 * Gets the max perc eclipse available.
	 *
	 * @return the max perc eclipse available
	 */
	public double getMaxPercEclipseAvailable() {
		return this.maxPercEclipseAvailable;
	}

	/**
	 * Sets the max perc eclipse available.
	 *
	 * @param maxPercEclipseAvailable the new max perc eclipse available
	 */
	public void setMaxPercEclipseAvailable(double maxPercEclipseAvailable) {
		this.maxPercEclipseAvailable = maxPercEclipseAvailable;
	}

	/**
	 * Gets the silent factor.
	 *
	 * @return the silent factor
	 */
	public double getSilentFactor() {
		return this.silentFactor;
	}

	/**
	 * Sets the silent factor.
	 *
	 * @param silentFactor the new silent factor
	 */
	public void setSilentFactor(double silentFactor) {
		this.silentFactor = silentFactor;
	}

	/**
	 * Gets the all vis for sat.
	 *
	 * @return the allVisForSat
	 */
	public List<Visibility> getAllVisForSat() {
		return this.allVisForSat;
	}

	/**
	 * Sets the all vis for sat.
	 *
	 * @param allVisForSat the allVisForSat to set
	 */
	public void setAllVisForSat(List<Visibility> allVisForSat) {
		this.allVisForSat = allVisForSat;
	}

	/**
	 * Gets the upper bound peak orbit.
	 *
	 * @return the upperBoundPeakOrbit
	 */
	public int getUpperBoundPeakOrbit() {
		return this.upperBoundPeakOrbit;
	}

	/**
	 * Sets the upper bound peak orbit.
	 *
	 * @param upperBoundPeakOrbit the upperBoundPeakOrbit to set
	 */
	public void setUpperBoundPeakOrbit(int upperBoundPeakOrbit) {
		this.upperBoundPeakOrbit = upperBoundPeakOrbit;
	}

	/**
	 * Gets the max theatre on A day.
	 *
	 * @return the maxTheatreOnADay
	 */
	public int getMaxTheatreOnADay() {
		return this.maxTheatreOnADay;
	}

	/**
	 * Sets the max theatre on A day.
	 *
	 * @param maxTheatreOnADay the maxTheatreOnADay to set
	 */
	public void setMaxTheatreOnADay(int maxTheatreOnADay) {
		this.maxTheatreOnADay = maxTheatreOnADay;
	}

	/**
	 * Gets the include silent in left attitude formula C 1.
	 *
	 * @return the includeSilentInLeftAttitudeFormulaC1
	 */
	public int getIncludeSilentInLeftAttitudeFormulaC1() {
		return this.includeSilentInLeftAttitudeFormulaC1;
	}

	/**
	 * Sets the include silent in left attitude formula C 1.
	 *
	 * @param includeSilentInLeftAttitudeFormulaC1 the
	 *                                             includeSilentInLeftAttitudeFormulaC1
	 *                                             to set
	 */
	public void setIncludeSilentInLeftAttitudeFormulaC1(int includeSilentInLeftAttitudeFormulaC1) {
		this.includeSilentInLeftAttitudeFormulaC1 = includeSilentInLeftAttitudeFormulaC1;
	}

	/**
	 * Gets the percent man left C 2.
	 *
	 * @return the percentManLeftC2
	 */
	public double getPercentManLeftC2() {
		return this.percentManLeftC2;
	}

	/**
	 * Sets the percent man left C 2.
	 *
	 * @param percentManLeftC2 the percentManLeftC2 to set
	 */
	public void setPercentManLeftC2(double percentManLeftC2) {
		this.percentManLeftC2 = percentManLeftC2;
	}

	/**
	 * Gets the max number of packet store.
	 *
	 * @return the maxNumberOfPacketStore
	 */
	public int getMaxNumberOfPacketStore() {
		return this.maxNumberOfPacketStore;
	}

	/**
	 * Sets the max number of packet store.
	 *
	 * @param maxNumberOfPacketStore the maxNumberOfPacketStore to set
	 */
	public void setMaxNumberOfPacketStore(int maxNumberOfPacketStore) {
		this.maxNumberOfPacketStore = maxNumberOfPacketStore;
	}

	/**
	 * Gets the max continuative time PDHT.
	 *
	 * @return the maxContinuativeTimePDHT
	 */
	public double getMaxContinuativeTimePDHT() {
		return this.maxContinuativeTimePDHT;
	}

	/**
	 * Sets the max continuative time PDHT.
	 *
	 * @param maxContinuativeTimePDHT the maxContinuativeTimePDHT to set
	 */
	public void setMaxContinuativeTimePDHT(double maxContinuativeTimePDHT) {
		this.maxContinuativeTimePDHT = maxContinuativeTimePDHT;
	}

	/**
	 * Gets the max cumulative time PDHT.
	 *
	 * @return the maxCumulativeTimePDHT
	 */
	public double getMaxCumulativeTimePDHT() {
		return this.maxCumulativeTimePDHT;
	}

	/**
	 * Sets the max cumulative time PDHT.
	 *
	 * @param maxCumulativeTimePDHT the maxCumulativeTimePDHT to set
	 */
	public void setMaxCumulativeTimePDHT(double maxCumulativeTimePDHT) {
		this.maxCumulativeTimePDHT = maxCumulativeTimePDHT;
	}

	/**
	 * Gets the max number of switches PDHT.
	 *
	 * @return the maxNumberOfSwitchesPDHT
	 */
	public int getMaxNumberOfSwitchesPDHT() {
		return this.maxNumberOfSwitchesPDHT;
	}

	/**
	 * Sets the max number of switches PDHT.
	 *
	 * @param maxNumberOfSwitchesPDHT the maxNumberOfSwitchesPDHT to set
	 */
	public void setMaxNumberOfSwitchesPDHT(int maxNumberOfSwitchesPDHT) {
		this.maxNumberOfSwitchesPDHT = maxNumberOfSwitchesPDHT;
	}

	/**
	 * Gets the axes reconfiguration time.
	 *
	 * @return the axesReconfigurationTime
	 */
	public double getAxesReconfigurationTime() {
		return this.axesReconfigurationTime;
	}

	/**
	 * Sets the axes reconfiguration time.
	 *
	 * @param axesReconfigurationTime the axesReconfigurationTime to set
	 */
	public void setAxesReconfigurationTime(double axesReconfigurationTime) {
		this.axesReconfigurationTime = axesReconfigurationTime;
	}

	/**
	 * Gets the max time in all the left period.
	 *
	 * @return the maxTimeInAllTheLeftPeriod
	 */
	public double getMaxTimeInAllTheLeftPeriod() {
		return this.maxTimeInAllTheLeftPeriod;
	}

	/**
	 * Sets the max time in all the left period.
	 *
	 * @param maxTimeInAllTheLeftPeriod the maxTimeInAllTheLeftPeriod to set
	 */
	public void setMaxTimeInAllTheLeftPeriod(double maxTimeInAllTheLeftPeriod) {
		this.maxTimeInAllTheLeftPeriod = maxTimeInAllTheLeftPeriod;
	}

	/**
	 * Gets the max time between two left acquisitions.
	 *
	 * @return the maxTimeBetweenTwoLeftAcquisitions
	 */
	public double getMaxTimeBetweenTwoLeftAcquisitions() {
		return this.maxTimeBetweenTwoLeftAcquisitions;
	}

	/**
	 * Sets the max time between two left acquisitions.
	 *
	 * @param maxTimeBetweenTwoLeftAcquisitions the
	 *                                          maxTimeBetweenTwoLeftAcquisitions to
	 *                                          set
	 */
	public void setMaxTimeBetweenTwoLeftAcquisitions(double maxTimeBetweenTwoLeftAcquisitions) {
		this.maxTimeBetweenTwoLeftAcquisitions = maxTimeBetweenTwoLeftAcquisitions;
	}

	/**
	 * Gets the activate urgent rule.
	 *
	 * @return the activateUrgentRule
	 */
	public int getActivateUrgentRule() {
		return this.activateUrgentRule;
	}

	/**
	 * Sets the activate urgent rule.
	 *
	 * @param activateUrgentRule the activateUrgentRule to set
	 */
	public void setActivateUrgentRule(int activateUrgentRule) {
		this.activateUrgentRule = activateUrgentRule;
	}

	/**
	 * Gets the percent effective eclipse.
	 *
	 * @return the percentEffectiveEclipse
	 */
	public double getPercentEffectiveEclipse() {
		return this.percentEffectiveEclipse;
	}

	/**
	 * Sets the percent effective eclipse.
	 *
	 * @param percentEffectiveEclipse the percentEffectiveEclipse to set
	 */
	public void setPercentEffectiveEclipse(double percentEffectiveEclipse) {
		this.percentEffectiveEclipse = percentEffectiveEclipse;
	}

	/**
	 * Gets the time before and after eclipse.
	 *
	 * @return the timeBeforeAndAfterEclipse
	 */
	public double getTimeBeforeAndAfterEclipse() {
		return this.timeBeforeAndAfterEclipse;
	}

	/**
	 * Sets the time before and after eclipse.
	 *
	 * @param timeBeforeAndAfterEclipse the timeBeforeAndAfterEclipse to set
	 */
	public void setTimeBeforeAndAfterEclipse(double timeBeforeAndAfterEclipse) {
		this.timeBeforeAndAfterEclipse = timeBeforeAndAfterEclipse;
	}

	/**
	 * Gets the lower bound peak orbit.
	 *
	 * @return the lowerBoundPeakOrbit
	 */
	public int getLowerBoundPeakOrbit() {
		return this.lowerBoundPeakOrbit;
	}

	/**
	 * Sets the lower bound peak orbit.
	 *
	 * @param lowerBoundPeakOrbit the lowerBoundPeakOrbit to set
	 */
	public void setLowerBoundPeakOrbit(int lowerBoundPeakOrbit) {
		this.lowerBoundPeakOrbit = lowerBoundPeakOrbit;
	}

	/**
	 * Gets the wait time between ramp and cmg.
	 *
	 * @return the waitTimeBetweenRampAndCmg
	 */
	public double getWaitTimeBetweenRampAndCmg() {
		return this.waitTimeBetweenRampAndCmg;
	}

	/**
	 * Sets the wait time between ramp and cmg.
	 *
	 * @param waitTimeBetweenRampAndCmg the waitTimeBetweenRampAndCmg to set
	 */
	public void setWaitTimeBetweenRampAndCmg(double waitTimeBetweenRampAndCmg) {
		this.waitTimeBetweenRampAndCmg = waitTimeBetweenRampAndCmg;
	}

	/**
	 * Gets the period before end of mh for smoothing unranked.
	 *
	 * @return the periodBeforeEndOfMhForSmoothingUnranked
	 */
	public double getPeriodBeforeEndOfMhForSmoothingUnranked() {
		return this.periodBeforeEndOfMhForSmoothingUnranked;
	}

	/**
	 * Sets the period before end of mh for smoothing unranked.
	 *
	 * @param periodBeforeEndOfMhForSmoothingUnranked the
	 *                                                periodBeforeEndOfMhForSmoothingUnranked
	 *                                                to set
	 */
	public void setPeriodBeforeEndOfMhForSmoothingUnranked(double periodBeforeEndOfMhForSmoothingUnranked) {
		this.periodBeforeEndOfMhForSmoothingUnranked = periodBeforeEndOfMhForSmoothingUnranked;
	}

	/**
	 * toString del metodo
	 * @return the toString
	 */
	@Override
	public String toString() {
		
		/*
		 * return he properties 
		 * related to the current 
		 * satellite with all the 
		 * infomation 
		 * about the sat
		 */
		return "SatelliteProperties [satId=" + this.satId + ", startWithRw=" + this.startWithRw
				+ ", maxNumberDailyPeak=" + this.maxNumberDailyPeak + ", periodBeforeEndOfMhForSmoothingUnranked="
				+ this.periodBeforeEndOfMhForSmoothingUnranked + ", pawExclusionList=" + this.pawExclusionList
				+ ", maxTheatreOnADay=" + this.maxTheatreOnADay + ", includeSilentInLeftAttitudeFormulaC1="
				+ this.includeSilentInLeftAttitudeFormulaC1 + ", allChecksOnOrbits=" + this.allChecksOnOrbits
				+ ", tranquillizationTimeRoll=" + this.tranquillizationTimeRoll + ", tranquillizationTimePitch="
				+ this.tranquillizationTimePitch + ", upperBoundPeakOrbit=" + this.upperBoundPeakOrbit
				+ ", lowerBoundPeakOrbit=" + this.lowerBoundPeakOrbit + ", percentManLeftC2=" + this.percentManLeftC2
				+ ", maxNumberOfPacketStore=" + this.maxNumberOfPacketStore + ", maxContinuativeTimePDHT="
				+ this.maxContinuativeTimePDHT + ", maxCumulativeTimePDHT=" + this.maxCumulativeTimePDHT
				+ ", waitTimeBetweenRampAndCmg=" + this.waitTimeBetweenRampAndCmg + ", maxNumberOfSwitchesPDHT="
				+ this.maxNumberOfSwitchesPDHT + ", axesReconfigurationTime=" + this.axesReconfigurationTime
				+ ", defaultMinTimeRight=" + this.defaultMinTimeRight + ", maxEssInLeftPeriod="
				+ this.maxEssInLeftPeriod + ", maxTimeInAllTheLeftPeriod=" + this.maxTimeInAllTheLeftPeriod
				+ ", maxTimeBetweenTwoLeftAcquisitions=" + this.maxTimeBetweenTwoLeftAcquisitions
				+ ", minPercDownloadOnVis=" + this.minPercDownloadOnVis + ", wizardLinkDataRate="
				+ this.wizardLinkDataRate + ", singleSectorDimension=" + this.singleSectorDimension
				+ ", activateUrgentRule=" + this.activateUrgentRule + ", downlinkPerChannel=" + this.downlinkPerChannel
				+ ", maxPercEclipseAvailable=" + this.maxPercEclipseAvailable + ", percentEffectiveEclipse="
				+ this.percentEffectiveEclipse + ", timeBeforeAndAfterEclipse=" + this.timeBeforeAndAfterEclipse
				+ ", silentFactor=" + this.silentFactor + ", allVisForSat=" + this.allVisForSat + "]";
	}

	/**
	 * Gets the min time download delay.
	 *
	 * @return the min time download delay
	 */
	public int getMinTimeDownloadDelay() {
		return minTimeDownloadDelay;
	}

	/**
	 * Sets the min time download delay.
	 *
	 * @param minTimeDownloadDelay the new min time download delay
	 */
	public void setMinTimeDownloadDelay(int minTimeDownloadDelay) {
		this.minTimeDownloadDelay = minTimeDownloadDelay;
	}

	/**
	 * Gets the number of sectors shift pt.
	 *
	 * @return the numberOfSectorsShiftPt
	 */
	public int getNumberOfSectorsShiftPt() {
		return numberOfSectorsShiftPt;
	}

	/**
	 * Sets the number of sectors shift pt.
	 *
	 * @param numberOfSectorsShiftPt the numberOfSectorsShiftPt to set
	 */
	public void setNumberOfSectorsShiftPt(int numberOfSectorsShiftPt) {
		this.numberOfSectorsShiftPt = numberOfSectorsShiftPt;
	}

	/**
	 * Gets the max available buffer size pt.
	 *
	 * @return the maxAvailableBufferSizePt
	 */
	public int getMaxAvailableBufferSizePt() {
		return maxAvailableBufferSizePt;
	}

	/**
	 * Sets the max available buffer size pt.
	 *
	 * @param maxAvailableBufferSizePt the maxAvailableBufferSizePt to set
	 */
	public void setMaxAvailableBufferSizePt(int maxAvailableBufferSizePt) {
		this.maxAvailableBufferSizePt = maxAvailableBufferSizePt;
	}

	/**
	 * Gets the max available buffer size gps.
	 *
	 * @return the maxAvailableBufferSizeGps
	 */
	public int getMaxAvailableBufferSizeGps() {
		return maxAvailableBufferSizeGps;
	}

	/**
	 * Sets the max available buffer size gps.
	 *
	 * @param maxAvailableBufferSizeGps the maxAvailableBufferSizeGps to set
	 */
	public void setMaxAvailableBufferSizeGps(int maxAvailableBufferSizeGps) {
		this.maxAvailableBufferSizeGps = maxAvailableBufferSizeGps;
	}

	/**
	 * Gets the use extra sectors pt.
	 *
	 * @return the useExtraSectorsPt
	 */
	public int getUseExtraSectorsPt() {
		return useExtraSectorsPt;
	}

	/**
	 * Sets the use extra sectors pt.
	 *
	 * @param useExtraSectorsPt the useExtraSectorsPt to set
	 */
	public void setUseExtraSectorsPt(int useExtraSectorsPt) {
		this.useExtraSectorsPt = useExtraSectorsPt;
	}

	/**
	 * Gets the minimum time between storage and acq.
	 *
	 * @return the minimumTimeBetweenStorageAndAcq
	 */
	public int getMinimumTimeBetweenStorageAndAcq() {
		return minimumTimeBetweenStorageAndAcq;
	}

	/**
	 * Sets the minimum time between storage and acq.
	 *
	 * @param minimumTimeBetweenStorageAndAcq the minimumTimeBetweenStorageAndAcq to
	 *                                        set
	 */
	public void setMinimumTimeBetweenStorageAndAcq(int minimumTimeBetweenStorageAndAcq) {
		this.minimumTimeBetweenStorageAndAcq = minimumTimeBetweenStorageAndAcq;
	}

	/**
	 * Gets the minimum distance between tasks.
	 *
	 * @return the minimumDistanceBetweenTasks
	 */
	public int getMinimumDistanceBetweenTasks() {
		return minimumDistanceBetweenTasks;
	}

	/**
	 * Sets the minimum distance between tasks.
	 *
	 * @param minimumDistanceBetweenTasks the minimumDistanceBetweenTasks to set
	 */
	public void setMinimumDistanceBetweenTasks(int minimumDistanceBetweenTasks) {
		this.minimumDistanceBetweenTasks = minimumDistanceBetweenTasks;
	}

}
