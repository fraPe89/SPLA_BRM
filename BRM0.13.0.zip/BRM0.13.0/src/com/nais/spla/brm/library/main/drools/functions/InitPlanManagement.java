/**
*
* MODULE FILE NAME:	InitPlanManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		24 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 24 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.List;
import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class InitPlanManagement.
 *
 * @author francesca
 */
public class InitPlanManagement {

	/**
	 * Insert previous tasks.
	 *
	 * @param kieSession   the kie session
	 * @param allInitTasks the all init tasks
	 */
	public void insertPreviousTasks(KieSession kieSession, List<Task> allInitTasks) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// iterate over the tasks given as input
		for (int i = 0; i < allInitTasks.size(); i++) {
			// mark the i-esim task as previously processed
			allInitTasks.get(i).setPreviousMh(true);
			logger.debug("************* init plan : inserting " + allInitTasks.get(i));

			// insert into Drools
			kieSession.insert(allInitTasks.get(i));

			// fire the rules so Drools can react to the new insert
			kieSession.fireAllRules();
		}
	}

}
