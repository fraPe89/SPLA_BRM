/**
 *
 * MODULE FILE NAME: TaskType.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum TaskType.
 */
public enum TaskType {

	/** The acquisition. */
	ACQUISITION,

	/** The dlo. */
	DLO,

	/** The download. */
	DOWNLOAD,

	/** The maneuver. */
	MANEUVER,

	/** The passthrough. */
	PASSTHROUGH,

	/** The silent. */
	SILENT,

	/** The ramp. */
	RAMP,

	/** The store. */
	STORE,

	/** The gps. */
	GPS,

	/** The axes reconf. */
	AXES_RECONF,

	/** The store aux. */
	STORE_AUX,

	/** The bite. */
	BITE
}
