/**
*
* MODULE FILE NAME: HpOrbitalExclusionManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * The Class HpOrbitalExclusionManagement.
 */
public class HpOrbitalExclusionManagement {

	/**
	 * Check if there are elements in interval.
	 *
	 * @param currentMh          the current mh
	 * @param allHPExclusionInMh the all HP exclusion in mh
	 * @param satId              the sat id
	 * @param timeForCmga        the time for cmga
	 * @return the list
	 * @throws ParseException the parse exception
	 */
	public List<HPExclusion> checkIfThereAreElementsInInterval(MissionHorizon currentMh,
			List<HPExclusion> allHPExclusionInMh, String satId, long timeForCmga) throws ParseException {

		// create an empty list of hpsegment valid for this current mission
		// horizon
		List<HPExclusion> onlySegmentInInterval = new ArrayList<>();

		// iterate over the hpSegments
		for (int i = 0; i < allHPExclusionInMh.size(); i++) {
			// get the i-esim hp segment
			HPExclusion segment = allHPExclusionInMh.get(i);

			// if is not specified the lookside at start
			if (segment.getStartLookSide() == null) {
				// force it to right
				segment.setStartLookSide("right");
			}

			// if is not specified the lookside at stop
			if (segment.getStopLookSide() == null) {
				// force it to right
				segment.setStopLookSide("right");
			}

			// logger.debug("check for segment : " + segment);

			// if segment is active
			if (segment.isEnabled()) {
				// chech if is pertinent for the current mission horizon
				boolean inInterval = checkIfSegmentIsInInterval(currentMh, segment, satId, timeForCmga);

				// if is pertinent
				if (inInterval) {
					// add to the list of valid hpSegment
					onlySegmentInInterval.add(segment);
					// logger.debug("segment is valid, added.");
				}
			}
		}
		return onlySegmentInInterval;
	}

	/**
	 * Check if segment is in interval.
	 *
	 * @param currentMh   the current mh
	 * @param segment     the segment
	 * @param satelliteId the satellite id
	 * @param timeForCmga the time for cmga
	 * @return true, if successful
	 * @throws ParseException the parse exception
	 */
	protected boolean checkIfSegmentIsInInterval(MissionHorizon currentMh, HPExclusion segment, String satelliteId,
			long timeForCmga) throws ParseException {

		// logger.debug("hp segment : " + segment);
		// logger.debug("currentMh : " + currentMh);

		// set that isn't inside the mission horizon as default
		boolean inInterval = false;

		// get the current isntance of calendar
		Calendar cal = Calendar.getInstance();

		// create a string for the start time of mh
		String startTimeMh = computeTime(currentMh.getStart());

		// create a string for the stop time of mh
		String endTimeMh = computeTime(currentMh.getStop());

		// create a string for the start time of segment
		String startTimeHpSeg = computeTime(segment.getStartTime());

		// create a string for the stop time of segment
		String endTimeHpSeg = computeTime(segment.getEndTime());

		// initialize all the dates
		Date startTimeMhTime = null;
		Date endTimeMhTime = null;
		Date startTimeHpSegTime = null;
		Date endTimeHpSegTime = null;

		// parse and convert as date all
		// the times defined above
		startTimeMhTime = new SimpleDateFormat("HH:mm:ss").parse(startTimeMh);
		endTimeMhTime = new SimpleDateFormat("HH:mm:ss").parse(endTimeMh);
		startTimeHpSegTime = new SimpleDateFormat("HH:mm:ss").parse(startTimeHpSeg);
		endTimeHpSegTime = new SimpleDateFormat("HH:mm:ss").parse(endTimeHpSeg);

		// if the segment is related to the current satellite
		if (segment.getSatelliteId().contains(satelliteId)) {
			boolean overlapInTime = (startTimeHpSegTime.getTime() <= endTimeMhTime.getTime())
					&& (endTimeHpSegTime.getTime() >= startTimeMhTime.getTime());

			// compute the duration of hpSegment
			long durationOfSegment = segment.getEndTime().getTime() - segment.getStartTime().getTime();

			// precheck : if the lookside at start and stop are different and
			// the gap is not enought to perform a maneuver
			if ((durationOfSegment < (timeForCmga * 1000))
					&& !segment.getStartLookSide().equalsIgnoreCase(segment.getStopLookSide())) {
				// consider the hpsegment as inconsistent
				inInterval = false;
			}

			// HPsegment is in overlap with mission horizon
			else {
				// compute if the segment is in overlap with current mission
				// horizon
				boolean effectiveOverlap = ((segment.getStartTime().getTime() <= currentMh.getStop().getTime())
						&& (segment.getEndTime().getTime() >= currentMh.getStart().getTime()));

				// if there is overlap
				if (effectiveOverlap) {
					// logger.debug("times are in overlap : segment is a
					// candidate");
					cal.setTime(segment.getStartTime());

					// mark as valid
					inInterval = true;
				}

				// there isn' t overlap but the time range is the same ->
				// segment is a potential candidate
				else if (overlapInTime) {
					// logger.debug("times are in overlap : segment is a
					// candidate");

					// set the start time with the start time of the segment
					cal.setTime(segment.getStartTime());

					// the segment is previous of mission horizon
					if ((segment.getStartTime().getTime() <= currentMh.getStart().getTime())) {
						// segment is previous or in overlap with mh
						// logger.debug("segment is previous or in overlap with
						// mh");

						// check if is period
						if (segment.isPeriodic()) {
							// iterate till the date will be in overlap with
							// current mh
							while (cal.getTime().before(currentMh.getStart())) {
								// logger.debug("adding 16 days to segment : " +
								// segment.getStartTime() + " obtaining :");

								// at every step, add 16 days to the current
								// date
								cal.add(Calendar.DATE, 16);

								// logger.debug("day : " + cal.getTime());

								// if there is overlap between the new date and
								// the mission horizon
								if ((cal.getTime().getTime() <= currentMh.getStop().getTime())
										&& (cal.getTime().getTime() >= currentMh.getStart().getTime())) {
									// mark as in interval
									inInterval = true;

									// compute duration of the segment
									long duration = segment.getEndTime().getTime() - segment.getStartTime().getTime();

									// update start time of segment
									segment.setStartTime(cal.getTime());

									// update stop time of the segment
									segment.setEndTime(new Date(segment.getStartTime().getTime() + (duration)));
									// logger.debug("updated start segment : " +
									// segment.getStartTime());
									// logger.debug("updated end segment : " +
									// segment.getEndTime());
								}
							}
						}
					}
				}
			}
		}
		return inInterval;
	}

	/**
	 * Compute time.
	 *
	 * @param start the start
	 * @return the string
	 */
	public String computeTime(Date start) {
		// get the first occurrence of the date
		int startTime = start.toString().trim().indexOf(":") - 2;

		// get the last occurrence of the date
		int stopTime = start.toString().trim().lastIndexOf(":") + 3;

		// create a subString with only the date
		String subStringTime = start.toString().trim().substring(startTime, stopTime);
		// logger.debug("subStringTime : " + subStringTime);
		return subStringTime;
	}

	/**
	 * Compute hp exclusion at end.
	 *
	 * @param acq               the acq
	 * @param hpSeg             the hp seg
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param rejected          the rejected
	 * @return the maneuver resources
	 */
	public ManeuverResources computeHpExclusionAtEnd(Acquisition acq, HPExclusion hpSeg, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions, Map<String, Acquisition> rejected) {
		ManeuverResources manRes = null;

		// declare a reason of Reject
		ReasonOfReject reason = null;

		// declare a description for the reason of reject
		String description = null;

		// create a boolean variable to detect when the repairing man is not
		// possible to perform
		boolean cannotPerform = false;

		// get the satellite id relative tto the current acq
		Satellite sat = droolsParams.getSatWithId(acq.getSatelliteId());
		ManeuverManagement maneuverManagement = new ManeuverManagement();

		// if the acquisition is VU this check must be skipped
		if (acq.getPrType().compareTo(PRType.VU) == 0) {
			// logger.debug("MANEUVER_RULE_ the acquisition is a VU, check on Hp
			// segment is skipped.");
		}

		// for all the others type of acq
		else {
			// set as limit for the maneuver the end time of the hpSegment
			long impossibleBeforeDate = hpSeg.getEndTime().getTime();
			// logger.debug("HP_exclusion_Segment_orbit_end RULE \n between acq
			// : " + acq + "\n and hp seg : " + hpSeg);

			// if the acquisition has a different lookSide of final lookside of
			// hpSegment
			if (!acq.getLookSide().equalsIgnoreCase(hpSeg.getStopLookSide())) {
				// create an instance of ManeuverResources
				manRes = new ManeuverResources();

				// compute the gap between the start time of acq and end time of
				// hpSegment
				long gap = (acq.getStartTime().getTime() - hpSeg.getEndTime().getTime()) / 1000;

				// if the gap is at least the time of maneuver CMGA
				if (gap > droolsParams.getTimeForManeuverCmga()) {
					// try to create a man
					manRes = maneuverManagement.createManBetweenAcqAndInterval(
							sat.getSatelliteProperties().isStartWithRw(), impossibleBeforeDate, acq, manRes,
							droolsParams, resourceFunctions, true, 0);
				}
				// if there isn't time for a man
				else {
					// mark the boolean variable to true
					cannotPerform = true;

					reason = ReasonOfReject.noTimeForAManeuver;
					description = "System Conflict";
				}

				// if the man is correctly created
				if (manRes.isPossible()) {
					// if there are new man
					if (!manRes.getNewMans().isEmpty()) {
						// set the new man with the mark of hpSegment
						manRes.getNewMans().get(0).setForHpSegm(true);
					}
				}
				// cannot perform the new man
				else {
					// mark the boolean variable to true
					cannotPerform = true;
				}

				// if is impossible to create a repairing man
				if (cannotPerform) {
					// logger.debug("MANEUVER_RULE_ invalid check : removing acq
					// that need a maneuver : " + acq);
					// logger.debug("add to reject acq : " + acq.getId());

					// mark the acquisition as rejected
					acq.setRejected(true);

					if (reason != null) {
						acq.addReasonOfReject(1, reason, description, 0, 0, null);
					}
					// add the acquisition to the rejected elements map
					rejected.put(acq.getId(), acq);
				}
			}
		}

		// if at least a field of manRes is not null
		if (((manRes != null) && manRes.isPossible())
				&& (!manRes.getNewMans().isEmpty() || !manRes.getOldMans().isEmpty() || !manRes.getNewRumps().isEmpty()
						|| !manRes.getOldRumps().isEmpty())) {
			// insert the manRes in Drools
			// logger.debug("manRes is possible");
		} else {
			manRes = null;
		}
		return manRes;
	}

}