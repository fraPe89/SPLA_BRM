/**
 *
 * MODULE FILE NAME: TaskMarkType.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum TaskMarkType.
 */
public enum TaskMarkType {

	/** The confirmed. */
	CONFIRMED,

	/** The deleted. */
	DELETED,

	/** The new. */
	NEW,

	/** The nominal. */
	NOMINAL,

	/** The unchanged. */
	UNCHANGED
}
