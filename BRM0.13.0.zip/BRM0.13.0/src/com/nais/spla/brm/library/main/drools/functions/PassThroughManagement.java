/**
*
* MODULE FILE NAME: PassThroughManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.FunctionUtils;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DownloadsForLink;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class PassThroughManagement.
 */
public class PassThroughManagement {

	/** The pdht mng. */
	PdhtManagement pdhtMng = new PdhtManagement();

	/** The dwl mng. */
	DownloadManagement dwlMng = new DownloadManagement();

	/** The dwl utils. */
	DownloadUtils dwlUtils = new DownloadUtils();

	/**
	 * Creates the pass through.
	 *
	 * @param acq               the acq
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @return the pass through
	 */
	@SuppressWarnings("unchecked")
	public PassThrough createPassThrough(Acquisition acq, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		logger.debug("trying to plan a PT");

		// create a new pt
		PassThrough pt = new PassThrough();

		// get the satellite properties for the satellite relative to the acq
		SatelliteProperties satProp = droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties();

		// create a new storage for the pt
		Storage sto = this.pdhtMng.createNewStorage(acq, droolsParams);
		logger.debug("storage : " + sto);

		// get the pdht function
		TreeMap<Long, ComplexPdht> PDHTFunction = (TreeMap<Long, ComplexPdht>) DroolsUtils
				.deepClone(resourceFunctions.getPDHTFunctionAssociatedToSat(acq.getSatelliteId()));

		logger.debug("pdht function : " + PDHTFunction);

		// try to insert the just created pt
		boolean inserted = this.pdhtMng.insertStoInPDHT(PDHTFunction, sto);

		// if the insert is ok
		if (inserted) {
			logger.debug("returned storage : " + sto);

			// set the number of packets of the pt
			pt.setNumberOfPackets(sto.getPacketsAssociated().size());

			// iterate over the packets stores
			for (int i = 0; i < sto.getPacketsAssociated().size(); i++) {
				// extract the i-esim ps
				PacketStore ps = sto.getPacketsAssociated().get(i);
				// if is related to Horizontal polarization
				if (ps.getPolarization().toString().startsWith("HH")) {
					// set size h
					pt.setPacketStoreSizeH(ps.getSize());
				}
				// if is related to Vertical polarization
				else {
					// set size V
					pt.setPacketStoreSizeV(ps.getSize());
				}
			}

			// set the task type
			pt.setTaskType(TaskType.PASSTHROUGH);

			// sedt the size
			// with the max size
			int size = acq.getSizeH();
			if (acq.getSizeV() > size) {
				size = acq.getSizeV();
			}

			logger.debug("trying to plan a PT : size" + size);

			// set IdTask
			pt.setIdTask(acq.getIdTask());

			// set StartTime
			// start time is after a wait of a number of sectors
			int switchSectors = droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
					.getNumberOfSectorsShiftPt();
			long psSwitch = (long) ((((switchSectors * satProp.getSingleSectorDimension()))
					/ (satProp.getWizardLinkDataRate() / 8)) * 1000);

			pt.setStartTime(new Date(acq.getStartTime().getTime() + psSwitch));

			// compute duration
			long psDurationInSec = (long) ((((size) * satProp.getSingleSectorDimension())
					/ (satProp.getDownlinkPerChannel() / 8)));
			logger.debug("packet store duration : " + psDurationInSec + " in seconds ->" + (psDurationInSec / 60)
					+ " minutes.");

			// compute end time of pt
			long endTimeInLong = pt.getStartTime().getTime() + (psDurationInSec * 1000);
			logger.debug("end time as date : " + new Date(endTimeInLong));

			// set the EndTime
			pt.setEndTime(new Date(endTimeInLong));

			// set theAcquisitionRequestId
			pt.setAcquisitionRequestId(
					FunctionUtils.extractArFromDto(acq.getIdTask(), DroolsParameters.getSplitChar()));

			// set the ProgrammingRequestId
			pt.setProgrammingRequestId(
					FunctionUtils.extractPrFromDto(acq.getIdTask(), DroolsParameters.getSplitChar()));

			// set the SatelliteId
			pt.setSatelliteId(acq.getSatelliteId());

			// setNumberOfPackets
			pt.setNumberOfPackets(size / satProp.getSingleSectorDimension());

			setAcquisitionStationForPt(acq, pt);

			String pol = acq.getPolarization().toString().replaceAll("_", "");
			// is in double polarization HV
			if (pol.contains("HV")) {
				pt.setDoublePol(true);
				// set the use of l1
				// and l2 correctly
				pt.setCarrierL2SelectionH(false);
				pt.setCarrierL2SelectionV(true);
			}

			// is in double pol VH
			else if (pol.contains("VH")) {
				pt.setDoublePol(true);
				// set the use of l1
				// and l2 correctly
				pt.setCarrierL2SelectionV(true);
				pt.setCarrierL2SelectionH(false);
			}
		} else {
			pt = null;
		}
		return pt;
	}

	/**
	 * Sets the acquisition station for pt.
	 *
	 * @param acq the acq
	 * @param pt  the pt
	 */
	public void setAcquisitionStationForPt(Acquisition acq, PassThrough pt) {
		// crete an empty list of acqStationsId
		List<String> acqStatList = new ArrayList<>();

		// iterate over the user info
		for (int i = 0; i < acq.getUserInfo().size(); i++) {
			// iterate over the acquisition stations
			// associated with the i-esim partner of the userInfo
			if (acq.getUserInfo().get(i).getAcquisitionStationIdList() != null) {
				for (int j = 0; j < acq.getUserInfo().get(i).getAcquisitionStationIdList().size(); j++) {
					// if in the list there isn't the current acqStat id
					if (!acqStatList.contains(acq.getUserInfo().get(i).getAcquisitionStationIdList().get(j))) {
						// add it
						acqStatList.add(acq.getUserInfo().get(i).getAcquisitionStationIdList().get(j));
					}
				}
			}
		}
		pt.setGroundStationId(acqStatList);
	}

	/**
	 * Try to plan PT.
	 *
	 * @param acq             the acq
	 * @param pt              the pt
	 * @param allVisInOverlap the all vis in overlap
	 * @param resFunc         the res func
	 * @return the pass through
	 */
	public PassThrough tryToPlanPT(Acquisition acq, PassThrough pt, List<Visibility> allVisInOverlap,
			ResourceFunctions resFunc) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// invoke the method to sort the visibility list
		this.dwlUtils.sortVisibilityList(allVisInOverlap, acq);

		// get all the downloads
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlAssociatedToSat = resFunc
				.getDownloadsAssociatedToSat(acq.getSatelliteId());
		boolean possible = false;
		logger.debug("all dwl associated to sat function :" + allDwlAssociatedToSat);

		// initialize the double polarization to false
		boolean doublePol = false;

		String polarization = acq.getPolarization().toString().replaceAll("_", "");
		// polarization is double (VH)
		if (polarization.contains("VH")) {
			doublePol = true;
			// set the use of l1
			// and l2 correctly
			pt.setCarrierL2SelectionV(false);
			pt.setCarrierL2SelectionH(true);
		}
		// polarization is double (HV)
		else if (polarization.contains("HV")) {
			doublePol = true;
			// set the use of l1
			// and l2 correctly
			pt.setCarrierL2SelectionH(false);
			pt.setCarrierL2SelectionV(true);
		} else if (polarization.contains("H")) {
			pt.setCarrierL2SelectionH(false);
		} else {
			pt.setCarrierL2SelectionV(false);
		}

		boolean foundAValidVis = false;
		// iterate over the overlapped vis
		for (int i = 0; i < allVisInOverlap.size(); i++) {
			logger.debug("check for vis in overlap : " + allVisInOverlap.get(i));
			logger.debug("ground stations available for this pt : " + pt.getGroundStationId());
			logger.debug("check if the current visibility is in the list of visibilities available for this pt...");

			if (!foundAValidVis) {
				// if the visibility is external of the pt has the vis as
				// visibility
				// associated
				if (pt.getGroundStationId().contains(allVisInOverlap.get(i).getAcqStatId())
						|| (allVisInOverlap.get(i).getOwnerId() == null)) {
					logger.debug("visibility is in list or it's external.");
					// check if is possible to perform
					// the pt on the current vis
					possible = checkIfItSPossibleOnVis(logger, pt, acq, allVisInOverlap.get(i), allDwlAssociatedToSat,
							doublePol);

					// possible to perform the pt
					if (possible) {
						logger.debug("pt correctly planned on this  visibility.");
						// set ground station id
						pt.setRelatedTaskId(acq.getIdTask());
						pt.setGroundStationId(new ArrayList<>(Arrays.asList(allVisInOverlap.get(i).getAcqStatId())));
						pt.setUgsOwnerList(acq.getPartnersAssociated());
						pt.setContactCounterVis(allVisInOverlap.get(i).getContactCounter());
						pt.setIdTask(acq.getIdTask());
						// insert into download structure
						this.dwlMng.insertInIDownloadStructure(pt, allVisInOverlap, allDwlAssociatedToSat);
						foundAValidVis = true;
					}
					// not possible to perform
					else {
						// choose another vis
						continue;
					}
				} else {
					logger.debug("visibility isn't in list..going to next..");
				}
			}

		}
		// if is not possible to perform the pt
		if (!possible) {
			// return an empty element
			pt = null;
		}
		return pt;
	}

	/**
	 * Check if it S possible on vis.
	 *
	 * @param logger                the logger
	 * @param pt                    the pt
	 * @param acq                   the acq
	 * @param visibility            the visibility
	 * @param allDwlAssociatedToSat the all dwl associated to sat
	 * @param doublePol             the double pol
	 * @return true, if successful
	 */
	private boolean checkIfItSPossibleOnVis(Logger logger, PassThrough pt, Acquisition acq, Visibility visibility,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlAssociatedToSat, boolean doublePol) {
		// initialize the boolean variable to check the feasibility of pt
		boolean isPossible = false;
		logger.debug("pt startTime : " + pt.getStartTime());
		logger.debug("pt stopTime : " + pt.getEndTime());

		DownloadsForLink allDwlForLink1 = null;

		allDwlForLink1 = detectDwlOnLink(visibility, "1", allDwlAssociatedToSat);

		logger.debug("DownloadsForLink 1 " + allDwlForLink1.toString());
		DownloadsForLink allDwlForLink2 = null;

		allDwlForLink2 = detectDwlOnLink(visibility, "2", allDwlAssociatedToSat);
		logger.debug("DownloadsForLink 2 " + allDwlForLink2.toString());

		// return the link more empty of the visibility (1 or 2)
		String linkMoreEmpty = visibility.getLinkMoreEmptyBasedOnSize(allDwlForLink1.getSize(),
				allDwlForLink2.getSize());

		/*
		 * if the choosen link starts before or at the time of the start of passthrough
		 * and is valid (the end time of the visibility is greater or equals to the end
		 * time of the passthrough
		 */
		if ((visibility.getAvailableStartTime(linkMoreEmpty).getTime() <= pt.getStartTime().getTime())
				&& (visibility.getEndTime().getTime() >= pt.getEndTime().getTime())) {
			/*
			 * if it's not the first time that the visibility is inserted into the treemap
			 * of downloads
			 */

			String contactCounterForVis = DownloadManagement.concatVisId(acq.getSatelliteId(), visibility);

			if (allDwlAssociatedToSat.containsKey(contactCounterForVis)) {
				String otherLink = "2";

				// if the emptiest link is the second one
				if (linkMoreEmpty.contains("2")) {
					otherLink = "1";
				}

				// get the treemap structure associated at the corrent
				// visibility

				TreeMap<String, TreeMap<Long, IDownload>> allDwlOnvis = allDwlAssociatedToSat.get(contactCounterForVis);

				// if the passthrought is in double polarization
				if (pt.isDoublePol()) {
					// check both link, l1 and l2 (must be both empty for all
					// the duration of the passthrough)
					boolean isPossibleOnMaxLink = findIfIsPossibleOnLink(pt, allDwlOnvis, linkMoreEmpty);
					boolean isPossibleOnOtherLink = findIfIsPossibleOnLink(pt, allDwlOnvis, otherLink);

					// if both link are valid
					if (isPossibleOnMaxLink && isPossibleOnOtherLink) {
						// set that the passthough is feasible
						isPossible = true;
					}
				}
				// if the passthrough is in single pol
				else {
					// check if it's possible on emptiest link
					isPossible = findIfIsPossibleOnLink(pt, allDwlOnvis, linkMoreEmpty);

					// if it's impossible
					if (!isPossible) {
						logger.debug(
								"impossible on linkv: " + linkMoreEmpty + " try with the other one" + otherLink + "\n");

						// try to use the other link of the visibility
						isPossible = findIfIsPossibleOnLink(pt, allDwlOnvis, otherLink);
					}
				}

			}
			// the visibility is empty, it was
			// never inserted in the download
			// treemap before
			else {
				// set that the passthough is feasible
				isPossible = true;
			}
		}
		return isPossible;
	}

	/**
	 * @param visibility
	 * @param string
	 * @param allDwlAssociatedToSat
	 * @return
	 */
	private DownloadsForLink detectDwlOnLink(Visibility visibility, String link,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlAssociatedToSat) {
		//get the univoque id of the current vis
		String contactCounterForVis = DownloadManagement.concatVisId(visibility.getSatelliteId(), visibility);
		
		//initialize the size of donloads
		double cumulativeSize = 0;
		
		//initialize the list of tasks
		List<Task> allDwlForLink = new ArrayList<>();

		//if there are elements planned on vis
		if (allDwlAssociatedToSat.get(contactCounterForVis) != null) {
			
			//get the partial treemap with 
			//all the elements planned on the current vis
			TreeMap<String, TreeMap<Long, IDownload>> subMap = allDwlAssociatedToSat.get(contactCounterForVis);
			//if there are lements planned on the link
			//given as input
			if (subMap.get(link) != null) {
				
				//get them
				TreeMap<Long, IDownload> elementsOnLink = subMap.get(link);

				if ((elementsOnLink != null) && !elementsOnLink.isEmpty()) {

					//iterate over them
					for (Map.Entry<Long, IDownload> sub : elementsOnLink.entrySet()) {
						//extract the i-esim element 
						Task currentEl = sub.getValue().getDwlOrPt();
						
						//add to the list
						allDwlForLink.add(currentEl);
						
						//if it is a download
						if (currentEl instanceof Download) {
							Download dwl = (Download) currentEl;
							cumulativeSize = cumulativeSize + dwl.getDownloadedSize();
						} 
						
						//if it is a PassThrough
						else {
							PassThrough pt = (PassThrough) currentEl;
							cumulativeSize = cumulativeSize + pt.getPacketStoreSizeH();
						}
					}
				}
			}
		}

		//crate a new DownloadsForLink
		DownloadsForLink dwlMng = new DownloadsForLink(cumulativeSize, allDwlForLink);

		return dwlMng;
	}

	/**
	 * Find if is possible on link.
	 *
	 * @param pt          the pt
	 * @param allDwlOnvis the all dwl onvis
	 * @param link        the link
	 * @return true, if successful
	 */
	private boolean findIfIsPossibleOnLink(PassThrough pt, TreeMap<String, TreeMap<Long, IDownload>> allDwlOnvis,
			String link) {
		Logger logger = DroolsParameters.getLogger();
		boolean isPossible = false;
		if (allDwlOnvis.containsKey(link)) {
			TreeMap<Long, IDownload> allDwlOnLink = allDwlOnvis.get(link);

			// String lowerKey = (pt.getStartTime().getTime());
			/*
			 * if exists a previous element (ordered by time)
			 */
			if (allDwlOnLink.lowerKey(pt.getStartTime().getTime()) != null) {
				IDownload prevDwl = allDwlOnLink.lowerEntry(pt.getStartTime().getTime()).getValue();

				/*
				 * if the previous download (if exist is a PT or a PAW) ends after the new pt ,
				 * the pt cannot be downloaded on this vis
				 */
				if (prevDwl.getStopTime().getTime() >= pt.getStartTime().getTime()) {
					if (prevDwl.getDwlOrPt() instanceof Download) {
						isPossible = true;
						// TODO : update residualSectors with the sector that was stored in this
						// download that will be removed
						logger.debug("found prev element : " + prevDwl);
						logger.debug(
								" previously planned on same link that will be in overlap with pt but is a download so it can be removed");

					} else {
						isPossible = false;
						logger.debug("found prev element : " + prevDwl);
						logger.debug(
								" previously planned on same link that will be in overlap with pt -> impossible to plan on link");
					}
				} else {
					isPossible = true;
				}
			}

			// String higherKey =
			// DownloadManagement.createHigherKey(pt.getStartTime().getTime());

			if (allDwlOnLink.higherKey(pt.getStartTime().getTime()) != null) {
				IDownload nextDwl = allDwlOnLink.higherEntry(pt.getStartTime().getTime()).getValue();
				logger.debug("found next element : " + nextDwl);

				/*
				 * if the next download (if exist is a PT or a PAW) starts before the new pt ,
				 * the pt cannot be downloaded on this vis
				 */
				if (nextDwl.getStartTime().getTime() <= pt.getEndTime().getTime()) {
					isPossible = false;
					logger.debug(
							" previously planned on same link that will  be in overlap with pt -> impossible to plan on link");
				} else {
					logger.debug("no overlap detected with next element, pt is valid . ");
					isPossible = true;
				}
			}
		}

		else {
			/*
			 * is the first time that the visibility is inserted on treemap -> it's all
			 * empty
			 */
			isPossible = true;
			logger.debug("link available, no overlap detected.");
		}

		return isPossible;
	}
}
