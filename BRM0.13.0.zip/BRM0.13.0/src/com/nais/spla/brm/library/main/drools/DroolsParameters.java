/**
*
  MODULE FILE NAME:	DroolsParameters.java
*
  MODULE TYPE:		Class definition
*
  FUNCTION:		<Functional description of the DDC>
*
  PURPOSE:
*
  CREATION DATE:		17 feb 2017
*
  AUTHORS:		fpedrola
*
  DESIGN ISSUE:		1.0
*
  INTERFACES:
*
  SUBORDINATES:
*
  MODIFICATION HISTORY:
*
   Date            |  Name      | New ver.    | Description
  -----------------+------------+-------------+-------------------------------
  17 feb 2017          | fpedrola    | 1.0         | first issue
  -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexReason;
import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.LowerAndUpperBoundPowers;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.SatelliteState;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.resources.Eclipse;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.MinTimeRight;

// TODO: Auto-generated Javadoc
/**
 * The Class DroolsParameters.
 *
 * @author fpedrola
 */

public class DroolsParameters {

	/** The logger. */
	private static Logger logger = null;

	/**
	 * this value if it's true means that all the rules must be checked before
	 * declare that a dto is rejected.
	 */
	private String idugsid = null;

	/** The current session. */
	private String currentSession = null;

	/** The disable GPS. */
	private String disableGPS = null;
	/** The local repo. */
	private String localRepo = null;

	/** The purge sensor mode. */
	private List<TypeOfAcquisition> purgeSensorMode = new ArrayList<>();

	/** The log4j file. */
	@SuppressWarnings("unused")
	private String log4jFile = null;

	/** The drl rules file. */
	private String drlRulesFile = null;

	/** The split char. */
	private static String splitChar = null;

	/** The responce file. */
	private String responceFile = null;

	/** The minutes for orbit. */
	private int minutesForOrbit = 0;

	/** The last position gps pdm. */
	private int lastPositionGpsPdm = 0;

	/** The last position gps ext. */
	private int lastPositionGpsExt = 0;

	/** The pratica di mare id. */
	private String praticaDiMareId = null;

	/** The matera id. */
	private String materaId = null;

	/** The disable check left attitude. */
	private boolean disableCheckLeftAttitude = false;
	/**
	 * number of bic reserved to the dto that work as slave in a di2s request. The
	 * master will get the rest of bic
	 **/
	private double percentBicDi2sSlaveMSOS = 0;

	/** The percent bic di 2 s master. */
	private double percentBicDi2sMasterMSOS = 0;

	/** The download triggered from CSPS. */
	private boolean downloadTriggeredFromCSPS = false;
	/**
	 * number of bic reserved to the dto that work as slave in a di2s request. The
	 * master will get the rest of bic
	 **/
	private double percentBicDi2sSlaveMSOR = 0;

	/** The percent bic di 2 s master. */
	private double percentBicDi2sMasterMSOR = 0;

	/**
	 * this value is a threshold to determinate the power associated to Di2s-OR.
	 */
	private double refd1_DI2S;

	/**
	 * this value is a threshold to determinate the power associated to Di2s-OS and
	 * Di2s-JN.
	 */
	private double refd2_DI2S;

	/** The gps always planned on link. */
	private String gpsAlwaysPlannedOnLink = null;

	/** The GPS reserved packet store PDM station. */
	private String GPSreservedpacketStore = null;

	/**
	 * Sets the GP sreservedpacket store.
	 *
	 * @param gPSreservedpacketStore the gPSreservedpacketStore to set
	 */
	public void setGPSreservedpacketStore(String gPSreservedpacketStore) {
		GPSreservedpacketStore = gPSreservedpacketStore;
	}

	/** The space wire for gps. */
	private double spaceWireForGps = 0;

	/** The all checks on orbits. */
	// private Map<Double, ResourceMaxValue> allChecksOnOrbits = null;

	/** The max hp bic fixed orbit. */
	private Map<String, Map<Integer, Double>> maxHpBicFixedOrbit = null;

	/** The hp eclusion list. */
	private List<HPExclusion> hpExclusionList = null;

	/** The powers sensor mode. */
	private Map<TypeOfAcquisition, Double> powersSensorMode = null;

	/** The powers with U lvalues. */
	private List<LowerAndUpperBoundPowers> powersWithULvalues = null;

	/** The tranquillization time. */
	private double tranquillizationTime = 0;

	/** The all CMGA. */
	private List<CMGA> allCMGA = null;

	/** The max tacc sat 1. */
	private double maxTaccSat1 = 0;

	/** The max tacc sat 2. */
	private double maxTaccSat2 = 0;

	/** The time for maneuver of type Rw. */
	private int timeForManeuverRW = 0;

	/** The time for maneuver of type cmga. */
	private int timeForManeuverCmga = 0;

	/** The number of satellites. */
	private int numberOfSatellites = 0;

	/** The number of sessions. */
	private int numberOfSessions = 0;

	/** Extra cost of left. */
	private double extraCostLeft = 0;

	/** The pr type max number. */
	private int prTypeMaxNumber = 0;

	/** The min time right. */
	private TreeMap<Double, List<MinTimeRight>> minTimeRight = null;

	/** The reason of reject map. */
	private static Map<ReasonOfReject, ComplexReason> reasonOfRejectMap = null;

	/** The all sat. */
	private List<Satellite> allSat = null;

	/** The all PAWS. */
	private List<PAW> allPAWS = null;

	/** The all PDHT. */
	private List<PDHT> allPDHT = null;

	/** The all visibilities. */
	private List<Visibility> allVisibilities = null;

	/** The all eclipses. */
	private List<Eclipse> allEclipses = null;

	/** The all partners. */
	private List<Partner> allPartners = null;

	/** The all partners. */
	private TreeMap<String, Partner> allPartnersAsMap = null;

	/** The current MH. */
	private MissionHorizon currentMH = null;

	/** The previously processed. */
	private boolean previousMh = false;

	/** The last acq. */
	private static Acquisition lastAcq = null;

	/** The last acq for session. */
	private static HashMap<String, Acquisition> lastAcqForSession = new HashMap<>();

	/** The satellite state. */
	private List<SatelliteState> satelliteState = new ArrayList<>();

	/**
	 * Instantiates a new drools parameters.
	 */
	public DroolsParameters() {
		// initialize the satellite states
		this.satelliteState = new ArrayList<>();

		// initialize the partners
		this.allPartners = new ArrayList<>();

		// initialize the eclipses
		this.allEclipses = new ArrayList<>();

		this.setAllPartnersAsMap(new TreeMap<String, Partner>());

		// initialize the visibilities
		this.allVisibilities = new ArrayList<>();

		// initialize the pdht status
		this.allPDHT = new ArrayList<>();

		// initialize the paws
		this.allPAWS = new ArrayList<>();

		// initialize the cmg units
		this.allCMGA = new ArrayList<>();

		// initialize the satellites
		this.allSat = new ArrayList<>();

		// initialize the table for min time in right after a left period
		this.minTimeRight = new TreeMap<>();

		// initialize the hp exclusion list
		this.hpExclusionList = new ArrayList<>();

		// initialize the map of sensor modes
		this.powersSensorMode = new HashMap<>();

		// invoke the function to manage special cases of sensor mode powers
		this.setPowersWithULvalues(new ArrayList<LowerAndUpperBoundPowers>());
	}

	/**
	 * Gets the all eclipses.
	 *
	 * @return the all eclipses
	 */
	public List<Eclipse> getAllEclipses() {
		return this.allEclipses;
	}

	/**
	 * Gets the hp eclusion list.
	 *
	 * @return the hpEclusionList
	 */
	public List<HPExclusion> getHpExclusionList() {
		return this.hpExclusionList;
	}

	/**
	 * Gets the percent bic di 2 s slave MSOS.
	 *
	 * @return the percentBicDi2sSlaveMSOS
	 */
	public double getPercentBicDi2sSlaveMSOS() {
		return this.percentBicDi2sSlaveMSOS;
	}

	/**
	 * Sets the percent bic di 2 s slave MSOS.
	 *
	 * @param percentBicDi2sSlaveMSOS the percentBicDi2sSlaveMSOS to set
	 */
	public void setPercentBicDi2sSlaveMSOS(double percentBicDi2sSlaveMSOS) {
		this.percentBicDi2sSlaveMSOS = percentBicDi2sSlaveMSOS;
	}

	/**
	 * Gets the percent bic di 2 s master MSOS.
	 *
	 * @return the percentBicDi2sMasterMSOS
	 */
	public double getPercentBicDi2sMasterMSOS() {
		return this.percentBicDi2sMasterMSOS;
	}

	/**
	 * Sets the percent bic di 2 s master MSOS.
	 *
	 * @param percentBicDi2sMasterMSOS the percentBicDi2sMasterMSOS to set
	 */
	public void setPercentBicDi2sMasterMSOS(double percentBicDi2sMasterMSOS) {
		// if this amount is more than 100
		if (percentBicDi2sMasterMSOS > 100) {
			// force it to 100
			percentBicDi2sMasterMSOS = 100;
		}
		
		this.percentBicDi2sMasterMSOS = percentBicDi2sMasterMSOS;
	}

	/**
	 * Gets the percent bic di 2 s slave MSOR.
	 *
	 * @return the percentBicDi2sSlaveMSOR
	 */
	public double getPercentBicDi2sSlaveMSOR() {
		return this.percentBicDi2sSlaveMSOR;
	}

	/**
	 * Sets the percent bic di 2 s slave MSOR.
	 *
	 * @param percentBicDi2sSlaveMSOR the percentBicDi2sSlaveMSOR to set
	 */
	public void setPercentBicDi2sSlaveMSOR(double percentBicDi2sSlaveMSOR) {
		this.percentBicDi2sSlaveMSOR = percentBicDi2sSlaveMSOR;
	}

	/**
	 * Gets the percent bic di 2 s master MSOR.
	 *
	 * @return the percentBicDi2sMasterMSOR
	 */
	public double getPercentBicDi2sMasterMSOR() {
		return this.percentBicDi2sMasterMSOR;
	}

	/**
	 * Sets the percent bic di 2 s master MSOR.
	 *
	 * @param percentBicDi2sMasterMSOR the percentBicDi2sMasterMSOR to set
	 */
	public void setPercentBicDi2sMasterMSOR(double percentBicDi2sMasterMSOR) {

		// if this amount is more than 100
		if (percentBicDi2sMasterMSOR > 100) {
			// force it to 100
			percentBicDi2sMasterMSOR = 100;
		}
		this.percentBicDi2sMasterMSOR = percentBicDi2sMasterMSOR;
	}

	/**
	 * Sets the hp eclusion list.
	 *
	 * @param hpEclusionList the hpEclusionList to set
	 */
	public void setHpExclusionList(List<HPExclusion> hpEclusionList) {
		this.hpExclusionList = hpEclusionList;
	}

	/**
	 * Gets the all partners.
	 *
	 * @return the all partners
	 */
	public List<Partner> getAllPartners() {
		return this.allPartners;
	}

	/**
	 * Gets the all PAWS.
	 *
	 * @return the allPAWS
	 */
	public List<PAW> getAllPAWS() {
		return this.allPAWS;
	}

	/**
	 * Gets the all PDHT.
	 *
	 * @return the allPDHT
	 */
	public List<PDHT> getAllPDHT() {
		return this.allPDHT;
	}

	/**
	 * Sets the logger.
	 *
	 * @param logger the logger to set
	 */
	public static void setLogger(Logger logger) {
		DroolsParameters.logger = logger;
	}

	/**
	 * Gets the all CMGA for sat.
	 *
	 * @param satId the sat id
	 * @return the all CMGA for sat
	 */
	public List<CMGA> getAllCMGAForSat(String satId) {
		// create an empty list of cmga unit
		List<CMGA> cmgaForSat = new ArrayList<>();

		// iterate over all the cmg
		for (int i = 0; i < this.allCMGA.size(); i++) {
			// if the i-esim cmg refers to the satellite id given as input
			if (this.allCMGA.get(i).getSatelliteId().equalsIgnoreCase(satId)) {
				// add it to the list
				cmgaForSat.add(this.allCMGA.get(i));
			}
		}
		return cmgaForSat;
	}

	/**
	 * Gets the all sat.
	 *
	 * @return the allSat
	 */
	public List<Satellite> getAllSat() {
		return this.allSat;
	}

	/**
	 * Gets the all sat.
	 *
	 * @param satId the sat id
	 * @return the allSat
	 */
	public Satellite getSatWithId(String satId) {
		// declare a satellite
		Satellite sat = null;

		// iterate over all the satellites
		for (int i = 0; i < this.allSat.size(); i++) {
			// if the i-esim sat contains the satellite id given as input
			boolean contained = this.allSat.get(i).getSatelliteId().contains(satId);
			if (contained) {
				// add it to the list
				sat = this.allSat.get(i);

				// escape
				break;
			}
		}
		return sat;
	}

	/**
	 * Gets the all visibilities.
	 *
	 * @return the allVisibilities
	 */
	public List<Visibility> getAllVisibilities() {
		return this.allVisibilities;
	}

	/**
	 * Gets the current MH.
	 *
	 * @return the current MH
	 */
	public MissionHorizon getCurrentMH() {
		return this.currentMH;
	}

	/**
	 * Gets the drl rules file.
	 *
	 * @return the drlRulesFile
	 */
	public String getDrlRulesFile() {
		return this.drlRulesFile;
	}

	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public static Logger getLogger() {
		return logger;
	}

	/**
	 * Gets the max hp bic fixed orbit.
	 *
	 * @return the max hp bic fixed orbit
	 */
	public Map<String, Map<Integer, Double>> getMaxHpBicFixedOrbit() {
		return this.maxHpBicFixedOrbit;
	}

	/**
	 * Gets the number of satellites.
	 *
	 * @return the numberOfSatellites
	 */
	public int getNumberOfSatellites() {
		return this.numberOfSatellites;
	}

	/**
	 * Gets the number of sessions.
	 *
	 * @return the numberOfSessions
	 */
	public int getNumberOfSessions() {
		return this.numberOfSessions;
	}

	/**
	 * Gets the pr type max number.
	 *
	 * @return the pr type max number
	 */
	public int getPrTypeMaxNumber() {
		return this.prTypeMaxNumber;
	}

	/**
	 * Gets the responce file.
	 *
	 * @return the responceFile
	 */
	public String getResponceFile() {
		return this.responceFile;
	}

	/**
	 * Gets the satellite state.
	 *
	 * @return the satelliteState
	 */
	public List<SatelliteState> getSatelliteState() {
		return this.satelliteState;
	}

	/**
	 * Sets the all eclipses.
	 *
	 * @param allEclipses the new all eclipses
	 */
	public void setAllEclipses(List<Eclipse> allEclipses) {
		this.allEclipses = allEclipses;
	}

	/**
	 * Sets the all partners.
	 *
	 * @param allPartners the new all partners
	 */
	public void setAllPartners(List<Partner> allPartners) {
		// iterate over the partner list
		for (int i = 0; i < allPartners.size(); i++) {
			// extract the i-esim partner
			Partner p = allPartners.get(i);

			// if the partner has debts
			if (!p.getLoanList().isEmpty()) {
				// iterate over the debts list
				for (int j = 0; j < p.getLoanList().size(); j++) {
					// extract the j-esim debit
					DebitCard y = p.getLoanList().get(j);

					// mark as previously processed (created in the previous mh)
					y.setPrevious(true);
				}
			}

			// if the partner has credits
			if (!p.getGivenLoan().isEmpty()) {
				// iterate over the loan list
				for (int k = 0; k < p.getGivenLoan().size(); k++) {
					// extract the j-esim credit
					CreditCard z = p.getGivenLoan().get(k);

					// mark as previously processed (created in the previous mh)
					z.setPrevious(true);
				}
			}
			this.allPartnersAsMap.put(p.getPartnerId(), p);
		}
		this.allPartners = allPartners;

	}

	/**
	 * Sets the all PAWS.
	 *
	 * @param allPAWS the allPAWS to set
	 */
	public void setAllPAWS(List<PAW> allPAWS) {
		this.allPAWS = allPAWS;
	}

	/**
	 * Sets the all PDHT.
	 *
	 * @param allPDHT the allPDHT to set
	 */
	public void setAllPDHT(List<PDHT> allPDHT) {
		this.allPDHT = allPDHT;
	}

	/**
	 * Sets the all sat.
	 *
	 * @param allSat the allSat to set
	 */
	public void setAllSat(List<Satellite> allSat) {
		this.allSat = allSat;
	}

	/**
	 * Sets the all visibilities.
	 *
	 * @param allVisibilities the allVisibilities to set
	 */
	public void setAllVisibilities(List<Visibility> allVisibilities) {
		this.allVisibilities = allVisibilities;
	}

	/**
	 * Sets the current MH.
	 *
	 * @param currentMH the new current MH
	 */
	public void setCurrentMH(MissionHorizon currentMH) {
		this.currentMH = currentMH;
	}

	/**
	 * Sets the drl rules file.
	 *
	 * @param drlRulesFile the drlRulesFile to set
	 */
	public void setDrlRulesFile(String drlRulesFile) {
		this.drlRulesFile = drlRulesFile;
	}

	/**
	 * Sets the log 4 j file.
	 *
	 * @param log4jFile the new log 4 j file
	 */
	public void setLog4jFile(String log4jFile) {
		// System.out.println(log4jFile);
		this.log4jFile = log4jFile;
	}

	/**
	 * Sets the max hp bic fixed orbit.
	 *
	 * @param maxHpBicFixedOrbit the max hp bic fixed orbit
	 */
	public void setMaxHpBicFixedOrbit(Map<String, Map<Integer, Double>> maxHpBicFixedOrbit) {
		this.maxHpBicFixedOrbit = maxHpBicFixedOrbit;
	}

	/**
	 * Sets the number of satellites.
	 *
	 * @param numberOfSatellites the numberOfSatellites to set
	 */
	public void setNumberOfSatellites(int numberOfSatellites) {
		this.numberOfSatellites = numberOfSatellites;
	}

	/**
	 * Sets the number of sessions.
	 *
	 * @param numberOfSessions the numberOfSessions to set
	 */
	public void setNumberOfSessions(int numberOfSessions) {
		this.numberOfSessions = numberOfSessions;
	}

	/**
	 * Sets the pr type max number.
	 *
	 * @param prTypeMaxNumber the new pr type max number
	 */
	public void setPrTypeMaxNumber(int prTypeMaxNumber) {
		this.prTypeMaxNumber = prTypeMaxNumber;
	}

	/**
	 * Sets the responce file.
	 *
	 * @param responceFile the responceFile to set
	 */
	public void setResponceFile(String responceFile) {
		this.responceFile = responceFile;
	}

	/**
	 * Sets the satellite state.
	 *
	 * @param satelliteState the satelliteState to set
	 */
	public void setSatelliteState(List<SatelliteState> satelliteState) {
		this.satelliteState = satelliteState;
	}

	/**
	 * Gets the all CMGA.
	 *
	 * @return the all CMGA
	 */
	public List<CMGA> getAllCMGA() {
		return this.allCMGA;
	}

	/**
	 * Gets the cmga with id.
	 *
	 * @param allCmga the all cmga
	 * @param id      the id
	 * @param sat     the sat
	 * @return the cmga with id
	 */
	public CMGA getCmgaWithId(List<CMGA> allCmga, String id, String sat) {
		// declare a cmg
		CMGA returnedCMGA = null;

		// iterate over the list of cmg units
		for (int i = 0; i < allCmga.size(); i++) {
			// if the i-esim cmg is referred to the satellite with the id given
			// as input
			if (allCmga.get(i).getCmgaId().contains(id) && allCmga.get(i).getSatelliteId().contains(sat)) {
				// set the cmg that must be returned from this method with the
				// i.esim cmg
				returnedCMGA = allCmga.get(i);
			}
		}
		return returnedCMGA;
	}

	/**
	 * Sets the all CMGA.
	 *
	 * @param allCMGA the new all CMGA
	 */
	public void setAllCMGA(List<CMGA> allCMGA) {
		this.allCMGA = allCMGA;

		// if the list of cmg unit in input is not null and not empty
		if ((allCMGA != null) && !allCMGA.isEmpty()) {
			// invoke the function to set the ramp time for satellite 1
			double maxTaccSat1 = computeMaxRampTimeForSat(allCMGA, "1");

			// invoke the function to set the ramp time for satellite 2
			double maxTaccSat2 = computeMaxRampTimeForSat(allCMGA, "2");

			// set the ramp time computed above
			this.setMaxTaccSat1(maxTaccSat1);

			// set the ramp time computed above
			this.setMaxTaccSat2(maxTaccSat2);
		}
	}

	/**
	 * Compute max ramp time for sat.
	 *
	 * @param allCMGA the all CMGA
	 * @param satId   the sat id
	 * @return the double
	 */
	private double computeMaxRampTimeForSat(List<CMGA> allCMGA, String satId) {
		// initialize the max time for a ramp with the value associated with the
		// first
		double maxTacc = 0;

		// iterate over the cmg units
		for (int i = 1; i < allCMGA.size(); i++) {
			if (allCMGA.get(i).isOperative() && allCMGA.get(i).getSatelliteId().contains(satId)) {
				// if the i-esim cmg unit has a time for ramp bigger than the
				// maxTacc
				if (allCMGA.get(i).gettAcc() > maxTacc) {
					// set this new value as maxTacc
					maxTacc = allCMGA.get(i).gettAcc();
				}
			}
		}
		return maxTacc;

	}

	/**
	 * Gets the extra cost left.
	 *
	 * @return the extra cost left
	 */
	public double getExtraCostLeft() {
		return this.extraCostLeft;
	}

	/**
	 * Sets the extra cost left.
	 *
	 * @param extraCostLeft the new extra cost left
	 */
	public void setExtraCostLeft(double extraCostLeft) {
		this.extraCostLeft = extraCostLeft;
	}

	/**
	 * Gets the min time right.
	 *
	 * @return the min time right
	 */
	public TreeMap<Double, List<MinTimeRight>> getMinTimeRight() {
		return this.minTimeRight;
	}

	/**
	 * Sets the min time left.
	 *
	 * @param minTimeRight the min time right
	 */
	public void setMinTimeRight(TreeMap<Double, List<MinTimeRight>> minTimeRight) {
		this.minTimeRight = minTimeRight;
	}

	/**
	 * Gets the max tacc sat 1.
	 *
	 * @return the max tacc sat 1
	 */
	public double getMaxTaccSat1() {
		return this.maxTaccSat1;
	}

	/**
	 * Sets the max tacc sat 1.
	 *
	 * @param maxTaccSat1 the new max tacc sat 1
	 */
	public void setMaxTaccSat1(double maxTaccSat1) {
		this.maxTaccSat1 = maxTaccSat1;
	}

	/**
	 * Gets the max tacc sat 2.
	 *
	 * @return the max tacc sat 2
	 */
	public double getMaxTaccSat2() {
		return this.maxTaccSat2;
	}

	/**
	 * Gets the max tacc for sat.
	 *
	 * @param satId the sat id
	 * @return the max tacc for sat
	 */
	public double getMaxTaccForSat(String satId) {
		// initialize the returned value with the max tAcc for sat 1
		double returnedMaxTacc = this.getMaxTaccSat1();

		// if the satellite given in input contains sat 2
		if (satId.contains("2")) {
			// set the returned value with the max tAcc for sat 2
			returnedMaxTacc = this.getMaxTaccSat2();
		}
		return returnedMaxTacc;
	}

	/**
	 * Sets the max tacc sat 2.
	 *
	 * @param maxTaccSat2 the new max tacc sat 2
	 */
	public void setMaxTaccSat2(double maxTaccSat2) {
		this.maxTaccSat2 = maxTaccSat2;
	}

	/**
	 * Gets the tranquillization time.
	 *
	 * @return the tranquillization time
	 */
	public double getTranquillizationTime() {
		return this.tranquillizationTime;
	}

	/**
	 * Sets the tranquillization time.
	 *
	 * @param tranquillizationTime the new tranquillization time
	 */
	public void setTranquillizationTime(double tranquillizationTime) {
		this.tranquillizationTime = tranquillizationTime;
	}

	/**
	 * Gets the current session.
	 *
	 * @return the current session
	 */
	public String getCurrentSession() {
		return this.currentSession;
	}

	/**
	 * Sets the current session.
	 *
	 * @param currentSession the new current session
	 */
	public void setCurrentSession(String currentSession) {
		this.currentSession = currentSession;
	}

	/**
	 * Gets the split char.
	 *
	 * @return the split char
	 */
	public static String getSplitChar() {
		return splitChar;
	}

	/**
	 * Sets the split char.
	 *
	 * @param splitChar the new split char
	 */
	public void setSplitChar(String splitChar) {
		DroolsParameters.splitChar = splitChar;
	}

	/**
	 * Gets the purge sensor mode.
	 *
	 * @return the purgeSensorMode
	 */
	public List<TypeOfAcquisition> getPurgeSensorMode() {
		return this.purgeSensorMode;
	}

	/**
	 * Sets the purge sensor mode.
	 *
	 * @param purgeSensorMode the purgeSensorMode to set
	 */
	public void setPurgeSensorMode(List<TypeOfAcquisition> purgeSensorMode) {
		this.purgeSensorMode = purgeSensorMode;
	}

	/**
	 * Gets the pratica di mare id.
	 *
	 * @return the praticaDiMareId
	 */
	public String getPraticaDiMareId() {
		return this.praticaDiMareId;
	}

	/**
	 * Sets the pratica di mare id.
	 *
	 * @param praticaDiMareId the praticaDiMareId to set
	 */
	public void setPraticaDiMareId(String praticaDiMareId) {
		this.praticaDiMareId = praticaDiMareId;
	}

	/**
	 * Gets the GP sreservedpacket store PDM station.
	 *
	 * @return the gPSreservedpacketStorePDMStation
	 */
	public String getGPSreservedpacketStore() {
		return this.GPSreservedpacketStore;
	}

	/**
	 * Gets the space wire for gps.
	 *
	 * @return the spaceWireForGps
	 */
	public double getSpaceWireForGps() {
		return this.spaceWireForGps;
	}

	/**
	 * Sets the space wire for gps.
	 *
	 * @param spaceWireForGps the spaceWireForGps to set
	 */
	public void setSpaceWireForGps(double spaceWireForGps) {
		this.spaceWireForGps = spaceWireForGps;
	}

	/**
	 * Gets the gps always planned on link.
	 *
	 * @return the gpsAlwaysPlannedOnLink
	 */
	public String getGpsAlwaysPlannedOnLink() {
		return this.gpsAlwaysPlannedOnLink;
	}

	/**
	 * Sets the gps always planned on link.
	 *
	 * @param gpsAlwaysPlannedOnLink the gpsAlwaysPlannedOnLink to set
	 */
	public void setGpsAlwaysPlannedOnLink(String gpsAlwaysPlannedOnLink) {
		this.gpsAlwaysPlannedOnLink = gpsAlwaysPlannedOnLink;
	}

	/**
	 * Gets the minutes for orbit.
	 *
	 * @return the minutesForOrbit
	 */
	public int getMinutesForOrbit() {
		return this.minutesForOrbit;
	}

	/**
	 * Sets the minutes for orbit.
	 *
	 * @param minutesForOrbit the minutesForOrbit to set
	 */
	public void setMinutesForOrbit(int minutesForOrbit) {
		this.minutesForOrbit = minutesForOrbit;
	}

	/**
	 * Gets the time for maneuver cmga.
	 *
	 * @return the timeForManeuverCmga
	 */
	public int getTimeForManeuverCmga() {
		return this.timeForManeuverCmga;
	}

	/**
	 * Sets the time for maneuver cmga.
	 *
	 * @param timeForManeuverCmga the timeForManeuverCmga to set
	 */
	public void setTimeForManeuverCmga(int timeForManeuverCmga) {
		this.timeForManeuverCmga = timeForManeuverCmga;
	}

	/**
	 * Gets the time for maneuver RW.
	 *
	 * @return the timeForManeuverRW
	 */
	public int getTimeForManeuverRW() {
		return this.timeForManeuverRW;
	}

	/**
	 * Sets the time for maneuver RW.
	 *
	 * @param timeForManeuverRW the timeForManeuverRW to set
	 */
	public void setTimeForManeuverRW(int timeForManeuverRW) {
		this.timeForManeuverRW = timeForManeuverRW;
	}

	/**
	 * Gets the powers with U lvalues.
	 *
	 * @return the powersWithULvalues
	 */
	public List<LowerAndUpperBoundPowers> getPowersWithULvalues() {
		return this.powersWithULvalues;
	}

	/**
	 * Sets the powers with U lvalues.
	 *
	 * @param powersWithULvalues the powersWithULvalues to set
	 */
	public void setPowersWithULvalues(List<LowerAndUpperBoundPowers> powersWithULvalues) {
		this.powersWithULvalues = powersWithULvalues;
	}

	/**
	 * Gets the power associated with sensor mode UL.
	 *
	 * @param sensorMode the sensor mode
	 * @param lowerBound the lower bound
	 * @return the power associated with sensor mode UL
	 */
	public double getPowerAssociatedWithSensorModeUL(TypeOfAcquisition sensorMode, boolean lowerBound) {
		double powerAssociated = 0;

		// iterate over the special powers
		for (int i = 0; i < this.powersWithULvalues.size(); i++) {
			// if the i-esim power is related to the sensor mode given as input
			if (this.powersWithULvalues.get(i).getSensorMode().equals(sensorMode)
					&& (this.powersWithULvalues.get(i).isLowerBound() == lowerBound)) {
				// extract the power associated
				powerAssociated = this.powersWithULvalues.get(i).getPowerAssociated();
				break;
			}
		}
		return powerAssociated;
	}

	/**
	 * Gets the refd 2 DI 2 S.
	 *
	 * @return the refd2_DI2S
	 */
	public double getRefd2_DI2S() {
		return this.refd2_DI2S;
	}

	/**
	 * Sets the refd 2 DI 2 S.
	 *
	 * @param refd2_DI2S the refd2_DI2S to set
	 */
	public void setRefd2_DI2S(double refd2_DI2S) {
		this.refd2_DI2S = refd2_DI2S;
	}

	/**
	 * Gets the refd 1 DI 2 S.
	 *
	 * @return the refd1_DI2S
	 */
	public double getRefd1_DI2S() {
		return this.refd1_DI2S;
	}

	/**
	 * Sets the refd 1 DI 2 S.
	 *
	 * @param refd1_DI2S the refd1_DI2S to set
	 */
	public void setRefd1_DI2S(double refd1_DI2S) {
		this.refd1_DI2S = refd1_DI2S;
	}

	/**
	 * Gets the powers sensor mode.
	 *
	 * @return the powersSensorMode
	 */
	public Map<TypeOfAcquisition, Double> getPowersSensorMode() {
		return this.powersSensorMode;
	}

	/**
	 * Sets the powers sensor mode.
	 *
	 * @param powersSensorMode the powersSensorMode to set
	 */
	public void setPowersSensorMode(Map<TypeOfAcquisition, Double> powersSensorMode) {
		this.powersSensorMode = powersSensorMode;
	}

	/**
	 * Gets the last acq.
	 *
	 * @return the lastAcq
	 */
	public static Acquisition getLastAcq() {
		return lastAcq;
	}

	/**
	 * Sets the last acq.
	 *
	 * @param lastAcq the lastAcq to set
	 */
	public static void setLastAcq(Acquisition lastAcq) {
		DroolsParameters.lastAcq = lastAcq;
	}

	/**
	 * Gets the idugsid.
	 *
	 * @return the idugsid
	 */
	public String getIdugsid() {
		return this.idugsid;
	}

	/**
	 * Sets the idugsid.
	 *
	 * @param idugsid the idugsid to set
	 */
	public void setIdugsid(String idugsid) {
		this.idugsid = idugsid;
	}

	/**
	 * Gets the disable GPS.
	 *
	 * @return the disableGPS
	 */
	public String getDisableGPS() {
		return this.disableGPS;
	}

	/**
	 * Sets the disable GPS.
	 *
	 * @param disableGPS the disableGPS to set
	 */
	public void setDisableGPS(String disableGPS) {
		this.disableGPS = disableGPS;
	}

	/**
	 * Gets the last acq for session.
	 *
	 * @return the lastAcqForSession
	 */
	public static HashMap<String, Acquisition> getLastAcqForSession() {
		return lastAcqForSession;
	}

	/**
	 * Checks if is disable check left attitude.
	 *
	 * @return true, if is disable check left attitude
	 */
	public boolean isDisableCheckLeftAttitude() {
		return this.disableCheckLeftAttitude;
	}

	/**
	 * Sets the disable check left attitude.
	 *
	 * @param disableCheckLeftAttitude the new disable check left attitude
	 */
	public void setDisableCheckLeftAttitude(String disableLeft) {
		if (disableLeft.equalsIgnoreCase("1")) {
			this.disableCheckLeftAttitude = true;
		}
	}

	/**
	 * Gets the local repo.
	 *
	 * @return the local repo
	 */
	public String getLocalRepo() {
		return this.localRepo;
	}

	/**
	 * Sets the local repo.
	 *
	 * @param localRepo the new local repo
	 */
	public void setLocalRepo(String localRepo) {
		this.localRepo = localRepo;
	}

	/**
	 * Gets the reason of reject map.
	 *
	 * @return the reason of reject map
	 */
	public static Map<ReasonOfReject, ComplexReason> getReasonOfRejectMap() {
		return reasonOfRejectMap;
	}

	/**
	 * Sets the reason of reject map.
	 *
	 * @param reasonOfRejectMap the reason of reject map
	 */
	public static void setReasonOfRejectMap(Map<ReasonOfReject, ComplexReason> reasonOfRejectMap) {
		DroolsParameters.reasonOfRejectMap = reasonOfRejectMap;
	}

	/**
	 * Concatenate session.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the string
	 */
	public static String concatenateSession(String currentSession, int currentInstance) {
		return currentSession + "_" + currentInstance;
	}

	/**
	 * Gets the all partners as map.
	 *
	 * @return the all partners as map
	 */
	public TreeMap<String, Partner> getAllPartnersAsMap() {
		return this.allPartnersAsMap;
	}

	/**
	 * Sets the all partners as map.
	 *
	 * @param allPartnersAsMap the all partners as map
	 */
	public void setAllPartnersAsMap(TreeMap<String, Partner> allPartnersAsMap) {
		this.allPartnersAsMap = allPartnersAsMap;
	}

	/**
	 * Checks if is download triggered from CSPS.
	 *
	 * @return true, if is download triggered from CSPS
	 */
	public boolean isDownloadTriggeredFromCSPS() {
		return this.downloadTriggeredFromCSPS;
	}

	/**
	 * Sets the download triggered from CSPS.
	 *
	 * @param downloadTriggeredFromCSPS the new download triggered from CSPS
	 */
	public void setDownloadTriggeredFromCSPS(boolean downloadTriggeredFromCSPS) {
		this.downloadTriggeredFromCSPS = downloadTriggeredFromCSPS;
	}

	/**
	 * Gets the matera id.
	 *
	 * @return the matera id
	 */
	public String getMateraId() {
		return this.materaId;
	}

	/**
	 * Sets the matera id.
	 *
	 * @param materaId the new matera id
	 */
	public void setMateraId(String materaId) {
		this.materaId = materaId;
	}

	/**
	 * Checks if is previous mh.
	 *
	 * @return true, if is previous mh
	 */
	public boolean isPreviousMh() {
		return this.previousMh;
	}

	/**
	 * Sets the previous mh.
	 *
	 * @param previousMh the new previous mh
	 */
	public void setPreviousMh(boolean previousMh) {
		this.previousMh = previousMh;
	}

	/**
	 * Gets the last position gps pdm.
	 *
	 * @return the lastPositionGpsPdm
	 */
	public int getLastPositionGpsPdm() {
		return lastPositionGpsPdm;
	}

	/**
	 * Sets the last position gps pdm.
	 *
	 * @param lastPositionGpsPdm the lastPositionGpsPdm to set
	 */
	public void setLastPositionGpsPdm(int lastPositionGpsPdm) {
		this.lastPositionGpsPdm = lastPositionGpsPdm;
	}

	/**
	 * Gets the last position gps ext.
	 *
	 * @return the lastPositionGpsExt
	 */
	public int getLastPositionGpsExt() {
		return lastPositionGpsExt;
	}

	/**
	 * Sets the last position gps ext.
	 *
	 * @param lastPositionGpsExt the lastPositionGpsExt to set
	 */
	public void setLastPositionGpsExt(int lastPositionGpsExt) {
		this.lastPositionGpsExt = lastPositionGpsExt;
	}
}
