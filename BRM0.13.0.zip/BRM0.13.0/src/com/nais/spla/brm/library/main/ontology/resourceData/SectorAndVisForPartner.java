/**
*
* MODULE FILE NAME:	SectorAndVisForPartner.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		03 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 03 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class SectorAndVisForPartner.
 *
 * @author francesca
 */
public class SectorAndVisForPartner implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The all vis for partner. */
	private List<String> allVisForPartner;

	/** The sectors for partner. */
	List<SizeOfSectorDwl> sectorsForPartner;

	/**
	 * Instantiates a new sector and vis for partner.
	 *
	 * @param allVisForPartner  the all vis for partner
	 * @param sectorsForPartner the sectors for partner
	 */
	public SectorAndVisForPartner(List<String> allVisForPartner, List<SizeOfSectorDwl> sectorsForPartner) {
		super();
		this.allVisForPartner = allVisForPartner;
		this.sectorsForPartner = sectorsForPartner;
	}

	/**
	 * Gets the sectors for partner.
	 *
	 * @return the sectorsForPartner
	 */
	public List<SizeOfSectorDwl> getSectorsForPartner() {
		return this.sectorsForPartner;
	}

	/**
	 * method to Sring.
	 *
	 * @return the string with all the info about the userInfo
	 */
	@Override
	public String toString() {
		return "SectorAndVisForPartner [allVisForPartner=" + this.allVisForPartner + ", sectorsForPartner="
				+ this.sectorsForPartner + "]";
	}

}
