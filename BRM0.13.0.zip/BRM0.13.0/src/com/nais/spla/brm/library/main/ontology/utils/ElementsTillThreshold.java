/**
 *
 * MODULE FILE NAME: ElementsTillThreshold.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.utils;

import java.util.List;

/**
 * The Class ElementsTillThreshold.
 */
public class ElementsTillThreshold {

	/** The reached value. */
	private double reachedValue;

	/** The elements checked. */
	private List<String> elementsChecked;

	/**
	 * Instantiates a new elements till threshold.
	 */
	public ElementsTillThreshold() {
		super();
	}

	/**
	 * Instantiates a new elements till threshold.
	 *
	 * @param reachedValue    the reached value
	 * @param elementsChecked the elements checked
	 */
	public ElementsTillThreshold(double reachedValue, List<String> elementsChecked) {
		super();
		// set the max value reached
		this.reachedValue = reachedValue;

		// set the list of checked elements
		this.elementsChecked = elementsChecked;
	}

	/**
	 * Gets the elements checked.
	 *
	 * @return the elements checked
	 */
	public List<String> getElementsChecked() {
		return this.elementsChecked;
	}

	/**
	 * Sets the elements checked.
	 *
	 * @param elementsChecked the new elements checked
	 */
	public void setElementsChecked(List<String> elementsChecked) {
		this.elementsChecked = elementsChecked;
	}

	/**
	 * Gets the reached value.
	 *
	 * @return the reached value
	 */
	public double getReachedValue() {
		return this.reachedValue;
	}

	/**
	 * Sets the reached value.
	 *
	 * @param reachedValue the new reached value
	 */
	public void setReachedValue(double reachedValue) {
		this.reachedValue = reachedValue;
	}

}
