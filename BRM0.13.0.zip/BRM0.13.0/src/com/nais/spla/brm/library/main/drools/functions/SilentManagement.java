/**
*
* MODULE FILE NAME:	SilentManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		18 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.utils.ElementsTillThreshold;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

/**
 * The Class SilentManagement.
 *
 * @author fpedrola
 */

public class SilentManagement {

	/** The du. */
	DroolsUtils du = new DroolsUtils();

	/**
	 * Compute silent energy.
	 *
	 * @param sil               the sil
	 * @param acqAssociated     the acq associated
	 * @param droolsParams      the drools params
	 * @param satProp           the sat prop
	 * @param resourceFunctions the resource functions
	 * @return true, if successful
	 */
	public boolean computeSilentEnergy(Silent sil, Acquisition acqAssociated, DroolsParameters droolsParams,
			SatelliteProperties satProp, ResourceFunctions resourceFunctions) {
		// initialize a reason of
		// reject with noEnergyForSilent
		ReasonOfReject potentialReasonOfReject = ReasonOfReject.noEnergyForSilent;

		// get the logger
		Logger logger = DroolsParameters.getLogger();
		double maxThresholdValue = 0;
		boolean needALoan = false;
		boolean acceptedSil = false;

		// get the silent function TreeMap
		TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions
				.getSilentFunctionAssociatedToSat(acqAssociated.getSatelliteId());
		// get the acquisition function TreeMap
		TreeMap<Long, EnergyAssociatedToTask> hashMapEss = resourceFunctions
				.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());

		// get the map with all
		// the checks on orbits
		Map<Double, ResourceMaxValue> allChecksOnOrbits = satProp.getAllChecksOnOrbits();
		TreeMap<Double, Double> maxValuesSW = new TreeMap<>();

		// initialize maxLoanForOrbitToCheck
		double maxLoanForOrbitToCheck = -1;
		double orbitThatNeedALoanEss = -1;
		double thresholdEssRelatedToOrbitThatNeedALoan = -1;
		double checkOnOrbit = 0;

		// insert into silent function
		silentFunction.put(sil.getStartTime().getTime(), new EnergyAssociatedToTask(sil, sil.getEnergy()));

		// iterate over all the checks
		for (Map.Entry<Double, ResourceMaxValue> map : allChecksOnOrbits.entrySet()) {
			// get the orbit
			checkOnOrbit = map.getKey();

			// get all the constraint for the orbit
			ResourceMaxValue valuesAssociatedToOrbit = map.getValue();
			// logger.debug("SILENT_RULE_ checking if silent constraints are
			// satisfied for orbit " + checkOnOrbit);
			// logger.debug("SILENT_RULE_ with max value of silent " +
			// valuesAssociatedToOrbit.getMaxSilent());

			// extract the ess threshold value
			maxThresholdValue = valuesAssociatedToOrbit.getMaxThreshold();

			// extract the silent threshold value
			double maxSilentValue = valuesAssociatedToOrbit.getMaxSilent();

			// if the check must be
			// performed (-1 means skip)
			if (maxSilentValue > -1) {
				// if the acq is in eclipse
				if (acqAssociated.isInEclipse()) {
					// set the reason of reject
					potentialReasonOfReject = ReasonOfReject.noEnergyForSilentInEclipse;

					// get percentage eclipse
					double maxPercEclipseAvailable = satProp.getMaxPercEclipseAvailable();

					// compute max threshold ess
					maxThresholdValue = (maxThresholdValue / 100.0) * (100 - maxPercEclipseAvailable);

					// compute max threshold silent
					maxSilentValue = (long) ((maxSilentValue / 100.0) * (100 - maxPercEclipseAvailable));
					// logger.debug("SILENT_RULE_ acq is in eclipse period , max
					// threshold is reduced : " + maxThresholdValue);
					// logger.debug("SILENT_RULE_ acq is in eclipse period , max
					// silent is reduced : " + maxSilentValue);
				}
				long slidingWindowsToCheck = (long) (checkOnOrbit * droolsParams.getMinutesForOrbit() * 60000);

				// compute maxSilInInterval
				double maxSilInInterval = calculateMaxSilentInInterval(potentialReasonOfReject, checkOnOrbit, logger,
						acqAssociated, sil, maxSilentValue, slidingWindowsToCheck, silentFunction, resourceFunctions);

				// valid maxSilInInterval
				if (maxSilInInterval > 0) {// add to the map
					maxValuesSW.put(maxSilInInterval, checkOnOrbit);
				}
			}
		}
		// if there is at least a value in map
		if (!maxValuesSW.isEmpty()) {
			// silent needs a loan from essx
			needALoan = true;
			// logger.debug("SILENT_RULE_ at least a check on orbit has
			// failed");
			// compute energy to request as loan
			double exceededEnergy = maxValuesSW.lastKey();
			// logger.debug("SILENT_RULE_ exceeded energy : " + exceededEnergy);

			if (exceededEnergy > maxLoanForOrbitToCheck) {
				maxLoanForOrbitToCheck = exceededEnergy;
				// orbitThatNeedALoanEss
				orbitThatNeedALoanEss = maxValuesSW.get(exceededEnergy);
				// thresholdEssRelatedToOrbitThatNeedALoan
				thresholdEssRelatedToOrbitThatNeedALoan = allChecksOnOrbits.get(orbitThatNeedALoanEss)
						.getMaxThreshold();
			}
		}

		// if is necessary a loan
		if (needALoan) {
			// invoke the method to check
			// if is possible to have a loan
			boolean availableEss = checkIfLoanIsSatisfiable(droolsParams, maxLoanForOrbitToCheck, orbitThatNeedALoanEss,
					hashMapEss, acqAssociated, thresholdEssRelatedToOrbitThatNeedALoan,
					droolsParams.getMinutesForOrbit(), potentialReasonOfReject);
			// is possible
			if (availableEss) {
				sil.setLoanFromEss(maxLoanForOrbitToCheck);
				hashMapEss.put(acqAssociated.getStartTime().getTime(),
						new EnergyAssociatedToTask(acqAssociated, acqAssociated.getEss() + maxLoanForOrbitToCheck));
				// accepted
				acceptedSil = true;
				// add to treemap function
				silentFunction.put(sil.getStartTime().getTime(),
						new EnergyAssociatedToTask(sil, sil.getEnergy() - maxLoanForOrbitToCheck));

			}
			// impossible have loan
			else {
				// not accepted
				acceptedSil = false;
			}
		} else {
			// accepted
			acceptedSil = true;
			// add to treemap function
			silentFunction.put(sil.getStartTime().getTime(), new EnergyAssociatedToTask(sil, sil.getEnergy()));
		}
		return acceptedSil;
	}

	/**
	 * Calculate max silent in interval.
	 *
	 * @param potentialReasonOfReject the potential reason of reject
	 * @param checkOnOrbit            the check on orbit
	 * @param logger                  the logger
	 * @param acq                     the acq
	 * @param sil                     the sil
	 * @param maxSilent               the max silent
	 * @param slidingWindow           the sliding window
	 * @param silentFunction          the silent function
	 * @param resourceFunctions       the resource functions
	 * @return the map
	 */
	public Double calculateMaxSilentInInterval(ReasonOfReject potentialReasonOfReject, double checkOnOrbit,
			Logger logger, Acquisition acq, Silent sil, double maxSilent, long slidingWindow,
			TreeMap<Long, EnergyAssociatedToTask> silentFunction, ResourceFunctions resourceFunctions) {
		// initialize returnedValues
		double returnedValues = 0;

		// initialize maxLoanTot
		double maxLoanTot = 0;

		// initialize exceeded
		boolean exceeded = false;

		// initialize start time as loan
		long from = sil.getStartTime().getTime();

		// initialize stop time a loan
		long to = sil.getStartTime().getTime() + slidingWindow;

		// at least an element in function
		if (!silentFunction.isEmpty()) {
			// get the submap
			NavigableMap<Long, EnergyAssociatedToTask> subMap = silentFunction.subMap(from, true, to, true);
			// if the submap has at least an element
			if (!subMap.isEmpty()) {// compute the amount of energy used in submap
				ElementsTillThreshold extractedTotEnergy = resourceFunctions.calculateLocalMax(from, to,
						silentFunction);
				// logger.debug("SILENT_RULE_ total energy used in interval : "
				// + extractedTotEnergy.getReachedValue());

				// reached silent threshold
				if (maxSilent < (extractedTotEnergy.getReachedValue())) {

					// compute the amount of loan
					maxLoanTot = (extractedTotEnergy.getReachedValue() - maxSilent);

					// if the computed loan exceed the single silent energy
					if (maxLoanTot > sil.getEnergy()) {
						// set the loan with only the silent energy
						maxLoanTot = sil.getEnergy();
					}

					// mark the variabled to true
					// to indicate that there is a
					// silent threshold violation
					exceeded = true;
				}

				// iterate over the elements in submap
				for (Map.Entry<Long, EnergyAssociatedToTask> entry : subMap.entrySet()) {
					// extract the i-esim silent
					Silent extractedSilent = (Silent) entry.getValue().getTask();

					// update start time of check
					long localFrom = extractedSilent.getEndTime().getTime() - slidingWindow;

					// update stop time of check
					long localTo = extractedSilent.getEndTime().getTime();
					// logger.debug("SILENT_RULE_ on sliding window that starts
					// at : " + new Date(localFrom));
					// logger.debug("SILENT_RULE_ and ends at : " + new
					// Date(localTo));
					// get the max silent used
					extractedTotEnergy = resourceFunctions.calculateLocalMax(localFrom, localTo, silentFunction);
					// logger.debug("SILENT_RULE_ total energy used in interval
					// : " + extractedTotEnergy.getReachedValue());
					// logger.debug("SILENT_RULE_ elements found in interval : "
					// + extractedTotEnergy.getElementsChecked());

					// silent threshold
					if (maxSilent < extractedTotEnergy.getReachedValue()) {
						maxLoanTot = (extractedTotEnergy.getReachedValue() - maxSilent);
						// if the computed loan exceed the single silent energy

						if (maxLoanTot > sil.getEnergy()) {
							// set the loan with only the silent energy
							maxLoanTot = sil.getEnergy();
						}
						// mark the variabled to true
						// to indicate that there is a
						// silent threshold violation
						exceeded = true;
					}
				}
			}
		}
		// if there is a silent threshold
		if (exceeded) {
			// return the max loan
			returnedValues = maxLoanTot;
			// logger.debug("SILENT_RULE_ exceeded in silent energy");
		}
		return returnedValues;
	}

	/**
	 * Check if loan is satisfiable.
	 *
	 * @param droolsParams            the drools params
	 * @param requestedAmount         the requested amount
	 * @param orbit                   the orbit
	 * @param hashMapEss              the hash map ess
	 * @param acqAssociated           the acq associated
	 * @param threshold               the threshold
	 * @param minutesForOrbit         the minutes for orbit
	 * @param potentialReasonOfReject the potential reason of reject
	 * @return true, if successful
	 */
	public boolean checkIfLoanIsSatisfiable(DroolsParameters droolsParams, double requestedAmount, double orbit,
			TreeMap<Long, EnergyAssociatedToTask> hashMapEss, Acquisition acqAssociated, double threshold,
			int minutesForOrbit, ReasonOfReject potentialReasonOfReject) {
		// compute the sliding window to check
		long slidingWindowsToCheck = (long) (minutesForOrbit * orbit * 60000);

		// initilize the resource function
		ResourceFunctions resourceFunc = new ResourceFunctions();
		boolean loanAvailable = false;

		// initialize the submap for energy
		Map<Long, EnergyAssociatedToTask> subMap = new HashMap<>();
		ElementsTillThreshold totalUsed = new ElementsTillThreshold();

		// set the start time of the interval
		long from = acqAssociated.getStartTime().getTime();

		// set the stop time of the interval
		long to = acqAssociated.getStartTime().getTime() + slidingWindowsToCheck;

		// create the submap for collect
		// all the elements into the interval
		subMap = hashMapEss.subMap(from, true, to, true);
		int cont = 0;

		// there aren't elements in interval
		if (subMap.size() == 0) {
			// requested amount is
			// less than threshold
			if (threshold > requestedAmount) {
				// can make a loan
				loanAvailable = true;
			}
		}

		// if there is at least an element
		else {
			// iterate over the elements
			for (Map.Entry<Long, EnergyAssociatedToTask> entry : subMap.entrySet()) {
				// extract he i-esim acq
				Acquisition acq = (Acquisition) entry.getValue().getTask();

				// update the start time to check
				long fromLocal = acq.getEndTime().getTime() - slidingWindowsToCheck;

				// update the end time to check
				long toLocal = acq.getEndTime().getTime();

				// get the total used ess
				totalUsed = resourceFunc.calculateLocalMax(fromLocal, toLocal, hashMapEss);
				cont++;

				// cannot make a loan
				if ((totalUsed.getReachedValue()) > threshold) {
					// set the boolean variable to false
					loanAvailable = false;

					// get all elements involved
					List<String> elementsInvolved = this.du.getAllElementsInvolved(fromLocal, toLocal, hashMapEss);

					// check the correct reason
					if (potentialReasonOfReject.equals(ReasonOfReject.noEnergyForSilent)) {
						// add reason of reject noEnergyForSilent
						acqAssociated.addReasonOfReject(33, ReasonOfReject.noEnergyForSilent,
								"Reached Equivalent Stripmap Second Threshold For Silent", orbit, cont,
								elementsInvolved);
					} else {
						// add reason of reject noEnergyForSilentInEclipse
						acqAssociated.addReasonOfReject(28, ReasonOfReject.noEnergyForSilentInEclipse,
								"Reached Equivalent Stripmap Second Threshold For Silent In Eclipse Period", orbit,
								cont, elementsInvolved);
					}
					// exit
					break;
				} else {
					// all done
					loanAvailable = true;
				}
			}
		}
		return loanAvailable;
	}

	/**
	 * Creates the silent.
	 *
	 * @param current          the current
	 * @param previous         the previous
	 * @param droolsParams     the drools params
	 * @param powersSensorMode the powers sensor mode
	 * @param tStandard        the t standard
	 * @param tThreshold       the t threshold
	 * @return the silent
	 */
	public Silent createSilent(Acquisition current, Acquisition previous, DroolsParameters droolsParams,
			Map<TypeOfAcquisition, Double> powersSensorMode,
			Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tStandard,
			Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tThreshold) {
		// get the satellite properties relative
		// to the satellite linked with the acq
		SatelliteProperties satProp = droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties();

		// get the silent factor
		double silentFactor = satProp.getSilentFactor();

		// initialize all variables needed for computation
		double actualTSilent = 0;
		double gapAsDouble = 0;
		double tReconf = 0;
		double actualTThreshold = 0;
		double actualTStandard = 0;
		double silentEnergy = 0;
		long startTime = 0;

		// create a new silent
		Silent newSilent = null;

		// if there is a previous
		if (previous != null) {
			// logger.debug("SILENT_RULE_ find previous acq : " +
			// previous.getId() + " | startTime : " + previous.getStartTime() +
			// " | stopTime : " + previous.getEndTime());
			// compute the gap with prev
			Long gap = (current.getStartTime().getTime() - previous.getEndTime().getTime());

			// cast to double
			gapAsDouble = gap.doubleValue();
			// logger.debug("SILENT_RULE_ gap between previous and current :" +
			// (gapAsDouble / 1000));

			// logger.debug("tthreshold : " + tThreshold);

			// get threshold time between prev and current
			actualTThreshold = tThreshold.get(previous.getSensorMode()).get(current.getSensorMode());
			// logger.debug("SILENT_RULE_ minimum threshold between previous ("
			// + previous.getSensorMode() + ") and current (" +
			// current.getSensorMode() + ") : " + actualTThreshold);

			// if gap is less than threshold
			if ((gap / 1000) < actualTThreshold) {
				// the silent is the gap
				actualTSilent = gapAsDouble / 1000;
				// logger.debug("SILENT_RULE_ TSilent is gap : " +
				// actualTSilent);
			}
			// if gap is more than threshold
			else {
				// get threshold time between prev and current
				actualTStandard = tStandard.get(previous.getSensorMode()).get(current.getSensorMode());
				// logger.debug("SILENT_RULE_ TSilent is standard : " +
				// actualTStandard);

				// the silent is the standard time
				actualTSilent = actualTStandard; // before the satellite is in
													// heater state
			}
		} else {
			// logger.debug("SILENT_RULE there isn't a previous acq ");
			// get t reconf
			tReconf = tStandard.get(current.getSensorMode()).get(current.getSensorMode());
			// logger.debug("SILENT_RULE creating silent based on the standard
			// time from current (" + current.getSensorMode() + ") to itself : "
			// + tReconf);

			// silent sime is tReconf
			actualTSilent = tReconf;
		}
		// logger.debug("SILENT_RULE_ silent factor : " + silentFactor);
		// compute silent energy
		silentEnergy = (actualTSilent * silentFactor);
		// logger.debug("SILENT_RULE_ energy of silent : " + silentEnergy);

		// reate a new silent
		newSilent = new Silent(current.getId(), silentEnergy);

		// set id task
		newSilent.setIdTask(current.getId());

		// set end time
		newSilent.setEndTime(current.getStartTime());

		// set satelliteId
		newSilent.setSatelliteId(current.getSatelliteId());

		// sxet start time
		startTime = (long) (newSilent.getEndTime().getTime() - (actualTSilent * 1000));
		newSilent.setStartTime(new Date(startTime));
		return newSilent;
	}

	/**
	 * Gets the maximum value of loan for silent.
	 *
	 * @param maxValuesSW the max values SW
	 * @return the maximum value of loan for silent
	 */
	public double getMaximumValueOfLoanForSilent(List<Double> maxValuesSW) {
		// initialize maxinum
		double maximum = 0;

		// iterate over all the collected values
		for (int i = 0; i < maxValuesSW.size(); i++) {
			// if there isx a new maximum
			if (maximum < maxValuesSW.get(i)) {
				// update max
				maximum = maxValuesSW.get(i);
			}
			// no new max
			else {
				// check next
				continue;
			}
		}
		return maximum;
	}

	/**
	 * Removes the silent.
	 *
	 * @param silent         the silent
	 * @param acqRelated     the acq related
	 * @param silentFunction the silent function
	 * @param essFunction    the ess function
	 */
	public void removeSilent(Silent silent, Acquisition acqRelated,
			TreeMap<Long, EnergyAssociatedToTask> silentFunction, TreeMap<Long, EnergyAssociatedToTask> essFunction) {
		// remove the silent from the silent treemap
		silentFunction.remove(silent.getStartTime().getTime());

		// if the silent was linked to ess with a loan
		if (silent.getLoanFromEss() > 0) {
			// get the EnergyAssociatedToTask of the associated acquisition task
			EnergyAssociatedToTask energyAssociated = essFunction.get(acqRelated.getStartTime().getTime());

			// restore the energy into the treemap with the only ess of the acq,
			// without the loan
			energyAssociated.setEssValue(acqRelated.getEss());
		}
	}

}
