
package com.nais.spla.brm.library.main.drools.functions.DI2SManagement;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class Di2sManagement.
 */
public class Di2sManagement {

	/**
	 * Insert di 2 s.
	 *
	 * @param droolsParams    the drools params
	 * @param equivalentDto   the equivalent dto
	 * @param totalBic        the total bic
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public boolean insertDi2s(DroolsParameters droolsParams, EquivalentDTO equivalentDto, double totalBic,
			String currentSession, int currentInstance) {

		/*
		 * get the logger
		 */
		Logger logger = DroolsParameters.getLogger();

		DroolsOperations droolsOp = new DroolsOperations();
		boolean performed = false;
		DroolsUtils du = new DroolsUtils();
		logger.debug("DI2S_PROCEDURE: performing di2s procedure...");

		try {
			/*
			 * concatenate the current session
			 */
			String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

			/*
			 * get the current kieSession of Drools
			 */
			if (SessionHandler.getKieSessionsMap().get(sessionInstance) != null) {
				/*
				 * get the current kieSession of Drools
				 */
				KieSession currentKieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
				/*
				 * get all the rejected elements from current session
				 */
				Map<String, Object> rejected = (Map<String, Object>) currentKieSession.getGlobal("rejected");

				/*
				 * if the equivalentDTo is a DI2S
				 */
				if (equivalentDto.getEquivType().equals(PRMode.DI2S)) {
					logger.debug("DI2S_PROCEDURE: performing di2s procedure , get master dto inside the equivalentDto");
					equivalentDto.setSatelliteId(equivalentDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

					/*
					 * get the element that works as master
					 */
					DTO master = equivalentDto.getAllDtoInEquivalentDto().get(0);
					logger.debug("DI2S_PROCEDURE: the master dto is : " + master);

					DTO slave = null;
					if (equivalentDto.getDi2sInfo().getSlaveDto() != null) {
						slave = equivalentDto.getDi2sInfo().getSlaveDto();

						logger.debug("DI2S_PROCEDURE: the slave dto is : " + slave);

						/*
						 * set the correct start and stop for the equivalent dto
						 */
						equivalentDto.setStartAndStop();

						/*
						 * get the id of the master
						 */
						List<String> listMaster = du.getPartnerIdFromUserInfo(master);

						List<String> listSlave = du.getPartnerIdFromUserInfo(slave);

						logger.debug(
								"DI2S_PROCEDURE: the master  : " + equivalentDto.getDi2sInfo().getRelativeMasterId());

						logger.debug("DI2S_PROCEDURE: the slave : " + equivalentDto.getDi2sInfo().getRelativeSlaveId());

						boolean retractedmaster = false;

						logger.debug("DI2S_PROCEDURE: retract the master if is present in Drools : " + master);
						/*
						 * retract the master if is present in Drools
						 */
						retractedmaster = retractMaster(master, droolsParams, currentSession, currentInstance);

						master.setPrMode(PRMode.DI2S);
						master.setImageBIC(totalBic);
						master.setDi2s(true);

						/*
						 * precheck on bic for master
						 */
						boolean bicAvailableForMaster = droolsOp.checkIfDi2sIsFeasible(master, listMaster, false,
								droolsParams);

						/*
						 * precheck on bic for slave
						 */
						boolean bicAvailableForSlave = droolsOp.checkIfDi2sIsFeasible(master, listSlave, true,
								droolsParams);

						/*
						 * if there are enough bic for both master and slave
						 */
						if (bicAvailableForMaster && bicAvailableForSlave) {
							// insert the equivalent dto and the related
							// di2sInfo in
							// Drools
							logger.debug("inserting DI2sInfo : " + equivalentDto.getDi2sInfo());
							currentKieSession.insert(equivalentDto.getDi2sInfo());
							currentKieSession.insert(equivalentDto.getAllDtoInEquivalentDto().get(0));
							logger.debug("inserting Di2s : " + equivalentDto.getAllDtoInEquivalentDto().get(0));

							/*
							 * invoke the fireAllRules to trigger the rules
							 */
							currentKieSession.fireAllRules();

							/*
							 * if the equivalent dto is rejected
							 */
							if (!rejected.isEmpty() && rejected
									.containsKey(equivalentDto.getAllDtoInEquivalentDto().get(0).getDtoId())) {
								if (!retractedmaster) {
									/*
									 * DI2S_PROCEDURE: at least an element of DI2S procedure is rejected
									 */
									logger.debug("DI2S_PROCEDURE: at least an element of DI2S procedure is rejected");
									performed = false;
								} else {
									/*
									 * DI2S_PROCEDURE: acceptDi2s check if di2s is valid
									 */
									performed = acceptDi2s(equivalentDto, currentSession, currentInstance, droolsParams,
											rejected);

								}
							} else {
								performed = acceptDi2s(equivalentDto, currentSession, currentInstance, droolsParams,
										rejected);

							}
						} else {
							/*
							 * DI2S_PROCEDURE: there aren't enough bic for master/slave
							 */
							logger.debug("DI2S_PROCEDURE: there aren't enough bic for master/slave");
							equivalentDto.getReasonOfReject().add(new ReasonOfRejectElement(
									ReasonOfReject.bicNotAvailable, 1, "System Conflict", null));
							rejected.put(equivalentDto.getEquivalentDtoId(), equivalentDto);
							performed = false;
						}
					} else {
						/*
						 * There isn't a slave associated!
						 */
						throw new Exception("There isn't a slave associated!");
					}

				} else {
					/*
					 * DI2S_PROCEDURE: the prMode isn't DI2S, cannot perform this operation
					 */
					logger.error("DI2S_PROCEDURE: the prMode isn't DI2S, cannot perform this operation.");
					performed = false;
				}
			} else {
				/*
				 * there isn't a valid session/istance!
				 */
				throw new Exception("there isn't a valid session/istance!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ERROR DI2S_PROCEDURE:" + e.toString());
		}

		return performed;
	}

	/**
	 * Accept di 2 s.
	 *
	 * @param equivalentDto   the equivalent dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param rejected        the rejected
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	private boolean acceptDi2s(EquivalentDTO equivalentDto, String currentSession, int currentInstance,
			DroolsParameters droolsParams, Map<String, Object> rejected) throws Exception {
		boolean performed = false;
		Logger logger = DroolsParameters.getLogger();

		/*
		 * concatenate the current session
		 */
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		/*
		 * get the curent kie session
		 */
		KieSession currentKieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		DroolsOperations droolsOp = new DroolsOperations();
		Acquisition acqFromDi2s = droolsOp.receiveAcceptedAcquisitionWithId(
				equivalentDto.getAllDtoInEquivalentDto().get(0).getDtoId(), currentSession, currentInstance);
		logger.debug("acq from di2s : " + acqFromDi2s);
		/*
		 * if there is a valid matched acq
		 */
		if (acqFromDi2s != null) {
			PdhtManagement pdhtMng = new PdhtManagement();
			boolean inserted;

			/*
			 * check if cq is insertable into the pdht
			 */
			inserted = pdhtMng.updatePdhtTillEnd(currentSession, currentInstance, acqFromDi2s, null, droolsParams,
					acqFromDi2s.getSatelliteId());

			/*
			 * if is inserted
			 */
			if (inserted) {
				logger.debug("DI2S_PROCEDURE: procedure success, all elements are accepted.");
				/*
				 * Di2s is correctly performed
				 */
				performed = true;
				/*
				 * remove from reject the master ->acepted
				 */
				rejected.remove(equivalentDto.getDi2sInfo().getRelativeMasterId());

				/*
				 * remove from reject the slave ->acepted
				 */
				rejected.remove(equivalentDto.getDi2sInfo().getRelativeSlaveId());
				logger.debug("DI2S_PROCEDURE: removed master and slave from rejected elements");
			}
		}
		/*
		 * if is not performed
		 */
		if (!performed) {
			/*
			 * remove di2s
			 */
			removeDi2s(currentKieSession, rejected, equivalentDto);

			/*
			 * reject the master
			 */
			DroolsOperations.retractSingleAcq(droolsParams, equivalentDto.getDi2sInfo().getRelativeMasterId(),
					currentSession, currentInstance, ReasonOfReject.cannotPerformDi2s);
			/*
			 * reject the master
			 */
			DroolsOperations.retractSingleAcq(droolsParams, equivalentDto.getDi2sInfo().getRelativeSlaveId(),
					currentSession, currentInstance, ReasonOfReject.cannotPerformDi2s);
		}
		return performed;
	}

	/**
	 * Retract master.
	 *
	 * @param master          the master
	 * @param droolsParams    the drools params
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	private boolean retractMaster(DTO master, DroolsParameters droolsParams, String currentSession,
			int currentInstance) {
		boolean retractedmaster = false;
		Logger logger = DroolsParameters.getLogger();
		// concatenate the current session
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the current kieSession of Drools
		KieSession currentKieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// invoke the query to find the acquisition related
		// to master inside Drools (if it is a valid acq)
		QueryResults validAcq = currentKieSession.getQueryResults("acqWithGivenId", master.getDtoId());

		logger.debug("ALL PARTNERS before removing master: " + droolsParams.getAllPartners());

		// iterate over the results
		Iterator<QueryResultsRow> iterator = validAcq.iterator();

		// if there is a match
		while (iterator.hasNext()) {
			// extract the acquisition
			Acquisition acq = (Acquisition) iterator.next().get("$acq");

			logger.debug("DI2S_PROCEDURE: the master is retracted");

			// mark as di2s unavailable
			acq.setDi2sAvailable(false);

			// add the correct reason of reject
			acq.addReasonOfReject(32, ReasonOfReject.deletedForDi2s, "Deleted For DI2S", 0, 0, null);
			retractedmaster = true;

			// retract the master to insert the di2s with merged master and
			// slave
			DroolsOperations.retractSingleAcq(droolsParams, acq.getIdTask(), currentSession, currentInstance,
					ReasonOfReject.deletedForDi2s);
		}
		return retractedmaster;
	}

	/**
	 * Removes the di 2 s.
	 *
	 * @param currentKieSession the current kie session
	 * @param rejected          the rejected
	 * @param equivalentDto     the equivalent dto
	 */
	protected void removeDi2s(KieSession currentKieSession, Map<String, Object> rejected, EquivalentDTO equivalentDto) {
		FactHandle handleForDi2sInfo = currentKieSession.insert(equivalentDto.getDi2sInfo());
		// Acquisition acqCreatedFromEquivDto = (Acquisition)
		// rejected.get(equivalentDto.getAllDtoInEquivalentDto().get(0).getDtoId());
		equivalentDto.getDi2sInfo().setRejected(true);
		equivalentDto.setRejected(true);
		// equivalentDto.getReasonOfReject().add(acqCreatedFromEquivDto.getReasonOfReject().get(0));
		// equivalentDto.getAllDtoInEquivalentDto().get(0).setRejected(true);
		currentKieSession.delete(handleForDi2sInfo);
	}

}
