/**
*
* MODULE FILE NAME:	Eclipse.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		04 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 04 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resources;

import java.util.Date;

/**
 * The Class Eclipse.
 *
 * @author fpedrola
 */
public class Eclipse {

	/** The start time. */
	private Date startTime;

	/** The end time. */
	private Date endTime;

	/** The satellite id. */
	private String satelliteId;

	/**
	 * Instantiates a new eclipse.
	 *
	 * @param startTime   the start time
	 * @param endTime     the end time
	 * @param satelliteId the satellite id
	 */
	public Eclipse(Date startTime, Date endTime, String satelliteId) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
		this.satelliteId = satelliteId;
	}

	/**
	 * Gets the end time.
	 *
	 * @return the end time
	 */
	public Date getEndTime() {
		return this.endTime;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Gets the start time.
	 *
	 * @return the start time
	 */
	public Date getStartTime() {
		return this.startTime;
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() {
		/**
		 * toString del metodo
		 */
		return "Eclipse [startTime=" + this.startTime + ", endTime=" + this.endTime + ", satelliteId="
				+ this.satelliteId + "]";
	}

}
