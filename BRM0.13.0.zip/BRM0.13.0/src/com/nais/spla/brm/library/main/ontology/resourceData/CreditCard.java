/**
*
* MODULE FILE NAME:	CreditCard.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		30 ago 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 30 ago 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;

/**
 * The Class CreditCard.
 *
 * @author fpedrola
 */
public class CreditCard implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Partner to whom the Creditor lent some BIC. */
	private String debitorId;

	/** amount of BIC that the Creditor give to the Debitor. */
	private double BICLent;

	/** loan for the acq with id. */
	private String forAcq;

	/** The donation. */
	private boolean donation;

	/** The is previous. */
	private boolean isPrevious;

	/**
	 * Instantiates a new credit card.
	 *
	 * @param debitorId the debitor id
	 * @param BICLent   the BIC lent
	 * @param forAcq    the for acq
	 */
	public CreditCard(String debitorId, double BICLent, String forAcq) {
		super();
		this.debitorId = debitorId;
		this.BICLent = BICLent;
		this.forAcq = forAcq;
		this.donation = false;
		this.isPrevious = false;
	}

	/**
	 * Gets the BIC lent.
	 *
	 * @return the bICLent
	 */
	public double getBICLent() {
		return this.BICLent;
	}

	/**
	 * Gets the debitor.
	 *
	 * @return the debitor
	 */
	public String getDebitor() {
		return this.debitorId;
	}

	/**
	 * Gets the for acq.
	 *
	 * @return the for acq
	 */
	public String getForAcq() {
		return this.forAcq;
	}

	/**
	 * Checks if is donation.
	 *
	 * @return true, if is donation
	 */
	public boolean isDonation() {
		return this.donation;
	}

	/**
	 * Sets the BIC lent.
	 *
	 * @param bic the new BIC lent
	 */
	public void setBICLent(double bic) {
		this.BICLent = bic;
	}

	/**
	 * Sets the donation.
	 *
	 * @param donation the new donation
	 */
	public void setDonation(boolean donation) {
		this.donation = donation;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "CreditCard [debitorId=" + this.debitorId + ", BICLent=" + this.BICLent + ", forAcq=" + this.forAcq
				+ ", donation=" + this.donation + "]";
	}

	/**
	 * Checks if is previous.
	 *
	 * @return true, if is previous
	 */
	public boolean isPrevious() {
		return this.isPrevious;
	}

	/**
	 * Sets the previous.
	 *
	 * @param isPrevious the new previous
	 */
	public void setPrevious(boolean isPrevious) {
		this.isPrevious = isPrevious;
	}

}
