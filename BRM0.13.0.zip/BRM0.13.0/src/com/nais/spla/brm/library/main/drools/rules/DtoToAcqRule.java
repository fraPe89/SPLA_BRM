/**
*
* MODULE FILE NAME:	DtoToAcqRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		23 ago 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 23 ago 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.rules;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.functions.EssEnergyManagement;
import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.ConfigMaps;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class DtoToAcqRule.
 *
 * @author francesca
 */
public class DtoToAcqRule {

	/**
	 * From dto to acq rule.
	 *
	 * @param dto               the dto
	 * @param droolsParams      the drools params
	 * @param report            the report
	 * @param resourceFunctions the resource functions
	 * @param configMaps        the config maps
	 * @param rejected          the rejected
	 * @throws Exception
	 */
	public Acquisition fromDtoToAcqRule(DTO dto, Di2sInfo di2s, DroolsParameters droolsParams, List<String> report,
			ResourceFunctions resourceFunctions, ConfigMaps configMaps, Map<String, Acquisition> rejected,
			HashMap<String, Acquisition> allAccepted) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// initialize the bicUtils for the check on partners associated with the
		// acq
		BicUtils bicUtils = new BicUtils();

		// initialize the EssEnergyManagement for the check on energy associated
		// with the acq
		EssEnergyManagement essManagement = new EssEnergyManagement();

		// initialize the PdhtManagement for the check on size associated with
		// the acq
		PdhtManagement pdhtManagement = new PdhtManagement();

		// get the working kieSession
		// KieSession kie =
		// DroolsParameters.getDroolsEnv().getKieSessionsMap().get(DroolsParameters.getCurrentSession());
		logger.info("RULE 000_PlanAcqFromDto for dto : " + dto);

		// create a new acquisition
		Acquisition acq = new Acquisition();
		acq.createAcqFromDto(dto, acq);

		// set the sizes of the acq
		acq.setSizeH(dto.getSizeH());
		acq.setSizeV(dto.getSizeV());

		acq.setBackupVis(dto.getBackupVis());

		// mark the current acquisition as last one processed
		DroolsParameters.setLastAcq(acq);

		// check if the size is valid
		boolean validSize = pdhtManagement.checkIfSizeIsValid(acq);

		// if is valid
		if (validSize) {
			logger.debug("RULE 000_PlanAcqFromDto acq prMode :" + acq.getPrMode());

			// if the acquisition has valid user info
			if (!acq.getUserInfo().isEmpty()) {
				// iterate over them
				for (int i = 0; i < acq.getUserInfo().size(); i++) {
					// extract the i-esim associated partner id
					String partnerId = acq.getUserInfo().get(i).getOwnerId();
					logger.debug("RULE 000_PlanAcqFromDto partner id :" + partnerId);

					// get the partner with the id extracted above
					Partner partner = bicUtils.findPartnerInList(partnerId, droolsParams.getAllPartners());
					logger.debug("RULE 000_PlanAcqFromDto partner  :" + partner);

					// decrement the ar id of the partner if is the first
					// time that we are manipulating this ar
					bicUtils.checkIfContainsArId(acq, partner, DroolsParameters.getSplitChar());

					// update the partner
					// kie.insert(partner);
				}
			}

			// set the equivalent dto id if present
			acq.setReferredEquivalentDto(dto.getReferredEquivalentDto());

			// if the dto is a di2s
			if (dto.isDi2s()) {
				// mark as di2s available
				acq.setDi2sAvailable(true);

				// link the di2sInfo to the acq
				acq.setDi2sInfo(di2s);
				logger.debug("RULE 000_PlanAcqFromDto acq with di2sInfo: " + acq.getDi2sInfo());
			}

			logger.debug("RULE 000_PlanAcqFromDto the new acq  : " + acq);

			// generate the string with the main information of the acq
			String acqForReport = acq.getIdTask() + ", startTime :" + acq.getStartTime() + ", endTime : "
					+ acq.getEndTime() + ", lookSide :" + acq.getLookSide() + ", sensorMode :" + acq.getSensorMode()
					+ " added";

			// if the list of processed elements dowsn't contains the
			// current acq
			if (!report.contains(acqForReport)) {
				// add it to the report
				report.add(acqForReport);
			}

			// get the treemap with all the acq
			TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions
					.getEssFunctionAssociatedToSat(acq.getSatelliteId());

			logger.debug("000_PlanAcqFromDto check for overlapped acq...");

			// check if the element is in overlap with other acq
			List<String> elementsInOverlap = essManagement.checkAcqOverlap(droolsParams, acq, allAcq,
					configMaps.getMinDistanceMap());

			logger.debug("000_PlanAcqFromDto ");

			// if there isn't an overlap
			if (elementsInOverlap.isEmpty()) {
				logger.debug("000_PlanAcqFromDto there isn't overlapped elements");

				// compute the energy relative to the acq
				double essAssoc = essManagement.computeEss(acq, droolsParams, configMaps.getPowerSensorMode());

				// set the energy
				acq.setEss(essAssoc);

				// insert in treemap
				allAcq.put(acq.getStartTime().getTime(), new EnergyAssociatedToTask(acq, acq.getEss()));

				// insert the acquisition into Drools
				// kie.insert(acq);

				logger.debug("RULE 000_PlanAcqFromDto acq :" + acq + " is inserted into the BRM");
			} else {
				logger.debug(
						"000_PlanAcqFromDto there are overlapped elements , processing them... " + elementsInOverlap);

				Map<Boolean, Map<String, Acquisition>> overlapped = detectOverlapCases(acq, elementsInOverlap, rejected,
						allAccepted);
				Map<String, Acquisition> subElements = overlapped.get(true);
				if ((subElements == null) || subElements.isEmpty()) {
					// insert in treemap
					allAcq.put(acq.getStartTime().getTime(), new EnergyAssociatedToTask(acq, acq.getEss()));

					// insert the acquisition into Drools
					// insert(acq);

					logger.debug("RULE 000_PlanAcqFromDto acq :" + acq + " is inserted into the BRM");
				} else {
					acq.addReasonOfReject(7, ReasonOfReject.acqOverlapWithAcquisition,
							"Acquisition Overlap With Another Acquisition", 0, 0, elementsInOverlap);
					acq.setRejected(true);
					rejected.put(acq.getId(), acq);
					// update(rejected);
					logger.debug("RULE 000_PlanAcqFromDto acq :" + acq + " cannot be inserted into the BRM");
				}
			}
		}
		return acq;

	}

	/**
	 * Detect overlap cases.
	 *
	 * @param acq               the acq
	 * @param elementsInOverlap the elements in overlap
	 * @param rejected          the rejected
	 * @return the map
	 */
	public Map<Boolean, Map<String, Acquisition>> detectOverlapCases(Acquisition acq, List<String> elementsInOverlap,
			Map<String, Acquisition> rejected, HashMap<String, Acquisition> allAccepted) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// set the correct points to the acq based on her prType
		int currentPrTypePoints = setPrTypePoints(acq);

		logger.debug("for the acq with prType :" + acq.getPrType() + " the points are :" + currentPrTypePoints);

		// decrement the point associated with the current acq
		currentPrTypePoints++;

		logger.debug(
				"RULE 000_PlanAcqFromDto decrement the point associated with the current acq : " + currentPrTypePoints);

		Map<Boolean, Map<String, Acquisition>> mustCancelTheCurrentAcq = detectWhatAcqMustBeCancelled(acq,
				elementsInOverlap, currentPrTypePoints, rejected, allAccepted);

		return mustCancelTheCurrentAcq;
	}

	/**
	 * Detect what acq must be cancelled.
	 *
	 * @param acq                the acq
	 * @param elementsInOverlap  the elements in overlap
	 * @param pointsOfCurrentAcq the points of current acq
	 * @param rejected           the rejected
	 * @return the map
	 */
	@SuppressWarnings("unchecked")
	public Map<Boolean, Map<String, Acquisition>> detectWhatAcqMustBeCancelled(Acquisition acq,
			List<String> elementsInOverlap, int pointsOfCurrentAcq, Map<String, Acquisition> rejected,
			HashMap<String, Acquisition> allAccepted) {
		// boolean variable to detect which acq will be removed
		boolean possible = true;

		// variable to detect the number of acquisition with higher priority
		// then the current one
		int higherPriorityInOverlap = 0;

		Map<Boolean, Map<String, Acquisition>> returnedElements = new HashMap<>();

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create an empty list to store the overlapped acq
		Map<String, Acquisition> overlappedAcqMap = new HashMap<>();

		logger.debug("RULE 000_PlanAcqFromDto iterate over the overlapped elements : " + elementsInOverlap);

		// iterate over the overlapped elements
		for (int i = 0; i < elementsInOverlap.size(); i++) {
			// extract the id of i-esim overlapped acq
			String acqId = elementsInOverlap.get(i);
			logger.debug("RULE 000_PlanAcqFromDto get the related acq for id : " + acqId);

			// initialize a new acquisition
			Acquisition overlappedAcq = null;

			if (allAccepted.get(acqId) != null) {
				// get the acquisition
				overlappedAcq = allAccepted.get(acqId);

				logger.debug("RULE 000_PlanAcqFromDto overlapped acq extracted : " + overlappedAcq);

				// insert the acq into the list of overlapped acq
				overlappedAcqMap.put(overlappedAcq.getIdTask(), overlappedAcq);

				// set the correct points based on prType
				int pointsOfOverlappedAcq = setPrTypePoints(overlappedAcq);

				// if the currentAcq has higher priority
				if (pointsOfCurrentAcq > pointsOfOverlappedAcq) {
					higherPriorityInOverlap++;
				}
			}
		}

		if (higherPriorityInOverlap > 0) {
			// mark the boolean variable at false -> remove current
			possible = false;
		}

		// extra check for LMP requests
		if (acq.getPrType().compareTo(PRType.LMP) == 0) {
			// clone overlapped elements
			Map<String, Acquisition> clonedOverlappedAcqMap = (Map<String, Acquisition>) DroolsUtils
					.deepClone(overlappedAcqMap);

			// check if the list of replaceable dto is not empty
			if ((acq.getReplacedRequestListId() != null) && !acq.getReplacedRequestListId().isEmpty()) {
				// iterate over the replaceable dto list
				for (int i = 0; i < acq.getReplacedRequestListId().size(); i++) {
					// if the overlapped element is a replaced one -> check
					// valid
					if (clonedOverlappedAcqMap.get(acq.getReplacedRequestListId().get(i)) != null) {
						// remove it from map
						clonedOverlappedAcqMap.remove(acq.getReplacedRequestListId().get(i));
					}
				}

				// if the size of the map is zero means that all the overlapped
				// elements was replaceable -> remove all replaceable elements
				// and insert the LMP
				if ((clonedOverlappedAcqMap.size() == 0) && (higherPriorityInOverlap == 0)) {
					// mark the boolean variable at false -> remove current acq
					possible = true;
				}
				// if the map isn't empty means that at least one of the
				// overlapped elements wasn't in replaceable list -> reject LMP
				else {
					// mark the boolean variable at false -> remove others
					possible = false;
				}
			}
		}
		returnedElements.put(possible, overlappedAcqMap);
		return returnedElements;
	}

	/**
	 * Sets the pr type points.
	 *
	 * @param acq the acq
	 * @return the int
	 */
	public static int setPrTypePoints(Acquisition acq) {
		// as default , set the points to 1 (for standard acquisitions)
		int points = 2;

		// if the acq is a VU
		if (acq.getPrType().compareTo(PRType.VU) == 0) {
			// increase the points to 1
			points = 0;
		}
		// if the acq is a LMP
		else if (acq.getPrType().compareTo(PRType.LMP) == 0) {
			// increase the points to 10000
			points = 1;
		}

		else if ((acq.getPrType().compareTo(PRType.RANKED_ROUTINE) == 0)
				|| (acq.getPrType().compareTo(PRType.UNRANKED_ROUTINE) == 0)) {
			points = 3;
		}
		return points;
	}

}
