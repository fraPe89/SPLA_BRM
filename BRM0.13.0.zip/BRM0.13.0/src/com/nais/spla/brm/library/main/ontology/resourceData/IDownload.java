/**
 *
 * MODULE FILE NAME: IDownload.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.DownloadLogic;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class IDownload.
 */
public class IDownload implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The related to task. */
	private String relatedToTask;

	/** The type of dwl. */
	private DownloadLogic typeOfDwl;

	/** The planned on. */
	private boolean plannedOn;

	/** The start time. */
	private Date startTime;

	/** The stop time. */
	private Date stopTime;

	/** The dwl or pt. */
	private Task dwlOrPt;

	/** The really planned. */
	private boolean reallyPlanned = true;

	/**
	 * Instantiates a new i download.
	 */
	public IDownload() {
		super();
	}

	/**
	 * Instantiates a new i download.
	 *
	 * @param relatedToTask the related to task
	 * @param typeOfDwl     the type of dwl
	 * @param plannedOn     the planned on
	 * @param startTime     the start time
	 * @param stopTime      the stop time
	 * @param dwlOrPt       the dwl or pt
	 */
	public IDownload(String relatedToTask, DownloadLogic typeOfDwl, boolean plannedOn, Date startTime, Date stopTime,
			Task dwlOrPt) {
		super();
		this.relatedToTask = relatedToTask;
		this.typeOfDwl = typeOfDwl;
		this.plannedOn = plannedOn;
		this.startTime = startTime;
		this.stopTime = stopTime;
		this.dwlOrPt = dwlOrPt;
	}

	/**
	 * Gets the related to task.
	 *
	 * @return the related to task
	 */
	public String getRelatedToTask() {
		return this.relatedToTask;
	}

	/**
	 * Sets the related to task.
	 *
	 * @param relatedToTask the new related to task
	 */
	public void setRelatedToTask(String relatedToTask) {
		this.relatedToTask = relatedToTask;
	}

	/**
	 * Gets the type of dwl.
	 *
	 * @return the type of dwl
	 */
	public DownloadLogic getTypeOfDwl() {
		return this.typeOfDwl;
	}

	/**
	 * Sets the type of dwl.
	 *
	 * @param typeOfDwl the new type of dwl
	 */
	public void setTypeOfDwl(DownloadLogic typeOfDwl) {
		this.typeOfDwl = typeOfDwl;
	}

	/**
	 * Sets the planned on.
	 *
	 * @param plannedOn the new planned on
	 */
	public void setPlannedOn(boolean plannedOn) {
		this.plannedOn = plannedOn;
	}

	/**
	 * Gets the stop time.
	 *
	 * @return the stop time
	 */
	public Date getStopTime() {
		return this.stopTime;
	}

	/**
	 * Sets the stop time.
	 *
	 * @param stopTime the new stop time
	 */
	public void setStopTime(Date stopTime) {
		this.stopTime = stopTime;
	}

	/**
	 * Gets the dwl or pt.
	 *
	 * @return the dwl or pt
	 */
	public Task getDwlOrPt() {
		return this.dwlOrPt;
	}

	/**
	 * Sets the dwl or pt.
	 *
	 * @param dwlOrPt the new dwl or pt
	 */
	public void setDwlOrPt(Task dwlOrPt) {
		this.dwlOrPt = dwlOrPt;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "IDownload [relatedToTask=" + this.relatedToTask + ", typeOfDwl=" + this.typeOfDwl + ", plannedOn="
				+ this.plannedOn + ", startTime = " + this.startTime + ", stopTime=" + this.stopTime + ", dwlOrPt="
				+ this.dwlOrPt + "]";
	}

	/**
	 * Gets the start time.
	 *
	 * @return the startTime
	 */
	public Date getStartTime() {
		return this.startTime;
	}

	/**
	 * Sets the start time.
	 *
	 * @param startTime the startTime to set
	 */
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * Checks if is really planned.
	 *
	 * @return the reallyPlanned
	 */
	public boolean isReallyPlanned() {
		return this.reallyPlanned;
	}

	/**
	 * Sets the really planned.
	 *
	 * @param reallyPlanned the reallyPlanned to set
	 */
	public void setReallyPlanned(boolean reallyPlanned) {
		this.reallyPlanned = reallyPlanned;
	}

}
