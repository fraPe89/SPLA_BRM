/**
*
* MODULE FILE NAME:	CMGAxisReconfigManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		30 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 30 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;

/**
 * The Class CMGAxisReconfigManagement.
 *
 * @author francesca
 */
public class CMGAxisReconfigManagement {

	/**
	 * Check if need cmg axis.
	 *
	 * @param man               the man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param rejected          the rejected
	 * @return the list
	 */
	public List<CMGAxis> checkIfNeedCmgAxis(Maneuver man, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions, Map<String, Acquisition> rejected) {
		List<CMGAxis> cmgAxis = new ArrayList<>();

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		logger.debug("CMGA_AXIS_RULE : rule check axes reconfiguration for :" + man);

		// get the satellite id related to the man under test
		String satId = man.getSatelliteId();

		// get the acquisition that must be removed if this check will fail
		Acquisition acqToRemove = DroolsParameters.getLastAcq();
		// logger.debug("CMGA_AXIS_RULE : potential acq to remove :" +
		// acqToRemove);

		// get the map with all the maneuvers relative to
		// the satellite related to the maneuver under test,
		// ordered by start time

		TreeMap<Long, Maneuver> manFunctions = resourceFunctions.getManeuverFunctionAssociatedToSat(satId);

		// create a variable where will be stored the
		// previous man of the man under test, if exists
		Maneuver previousMan = null;

		// create a variable where will be stored the
		// next man of the man under test, if exists

		Maneuver nextMan = null;

		boolean validPlanWithPrev = true;
		boolean validPlanWithNext = true;

		List<CMGAxis> createdCmgAxis = new ArrayList<>();

		logger.debug("CMGA_AXIS_RULE : searching the previous cmg man...");

		String prevOrNextCheck = "prev";

		// check if there gap with previous man is
		// enough for plan an axis reconfiguration

		LeftAttitudeProfileManagement leftAttitude = new LeftAttitudeProfileManagement();

		if (leftAttitude.getPrevOrNextManOfRelatedType(manFunctions, man.getStartTime().getTime(), true,
				Actuator.CMGA) != null) {
			// if exists a previous man, memorize it in previousMan
			previousMan = manFunctions.get(leftAttitude.getPrevOrNextManOfRelatedType(manFunctions,
					man.getStartTime().getTime(), true, Actuator.CMGA));

			logger.debug("CMGA_AXIS_RULE : previous man is :" + previousMan);

			// check if is possible to create a cmgAxis
			Map<Boolean, CMGAxis> returnedCMAxis = checkAndCreateCmgAxis(previousMan, man, droolsParams,
					resourceFunctions, prevOrNextCheck);

			// if is impossible
			if (returnedCMAxis.containsKey(false)) {
				// set the return variable to false
				validPlanWithPrev = false;
			}
			// if is possible
			else if (returnedCMAxis.containsKey(true)) {
				// logger.debug("CMGA_AXIS_RULE : adding the new cmgAxis to the
				// list of created cmgAxis");

				if (returnedCMAxis.get(true) != null) {
					// add the just created cmg axis to the list
					createdCmgAxis.add(returnedCMAxis.get(true));
				}

			}
		} else {
			// there isn't a previous man. Check passed
			logger.debug("CMGA_AXIS_RULE : there isn't a previous man. Check   passed.");
		}

		// if the check with previous is ok
		if (validPlanWithPrev) {
			logger.debug("CMGA_AXIS_RULE : searching the next man...");

			// start the check with next. check if exist a next man
			if (leftAttitude.getPrevOrNextManOfRelatedType(manFunctions, man.getEndTime().getTime(), false,
					Actuator.CMGA) != null) {
				// extract the next man
				nextMan = manFunctions.get(leftAttitude.getPrevOrNextManOfRelatedType(manFunctions,
						man.getEndTime().getTime(), false, Actuator.CMGA));

				logger.debug("CMGA_AXIS_RULE : next man is :" + nextMan);

				prevOrNextCheck = "next";

				// invoke the function to create the cmgAxis if needed
				Map<Boolean, CMGAxis> returnedCMAxis = checkAndCreateCmgAxis(man, nextMan, droolsParams,
						resourceFunctions, prevOrNextCheck);

				// if there isn't a way to create a cmgAxis
				if (returnedCMAxis.containsKey(false)) {
					validPlanWithNext = false;
				}
				// cmgAxis correctly created
				else if (returnedCMAxis.containsKey(true)) {
					logger.debug("CMGA_AXIS_RULE : adding the new cmgAxis to the list of created cmgAxis");

					// add it to the list
					if (returnedCMAxis.get(true) != null) {
						createdCmgAxis.add(returnedCMAxis.get(true));

					}
				}
			}
			// there isn't a next maneuver
			else {
				validPlanWithNext = true;
				// there isn't a next man. Check passed
				logger.debug("CMGA_AXIS_RULE : there isn't a next man. Check passed.");
			}
		}

		// if the plan is consistent and all the cmgAxis needed are created
		if (validPlanWithPrev && validPlanWithNext) {
			// for each new cmgAxis
			for (int i = 0; i < createdCmgAxis.size(); i++) {
				TreeMap<Long, CMGAxis> cmgAxisForSat = resourceFunctions.getCmgaAxisAssociatedToSat(satId);
				// add it to the treemap structure
				cmgAxisForSat.put(createdCmgAxis.get(i).getStartTime().getTime(), createdCmgAxis.get(i));
				// logger.debug("CMGA_AXIS_RULE : add the cmgaAxis to the
				// resource structure" + createdCmgAxis.get(i));

				cmgAxis.add(createdCmgAxis.get(i));
			}
		} else {
			// add the correct reasonOfReject to the acquisition
			acqToRemove.addReasonOfReject(12, ReasonOfReject.noTimeForAxesReconf, "No Time For Axes Reconfiguration", 0,
					0, null);

			// mark the acquisition as rejected
			acqToRemove.setRejected(true);

			// insert the last acquisition in the rejected list
			rejected.put(acqToRemove.getId(), acqToRemove);
			// logger.debug("ACQ rejected : " + acqToRemove.getId() + "because :
			// noTimeForAxesReconf");
		}
		return cmgAxis;
	}

	/**
	 * Check and create cmg axis.
	 *
	 * @param previousMan       the previous man
	 * @param man               the man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param prevOrNextCheck   the prev or next check
	 * @return the map
	 */
	public Map<Boolean, CMGAxis> checkAndCreateCmgAxis(Maneuver previousMan, Maneuver man,
			DroolsParameters droolsParams, ResourceFunctions resourceFunctions, String prevOrNextCheck) {
		Map<Boolean, CMGAxis> results = new HashMap<>();

		// compute gap between previous and current man
		long gapWithPrev = man.getStartTime().getTime() - previousMan.getEndTime().getTime();

		// System.out.println("gap with prev : " + gapWithPrev);
		boolean axisReconfInserted = true;
		CMGAxis newCmgAxis = null;

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the satellite id
		String satId = man.getSatelliteId();

		// create an instance of CMGAManeuverManagement to use the related
		// functions
		CMGAManeuverManagement cmgaMng = new CMGAManeuverManagement();

		// extract all the cmga related to the current satellite
		List<CMGA> allCmgaForSatellite = droolsParams.getAllCMGAForSat(man.getSatelliteId());

		// and its relative properties
		SatelliteProperties satProp = droolsParams.getSatWithId(satId).getSatelliteProperties();

		TreeMap<Long, RampCMGA> rampFunction = resourceFunctions.getRampFunctionAssociatedToSat(man.getSatelliteId());

		Date endTimeAxisRec = man.getStartTime();
		Date startTimeAxisRec = null;

		boolean fromRollToPitch = false;
		int differentTypes = 0;

		// if the type of previous man is different from the type of current
		// man (Pitch/Roll or viceversa)
		if ((previousMan.getType().toString().startsWith("Pitch") && man.getType().toString().startsWith("Roll"))) {
			differentTypes = 1;
		} else if (previousMan.getType().toString().startsWith("Roll")
				&& man.getType().toString().startsWith("Pitch")) {
			differentTypes = 1;
			fromRollToPitch = true;
		}

		if (differentTypes == 1) {
			// get the max time of tAcc for the current satellite
			long timeTacc = (long) cmgaMng.getMaxTimeTacc(allCmgaForSatellite);

			RampCMGA rampUpRelativeToSecondMan = null;

			logger.trace("CMGA_AXIS_RULE : both maneuvers are in cmga");
			rampUpRelativeToSecondMan = rampFunction.lowerEntry(man.getStartTime().getTime()).getValue();

			// if the ramp up of the second man is after the
			// previous man -> the maneuvers are in two single
			// plateau
			if (rampUpRelativeToSecondMan.isRampUp()
					&& (rampUpRelativeToSecondMan.getStartTime().getTime() > previousMan.getEndTime().getTime())) {
				// decrement from gap the time of ramp down
				gapWithPrev = man.getStartTime().getTime() - previousMan.getEndTime().getTime()
						- (2 * (timeTacc * 1000));

				// validInterval =
				// checkIfGapIsInOverlapWithNoStandardAcq(gapWithPrev);

				logger.trace("the computed gap is : " + (gapWithPrev / 1000) + " seconds.");

				// the start time of the cmgaAxis is before the
				startTimeAxisRec = new Date((long) (man.getStartTime().getTime() - (timeTacc * 1000)
						- (satProp.getAxesReconfigurationTime() * 1000)));
				endTimeAxisRec = new Date(
						(long) (startTimeAxisRec.getTime() + (satProp.getAxesReconfigurationTime() * 1000)));
			} else
			// the ramp up is before the previous man -> the
			// maneuvers are in a merged plateau
			{
				// the gap doesn't consider the ramp down time
				gapWithPrev = man.getStartTime().getTime() - previousMan.getEndTime().getTime();
				logger.trace("the computed gap is : " + (gapWithPrev / 1000) + " seconds.");

				// set the start time and the stop time
				startTimeAxisRec = new Date(
						(long) (man.getStartTime().getTime() - (satProp.getAxesReconfigurationTime() * 1000)));
				endTimeAxisRec = new Date(
						(long) (startTimeAxisRec.getTime() + (satProp.getAxesReconfigurationTime() * 1000)));
			}

			// if the gap is too short for an axis reconf
			if (gapWithPrev < (satProp.getAxesReconfigurationTime() * 1000)) {
				logger.debug("CMGA_AXIS_RULE : the gap is not enough, there isn't time for axes reconf");

				// remove the last acq because
				// there isn't time for axes reconf
				axisReconfInserted = false;
			}
			// gap is enough
			else {
				// plan axes reconf between maneuvers
				// logger.debug("CMGA_AXIS_RULE : the gap is enough, plan
				// cmgaAxis");

				String axisId = "_" + previousMan.getIdTask() + "_" + man.getIdTask() + "_";
				// logger.debug("CMGA_AXIS_RULE : creating id for new cmgAxis "
				// + axisId);

				// create a new cmgAxis
				newCmgAxis = new CMGAxis(startTimeAxisRec, endTimeAxisRec);

				newCmgAxis.setStartTime(startTimeAxisRec);

				// set the end time
				newCmgAxis.setEndTime(endTimeAxisRec);

				newCmgAxis.setRollToPitch(fromRollToPitch);
				// sedt the satellite id
				newCmgAxis.setSatelliteId(man.getSatelliteId());

				// set the task type
				newCmgAxis.setTaskType(TaskType.AXES_RECONF);

				// set the id of the task
				newCmgAxis.setIdTask(axisId);

				// mark as true the variable to detect that the insert was a
				// success
				axisReconfInserted = true;
			}
		} else {
			logger.debug("same actuator, nothing to do.");

		}
		results.put(axisReconfInserted, newCmgAxis);

		return results;
	}

}
