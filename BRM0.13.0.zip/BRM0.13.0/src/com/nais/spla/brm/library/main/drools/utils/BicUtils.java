/**
*
* MODULE FILE NAME:	BicUtils.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		26 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 26 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class BicUtils.
 *
 * @author francesca
 */
public class BicUtils {

	/**
	 * Find partner in list.
	 *
	 * @param partnerId   the partner id
	 * @param allPartners the all partners
	 * @return the partner
	 * @throws Exception
	 */
	public Partner findPartnerInList(String partnerId, List<Partner> allPartners) {
		// create a new Partner object
		Partner partnerExtracted = null;

		// iterate over all the partners
		for (int z = 0; z < allPartners.size(); z++) {
			// is the i-esim partner has the same id of the one given as input
			if (allPartners.get(z).getPartnerId().equalsIgnoreCase(partnerId)) {
				// get the partner
				partnerExtracted = allPartners.get(z);

				// exit from the search
				break;
			}
		}
		if (partnerExtracted == null) {
			DroolsParameters.getLogger().error("partner not found");
		}
		return partnerExtracted;
	}

	/**
	 * Check if is of expected type.
	 *
	 * @param prModeOfAcq the pr mode of acq
	 * @param prToCheck   the pr to check
	 * @return true, if successful
	 */
	public boolean checkIfIsOfExpectedType(PRMode prModeOfAcq, PRMode prToCheck) {
		// initialize the search of the PrMode to false
		boolean prModeAreEquals = false;

		// if the prMode of the acquisition is the same of the one given as
		// input
		if (prModeOfAcq.equals(prToCheck)) {

			// set the boolean variable to true
			prModeAreEquals = true;
		}

		// return the result
		return prModeAreEquals;
	}

	/**
	 * Find if contains partner.
	 *
	 * @param allUserInfo the all user info
	 * @param partnerId   the partner id
	 * @return true, if successful
	 */
	public boolean findIfContainsPartner(List<UserInfo> allUserInfo, String partnerId) {
		// set the boolean variable to false as default
		boolean contained = false;

		// iterate over all the user info given as input
		for (int i = 0; i < allUserInfo.size(); i++) {
			// if the i.esim user info contains the id of the partner
			if (allUserInfo.get(i).getOwnerId().equalsIgnoreCase(partnerId)) {
				// mark the boolean variable to true
				contained = true;
			}
		}
		// return the result
		return contained;
	}

	/**
	 * Sort partners for max BIC available.
	 *
	 * @param allPartners the all partners
	 */
	public void sortPartnersForMaxBICAvailable(List<Partner> allPartners) {
		// from a list of partners use a Comparator to order them by residual
		// bic available
		Collections.sort(allPartners, new Comparator<Partner>() {

			@Override
			public int compare(Partner c1, Partner c2) {
				// use a proportion : if the residual bic of c2 are less than
				// c1, invert their order
				return Double.compare(((c2.getMaxBICAvailable() - c2.getUsedBIC()) / 100) * c2.getMaxPercLoanBic(),
						((c1.getMaxBICAvailable() - c1.getUsedBIC()) / 100) * c1.getMaxPercLoanBic());
			}
		});
	}

	/**
	 * Check if contains ar id.
	 *
	 * @param acq       the acq
	 * @param partner   the partner
	 * @param splitChar the split char
	 * @return true, if successful
	 */
	public boolean checkIfContainsArId(Acquisition acq, Partner partner, String splitChar) {
		// set as default that the acq doesn't contains the ar id
		boolean contained = false;

		// invoke the function to extract the ar from the id of the dto
		String dtoArId = FunctionUtils.extractArFromDto(acq.getId(), splitChar);

		// if the partner has the ar id list not empty
		if ((partner.getArIdForPartner() != null) && !partner.getArIdForPartner().isEmpty()) {
			// iterate over the ar id list
			for (int i = 0; i < partner.getArIdForPartner().size(); i++) {
				// if there is a match between ar id extracted and the current
				// in iteration
				if (partner.getArIdForPartner().get(i).toString().contains(dtoArId.toString())) {
					// mark as found
					contained = true;

					// remove the current arId
					partner.getArIdForPartner().remove(i);

					// decrement the index
					i--;

					acq.setRemoveArId(true);

					// if now the list of ar is empty
					if (partner.getArIdForPartner().isEmpty()) {
						// mark the partner as finished
						partner.setFinished(true);
					}
				}
			}
		}
		// if there isn't ar id associated with partner
		else {
			// mark the partner as finished
			partner.setFinished(true);
		}
		return contained;
	}

	/**
	 * Gets the allelements in interval.
	 *
	 * @param from   the from
	 * @param to     the to
	 * @param allAcq the all acq
	 * @return the allelements in interval
	 */
	public TreeMap<Long, EnergyAssociatedToTask> getAllelementsInInterval(Date from, Date to,
			TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		// get the subMap of th acquisition map from the start to the end given
		// as input
		NavigableMap<Long, EnergyAssociatedToTask> subMap = allAcq.subMap(from.getTime(), true, to.getTime(), true);

		// using a navigable map is impossible, in borderline cases (acquisition
		// starts outside the start of interval and ends inside) to insert the
		// borderline acq inside the map

		TreeMap<Long, EnergyAssociatedToTask> effectiveSubMap = new TreeMap<>();

		// if there are elements in submap
		if (!subMap.isEmpty()) {
			// iterate over them
			for (Map.Entry<Long, EnergyAssociatedToTask> submapElements : subMap.entrySet()) {
				// add each element
				effectiveSubMap.put(submapElements.getKey(), submapElements.getValue());
			}
		}

		// get previous element
		Object key = allAcq.lowerKey(from.getTime());

		// if there is a previous element
		if (key != null) {
			// extract the relative Object of energyAssociatedToTask
			EnergyAssociatedToTask previousOutsideIntervalInStart = allAcq.lowerEntry(from.getTime()).getValue();

			// if the previous element is in overlap with the start time of
			// interval
			if (previousOutsideIntervalInStart.getTask().getEndTime().after(from)) {
				// add it to the map
				effectiveSubMap.put(previousOutsideIntervalInStart.getTask().getStartTime().getTime(),
						previousOutsideIntervalInStart);
			}
		}
		return effectiveSubMap;
	}

	/**
	 * Check if must be decrement bic.
	 *
	 * @param sessionType the session type
	 * @param acq         the acq
	 * @return true, if successful
	 */
	public boolean checkIfMustBeDecrementBic(SessionType sessionType, Acquisition acq) {
		// initialize the returned value to false
		boolean decrement = false;

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		logger.debug("Check if bic must be decremented : session type is :  " + sessionType);
		logger.debug("Check if bic must be decremented : and prType is :  " + acq.getPrType());

		// if the session is for HP / PP / CRISIS
		if (sessionType.compareTo(SessionType.premium) == 0) {
			// if the acquisition that we are checking is referred to a premium
			// session
			if (acq.getPrType().equals(PRType.HP) || acq.getPrType().equals(PRType.PP)
					|| acq.getPrType().equals(PRType.CRISIS) || acq.getPrType().equals(PRType.CIVILIAN_HP)) {
				// decrement
				decrement = true;
			}
		}
		// if the session is for routine
		else if (sessionType.compareTo(SessionType.routine) == 0) {
			// if the acquisition that we are checking is referred to a routine
			// session
			if (acq.getPrType().equals(PRType.RANKED_ROUTINE) || acq.getPrType().equals(PRType.UNRANKED_ROUTINE)) {
				// decrement
				decrement = true;
			}
		}

		logger.debug("Check if bic must be decremented : need to decrement :  " + decrement);
		// in all the other cases don't decrememnt
		return decrement;
	}
}
