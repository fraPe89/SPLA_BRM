/**
*
* MODULE FILE NAME: SatelliteState.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.Date;

/**
 * The Class SatelliteState.
 */
public class SatelliteState {

	/** The satellite id. */
	private String satelliteId;

	/** The start unavailability. */
	private Date startUnavailability;

	/** The end unavailability. */
	private Date endUnavailability;

	/**
	 * Instantiates a new satellite state.
	 *
	 * @param satelliteId         the satellite id
	 * @param startUnavailability the start unavailability
	 * @param endUnavailability   the end unavailability
	 */
	public SatelliteState(String satelliteId, Date startUnavailability, Date endUnavailability) {
		this.satelliteId = satelliteId;
		this.startUnavailability = startUnavailability;
		this.endUnavailability = endUnavailability;
	}

	/**
	 * Gets the end unavailability.
	 *
	 * @return the end unavailability
	 */
	public Date getEndUnavailability() {
		return this.endUnavailability;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satellite id
	 */
	public String getSatelliteId() {
		return this.satelliteId;
	}

	/**
	 * Gets the start unavailability.
	 *
	 * @return the start unavailability
	 */
	public Date getStartUnavailability() {
		return this.startUnavailability;
	}

}
