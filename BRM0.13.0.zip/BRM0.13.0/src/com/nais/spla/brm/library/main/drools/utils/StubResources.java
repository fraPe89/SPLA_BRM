/**
*
* MODULE FILE NAME:	StubResources.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		25 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 25 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.SatelliteState;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Eclipse;

/**
 * The Class StubResources.
 *
 * @author francesca
 */
public class StubResources {

	/** The formatter. */
	private SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	/**
	 * Creates the eclipse.
	 *
	 * @param start       the start
	 * @param end         the end
	 * @param satelliteId the satellite id
	 * @return the eclipse
	 * @throws ParseException the parse exception
	 */
	public Eclipse createEclipse(String start, String end, String satelliteId) throws ParseException {
		// initialize the start time
		Date startTime = null;

		// initialize the stop time
		Date endTime = null;

		// create a new eclipse
		Eclipse newEclipse = null;
		try {
			// parse the date for the start
			startTime = this.formatter.parse(start);

			// parsxe the date for the end
			endTime = this.formatter.parse(end);

			// create a new eclipse
			newEclipse = new Eclipse(startTime, endTime, satelliteId);
		} catch (ParseException e) {
			throw new ParseException("error", 0);
		}

		return newEclipse;
	}

	/**
	 * Creates the HP exclusion.
	 *
	 * @param id                the id
	 * @param startTimeAsString the start time as string
	 * @param startLookSide     the start look side
	 * @param endTimeAsString   the end time as string
	 * @param endLookSide       the end look side
	 * @param satelliteId       the satellite id
	 * @param isEnabled         the is enabled
	 * @param isPeriodic        the is periodic
	 * @return the HP exclusion
	 */
	public HPExclusion createHPExclusion(String id, String startTimeAsString, String startLookSide,
			String endTimeAsString, String endLookSide, String satelliteId, boolean isEnabled, boolean isPeriodic) {
		// initialize start and stop time
		Date startTime = null, endTime = null;

		// create a new object of HPExclusion
		HPExclusion hpExcl = null;
		try {
			// parse the date for the start
			startTime = this.formatter.parse(startTimeAsString);

			// parse the date for the end
			endTime = this.formatter.parse(endTimeAsString);

			// set the new hpExclusion
			hpExcl = new HPExclusion(id, startTime, startLookSide, endTime, endLookSide, satelliteId, isEnabled,
					isPeriodic);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return hpExcl;
	}

	/**
	 * Creates the visibility.
	 *
	 * @param contactCounterId the contact counter id
	 * @param satId            the satellite id
	 * @param acqStatId        the acquisitionStation id
	 * @param ownerId          the owner id
	 * @param start            the string that identifies the startTime for the
	 *                         visibility
	 * @param end              the string that identifies the endTime for the
	 *                         visibility
	 * @return the visibility
	 */
	public Visibility createVisibility(long contactCounterId, String satId, String acqStatId, String ownerId,
			String start, String end) {
		// create a new visibility
		Visibility vis = null;

		// initialize start and stop
		Date startTime = null;
		Date endTime = null;
		try {
			// parse the date for the start
			startTime = this.formatter.parse(start);

			// parse the date for the stop
			endTime = this.formatter.parse(end);

			// create a new visibility
			vis = new Visibility(contactCounterId, satId, acqStatId, ownerId, startTime, endTime);

			// if there isn't an owner id
			if (ownerId == null) {
				// mark the visibility as external
				vis.setExternal(true);
			}
		} catch (ParseException e) {
			// catch the exception
			e.printStackTrace();
		}

		return vis;
	}

	/**
	 * Creates the paw.
	 *
	 * @param id          the id
	 * @param satelliteId the satellite id
	 * @param start       the start
	 * @param end         the end
	 * @param pawType     the paw type
	 * @return the paw
	 */
	public PAW createPaw(int id, String satelliteId, String start, String end, PAWType pawType) {
		// initialize the start and the stop
		Date startTime = null, endTime = null;

		// create a new paw
		PAW paw = null;
		try {
			// parse the date for the start
			startTime = this.formatter.parse(start);

			// parse the date for the stop
			endTime = this.formatter.parse(end);

			// populate the new paw
			paw = new PAW(id, satelliteId, startTime, endTime);
			paw.setType(pawType);
		} catch (ParseException e) {
			// catch the exception
			e.printStackTrace();
		}
		return paw;
	}

	/**
	 * Creates the satellite state.
	 *
	 * @param satelliteId the satellite id
	 * @param start       the start
	 * @param end         the end
	 * @return SatelliteState
	 */
	public SatelliteState createSatelliteState(String satelliteId, String start, String end) {
		// initialize start and stop
		Date startTime = null;
		Date endTime = null;
		SatelliteState satState = null;
		try {
			// parse the date for the start
			startTime = this.formatter.parse(start);

			// parse the date for the stop
			endTime = this.formatter.parse(end);

			satState = new SatelliteState(satelliteId, startTime, endTime);

		} catch (ParseException e) {
			// catch the exception
			e.printStackTrace();
		}
		// return the new satellite state with the parsed data
		return satState;
	}

	/**
	 * Creates the MH.
	 *
	 * @param start the start
	 * @param end   the end
	 * @return the mission horizon
	 */
	public MissionHorizon createMH(String start, String end) {
		// initialize start and stop
		Date startTime = null;
		Date endTime = null;
		// create a new mission horizon
		MissionHorizon MH = new MissionHorizon();
		try {
			// parse the date for the start
			startTime = this.formatter.parse(start);

			// parse the date for the stop
			endTime = this.formatter.parse(end);

			// set the start time and the stop time
			MH.setStart(startTime);
			MH.setStop(endTime);
		} catch (ParseException e) {
			// catch the exception
			e.printStackTrace();
		}
		return MH;
	}

}
