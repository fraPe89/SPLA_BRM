/**
 *
 * MODULE FILE NAME: DroolsOperations.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.drools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.instrument.IllegalClassFormatException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.apache.log4j.PropertyConfigurator;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.nais.spla.brm.library.main.drools.functions.BicManagement;
import com.nais.spla.brm.library.main.drools.functions.EssEnergyManagement;
import com.nais.spla.brm.library.main.drools.functions.InitPlanManagement;
import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
import com.nais.spla.brm.library.main.drools.functions.TheatreManagement;
import com.nais.spla.brm.library.main.drools.functions.DI2SManagement.Di2sManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.drools.rules.DtoToAcqRule;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.EnvironmentUtils;
import com.nais.spla.brm.library.main.drools.utils.FunctionUtils;
import com.nais.spla.brm.library.main.drools.utils.ReportDownloads;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.DownloadLogic;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SatelliteState;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.resources.Eclipse;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ConfigMaps;
import com.nais.spla.brm.library.main.ontology.utils.ElementsInvolvedOnOrbit;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.InitPlanTasks;

// TODO: Auto-generated Javadoc
/**
 * class that implements all the functionalities used from Drools, in detail :
 * <ul>
 * <li>read requests from external file
 * <li>load rules file
 * <li>manage different kieSession for different data execution
 * <li>execute the rules for validate the requests taken from the external txt
 * file or from a list of dto passed as parameter
 * <li>write report on external file
 * </ul>
 * .
 */
public class DroolsOperations {

	/** The cont dto. */
	private static int contDto;

	/** The queries. */
	private DroolsQueries queries = null;
	/** The du. */
	private DroolsUtils du = null;

	/** The drools env. */
	private DroolsEnvironment droolsEnv = null;

	/** The drools env. */
	private EnvironmentUtils envUtils = null;

	/** The dwl mng. */
	private DownloadManagement dwlMng = null;

	/** The logger. */
	private final static Logger logger = LoggerFactory.getLogger(DroolsOperations.class);

	/** The pdht mng. */
	private PdhtManagement pdhtMng = null;

	/**
	 * Instantiates a new drools operations.
	 */
	public DroolsOperations() {
		// set the logger
		// DroolsOperations.logger =
		// LoggerFactory.getLogger(DroolsOperations.class);

		// initialize the DownloadManagement
		this.dwlMng = new DownloadManagement();

		this.envUtils = new EnvironmentUtils();

		contDto = 0;

		// initialize the DroolsQueries
		this.queries = new DroolsQueries();

		// initialize the DroolsUtils
		this.du = new DroolsUtils();

		// initialize the PdhtManagement
		this.pdhtMng = new PdhtManagement();
		// DroolsOperations.logger.debug("BRM is starting ");
	}

	/**
	 * This method give to the CSPS the possibility to set the environment with all
	 * the files needed to let Drools works as expected.
	 *
	 * @param sessionId    the session id
	 * @param droolsParams the drools params
	 * @param localRepo    the local repo
	 * @param pathForTest  the path for test
	 * @return the drools environment
	 * @throws IllegalClassFormatException the illegal class format exception
	 */
	public DroolsEnvironment setUpEnvironment(String sessionId, DroolsParameters droolsParams, String localRepo,
			boolean pathForTest) throws IllegalClassFormatException {
		DroolsEnvironment droolsEnv = null;
		try {
			// instantiate the Drools Environment
			droolsEnv = new DroolsEnvironment("BRM");

			// set up the logger
			DroolsParameters.setLogger(DroolsOperations.logger);

			// initialize the Drools Environment
			droolsEnv.init(droolsParams, localRepo, pathForTest);

			// The log4j properties configuration
			PropertyConfigurator.configure(droolsEnv.getLogFileProperties());

			// initialize the Drools Environment
			droolsEnv.configure(droolsParams, localRepo, pathForTest);

			// Log settings
			// DroolsOperations.logger.debug("Custom Properties correctly
			// loaded.");

			// receive the number of session that must be set
			int numberOfSessions = droolsParams.getNumberOfSessions();

			// create the kieContainer, base element for build the inference
			// engine of drools

			droolsEnv.createKieContainer(sessionId, numberOfSessions, droolsParams);
		} catch (Exception e) {
			// error in the setUp of the Drools environment
			e.printStackTrace();
			DroolsOperations.logger.debug("error in the setUp of the Drools environment" + e.toString());
			droolsEnv = null;
		}
		return droolsEnv;
	}

	/**
	 * Check session.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	public static boolean checkSession(String currentSession, int currentInstance) {
		// create a boolean variable and initialize to false
		boolean existSession = false;
		/**
		 * if the hashmap that has all the created sessions cointains the one passed as
		 * parameter, set the boolean variable to true
		 */
		Logger logger = DroolsParameters.getLogger();

		String sessionIdInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		if (SessionHandler.getKieSessionsMap().containsKey(sessionIdInstance)) {
			// mark the boolean variable to true
			existSession = true;
		} else {
			// print an error on the log: there isn't a session with this id
			logger.error("error : there isn't a session with this id, retry");
		}
		return existSession;
	}

	/**
	 * Close all.
	 *
	 * @param sessionId the session id
	 */
	public void closeAllInstancesForSession(String sessionId) {
		// get the treeMap with all the instantiated sessions
		TreeMap<String, KieSession> openedKie = SessionHandler.getKieSessionsMap();

		// if there are opened sessions
		if (openedKie.size() > 0) {
			List<String> allInstancesToRemove = new ArrayList<>();
			// iterate over them and dispose each one
			for (Map.Entry<String, KieSession> entry : openedKie.entrySet()) {

				if (entry.getKey().startsWith(sessionId + "_")) {
					// extract the i-esim session
					KieSession kie = entry.getValue();

					// dispose it
					kie.dispose();

					// totally deallocate the session
					kie.destroy();

					allInstancesToRemove.add(entry.getKey());
				}

			}

			for (int i = 0; i < allInstancesToRemove.size(); i++) {
				// remove the session from the hashMap and finally destroy it
				SessionHandler.getKieSessionsMap().remove(allInstancesToRemove.get(i));

			}

			DroolsOperations.logger.debug("CLOSE SESSION : all sessions are closed for " + sessionId);
		} else {
			// there aren't opened sessions
			DroolsOperations.logger.debug("CLOSE SESSION : There aren't opened sessions, nothing to close.");
		}
	}

	/**
	 * Close session.
	 *
	 * @param sessionId      the session id
	 * @param currentSession the current session
	 */
	public void closeSession(String sessionId, int currentSession) {
		try {
			Logger logger = DroolsParameters.getLogger();

			String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentSession);
			// DroolsOperations.logger.debug("CLOSE SESSION : closing session :
			// " + sessionIdInstance);

			// get the session with the id given as parameter, if exists
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionIdInstance);

			logger.debug("tear down the current Drools kieSession ");
			// dispose it, so the memory used for
			// the session returns to be free
			kieSession.dispose();

			// remove the session from the hashMap and finally destroy it
			SessionHandler.getKieSessionsMap().remove(sessionIdInstance);

			// totally deallocate the session
			kieSession.destroy();
			// DroolsOperations.logger.debug("session " + currentSession + "
			// closed.");
		}
		// CLOSE SESSION : there isn't a session with this id. Nothing to close
		catch (NullPointerException e1) {
			DroolsOperations.logger
					.error("CLOSE SESSION : there isn't a session with this id. Nothing to close." + e1.toString());
		}
	}

	/**
	 * Gets the drools environment.
	 *
	 * @return the drools environment
	 */
	public DroolsEnvironment getDroolsEnvironment() {
		return droolsEnv;
	}

	/**
	 * Gets the global.
	 *
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @param global          the global
	 * @return the global
	 */
	public Object getGlobal(String sessionId, int currentInstance, String global) {
		try {
			String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

			// get the session with the id given
			// as parameter, if exists

			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionIdInstance);

			// use the drools API to receiving back the variables declared as
			// globals. The cast to the specific object type must be done inside
			// the method that use this function.
			Object obj = kieSession.getGlobal(global);
			// DroolsOperations.logger.debug("RECEIVE GLOBAL : " + global + " :
			// " + obj);
			return obj;
		} catch (NullPointerException e) {
			// Trying to use a session that isn't setted up before
			// DroolsOperations.logger.error("RECEIVE GLOBAL : Trying to use a
			// session that isn't setted up before " + e.toString());
			throw new NullPointerException(
					"RECEIVE GLOBAL : Trying to close all sessions, but Drools has not  been started yet"
							+ e.getStackTrace());
		}
	}

	/**
	 * Gets the PDHT status.
	 *
	 * @param timeToCheck     the time to check
	 * @param satelliteId     the satellite id
	 * @param sessionId       the session id
	 * @param currentInstance the current instance
	 * @return the PDHT status
	 */
	public PDHT getPDHTStatus(Date timeToCheck, String satelliteId, String sessionId, int currentInstance) {
		// create an object of type PDHT
		PDHT pdht = null;

		// get the current instance
		String sessionIdInstance = DroolsParameters.concatenateSession(sessionId, currentInstance);

		// extract the current kieSession
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionIdInstance);

		// get the resources instantiated for this current session
		ResourceFunctions resources = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		// get the treeMap with all the photograpy of PDHT status at every time
		// is inserted a new storage/download
		TreeMap<Long, ComplexPdht> PDHTFunctions = resources.getPDHTFunctionAssociatedToSat(satelliteId);

		// get the first instance
		Long keyReturned = PDHTFunctions.floorKey(timeToCheck.getTime());

		// if the previous step find a valid element
		if (keyReturned != null) {
			// extract the related pdht
			pdht = PDHTFunctions.get(keyReturned).getPdht();

			sortMemoryModulesInsidePDHT(pdht);
		} else {
			// print the error
			DroolsOperations.logger
					.debug("FUNCTION ERROR : there aren't  elements at time passed as input or previously");
		}
		return pdht;
	}

	/**
	 * Sort memory modules inside PDHT.
	 *
	 * @param pdht the pdht
	 * @return the pdht
	 */
	private PDHT sortMemoryModulesInsidePDHT(PDHT pdht) {
		List<MemoryModule> orderedMemMod = new ArrayList<>();

		orderedMemMod.add(pdht.getMemoryModuleWithId("1"));
		orderedMemMod.add(pdht.getMemoryModuleWithId("2"));
		orderedMemMod.add(pdht.getMemoryModuleWithId("3"));
		orderedMemMod.add(pdht.getMemoryModuleWithId("4"));
		orderedMemMod.add(pdht.getMemoryModuleWithId("5"));
		orderedMemMod.add(pdht.getMemoryModuleWithId("6"));

		pdht.setMMList(orderedMemMod);
		return pdht;
	}

	/**
	 * Purge sensor mode for mission horizon.
	 *
	 * @param sensorModeToPurge the sensor mode to purge
	 * @param droolsParams      the drools params
	 */
	public void purgeSensorModeForMissionHorizon(List<TypeOfAcquisition> sensorModeToPurge,
			DroolsParameters droolsParams) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		logger.debug("purge all acquisition with sensor mode :");

		// invoke the function to purge sensor mode
		droolsParams.setPurgeSensorMode(sensorModeToPurge);
	}

	/**
	 * Init the plan.
	 *
	 * @param droolsParams             the drools params
	 * @param previousTasks            the previous tasks
	 * @param previousTheatreInSession the previous theatre in session
	 * @param currentSession           the current session
	 * @param currentInstance          the current instance
	 * @param isPreviousMh             the is previous mh
	 * @return true, if successful
	 */
	public void initPlan(DroolsParameters droolsParams, List<Task> previousTasks,
			List<EquivalentDTO> previousTheatreInSession, String currentSession, int currentInstance,
			boolean isPreviousMh) {
		try {

			Logger logger = DroolsParameters.getLogger();
			String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);
			droolsParams.setCurrentSession(sessionInstance);
			// create an object of type InitPlanTasks to split all the
			// previously accepted tasks by type
			InitPlanTasks initPlanTask = this.du.splitTasksByCategory(previousTasks);

			for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {
				droolsParams.getAllVisibilities().get(i)
						.setAvailableStartTimeL1(droolsParams.getAllVisibilities().get(i).getStartTime());
				droolsParams.getAllVisibilities().get(i)
						.setAvailableStartTimeL2(droolsParams.getAllVisibilities().get(i).getStartTime());
			}
			// get the current active session
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
			logger.debug("***************************** init plan  ***************************** ");
			logger.debug("CURRENT MH FOR INIT PLAN :" + droolsParams.getCurrentMH());

			TreeMap<String, PriorityQueue> downloadPriorityQueue = new TreeMap<>();

			logger.info("************* init plan : TASKS THAT WILL BE INSERTED : START");

			for (int i = 0; i < previousTasks.size(); i++) {
				logger.info("************* init plan :" + previousTasks.get(i));
			}
			logger.info("************* init plan : TASKS THAT WILL BE INSERTED : STOP \n");

			// get the global ResourceFunctions that contains all the resources
			// allocated for this session
			ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
			resFunc.getDownloadPriorityQueueForSat("1").clear();
			resFunc.getDownloadPriorityQueueForSat("2").clear();

			InitPlanManagement initPlanMng = new InitPlanManagement();

			// get all previous acquisitions
			List<Acquisition> onlyPreviousAcquisitions = initPlanTask.getAllInitAcq();
			TreeMap<String, Acquisition> prevAcqTreeMapsat1 = new TreeMap<>();
			TreeMap<String, Acquisition> prevAcqTreeMapsat2 = new TreeMap<>();

			DownloadManagement dwlMng = new DownloadManagement();

			// filter previous tasks removing acquisitions
			previousTasks.removeAll(initPlanTask.getAllInitAcq());
			previousTasks.removeAll(initPlanTask.getAllInitDwl());
			previousTasks.removeAll(initPlanTask.getAllInitSto());

			for (int i = 0; i < initPlanTask.getAllInitSto().size(); i++) {
				Storage sto = initPlanTask.getAllInitSto().get(i);
				sto.setPreviousMh(true);
				resFunc.getStoragesAssociatedToSat(sto.getSatelliteId()).put(sto.getIdTask(), sto);
			}

			DownloadUtils dwlUtils = new DownloadUtils();
			for (int j = 0; j < initPlanTask.getAllInitDwl().size(); j++) {

				Download dwl = initPlanTask.getAllInitDwl().get(j);
				dwl.setPreviousMh(true);
				TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
						.getDownloadsAssociatedToSat(dwl.getSatelliteId());

				logger.info("************* init plan : inserting download :" + dwl);

				List<Visibility> allVisInOverlapWithDwl = dwlUtils.findAllVisInOverlapWithDate(dwl.getStartTime(),
						dwl.getEndTime(), droolsParams.getAllVisibilities(), dwl.getSatelliteId());
				dwlMng.insertInIDownloadStructure(dwl, allVisInOverlapWithDwl, dwlTreeMap);
			}

			// insert previous tasks except acquisitions
			initPlanMng.insertPreviousTasks(kieSession, previousTasks);

			TreeMap<String, Download> allDwlAsMap = new TreeMap<>();
			for (int j = 0; j < initPlanTask.getAllInitDwl().size(); j++) {
				String keyDwl = dwlMng.getKeyTreeMapDownloads(initPlanTask.getAllInitDwl().get(j));
				allDwlAsMap.put(keyDwl, initPlanTask.getAllInitDwl().get(j));
			}

			// iterate over previously accepted acquisitions
			for (int i = 0; i < onlyPreviousAcquisitions.size(); i++) {
				// get the number of dto count
				int key = getContDto();

				// extract i.-e-esim acq
				Acquisition acq = onlyPreviousAcquisitions.get(i);
				acq.setKey(key);

				downloadPriorityQueue = resFunc.getDownloadPriorityQueueForSat(acq.getSatelliteId());

				if (acq.getSatelliteId().contains("1")) {
					prevAcqTreeMapsat1.put(dwlMng.getPriorityKey(acq), acq);

				} else {
					prevAcqTreeMapsat2.put(dwlMng.getPriorityKey(acq), acq);
				}
				// if the tasks that we are inserting are referred to previous
				// mh
				if (isPreviousMh) {
					// mark the acq as previously processed
					acq.setPreviousMh(true);

					acq.setDecrementBic(false);
				}

				acq.setPriority(key);
				key++;
				setContDto(key);
				logger.info("************* init plan : inserting acq " + acq);

				// insert the acq in drools
				kieSession.insert(acq);

				// active all the rules
				kieSession.fireAllRules();

				DroolsQueries dq = new DroolsQueries();

				TreeMap<String, Storage> allStorages = resFunc.getStoragesAssociatedToSat(acq.getSatelliteId());

				Storage relatedSto = dq.getStoWithGivenid(allStorages, acq.getIdTask());

				if (relatedSto != null) {
					List<Download> allDwlRelatedToSto = dq.getAllDwlRelatedToSto(droolsParams, acq.getIdTask(),
							allDwlAsMap);
					dwlMng.initPlanDownload(acq, relatedSto, allDwlRelatedToSto, droolsParams, downloadPriorityQueue);

				} 

				@SuppressWarnings("unchecked")
				TreeMap<String, PriorityQueue> downloadPriorityQueueCloned = (TreeMap<String, PriorityQueue>) DroolsUtils
						.deepClone(downloadPriorityQueue);
				resFunc.setDownloadPriorityQueueSatInitPlanSat(acq.getSatelliteId(), downloadPriorityQueueCloned);

			}

			// if there are previously processed theatres
			if (previousTheatreInSession != null) {
				// iterate over them
				for (int j = 0; j < previousTheatreInSession.size(); j++) {
					logger.debug("INIT PLAN MANAGEMENT : inserting previously accepted theatre : "
							+ previousTheatreInSession.get(j));
					// insert inside Drools
					kieSession.insert(previousTheatreInSession.get(j));
				}
			}

			Map<String, Task> alltasksAfterInitPlan = getAllTasksAcceptedAsMap(droolsParams, currentSession,
					currentInstance);
			logger.debug(
					"************* init plan : inserted " + alltasksAfterInitPlan.size() + " previously planned task");
			// processDownloadsFromPrevSession(droolsParams, currentSession,
			// currentInstance);
		} catch (Exception e) {
			// there isn't a session with this id
			logger.error("************* init plan : there isn't a session with this id : " + e.toString());
			throw new NullPointerException(
					"************* init plan : there isn't a session with this id " + e.getStackTrace());
		}
	}

	/**
	 * Process downloads from prev session.
	 *
	 * @param droolsParams    the drools params
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 */
	public void processDownloadsFromPrevSession(DroolsParameters droolsParams, String currentSession,
			int currentInstance) {
		logger.info("************* processDownloadsFromPrevSession ");
		logger.info("************* init plan : create downloads for retain tasks in previous mission horizon...");

		// get the univoque session instanc
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the related kiSession
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get the resourc functions related to the kieSession
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		// get the pdht structure
		TreeMap<Long, ComplexPdht> localPdhtFunction = resFunc.getPDHTFunctionAssociatedToSat("1");

		// get the download priority structure
		TreeMap<String, PriorityQueue> downloadPrioritySat1 = resFunc.getDownloadPriorityQueueForSat("1");

		// get the downloads structure
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat1 = resFunc
				.getDownloadsAssociatedToSat("1");

		// restore the priority queue with all the
		// initial amount of sectors that must be downloaded
		this.pdhtMng.restorePriorityQueue(downloadPrioritySat1);

		// remov from structure all the previous downloads
		this.dwlMng.removeAllDownloadsExceptPT("1", droolsParams, dwlTreeMapSat1, resFunc);

		// if there are element that needs download for sat1
		if (!downloadPrioritySat1.isEmpty()) {

			// get all toraes relative to the sat1
			TreeMap<String, Storage> allStorages = resFunc.getStoragesAssociatedToSat("1");

			// create a new arrayList of tasks that
			// will be a collection of download and storages
			List<Task> allCreatedDwlsAndSto = new ArrayList<>();

			// creat an arrayList of downloads
			List<Task> allCreatedDwl = new ArrayList<>();

			/*
			 * invoke the alo for create the downloads
			 */
			allCreatedDwl = this.dwlMng.processDownloadFromPriorityQueue(allCreatedDwl, downloadPrioritySat1,
					droolsParams, dwlTreeMapSat1, resFunc, "1");

			/*
			 * if there are created dwl
			 */
			if (allCreatedDwl.size() > 0) {
				/*
				 * add the downloads just reated to the list
				 */
				allCreatedDwlsAndSto.addAll(allCreatedDwl);
			}

			// add also all the storages
			allCreatedDwlsAndSto.addAll(allStorages.values());

			// clear all the instances of pdht from the mh startTime to mhstop time
			localPdhtFunction.subMap(droolsParams.getCurrentMH().getStart().getTime() + 1000, false,
					droolsParams.getCurrentMH().getStop().getTime(), true).clear();

			/*
			 * check if the pdht is overheaded after the insert of the storages and
			 * downloads
			 */
			this.pdhtMng.checkPdhtOverload(allCreatedDwlsAndSto, localPdhtFunction, droolsParams, allStorages);

			// persist downloads
			resFunc.setDownloadsAssociatedToSat("1", dwlTreeMapSat1);
			this.dwlMng.persistDwl(allCreatedDwl, dwlTreeMapSat1, droolsParams, "1");
		}

		// get priority quue for sat2
		TreeMap<String, PriorityQueue> downloadPrioritySat2 = resFunc.getDownloadPriorityQueueForSat("2");

		// get downloads planned for sat2

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMapSat2 = resFunc
				.getDownloadsAssociatedToSat("2");

		// restore the priority queue for sat2
		this.pdhtMng.restorePriorityQueue(downloadPrioritySat2);

		this.dwlMng.removeAllDownloadsExceptPT("2", droolsParams, dwlTreeMapSat2, resFunc);

		if (!downloadPrioritySat2.isEmpty()) {
			List<Task> allCreatedDwlsAndSto = new ArrayList<>();
			TreeMap<String, Storage> allStorages = resFunc.getStoragesAssociatedToSat("2");

			List<Task> allCreatedDwl = new ArrayList<>();
			allCreatedDwl = this.dwlMng.processDownloadFromPriorityQueue(allCreatedDwl, downloadPrioritySat2,
					droolsParams, dwlTreeMapSat2, resFunc, "2");
			if (allCreatedDwl.size() > 0) {
				// add the downloads just reated to the list
				allCreatedDwlsAndSto.addAll(allCreatedDwl);
			}

			// add also all the storages
			allCreatedDwlsAndSto.addAll(allStorages.values());

			localPdhtFunction.subMap(droolsParams.getCurrentMH().getStart().getTime() + 1000, false,
					droolsParams.getCurrentMH().getStop().getTime(), true).clear();

			this.pdhtMng.checkPdhtOverload(allCreatedDwlsAndSto, localPdhtFunction, droolsParams, allStorages);
			resFunc.setDownloadsAssociatedToSat("2", dwlTreeMapSat2);

			this.dwlMng.persistDwl(allCreatedDwl, dwlTreeMapSat2, droolsParams, "2");
		}
	}

	/**
	 * Insert dto.
	 *
	 * @param droolsParams    the drools params
	 * @param singleDto       the single dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	@SuppressWarnings("unchecked")
	public boolean insertDto(DroolsParameters droolsParams, DTO singleDto, String currentSession, int currentInstance)
			throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// create a boolean variable that determine if the dto is accepted or
		// not
		boolean accepted = true;
		// create an acquisition
		Acquisition relatedAcq = null;
		try {
			logger.debug("current session : " + sessionInstance);
			// get the current kie session
			KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
			droolsParams.setCurrentSession(sessionInstance);

			// check if the dto is already into the session
			QueryResults dtoIsAlreadyInWorkingMemory = kie.getQueryResults("acqWithGivenId", singleDto.getDtoId());
			if (dtoIsAlreadyInWorkingMemory.size() > 0) {
				logger.debug("the dto is already in the working memory ,  it cannot be inserted again !");
				// dto is still present, cannot be inserted again, set the
				// boolean variable to false
				accepted = false;
			} else {
				// set the dto id (an incremental number)
				int dtoKey = getContDto();
				singleDto.setKey(dtoKey);
				singleDto.setRejected(false);

				// increment the key
				dtoKey++;
				setContDto(dtoKey);
				// insert the dto inside the current session
				kie.insert(singleDto);

				// execute all the rules
				kie.fireAllRules();

				// receive the acquisition related to the inserted dto
				QueryResults dtoWithId = kie.getQueryResults("acqWithGivenId", singleDto.getDtoId());

				// if there is a valid result
				if (dtoWithId.size() == 1) {
					for (QueryResultsRow row : dtoWithId) {
						// extract the acquisition
						relatedAcq = (Acquisition) row.get("$acq");
						logger.debug("ACQ correctly planned : " + relatedAcq);

						// if the acquisition isn't a PT
						if (relatedAcq.isPassThroughFlag() == false) {
							logger.debug("insert in pdht" + relatedAcq.getIdTask());

							accepted = this.pdhtMng.updatePdhtTillEnd(currentSession, currentInstance, relatedAcq, null,
									droolsParams, relatedAcq.getSatelliteId());

						} else {
							// the acquisition is a PT, the storage is
							// guaranteed by a specific procedure
							logger.debug("the acquisition " + relatedAcq.getIdTask()
									+ " is accepted as passthrough, no storages are needed.");
						}
					}
				}
				// there isn't an acq associated, so the dto was rejected
				else {
					// if the sensor mode of dto wasn't BITE (no related
					// acquisition for this case)
					if (!singleDto.getSensorMode().equals(TypeOfAcquisition.BITE)) {
						// extract the rejected global variable
						Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) kie
								.getGlobal("rejected");
						logger.debug("reject elements :" + rejectedElements);
						logger.debug("ACQ is rejected : " + rejectedElements.get(singleDto.getDtoId()));

						// mark the boolean variable as false -> Dto rejected
						accepted = false;
					}
					// the dto is of type BITE
					else {
						// extract the BITE associated with the current dto
						QueryResults associatedBite = kie.getQueryResults("biteWithGivenId", singleDto.getDtoId());

						// if there is a match
						if (associatedBite.size() > 0) {
							logger.debug("ACQ is accepted : BITE correctly performed");
							// mark the boolean variable as true -> Dto accepted
							accepted = true;
						}
						// there isn't a bite associated
						else {
							logger.debug("ACQ is rejected : BITE cannot be performed");
							// mark the boolean variable as false -> Dto
							// rejected
							accepted = false;
						}
					}
				}
			}
			if (accepted) {
				logger.info("all done for the current acquisition ");
			} else {
				logger.info("the current acquisition is rejected");
			}
		} catch (Exception e) {
			logger.error("Exception : " + e.toString());
			logger.error("retract single acq : " + singleDto.getDtoId());

			retractSingleAcq(droolsParams, singleDto.getDtoId(), currentSession, currentInstance,
					ReasonOfReject.internallyInconsistent);
			// the id isn't related to a valid session
			try {
				throw new Exception("Exception : " + e.getStackTrace());
			} catch (Exception e1) {

				e1.printStackTrace();
			}
		}

		return accepted;
	}

	/**
	 * Clear the current session, removing all the planned tasks.
	 *
	 * @param currentSession         the current session of Drools
	 * @param currentInstance        the current instance
	 * @param droolsParams           the drools params
	 * @param cancelRejectedElements if true, cancel also the rejectedElements list
	 */
	@SuppressWarnings("unchecked")
	public void clearSessionInstance(String currentSession, int currentInstance, DroolsParameters droolsParams,
			boolean cancelRejectedElements) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the logger
		Logger logger = DroolsParameters.getLogger();
		try {
			logger.debug("current session : " + currentSession);

			// extract the current kie session
			KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
			logger.debug("drools env : " + SessionHandler.getKieSessionsMap());

			// get the resource functions from Drools global
			ResourceFunctions resFunc = (ResourceFunctions) kie.getGlobal("resourceFunctions");
			kie.setGlobal("isLmpOrVu", false);

			// restore all the resources
			resFunc.clearAll();
			logger.debug("res func ess : " + resFunc.getEssFunctionSat1());

			// for every pdht
			for (int i = 0; i < droolsParams.getAllPDHT().size(); i++) {
				// get the satellite id
				String satId = droolsParams.getAllPDHT().get(i).getSatelliteId();

				// insert into the pdht function the initial state of pdht
				resFunc.getPDHTFunctionAssociatedToSat(satId).put(droolsParams.getCurrentMH().getStart().getTime(),
						new ComplexPdht(droolsParams.getAllPDHT().get(i)));
			}

			// if there is the command in input to cancel the rejected elements
			if (cancelRejectedElements == true) {
				// get the global variable where are stored all the rejected
				// elements
				Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) kie.getGlobal("rejected");

				// clear it
				rejectedElements.clear();
			}

			// create an empty list of taks
			List<Task> allTasksAccepted = new ArrayList<>();

			// invoke the drools function to get all the accepted tasks
			QueryResults queryResults = kie.getQueryResults("getAllAcceptedTasks");

			Iterator<QueryResultsRow> iterator = queryResults.iterator();

			// iterate over the results
			while (iterator.hasNext()) {
				// extract the i.esim task
				Task task = (Task) iterator.next().get("$task");

				// add to the empty list of tasks
				allTasksAccepted.add(task);
			}

			// iterate over the just filled list of tasks
			for (int i = 0; i < allTasksAccepted.size(); i++) {
				// if the i-esim task is an acquisition
				if (allTasksAccepted.get(i) instanceof Acquisition) {
					// extract it
					Acquisition acq = (Acquisition) allTasksAccepted.get(i);
					logger.debug("retracting acq for clear session");

					acq.setRemovableFlag(true);

					// retract from drools
					retractSingleAcq(droolsParams, acq.getIdTask(), currentSession, currentInstance, null);
				}
			}
			// get all the fact handles for the current kie instance
			Collection<FactHandle> allFacts = kie.getFactHandles();

			// iterate over the set
			for (FactHandle iterable_element : allFacts) {
				// delete each fact handle
				kie.delete(iterable_element);
			}

			// restore all the resources
			this.envUtils.setAllResources(droolsParams, resFunc, kie,
					droolsParams.getSatWithId("1").getSatelliteProperties(),
					droolsParams.getSatWithId("2").getSatelliteProperties());
		}
		// manage the exception if it's
		// impossible to find a session
		catch (NullPointerException e) {
			logger.error("there isn't a session with this id : " + currentSession + ": " + e.toString());
			throw new NullPointerException("there isn't a session with this id " + e.getStackTrace());
		}
	}

	/**
	 * Insert equivalent dto.
	 *
	 * @param equivDto        the equiv dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	public boolean insertPreviousEquivalentDto(EquivalentDTO equivDto, String currentSession, int currentInstance) {

		// initialize the variable to track if the process is ok or not
		boolean accepted = true;

		// get the current session instance
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// DroolsOperations.logger.debug("Trying to insert into the working
		// memory an EquivDTO previously processed : \n" + equivDto);

		// DroolsOperations.logger.debug("current session : " + currentSession);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// extract the equivalent dto with the id of the equivalent dto in
		// input, if
		// exist
		QueryResults resultsAcqAssociated = kie.getQueryResults("getEquivDtoWithId", equivDto.getEquivalentDtoId());

		// if there is a valid match
		if (resultsAcqAssociated.size() > 0) {

			// the same equivalent dto is already inserted, cannot be inserted
			// again.
			DroolsOperations.logger
					.debug("the equivalentDto is already in  the working memory , it cannot be inserted again !");

			// set the boolean variable to false
			accepted = false;
		}
		// no equivalent dto found -> can be inserted
		else {

			// insert the equivalent dto in Drools
			kie.insert(equivDto);

			// execute all the rules
			kie.fireAllRules();
		}
		return accepted;
	}

	/**
	 * Insert list dto.
	 *
	 * @param listDto         the list dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return true, if successful
	 */
	public boolean insertListDto(List<DTO> listDto, String currentSession, int currentInstance,
			DroolsParameters droolsParams) {
		droolsParams.setDownloadTriggeredFromCSPS(false);

		// get the current session instance
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// initialize the boolean variable to false
		boolean accepted = false;

		// get the number of dto given as input
		int cont = listDto.size();

		// initialize the cont of dto to zero
		int contValidDto = 0;
		try {
			// get the current kie session
			KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

			// set the current session
			droolsParams.setCurrentSession(sessionInstance);
			kie.setGlobal("currentSession", currentSession);

			// iterate over the list of dto
			for (int i = 0; i < listDto.size(); i++) {

				// get the i-esim dto
				DTO dto = listDto.get(i);

				boolean acceptedDto = insertDto(droolsParams, dto, currentSession, currentInstance);
				if (acceptedDto) {
					contValidDto++;
				}
			}
			// if all dtos are acceopted
			if (contValidDto == cont) {
				// return true
				accepted = true;
				// processDownloadsFromPrevSession(droolsParams, currentSession,
				// currentInstance);
			}
			// otherwise
			else {
				// return false
				accepted = false;
			}
		}
		// if there isn't a session associated
		catch (NullPointerException e) {
			DroolsOperations.logger.error("there isn't a session with this id : " + e.toString());
			// throw the exception
			throw new NullPointerException("there isn't a session with this id " + e.getStackTrace());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accepted;
	}

	/**
	 * Insert partner.
	 *
	 * @param partner         the partner
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	public void insertPartner(Partner partner, String currentSession, int currentInstance) {
		// get the current active session
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// iterate over the loan list of the partner given in input
		for (int i = 0; i < partner.getLoanList().size(); i++) {
			// mark each element to previously processed
			partner.getLoanList().get(i).setPrevious(true);
		}

		// iterate over the borrow list of the partner given in input
		for (int i = 0; i < partner.getGivenLoan().size(); i++) {
			// mark each element as previously processed
			partner.getGivenLoan().get(i).setPrevious(true);
		}
		// insert the partner in drools
		kie.insert(partner);

		// execute the rules
		kie.fireAllRules();

	}

	/**
	 * Gets the all tasks accepted as map.
	 *
	 * @param droolsParams    the drools params
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the all tasks accepted as map
	 */
	public Map<String, Task> getAllTasksAcceptedAsMap(DroolsParameters droolsParams, String currentSession,
			int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);
		// create an empty map of tasks
		Map<String, Task> allTasksAccepted = new HashMap<>();

		// create an empty list of acquisitions
		List<Acquisition> allAcq = new ArrayList<>();

		// create an empty list of storages
		List<Storage> allSto = new ArrayList<>();

		// create an empty list of downloads
		List<Download> allDwl = new ArrayList<>();

		// create an empty list of silents
		List<Silent> allSil = new ArrayList<>();

		// create an empty list of maneuvers
		List<Maneuver> allMan = new ArrayList<>();

		// create an empty list of ramps
		List<RampCMGA> allRamps = new ArrayList<>();

		// create an empty list of storeAux
		List<StoreAUX> allStoAux = new ArrayList<>();

		// create an empty list of passThrough
		List<PassThrough> allPT = new ArrayList<>();

		// create an empty list of cmgAxis
		List<CMGAxis> allCmgaAxisReconf = new ArrayList<>();

		// create an empty list of bites
		List<Bite> allBites = new ArrayList<>();

		// if the session given as input is a valid one
		if (SessionHandler.getKieSessionsMap().containsKey(sessionInstance)) {
			// create an instance of taskPlanned where collect all the accepted
			// tasks
			TaskPlanned taskPlanned = new TaskPlanned();

			// get the active kie session
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

			ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
			DownloadManagement dwlMng = new DownloadManagement();
			// iterate over the satellites
			for (int i = 0; i < droolsParams.getAllSat().size(); i++) {
				String satId = droolsParams.getAllSat().get(i).getSatelliteId();

				// get the downloads relative to the currrent satellite
				TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
						.getDownloadsAssociatedToSat(satId);

				// add all acquisitions to the list, filtered by satellite
				allAcq.addAll(receiveAllAcquisitions(currentSession, currentInstance, satId));

				TreeMap<String, Storage> allStoragesAsMAp = receiveAllStorages(currentSession, currentInstance, satId);
				// add all storages to the list, filtered by satellite

				for (Map.Entry<String, Storage> allStorages : allStoragesAsMAp.entrySet()) {
					allSto.add(allStorages.getValue());
				}

				// add all downloads to the list , filtered by satellite
				allDwl.addAll(dwlMng.getAllDwlFromTreeMap(satId, droolsParams, dwlTreeMap));

				// and also the downloads of type GPS
				allDwl.addAll(DownloadManagement.getAllDwlFromTreeMapGPS(satId, droolsParams, dwlTreeMap));

				// add all storeAux to the list, filtered by satellite
				allStoAux.addAll(taskPlanned.receiveAllStoreAux(currentSession, currentInstance, droolsParams, satId));

				// add all silents to the list, filtered by satellite
				allSil.addAll(taskPlanned.receiveAllSilent(currentSession, currentInstance, droolsParams, satId));

				// add all ramps to the list, filtered by satellite
				allRamps.addAll(taskPlanned.receiveAllRamps(currentSession, currentInstance, droolsParams, satId));

				// add all passThrough to the list, filtered by satellite
				allPT.addAll(receiveAllPassTrhough(currentSession, currentInstance, satId, droolsParams));

				// add all maneuvers to the list, filtered by satellite
				allMan.addAll(taskPlanned.receiveAllManeuvers(currentSession, currentInstance, droolsParams, satId));

				// add all cmgAxis to the list, filtered by satellite
				allCmgaAxisReconf.addAll(receiveAllCmgaAxis(droolsParams, currentSession, currentInstance, satId));

				// add all bites to the list, filtered by satellite
				allBites.addAll(receiveAllBites(currentSession, currentInstance, satId, droolsParams));
				addAllElements(allTasksAccepted, allAcq, allSto, allStoAux, allSil, allRamps, allMan, allBites, allDwl,
						allPT, allCmgaAxisReconf);

				// allTasksAccepted = filterTasksForMh(allTasksAccepted,
				// droolsParams);
			}
		}
		return allTasksAccepted;
	}

	/**
	 * Filter tasks for mh.
	 *
	 * @param allTasksAccepted the all tasks accepted
	 * @param droolsParams     the drools params
	 * @return the map
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Task> filterTasksForMh(Map<String, Task> allTasksAccepted, DroolsParameters droolsParams) {
		logger.debug("all tasks : " + allTasksAccepted);

		Map<String, Task> allTasksAcceptedCloned = (Map<String, Task>) DroolsUtils.deepClone(allTasksAccepted);

		// iterate over the cloned map
		for (Map.Entry<String, Task> tasksIterator : allTasksAcceptedCloned.entrySet()) {
			// extract the task
			Task task = tasksIterator.getValue();
			logger.debug("task :" + task);

			// if the task is relative to the current mh
			if ((droolsParams.getCurrentMH().getStart().getTime() <= task.getEndTime().getTime())
					&& (droolsParams.getCurrentMH().getStop().getTime() >= task.getStartTime().getTime())) {
				// logger.debug("task is inside mh, correctly inserted");
			}
			// if the task is outside the current mh
			else {
				// remove from the list
				allTasksAccepted.remove(tasksIterator.getKey());
			}
		}
		return allTasksAccepted;
	}

	/**
	 * Filter tasks for mh list.
	 *
	 * @param allTasksAccepted the all tasks accepted
	 * @param droolsParams     the drools params
	 * @return the list
	 */
	public static List<Task> filterTasksForMhList(List<Task> allTasksAccepted, DroolsParameters droolsParams) {
		logger.debug("all tasks : " + allTasksAccepted);

		List<Task> allTasksAcceptedCloned = new ArrayList<>();

		// iterate over the cloned map
		for (int i = 0; i < allTasksAccepted.size(); i++) {
			// extract the task
			Task task = allTasksAccepted.get(i);
			logger.debug("task :" + task);

			// if the task is relative to the current mh
			if ((droolsParams.getCurrentMH().getStart().getTime() <= task.getEndTime().getTime())
					&& (droolsParams.getCurrentMH().getStop().getTime() >= task.getStartTime().getTime())) {
				// logger.debug("task is inside mh, correctly inserted");
				allTasksAcceptedCloned.add(task);
			}
		}
		return allTasksAcceptedCloned;
	}

	/**
	 * Receive all acquisitions as map.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param satId           the sat id
	 * @return the map
	 */
	public Map<String, Acquisition> receiveAllAcquisitionsAsMap(String currentSession, int currentInstance,
			DroolsParameters droolsParams, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// create an empty map for all the valid acquisitions
		Map<String, Acquisition> allAcq = new HashMap<>();
		logger.trace("receive all acquisitions method ");

		// if the session given as input isn't initialized yet
		if (!SessionHandler.getKieSessionsMap().containsKey(sessionInstance)) {
			// error with the session
			logger.error("there isn't a session with this id.");

			// return an empty map
			allAcq = null;
		}
		// the session is a valid one
		else {
			// get the current kieSession relative to the session id
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

			// invoke the Drools query to receive all the valid acquisitions
			QueryResults resultsAcq = kieSession.getQueryResults("getObjectsOfAcquisition", satId);

			// iterate over the QueryResults
			for (QueryResultsRow row : resultsAcq) {
				// cast the i-esim returned object into an acquisition
				Acquisition acq = (Acquisition) row.get("$allAcq");
				logger.trace("found acq : " + acq);

				// add the acquisition to the map
				allAcq.put(acq.getId(), acq);
			}
		}
		logger.trace("returned acq map : " + allAcq);

		// return the map
		return allAcq;
	}

	/**
	 * Receive all cmga axis.
	 *
	 * @param droolsParams    the drools params
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @return the collection<? extends CMG axis>
	 */
	private Collection<? extends CMGAxis> receiveAllCmgaAxis(DroolsParameters droolsParams, String currentSession,
			int currentInstance, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// create an empty list of cmgAxis
		List<CMGAxis> allCMGAxis = new ArrayList<>();

		// get the current kieSession
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get the resourceFunctions with all the resources useful for this
		// session
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		// get the map with all the valid cmgAxis
		TreeMap<Long, CMGAxis> cmgAxisForSat = resFunc.getCmgaAxisAssociatedToSat(satId);

		// if the map is not empty
		if (!cmgAxisForSat.isEmpty()) {
			// iterate over the map
			for (Map.Entry<Long, CMGAxis> elemensOfAxis : cmgAxisForSat.entrySet()) {
				// extract the i-esim element
				CMGAxis axis = elemensOfAxis.getValue();
				// DroolsOperations.logger.debug("axis found:" + axis);

				// add it to the returned list
				allCMGAxis.add(axis);
			}
		}
		// return the list
		return allCMGAxis;
	}

	/**
	 * Gets the correct conflict rank.
	 *
	 * @param acqId           the acq id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param reason          the reason
	 * @return the correct conflict rank
	 */
	@SuppressWarnings("unchecked")
	public String getCorrectConflictRank(String acqId, String currentSession, int currentInstance,
			ReasonOfReject reason) {

		FunctionUtils funcUtils = new FunctionUtils();

		// initialize the conflict rank
		String returnedConflictRank = null;

		// initialize the type of rank
		boolean rankUp = true;

		// initialize the relative acq
		Acquisition acq = null;

		// get all rejected elements
		Map<String, Acquisition> allRejectedAcq = (Map<String, Acquisition>) getGlobal(currentSession, currentInstance,
				"rejected");

		HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) getGlobal(currentSession,
				currentInstance, "allAccepted");

		// check if the id given as input is of a rejected acq
		try {
			// get the acq
			acq = allRejectedAcq.get(acqId);

			// check if the reason of reject of the acquisition match with one
			// of the reasons that need a rankUp
			boolean up = reason.equals(ReasonOfReject.acqOverlapWithAcquisition)
					|| reason.equals(ReasonOfReject.maneuverOverlapDloOrPaw)
					|| reason.equals(ReasonOfReject.maneuverOverlapWithAcquisition)
					|| reason.equals(ReasonOfReject.noTimeForAxesReconf)
					|| reason.equals(ReasonOfReject.acqOverlapWithPassThrough)
					|| reason.equals(ReasonOfReject.passThroughOverlapAcq)
					|| reason.equals(ReasonOfReject.acqOverlapWithAcquisition);

			// check if the reason of reject of the acquisition match with one
			// of the reasons that need a rankDown
			boolean down = reason.equals(ReasonOfReject.minDistanceViolation)
					|| reason.equals(ReasonOfReject.noTimeForAManeuver)
					|| reason.equals(ReasonOfReject.acqOverlapTheatre)
					|| reason.equals(ReasonOfReject.smoothingEssUnranked) || reason.equals(ReasonOfReject.noSpaceInPdht)
					|| reason.equals(ReasonOfReject.HpFixedOrbitLimitReached)
					|| reason.equals(ReasonOfReject.maxNumberPrType)
					|| reason.equals(ReasonOfReject.noEnergyForSilentInEclipse)
					|| reason.equals(ReasonOfReject.noEnergyForSilent)
					|| reason.equals(ReasonOfReject.reachedOrbitThreshold)
					|| reason.equals(ReasonOfReject.reachedOrbitThresholdInEclipse)
					|| reason.equals(ReasonOfReject.CMGFormulaViolation)
					|| reason.equals(ReasonOfReject.leftAttitudeModeViolation)
					|| reason.equals(ReasonOfReject.essLeftMoreThanThreshold)
					|| reason.equals(ReasonOfReject.moreThanLeftAttitudeTimeThreshold)
					|| reason.equals(ReasonOfReject.moreThanUpperBoundPeaksBic)
					|| reason.equals(ReasonOfReject.reachedOrbitThreshold);

			// if the requested reason is up
			if (up) {
				// return the id with highest rank of same partner
				rankUp = true;
				returnedConflictRank = funcUtils.rankUpDown(allAccepted, acq, rankUp, allRejectedAcq);
			}

			// if the requested rank is down
			else if (down) {
				// return the id with highest rank of same partner
				rankUp = false;
				returnedConflictRank = funcUtils.rankUpDown(allAccepted, acq, rankUp, allRejectedAcq);
			}
		} catch (NullPointerException e) {
			// DroolsOperations.logger.error("not found a relative acq for this
			// id");
		}
		return returnedConflictRank;
	}

	/**
	 * Check if LM P V U is valid for overlap.
	 *
	 * @param droolsParams    the drools params
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param dto             the dto
	 * @return the map
	 */
	@SuppressWarnings("unchecked")
	public Map<Boolean, List<String>> checkIfLMP_VU_IsValidForOverlap(DroolsParameters droolsParams,
			String currentSession, int currentInstance, DTO dto) {

		// create an empty list of results
		Map<Boolean, List<String>> LMPisPossible = new HashMap<>();

		boolean possible = false;

		// create an instance of EssEnergyManagement
		EssEnergyManagement essManagement = new EssEnergyManagement();

		// create an empty acquisition
		Acquisition acq = new Acquisition();

		// convert the Dto to an acq
		try {
			acq.createAcqFromDto(dto, acq);

			// get the resource functions object
			ResourceFunctions resourceFunctions = (ResourceFunctions) getGlobal(currentSession, currentInstance,
					"resourceFunctions");

			// get the list of rejected elements
			Map<String, Acquisition> rejected = (Map<String, Acquisition>) getGlobal(currentSession, currentInstance,
					"rejected");

			HashMap<String, Acquisition> accepted = (HashMap<String, Acquisition>) getGlobal(currentSession,
					currentInstance, "allAccepted");

			// get all the configurations maps
			ConfigMaps configMaps = (ConfigMaps) getGlobal(currentSession, currentInstance, "configMaps");

			// get the treemap with all the acq
			TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions
					.getEssFunctionAssociatedToSat(acq.getSatelliteId());

			// check if the element is in overlap with other acq
			List<String> elementsInOverlap = essManagement.checkAcqOverlap(droolsParams, acq, allAcq,
					configMaps.getMinDistanceMap());

			DtoToAcqRule dtoToAcq = new DtoToAcqRule();

			List<String> involvedElementId = new ArrayList<>();

			// if there is an overlap
			if ((elementsInOverlap != null) && !elementsInOverlap.isEmpty()) {
				// DroolsOperations.logger.debug("000_PlanAcqFromDto there are
				// overlapped elements , processing them... " +
				// elementsInOverlap);

				// invoke the function that detect the overlap with elements
				Map<Boolean, Map<String, Acquisition>> overlapMng = dtoToAcq.detectOverlapCases(acq, elementsInOverlap,
						rejected, accepted);

				// create a map of involved elements
				Map<String, Acquisition> involvedElements = new HashMap<>();

				// if the acquisition is valid
				if (overlapMng.get(true) != null) {
					possible = true;
				}
				// if the acquisition is not valid
				else {
					possible = false;
				}
				// get the involved elements
				involvedElements = overlapMng.get(possible);

				// add all the elements involved
				for (Map.Entry<String, Acquisition> elementInvolved : involvedElements.entrySet()) {
					involvedElementId.add(elementInvolved.getKey());
				}

				// add the involved elements to the list
				LMPisPossible.put(possible, involvedElementId);
			}

			// otherwise
			else {
				// add true to the list, lmp is possible
				LMPisPossible.put(true, involvedElementId);
			}
		}
		// get the exception
		catch (Exception e) {
			e.printStackTrace();
			logger.error("error checkIfLMP_VU_IsValidForOverlap " + e.getStackTrace());
		}

		return LMPisPossible;
	}

	/**
	 * Receive all bites.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @param droolsParams    the drools params
	 * @return the collection<? extends bite>
	 */
	private Collection<? extends Bite> receiveAllBites(String currentSession, int currentInstance, String satId,
			DroolsParameters droolsParams) {
		// get the current session instance
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// create an empty list of Bite elements
		List<Bite> allBites = new ArrayList<>();

		// get the current kieSession
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// invoke the query to collect the Bite objects
		QueryResults resultsAcq = kieSession.getQueryResults("getObjectsOfBites", satId);

		// if there is at least a valid acq
		if (resultsAcq.size() > 0) {
			for (QueryResultsRow row : resultsAcq) {
				Bite bite = (Bite) row.get("$allBites");
				allBites.add(bite);
			}
		}
		return allBites;
	}

	/**
	 * Receive all pass trhough.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @param droolsParams    the drools params
	 * @return the list
	 */

	private List<PassThrough> receiveAllPassTrhough(String currentSession, int currentInstance, String satId,
			DroolsParameters droolsParams) {

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		DownloadManagement dwlMng = new DownloadManagement();
		List<PassThrough> allPt = new ArrayList<>();
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
				.getDownloadsAssociatedToSat(satId);
		// DroolsOperations.logger.debug("download treemap sat : " + satId + "
		// is : " + dwlTreeMap);
		allPt = dwlMng.getAllPTFromTreeMap(satId, droolsParams, dwlTreeMap);
		// DroolsOperations.logger.debug("all PT : " + allPt);
		return allPt;
	}

	/**
	 * Adds the all elements.
	 *
	 * @param allTasksAccepted the all tasks accepted
	 * @param allAcq           the all acq
	 * @param allSto           the all sto
	 * @param allStoreAux      the all store aux
	 * @param allSil           the all sil
	 * @param allRamps         the all ramps
	 * @param allMan           the all man
	 * @param allBites         the all bites
	 * @param allDwl           the all dwl
	 * @param allPt            the all pt
	 * @param allCmgAxis       the all cmg axis
	 */
	private void addAllElements(Map<String, Task> allTasksAccepted, List<Acquisition> allAcq, List<Storage> allSto,
			List<StoreAUX> allStoreAux, List<Silent> allSil, List<RampCMGA> allRamps, List<Maneuver> allMan,
			List<Bite> allBites, List<Download> allDwl, List<PassThrough> allPt, List<CMGAxis> allCmgAxis) {
		for (int i = 0; i < allAcq.size(); i++) {
			allTasksAccepted.put("ACQ_" + allAcq.get(i).getIdTask(), allAcq.get(i));
		}
		for (int j = 0; j < allSto.size(); j++) {
			allTasksAccepted.put("STO_" + allSto.get(j).getIdTask(), allSto.get(j));
		}
		for (int w = 0; w < allDwl.size(); w++) {
			// DroolsOperations.logger.debug("addAllElements _ inserting dwl : "
			// + allDwl.get(w));
			String key = "DWL_" + allDwl.get(w).getIdTask() + w;
			allTasksAccepted.put(key, allDwl.get(w));
		}
		for (int k = 0; k < allStoreAux.size(); k++) {
			String key = "StoreAUX_" + allStoreAux.get(k).getIdTask() + k;
			allTasksAccepted.put(key, allStoreAux.get(k));
		}
		for (int k = 0; k < allSil.size(); k++) {
			allTasksAccepted.put("SIL_" + allSil.get(k).getIdTask(), allSil.get(k));
		}
		for (int y = 0; y < allMan.size(); y++) {
			allTasksAccepted.put("MAN_" + allMan.get(y).getIdTask(), allMan.get(y));
		}
		for (int y = 0; y < allBites.size(); y++) {
			allTasksAccepted.put("BITE_" + allBites.get(y).getIdTask(), allBites.get(y));
		}
		for (int w = 0; w < allRamps.size(); w++) {
			allTasksAccepted.put("RAMP_" + allRamps.get(w).getIdTask(), allRamps.get(w));
		}
		for (int q = 0; q < allPt.size(); q++) {
			allTasksAccepted.put("PT_" + allPt.get(q).getIdTask(), allPt.get(q));
		}
		for (int q = 0; q < allCmgAxis.size(); q++) {
			allTasksAccepted.put("CMG_Axis_" + allCmgAxis.get(q).getIdTask(), allCmgAxis.get(q));
		}
	}

	/**
	 * Check if di2s are consistent in distance.
	 *
	 * @param firstAcq        the first acq
	 * @param secondAcq       the second acq
	 * @param gap             the gap
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public boolean checkIfDi2sAreConsistentInDistance(TypeOfAcquisition firstAcq, TypeOfAcquisition secondAcq, long gap,
			String currentSession, int currentInstance, DroolsParameters droolsParams) {
		/*
		 * create a boolean variable to check if the distance between potential di2s
		 * couple of requests
		 */
		boolean correctDistance = false;

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the current kie Session
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get the minDistance map from drools Globals
		Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceProp = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) kieSession
				.getGlobal("minDistanceMap");

		/*
		 * extract the minDistance based on sensor modes of the couple of requests
		 */
		double mindistance = minDistanceProp.get(firstAcq).get(secondAcq);
		logger.debug("min distance between :" + firstAcq + " and " + secondAcq + " is : " + mindistance);
		logger.debug("gap is:" + (gap / 1000));

		// if the gap is less than the min distance
		if (mindistance > (gap / 1000)) {
			// the distance is valid
			correctDistance = true;
			logger.debug("min distance is more than gap, Di2s can be performed");
		} else {
			// the distance is invalid
			logger.debug("min distance is less than gap, Di2s cannot be performed");
		}
		return correctDistance;
	}

	/**
	 * Check if theatre is valid.
	 *
	 * @param equivDto        the equiv dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public boolean checkIfTheatreIsValid(EquivalentDTO equivDto, String currentSession, int currentInstance,
			DroolsParameters droolsParams) {
		boolean isConsistent = true;

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// extract the satellite id and his relative properties
		String satId = equivDto.getAllDtoInEquivalentDto().get(0).getSatelliteId();
		SatelliteProperties satProp = droolsParams.getSatWithId(satId).getSatelliteProperties();

		// extract the max number of theatre in a day for this satellite
		int maxNumberTheatreInADay = satProp.getMaxTheatreOnADay();
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		boolean maxNumberTheatreReached = false;
		// get the kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		logger.info("THEATRE OPERATION : check max number of theatre in a day");

		long aDayExpressedInMilliSec = 24 * 60 * 60000;
		List<Maneuver> allImpactedMan = new ArrayList<>();

		/*
		 * extract from Drools the map of rejected element that must be updated in case
		 * of theatre inconsistent internally
		 */
		Map<String, Acquisition> rejected = (Map<String, Acquisition>) kie.getGlobal("rejected");

		int theatreInADay = 0;

		/*
		 * set the start and the end range to check, centered on the acquisition under
		 * test (+-12 hours)
		 */
		long startTimeToCheck = equivDto.getEndTime().getTime() - (aDayExpressedInMilliSec);
		long endTimeToCheck = equivDto.getStartTime().getTime() + (aDayExpressedInMilliSec);
		logger.info("THEATRE OPERATION : start time of equivalent dto to check :  " + equivDto.getStartTime());
		logger.info("THEATRE OPERATION : stop time of equivalent dto to check :  " + equivDto.getEndTime());

		logger.info("THEATRE OPERATION : start check (based on current theatre) " + new Date(startTimeToCheck));
		logger.info("THEATRE OPERATION : end check (based on current theatre) " + new Date(endTimeToCheck));

		logger.info("ALL EQUIV DTO IN DROOLS :");

		// getEquivDto
		QueryResults allEquiv = kie.getQueryResults("getEquivDto");
		if (allEquiv.size() > 0) {
			for (QueryResultsRow row : allEquiv) {
				EquivalentDTO equivDTo = (EquivalentDTO) row.get("$equivDto");
				logger.info("ALL EQUIV DTO IN DROOLS :" + equivDTo);

			}
		}

		System.out.println(equivDto.getManAssociated().get(0).getSatelliteId());

		QueryResults dtoWithId = kie.getQueryResults("manCPS", new Date(startTimeToCheck), new Date(endTimeToCheck),
				equivDto.getManAssociated().get(0).getSatelliteId());

		List<String> theatreId = new ArrayList<>();
		if (dtoWithId.size() > 0) {
			for (QueryResultsRow row : dtoWithId) {
				Maneuver manCps = (Maneuver) row.get("$manCps");
				allImpactedMan.add(manCps);
				theatreId.add(manCps.getReferredEquivalentDto());
			}
		}

		for (int i = 0; i < allImpactedMan.size(); i++) {
			theatreInADay = 0;
			long startTimeToCheckInternalFirst = allImpactedMan.get(i).getEndTime().getTime()
					- (aDayExpressedInMilliSec);
			long endTimeToCheckInternalFirst = allImpactedMan.get(i).getStartTime().getTime();

			dtoWithId = kie.getQueryResults("manCPS", new Date(startTimeToCheckInternalFirst),
					new Date(endTimeToCheckInternalFirst), equivDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

			theatreId = new ArrayList<>();
			if (dtoWithId.size() > 0) {
				for (QueryResultsRow row : dtoWithId) {
					Maneuver manCps = (Maneuver) row.get("$manCps");
					theatreId.add(manCps.getReferredEquivalentDto());
					theatreInADay++;
				}

			}
			if ((theatreInADay + 1) > maxNumberTheatreInADay) {
				maxNumberTheatreReached = true;
				break;
			} else {
				theatreInADay = 0;
				long startTimeToCheckInternalSecond = allImpactedMan.get(i).getEndTime().getTime();
				long endTimeToCheckInternalSecond = allImpactedMan.get(i).getStartTime().getTime()
						+ (aDayExpressedInMilliSec);

				dtoWithId = kie.getQueryResults("theatreOverlapInterval", new Date(startTimeToCheckInternalSecond),
						new Date(endTimeToCheckInternalSecond),
						equivDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

				theatreId = new ArrayList<>();
				if (dtoWithId.size() > 0) {
					for (QueryResultsRow row : dtoWithId) {
						EquivalentDTO equivDTo = (EquivalentDTO) row.get("$equivDto");
						theatreId.add(equivDTo.getEquivalentDtoId());
						theatreInADay++;
					}

				}
				if ((theatreInADay + 1) > maxNumberTheatreInADay) {
					maxNumberTheatreReached = true;
					break;
				}
			}

		}

		logger.info("THEATRE OPERATION : max number allowed : " + maxNumberTheatreInADay);
		logger.info("THEATRE OPERATION : number of returned theatre in a day : " + dtoWithId.size());
		logger.info("THEATRE OPERATION : returned theatre in a day : " + theatreId);

		/*
		 * if with this theatre under analysis (+1) there is an overhead of theatre in a
		 * day
		 */
		if (maxNumberTheatreReached) {
			logger.info("THEATRE OPERATION : max number of theatre in a day reached, theatre is rejected");

			rejectTheatreForMAxNumberInADayReached(equivDto, kie, rejected);

			// set the consistence to false
			isConsistent = false;
		} else {
			logger.info("THEATRE OPERATION : max number of theatre in a day not reached, check passed");

			// get the configuration environment declared in Drools as global
			// variable
			ConfigMaps configMaps = (ConfigMaps) kie.getGlobal("configMaps");

			// get the map with all the max duration of dtos based on their
			// sensor mode
			Map<TypeOfAcquisition, Double> maxdurationSensorMode = configMaps.getMaxDurationSensorMode();

			// Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>
			// minDistanceMap = configMaps.getMinDistanceMap();

			// create an array list of acquisition where will be stored all the
			// performed acquisition relative to the equivalent dto under
			// analysis
			List<Acquisition> allacq = new ArrayList<>();

			logger.info("THEATRE OPERATION : check if max duration for sensor mode is reached");

			TheatreManagement theatreMng = new TheatreManagement();

			// invoke the method to convert a dto in an acq
			allacq = theatreMng.convertElementInsideTheatreInAcq(equivDto);

			isConsistent = theatreMng.checkIfTheatreIsConsistentForMaxDuration(allacq, maxdurationSensorMode);

			if (isConsistent) {
				logger.info("THEATRE OPERATION : check if there are internal overlaps");

				isConsistent = theatreMng.checkIfTheatreIsConsistentForOverlap(allacq);
			}

			// if the equivalent dto is not consistent
			if (!isConsistent) {
				for (int i = 0; i < allacq.size(); i++) {
					rejected.put(allacq.get(i).getIdTask(), allacq.get(i));
					kie.insert(allacq.get(i));
					kie.fireAllRules();
				}
			}
		}
		return isConsistent;
	}

	/**
	 * Reject theatre for M ax number in A day reached.
	 *
	 * @param equivDto the equiv dto
	 * @param kie      the kie
	 * @param rejected the rejected
	 */
	private void rejectTheatreForMAxNumberInADayReached(EquivalentDTO equivDto, KieSession kie,
			Map<String, Acquisition> rejected) {
		// DroolsOperations.logger.debug("THEATRE OPERATION : max number of
		// theatre in a day reached, theatre is rejected");

		// set the reason of reject to maxNumTheatreReached
		ReasonOfReject reason = ReasonOfReject.maxNumTheatreReached;
		// DroolsOperations.logger.debug("THEATRE OPERATION : reject all acq
		// inside the theatre ");

		// iterate over all the dto inside the equivalent dto
		for (int i = 0; i < equivDto.getAllDtoInEquivalentDto().size(); i++) {
			// extract the i-esim dto
			DTO currentElement = equivDto.getAllDtoInEquivalentDto().get(i);

			// create the related acq
			Acquisition relatedAcq = this.du.fromDtoToAcq(currentElement);

			/*
			 * set the reason of reject for this acquisition to the reason defined above
			 */
			relatedAcq.addReasonOfReject(1, reason, "System Conflict", 0, 0, null);
			relatedAcq.setRejected(true);

			// add it to the rejected elements map
			rejected.put(relatedAcq.getIdTask(), relatedAcq);

			/*
			 * insert in Drools. It is marked as rejected, so no rules will be triggered
			 * with the exception of the remove_acq rule
			 */
			kie.insert(relatedAcq);
			kie.fireAllRules();
		}
	}

	/**
	 * Receive acquisition with id.
	 *
	 * @param acqId           the acq id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the acquisition
	 */
	public Acquisition receiveAcceptedAcquisitionWithId(String acqId, String currentSession, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
		QueryResults queryResultsAcq = kie.getQueryResults("acqWithGivenId", acqId);
		Acquisition extractedAcq = null;
		if (queryResultsAcq.size() > 0) {
			for (QueryResultsRow row : queryResultsAcq) {
				extractedAcq = (Acquisition) row.get("$acq");
			}
		}
		return extractedAcq;
	}

	/**
	 * Receive acquisition with id.
	 *
	 * @param logger          the logger
	 * @param arId            the ar id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @return the acquisition
	 */
	public Acquisition receiveAcquisitionWithArId(Logger logger, String arId, String currentSession,
			int currentInstance, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// create the returned element
		Acquisition extractedAcq = null;

		// invoke the drools query to receive all the acquisitions related to
		// the satelliteId in input
		QueryResults queryResultsAcq = kie.getQueryResults("getObjectsOfAcquisition", satId);

		// if at least an element is detect
		if (queryResultsAcq.size() > 0) {
			for (QueryResultsRow row : queryResultsAcq) {
				// extract the i-esim element
				extractedAcq = (Acquisition) row.get("$allAcq");

				// if there is a match between the idTask and the searched ar
				if (extractedAcq.getIdTask().contains(arId)) {
					// exit from cycle
					break;
				}
			}
		}

		return extractedAcq;
	}

	/**
	 * Receive prev and next man.
	 *
	 * @param acq             the acq
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the list
	 */
	public List<Maneuver> receivePrevAndNextMan(Acquisition acq, String currentSession, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
		List<Maneuver> prevAndNextMan = new ArrayList<>();
		ResourceFunctions resFunc = (ResourceFunctions) kie.getGlobal("resourceFunctions");
		TreeMap<Long, Maneuver> allManForSat = resFunc.getManeuverFunctionAssociatedToSat(acq.getSatelliteId());
		if ((allManForSat != null) && !allManForSat.isEmpty()) {
			Object prevManKey = allManForSat.lowerKey(acq.getStartTime().getTime());
			if (prevManKey != null) {
				Maneuver manPrev = allManForSat.get(prevManKey);
				prevAndNextMan.add(manPrev);
			}
			Object nextManKey = allManForSat.higherKey(acq.getStartTime().getTime() - 1);
			if (nextManKey != null) {
				Maneuver manNext = allManForSat.get(nextManKey);
				prevAndNextMan.add(manNext);
			}
		}
		return prevAndNextMan;
	}

	/**
	 * Receive all acquisitions.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @return the list
	 */
	public List<Acquisition> receiveAllAcquisitions(String currentSession, int currentInstance, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		List<Acquisition> allAcq = new ArrayList<>();
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		QueryResults resultsAcq = kieSession.getQueryResults("getObjectsOfAcquisition", satId);
		if (resultsAcq.size() > 0) {
			for (QueryResultsRow row : resultsAcq) {
				Acquisition acq = (Acquisition) row.get("$allAcq");
				allAcq.add(acq);
			}
		}
		return allAcq;
	}

	/**
	 * Receive all download associated to dto.
	 *
	 * @param dtoId           the dto id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return the list
	 */
	public List<Download> receiveAllDownloadAssociatedToDto(String dtoId, String currentSession, int currentInstance,
			DroolsParameters droolsParams) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		Acquisition acqRelated = receiveAcceptedAcquisitionWithId(dtoId, currentSession, currentInstance);

		// create an empty list of downloads
		List<Download> allDwl = new ArrayList<>();

		// get the downloads relative to the currrent satellite
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
				.getDownloadsAssociatedToSat(acqRelated.getSatelliteId());
		List<Download> allDownAssociatedToDto = new ArrayList<>();

		if (acqRelated != null) {
			// add all downloads to the list , filtered by satellite
			allDwl.addAll(this.dwlMng.getAllDwlFromTreeMap(acqRelated.getSatelliteId(), droolsParams, dwlTreeMap));

			for (int i = 0; i < allDwl.size(); i++) {
				if (allDwl.get(i).getRelatedTask() != null && allDwl.get(i).getRelatedTask().equalsIgnoreCase(dtoId)) {
					allDownAssociatedToDto.add(allDwl.get(i));
				}
			}
		}

		// DroolsOperations.logger.debug("all DWL associated to dto : " +
		// allDownAssociatedToDto);
		return allDownAssociatedToDto;
	}

	/**
	 * Receive all download associated to dto.
	 *
	 * @param dtoId           the dto id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return the list
	 */
	public List<Download> receiveAllDownloadAssociatedToDtoForMh(String dtoId, String currentSession,
			int currentInstance, DroolsParameters droolsParams) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		Acquisition acqRelated = receiveAcceptedAcquisitionWithId(dtoId, currentSession, currentInstance);

		// create an empty list of downloads
		List<Download> allDwl = new ArrayList<>();

		// get the downloads relative to the currrent satellite
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
				.getDownloadsAssociatedToSat(acqRelated.getSatelliteId());
		List<Download> allDownAssociatedToDto = new ArrayList<>();

		if (acqRelated != null) {
			// add all downloads to the list , filtered by satellite
			allDwl.addAll(this.dwlMng.getAllDwlFromTreeMap(acqRelated.getSatelliteId(), droolsParams, dwlTreeMap));

			for (int i = 0; i < allDwl.size(); i++) {
				if (allDwl.get(i).getRelatedTask() != null && allDwl.get(i).getRelatedTask().equalsIgnoreCase(dtoId)
						&& allDwl.get(i).getStartTime().getTime() <= droolsParams.getCurrentMH().getStop().getTime()
						&& allDwl.get(i).getEndTime().getTime() >= droolsParams.getCurrentMH().getStart().getTime()) {
					allDownAssociatedToDto.add(allDwl.get(i));
				}
			}
		}

		// DroolsOperations.logger.debug("all DWL associated to dto : " +
		// allDownAssociatedToDto);
		return allDownAssociatedToDto;
	}

	/**
	 * Receive all partners.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the list
	 */
	public List<Partner> receiveAllPartners(String currentSession, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		List<Partner> allPartner = new ArrayList<>();
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		QueryResults resultsPartner = kieSession.getQueryResults("getObjectsOfPartner");
		for (QueryResultsRow row : resultsPartner) {
			Partner p = (Partner) row.get("p");
			allPartner.add(p);
		}
		return allPartner;
	}

	/**
	 * Receive all partners as map.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the map
	 */
	public Map<String, Partner> receiveAllPartnersAsMap(String currentSession, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		Map<String, Partner> allPartner = new HashMap<>();
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		QueryResults resultsPartner = kieSession.getQueryResults("getObjectsOfPartner");
		for (QueryResultsRow row : resultsPartner) {
			Partner p = (Partner) row.get("p");
			allPartner.put(p.getPartnerId(), p);
		}
		return allPartner;
	}

	/**
	 * Receive all silent.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @return the list
	 */
	public Map<String, Silent> receiveAllSilentAsMap(String currentSession, int currentInstance, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		Map<String, Silent> allSilents = new HashMap<>();
		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		QueryResults resultsDown = kieSession.getQueryResults("getObjectsOfSilent", satId);
		for (QueryResultsRow row : resultsDown) {
			Silent sil = (Silent) row.get("$allSil");
			allSilents.put(sil.getIdTask(), sil);
		}
		return allSilents;
	}

	/**
	 * Receive all storages.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @return the list
	 */
	public TreeMap<String, Storage> receiveAllStorages(String currentSession, int currentInstance, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

		TreeMap<String, Storage> allStorages = resFunc.getStoragesAssociatedToSat(satId);
		// DroolsOperations.logger.debug("all sto : " + allStorages);
		return allStorages;
	}

	/**
	 * Receive dto accepted.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @param satId           the sat id
	 * @return the list
	 */
	public List<Task> receiveDtoAccepted(String currentSession, int currentInstance, DroolsParameters droolsParams,
			String satId) {

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// initialize the dwlMng
		DownloadManagement dwlMng = new DownloadManagement();

		// check if the session is valid
		boolean existSession = checkSession(currentSession, currentInstance);

		// create an empty list of tasks
		List<Task> facts = null;

		// if the session is valid
		if (existSession) {
			// initialize the tasks list
			facts = new ArrayList<>();

			// get the current kie session
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

			// get the ResourceFunctions structure
			ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");

			// get all the dwl for the satellite given as input
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreemap = resFunc
					.getDwlFunctionAssociatedToSat(satId);

			// get all the storage for the satellite given as input
			TreeMap<String, Storage> resultsSto = resFunc.getStoragesAssociatedToSat(satId);

			// get all the acq for the satellite given as input
			QueryResults resultsAcq = kieSession.getQueryResults("getObjectsOfAcquisition", satId);

			// get all the man for the satellite given as input
			QueryResults resultsMan = kieSession.getQueryResults("getObjectsOfManeuver", satId);

			// List<Download> allDwl = dwlMng.getAllDwlFromTreeMap(satId,
			// droolsParams, dwlTreemap);

			// get all the dwl for the satellite given as input
			TreeMap<String, Download> allDwl = dwlMng.getAllFromTreeMap(satId, droolsParams, dwlTreemap,
					DownloadLogic.DWL);

			// get all the gps for the satellite given as input
			TreeMap<String, Download> allGps = dwlMng.getAllFromTreeMap(satId, droolsParams, dwlTreemap,
					DownloadLogic.GPS);

			// get all the sil for the satellite given as input
			QueryResults resultsSil = kieSession.getQueryResults("getObjectsOfSilent", satId);

			// get all the ramps for the satellite given as input
			QueryResults resultsRamp = kieSession.getQueryResults("getObjectsOfRamps", satId);

			// get all the pt for the satellite given as input
			QueryResults resultsPt = kieSession.getQueryResults("getObjectsOfPt", satId);

			// get all the bite for the satellite given as input
			QueryResults resultsBite = kieSession.getQueryResults("getObjectsOfBites", satId);

			// get all the cmgAxis for the satellite given as input
			TreeMap<Long, CMGAxis> resultsAxis = resFunc.getCmgaAxisAssociatedToSat(satId);// kieSession.getQueryResults("getAllCmgAxis",
																							// satId);

			logger.debug("QUERY RESULTS ACQUISITION " + resultsAcq.size());
			logger.debug("QUERY RESULTS STORAGE " + resultsSto.size());
			logger.debug("QUERY RESULTS MANEUVER " + resultsMan.size());
			logger.debug("QUERY RESULTS DOWNLOAD " + allDwl.size());
			logger.debug("QUERY RESULTS GPS " + allGps.size());
			logger.debug("QUERY RESULTS SILENT " + resultsSil.size());
			logger.debug("QUERY RESULTS RAMP " + resultsRamp.size());
			logger.debug("QUERY RESULTS PT " + resultsPt.size());
			logger.debug("QUERY RESULTS BITE " + resultsBite.size());
			logger.debug("QUERY RESULTS CMGAXis " + resultsAxis.size());

			for (QueryResultsRow row : resultsAcq) {
				Acquisition acq = (Acquisition) row.get("$allAcq");
				// logger.debug("Acquisition found:" + acq);
				this.du.addElement(facts, acq, droolsParams);
			}

			for (Map.Entry<String, Storage> elementsSto : resultsSto.entrySet()) {
				// logger.debug("Storage found : " + elementsSto.getValue());
				this.du.addElement(facts, elementsSto.getValue(), droolsParams);
			}

			for (QueryResultsRow row : resultsMan) {
				Maneuver man = (Maneuver) row.get("$allMan");
				// logger.debug("maneuver found :" + man);
				this.du.addElement(facts, man, droolsParams);
			}

			for (Map.Entry<String, Download> elementsDwl : allDwl.entrySet()) {
				// logger.debug("download found : " + elementsDwl.getValue());
				this.du.addElement(facts, elementsDwl.getValue(), droolsParams);
			}

			for (Map.Entry<String, Download> elementsGps : allGps.entrySet()) {
				// logger.debug("download GPS found : " + elementsGps.getValue());
				this.du.addElement(facts, elementsGps.getValue(), droolsParams);
			}

			for (QueryResultsRow row : resultsSil) {
				Silent sil = (Silent) row.get("$allSil");
				// logger.debug("silent found : " + sil);
				this.du.addElement(facts, sil, droolsParams);
			}

			HashMap<Long, RampCMGA> allRampsAsMap = new HashMap<>();
			for (QueryResultsRow row : resultsRamp) {
				RampCMGA ramp = (RampCMGA) row.get("$allRamps");
				allRampsAsMap.put(ramp.getStartTime().getTime(), ramp);
			}
			for (Map.Entry<Long, RampCMGA> allRamps : allRampsAsMap.entrySet()) {
				// logger.debug("ramp found : " + allRamps.getValue());
				this.du.addElement(facts, allRamps.getValue(), droolsParams);
			}

			for (QueryResultsRow row : resultsPt) {
				PassThrough pt = (PassThrough) row.get("$allPt");
				// logger.debug("pt found : " + pt);
				this.du.addElement(facts, pt, droolsParams);

			}

			for (QueryResultsRow row : resultsBite) {
				Bite bite = (Bite) row.get("$allBites");
				// logger.debug("bite found:" + bite);
				this.du.addElement(facts, bite, droolsParams);
			}

			// if there are cmgAxis
			if (!resultsAxis.isEmpty()) {
				// iterate over them
				for (Map.Entry<Long, CMGAxis> elemensOfAxis : resultsAxis.entrySet()) {
					// extract the i-esim cmgAxis
					CMGAxis axis = elemensOfAxis.getValue();
					// logger.debug("axis found:" + axis);

					// add element to the list, if is not present
					this.du.addElement(facts, axis, droolsParams);
				}
			}
		}
		return facts;
	}

	/**
	 * Receive partner with id.
	 *
	 * @param partnerId       the partner id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the partner
	 */
	public Partner receivePartnerWithId(String partnerId, String currentSession, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		Partner extractedPartner = null;
		boolean existSession = checkSession(currentSession, currentInstance);
		if (existSession) {
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
			QueryResults resultsPartner = kieSession.getQueryResults("partner with given id", partnerId);
			if (resultsPartner.size() > 0) {
				for (QueryResultsRow row : resultsPartner) {
					extractedPartner = (Partner) row.get("$partner");
				}
			}
		}
		return extractedPartner;
	}

	/**
	 * Receive PDHT function.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param satId           the sat id
	 * @return the tree map
	 */
	public TreeMap<Long, ComplexPdht> receivePDHTFunction(String currentSession, int currentInstance, String satId) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resources = (ResourceFunctions) kie.getGlobal("resourceFunctions");
		TreeMap<Long, ComplexPdht> pdhtFunction = resources.getPDHTFunctionAssociatedToSat(satId);
		return pdhtFunction;
	}

	/**
	 * Retract single acq.
	 *
	 * @param droolsParams    the drools params
	 * @param acqIdToRetract  the acq id to retract
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param reason          the reason
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public static boolean retractSingleAcq(DroolsParameters droolsParams, String acqIdToRetract, String currentSession,
			int currentInstance, ReasonOfReject reason) {
		Logger logger = DroolsParameters.getLogger();
		boolean retracted = true;
		logger.debug("retractSingleAcq method : retracting ACQ from working memory the acquisition with id : "
				+ acqIdToRetract);
		logger.debug("retractSingleAcq method : for reason " + reason);

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// check if the session has been initialized
		boolean existSession = checkSession(currentSession, currentInstance);

		// if exists
		if (existSession) {
			// get the current kie session
			KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

			// invoke the query to extract an acquisition from an id
			QueryResults acqWithId = kie.getQueryResults("acqWithGivenId", acqIdToRetract);

			// initialize an acquisition
			Acquisition acq = null;
			if (acqWithId.size() > 0) {
				logger.debug("founded an acquisition correlated with this id");

				// get the rejected elements
				Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) kie.getGlobal("rejected");
				Map<String, Acquisition> allAccepted = (Map<String, Acquisition>) kie.getGlobal("allAccepted");
				// iterate over the results
				for (QueryResultsRow rowAcq : acqWithId) {
					// cast the result to an acquisition
					acq = (Acquisition) rowAcq.get("$acq");
					allAccepted.remove(acq.getIdTask());

					// if the acquisition has no elements involved
					if (acq.getReasonOfReject().isEmpty()) {
						// if there is a reason given as input
						if (reason != null) {
							// add the reason of reject to the acquisition
							acq.addReasonOfReject(1, reason, "System Conflict", 0, 0, null);
						}
						// if there isn't a reason
						else {
							// use the default reason : deletedByCsps
							acq.addReasonOfReject(100, ReasonOfReject.deletedByCsps, "System Conflict", 0, 0, null);
						}
					}

					// get the factHandle relative to the acq
					FactHandle factHandle = kie.getFactHandle(acq);

					// add the acquisition to the rejected elements
					rejectedElements.put(acq.getId(), acq);

					// mark the acquisition has rejected
					acq.setRejected(true);

					// update the acq
					kie.update(factHandle, acq);

					// fire all the Drools rules
					kie.fireAllRules();
					factHandle = kie.getFactHandle(acq);
					if (factHandle != null) {
						kie.delete(factHandle);
					}
				}
			} else {
				logger.debug("there isn't an acq with this id in the working memory!!!");
				retracted = false;

			}

			// invoke the query to extract an acquisition from an id
			acqWithId = kie.getQueryResults("acqWithGivenId", acqIdToRetract);

			if (acqWithId.size() > 0) {
				logger.debug("there isn't an acq with this id in the working memory!!!");
				retracted = false;

			}
		}
		return retracted;
	}

	/**
	 * Sets the drools env.
	 *
	 * @param droolsEnv the new drools env
	 */
	public void setDroolsEnv(DroolsEnvironment droolsEnv) {
		this.droolsEnv = droolsEnv;
	}

	/**
	 * This method give to the CSPS the possibility to set all the resources taken
	 * from the database to be used and updated inside the BRM.
	 *
	 * @param droolsParams       the drools params
	 * @param allSats            the all sats
	 * @param allPDHT            the all PDHT
	 * @param allVisibilities    the all visibilities
	 * @param allPaws            the all paws
	 * @param satelliteStates    the satellite states
	 * @param allCMGA            the all CMGA
	 * @param allEclipses        the all eclipses
	 * @param allPartners        the all partners
	 * @param MH                 the mh
	 * @param maxHpBicFixedOrbit the max hp bic fixed orbit
	 * @param hpExclusionList    the hp exclusion list
	 * @param prTypeMaxNumber    the pr type max number
	 * @param extraCostLeft      the extra cost left
	 */
	public void setParameters(DroolsParameters droolsParams, List<Satellite> allSats, List<PDHT> allPDHT,
			List<Visibility> allVisibilities, List<PAW> allPaws, List<SatelliteState> satelliteStates,
			List<CMGA> allCMGA, List<Eclipse> allEclipses, List<Partner> allPartners, MissionHorizon MH,
			Map<String, Map<Integer, Double>> maxHpBicFixedOrbit, List<HPExclusion> hpExclusionList,
			int prTypeMaxNumber, double extraCostLeft) {
		// DroolsOperations.logger.debug("BRM is settings all the resources ");

		// set all the satellites
		droolsParams.setAllSat(allSats);

		// set all the pdht
		droolsParams.setAllPDHT(allPDHT);

		// set all the paw
		droolsParams.setAllPAWS(allPaws);

		List<Visibility> onlyValid = this.du.avoidCloneVis(allVisibilities);

		// set all the visibilities
		droolsParams.setAllVisibilities(onlyValid);

		// set all the satellite states
		droolsParams.setSatelliteState(satelliteStates);

		// set all the cmga
		droolsParams.setAllCMGA(allCMGA);

		// set all the eclipses
		droolsParams.setAllEclipses(allEclipses);

		// set all the partners
		droolsParams.setAllPartners(allPartners);

		// set the mission horizon
		droolsParams.setCurrentMH(MH);

		// set the list of hpSegment
		droolsParams.setHpExclusionList(hpExclusionList);

		// set the map of max number of hp for fixed orbit
		droolsParams.setMaxHpBicFixedOrbit(maxHpBicFixedOrbit);

		// set the max number of pr type
		droolsParams.setPrTypeMaxNumber(prTypeMaxNumber);

		// set the extra cost left
		droolsParams.setExtraCostLeft(extraCostLeft);
	}

	/**
	 * Receive dto rejected.
	 *
	 * @param session         the session
	 * @param currentInstance the current instance
	 * @return the map where the key is the id of the rejected acquisition and the
	 *         value is the reason of reject
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Acquisition> receiveDtoRejected(String session, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(session, currentInstance);
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
		Map<String, Acquisition> allRejectedElements = (Map<String, Acquisition>) kie.getGlobal("rejected");
		return allRejectedElements;
	}

	/**
	 * Receive dto rejected for satellite.
	 *
	 * @param satelliteId     the satellite id
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the list
	 */
	@SuppressWarnings("unchecked")
	public List<Task> receiveDtoRejectedForSatellite(String satelliteId, String currentSession, int currentInstance) {
		// concatenate the current session
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// create an empty list of tasks
		List<Task> onlyRejectedForSat = new ArrayList<>();

		// receive the global variable rejected
		Map<String, Task> allRejectedElements = (Map<String, Task>) kie.getGlobal("rejected");

		// iterate over the rejected elements
		for (Map.Entry<String, Task> allRjeectedEl : allRejectedElements.entrySet()) {

			String satIdToMatch = allRjeectedEl.getValue().getSatelliteId();
			if (satIdToMatch.toString().toUpperCase().contains(satelliteId.toUpperCase())) {
				onlyRejectedForSat.add(allRjeectedEl.getValue());
			}
		}
		return onlyRejectedForSat;
	}

	/**
	 * Restore extra cost left acq and theatre.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return true, if successful
	 */
	public boolean restoreExtraCostLeftAcq(String currentSession, int currentInstance, DroolsParameters droolsParams) {
		// get the bic management
		BicManagement bicMng = new BicManagement();

		// concatenate the current session
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// set as default that the function is used for restore only extra cost
		boolean restoreOnlyExtraCost = true;
		boolean performed = false;

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get the resource function
		ResourceFunctions resFunc = (ResourceFunctions) kie.getGlobal("resourceFunctions");

		// iterate over all the satellites
		for (int i = 0; i < droolsParams.getAllSat().size(); i++) {
			// get the list of acquisitions
			TreeMap<Long, EnergyAssociatedToTask> acqSat = resFunc
					.getEssFunctionAssociatedToSat(droolsParams.getAllSat().get(i).getSatelliteId());
			// DroolsOperations.logger.debug("RESTORING EXTRA COST FOR SATELLITE
			// : " + droolsParams.getAllSat().get(i).getSatelliteId());

			// if the list isn't empty
			if (!acqSat.isEmpty()) {
				// iterate over all the aacquisitions
				for (Map.Entry<Long, EnergyAssociatedToTask> allAcq : acqSat.entrySet()) {
					// extract the i-esim acq
					Acquisition currentAcq = (Acquisition) allAcq.getValue().getTask();

					// if the acq is a left one
					if (currentAcq.getLookSide().equalsIgnoreCase("left")) {
						// DroolsOperations.logger.debug("current left acq : " +
						// currentAcq);

						// initialize an equivalent dto
						EquivalentDTO referredEquivDto = null;

						// if the acq is linked with a valid equivalent dto
						if (currentAcq.getReferredEquivalentDto() != null) {
							// extract the relative equivalent dto
							QueryResults relatedEquivDtoResults = kie.getQueryResults("getEquivDtoWithId",
									currentAcq.getReferredEquivalentDto());

							// if there is a valid match
							if (relatedEquivDtoResults.size() > 0) {
								// iterate over the results
								for (QueryResultsRow rowEquivDto : relatedEquivDtoResults) {
									// extract the equivalent dto
									referredEquivDto = (EquivalentDTO) rowEquivDto.get("$equivDto");
								}
							}
						}
						// invoke the function to restore the bic
						try {
							bicMng.restoreBicAndLoanToPartner(currentAcq, droolsParams, restoreOnlyExtraCost,
									referredEquivDto, false, 0);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		return performed;
	}

	/**
	 * Restore extra cost left acq and theatre.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 * @return true, if successful
	 */
	public void restoreExtraCostTheatre(String currentSession, int currentInstance, DroolsParameters droolsParams) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);
		// create an instance of BicManagement
		BicManagement bicMng = new BicManagement();

		// get the current active kieSession
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// extract the mission horizon
		MissionHorizon mh = droolsParams.getCurrentMH();

		// iterate over all the satellites
		for (int i = 0; i < droolsParams.getAllSat().size(); i++) {
			// extract the satellite id of the current satellite
			String satId = droolsParams.getAllSat().get(i).getSatelliteId();

			logger.debug(
					"RESTORE_EXTRA_COST_THEATRE : FOR SATELLITE : " + droolsParams.getAllSat().get(i).getSatelliteId());

			// get all the theatre that are in overlap with the current mission
			// horizon for the current satellite
			QueryResults relatedEquivDtoResults = kie.getQueryResults("theatreOverlapInterval", mh.getStart(),
					mh.getStop(), satId);

			// if there is at least an element in overlap
			if (relatedEquivDtoResults.size() > 0) {
				for (QueryResultsRow rowEquivDto : relatedEquivDtoResults) {
					// get the referred equivalent dto
					EquivalentDTO referredEquivDto = (EquivalentDTO) rowEquivDto.get("$equivDto");

					// extract the extra cost for theatre acquisitions
					double extraCostTheatre = referredEquivDto.getExtraCostPitch();

					logger.debug("RESTORE_EXTRA_COST_THEATRE : found a threatre : " + referredEquivDto);

					// don't restore if the mission horizon is the previous
					if (referredEquivDto.getStartTime().getTime() < mh.getStart().getTime()) {
						logger.debug(
								"RESTORE_EXTRA_COST_THEATRE : theatre is excluded from computation because starts outside current mission horizon");
					} else {
						logger.debug("RESTORE_EXTRA_COST_THEATRE : start restore bic for the current theatre ");

						// get all the acquisitions
						// involved in theatre
						List<Acquisition> allAcqInvolvedInTheatre = new ArrayList<>();

						// get all the id of acquisitions involved in theatre
						List<String> allAcqIdInvolvedInTheatre = new ArrayList<>();

						// receive the acquisition related to the inserted dto
						QueryResults dtoWithId = kie.getQueryResults("acqInvolvedInTheatre",
								referredEquivDto.getEquivalentDtoId());

						// iterate over the results
						for (QueryResultsRow row : dtoWithId) {
							// extract the acquisition
							Acquisition acq = (Acquisition) row.get("$acq");

							// add the acquisition to the list of acquisitions
							// involved in
							// theatre
							allAcqInvolvedInTheatre.add(acq);
							allAcqIdInvolvedInTheatre.add(acq.getIdTask());
						}

						logger.debug("RESTORE_BIC THEATRE : list of acquisitions involved in theatre : "
								+ allAcqIdInvolvedInTheatre);

						// restore extra cost theatre
						try {
							bicMng.restoreBicAndLoanForTheatre(referredEquivDto.getEquivalentDtoId(),
									allAcqInvolvedInTheatre, extraCostTheatre, droolsParams);
						} catch (Exception e) {

							e.printStackTrace();
						}
					}
				}
			}
		}
	}

	/**
	 * Receive deleted tasks.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return the list
	 */
	@SuppressWarnings("unchecked")
	public List<Task> receiveDeletedTasks(String currentSession, int currentInstance) {
		// create an empty list of tasks
		List<Task> deletedTasks = new ArrayList<>();

		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);
		deletedTasks = (List<Task>) kie.getGlobal("deletedTasks");
		return deletedTasks;
	}

	/**
	 * Decrement bic di 2 s.
	 *
	 * @param dto           the dto
	 * @param partnerIdList the partner id list
	 * @param isSlave       the is slave
	 * @param droolsParams  the drools params
	 * @return true, if successful
	 */
	public boolean checkIfDi2sIsFeasible(DTO dto, List<String> partnerIdList, boolean isSlave,
			DroolsParameters droolsParams) {
		// variable used to check if the partner under anaysis has enough bic or
		// not

		boolean possible = false;
		double bicForPartner = 0;
		Partner partner = null;

		Logger logger = DroolsParameters.getLogger();

		double totalBicAcq = dto.getImageBIC();
		// declare a new BicUtils
		BicUtils bicUtils = new BicUtils();

		// declare a new BicManagement
		BicManagement bicMng = new BicManagement();

		for (int i = 0; i < partnerIdList.size(); i++) {
			// receive the partner associated with
			// the partnerId given as input
			partner = bicUtils.findPartnerInList(partnerIdList.get(i), droolsParams.getAllPartners());

			if (isSlave) {
				// if we are checking the slave, get the second partnerId
				// from
				// dto and receive the related partner

				// if the acquisition is a SPOTLIGHT_2_MSOS
				if (dto.getSensorMode().equals(TypeOfAcquisition.SPOTLIGHT_2_MSOS)) {
					bicForPartner = ((totalBicAcq / 100) * droolsParams.getPercentBicDi2sSlaveMSOS())
							/ partnerIdList.size();
					logger.debug("percent bic reserved to Slave MSOS:" + droolsParams.getPercentBicDi2sSlaveMSOS());
				}
				// if the acquisition is a SPOTLIGHT_2_MSOR
				else {
					bicForPartner = ((totalBicAcq / 100) * droolsParams.getPercentBicDi2sSlaveMSOR())
							/ partnerIdList.size();

					logger.debug("percent bic reserved to Slave MSOR:" + droolsParams.getPercentBicDi2sSlaveMSOR());
				}
				logger.debug("total bic :" + totalBicAcq);
				logger.debug("bic splitted between slaves :" + bicForPartner);
				// computed bic for slave
				// DroolsOperations.logger.debug("computed bic for slave :"
				// + bicForPartner);
			} else {
				// if we are checking the master, get the first partnerId
				// from
				// dto and receive the related partner

				// if the acquisition is a SPOTLIGHT_2_MSOS
				if (dto.getSensorMode().equals(TypeOfAcquisition.SPOTLIGHT_2_MSOS)) {
					bicForPartner = ((totalBicAcq / 100) * droolsParams.getPercentBicDi2sMasterMSOS())
							/ partnerIdList.size();
					// DroolsOperations.logger.debug("percent bic reserved
					// to Master :" +
					// droolsParams.getPercentBicDi2sMasterMSOS());
				}

				// if the acquisition is a SPOTLIGHT_2_MSOR
				else {
					bicForPartner = ((totalBicAcq / 100) * droolsParams.getPercentBicDi2sMasterMSOR())
							/ partnerIdList.size();
					// DroolsOperations.logger.debug("percent bic reserved
					// to Master :" +
					// droolsParams.getPercentBicDi2sMasterMSOR());
				}
			}

			// check if the partner has the requested amount of nic to
			// process
			// the acquisition
			possible = bicMng.checkBicAndNeoBicForAcqDi2s(droolsParams, dto, partner, bicForPartner);

			if (!possible) {
				break;
			}
		}
		return possible;
	}

	/**
	 * Insert DI 2 S.
	 *
	 * @param droolsParams    the drools params
	 * @param equivalentDto   the equivalent dto
	 * @param totalBic        the total bic
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	public boolean insert_DI2S(DroolsParameters droolsParams, EquivalentDTO equivalentDto, double totalBic,
			String currentSession, int currentInstance) {

		Di2sManagement di2sMng = new Di2sManagement();
		// this variable is used to understand if the new inserted elements are
		// valid or not
		boolean performed = false;

		performed = di2sMng.insertDi2s(droolsParams, equivalentDto, totalBic, currentSession, currentInstance);

		return performed;
	}

	/**
	 * Insert Experimental.
	 *
	 * @param droolsParams    the drools params
	 * @param equivalentDto   the equivalent dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public boolean insert_Experimental(DroolsParameters droolsParams, EquivalentDTO equivalentDto,
			String currentSession, int currentInstance) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		/*
		 * get the current kieSession of Drools
		 */
		KieSession currentKieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// this variable is used to understand if the new inserted elements are
		// valid or not
		boolean performed = true;

		/*
		 * get the logger
		 */
		Logger logger = DroolsParameters.getLogger();

		/*
		 * if the equivalentDTo is an experimental
		 */
		if (equivalentDto.getEquivType().equals(PRMode.Exp)) {
			/*
			 * receive the kieSession from Drools
			 */
			KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);

			/**
			 * gt the list of rejected acq
			 */
			Map<String, Acquisition> rejected = (Map<String, Acquisition>) kieSession.getGlobal("rejected");
			Map<FactHandle, Task> allElementsOfTheatre = new HashMap<>();
			logger.debug("INSERTING ALL DTOs of Experimental type");

			/*
			 * iterate over all dtos in equivalent dto
			 */
			for (int i = equivalentDto.getAllDtoInEquivalentDto().size() - 1; i >= 0; i--) {
				int dtoKey = getContDto();
				// set the orrect key for the dto
				equivalentDto.getAllDtoInEquivalentDto().get(i).setKey(dtoKey);

				// link the dto with the referred equiv dto
				equivalentDto.getAllDtoInEquivalentDto().get(i)
						.setReferredEquivalentDto(equivalentDto.getEquivalentDtoId());

				// increment the key
				dtoKey++;
				setContDto(dtoKey);
				boolean inserted = false;

				try {
					/*
					 * try to insert the experimental inside the drools engine
					 */
					inserted = insertDto(droolsParams, equivalentDto.getAllDtoInEquivalentDto().get(i), currentSession,
							currentInstance);
				} catch (Exception e) {
					e.printStackTrace();
				}

				// if it isn't inserted
				if (!inserted) {
					logger.debug("an element inside experimental is rejected ");
					performed = false;
				} else {
					logger.debug("experimental is valid ");
				}
			}

			// if the experimental is valid and there are maneuvers associated
			if (performed && (equivalentDto.getManAssociated() != null)
					&& !equivalentDto.getManAssociated().isEmpty()) {
				logger.debug("inserting all maneuvers ");

				// iterate over the maneuvers
				for (int i = 0; i < equivalentDto.getManAssociated().size(); i++) {
					logger.debug(
							"EXPERIMENTAL OPERATION : inserting maneuver : " + equivalentDto.getManAssociated().get(i));
					// set th equivlent dto id
					equivalentDto.getManAssociated().get(i)
							.setReferredEquivalentDto(equivalentDto.getEquivalentDtoId());
					// set the type of maneuver to PitchSlew
					equivalentDto.getManAssociated().get(i).setType(ManeuverType.PitchSlew);
					// set the satelliteId
					equivalentDto.getManAssociated().get(i)
							.setSatelliteId(equivalentDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

					// if the maneuver is
					if (equivalentDto.getAllDtoInEquivalentDto().get(0).getLookSide().equalsIgnoreCase("left")) {

						// set a dummy look side, it is a slew, not a roll maneuver
						equivalentDto.getManAssociated().get(i).setRightToLeftFlag(true);
					} else {
						// set a dummy look side, it is a slew, not a roll maneuver
						equivalentDto.getManAssociated().get(i).setRightToLeftFlag(false);
					}
					// set the first id with the first dto id involved in expermental
					equivalentDto.getManAssociated().get(i)
							.setAcq1Id(equivalentDto.getAllDtoInEquivalentDto().get(0).getDtoId());

					// insert the man inside drools
					FactHandle man = currentKieSession.insert(equivalentDto.getManAssociated().get(i));

					// nsert the man inside the structure
					allElementsOfTheatre.put(man, equivalentDto.getManAssociated().get(i));

					// execute all rules
					kieSession.fireAllRules();

					// get the rejected elements
					rejected = (Map<String, Acquisition>) kieSession.getGlobal("rejected");

					// if there are rejected elements
					if ((rejected != null) && !rejected.isEmpty()) {
						// iterate over the elements related to the experimental
						for (int j = 0; j < equivalentDto.getAllDtoInEquivalentDto().size(); j++) {

							// if at least one of them is in the rejected list
							if (rejected
									.containsKey(equivalentDto.getAllDtoInEquivalentDto().get(j).getDtoId()) == true) {

								// set performed to false
								performed = false;

								// exit from cycle
								break;
							}
						}
					}
				}

			}
			// if is not performed
			if (!performed) {

				// get all accepted dto related to the experimental
				// invoking drools query
				QueryResults otherAcqInEquivDto = kieSession.getQueryResults("getAllAcqRelatedToEquivalentDto",
						equivalentDto.getEquivalentDtoId());

				// if there are others acq
				if (otherAcqInEquivDto.size() > 0) {
					// iterate over them
					for (QueryResultsRow rowAcq : otherAcqInEquivDto) {
						// extract the i-esim acq
						Acquisition otherAcq = (Acquisition) rowAcq.get("$allDtoInEquivDto");
						// mark as rejected
						otherAcq.setRejected(true);

						// add the correct reason of reject
						otherAcq.addReasonOfReject(1, ReasonOfReject.cannotPerformExperimental, "System Conflict", 0, 0,
								null);

						logger.debug("retracting acq because cannot perform experimental");
						// retract the acq
						retractSingleAcq(droolsParams, otherAcq.getIdTask(), currentSession, currentInstance,
								ReasonOfReject.cannotPerformExperimental);
					}
				}
			} else {
				logger.debug("experimental is valid");
			}
		} else {
			logger.debug("invalid experimental : not exp prMode");
			performed = false;
		}

		return performed;
	}

	/**
	 * Insert theatre.
	 *
	 * @param droolsParams    the drools params
	 * @param equivalentDto   the equivalent dto
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @return true, if successful
	 */
	@SuppressWarnings("unchecked")
	public boolean insert_Theatre(DroolsParameters droolsParams, EquivalentDTO equivalentDto, String currentSession,
			int currentInstance) {
		// this variable is used to understand if the new inserted elements are
		// valid or not

		boolean performed = true;
		boolean thereIsMan = true;
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// if the equivalent dto is of type theatre
		if (equivalentDto.getEquivType().equals(PRMode.Theatre)) {
			logger.info("THEATRE OPERATION : Processing a theatre operation.");

			try {
				// receive the kieSession from Drools
				KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
				Map<String, Acquisition> rejected = (Map<String, Acquisition>) kieSession.getGlobal("rejected");

				List<String> allProcessedDto = (List<String>) kieSession.getGlobal("report");
				// iterate over the extracted id
				for (int i = 0; i < equivalentDto.getAllDtoInEquivalentDto().size(); i++) {
					DTO dto = equivalentDto.getAllDtoInEquivalentDto().get(i);

					if (equivalentDto.isPreviousSession()) {
						dto.setPreviousSession(true);
					}

					String acqForReport = dto.getDtoId() + ", startTime :" + dto.getStartTime() + ", endTime :"
							+ dto.getEndTime() + ", lookSide :" + dto.getLookSide() + ", sensorMode :"
							+ dto.getSensorMode() + " , prType : " + dto.getPrType() + "+isTimePerformance :"
							+ dto.isTimePerformance() + " , sat :" + dto.getSatelliteId() + " added";

					allProcessedDto.add(acqForReport);
				}

				boolean overlappedExternal = false;
				equivalentDto.setStartAndStop();
				equivalentDto.setSatelliteId(equivalentDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

				// check if theatre is iternally valid
				performed = checkIfTheatreIsValid(equivalentDto, currentSession, currentInstance, droolsParams);

				logger.info("THEATRE VALID FOR PRECHECK: " + performed);

				if ((equivalentDto.getManAssociated() == null) || (equivalentDto.getManAssociated().size() == 0)) {
					thereIsMan = false;
				}
				// if the precheck is ok
				if (performed && thereIsMan) {

					List<Acquisition> acceptedAcqList = new ArrayList<>();

					// insert the equivalent dto inside drools
					FactHandle factHandleEquivalent = SessionHandler.getKieSessionsMap().get(sessionInstance)
							.insert(equivalentDto);

					// fire all the rules to let Drools manages the
					// equivalentDto
					SessionHandler.getKieSessionsMap().get(sessionInstance).fireAllRules();

					// check if the equivalentDto is returned back from drools
					// (so it wasn't rejected)
					EquivalentDTO returnedEquivDto = this.queries.getEquivDtoWithId(currentSession, currentInstance,
							droolsParams, equivalentDto.getEquivalentDtoId());

					// if null, it means that the equivalent dto was rejected
					if (returnedEquivDto == null) {
						logger.debug("THEATRE OPERATION : the theatre was in overlap with acq -> rejected");

						// mark the boolean variable to false -> theatre cannot
						// be accepted
						performed = false;

						// extract the id of all the acquisitions in overlap
						// with theatre
						List<String> allAcqIdInOverlapWithTheatre = this.queries.getAllAcquisitionInInterval(
								currentSession, currentInstance, droolsParams, equivalentDto.getStartTime(),
								equivalentDto.getEndTime(),
								equivalentDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

						// create an empty list of acquisition
						List<Acquisition> allAcqInOverlapWithTheatre = new ArrayList<>();

						DroolsQueries dq = new DroolsQueries();
						// iterate over the extracted id
						for (int i = 0; i < allAcqIdInOverlapWithTheatre.size(); i++) {
							// get the Acquisition relative to the current id
							Acquisition acq = dq.getAcqWithId(currentSession, currentInstance,
									allAcqIdInOverlapWithTheatre.get(i));

							// add the acquisition to the list of acquisitions
							// created above
							allAcqInOverlapWithTheatre.add(acq);
						}

						// iterate over the dto inside the equivalent dto
						for (int i = 0; i < equivalentDto.getAllDtoInEquivalentDto().size(); i++) {
							// initialize the variable to detect if there is
							// overlap between the current dto and external
							// elements to false
							overlappedExternal = false;

							// extract the i-esim dto
							DTO currentDto = equivalentDto.getAllDtoInEquivalentDto().get(i);

							// convert it to an acquisition
							Acquisition relatedAcq = this.du.fromDtoToAcq(currentDto);

							// iterate over all the acquisitions in overlap with
							// the equivalent dto
							for (int j = 0; j < allAcqInOverlapWithTheatre.size(); j++) {
								// extract the j-esim acquisition in overlap
								Acquisition currentAcq = allAcqInOverlapWithTheatre.get(j);

								// if the acquisition is in overlap with the
								// current dto
								if ((currentDto.getStartTime().getTime() <= currentAcq.getEndTime().getTime())
										&& (currentDto.getEndTime().getTime() >= currentAcq.getStartTime().getTime())) {
									// add as reason of reject the overlap
									relatedAcq.addReasonOfReject(7, ReasonOfReject.acqOverlapWithAcquisition,
											"Acquisition Overlap With Another Acquisition", 0, 0,
											new ArrayList<>(Arrays.asList(currentAcq.getId())));

									// mark the acq relative to the dto as
									// deleted
									relatedAcq.setRejected(true);

									// add the just created acq into the
									// rejected elements
									rejected.put(relatedAcq.getId(), relatedAcq);

									overlappedExternal = true;
								}
							}

							/*
							 * if the current dto wasn't in overlap with external acq, it must be deleted
							 * because something else was in overlap. Add a generic reason of reject
							 */
							if (!overlappedExternal) {
								// mark the acq relative to the dto as deleted
								relatedAcq.setRejected(true);

								relatedAcq.addReasonOfReject(31, ReasonOfReject.theatreOverlapAcquisition,
										"Cannot Perform Theatre Acquisition", 0, 0, null);

								// add the just created acq into the rejected
								// elements
								rejected.put(relatedAcq.getId(), relatedAcq);
							}
						}
						// detect that there is an external overlap
						overlappedExternal = true;

						// remove fact handle
						kieSession.delete(factHandleEquivalent);
					}

					// the equivalent dto isn't in overlap with anything
					else {

						TreeMap<Long, DTO> sortedDto = TheatreManagement
								.sortTheatreDto(equivalentDto.getAllDtoInEquivalentDto());
						// if the acquisition can be performed
						if (performed) {
							logger.info("THEATRE OPERATION : INSERTING ALL DTO IN THeatre");

							// iterate over all dtos in equivalent dto
							for (Map.Entry<Long, DTO> orderedElements : sortedDto.entrySet()) {
								// get the key
								int dtoKey = getContDto();

								// extract the i-esim Dto inside the
								DTO currentDto = orderedElements.getValue();

								// set the key
								currentDto.setKey(dtoKey);

								// link the current dto with the equivalent dto
								currentDto.setReferredEquivalentDto(equivalentDto.getEquivalentDtoId());

								// increment the key
								dtoKey++;
								setContDto(dtoKey);

								// check if the dto is insertable
								boolean inserted = insertDto(droolsParams, currentDto, currentSession, currentInstance);

								// if the theatre cannot be inserted
								if (!inserted) {
									// get the global variable with rejected
									// elements
									rejected = (Map<String, Acquisition>) kieSession.getGlobal("rejected");
									logger.info("rejected at step " + rejected);
									logger.info("THEATRE OPERATION : an element inside theatre is rejected ");

									// mark the boolean variable to check
									// perform to false
									performed = false;
								} else {
									// invoke the query to search the
									// acquisition with the given id
									QueryResults validAcq = kieSession.getQueryResults("acqWithGivenId",
											currentDto.getDtoId());

									// create an iterator
									Iterator<QueryResultsRow> iterator = validAcq.iterator();

									// iterate over results
									while (iterator.hasNext()) {
										// get the related acq
										Acquisition acq = (Acquisition) iterator.next().get("$acq");

										// add it to the list
										acceptedAcqList.add(acq);
									}
								}

							}
							// if the operation is valid
							if (performed) {
								// if there are linked maneuvers
								if ((equivalentDto.getManAssociated() != null)
										&& !equivalentDto.getManAssociated().isEmpty()) {
									logger.info("THEATRE OPERATION : inserting all maneuvers ");

									// get the global variable with rejected
									// elements
									rejected = (Map<String, Acquisition>) kieSession.getGlobal("rejected");

									// iterate over the man
									for (int i = 0; i < equivalentDto.getManAssociated().size(); i++) {
										logger.info("THEATRE OPERATION : inserting maneuver : "
												+ equivalentDto.getManAssociated().get(i));

										// lik the man with the equivalent dto
										// using the equivDto id
										equivalentDto.getManAssociated().get(i)
												.setReferredEquivalentDto(equivalentDto.getEquivalentDtoId());

										// set the type of man
										equivalentDto.getManAssociated().get(i).setType(ManeuverType.PitchCPS);

										// set the satellite id
										equivalentDto.getManAssociated().get(i).setSatelliteId(
												equivalentDto.getAllDtoInEquivalentDto().get(0).getSatelliteId());

										equivalentDto.getManAssociated().get(i)
												.setIdTask("x_THEATRE_" + sortedDto.firstEntry().getValue().getDtoId());
										// set correct asset
										if (sortedDto.firstEntry().getValue().getLookSide().equalsIgnoreCase("left")) {
											// to left
											equivalentDto.getManAssociated().get(i).setRightToLeftFlag(true);
										} else {
											// to right
											equivalentDto.getManAssociated().get(i).setRightToLeftFlag(false);
										}
										// set the id with the d of the first
										// element inside the equivalent dto
										equivalentDto.getManAssociated().get(i)
												.setAcq2Id(sortedDto.firstEntry().getValue().getDtoId());

										// insert the man
										kieSession.insert(equivalentDto.getManAssociated().get(i));

										kieSession.fireAllRules();

										rejected = (Map<String, Acquisition>) kieSession.getGlobal("rejected");

										if ((rejected != null) && !rejected.isEmpty()) {
											for (int j = 0; j < equivalentDto.getAllDtoInEquivalentDto().size(); j++) {
												if (rejected.containsKey(equivalentDto.getAllDtoInEquivalentDto().get(j)
														.getDtoId()) == true) {
													performed = false;
													break;
												}
											}
										}
									}
								}
							}
						}
					}
					if (!performed) {
						if (!overlappedExternal) {
							logger.info("equivalentDto id :" + equivalentDto.getEquivalentDtoId());

							for (int i = 0; i < equivalentDto.getAllDtoInEquivalentDto().size(); i++) {
								QueryResults validAcq = null;
								validAcq = kieSession.getQueryResults("acqWithGivenId",
										equivalentDto.getAllDtoInEquivalentDto().get(i).getDtoId());
								if (validAcq != null) {
									Iterator<QueryResultsRow> iterator = validAcq.iterator();
									while (iterator.hasNext()) {
										Acquisition acq = (Acquisition) iterator.next().get("$acq");
										acq.setRejected(true);
										acq.addReasonOfReject(31, ReasonOfReject.theatreOverlapAcquisition,
												"Cannot Perform Theatre Acquisition", 0, 0, null);

										logger.debug("THEATRE OPERATION : retract all acq inside theatre");
										rejected.put(acq.getId(), acq);
										retractSingleAcq(droolsParams, acq.getIdTask(), currentSession, currentInstance,
												ReasonOfReject.theatreOverlapAcquisition);
									}
								} else {
									// Acquisition relatedAcq =
									// this.du.fromDtoToAcq(equivalentDto.getAllDtoInEquivalentDto().get(i));
								}
							}
						}

					} else {
						logger.info("THEATRE OPERATION : theatre is valid");
					}

				} else if (!performed) {
					logger.info("THEATRE OPERATION : theatre is not valid because is internally inconsistent.");
					equivalentDto.rejectAllDtoInEquivalent(ReasonOfReject.theatreOverlapAcquisition);
					for (int i = 0; i < equivalentDto.getAllDtoInEquivalentDto().size(); i++) {
						retractSingleAcq(droolsParams, equivalentDto.getAllDtoInEquivalentDto().get(i).getDtoId(),
								currentSession, currentInstance, null);
					}
				} else {
					logger.info("THEATRE OPERATION : there isn t a maneuver associated with theatre.");
					equivalentDto.rejectAllDtoInEquivalent(ReasonOfReject.theatreInternallyInconsistent);
					performed = false;
				}

			} catch (Exception e) {
				// DroolsOperations.logger.error("there isn't a session with
				// this id : " + e.toString());
				throw new NullPointerException("there isn't a session with this id " + e.getStackTrace());
			}
		}
		return performed;
	}

	/**
	 * Write to file.
	 *
	 * @param currentSession  the current session
	 * @param currentInstance the current instance
	 * @param droolsParams    the drools params
	 */
	@SuppressWarnings("unchecked")
	public void writeToFile(String currentSession, int currentInstance, DroolsParameters droolsParams) {
		String sessionInstance = DroolsParameters.concatenateSession(currentSession, currentInstance);

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the path where will
		// be stored the output
		String orderedResponceFilePath = droolsParams.getResponceFile();

		// get the current kie session
		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionInstance);

		// get all the resourceFunctions
		ResourceFunctions resFunc = (ResourceFunctions) kie.getGlobal("resourceFunctions");
		logger.debug(orderedResponceFilePath);
		logger.debug("writing to file all accepted elements");
		try {

			System.out.println(orderedResponceFilePath);
			String path = orderedResponceFilePath.substring(0, orderedResponceFilePath.lastIndexOf("/") - 1);
			System.out.println("path " + path);

			String folderName = orderedResponceFilePath.substring(orderedResponceFilePath.lastIndexOf("/") + 1,
					orderedResponceFilePath.lastIndexOf("."));
			System.out.println("folderName " + folderName);
			String fileWithoutExtension = orderedResponceFilePath.substring(0,
					orderedResponceFilePath.lastIndexOf("."));
			System.out.println("fileWithoutExtension " + fileWithoutExtension);

			// File dir = new File(fileWithoutExtension);
			// dir.mkdir();

			String subFolder = fileWithoutExtension + File.separator + folderName + "RESOURCES.xml";
			System.out.println("subFolder " + subFolder);

			// PrintOutput.resourcesXML(subFolder, currentSession,
			// currentInstance, droolsParams);

			// receive the report from Drools global
			List<String> allAcqPerformedByPriority = (List<String>) kie.getGlobal("report");

			// concatenate the name with the current session
			orderedResponceFilePath = fileWithoutExtension.concat(sessionInstance).concat(".txt");
			List<Task> factsSat1 = new ArrayList<>();
			List<Task> factsSat2 = new ArrayList<>();
			for (int i = 0; i < droolsParams.getAllSat().size(); i++) {
				// if the i-esim satellite is sat1
				if (droolsParams.getAllSat().get(i).getSatelliteId().contains("1")) {
					// add all the accepted dto for sat1
					factsSat1.addAll(receiveDtoAccepted(currentSession, currentInstance, droolsParams,
							droolsParams.getAllSat().get(i).getSatelliteId()));
				}
				// if the i-esim satellite is sat2
				else {
					// add all the accepted dto for sat2
					factsSat2.addAll(receiveDtoAccepted(currentSession, currentInstance, droolsParams,
							droolsParams.getAllSat().get(i).getSatelliteId()));
				}
			}

			// get only the rejected for sat1
			List<Task> invalidElementsSat1 = receiveDtoRejectedForSatellite("1", currentSession, currentInstance);
			// get only the rejected for sat2
			List<Task> invalidElementsSat2 = receiveDtoRejectedForSatellite("2", currentSession, currentInstance);

			// create a BufferedWriter
			BufferedWriter bw = new BufferedWriter(new FileWriter(orderedResponceFilePath));
			bw.write(" \n\n file printed at time : " + new Date() + " \n\n");

			bw.write("Initial status of resources \n\n");
			bw.write("hp segment valid for sat 1 :" + resFunc.getHpExclAssociatedToSat("1") + "\n");
			bw.write("hp segment valid for sat 2 :" + resFunc.getHpExclAssociatedToSat("2") + "\n");

			bw.write("initial lookSide sat1 : " + droolsParams.getAllSat().get(0).getInitialLookSide() + "\n");
			bw.write("initial lookSide sat2 : " + droolsParams.getAllSat().get(1).getInitialLookSide() + "\n");
			bw.write("time for maneuver RW: " + droolsParams.getTimeForManeuverRW() + "\n");
			bw.write("time for maneuver CMGA: " + droolsParams.getTimeForManeuverCmga() + "\n");
			bw.write("max number of hp acquisition for session  : " + droolsParams.getPrTypeMaxNumber() + "\n");
			bw.write("\n\n----------------------------------------------------------\n\n");
			bw.write("RESOURCES AT MISSION HORIZON START TIME : \n\n\n");
			bw.write("\nMISSION HORIZON  :  \n");
			bw.write(droolsParams.getCurrentMH() + " \n");
			bw.write("\nSatellites :  \n");

			// write all sats
			for (int i = 0; i < droolsParams.getAllSat().size(); i++) {
				bw.write(droolsParams.getAllSat().get(i) + "\n");
			}

			// write all paws
			bw.write("\n PAW :  \n");
			for (int i = 0; i < droolsParams.getAllPAWS().size(); i++) {
				bw.write(droolsParams.getAllPAWS().get(i) + "\n");
			}

			// write all visibilities
			bw.write("\n Visibilities :  \n");
			for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {
				bw.write("\t" + droolsParams.getAllVisibilities().get(i) + "\n\n");
			}

			// write all eclipses
			bw.write("\n Eclipses :  \n");
			for (int i = 0; i < droolsParams.getAllEclipses().size(); i++) {
				bw.write(droolsParams.getAllEclipses().get(i) + "\n");
			}

			// write all pdht state at initial time
			bw.write("\n DOWNLOAD RETAIN :  \n");

			// for (int i = 0; i < droolsParams.getAllPDHT().size(); i++)
			// {
			bw.write("" + resFunc.getDownloadPriorityQueueSatInitPlan1() + "\n");
			// }

			// write all pdht state at initial time
			bw.write("\n PDHT INITIAL STATE :  \n");
			for (int i = 0; i < droolsParams.getAllPDHT().size(); i++) {
				bw.write("" + sortMemoryModulesInsidePDHT(droolsParams.getAllPDHT().get(i)) + "\n");
			}

			// write all pdht state at final time
			bw.write("\n PDHT LAST STATE :  \n");
			bw.write("" + sortMemoryModulesInsidePDHT(
					resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht()) + "\n");
			bw.write("" + sortMemoryModulesInsidePDHT(
					resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht()) + "\n");

			bw.write("\n Partners :  \n");
			for (int i = 0; i < droolsParams.getAllPartners().size(); i++) {
				bw.write(droolsParams.getAllPartners().get(i) + "\n");
			}

			bw.write("\n\n----------------------------------------------------------\n\n");
			bw.write("\n acq performed by priority : \n");

			for (int i = 0; i < allAcqPerformedByPriority.size(); i++) {
				bw.write("\t  " + allAcqPerformedByPriority.get(i) + "\n");
			}

			printElements(droolsParams, "sat1", factsSat1, invalidElementsSat1, resFunc, bw);
			printElements(droolsParams, "sat2", factsSat2, invalidElementsSat2, resFunc, bw);

			// close the BufferedWriter
			bw.close();
			// DroolsOperations.logger.debug("writed the results on file : " +
			// orderedResponceFilePath);

		} catch (IOException e1) {
			// error on the IO operation
			// with the responceFilePath
			try {
				throw new IOException(e1.toString() + " error on the IO operation with the responceFilePath ");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Prints the invalid elements.
	 *
	 * @param droolsParams     the drools params
	 * @param satId            the sat id
	 * @param factsSat1        the facts sat 1
	 * @param rejectedElements the rejected elements
	 * @param resFunc          the res func
	 * @param bw               the bw
	 */
	public void printElements(DroolsParameters droolsParams, String satId, List<Task> factsSat1,
			List<Task> rejectedElements, ResourceFunctions resFunc, BufferedWriter bw) {
		try {
			List<Task> alltasksWrited = new ArrayList<>();
			// create a count for the
			// total processed acq
			int contTotalAcq = 0;

			// create a count for the
			// total left processed acq
			int acqLeft = 0;

			bw.write("\n\n-----------------VALID ELEMENTS FOR " + satId + "---------------------\n\n");

			// sort elements by start time
			DownloadUtils.sortTasksByStartTime(factsSat1);

			// iterate over all the elements
			for (int i = 0; i < factsSat1.size(); i++) {
				if (!alltasksWrited.contains(factsSat1.get(i))) {
					alltasksWrited.add(factsSat1.get(i));
					bw.write(factsSat1.get(i) + "\n");
				}
				// if the element is an acquisition
				if (factsSat1.get(i).getTaskType().compareTo(TaskType.ACQUISITION) == 0) {
					// increment the total
					contTotalAcq++;
					Acquisition acq = (Acquisition) factsSat1.get(i);

					// if lookside is left
					if (acq.getLookSide().equalsIgnoreCase("left")) {
						// increment the total left
						acqLeft++;
					}
				}
			}
			List<ReportDownloads> retainDownloads = this.du
					.processRetainDownloads(resFunc.getDownloadPriorityQueueForSat(satId));

			bw.write("\n\n total acq performed : " + contTotalAcq);
			bw.write("\n\n left acq are : " + acqLeft + "/" + contTotalAcq);
			bw.write("\n\n extra cost left  : " + droolsParams.getExtraCostLeft());
			bw.write("\n\n acq in retain mode  : " + retainDownloads.size());

			for (int i = 0; i < retainDownloads.size(); i++) {
				bw.write("\n\n\t acq retain : " + retainDownloads.get(i).getForAcq());
				bw.write("\n\n\t\t partners : " + retainDownloads.get(i).getSectorsForPartner());
			}

			bw.write("\n\n-----------------INVALID ELEMENTS FOR " + satId + "---------------------\n\n");

			// if there are invalid elements
			if ((rejectedElements != null) && !rejectedElements.isEmpty()) {
				// iterate over them
				for (int i = 0; i < rejectedElements.size(); i++) {
					Task acq = rejectedElements.get(i);
					// DroolsOperations.logger.debug("acq : " + acq);

					// if the element has at least a
					// reason of reject associated
					if (!acq.getReasonOfReject().isEmpty()
							&& (acq.getReasonOfReject().get(0).getReason().compareTo(ReasonOfReject.deletedByCsps) != 0)
							&& (acq.getReasonOfReject().get(0).getReason()
									.compareTo(ReasonOfReject.deletedForDi2s) != 0)) {
						bw.write("\n\n ID:" + acq.getIdTask() + ", startTime : " + acq.getStartTime() + ", endTime :"
								+ acq.getEndTime());

						// iterate over the reasons
						for (int j = 0; j < acq.getReasonOfReject().size(); j++) {
							// extract the j-esim reason
							ReasonOfRejectElement reason = acq.getReasonOfReject().get(j);

							bw.write("\n\tBECAUSE : \t:" + reason.getReason() + "\n");

							// if there are elements involved in the reject
							if ((reason.getElementsInvolved() != null) && !reason.getElementsInvolved().isEmpty()) {
								// iterate over them
								for (Map.Entry<Double, List<ElementsInvolvedOnOrbit>> violationOrbit : reason
										.getElementsInvolved().entrySet()) {
									// extract the orbit where there
									// is the failure
									double failOnOrbit = violationOrbit.getKey();
									bw.write("\t: fail on orbit " + failOnOrbit);
									List<ElementsInvolvedOnOrbit> elements = violationOrbit.getValue();

									// if there are ElementsInvolvedOnOrbit
									// associated
									for (int k = 0; k < elements.size(); k++) {
										if ((elements.get(k) != null)
												&& (elements.get(k).getElementsInvolved() != null)) {

											// write the elements involved
											bw.write("\t\t\t: sliding window  " + elements.get(k).getSlidingWindow());
											bw.write(" elements involved : "
													+ elements.get(k).getElementsInvolved().toString());
										}
									}
								}
							}
						}
					}
				}
			} else {
				// there aren't invalid elements
				bw.write("\n\n\n there aren't invalid elements for " + satId + " \n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Gets the cont dto.
	 *
	 * @return the cont dto
	 */
	public static int getContDto() {
		return contDto;
	}

	/**
	 * Sets the cont dto.
	 *
	 * @param cont the new cont dto
	 */
	public static void setContDto(int cont) {
		contDto = cont;
	}
}
