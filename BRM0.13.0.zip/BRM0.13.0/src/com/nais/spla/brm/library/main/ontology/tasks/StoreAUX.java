/**
*
* MODULE FILE NAME:	StoreAUX.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		06 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 06 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;

// TODO: Auto-generated Javadoc
/**
 * The Class StoreAUX.
 *
 * @author francesca
 */
@SuppressWarnings("serial")
public class StoreAUX extends Task {

	/** The enable flag. */
	private boolean enableFlag = false;

	/** The packet store id. */
	private String packetStoreId = null;

	/** The paw type. */
	private PAWType pawType = null;

	/**
	 * Instantiates a new store AUX.
	 */
	public StoreAUX() {
		super();
	}

	/**
	 * Instantiates a new store AUX.
	 *
	 * @param enableFlag    the enable flag
	 * @param packetStoreId the packet store id
	 */
	public StoreAUX(boolean enableFlag, String packetStoreId) {
		super();

		// set the enable flag : true for turn off the download of gps and false
		// to turn on
		this.enableFlag = enableFlag;
		this.packetStoreId = packetStoreId;
	}

	/**
	 * Checks if is enable flag.
	 *
	 * @return the enableFlag
	 */
	public boolean isEnableFlag() {
		return this.enableFlag;
	}

	/**
	 * toString
	 *
	 * @return toString
	 */
	@Override
	public String toString() {
		return "StoreAUX [enableFlag=" + this.enableFlag + ", packetStoreId=" + this.packetStoreId + ", getStartTime()="
				+ getStartTime() + " for type of paw : " + this.pawType + " ]";
	}

	/**
	 * Gets the paw type.
	 *
	 * @return the pawType
	 */
	public PAWType getPawType() {
		return this.pawType;
	}

	/**
	 * Sets the paw type.
	 *
	 * @param pawType the pawType to set
	 */
	public void setPawType(PAWType pawType) {
		this.pawType = pawType;
	}

	/**
	 * Gets the packet store id.
	 *
	 * @return the packet store id
	 */
	public String getPacketStoreId() {
		return packetStoreId;
	}

}
