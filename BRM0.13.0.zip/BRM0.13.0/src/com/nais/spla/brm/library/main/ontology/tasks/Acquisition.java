/**
*
* MODULE FILE NAME: Acquisition.java
*
* MODULE TYPE:      <Class definition>
*
* FUNCTION:         <Functional description of the DDC>
*
* PURPOSE:          <List of SR>
*
* CREATION DATE:    <17-NOV-2016>
*
* AUTHORS:          Francesca Pedrola
*
* DESIGN ISSUE:     0.1
*
* INTERFACES:       <prototype and list of input/output parameters>
*
* SUBORDINATES:     <list of functions called by this DDC>
*
* MODIFICATION HISTORY:
*
*             Date          |  Name      |   New ver.     | Description
* --------------------------+------------+----------------+-------------------------------
* <DD-MMM-YYYY>             | <name>     |<Ver>.<Rel>     | <reasons of changes>
* --------------------------+------------+----------------+-------------------------------
*
* PROCESSING
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;
import com.nais.spla.brm.library.main.ontology.utils.ElementsInvolvedOnOrbit;

// TODO: Auto-generated Javadoc
/**
 * This class models the task associated with an image acquisition.
 */
@SuppressWarnings("serial")
public class Acquisition extends Task {

	/** The key. */
	private long key;

	/** The look side. */
	private String lookSide;

	/** The remove ar id. */
	private boolean removeArId = false;

	/** The size. */
	private int sizeH;

	/** The size. */
	private int sizeV;

	/** The extra left. */
	private double extraLeft = 0;

	/** The sensor mode. */
	private TypeOfAcquisition sensorMode;

	/** The ess. */
	private double ess = 0;

	/** The polarization. */
	private Polarization polarization;

	/** The pr mode. */
	private PRMode prMode;

	/** The is stereopair. */
	private boolean isStereopair;

	/** The linked dto id. */
	private String linkedDtoId;

	/** The in eclipse. */
	private boolean inEclipse = false;

	/** The revolution number. */
	private int revolutionNumber = -1;

	/** The pass through flag. */
	private boolean passThroughFlag;

	/** The neo. */
	private boolean neo = false;

	/** The next element key. */
	private long nextElementKey = -1;

	/** The image BIC. */
	private double imageBIC = 0;

	/** The pr type. */
	private PRType prType = null;

	/** The di2s available. */
	private boolean di2sAvailable;

	/** The interleaved channel. */
	private int interleavedChannel;

	/** The backup vis. */
	private List<String> backupVis = null;

	/** The user info. */
	private List<UserInfo> userInfo = null;

	/** The priority. */
	private int priority = 1;

	/** The preferred vis. */
	private List<String> preferredVis = null;

	/** The replaced request list id. */
	private List<String> replacedRequestListId = null;

	/**
	 * empty constructor used only for tests.
	 */
	public Acquisition() {
		super();
		// set the task type
		super.setTaskType(TaskType.ACQUISITION);
		this.revolutionNumber = -1;

		// set the removable flag
		super.setRemovableFlag(true);

		// initialize the rejected flag
		super.setRejected(false);

		// set the pr type
		this.setPrType(PRType.HP);

		// initialize the dummy flag
		this.setDummy(false);

		// initialize the pt flag
		this.passThroughFlag = false;
		this.userInfo = new ArrayList<>();

		// initialize the di2s flag
		this.di2sAvailable = false;
		this.extraLeft = 0;
		this.userInfo = new ArrayList<>();
		this.preferredVis = new ArrayList<>();

		this.backupVis = new ArrayList<>();
	}

	/**
	 * parameterized Constructor.
	 *
	 * @param id          the id
	 * @param start       the start
	 * @param end         the end
	 * @param lookSide    the look side
	 * @param satelliteId the satellite id
	 * @param sensorMode  the sensor mode
	 */
	public Acquisition(String id, Date start, Date end, String lookSide, String satelliteId,
			TypeOfAcquisition sensorMode) {
		super();
		// set the id task
		super.setIdTask(id);

		// set the start time
		super.setStartTime(start);

		// set the stop time
		super.setEndTime(end);

		// set if is rejected
		super.setRejected(false);

		super.setPreviousMh(false);

		super.setPreviousSession(false);

		// set the satellite id
		super.setSatelliteId(satelliteId);

		// set the task type
		super.setTaskType(TaskType.ACQUISITION);

		// set the pr type
		this.setPrType(PRType.HP);

		// set the removable flag
		super.setRemovableFlag(true);

		// set the lookSide
		this.lookSide = lookSide;

		// set the pt flag
		this.passThroughFlag = false;

		this.userInfo = new ArrayList<>();
		this.sensorMode = sensorMode;
		this.di2sAvailable = false;
		this.userInfo = new ArrayList<>();
		this.setDummy(false);
		super.setReferredEquivalentDto(null);
		this.setPreferredVis(new ArrayList<String>());

	}

	/**
	 * Sets the id task.
	 *
	 * @param idTask the new id task
	 */
	@Override
	public void setIdTask(String idTask) {
		super.setIdTask(idTask);
	}

	/**
	 * Gets the ess.
	 *
	 * @return the ess
	 */
	public double getEss() {
		return this.ess;
	}

	/**
	 * Gets the boolean flag that indicate if the acquisition is removable or not.
	 *
	 * @return isRemovableFlag : true if is removable, false if is referred to the previous mission horizon so it is unremovable
	 */
	@Override
	public boolean isRemovableFlag() {
		return super.isRemovableFlag();
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return super.getIdTask();
	}

	/**
	 * Sets the id.
	 *
	 * @param idTask the new id
	 */
	public void setId(String idTask) {
		super.setIdTask(idTask);
	}

	/**
	 * Gets the image BIC.
	 *
	 * @return the image BIC
	 */
	public double getImageBIC() {
		return this.imageBIC;
	}


	/**
	 * Gets the key.
	 *
	 * @return the key
	 */
	public long getKey() {
		return this.key;
	}

	/**
	 * Gets the look side.
	 *
	 * @return the lookSide
	 */
	public String getLookSide() {
		return this.lookSide;
	}

	/**
	 * Gets the interleaved channel.
	 *
	 * @return the interleavedChannel
	 */
	public int getInterleavedChannel() {
		return this.interleavedChannel;
	}

	/**
	 * Sets the look side.
	 *
	 * @param lookSide the lookSide to set
	 */
	public void setLookSide(String lookSide) {
		this.lookSide = lookSide;
	}

	/**
	 * Gets the next element key.
	 *
	 * @return the nextElementKey
	 */
	public long getNextElementKey() {
		return this.nextElementKey;
	}

	/**
	 * Gets the polarization.
	 *
	 * @return the polarization
	 */
	public Polarization getPolarization() {
		return this.polarization;
	}

	/**
	 * Gets the pr type.
	 *
	 * @return the pr type
	 */
	public PRType getPrType() {
		return this.prType;
	}

	/**
	 * Gets the revolution number.
	 *
	 * @return the revolution number
	 */
	public int getRevolutionNumber() {
		return this.revolutionNumber;
	}

	/**
	 * Gets the satellite id.
	 *
	 * @return the satelliteId
	 */

	@Override
	public String getSatelliteId() {
		return super.getSatelliteId();
	}

	/**
	 * Gets the sensor mode.
	 *
	 * @return the sensorMode
	 */
	public TypeOfAcquisition getSensorMode() {
		return this.sensorMode;
	}

	/**
	 * Gets the start time of the acquisition
	 * 
	 * @return the download start time
	 */
	@Override
	public Date getStartTime() {
		return super.getStartTime();
	}

	/**
	 * Checks if is rejected.
	 *
	 * @return true, if is rejected
	 */
	/*
	 * public void setSatelliteId(String satelliteId) { this.satelliteId =
	 * satelliteId; }
	 */

	/**
	 * Checks if is in eclipse.
	 *
	 * @return true, if is in eclipse
	 */
	public boolean isInEclipse() {
		return this.inEclipse;
	}

	/**
	 * Checks if is neo.
	 *
	 * @return true, if is neo
	 */
	public boolean isNeo() {
		return this.neo;
	}

	/**
	 * Sets the ess.
	 *
	 * @param ess the ess to set
	 */
	public void setEss(double ess) {
		this.ess = ess;
	}

	/**
	 * Sets the image BIC.
	 *
	 * @param imageBIC the new image BIC
	 */
	public void setImageBIC(double imageBIC) {
		this.imageBIC = imageBIC;
	}

	/**
	 * Sets the in eclipse.
	 *
	 * @param inEclipse the new in eclipse
	 */
	public void setInEclipse(boolean inEclipse) {
		this.inEclipse = inEclipse;
	}

	/**
	 * Sets the key.
	 *
	 * @param key the key to set
	 *
	 *            ONLY FOR TEST
	 */
	public void setKey(long key) {
		this.key = key;
	}

	/**
	 * Sets the neo.
	 *
	 * @param neo the new neo
	 */
	public void setNeo(boolean neo) {
		this.neo = neo;
	}

	/**
	 * Sets the next element key.
	 *
	 * @param nextElementKey the nextElementKey to set
	 */
	public void setNextElementKey(long nextElementKey) {
		this.nextElementKey = nextElementKey;
	}

	/**
	 * Sets the polarization.
	 *
	 * @param polarization the new polarization
	 */
	public void setPolarization(Polarization polarization) {
		this.polarization = polarization;
	}

	/**
	 * Sets the pr type.
	 *
	 * @param prType the new pr type
	 */
	public void setPrType(PRType prType) {
		this.prType = prType;
	}

	/**
	 * Sets the revolution number.
	 *
	 * @param revolutionNumber the new revolution number
	 */
	public void setRevolutionNumber(int revolutionNumber) {
		this.revolutionNumber = revolutionNumber;
	}

	/**
	 * Sets the sensor mode.
	 *
	 * @param sensorMode the sensorMode to set ONLY FOR TEST
	 */
	public void setSensorMode(TypeOfAcquisition sensorMode) {
		this.sensorMode = sensorMode;
	}

	/**
	 * Gets the id task.
	 *
	 * @return idTask the task id of the acquisition
	 */
	@Override
	public String getIdTask() {
		return super.getIdTask();
	}

	/**
	 * Checks if is di 2 s available.
	 *
	 * @return true, if is di 2 s available
	 */
	public boolean isDi2sAvailable() {
		return this.di2sAvailable;
	}

	/**
	 * Gets the isRejected that indicate if an acquisition is rejected or not
	 *
	 * @return isRejected  false is the acquisition is scheduled, true is is rejected
	 */
	@Override
	public boolean isRejected() {
		return super.isRejected();
	}

	/**
	 * Sets the isRejected flag
	 *
	 * @param isRejected false is the acquisition is scheduled, true is is rejected
	 */
	@Override
	public void setRejected(boolean rejected) {
		super.setRejected(rejected);
	}

	/**
	 * Sets the di 2 s available.
	 *
	 * @param di2sAvailable the new di 2 s available
	 */
	public void setDi2sAvailable(boolean di2sAvailable) {
		this.di2sAvailable = di2sAvailable;
	}

	/**
	 * Gets the reason of reject.
	 *
	 * @return the reason of reject
	 */
	@Override
	public List<ReasonOfRejectElement> getReasonOfReject() {
		return super.getReasonOfReject();
	}

	/**
	 * Find reason of reject.
	 *
	 * @param reason the reason
	 * @return the reason of reject element
	 */
	public ReasonOfRejectElement findReasonOfReject(ReasonOfReject reason) {
		// declare a reason of reject
		ReasonOfRejectElement foundReason = null;

		// iterate over the reasonOfReject associated with the acq
		for (int i = 0; i < this.getReasonOfReject().size(); i++) {
			// if the i-esim reason is the same of the one given as input
			if (this.getReasonOfReject().get(i).getReason().compareTo(reason) == 0) {
				// extract the reason
				foundReason = this.getReasonOfReject().get(i);

				// exit from the cycle
				break;
			}
		}
		return foundReason;
	}

	/**
	 * Gets the partners associated.
	 *
	 * @return the partners associated
	 */
	public List<String> getPartnersAssociated() {
		// create an empty list of partners associated id
		List<String> partnersAssociated = new ArrayList<>();

		// iterate over the user info
		for (int i = 0; i < this.userInfo.size(); i++) {
			// add the i-esim user info owner id to the list of partners
			// associated
			partnersAssociated.add(this.userInfo.get(i).getOwnerId());
		}
		return partnersAssociated;
	}

	/**
	 * Adds the reason of reject.
	 *
	 * @param id               the id
	 * @param reason           the reason
	 * @param description      the description
	 * @param orbit            the orbit
	 * @param slidingWindow    the sliding window
	 * @param elementsInvolved the elements involved
	 */
	public void addReasonOfReject(int id, ReasonOfReject reason, String description, double orbit, int slidingWindow,
			List<String> elementsInvolved) {
		// if there is at least an element involved
		if ((elementsInvolved != null) && !elementsInvolved.isEmpty()) {
			// filter from unremovable tasks
			elementsInvolved = excludeUnremovableTasks(elementsInvolved);
		}

		// initialize the boolean variable to false
		boolean found = false;

		// create a new instance of ElementsInvolvedOnOrbit
		ElementsInvolvedOnOrbit newElementsInvolved = new ElementsInvolvedOnOrbit(slidingWindow, elementsInvolved);

		// iterate over the reason of reject
		for (int i = 0; i < this.getReasonOfReject().size(); i++) {
			// extract the i-esim reason
			ReasonOfRejectElement currentReason = this.getReasonOfReject().get(i);

			// if there is a match
			if (currentReason.getReason().compareTo(reason) == 0) {
				// if the list of elements still has the reason of reject
				found = true;
				currentReason.addElementInvolved(orbit, newElementsInvolved);
			}
		}
		// if the list of elements doesn't have the reason of reject
		if (!found) {
			// create a new reason with the parameters given as input
			ReasonOfRejectElement newReason = new ReasonOfRejectElement(reason, id, description, null);

			newReason.addElementInvolved(orbit, newElementsInvolved);

			// add to the list of reaqson of reject
			this.getReasonOfReject().add(newReason);
		}
		// mark the acq as rejected
		this.setRejected(true);

	}

	/**
	 * Exclude unremovable tasks.
	 *
	 * @param elementsInvolved the elements involved
	 * @return the list
	 */
	private List<String> excludeUnremovableTasks(List<String> elementsInvolved) {
		// extract the logger
		// Logger logger = DroolsParameters.getLogger();
		//
		// //get the current kie session
		// KieSession kie =
		// DroolsParameters.getDroolsEnv().getKieSessionsMap().get(DroolsParameters.getCurrentSession());
		//
		// HashMap<String,Acquisition> allAcq = (HashMap<String,Acquisition>)
		// kie.getGlobal("alLAccepted");
		//
		// //iterate over the involved elements
		// for(int i=0;i<elementsInvolved.size();i++)
		// {
		//
		// //if the acquisition is flagged as unremovable
		// if(allAcq.containsKey(elementsInvolved.get(i)) &&
		// (allAcq.get(elementsInvolved.get(i)).isRemovableFlag()==false))
		// {
		// //delete it from the list of involved elements
		// elementsInvolved.remove(i);
		//
		// //decrement the index
		// i--;
		// }
		// }
		// return the filtered list
		return elementsInvolved;
	}

	/**
	 * Checks if is pass through flag.
	 *
	 * @return true, if is pass through flag
	 */
	public boolean isPassThroughFlag() {
		return this.passThroughFlag;
	}

	/**
	 * Sets the pass through flag.
	 *
	 * @param passThroughFlag the new pass through flag
	 */
	public void setPassThroughFlag(boolean passThroughFlag) {
		this.passThroughFlag = passThroughFlag;
	}

	/**
	 * Gets the size H.
	 *
	 * @return the size H
	 */
	public int getSizeH() {
		return this.sizeH;
	}

	/**
	 * Sets the size H.
	 *
	 * @param sizeH the new size H
	 */
	public void setSizeH(int sizeH) {
		this.sizeH = sizeH;
	}

	/**
	 * Gets the size V.
	 *
	 * @return the size V
	 */
	public int getSizeV() {
		return this.sizeV;
	}

	/**
	 * Gets the task mark.
	 *
	 * @return the related task mark
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/**
	 * Sets the task mark of the acquisition
	 *
	 * @param the taskMark of the acquisition
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/**
	 * Gets the related task type.
	 *
	 * @return the related task type
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/**
	 * Sets the related task type.
	 *
	 * @params the related taskType
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}
	/**
	 * Sets the size V.
	 *
	 * @param sizeV the new size V
	 */
	public void setSizeV(int sizeV) {
		this.sizeV = sizeV;
	}

	/**
	 * Gets the boolean flag that indicate if the acquisition is dummy or not
	 *
	 * @return isDummy 
	 */
	@Override
	public boolean isDummy() {
		return super.isDummy();
	}

	/**
	 * set the boolean flag that indicate if the acquisition is dummy or not
	 *
	 * @params sDummy : true if the acquisition is dummy and it is used only as mock object
	 * false : is the acquisition is a real one
	 */
	@Override
	public void setDummy(boolean isDummy) {
		super.setDummy(isDummy);
	}

	/**
	 * Gets the referred equiv dto.
	 *
	 * @return the referred equiv dto
	 */
	@Override
	public String getReferredEquivalentDto() {
		return super.getReferredEquivalentDto();
	}

	/**
	 * Sets the referred equiv dto.
	 *
	 * @param referredEquivDto the new referred equiv dto
	 */
	@Override
	public void setReferredEquivalentDto(String referredEquivDto) {
		super.setReferredEquivalentDto(referredEquivDto);
	}

	/**
	 * Gets the user info.
	 *
	 * @return the user info
	 */
	public List<UserInfo> getUserInfo() {
		return this.userInfo;
	}

	/**
	 * Check if user info contains partner id.
	 *
	 * @param partnerId the partner id
	 * @return true, if successful
	 */
	public boolean checkIfUserInfoContainsPartnerId(String partnerId) {
		// initialize the boolean variable to false
		boolean contained = false;

		// if there is at least an user info associated
		if (this.userInfo.size() > 0) {
			// iterate over the user info
			for (int i = 0; i < this.userInfo.size(); i++) {
				// if there is a match of owner id
				if (this.userInfo.get(i).getOwnerId().equalsIgnoreCase(partnerId)) {
					// found
					contained = true;
				}
			}
		}
		return contained;
	}

	/**
	 * Removes the reason of reject.
	 *
	 * @param reason the reason
	 */
	public void removeReasonOfReject(ReasonOfReject reason) {
		// iterate over the reasons of reject
		for (int i = 0; i < this.getReasonOfReject().size(); i++) {
			// if there is a match
			if (this.getReasonOfReject().get(i).getReason().equals(reason)) {
				// remove the i-esim reason
				this.getReasonOfReject().remove(i);

				// decrement the index
				i--;
			}

		}
	}

	/**
	 * Sets the user info.
	 *
	 * @param userInfo the new user info
	 */
	public void setUserInfo(List<UserInfo> userInfo) {
		this.userInfo = userInfo;
	}

	/**
	 * print out all the properties of the acquisition
	 *
	 * @return the tostring with a report of all the properties of the acquisition 
	 */
	@Override
	public String toString() {
		
		/*
		 * print out all the 
		 * properties of the acquisition
		 *
		 * return the tostring with 
		 * a report of all the properties 
		 * of the acquisition 
		 */
		return "Acquisition [id=" + super.getIdTask() + "  isRejected :" + super.isRejected() + ", reasonOfReject= "
				+ this.getReasonOfReject() + ", extraCostLeft : " + this.extraLeft + " ,starttime : "
				+ super.getStartTime() + ", endTime : " + super.getEndTime() + ", lookSide=" + this.lookSide
				+ ", sizeH=" + this.sizeH + ", sizeV=" + this.sizeV + ", sensorMode=" + this.sensorMode + ", ess="
				+ this.ess + ", polarization=" + this.polarization + ", prMode=" + this.prMode + ", isStereopair="
				+ this.isStereopair + ", linkedDtoId=" + this.linkedDtoId + ", inEclipse=" + this.inEclipse
				+ ", revolutionNumber=" + this.revolutionNumber + ", passThroughFlag=" + this.passThroughFlag + ", neo="
				+ this.neo + ", nextElementKey=" + this.nextElementKey + ", imageBIC=" + this.imageBIC + ", prType="
				+ this.prType + ", di2sAvailable=" + this.di2sAvailable + ", interleavedChannel="
				+ this.interleavedChannel + ", userInfo=" + this.userInfo + ", priority=" + this.priority
				+ ", preferredVis=" + this.preferredVis + "backUpVis =" + this.backupVis + " , satelliteId ="
				+ super.getSatelliteId() + ",di2sInfo : " + this.getDi2sInfo() + "isTimePerformance :"
				+ this.isTimePerformance() + " revolutionNumber " + this.getRevolutionNumber() + "]";
	}

	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return this.priority;
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * Gets the preferred vis.
	 *
	 * @return the preferredVis
	 */
	public List<String> getPreferredVis() {
		return this.preferredVis;
	}

	/**
	 * Sets the preferred vis.
	 *
	 * @param preferredVis the preferredVis to set
	 */
	public void setPreferredVis(List<String> preferredVis) {
		this.preferredVis = preferredVis;
	}

	/**
	 * Gets the pr mode.
	 *
	 * @return the prMode
	 */
	public PRMode getPrMode() {
		return this.prMode;
	}

	/**
	 * Sets the pr mode.
	 *
	 * @param prMode the prMode to set
	 */
	public void setPrMode(PRMode prMode) {
		this.prMode = prMode;
	}

	/**
	 * Sets the interleaved channel.
	 *
	 * @param interleavedChannel the interleavedChannel to set
	 */
	public void setInterleavedChannel(int interleavedChannel) {
		this.interleavedChannel = interleavedChannel;
	}

	/**
	 * Checks if is stereopair.
	 *
	 * @return the isStereopair
	 */
	public boolean isStereopair() {
		return this.isStereopair;
	}

	/**
	 * Sets the stereopair.
	 *
	 * @param isStereopair the isStereopair to set
	 */
	public void setStereopair(boolean isStereopair) {
		this.isStereopair = isStereopair;
	}

	/**
	 * Gets the linked dto id.
	 *
	 * @return the linkedDtoId
	 */
	public String getLinkedDtoId() {
		return this.linkedDtoId;
	}

	/**
	 * Sets the linked dto id.
	 *
	 * @param linkedDtoId the linkedDtoId to set
	 */
	public void setLinkedDtoId(String linkedDtoId) {
		this.linkedDtoId = linkedDtoId;
	}

	/**
	 * Creates the acq from dto.
	 *
	 * @param dto the dto
	 * @param acq the acq
	 * @throws Exception the exception
	 */
	public void createAcqFromDto(DTO dto, Acquisition acq) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		logger.debug("trying to convert the dto into an acq");

//        // if the dto is a VU
//        if (dto.getPrType().compareTo(PRType.VU) == 0)
//        {
//            // mark the acquisition as unremovable
//            acq.setRemovableFlag(false);
//        }

		// set the sizes of the acq
		acq.setSizeH(dto.getSizeH());
		acq.setSizeV(dto.getSizeV());

		acq.setTimePerformance(dto.isTimePerformance());

		// set the task type
		acq.setTaskType(TaskType.ACQUISITION);

		// set the id
		acq.setId(dto.getDtoId());

		// set the start time
		acq.setStartTime(dto.getStartTime());

		// set the stop time
		acq.setEndTime(dto.getEndTime());

		// set the lookSide
		acq.setLookSide(dto.getLookSide());

		// set the satellite id
		acq.setSatelliteId(dto.getSatelliteId());

		// set the sensor mode
		acq.setSensorMode(dto.getSensorMode());

		// set the key
		acq.setKey(dto.getKey());

		// set the polarization
		acq.setPolarization(dto.getPol());

		// set the prType
		acq.setPrType(dto.getPrType());

		// set if the acquisition is a neo or not
		acq.setNeo(dto.isNeoAvailable());

		// set the image bic
		acq.setImageBIC(dto.getImageBIC());

		// set the priority
		acq.setPriority(dto.getPriority());

		// set the list of preferred visibilities
		acq.setPreferredVis(dto.getPreferredVis());

		acq.setBackupVis(dto.getBackupVis());

		// set the list of user info
		acq.setUserInfo(dto.getUserInfo());

		// set the passthrough flag
		acq.setPassThroughFlag(dto.isPtAvailable());

		// set the referred equivalent dto id
		acq.setReferredEquivalentDto(dto.getReferredEquivalentDto());

		// set the revolution number
		acq.setRevolutionNumber(dto.getRevolutionNumber());

		// set the prmode
		acq.setPrMode(dto.getPrMode());

		acq.setDi2sAvailable(dto.isDi2s());

		// set if is a stereopair
		acq.setStereopair(dto.isStereopair());

		// set the linked dto id
		acq.setLinkedDtoId(dto.getLinkedDtoId());

		// set the list of repleaceable dto id
		acq.setReplacedRequestListId(dto.getReplacedRequestListId());

		// set the interleaved channel
		acq.setInterleavedChannel(dto.getInterleavedChannel());

		// if the dto is inherent of previous mh
		if (dto.isPreviousMh()) {
			// flag as previously processed
			acq.setPreviousMh(true);
		}

		// if the dto is inherent of previous session
		if (dto.isPreviousSession()) {
			// flag as previously processed
			acq.setPreviousSession(true);
		}

	}

	/**
	 * Gets the extra left.
	 *
	 * @return the extraLeft
	 */
	public double getExtraLeft() {
		return this.extraLeft;
	}

	/**
	 * Sets the extra left.
	 *
	 * @param extraLeft the extraLeft to set
	 */
	public void setExtraLeft(double extraLeft) {
		this.extraLeft = extraLeft;
	}

	/**
	 * Gets the replaced request list id.
	 *
	 * @return the replacedRequestListId
	 */
	public List<String> getReplacedRequestListId() {
		return this.replacedRequestListId;
	}

	/**
	 * Sets the replaced request list id.
	 *
	 * @param replacedRequestListId the replacedRequestListId to set
	 */
	public void setReplacedRequestListId(List<String> replacedRequestListId) {
		this.replacedRequestListId = replacedRequestListId;
	}

	/**
	 * Gets the backup vis.
	 *
	 * @return the backup vis
	 */
	public List<String> getBackupVis() {
		return this.backupVis;
	}

	/**
	 * Sets the backup vis.
	 *
	 * @param backupVis the new backup vis
	 */
	public void setBackupVis(List<String> backupVis) {
		this.backupVis = backupVis;
	}

	/**
	 * Checks if is removes the ar id.
	 *
	 * @return true, if is removes the ar id
	 */
	public boolean isRemoveArId() {
		return this.removeArId;
	}

	/**
	 * Sets the removes the ar id.
	 *
	 * @param removeArId the new removes the ar id
	 */
	public void setRemoveArId(boolean removeArId) {
		this.removeArId = removeArId;
	}

	/**
	 * Adds the slave.
	 *
	 * @param slaveId the slave id
	 */
	public void addSlave(Partner slaveId) {
		
		//initialize to false
		boolean found = false;
		
		//iterate over the user info associated with the current acq
		for (int i = 0; i < this.userInfo.size(); i++) {
			if (this.userInfo.get(i).getOwnerId().equalsIgnoreCase(slaveId.getPartnerId())) {
				found = true;
			}
		}
		//if not found
		if (!found) {
			//create an userInfo for the slave 
			UserInfo userInfoSlave = new UserInfo(slaveId.getAllVisForPartner(), true, slaveId.getPartnerId(),
					slaveId.getUgsId());
			userInfoSlave.setSlave(true);
			this.userInfo.add(userInfoSlave);
		}
	}

}
