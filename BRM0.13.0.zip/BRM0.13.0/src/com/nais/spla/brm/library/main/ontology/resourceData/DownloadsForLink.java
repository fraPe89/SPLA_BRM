
/**
*
* MODULE FILE NAME:	DownloadsForLink.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		24 nov 2018
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 24 nov 2018          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.List;

import com.nais.spla.brm.library.main.ontology.tasks.Task;

// TODO: Auto-generated Javadoc
/**
 * The Class DownloadsForLink.
 *
 * @author fpedrola
 */
public class DownloadsForLink {

	/** The size. */
	private double size;

	/** The all dwl for link. */
	private List<Task> allDwlForLink = null;

	/**
	 * Instantiates a new downloads for link.
	 *
	 * @param size the size
	 * @param allDwlForLink the all dwl for link
	 */
	public DownloadsForLink(double size, List<Task> allDwlForLink) {
		super();
		this.size = size;
		this.allDwlForLink = allDwlForLink;
	}

	/**
	 * Gets the size.
	 *
	 * @return the size
	 */
	public double getSize() {
		return this.size;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DownloadsForLink [size=" + this.size + ", allDwlForLink=" + this.allDwlForLink + "]";
	}

}
