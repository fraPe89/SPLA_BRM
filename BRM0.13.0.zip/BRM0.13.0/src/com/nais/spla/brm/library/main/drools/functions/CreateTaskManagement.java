package com.nais.spla.brm.library.main.drools.functions;

import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;

// TODO: Auto-generated Javadoc
/**
 * The Class CreateTaskManagement.
 */
public class CreateTaskManagement {

	/**
	 * Creates the store aux.
	 *
	 * @param currentPaw the current paw
	 * @param enableFlag the enable flag
	 * @param currentPs  the current ps
	 * @return the store AUX
	 */
	public static StoreAUX createStoreAux(PAW currentPaw, boolean enableFlag, String currentPs) {

		// iitialize a storeAux
		StoreAUX gpsStoreSwitchOn = new StoreAUX(enableFlag, currentPs);

		// set the pawType
		gpsStoreSwitchOn.setPawType(currentPaw.getType());

		// set the task type
		gpsStoreSwitchOn.setTaskType(TaskType.STORE_AUX);

		// set the satellite id
		gpsStoreSwitchOn.setSatelliteId(currentPaw.getSatelliteId());

		// set the endTime
		gpsStoreSwitchOn.setEndTime(currentPaw.getStartTime());

		// if is a disable storeAux
		if (!enableFlag) {
			// set the start time
			gpsStoreSwitchOn.setStartTime(currentPaw.getStartTime());
			// set the end time
			gpsStoreSwitchOn.setEndTime(currentPaw.getStartTime());

		}
		// if is an enable storeAux
		else {
			// set the startTime
			gpsStoreSwitchOn.setStartTime(currentPaw.getEndTime());

			// set the stopTime
			gpsStoreSwitchOn.setEndTime(currentPaw.getEndTime());

		}
		return gpsStoreSwitchOn;
	}

}
