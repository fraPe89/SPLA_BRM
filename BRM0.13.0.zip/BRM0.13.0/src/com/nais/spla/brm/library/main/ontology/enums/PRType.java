/**
*
* MODULE FILE NAME:	PRType.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		27 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 27 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.enums;

/**
 * The Enum PRType.
 *
 * @author fpedrola
 */
public enum PRType {

	/** The hp. */
	HP,

	/** The civilian hp. */
	CIVILIAN_HP,

	/** The pp. */
	PP,

	/** The ranked routine. */
	RANKED_ROUTINE,

	/** The unranked routine. */
	UNRANKED_ROUTINE,

	/** The vu. */
	VU,

	/** The lmp. */
	LMP,

	/** The crisis. */
	CRISIS

}
