/**
 *
 * MODULE FILE NAME: ElementsInvolvedOnOrbit.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.utils;

import java.io.Serializable;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class ElementsInvolvedOnOrbit.
 */
@SuppressWarnings("serial")
public class ElementsInvolvedOnOrbit implements Serializable {

	/** The sliding window. */
	private int slidingWindow;

	/** The elements involved. */
	private List<String> elementsInvolved;

	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "ElementsInvolvedOnOrbit [onSlidingWindow=" + this.slidingWindow + ", elementsInvolved="
				+ this.elementsInvolved + "]";
	}

	/**
	 * Instantiates a new elements involved on orbit.
	 *
	 * @param slidingWindow    the sliding window
	 * @param elementsInvolved the elements involved
	 */
	public ElementsInvolvedOnOrbit(int slidingWindow, List<String> elementsInvolved) {
		super();

		// set the sliding window
		this.slidingWindow = slidingWindow;

		// set the elements involved
		this.elementsInvolved = elementsInvolved;
	}

	/**
	 * Instantiates a new elements involved on orbit.
	 */
	public ElementsInvolvedOnOrbit() {
		super();
	}

	/**
	 * Gets the elements involved.
	 *
	 * @return the elements involved
	 */
	public List<String> getElementsInvolved() {
		return this.elementsInvolved;
	}

	/**
	 * Sets the elements involved.
	 *
	 * @param elementsInvolved the new elements involved
	 */
	public void setElementsInvolved(List<String> elementsInvolved) {
		this.elementsInvolved = elementsInvolved;
	}

	/**
	 * Gets the sliding window.
	 *
	 * @return the sliding window
	 */
	public int getSlidingWindow() {
		return this.slidingWindow;
	}

	/**
	 * Sets the sliding window.
	 *
	 * @param slidingWindow the new sliding window
	 */
	public void setSlidingWindow(int slidingWindow) {
		this.slidingWindow = slidingWindow;
	}

}
