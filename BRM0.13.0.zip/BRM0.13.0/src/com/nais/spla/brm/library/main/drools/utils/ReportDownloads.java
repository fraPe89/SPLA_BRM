
package com.nais.spla.brm.library.main.drools.utils;

import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class ReportDownloads.
 */
public class ReportDownloads {

	/** The for acq. */
	private String forAcq = null;
	
	/** The sectors for partner. */
	private List<String> sectorsForPartner;

	/**
	 * Instantiates a 
	 * new report 
	 * downloads.
	 */
	public ReportDownloads() {
		super();
		//initialize the acq
		this.forAcq = null;
		this.sectorsForPartner = new ArrayList<>();
		this.setSectorsForPartner(sectorsForPartner);
	}

	/**
	 * Gets the for acq.
	 *
	 * @return the for acq
	 */
	public String getForAcq() {
		return this.forAcq;
	}

	/**
	 * Sets the for acq.
	 *
	 * @param forAcq the new for acq
	 */
	public void setForAcq(String forAcq) {
		this.forAcq = forAcq;
	}

	/**
	 * Gets the sectors for partner.
	 *
	 * @return the sectors for partner
	 */
	public List<String> getSectorsForPartner() {
		return this.sectorsForPartner;
	}

	/**
	 * Sets the sectors for partner.
	 *
	 * @param sectorsForPartner the new sectors for partner
	 */
	public void setSectorsForPartner(List<String> sectorsForPartner) {
		this.sectorsForPartner = sectorsForPartner;
	}

}
