/**
*
* MODULE FILE NAME: CMGAManeuverManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.CmgaResources;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

// TODO: Auto-generated Javadoc
/**
 * The Class CMGAManeuverManagement.
 */
public class CMGAManeuverManagement {

	/**
	 * Cmga algorithm.
	 *
	 * @param dateRes      the date res
	 * @param satelliteId  the satellite id
	 * @param previous     the previous
	 * @param current      the current
	 * @param droolsParams the drools params
	 * @return the maneuver
	 */
	public Maneuver tryWithCmgaMan(DateResource dateRes, String satelliteId, Acquisition previous, Acquisition current,
			DroolsParameters droolsParams) {
		// create a new maneuver
		Maneuver newManCmga = null;

		// get the time necessary to perform a maneuver of type cmga
		long timeForCmg = droolsParams.getTimeForManeuverCmga();

		// invoke the method for create a cmg maneuver
		newManCmga = createACmgManeuver(dateRes, previous, current, timeForCmg, droolsParams.getTranquillizationTime());

		// add the just created man to the maneuverResource
		// manRes.getNewMans().add(newManCmga);

		return newManCmga;
	}

	/**
	 * Check cmga formula.
	 *
	 * @param newMan            the new man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @return true, if successful
	 */
	public boolean checkCmgaFormula(Maneuver newMan, DroolsParameters droolsParams,
			ResourceFunctions resourceFunctions) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// set that the check is not passed as default
		boolean checked = false;

		// get the satellite properties relative to the satellite linked with
		// the man
		SatelliteProperties satProp = droolsParams.getSatWithId(newMan.getSatelliteId()).getSatelliteProperties();

		// get all the cmga rlative to the satellite just extracted
		List<CMGA> allCmgaForSatellite = droolsParams.getAllCMGAForSat(newMan.getSatelliteId());

		// compute max time tAcc (time for ramp)
		long timeTacc = (long) getMaxTimeTacc(allCmgaForSatellite);

		// get the treemap with all the man relative to the satellite
		TreeMap<Long, Maneuver> allManRelatedToSat = resourceFunctions
				.getManeuverFunctionAssociatedToSat(newMan.getSatelliteId());

		// get the treemap with all the ramps relative to the satellite
		TreeMap<Long, RampCMGA> allRampsRelatedToSat = resourceFunctions
				.getRampFunctionAssociatedToSat(newMan.getSatelliteId());

		// initialize the cont for the invalid cmg formula
		int contInvalidFormula = 0;

		// iterate over the cmg units for the satellite
		for (int i = 0; i < allCmgaForSatellite.size(); i++) {
			// if the i-esim cmg unit is operative
			if (allCmgaForSatellite.get(i).isOperative()) {
				// iterate over the orbit to check
				for (Map.Entry<Double, Double> orbitToCheck : allCmgaForSatellite.get(i).getAllPowersForOrbit()
						.entrySet()) {
					// extract the i-esim orbit
					double orbit = orbitToCheck.getKey();
					logger.debug("check on orbit : " + orbit);

					// compute the interval to check as milliseconds
					long interval = (long) (orbit * droolsParams.getMinutesForOrbit() * 60000);

					// set as start check the start of the man under test - half
					// interval computed above
					Date startIntToCheck = new Date(newMan.getStartTime().getTime() - (interval / 2));

					// set as end check the start of the man under test + half
					// interval computed above
					Date endIntToCheck = new Date(newMan.getStartTime().getTime() + (interval / 2));

					// NavigableMap<Long, Maneuver> onlyManInPeriodToCheck =
					// allManRelatedToSat.subMap(startIntToCheck.getTime(), true,
					// endIntToCheck.getTime(), true);

					logger.debug("start interval to check : " + startIntToCheck);
					logger.debug("end interval to check : " + endIntToCheck);

					// invoke the method to compute the resouces in interval
					CmgaResources cmgaRes = computeResourcesInInterval(timeTacc, allManRelatedToSat,
							allRampsRelatedToSat, startIntToCheck, endIntToCheck);

					List<CMGA> invalidCmga = checkCMGFormula(orbit, interval, allCmgaForSatellite, timeTacc, cmgaRes,
							satProp);
					logger.debug("invalid cmga " + invalidCmga);
					// contInvalidFormula = contInvalidFormula
					// +invalidCmga.size();
				}
			}
		}

		if (contInvalidFormula > 0) {
			checked = true;
		}
		return checked;
	}

	/**
	 * Find next or prev ramp.
	 *
	 * @param allRampsRelatedToSat the all ramps related to sat
	 * @param manTooClose          the man too close
	 * @param prevOrNext           the prev or next
	 * @param UpOrDown             the up or down
	 * @return the ramp CMGA
	 */
	public RampCMGA findNextOrPrevRamp(TreeMap<Long, RampCMGA> allRampsRelatedToSat, Maneuver manTooClose,
			String prevOrNext, String UpOrDown) {
		// initialize ramp as object
		Object rampObj = null;

		// initialize ramp
		RampCMGA rampDown = null;
		Long elementAsLong = 0l;

		// search a previous element as default
		boolean searchedPrevious = true;

		// search a rump up as default
		boolean searchedRampUp = true;

		// if we are searching next
		if (prevOrNext.equalsIgnoreCase("next")) {
			// set the boolean variable to false
			searchedPrevious = false;
		}

		// if the method was invoked for search a ramp down
		if (UpOrDown.equalsIgnoreCase("down")) {
			// set the boolean variable to false
			searchedRampUp = false;
		}

		// set as start of search the start time of the maneuver
		elementAsLong = manTooClose.getStartTime().getTime();

		do {
			// search for a next ramp as default
			rampObj = allRampsRelatedToSat.higherKey(elementAsLong);

			if (searchedPrevious) {
				// else search for a previous ramp
				rampObj = allRampsRelatedToSat.lowerKey(elementAsLong);
			}

			// if there is a valid result
			if (rampObj != null) {
				// initialize the ramp
				RampCMGA extractedRamp = null;

				if (searchedPrevious) {
					// extract the previous element
					extractedRamp = allRampsRelatedToSat.lowerEntry(elementAsLong).getValue();
				} else {
					extractedRamp = allRampsRelatedToSat.higherEntry(elementAsLong).getValue();
				}
				// f the previous element is of the searched type
				if (extractedRamp.isRampUp() == searchedRampUp) {
					// extract the element and exit
					rampDown = extractedRamp;
					break;
				} else {
					// continue to extract the next element
					elementAsLong = extractedRamp.getStartTime().getTime();
				}
			} else {
				// set the evariable to 0 for escape
				elementAsLong = 0l;
			}
		} while (elementAsLong > 0);
		return rampDown;
	}

	/**
	 * Find next or prev cmga man.
	 *
	 * @param allManRelatedToSat the all man related to sat
	 * @param currentMan         the current man
	 * @param prevOrNext         the prev or next
	 * @return the maneuver
	 */
	public Maneuver findNextOrPrevCmgaMan(TreeMap<Long, Maneuver> allManRelatedToSat, Maneuver currentMan,
			String prevOrNext) {
		Object manObj = null;
		Maneuver returnedMan = null;
		Long elementAsLong = 0l;

		boolean searchedPrevious = true; // search a previous element as default

		if (prevOrNext.equalsIgnoreCase("next")) {
			searchedPrevious = false;
		}

		elementAsLong = currentMan.getStartTime().getTime();

		do {
			// search for a next ramp as default
			manObj = allManRelatedToSat.higherKey(elementAsLong);

			if (searchedPrevious) {
				// else search for a previous ramp
				manObj = allManRelatedToSat.lowerKey(elementAsLong);
			}
			if (manObj != null) {
				Maneuver man = null;
				if (searchedPrevious) {
					// extract the previous element
					man = allManRelatedToSat.lowerEntry(elementAsLong).getValue();
				} else {
					man = allManRelatedToSat.higherEntry(elementAsLong).getValue();
				}
				// f the previous element is of the searched type
				if (man.getActuator().compareTo(Actuator.CMGA) == 0) {
					// extract the element and exit
					returnedMan = man;
					break;
				} else {
					// continue to extract the next element
					elementAsLong = man.getStartTime().getTime();
				}
			} else {
				// set the evariable to 0 for escape
				elementAsLong = 0l;
			}
		} while (elementAsLong > 0);
		return returnedMan;
	}

	/**
	 * Removes the or reduce rump.
	 *
	 * @param droolsParams  the drools params
	 * @param manToRemove   the man to remove
	 * @param localAllMan   the local all man
	 * @param localAllRumps the local all rumps
	 * @param manRes        the man res
	 * @param timeForRump   the time for rump
	 * @return the maneuver resources
	 */
	public ManeuverResources removeOrReduceRump(DroolsParameters droolsParams, Maneuver manToRemove,
			TreeMap<Long, Maneuver> localAllMan, TreeMap<Long, RampCMGA> localAllRumps, ManeuverResources manRes,
			double timeForRump) {
		RampCMGA previousRumpUp = null;
		RampCMGA nextRumpDown = null;

		// get the previous ramp key
		Object previousRumpKey = localAllRumps.lowerKey(manToRemove.getStartTime().getTime());

		// get the next ramp key
		Object nextRumpKey = localAllRumps.ceilingKey(manToRemove.getStartTime().getTime());

		long startCheck = droolsParams.getCurrentMH().getStart().getTime();
		long endCheck = droolsParams.getCurrentMH().getStop().getTime();

		List<Maneuver> manInInterval = new ArrayList<>();

		// if next ramp is not null
		// means that the ramp down
		// is adjacent to the
		// maneuver that needs to be
		// removed -> last of a train or
		// single plateau
		if (nextRumpKey != null) {
			nextRumpDown = localAllRumps.get(nextRumpKey);
			endCheck = nextRumpDown.getStartTime().getTime();

			// manInInterval = findAllCmgaInInterval(startCheck, endCheck,
			// localAllMan);

		}
		// if there is a ramp
		// up before the maneuver
		// that must be removed
		if (previousRumpKey != null) {
			previousRumpUp = localAllRumps.lowerEntry(manToRemove.getStartTime().getTime()).getValue();
			startCheck = (long) (previousRumpUp.getStartTime().getTime() + timeForRump);
		}

		manInInterval = findAllCmgaInInterval(startCheck, endCheck, localAllMan);

		if (previousRumpUp != null) {
			manInInterval.remove(manToRemove);
			if (manInInterval.size() == 0) {
				manRes.getOldRumps().add(previousRumpUp);
				localAllRumps.remove(previousRumpUp.getStartTime().getTime());

				if (nextRumpDown != null) {
					manRes.getOldRumps().add(nextRumpDown);
					localAllRumps.remove(nextRumpDown.getStartTime().getTime());
				}

				manRes.setPossible(true);
			} else {
				manInInterval = findAllCmgaInInterval(previousRumpUp.getStartTime().getTime(),
						manToRemove.getStartTime().getTime(), localAllMan);
				manInInterval.remove(manToRemove);

				if (manInInterval.size() > 0) {
					// cannot remove the rump up, it needs to another cmg
					manInInterval = findAllCmgaInInterval(manToRemove.getStartTime().getTime(),
							nextRumpDown.getStartTime().getTime(), localAllMan);
					manInInterval.remove(manToRemove);
					if (manInInterval.size() >= 1) {
						// cannot remove the down up, it needs to another cmg
						System.out.println("nothing to do");
					} else {
						System.out.println("remove ramp down");
						manRes.getOldRumps().add(nextRumpDown);
						localAllRumps.remove(nextRumpDown.getStartTime().getTime());

						Maneuver prevMan = findNextOrPrevCmgaMan(localAllMan, manToRemove, "prev");
						System.out.println("found maneuver : " + prevMan);
						Date updatedRumpDownEnd = new Date(
								prevMan.getEndTime().getTime() + ((long) timeForRump * 1000));
						RampCMGA updatedRumpDown = new RampCMGA(prevMan.getIdTask(), prevMan.getEndTime(),
								updatedRumpDownEnd, false, manToRemove.getSatelliteId());
						localAllRumps.put(updatedRumpDown.getStartTime().getTime(), updatedRumpDown);
						manRes.getNewRumps().add(updatedRumpDown);

						manRes.setPossible(true);
					}
				} else {
					// remove ramp up ->replan
					manRes.getOldRumps().add(previousRumpUp);
					localAllRumps.remove(previousRumpUp.getStartTime().getTime());

					// remove previous ramp
					manRes.getOldRumps().add(previousRumpUp);
					localAllRumps.remove(previousRumpUp.getStartTime().getTime());

					// find next man involved in the same plateau
					Maneuver nextMan = findNextOrPrevCmgaMan(localAllMan, manToRemove, "next");
					// System.out.println("found maneuver : " + nextMan);
					Date updatedStartTimeForRumpUp = new Date(
							nextMan.getStartTime().getTime() - ((long) timeForRump * 1000));
					Date updatedStopTimeForRumpUp = new Date(
							updatedStartTimeForRumpUp.getTime() + ((long) timeForRump * 1000));

					RampCMGA updatedRumpUp = new RampCMGA(nextMan.getIdTask(), updatedStartTimeForRumpUp,
							updatedStopTimeForRumpUp, true, manToRemove.getSatelliteId());
					// System.out.println("updated start time for rump up :
					// " + updatedRumpUp);
					localAllRumps.put(updatedRumpUp.getStartTime().getTime(), updatedRumpUp);
					manRes.getNewRumps().add(updatedRumpUp);

					// check for ramp down
					manInInterval = findAllCmgaInInterval(manToRemove.getStartTime().getTime(),
							nextRumpDown.getStartTime().getTime(), localAllMan);
					manInInterval.remove(manToRemove);
					if (manInInterval.size() > 0) {
						// cannot remove the down up, it needs to another cmg

					} else {
						manRes.getOldRumps().add(nextRumpDown);
						localAllRumps.remove(nextRumpDown.getStartTime().getTime());

						Maneuver prevMan = findNextOrPrevCmgaMan(localAllMan, manToRemove, "prev");
						System.out.println("found maneuver : " + prevMan);
						Date updatedRumpDownEnd = new Date(
								prevMan.getEndTime().getTime() + ((long) timeForRump * 1000));
						RampCMGA updatedRumpDown = new RampCMGA(prevMan.getIdTask(), prevMan.getEndTime(),
								updatedRumpDownEnd, false, manToRemove.getSatelliteId());
						localAllRumps.put(updatedRumpDown.getStartTime().getTime(), updatedRumpDown);
						manRes.getNewRumps().add(updatedRumpDown);

						manRes.setPossible(true);
					}
				}

			}

		}
		return manRes;
	}

	/**
	 * Find all cmga in interval.
	 *
	 * @param startCheck  the start check
	 * @param endCheck    the end check
	 * @param localAllMan the local all man
	 * @return the list
	 */
	private List<Maneuver> findAllCmgaInInterval(long startCheck, long endCheck, TreeMap<Long, Maneuver> localAllMan) {
		SortedMap<Long, Maneuver> allManInInterval = localAllMan.subMap(startCheck, endCheck);

		List<Maneuver> allMan = new ArrayList<>();
		for (Map.Entry<Long, Maneuver> subElement : allManInInterval.entrySet()) {
			if (subElement.getValue().getActuator().equals(Actuator.CMGA)) {
				allMan.add(subElement.getValue());
			}
		}
		return allMan;
	}

	/**
	 * Creates the ramp up or down.
	 *
	 * @param droolsParams the drools params
	 * @param newMan       the new man
	 * @param timeForRamp  the time for ramp
	 * @param isUp         the is up
	 * @return the ramp CMGA
	 */
	public RampCMGA createRampUpOrDown(DroolsParameters droolsParams, Maneuver newMan, long timeForRamp, boolean isUp) {
		long waitTimeRampCmg = (long) droolsParams.getSatWithId(newMan.getSatelliteId()).getSatelliteProperties()
				.getWaitTimeBetweenRampAndCmg();

		RampCMGA newRamp = null;
		if (isUp) {
			long endTimeAsLong = newMan.getStartTime().getTime() - (waitTimeRampCmg * 1000);
			Date endRampUp = new Date(endTimeAsLong);
			Date startRampUp = new Date(endRampUp.getTime() - (timeForRamp * 1000));
			newRamp = new RampCMGA(newMan.getIdTask() + "Up", startRampUp, endRampUp, true, newMan.getSatelliteId());
		} else {
			long startTimeAsLong = newMan.getEndTime().getTime() + (waitTimeRampCmg * 1000);
			Date startRampDown = new Date(startTimeAsLong);
			Date endRampDown = new Date(startRampDown.getTime() + (timeForRamp * 1000));
			newRamp = new RampCMGA(newMan.getIdTask() + "Down", startRampDown, endRampDown, false,
					newMan.getSatelliteId());
		}
		return newRamp;
	}

	/**
	 * Creates the ramps.
	 *
	 * @param man               the man
	 * @param droolsParams      the drools params
	 * @param resourceFunctions the resource functions
	 * @param sessionId         the session id
	 * @param sessionInstance   the session instance
	 */
	@SuppressWarnings("unchecked")
	public void createRamps(Maneuver man, DroolsParameters droolsParams, ResourceFunctions resourceFunctions,
			String sessionId, int sessionInstance) {
		Logger logger = DroolsParameters.getLogger();
		logger.info("INSERT_CMGA_RULE : " + man);

		// logger.debug("INSERT_CMGA_RULE : create ramp for man cmga " + man);

		// get the treemap structure for all the ramps associated with the
		// current satellite
		TreeMap<Long, RampCMGA> allRamps = resourceFunctions.getRampFunctionAssociatedToSat(man.getSatelliteId());
		TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(man.getSatelliteId());
		String sessionIdConcat = DroolsParameters.concatenateSession(sessionId, sessionInstance);

		KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);

		HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");

		// insert the new maneuver into the treemap
		allMan.put(man.getStartTime().getTime(), man);

		// declare two new object of type RampCmga (up and down) for the new
		// maneuver
		RampCMGA newRampUp = null;
		RampCMGA newRampDown = null;

		// get the previous ramp object
		Object previousRampObj = allRamps.lowerKey(man.getStartTime().getTime());

		// get the next ramp object
		Object nextRampObj = allRamps.higherKey(man.getStartTime().getTime());

		// get the max ramp up/down time of all the cmg active units
		long timeTacc = (long) getMaxTimeTacc(droolsParams.getAllCMGAForSat(man.getSatelliteId()));

		// if exist both previous and next ramps
		if ((previousRampObj != null) && (nextRampObj != null)) {
			// extract the previous ramp
			RampCMGA prevRamp = allRamps.lowerEntry(man.getStartTime().getTime()).getValue();

			// compute the gap between the man and the previous ramp
			long gapWithPrev = (man.getStartTime().getTime() - prevRamp.getEndTime().getTime()) / 1000;

			// extract the next ramp
			RampCMGA nextRamp = allRamps.higherEntry(man.getStartTime().getTime()).getValue();

			// compute the gap between the man and the next ramp
			long gapWithNext = (nextRamp.getEndTime().getTime() - man.getEndTime().getTime()) / 1000;

			// logger.debug("INSERT_CMGA_RULE : there is a previous ramp " +
			// prevRamp);
			// logger.debug("INSERT_CMGA_RULE : there is a next ramp " +
			// nextRamp);

			// if the previous ramp is a ramp down
			if (prevRamp.isRampUp() == false) {

				// if both gaps are not enough to come back in normal asset ->
				// remove ramps and stay in plateau -> merge all
				if ((gapWithPrev < (timeTacc * 2)) && (gapWithNext < (timeTacc * 2))) {
					FactHandle prevRampFH = kie.getFactHandle(prevRamp);
					FactHandle nextRampFH = kie.getFactHandle(nextRamp);

					// remove previous ramp
					allRamps.remove(prevRamp.getStartTime().getTime());

					// remove next ramp
					allRamps.remove(nextRamp.getStartTime().getTime());

					kie.delete(prevRampFH);
					kie.delete(nextRampFH);

				}
				// if only the gap with prev is not enough -> remove only first
				// previous ramp
				else if (gapWithPrev < (timeTacc * 2)) {
					// create only the ramp down
					newRampDown = createRampUpOrDown(droolsParams, man, timeTacc, false);

					// insert the new ramp into the treemap
					allRamps.put(newRampDown.getStartTime().getTime(), newRampDown);

					// insert the new ramp in Drools
					kie.insert(newRampDown);

					// remove previous ramp down
					allRamps.remove(prevRamp.getStartTime().getTime());

					FactHandle prevRampFH = kie.getFactHandle(prevRamp);

					kie.delete(prevRampFH);

				}
				// if only the gap with next is not enough -> remove only next
				// ramp
				else if (gapWithNext < (timeTacc * 2)) {
					// create only the ramp up
					newRampUp = createRampUpOrDown(droolsParams, man, timeTacc, true);

					// insert the new ramp into the treemap
					allRamps.put(newRampUp.getStartTime().getTime(), newRampUp);

					// insert the new ramp in Drools
					kie.insert(newRampUp);

					// remove previous ramp up
					allRamps.remove(nextRamp.getStartTime().getTime());

					FactHandle nextRampFH = kie.getFactHandle(nextRamp);

					kie.delete(nextRampFH);
				}
				// if both gap are enough -> come back to normal asset
				else {
					// create a new ramp up
					newRampUp = createRampUpOrDown(droolsParams, man, timeTacc, true);

					// create a new ramp down
					newRampDown = createRampUpOrDown(droolsParams, man, timeTacc, false);

					// insert the new ramp up into the treemap
					allRamps.put(newRampUp.getStartTime().getTime(), newRampUp);

					// insert the new ramp down into the treemap
					allRamps.put(newRampDown.getStartTime().getTime(), newRampDown);

					// insert the new ramps in Drools
					kie.insert(newRampUp);
					kie.insert(newRampDown);
				}
			}
		}

		// there is only a previous ramp
		else if (previousRampObj != null) {
			// get the previous ramp
			RampCMGA prevRamp = allRamps.lowerEntry(man.getStartTime().getTime()).getValue();

			// logger.debug("INSERT_CMGA_RULE : there is only a previous ramp "
			// + prevRamp);

			// compute the gap between the man and the previous ramp
			long gapWithPrev = (man.getStartTime().getTime() - prevRamp.getEndTime().getTime()) / 1000;

			// if the previous ramp is a ramp down
			if (prevRamp.isRampUp() == false) // prev ramp is down
			{
				// if the gap is not enough
				if ((prevRamp.getEndTime().getTime() > man.getStartTime().getTime())
						|| (gapWithPrev < (timeTacc * 2))) {
					// remove previous ramp
					allRamps.remove(prevRamp.getStartTime().getTime());

					FactHandle prevRampFH = kie.getFactHandle(prevRamp);

					kie.delete(prevRampFH);

					// create a new ramp down
					newRampDown = createRampUpOrDown(droolsParams, man, timeTacc, false);

					// insert the new ramp down into the treemap
					allRamps.put(newRampDown.getStartTime().getTime(), newRampDown);

					// insert the new ramp in Drools
					kie.insert(newRampDown);
				}
			}

			// if the gap is enough
			if (gapWithPrev > (timeTacc * 2)) {
				// create a new ramp up
				newRampUp = createRampUpOrDown(droolsParams, man, timeTacc, true);

				// create a new ramp down
				newRampDown = createRampUpOrDown(droolsParams, man, timeTacc, false);

				// insert the new ramps down into the treemap
				allRamps.put(newRampUp.getStartTime().getTime(), newRampUp);
				allRamps.put(newRampDown.getStartTime().getTime(), newRampDown);

				// insert the new ramps in Drools
				kie.insert(newRampUp);
				kie.insert(newRampDown);
			}
		}

		// there is only a next ramp
		else if (nextRampObj != null) {
			// get the next ramp
			RampCMGA nextRampDown = allRamps.higherEntry(man.getStartTime().getTime()).getValue();

			// logger.debug("INSERT_CMGA_RULE : there is only a next ramp " +
			// nextRampDown);

			// compute the gap between the man and the next ramp
			long gapWithNext = (nextRampDown.getStartTime().getTime() - man.getStartTime().getTime()) / 1000;

			// if the next ramp is a ramp up
			if (nextRampDown.isRampUp() == true) {
				// if the gap is not enough
				if ((nextRampDown.getStartTime().getTime() < man.getEndTime().getTime())
						|| (gapWithNext < (timeTacc * 2))) {
					// create a new ramp up
					newRampUp = createRampUpOrDown(droolsParams, man, timeTacc, true);

					// remove next ramp
					allRamps.remove(nextRampDown.getStartTime().getTime());

					FactHandle prevRampFH = kie.getFactHandle(nextRampDown);

					kie.delete(prevRampFH);
					// insert the new ramp down into the treemap
					allRamps.put(newRampUp.getStartTime().getTime(), newRampUp);
					kie.insert(newRampUp);
				}

				// if the gap is enough
				else {
					// create a new ramp up
					newRampUp = createRampUpOrDown(droolsParams, man, timeTacc, true);

					// create a new ramp down
					newRampDown = createRampUpOrDown(droolsParams, man, timeTacc, false);

					// insert the new ramps down into the treemap
					allRamps.put(newRampUp.getStartTime().getTime(), newRampUp);
					allRamps.put(newRampDown.getStartTime().getTime(), newRampDown);

					// insert the new ramps in Drools
					kie.insert(newRampUp);
					kie.insert(newRampDown);
				}
			}
		}
		// there aren't previous and next ramp
		else {
			// logger.debug("INSERT_CMGA_RULE : there aren't previous and next
			// ramps ");

			// create a new ramp up
			newRampUp = createRampUpOrDown(droolsParams, man, timeTacc, true);

			// create a new ramp down
			newRampDown = createRampUpOrDown(droolsParams, man, timeTacc, false);

			// insert the new ramps down into the treemap
			allRamps.put(newRampUp.getStartTime().getTime(), newRampUp);
			allRamps.put(newRampDown.getStartTime().getTime(), newRampDown);

			// insert the new ramps in Drools
			kie.insert(newRampUp);
			kie.insert(newRampDown);
		}

		// check if the cmg formula is violated for at least one of the active
		// cmg units
		boolean overheadCmgaFormula = checkCmgaFormula(man, droolsParams, resourceFunctions);

		// if is violated
		if (overheadCmgaFormula) {
			// get the last acq inserted into the Drools engine
			Acquisition potential = DroolsParameters.getLastAcq();
			FactHandle potentialFH = kie.getFactHandle(potential);

			// mark as rejected
			potential.setRejected(true);

			// add the reason of reject
			potential.addReasonOfReject(35, ReasonOfReject.CMGFormulaViolation,
					"Control Momentum Gyro Assembly Formula Violation", 0, 0, null);

			// add it to the map of rejected elements
			rejected.put(potential.getId(), potential);

			// logger.debug("INSERT_CMGA_RULE : reject last acquisition " +
			// potential);

			// update so Drools react to the changes
			kie.update(potentialFH, potential);
		}

		// if the formula is valid
		else {
			// logger.debug("INSERT_CMGA_RULE : check passed");
			// logger.debug("check on cmga passed");
		}
	}

	/**
	 * Method description : this method allows to create a cmg maneuver. If the
	 * previous acquisition is on the left, in order to minimize the time in which
	 * the satellite remains on the left, the maneuver will be placed immediately at
	 * the end of this acquisition. Otherwise, if the previous acquisition is on the
	 * right, the maneuver will be placed immediately before the next acquisition.
	 *
	 * Method parameters :
	 *
	 * @param dateRes              the date res
	 * @param previous             the previous
	 * @param next                 the next
	 * @param timeForCmg           the time for cmg
	 * @param tranquillizationTime the tranquillization time
	 * @return a new Cmga maneuver
	 */
	public Maneuver createACmgManeuver(DateResource dateRes, Acquisition previous, Acquisition next, long timeForCmg,
			double tranquillizationTime) {
		Maneuver newCmgManeuver = null;
		String satelliteId = null;
		Date startMan = null;
		Date endMan = null;
		String idPrevious = "x";
		String idNext = "x";
		boolean lookSide = false;
		if ((previous != null) && (next != null)) {

			satelliteId = previous.getSatelliteId();
			if (next.getLookSide().equalsIgnoreCase("left")) {
				lookSide = true;
			}

			idPrevious = previous.getIdTask();
			idNext = next.getIdTask();
		} else if (previous == null) {
			/*
			 * this case is verified when the cmga maneuver is needed at starts, because the
			 * initial lookside of the satellite is opposite to the loookside of the first
			 * acquisition performed
			 */
			if (next.getLookSide().equalsIgnoreCase("left")) {
				lookSide = true;
			}
			satelliteId = next.getSatelliteId();
			idNext = next.getIdTask();
		}
		// if only next == null
		else { /*
				 * this case is verified when the cmga maneuver is needed as contermaneuver (to
				 * bring back to normal side (right) the satellite
				 */
			satelliteId = previous.getSatelliteId();
			idPrevious = previous.getIdTask();
		}

		if (lookSide) {
			endMan = new Date((dateRes.getStop().getTime()));
			startMan = new Date(endMan.getTime() - (timeForCmg * 1000));
		} else {
			startMan = dateRes.getStart();
			endMan = new Date(startMan.getTime() + (timeForCmg * 1000));
		}

		newCmgManeuver = new Maneuver(idPrevious, idNext, startMan, endMan, satelliteId);
		newCmgManeuver.setIdTask(idPrevious + "_" + idNext);
		newCmgManeuver.setActuator(Actuator.CMGA);
		newCmgManeuver.setRightToLeftFlag(lookSide);
		return newCmgManeuver;
	}

	/**
	 * Find if there are maneuver too close.
	 *
	 * @param newMan             the new man
	 * @param allManRelatedToSat the all man related to sat
	 * @param allRamps           the all ramps
	 * @param tAcc               the t acc
	 * @return the list
	 */
	protected List<Maneuver> findIfThereAreManeuverTooClose(Maneuver newMan, TreeMap<Long, Maneuver> allManRelatedToSat,
			TreeMap<Long, RampCMGA> allRamps, double tAcc) {
		List<Maneuver> nearestMan = new ArrayList<>();
		double minTimeToMergeAcq = tAcc * 2;
		long minGap = (long) ((minTimeToMergeAcq * 1000)
				+ (newMan.getEndTime().getTime() - newMan.getStartTime().getTime()));
		// System.out.println("min gap is : " + (minGap / 1000) + " seconds = "
		// +
		// (minGap / (1000 * 60)) + " minutes");
		// System.out.println("gap in minutes : " + (minGap / 1000));

		Maneuver nextCmgaMan = findNextOrPrevCmgaMan(allManRelatedToSat, newMan, "next");
		Maneuver prevCmgaMan = findNextOrPrevCmgaMan(allManRelatedToSat, newMan, "previous");

		if (nextCmgaMan != null) {
			long gapwWithNext = nextCmgaMan.getStartTime().getTime() - newMan.getEndTime().getTime();
			// System.out.println("next man : " + nextCmgaMan);
			// System.out.println("gap with next :" + gapwWithNext);
			if (gapwWithNext < minGap) {
				nearestMan.add(nextCmgaMan);
			}
		}

		if (prevCmgaMan != null) {
			long gapwWitPrev = newMan.getStartTime().getTime() - prevCmgaMan.getEndTime().getTime();
			// System.out.println("gap with prev :" + gapwWitPrev);
			if (gapwWitPrev < minGap) {
				nearestMan.add(prevCmgaMan);
			}
		}
		return nearestMan;
	}

	/**
	 * Check CMG formula.
	 *
	 * @param orbit               the orbit
	 * @param interval            the interval
	 * @param allCMGAForSatellite the all CMGA for satellite
	 * @param tAcc                the t acc
	 * @param cmgRes              the cmg res
	 * @param satProp             the sat prop
	 * @return the list
	 */
	protected List<CMGA> checkCMGFormula(double orbit, long interval, List<CMGA> allCMGAForSatellite, double tAcc,
			CmgaResources cmgRes, SatelliteProperties satProp) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get all the check that must be performed for the current satellite
		Map<Double, ResourceMaxValue> allChecks = satProp.getAllChecksOnOrbits();

		// create a list of cmga where will be put all the cmg unit that cannot
		// satisfy the formula
		List<CMGA> invalidCMGAUnit = new ArrayList<>();

		// variable to track the total power energy consumed with the current
		// cmga
		double totalCMGPower = 0;

		// iterate over the cmga unit
		for (int i = 0; i < allCMGAForSatellite.size(); i++) {
			// extract the i-esim cmg unit
			CMGA currentCmga = allCMGAForSatellite.get(i);

			// process all and only cmg units that are operative (2 on 3)
			if (currentCmga.isOperative()) {
				// logger.debug("CHECK CMG : " + currentCmga);

				// connt to
				int countOfViolatedFormula = 0;
				// logger.debug("on orbit : " + orbit);
				for (Map.Entry<Double, ResourceMaxValue> orbitToCheck : allChecks.entrySet()) {
					// System.out.println("orbit to check ; " + orbitToCheck);
					double maxPowerForCmg = allCMGAForSatellite.get(i).getAllPowersForOrbit()
							.get(orbitToCheck.getKey());
					logger.trace("for sat : " + allCMGAForSatellite.get(i).getCmgaId());
					logger.trace("on orbit : " + orbitToCheck.getKey());
					logger.trace("max power :  " + maxPowerForCmg);

					if (maxPowerForCmg > 0) {
						totalCMGPower = ((currentCmga.getwAcc() * tAcc) + (currentCmga.getwPlat() * cmgRes.gettPlat())
								+ (currentCmga.getwRest() * (interval - cmgRes.gettPlat() - (cmgRes.getTRamp()))))
								/ interval;
						logger.trace("final formula : " + totalCMGPower);
						if (totalCMGPower > maxPowerForCmg) {
							countOfViolatedFormula++;
							logger.trace("**CMG_FORMULA**limit reached : formula is invalid ");
						}
					}
					if (countOfViolatedFormula > 0) {
						invalidCMGAUnit.add(currentCmga);
						logger.trace("**CMG_FORMULA**invalid cmga is added to list :" + currentCmga);
					}
				}
			}
		}
		return invalidCMGAUnit;
	}

	/**
	 * Removes the CMGA.
	 *
	 * @param manToRemove         the man to remove
	 * @param resourceFunctions   the resource functions
	 * @param allCmgaForSatellite the all cmga for satellite
	 * @param tAccCmg             the t acc cmg
	 */
	protected void removeCMGA(Maneuver manToRemove, ResourceFunctions resourceFunctions, List<CMGA> allCmgaForSatellite,
			double tAccCmg) {
		double timeTacc = getMaxTimeTacc(allCmgaForSatellite);
		String satelliteId = manToRemove.getSatelliteId();
		long maxTimeAllowed = (long) (getMaxTimeTacc(allCmgaForSatellite) - 1);
		Maneuver nextMan = null;
		Maneuver previousMan = null;

		TreeMap<Long, RampCMGA> allRamps = resourceFunctions.getRampFunctionAssociatedToSat(satelliteId);
		TreeMap<Long, Maneuver> allManRelatedToSat = resourceFunctions.getManeuverFunctionAssociatedToSat(satelliteId);

		// System.out.println("man to remove : " + manToRemove);
		RampCMGA previousRampUp = allRamps.lowerEntry(manToRemove.getStartTime().getTime() + 1).getValue();
		// System.out.println("previous Ramp : " + previousRampUp);
		RampCMGA nextRampDown = allRamps.higherEntry(manToRemove.getEndTime().getTime() - 1).getValue();
		// System.out.println("following Ramp : " + nextRampDown);

		long gapBetweenMAnAndRampUp = (long) (manToRemove.getStartTime().getTime()
				- (previousRampUp.getStartTime().getTime() + (timeTacc * 1000)));
		long gapBetweenMAnAndRampDown = nextRampDown.getStartTime().getTime() - manToRemove.getEndTime().getTime();
		if ((gapBetweenMAnAndRampUp <= maxTimeAllowed) && (gapBetweenMAnAndRampDown <= maxTimeAllowed)) {
			// if previous Ramp and next Ramp are related to the current
			// maneuver that must be deleted -> delete also the Ramps
			allRamps.remove(previousRampUp.getStartTime().getTime());
			// System.out.println("removing Ramp up ");
			allRamps.remove(nextRampDown.getStartTime().getTime());
			// System.out.println("removing Ramp down ");
			allManRelatedToSat.remove(manToRemove.getStartTime().getTime());
		} else if (gapBetweenMAnAndRampUp <= maxTimeAllowed) {

			// if only the Ramp up is near the maneuver that must be deleted
			// that means that the maneuver was the first of a train of cmga ->
			// shift Ramp up after the maneuver and let it ends when the next
			// maneuver in the same plateau starts
			allRamps.remove(previousRampUp.getStartTime().getTime());
			// System.out.println("removing Ramp up ");
			nextMan = allManRelatedToSat.higherEntry(manToRemove.getEndTime().getTime()).getValue();
			// System.out.println("next man extracted from function : " +
			// nextMan);
			long newStartTimeOfRampUp = (long) (nextMan.getStartTime().getTime() - (tAccCmg * 1000));
			// System.out.println("Ramp up start time is shifted next till the
			// start of next
			// maneuver "
			// + new Date(newStartTimeOfRampUp));
			previousRampUp.setStartTime(new Date(newStartTimeOfRampUp));
			// System.out.println("inserting the new Ramp up into the Ramp
			// function ");
			allRamps.put(previousRampUp.getStartTime().getTime(), previousRampUp);
		} else // if only the gapBetweenMAnAndRampDown is <= maxTimeAllowed
		{
			/*
			 * if only the Ramp down is near the maneuver that must be deleted that means
			 * that the maneuver was the last of a train of cmga -> shift Ramp down before
			 * the maneuver, till the end of the previous man cmga in the same plateau
			 */
			allRamps.remove(nextRampDown.getStartTime().getTime());
			previousMan = allManRelatedToSat.lowerEntry(manToRemove.getStartTime().getTime()).getValue();
			long newStartTimeOfRampDown = previousMan.getEndTime().getTime();
			// System.out.println("Ramp down start time is shifted back till the
			// end of the
			// previous maneuver : "
			// + new Date(newStartTimeOfRampDown));
			nextRampDown.setStartTime(new Date(newStartTimeOfRampDown));
			allRamps.put(nextRampDown.getStartTime().getTime(), nextRampDown);
		}
		// else
		// {
		/*
		 * if the maneuver that must be cancelled is not close to both Ramp up and down,
		 * this means that it is in the middle of a train of cmga -> don't need to
		 * delete any Ramp. //if the maneuver is in the middle of a train of maneuver //
		 * cmga try to split the residual cmg into two separated cmg , if // the formula
		 * is less than if it stay in a single cmga
		 */
		// tryToSplitInTwoDifferentCmg(previousMan, nextMan, tAccCmg, allRamps);
		// }
		// System.out.println("removing the man :" + manToRemove);
		allManRelatedToSat.remove(manToRemove.getStartTime().getTime());
	}

	/**
	 * Try to split in two different cmg.
	 *
	 * @param previousMan the previous man
	 * @param nextMan     the next man
	 * @param tAccCmg     the t acc cmg
	 * @param allRamps    the all ramps
	 */
	protected void tryToSplitInTwoDifferentCmg(Maneuver previousMan, Maneuver nextMan, double tAccCmg,
			TreeMap<Long, RampCMGA> allRamps) {
		long gap = (nextMan.getStartTime().getTime() - previousMan.getEndTime().getTime()) / 1000;
		long timeForRamp = (long) (tAccCmg * 1000);
		if (gap > (tAccCmg * 2)) {
			// spit the single plateau in two separated plateau
			// System.out.println("divide the plateau in two separated
			// plateau");
			Date newRumpDownForPreviousManEnd = new Date(previousMan.getEndTime().getTime() + timeForRamp);
			RampCMGA newRumpDownForPreviousMan = new RampCMGA(previousMan.getIdTask(), previousMan.getEndTime(),
					newRumpDownForPreviousManEnd, false, previousMan.getSatelliteId());

			Date newRampUpStart = new Date(nextMan.getStartTime().getTime() - timeForRamp);
			Date newRampUpEnd = nextMan.getStartTime();
			RampCMGA newRumpUpForNextMan = new RampCMGA(nextMan.getIdTask(), newRampUpStart, newRampUpEnd, true,
					nextMan.getSatelliteId());

			allRamps.put(newRumpDownForPreviousMan.getStartTime().getTime(), newRumpDownForPreviousMan);
			allRamps.put(newRumpUpForNextMan.getStartTime().getTime(), newRumpUpForNextMan);
		}
	}

	/**
	 * Gets the max time tacc.
	 *
	 * @param allCmgaForSatellite the all cmga for satellite
	 * @return the max time tacc
	 */
	public double getMaxTimeTacc(List<CMGA> allCmgaForSatellite) {
		double timeTacc = -1;
		for (int i = 0; i < allCmgaForSatellite.size(); i++) {
			if (allCmgaForSatellite.get(i).gettAcc() > timeTacc) {
				if (allCmgaForSatellite.get(i).isOperative()) {
					timeTacc = allCmgaForSatellite.get(i).gettAcc();
				}
			}
		}
		return timeTacc;
	}

	/**
	 * Gets the all man of type.
	 *
	 * @param allMan           the all man
	 * @param startIntToCheck  the start int to check
	 * @param endIntToCheck    the end int to check
	 * @param actuatorToSelect the actuator to select
	 * @return the all man of type
	 */
	private List<Maneuver> getAllManOfType(TreeMap<Long, Maneuver> allMan, Date startIntToCheck, Date endIntToCheck,
			Actuator actuatorToSelect) {
		List<Maneuver> allManOfSelectedType = new ArrayList<>();
		NavigableMap<Long, Maneuver> onlyManInPeriodToCheck = allMan.subMap(startIntToCheck.getTime(), true,
				endIntToCheck.getTime(), true);
		for (Map.Entry<Long, Maneuver> allManInSubMap : onlyManInPeriodToCheck.entrySet()) {
			if (allManInSubMap.getValue().getActuator().compareTo(actuatorToSelect) == 0) {
				allManOfSelectedType.add(allManInSubMap.getValue());
			}
		}
		return allManOfSelectedType;
	}

	/**
	 * Compute resources in interval.
	 *
	 * @param tAcc            the t acc
	 * @param allMan          the all man
	 * @param allRamps        the all ramps
	 * @param startIntToCheck the start int to check
	 * @param endIntToCheck   the end int to check
	 * @return the cmga resources
	 */
	protected CmgaResources computeResourcesInInterval(double tAcc, TreeMap<Long, Maneuver> allMan,
			TreeMap<Long, RampCMGA> allRamps, Date startIntToCheck, Date endIntToCheck) {
		CmgaResources cmgRes = new CmgaResources();
		long singleTimeForRamp = (new Double(tAcc).longValue());
		double tRamp = 0;
		double tPlat = 0;
		double tRest = 0;

		// extract only the Ramps included in interval
		NavigableMap<Long, RampCMGA> onlyRampsInPeriodToCheck = allRamps.subMap(startIntToCheck.getTime(), true,
				endIntToCheck.getTime(), true);

		List<Maneuver> onlyManCmga = getAllManOfType(allMan, startIntToCheck, endIntToCheck, Actuator.CMGA);

		List<Task> allManCmgAndRamps = new ArrayList<>();

		for (Map.Entry<Long, RampCMGA> allRampInSubMap : onlyRampsInPeriodToCheck.entrySet()) {
			allManCmgAndRamps.add(allRampInSubMap.getValue());
		}
		allManCmgAndRamps.addAll(onlyManCmga);
		DownloadUtils.sortTasksByStartTime(allManCmgAndRamps);

		long startCheck = startIntToCheck.getTime();
		long endCheck = endIntToCheck.getTime();
		long gapWithPrevEl = 0;

		for (int i = 0; i < allManCmgAndRamps.size(); i++) {
			Task current = allManCmgAndRamps.get(i);
			System.out.println(current);
			if (current instanceof Maneuver) {
				Maneuver currentMan = (Maneuver) current;
				// System.out.println("start of man : " +
				// currentMan.getStartTime());

				gapWithPrevEl = currentMan.getStartTime().getTime() - startCheck;

				Object previousRampObject = onlyRampsInPeriodToCheck.lowerKey(currentMan.getStartTime().getTime());
				if (previousRampObject != null) {
					RampCMGA prevRamp = onlyRampsInPeriodToCheck.lowerEntry(currentMan.getStartTime().getTime())
							.getValue();
					// if there aren't other man cmga in the interval
					// between the previous ramp and the man
					if (allMan
							.subMap(prevRamp.getStartTime().getTime(), true, currentMan.getStartTime().getTime(), false)
							.isEmpty()) {
						tRamp = tRamp + (singleTimeForRamp * 1000);
						// System.out.println("partial tRamp : " + (tRamp /
						// 60000));

						startCheck = prevRamp.getStartTime().getTime() + (singleTimeForRamp * 1000);
					}
				} else {
					tRest = tRest + gapWithPrevEl;
				}
				Object nextRampObject = onlyRampsInPeriodToCheck.higherKey(currentMan.getStartTime().getTime());
				if (nextRampObject != null) {
					RampCMGA nextRamp = onlyRampsInPeriodToCheck.higherEntry(currentMan.getStartTime().getTime())
							.getValue();
					// System.out.println("start of ramp : " +
					// nextRamp.getStartTime());

					if (nextRamp.isRampUp() == false) {
						// if there aren't other man cmga in the interval
						// between the man and the next ramp
						if (allMan.subMap(currentMan.getStartTime().getTime(), false, nextRamp.getStartTime().getTime(),
								true).isEmpty()) {
							tRamp = tRamp + (singleTimeForRamp * 1000);
						}
					}
				} else {
					gapWithPrevEl = endCheck - startCheck;
					tPlat = tPlat + gapWithPrevEl;
					startCheck = endCheck;
				}
			} else {
				RampCMGA currentRamp = (RampCMGA) current;
				// System.out.println("start of ramp : " +
				// currentRamp.getStartTime());
				if (currentRamp.isRampUp()) {
					gapWithPrevEl = currentRamp.getStartTime().getTime() - startCheck;
					tRest = tRest + gapWithPrevEl;
					// System.out.println("partial tRest : " + (tRest / 60000));
					startCheck = currentRamp.getStartTime().getTime();
				} else {
					gapWithPrevEl = currentRamp.getStartTime().getTime() - startCheck;
					tPlat = tPlat + gapWithPrevEl;
					// System.out.println("partial tPlat : " + (tPlat / 60000));
					startCheck = currentRamp.getStartTime().getTime();
				}
			}
		}
		if (startCheck < endIntToCheck.getTime()) {
			gapWithPrevEl = endIntToCheck.getTime() - startCheck;
			tRest = tRest + gapWithPrevEl;
		}
		cmgRes.settRest(tRest);

		cmgRes.settPlat(tPlat);
		cmgRes.setTRamp(tRamp);
		return cmgRes;
	}

}
