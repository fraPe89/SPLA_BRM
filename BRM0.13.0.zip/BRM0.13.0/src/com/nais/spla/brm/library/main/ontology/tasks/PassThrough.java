/**
 *
 * MODULE FILE NAME: PassThrough.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.tasks;

import java.math.BigDecimal;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;

// TODO: Auto-generated Javadoc
/**
 * The Class PassThrough.
 */
@SuppressWarnings("serial")
public class PassThrough extends Task {

	/** The programming request id. */
	private String programmingRequestId;

	/** The acquisition request id. */
	private String acquisitionRequestId;

	/** The ground station id. */
	private List<String> groundStationId;

	/** The packet store id. */
	private String packetStoreId;

	/** The carrier L 2 selection H. */
	private boolean carrierL2SelectionH;

	/** The carrier L 2 selection V. */
	private boolean carrierL2SelectionV;

	/** The data strategy H. */
	private boolean dataStrategyH;

	/** The data strategy V. */
	private boolean dataStrategyV;

	/** The memory modules. */
	private List<Integer> memoryModules;

	/** The packet store size H. */
	private int packetStoreSizeH = 0;

	/** The packet store size V. */
	private int packetStoreSizeV = 0;

	/** The for partners. */
	private List<String> ugsOwnerList;

	/**
	 * Checks if is carrier L 2 selection H.
	 *
	 * @return the carrierL2SelectionH
	 */
	public boolean isCarrierL2SelectionH() {
		return this.carrierL2SelectionH;
	}

	/**
	 * Sets the carrier L 2 selection H.
	 *
	 * @param carrierL2SelectionH the carrierL2SelectionH to set
	 */
	public void setCarrierL2SelectionH(boolean carrierL2SelectionH) {
		this.carrierL2SelectionH = carrierL2SelectionH;
	}

	/**
	 * Checks if is carrier L 2 selection V.
	 *
	 * @return the carrierL2SelectionV
	 */
	public boolean isCarrierL2SelectionV() {
		return this.carrierL2SelectionV;
	}

	/**
	 * Sets the carrier L 2 selection V.
	 *
	 * @param carrierL2SelectionV the carrierL2SelectionV to set
	 */
	public void setCarrierL2SelectionV(boolean carrierL2SelectionV) {
		this.carrierL2SelectionV = carrierL2SelectionV;
	}

	/**
	 * Checks if is data strategy H.
	 *
	 * @return the dataStrategyH
	 */
	public boolean isDataStrategyH() {
		return this.dataStrategyH;
	}

	/**
	 * Sets the data strategy H.
	 *
	 * @param dataStrategyH the dataStrategyH to set
	 */
	public void setDataStrategyH(boolean dataStrategyH) {
		this.dataStrategyH = dataStrategyH;
	}

	/**
	 * Checks if is data strategy V.
	 *
	 * @return the dataStrategyV
	 */
	public boolean isDataStrategyV() {
		return this.dataStrategyV;
	}

	/**
	 * Sets the data strategy V.
	 *
	 * @param dataStrategyV the dataStrategyV to set
	 */
	public void setDataStrategyV(boolean dataStrategyV) {
		this.dataStrategyV = dataStrategyV;
	}

	/**
	 * Gets the packet store size H.
	 *
	 * @return the packetStoreSizeH
	 */
	public int getPacketStoreSizeH() {
		return this.packetStoreSizeH;
	}

	/**
	 * Sets the packet store size H.
	 *
	 * @param packetStoreSizeH the packetStoreSizeH to set
	 */
	public void setPacketStoreSizeH(int packetStoreSizeH) {
		this.packetStoreSizeH = packetStoreSizeH;
	}

	/**
	 * Gets the packet store size V.
	 *
	 * @return the packetStoreSizeV
	 */
	public int getPacketStoreSizeV() {
		return this.packetStoreSizeV;
	}

	/**
	 * Sets the packet store size V.
	 *
	 * @param packetStoreSizeV the packetStoreSizeV to set
	 */
	public void setPacketStoreSizeV(int packetStoreSizeV) {
		this.packetStoreSizeV = packetStoreSizeV;
	}

	/** The number of packets. */
	private int numberOfPackets;

	/** The deliberate delay. */
	private BigDecimal deliberateDelay;

	/** The contact counter vis. */
	private long contactCounterVis;

	/** The double pol. */
	private boolean doublePol = false;

	/** The planned on L 2. */
	private boolean plannedOnL2 = false;

	/**
	 * Instantiates a new pass through.
	 */
	public PassThrough() {
		super();
		this.doublePol = false;
	}

	/**
	 * Instantiates a new pass through.
	 *
	 * @param idTask               the id task
	 * @param programmingRequestId the programming request id
	 * @param acquisitionRequestId the acquisition request id
	 * @param satelliteId          the satellite id
	 * @param groundStationId      the ground station id
	 * @param packetStoreId        the packet store id
	 * @param packetStoreSizeH     the packet store size H
	 * @param packetStoreSizeV     the packet store size V
	 * @param numberOfPackets      the number of packets
	 * @param deliberateDelay      the deliberate delay
	 */
	public PassThrough(String idTask, String programmingRequestId, String acquisitionRequestId, String satelliteId,
			List<String> groundStationId, String packetStoreId, int packetStoreSizeH, int packetStoreSizeV,
			int numberOfPackets, BigDecimal deliberateDelay) {
		super();
		super.setIdTask(idTask);
		// set the task type
		super.setTaskType(TaskType.PASSTHROUGH);

		// set the satellite id
		super.setSatelliteId(satelliteId);

		// set the pr id
		this.programmingRequestId = programmingRequestId;

		// set the ar id
		this.acquisitionRequestId = acquisitionRequestId;

		// set the ugs id
		this.groundStationId = groundStationId;

		// set the packet store id
		this.packetStoreId = packetStoreId;

		// set the packet store size
		this.packetStoreSizeH = packetStoreSizeH;
		this.packetStoreSizeV = packetStoreSizeV;

		this.numberOfPackets = numberOfPackets;
		this.deliberateDelay = deliberateDelay;
	}

	/**
	 * Gets the programming request id.
	 *
	 * @return the programming request id
	 */
	public String getProgrammingRequestId() {
		return this.programmingRequestId;
	}

	/**
	 * Sets the programming request id.
	 *
	 * @param programmingRequestId the new programming request id
	 */
	public void setProgrammingRequestId(String programmingRequestId) {
		this.programmingRequestId = programmingRequestId;
	}

	/**
	 * Gets the acquisition request id.
	 *
	 * @return the acquisition request id
	 */
	public String getAcquisitionRequestId() {
		return this.acquisitionRequestId;
	}

	/**
	 * Sets the acquisition request id.
	 *
	 * @param acquisitionRequestId the new acquisition request id
	 */
	public void setAcquisitionRequestId(String acquisitionRequestId) {
		this.acquisitionRequestId = acquisitionRequestId;
	}

	/**
	 * Gets the ground station id.
	 *
	 * @return the ground station id
	 */
	public List<String> getGroundStationId() {
		return this.groundStationId;
	}

	/**
	 *  
	 * return the toString of the object.
	 *
	 * @return the toString
	 */
	@Override
	public String toString() {
		
		/*
		 * this method return 
		 * the toString ith all 
		 * the properties of 
		 * the passthroguh
		 */
		return "PassThrough [id :" + super.getIdTask() + " startTime : " + super.getStartTime() + ", endTime :"
				+ super.getEndTime() + ", programmingRequestId=" + this.getProgrammingRequestId()
				+ ", acquisitionRequestId=" + this.acquisitionRequestId + ", groundStationId=" + this.groundStationId
				+ ", packetStoreSizeH=" + this.packetStoreSizeH + " packetStoreSizeV=" + this.packetStoreSizeV
				+ ", carrierL2SelectionH=" + this.carrierL2SelectionH + ", carrierL2SelectionV="
				+ this.isCarrierL2SelectionV() + ", dataStrategyH=" + this.isDataStrategyH() + ", dataStrategyV="
				+ this.isDataStrategyV() + ", memoryModules=" + this.getMemoryModules() + ", packetStoreSizeH="
				+ this.getPacketStoreSizeH() + ", packetStoreSizeV=" + this.getPacketStoreSizeV() + ", numberOfPackets="
				+ this.getNumberOfPackets() + ", contactCounterVis=" + this.getContactCounterVis() + ", doublePol="
				+ this.isDoublePol() + ", plannedOnL2=" + this.isPlannedOnL2() + "]";
	}

	/**
	 * Sets the ground station id.
	 *
	 * @param groundStationId the new ground station id
	 */
	public void setGroundStationId(List<String> groundStationId) {
		this.groundStationId = groundStationId;
	}

	/**
	 * Gets the packet store id.
	 *
	 * @return the packet store id
	 */
	public String getPacketStoreId() {
		return this.packetStoreId;
	}

	/**
	 * Sets the packet store id.
	 *
	 * @param packetStoreId the new packet store id
	 */
	public void setPacketStoreId(String packetStoreId) {
		this.packetStoreId = packetStoreId;
	}

	/**
	 * Gets the number of packets.
	 *
	 * @return the number of packets
	 */
	public int getNumberOfPackets() {
		return this.numberOfPackets;
	}

	/**
	 * Sets the number of packets.
	 *
	 * @param numberOfPackets the new number of packets
	 */
	public void setNumberOfPackets(int numberOfPackets) {
		this.numberOfPackets = numberOfPackets;
	}

	/**
	 * Gets the deliberate delay.
	 *
	 * @return the deliberate delay
	 */
	public BigDecimal getDeliberateDelay() {
		return this.deliberateDelay;
	}

	/**
	 * Sets the deliberate delay.
	 *
	 * @param deliberateDelay the new deliberate delay
	 */
	public void setDeliberateDelay(BigDecimal deliberateDelay) {
		this.deliberateDelay = deliberateDelay;
	}

	/**
	 *  
	 * return the satellite id
	 *
	 * @return the satellite id relative to the passthrough
	 */
	@Override
	public String getSatelliteId() {
		return super.getSatelliteId();
	}

	/**
	 *  
	 * return the taskMark of the object.
	 *
	 * @return the taskMark of the passthrough
	 */
	@Override
	public TaskMarkType getTaskMark() {
		return super.getTaskMark();
	}

	/**
	 *  
	 * return the taskType of the object.
	 *
	 * @return the taskType of the passthrough
	 */
	@Override
	public TaskType getTaskType() {
		return super.getTaskType();
	}

	/**
	 *  
	 * set the taskType of the object.
	 *
	 */
	@Override
	public void setTaskType(TaskType taskType) {
		super.setTaskType(taskType);
	}

	/**
	 *  
	 * set the taskMrk of the object.
	 */
	@Override
	public void setTaskMark(TaskMarkType taskMark) {
		super.setTaskMark(taskMark);
	}

	/**
	 *  
	 * set the taskId of the object.
	 *
	 */
	@Override
	public void setIdTask(String idTask) {
		super.setIdTask(idTask);
	}

	/**
	 *  
	 * return the taskId of the object.
	 *
	 * @return the taskId of the passthrough
	 */
	@Override
	public String getIdTask() {
		return super.getIdTask();
	}

	/**
	 * Gets the contact counter vis.
	 *
	 * @return the contact counter vis
	 */
	public long getContactCounterVis() {
		return this.contactCounterVis;
	}

	/**
	 * Sets the contact counter vis.
	 *
	 * @param contactCounterVis the new contact counter vis
	 */
	public void setContactCounterVis(long contactCounterVis) {
		this.contactCounterVis = contactCounterVis;
	}

	/**
	 * Checks if is double pol.
	 *
	 * @return the doublePol
	 */
	public boolean isDoublePol() {
		return this.doublePol;
	}

	/**
	 * Sets the double pol.
	 *
	 * @param doublePol the doublePol to set
	 */
	public void setDoublePol(boolean doublePol) {
		this.doublePol = doublePol;
	}

	/**
	 * Checks if is planned on L 2.
	 *
	 * @return the plannedOnL2
	 */
	public boolean isPlannedOnL2() {
		return this.plannedOnL2;
	}

	/**
	 * Sets the planned on L 2.
	 *
	 * @param plannedOnL2 the plannedOnL2 to set
	 */
	public void setPlannedOnL2(boolean plannedOnL2) {
		this.plannedOnL2 = plannedOnL2;
	}

	/**
	 * Gets the ugs owner list.
	 *
	 * @return the ugsOwnerList
	 */
	public List<String> getUgsOwnerList() {
		return this.ugsOwnerList;
	}

	/**
	 * Sets the ugs owner list.
	 *
	 * @param ugsOwnerList the ugsOwnerList to set
	 */
	public void setUgsOwnerList(List<String> ugsOwnerList) {
		this.ugsOwnerList = ugsOwnerList;
	}

	/**
	 * Gets the memory modules.
	 *
	 * @return the memory modules
	 */
	public List<Integer> getMemoryModules() {
		return memoryModules;
	}

	/**
	 * Sets the memory modules.
	 *
	 * @param memoryModules the new memory modules
	 */
	public void setMemoryModules(List<Integer> memoryModules) {
		this.memoryModules = memoryModules;
	}

}
