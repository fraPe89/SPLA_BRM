/**
*
* MODULE FILE NAME:	PacketStore.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		05 mag 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 05 mag 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;

/**
 * The Class PacketStore.
 *
 * @author fpedrola
 */
public class PacketStore implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The polarization. */
	private Polarization polarization;

	/** The associated sto id. */
	private String associatedStoId;

	/** The used sectors. */
	private int usedSectors = 0;

	/** The residual sectors. */
	private int residualSectors = 0;

	/** The size. */
	private int size = 0;

	/** The planned on mem module. */
	private Map<MemoryModule, Long> plannedOnMemModule = new HashMap<>();

	/**
	 * Gets the associated sto id.
	 *
	 * @return the associated sto id
	 */
	public String getAssociatedStoId() {
		return this.associatedStoId;
	}

	/**
	 * Sets the associated sto id.
	 *
	 * @param associatedStoId the new associated sto id
	 */
	public void setAssociatedStoId(String associatedStoId) {
		this.associatedStoId = associatedStoId;
	}

	/**
	 * Gets the used sectors.
	 *
	 * @return the used sectors
	 */
	public int getUsedSectors() {
		return this.usedSectors;
	}

	/**
	 * Sets the used sectors.
	 *
	 * @param usedSectors the new used sectors
	 */
	public void setUsedSectors(int usedSectors) {
		this.usedSectors = usedSectors;
	}

	/**
	 * Gets the residual sectors.
	 *
	 * @return the residual sectors
	 */
	public int getResidualSectors() {
		return this.residualSectors;
	}

	/**
	 * Sets the residual sectors.
	 *
	 * @param residualSectors the new residual sectors
	 */
	public void setResidualSectors(int residualSectors) {
		this.residualSectors = residualSectors;
	}

	/**
	 * Sets the planned on mem module.
	 *
	 * @param plannedOnMemModule the planned on mem module
	 */
	public void setPlannedOnMemModule(Map<MemoryModule, Long> plannedOnMemModule) {
		this.plannedOnMemModule = plannedOnMemModule;
	}

	/**
	 * Instantiates a new packet store.
	 *
	 * @param associatedStoId the associated sto id
	 */
	public PacketStore(String associatedStoId) {
		// setId(getId() + 1);
		this.associatedStoId = associatedStoId;
	}

	/**
	 * Instantiates a new packet store.
	 *
	 * @param associatedStoId the associated sto id
	 * @param polarization    the polarization
	 */
	public PacketStore(String associatedStoId, Polarization polarization) {
		this.associatedStoId = associatedStoId;
		this.polarization = polarization;
	}

	/**
	 * Instantiates a new packet store.
	 *
	 * @param associatedStoId the associated sto id
	 * @param polarization    the polarization
	 * @param size            the size
	 */
	public PacketStore(String associatedStoId, Polarization polarization, int size) {
		this.associatedStoId = associatedStoId;
		this.polarization = polarization;
		this.size = size;
	}

	/**
	 * Adds the memory module to PS.
	 *
	 * @param mem        the mem
	 * @param sectorUsed the sector used
	 */
	public void addMemoryModuleToPS(MemoryModule mem, long sectorUsed) {
		this.plannedOnMemModule.put(mem, sectorUsed);
	}

	/**
	 * Gets the planned on mem module.
	 *
	 * @return the planned on mem module
	 */
	public Map<MemoryModule, Long> getPlannedOnMemModule() {
		return this.plannedOnMemModule;
	}

	/**
	 * Gets the polarization.
	 *
	 * @return the polarization
	 */
	public Polarization getPolarization() {
		return this.polarization;
	}

	/**
	 * Gets the size.
	 *
	 * @return the size
	 */
	public int getSize() {
		// initialize the tot
		int tot = 0;

		// iterate over the map of memory modules used for the current ps
		for (Map.Entry<MemoryModule, Long> entry : this.plannedOnMemModule.entrySet()) {
			// extract the value of sectors used for this ps on this mem module
			long value = entry.getValue();

			// increment the totl with the value just extracted
			tot = (int) (tot + value);
		}

		// set the size
		this.size = tot;
		return this.size;
	}

	/**
	 * Sets the polarization.
	 *
	 * @param polarization the new polarization
	 */
	public void setPolarization(Polarization polarization) {
		this.polarization = polarization;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the packetStore
	 */
	@Override
	public String toString() {
		return "PacketStore [polarization=" + this.polarization + ", associatedStoId=" + this.associatedStoId
				+ ", plannedOnMemModule=" + this.plannedOnMemModule + "]";
	}

	/**
	 * Sets the size.
	 *
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

}
