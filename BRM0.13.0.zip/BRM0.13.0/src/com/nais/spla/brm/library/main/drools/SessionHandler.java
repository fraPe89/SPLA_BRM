/**
*
* MODULE FILE NAME:	SessionHandler.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		08 Sett 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 08 Sett 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import java.util.TreeMap;

import org.kie.api.runtime.KieSession;

/**
 * The Class SessionHandler.
 *
 * @author francesca
 */
public class SessionHandler {

	/** The kie sessions map. */
	private static TreeMap<String, KieSession> kieSessionsMap = new TreeMap<>();

	/**
	 * Instantiates a new session handler.
	 */
	public SessionHandler() {
		super();

	}

	/**
	 * Gets the kie sessions map.
	 *
	 * @return the kieSessionsMap
	 */
	public static TreeMap<String, KieSession> getKieSessionsMap() {
		return kieSessionsMap;
	}
}
