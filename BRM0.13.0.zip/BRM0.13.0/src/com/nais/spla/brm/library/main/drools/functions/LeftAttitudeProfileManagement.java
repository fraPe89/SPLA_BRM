/**
*
* MODULE FILE NAME: LeftAttitudeProfileManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        18 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 18 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;

import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.OrbitResources;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.MinTimeRight;

// TODO: Auto-generated Javadoc
/**
 * The Class LeftAttitudeProfileManagement.
 */
public class LeftAttitudeProfileManagement {

	/**
	 * Compute max time left algo.
	 *
	 * @param acq          the acq
	 * @param droolsParams the drools params
	 * @param manTreemap   the man treemap
	 * @param acqTreemap   the acq treemap
	 * @param silTreemap   the sil treemap
	 * @param fromMethod   the from method
	 * @return true, if successful
	 */
	public boolean computeMaxTimeLeftAlgo(Acquisition acq, DroolsParameters droolsParams,
			TreeMap<Long, Maneuver> manTreemap, TreeMap<Long, EnergyAssociatedToTask> acqTreemap,
			TreeMap<Long, EnergyAssociatedToTask> silTreemap, String fromMethod) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		logger.info("from method " + fromMethod);
		logger.info("for acq : " + acq);
		logger.info("manTreemap : " + manTreemap);

		for (Map.Entry<Long, Maneuver> allMan : manTreemap.entrySet()) {
			logger.info("manTreemap : " + allMan.getValue());

		}
		// variable that is returned from this method, to show if the check on
		// left attitude is valid
		boolean validLeftAttitude = true;

		// logger.info("disable check on left attitude ? " +
		// droolsParams.isDisableCheckLeftAttitude());

		if (!droolsParams.isDisableCheckLeftAttitude()) {
			SatelliteProperties satProp = droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties();
			// extract the percentage that the maneuver is considered in left
			// period
			double percManLeft = satProp.getPercentManLeftC2();

			logger.info("MAX_LEFT_PERIOD_RULE : percent man computed for left period : " + percManLeft);
			List<DateResource> startAndStopLeftPeriod = new ArrayList<>();

			// get the current mh
			MissionHorizon mh = droolsParams.getCurrentMH();

			// extract the max time between two left
			// acquisition for let them stay
			// in the same left period. If the gap
			// between them is more than this
			// configurable variable, they must be
			// divided in two left period with
			// contermaneuvers

			logger.info("MAX_LEFT_PERIOD_RULE FOR : " + acq.getId() + " |lookSide : " + acq.getLookSide()
					+ " | start : " + acq.getStartTime() + " | stop : " + acq.getEndTime());
			// if the acq is a left
			if (acq.getLookSide().equalsIgnoreCase("left")) {
				logger.info("MAX_LEFT_PERIOD_RULE processing a left acq ");
				logger.info("MAX_LEFT_PERIOD_RULE detect the left period with the current acq involved");

				// get the left period where
				// this acquisiton is involved
				DateResource firstCheck = detectActualLeftPeriod(logger, acq, manTreemap, mh, percManLeft);
				startAndStopLeftPeriod.add(firstCheck);
				Acquisition acqNextLeft = findNextLeft(firstCheck, manTreemap, acqTreemap);
				if (acqNextLeft != null) {
					DateResource secondCheck = detectActualLeftPeriod(logger, acqNextLeft, manTreemap, mh, percManLeft);
					startAndStopLeftPeriod.add(secondCheck);
				}
			}

			// is a right
			else {
				logger.info("MAX_LEFT_PERIOD_RULE processing a right acq ");
				logger.info("MAX_LEFT_PERIOD_RULE find last previous left acq ");
				boolean previous = true;
				// get the last left acquisition
				Acquisition previousInLeft = getPrevLeftPeriod(acq, acqTreemap, previous);

				// if previous left exists
				if (previousInLeft != null) {
					logger.info("MAX_LEFT_PERIOD_RULE detect the left period with the previous left acq involved");

					// detect
					DateResource firstCheck = detectActualLeftPeriod(logger, previousInLeft, manTreemap, mh,
							percManLeft);
					startAndStopLeftPeriod.add(firstCheck);

				}
				previous = false;
				// get the next left acquisition
				Acquisition nextInLeft = getPrevLeftPeriod(acq, acqTreemap, previous);

				for (Map.Entry<Long, Maneuver> treeMap : manTreemap.entrySet()) {
					System.out.println(treeMap.getValue());

				}
				// if next left exists
				if (nextInLeft != null) {
					logger.info("MAX_LEFT_PERIOD_RULE detect the left period with the next left acq involved");

					// detect
					DateResource secondCheck = detectActualLeftPeriod(logger, nextInLeft, manTreemap, mh, percManLeft);
					startAndStopLeftPeriod.add(secondCheck);
				}

				if ((previousInLeft == null) && (nextInLeft == null)) {
					// check passed
					logger.info("MAX_LEFT_PERIOD_RULE there isn't a previous/next left acq, nothing to check. ");
				}
			}

			// if the left period is found
			validLeftAttitude = processResources(startAndStopLeftPeriod, acq, droolsParams, acqTreemap, silTreemap,
					manTreemap, percManLeft);

		}
		return validLeftAttitude;
	}

	/**
	 * Process resources.
	 *
	 * @param startAndStopLeftPeriod the start and stop left period
	 * @param acq                    the acq
	 * @param droolsParams           the drools params
	 * @param acqTreemap             the acq treemap
	 * @param silTreemap             the sil treemap
	 * @param manTreemap             the man treemap
	 * @param percManLeft            the perc man left
	 * @return true, if successful
	 */
	public boolean processResources(List<DateResource> startAndStopLeftPeriod, Acquisition acq,
			DroolsParameters droolsParams, TreeMap<Long, EnergyAssociatedToTask> acqTreemap,
			TreeMap<Long, EnergyAssociatedToTask> silTreemap, TreeMap<Long, Maneuver> manTreemap, double percManLeft) {
		Logger logger = DroolsParameters.getLogger();
		boolean validLeftAttitude = true;

		if (!startAndStopLeftPeriod.isEmpty()) {

			// initialize variable to track the previous orbit start time
			long startPreviousOrbit = 0;

			// initialize variable to track the previous orbit stop time
			long endPreviousOrbit = 0;

			// initialize variable to track the next orbit start time
			long maxEndNextOrbit = 0;

			// initialize variable to track the next orbit stop time
			long endOfNextOrbit = 0;
			long startNextOrbit = 0;

			// variable to check if silent energy must be included or not in the
			// computation, false as default
			boolean includeSilent = false;

			double percentManLeft = droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
					.getPercentManLeftC2();
			// if the configuration variable relative to include silent is 1
			if (droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
					.getIncludeSilentInLeftAttitudeFormulaC1() == 1) {
				// set the boolean variable to true
				includeSilent = true;
			}

			double totalEssRight = 0;
			double totalEssLeft = 0;
			double totalTimeInLeft = 0;
			double totalTimeInRight = 0;
			double minimumTimeInRight = 0;
			OrbitResources previousOrbit = null;
			OrbitResources nextOrbit = null;
			for (int i = 0; i < startAndStopLeftPeriod.size(); i++) {
				if (validLeftAttitude) {
					OrbitResources leftPeriod = new OrbitResources();
					try {
						logger.info("MAX_LEFT_PERIOD_RULE start of left  period : "
								+ startAndStopLeftPeriod.get(i).getStart());
						logger.info(
								"MAX_LEFT_PERIOD_RULE end of left period : " + startAndStopLeftPeriod.get(i).getStop());

						// set the start time
						leftPeriod.setStart(startAndStopLeftPeriod.get(i).getStart());

						// set the stop time
						leftPeriod.setStop(startAndStopLeftPeriod.get(i).getStop());

						// compute energy and time spent in left period

						leftPeriod = computeEssValuesInInterval(includeSilent, percentManLeft,
								leftPeriod.getStart().getTime(), leftPeriod.getStop().getTime(), acqTreemap, silTreemap,
								manTreemap);

						logger.info("MAX_LEFT_PERIOD_RULE time in left  period : " + leftPeriod.getTimeInLeft());
						logger.info("MAX_LEFT_PERIOD_RULE check versus the time of two orbits : "
								+ (droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
										.getMaxTimeInAllTheLeftPeriod()));

						// first precheck
						// check on time in left
						// if is more than 2 orbit
						// is an invalid attitude
						if (leftPeriod.getTimeInLeft() > ((droolsParams.getSatWithId(acq.getSatelliteId())
								.getSatelliteProperties().getMaxTimeInAllTheLeftPeriod()))) {
							logger.info("MAX_LEFT_PERIOD_RULE reject acq  because : "
									+ ReasonOfReject.leftAttitudeModeViolation);
							logger.info(
									"MAX_LEFT_PERIOD_RULE reject acq caused by :total time in left is more than 2 orbits ");
							// get the involved elements
							List<String> elementsInvolved = getAllElementsInvolved(leftPeriod.getStart().getTime(),
									leftPeriod.getStop().getTime(), acqTreemap);

							// add the reason of reject
							acq.addReasonOfReject(38, ReasonOfReject.moreThanLeftAttitudeTimeThreshold,
									"Left Looking Duration Exceeded The Threshold", 0, 0, elementsInvolved);
							validLeftAttitude = false;
						}

						// if the check is valid, continue
						if (validLeftAttitude) {
							// second precheck
							// if the energy spent in left
							// period is more than configurable
							// value than reject for
							// moreThanLeftAttitudeTimeThreshold
							logger.info("MAX_LEFT_PERIOD_RULE passed prefilter on constraint of time in left period");
							logger.info("MAX_LEFT_PERIOD_RULE ess in left period : " + leftPeriod.getEssLeft());
							logger.info("MAX_LEFT_PERIOD_RULE check versus the time of two energy barrels : "
									+ droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties()
											.getMaxEssInLeftPeriod());

							// check if is reached the second precheck
							if (leftPeriod.getEssLeft() > droolsParams.getSatWithId(acq.getSatelliteId())
									.getSatelliteProperties().getMaxEssInLeftPeriod()) {
								logger.info("MAX_LEFT_PERIOD_RULE reject acq because : "
										+ ReasonOfReject.leftAttitudeModeViolation);
								logger.info(
										"MAX_LEFT_PERIOD_RULE reject acq caused by : total ess in left period are > than "
												+ droolsParams.getSatWithId(acq.getSatelliteId())
														.getSatelliteProperties().getMaxEssInLeftPeriod()
												+ " 2 orbital peaks");

								// get elements involved
								List<String> elementsInvolved = getAllElementsInvolved(leftPeriod.getStart().getTime(),
										leftPeriod.getStop().getTime(), acqTreemap);

								// add reason of reject
								acq.addReasonOfReject(38, ReasonOfReject.essLeftMoreThanThreshold,
										"Left Looking Energy Exceeded The Threshold", 0, 0, elementsInvolved);
								validLeftAttitude = false;
							}
							// is also the second check is passed
							if (validLeftAttitude) {

								logger.info(
										"MAX_LEFT_PERIOD_RULE passed prefilter on constraint of ess in left period");
								// set the previous orbit end time
								endPreviousOrbit = leftPeriod.getStart().getTime();

								// set the previous orbit start time
								startPreviousOrbit = endPreviousOrbit - (droolsParams.getMinutesForOrbit() * 60000);
								logger.info("MAX_LEFT_PERIOD_RULE start of previous orbit : "
										+ new Date(startPreviousOrbit));
								logger.info(
										"MAX_LEFT_PERIOD_RULE end of previous orbit : " + new Date(endPreviousOrbit));

								// set the next orbit max time
								maxEndNextOrbit = leftPeriod.getStop().getTime()
										+ (droolsParams.getMinutesForOrbit() * 60000);

								startNextOrbit = leftPeriod.getStop().getTime();
								endOfNextOrbit = findEndOfNextOrbit(leftPeriod.getStop().getTime(), maxEndNextOrbit,
										acqTreemap, manTreemap);
								logger.info("MAX_LEFT_PERIOD_RULE start of right period to check : "
										+ new Date(startNextOrbit));
								logger.info("MAX_LEFT_PERIOD_RULE end of right period to check : "
										+ new Date(endOfNextOrbit));

								// compute energy and time spent in prev orbit
								previousOrbit = computeEssValuesInInterval(includeSilent, percentManLeft,
										startPreviousOrbit, endPreviousOrbit, acqTreemap, silTreemap, manTreemap);

								// compute energy and time spent in next orbit
								nextOrbit = computeEssValuesInInterval(includeSilent, percentManLeft,
										leftPeriod.getStop().getTime(), endOfNextOrbit, acqTreemap, silTreemap,
										manTreemap);

								// compute the total ess spent in right
								totalEssRight = previousOrbit.getEssRight() + nextOrbit.getEssRight();

								// compute the total ess spent in right
								totalEssLeft = previousOrbit.getEssLeft() + leftPeriod.getEssLeft();

								// compute the total ess spent in right
								totalTimeInLeft = previousOrbit.getTimeInLeft() + leftPeriod.getTimeInLeft();

								if (maxEndNextOrbit < droolsParams.getCurrentMH().getStop().getTime()) {
									maxEndNextOrbit = droolsParams.getCurrentMH().getStop().getTime();
								}
								long effectiveTimeInRightInNextOrbit = findEndOfNextOrbit(
										leftPeriod.getStop().getTime(), maxEndNextOrbit, acqTreemap, manTreemap);
								logger.info("compute the effetive time in right on next orbits :"
										+ new Date(effectiveTimeInRightInNextOrbit));

								double gap = (effectiveTimeInRightInNextOrbit - leftPeriod.getStop().getTime()) / 1000;
								// compute the total ess spent in right
								totalTimeInRight = previousOrbit.getTimeInRight() + gap;

								if (effectiveTimeInRightInNextOrbit >= droolsParams.getCurrentMH().getStop()
										.getTime()) {
									totalTimeInRight = Double.POSITIVE_INFINITY;
								}

								logger.info("total time right (prev + next orbits) : " + totalTimeInRight);

								logger.info("MAX_LEFT_PERIOD_RULE computed left period : " + leftPeriod);
								logger.info("MAX_LEFT_PERIOD_RULE computed previous orbit : " + previousOrbit);
								logger.info("MAX_LEFT_PERIOD_RULE computed next orbit : " + nextOrbit);
								logger.info("MAX_LEFT_PERIOD_RULE total time in right computed : " + totalTimeInRight);
								logger.info(
										"MAX_LEFT_PERIOD_RULE find the correct value in table to compare it with the computed one : "
												+ totalTimeInRight);

								// extract the minimum time
								// that the satellite must
								// stay in right based on
								// values computed above
								minimumTimeInRight = findMinimumValueInTable(droolsParams, totalEssRight, totalEssLeft,
										totalTimeInLeft, totalTimeInRight,
										droolsParams.getSatWithId(acq.getSatelliteId()).getSatelliteProperties());
								logger.info("MAX_LEFT_PERIOD_RULE returned value from table : " + minimumTimeInRight);
								logger.info("MAX_LEFT_PERIOD_RULE check versus : " + totalTimeInRight);

								// not enough time in righe
								if (minimumTimeInRight > (totalTimeInRight)) {
									logger.info("MAX_LEFT_PERIOD_RULE rejectacq because : "
											+ ReasonOfReject.leftAttitudeModeViolation);
									List<String> elementsInvolved = getAllElementsInvolved(
											previousOrbit.getStart().getTime(), endOfNextOrbit, acqTreemap);
									acq.addReasonOfReject(36, ReasonOfReject.leftAttitudeModeViolation,
											"Left Attitude Constrains Violation", 0, 0, elementsInvolved);
									validLeftAttitude = false;
								} else {
									logger.info("MAX_LEFT_PERIOD_RULE there is enough time in right, check passed.");
								}
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		return validLeftAttitude;
	}

	/**
	 * Find next left.
	 *
	 * @param firstCheck the first check
	 * @param manTreemap the man treemap
	 * @param acqTreemap the acq treemap
	 * @return the acquisition
	 */
	public Acquisition findNextLeft(DateResource firstCheck, TreeMap<Long, Maneuver> manTreemap,
			TreeMap<Long, EnergyAssociatedToTask> acqTreemap) {
		Acquisition acqNextLeft = null;
		Long nextManKey = getNextMan(manTreemap, firstCheck.getStop());
		if (nextManKey != null) {
			Maneuver nextMan = manTreemap.get(nextManKey);
			if (nextMan.isRightToLeftFlag()) {
				if (acqTreemap.higherEntry(nextMan.getEndTime().getTime()) != null) {
					acqNextLeft = (Acquisition) acqTreemap.higherEntry(nextMan.getEndTime().getTime()).getValue()
							.getTask();
				}
			} else {
				nextManKey = getNextMan(manTreemap, nextMan.getEndTime());
				if (nextManKey != null) {
					nextMan = manTreemap.get(nextManKey);
					if (acqTreemap.higherEntry(nextMan.getEndTime().getTime()) != null) {
						acqNextLeft = (Acquisition) acqTreemap.higherEntry(nextMan.getEndTime().getTime()).getValue()
								.getTask();
					}
				}
			}
		}
		return acqNextLeft;
	}

	/**
	 * this method allows to calculate the time interval in which the satellite
	 * remains in the left, based on the acquisition of the left that we are dealing
	 * with. the time is surrounded by two maneuvers (the first R2L and the second
	 * L2R) NB: nextMan can never be null, since by default after a left maneuver
	 * there is always an L2R countermaneuver
	 *
	 * @param logger      the logger
	 * @param acqLeft     the acq left
	 * @param manTreemap  the man treemap
	 * @param mh          the mh
	 * @param percManLeft the perc man left
	 * @return the list
	 */
	public DateResource detectActualLeftPeriod(Logger logger, Acquisition acqLeft, TreeMap<Long, Maneuver> manTreemap,
			MissionHorizon mh, double percManLeft) {
		// create a list of Date for start and stop of the current left period
		DateResource startAndStopLeftPeriod = new DateResource();

		// get the key to find, as start time of the current acq
		long keyToFind = acqLeft.getStartTime().getTime();

		// initialize previous and next man
		Maneuver previousMan = null;
		Maneuver nextMan = null;

		// extract previous man (the search of previous elements is allowed by
		// the boolean variable at true)
		Object previousManKey = getPrevOrNextMan(manTreemap, keyToFind, true);

		// if there is a previous man
		if (previousManKey != null) {
			// extract it
			previousMan = manTreemap.get(previousManKey);

			logger.info("previousMan " + previousMan);
			// compute time of maneuver that must be considered as left time
			long timeToAddForManAtStart = addPercentLeftMan(previousMan, percManLeft);

			logger.info("MAX_LEFT_PERIOD_RULE found a previous man at : " + previousMan.getStartTime());
			logger.info("MAX_LEFT_PERIOD_RULE left period start : " + previousMan.getEndTime());

			// add the end time of the man to the start time of left period
			startAndStopLeftPeriod.setStart(new Date(previousMan.getEndTime().getTime() - timeToAddForManAtStart));
		}
		// there isn't a previous man
		else {
			logger.info("MAX_LEFT_PERIOD_RULE cannot found a previous maneuver : left period starts at mh start time ");
			// logger.info("MAX_LEFT_PERIOD_RULE left period start : " +
			// mh.getStart());

			// add as start time the mission horizon start time
			startAndStopLeftPeriod.setStart(mh.getStart());
		}

		// extract next man (the search of next elements is allowed by the
		// boolean variable at false)
		Object nextManKey = getPrevOrNextMan(manTreemap, keyToFind, false);

		logger.info("next man key " + nextManKey);
		// if exists a next man
		if (nextManKey != null) {
			// extract it
			nextMan = manTreemap.get(nextManKey);

			long timeToAddForManAtEnd = addPercentLeftMan(nextMan, percManLeft);

			logger.info("MAX_LEFT_PERIOD_RULE found a next maneuver at :" + nextMan.getStartTime());

			// add the start time of the
			// man as end of left period
			startAndStopLeftPeriod.setStop(new Date(nextMan.getStartTime().getTime() + timeToAddForManAtEnd));
			logger.info("MAX_LEFT_PERIOD_RULE left period ends at : "
					+ new Date(nextMan.getStartTime().getTime() + timeToAddForManAtEnd));

		}
		// if doesn't exists a next man
		else {
			logger.info("MAX_LEFT_PERIOD_RULE cannot found a next maneuver :left period ends at mh end time ");
			logger.info("MAX_LEFT_PERIOD_RULE left period end : " + mh.getStop());
			startAndStopLeftPeriod.setStop(mh.getStop());
		}
		return startAndStopLeftPeriod;
	}

	/**
	 * Adds the percent left man.
	 *
	 * @param manLeft     the man left
	 * @param percManLeft the perc man left
	 * @return the long
	 */
	public long addPercentLeftMan(Maneuver manLeft, double percManLeft) {
		// initialize the return variable
		long millisecAsLeft = 0;

		// compute the duration of maneuver
		long periodOfMan = manLeft.getEndTime().getTime() - manLeft.getStartTime().getTime();

		// get the interval that must be reserved as left period
		millisecAsLeft = (long) ((percManLeft * periodOfMan) / 100);

		// return it
		return millisecAsLeft;
	}

	/**
	 * Gets the prev or next man.
	 *
	 * @param manTreemap the man treemap with all the maneuvers related to a
	 *                   satellite ordered by starTTime
	 * @param keyToFind  the key to find expressed as long (a Date.getTime())
	 * @param back       a boolean type that if is true means that the algo will
	 *                   search for a previous maneuver, if false a next maneuver
	 * @param actuator   the actuator
	 * @return the prev or next man start time, or null if there isn't a prev/next
	 *         man
	 */
	public Object getPrevOrNextManOfRelatedType(TreeMap<Long, Maneuver> manTreemap, long keyToFind, boolean back,
			Actuator actuator) {
		// create an object where store the key of previous or next element to
		// find
		Object key = null;

		// if we are searching for previous
		if (back) {
			// get the lowerkey
			key = manTreemap.lowerKey(keyToFind);
		}
		// if we are searching for next
		else {
			// extract the higherKey
			key = manTreemap.higherKey(keyToFind);
		}

		// create a variable to escape from while
		boolean isInvalid = true;

		// continue the research till there aren't previous/next elements
		// or the extracted element is of type Roll
		while (isInvalid && (key != null)) {
			// if we are searching for previous
			if (back) {
				// get the previous man
				Maneuver man = manTreemap.lowerEntry(keyToFind).getValue();

				// if the type of man isn't rollSlew
				if (man.getActuator().compareTo(actuator) == 0) {
					// set the boolean variable to valid and exit from while
					isInvalid = false;

				}
				// the extracted man is of type rollSlew
				else {
					// go to next previous element
					key = manTreemap.lowerKey(man.getStartTime().getTime());

					// update key to find with the extracted man start time
					keyToFind = man.getStartTime().getTime();
				}
			}
			// if we are searching for next
			else {
				// get the next man
				Maneuver man = manTreemap.higherEntry(keyToFind).getValue();

				// if the type of man isn't rollSlew
				if (man.getActuator().compareTo(actuator) == 0) {
					// set the boolean variable to valid and exit from while
					isInvalid = false;

				}
				// the extracted man is of type rollSlew
				else {
					// go to next element of next element
					key = manTreemap.higherKey(man.getStartTime().getTime());

					// update key to find with the extracted man start time
					keyToFind = man.getStartTime().getTime();
				}
			}
		}
		return key;
	}

	/**
	 * Gets the prev or next man.
	 *
	 * @param manTreemap the man treemap with all the maneuvers related to a
	 *                   satellite ordered by starTTime
	 * @param keyToFind  the key to find expressed as long (a Date.getTime())
	 * @param back       a boolean type that if is true means that the algo will
	 *                   search for a previous maneuver, if false a next maneuver
	 * @return the prev or next man start time, or null if there isn't a prev/next
	 *         man
	 */
	public Object getPrevOrNextMan(TreeMap<Long, Maneuver> manTreemap, long keyToFind, boolean back) {
		// create an object where store the key of previous or next element to
		// find
		Object key = null;

		// if we are searching for previous
		if (back) {
			// get the lowerkey
			key = manTreemap.lowerKey(keyToFind);
		}
		// if we are searching for next
		else {
			// extract the higherKey
			key = manTreemap.higherKey(keyToFind);
		}

		// create a variable to escape from while
		boolean isInvalid = true;

		// continue the research till there aren't previous/next elements
		// or the extracted element is of type Roll
		while (isInvalid && (key != null)) {
			// if we are searching for previous
			if (back) {
				// get the previous man
				Maneuver man = manTreemap.lowerEntry(keyToFind).getValue();

				// if the type of man isn't rollSlew
				if (man.getType().compareTo(ManeuverType.RollSlew) != 0) {
					// go to next previous element
					key = manTreemap.lowerKey(man.getStartTime().getTime());

					// update key to find with the extracted man start time
					keyToFind = man.getStartTime().getTime();
				}
				// the extracted man is of type rollSlew
				else {
					// set the boolean variable to valid and exit from while
					isInvalid = false;
				}
			}
			// if we are searching for next
			else {
				// get the next man
				Maneuver man = manTreemap.higherEntry(keyToFind).getValue();

				// if the type of man isn't rollSlew
				if (man.getType().compareTo(ManeuverType.RollSlew) != 0) {
					// go to next element of next element
					key = manTreemap.higherKey(man.getStartTime().getTime());

					// update key to find with the extracted man start time
					keyToFind = man.getStartTime().getTime();
				}
				// the extracted man is of type rollSlew
				else {
					// set the boolean variable to valid and exit from while
					isInvalid = false;
				}
			}
		}
		return key;
	}

	/**
	 * Find minimum value in table. 1. Compute the relevant parameters presented for
	 * each i-esim left period; 2. Identify the reference column in the table
	 * (column with Tref - L equal or immediately greater that the total left time
	 * TL,i); 3. Identify the reference group of rows in the table (group of rows
	 * with ESSref-T, equal or immediately greater than the ESST,i) . Please note
	 * that in case all rows of the identify group of rows have ESSref � L < ESSL,i,
	 * another group of rows, with a larger ESSref-T , has to be identified; 4.
	 * Identify the reference row within the group (row with the ESSref - L equal or
	 * immediately greater than ESSL,i); 5. Check that the i+1-esim left period is
	 * not closer from the i-esim left period of the value found in the table.
	 *
	 * @param droolsParams     the drools params
	 * @param totalEssRight    the total ess right
	 * @param totalEssLeft     the total ess left
	 * @param totalTimeInLeft  the total time in left
	 * @param totalTimeInRight the total time in right
	 * @param satProp          the sat prop
	 * @return the double
	 */
	protected double findMinimumValueInTable(DroolsParameters droolsParams, double totalEssRight, double totalEssLeft,
			double totalTimeInLeft, double totalTimeInRight, SatelliteProperties satProp) {
		Logger logger = DroolsParameters.getLogger();

		// set as default the minTimeInRight to -1
		double timeInRight = -1;

		// get the treemap with the minimum values in right
		TreeMap<Double, List<MinTimeRight>> minTimeInRight = droolsParams.getMinTimeRight();

		// initialize the rows to match
		List<MinTimeRight> allRowsRelatedToSelectedTime = new ArrayList<>();

		// initialize the list of possible rows
		List<MinTimeRight> listPossibleRows = new ArrayList<>();
		logger.info("MAX_LEFT_PERIOD_RULE get value in table ");
		logger.info("MAX_LEFT_PERIOD_RULE for computed values : totalEssR " + totalEssRight + " totalEssL :"
				+ totalEssLeft + " totalTimeInLeft:" + totalTimeInLeft);
		logger.info("MAX_LEFT_PERIOD_RULE computed timeInRight : " + totalTimeInRight);

		// returns the least key greater than or equal to
		// the given key, or null if there is no such key.
		Object nearestKey = minTimeInRight.ceilingKey(totalTimeInLeft);

		logger.info("MAX_LEFT_PERIOD_RULE find correct column : " + nearestKey);

		// if there is an higher value
		if (nearestKey != null) {
			// get all the rows associated with this value
			allRowsRelatedToSelectedTime = minTimeInRight.get(nearestKey);
		} else {
			// case more than 2 orbit (maximum value), impossible for the
			// satellite to stay in left attitude for more than 2 orbit, reject.
			logger.info("get last entry :" + minTimeInRight.lastEntry().getValue());
			allRowsRelatedToSelectedTime = null;
			timeInRight = -1;
		}

		// if there is a row to match
		if (allRowsRelatedToSelectedTime != null) {
			// get all the possible rows
			listPossibleRows = findPossibleRows(allRowsRelatedToSelectedTime, totalEssLeft + totalEssRight);
			logger.info(
					"MAX_LEFT_PERIOD_RULE rows of the table nearest to searched element : " + listPossibleRows.size());

			// iterate over them
			for (int i = 0; i < listPossibleRows.size(); i++) {
				logger.info("MAX_LEFT_PERIOD_RULE rows of the table nearest to searched element : "
						+ listPossibleRows.get(i));
			}

			// get the nearest row
			MinTimeRight chosenRow = getNearestLeftTime(listPossibleRows, totalEssLeft);
			logger.info("row chosen : " + chosenRow);

			// if there is a valid row
			if (chosenRow != null) {
				// use default time in right
				timeInRight = chosenRow.getTimeInRight();
				logger.info("MAX_LEFT_PERIOD_RULE selected row to compare :" + chosenRow);
			}
			// if there isn't a valid row
			else {
				// use default time in right
				timeInRight = satProp.getDefaultMinTimeRight() * 60;
				logger.info("MAX_LEFT_PERIOD_RULE there isn't a row to compare, use default value " + timeInRight);
			}
		}
		return timeInRight;
	}

	/**
	 * Find possible rows.
	 *
	 * @param value      the value
	 * @param totalEssLR the total ess LR
	 * @return the list
	 */
	protected static List<MinTimeRight> findPossibleRows(List<MinTimeRight> value, double totalEssLR) {
		List<MinTimeRight> possibleRows = new ArrayList<>();
		Collections.sort(value, compareEssLR);

		int cont = 0;
		double valueToSearch = totalEssLR;
		for (int i = 0; i < value.size(); i++) {
			if (value.get(i).getTotalEssLR() >= valueToSearch) {
				if (cont == 0) {
					valueToSearch = value.get(i).getTotalEssLR();
					possibleRows.add(value.get(i));
				} else {
					if (value.get(i).getTotalEssLR() == valueToSearch) {
						possibleRows.add(value.get(i));
					}
				}
				cont++;
			}
		}
		return possibleRows;
	}

	/** The compare ess LR. */
	/* Comparator for sorting the list by roll no */
	public static Comparator<MinTimeRight> compareEssLR = new Comparator<MinTimeRight>() {
		/* Comparator for sorting the list by roll no */

		@Override
		public int compare(MinTimeRight s1, MinTimeRight s2) {
			// get the ess for the first member

			double essLR1 = s1.getTotalEssLR();
			// get the ess for the second member

			double essLR2 = s2.getTotalEssLR();

			// For ascending order
			return (int) (essLR1 - essLR2);
		}
	};

	/** The compare ess L. */
	/* Comparator for sorting the list by roll no */
	public static Comparator<MinTimeRight> compareEssL = new Comparator<MinTimeRight>() {

		@Override
		/*
		 * Comparator for sorting the list by roll no
		 * 
		 */

		public int compare(MinTimeRight s1, MinTimeRight s2) {
			// get the ess for the first member
			double essL1 = s1.getOnlyEssL();
			// get the ess for the second member
			double essL2 = s2.getOnlyEssL();

			// For ascending order
			return (int) (essL1 - essL2);
		}
	};

	/**
	 * Compute ess values in interval.
	 *
	 * @param includeSilent  the include silent
	 * @param percentManLeft the percent man left
	 * @param startTime      the start time
	 * @param endTime        the end time
	 * @param acqTreemap     the acq treemap
	 * @param silTreemap     the sil treemap
	 * @param allMan         the all man
	 * @return the orbit resources
	 * @throws Exception the exception
	 */
	protected OrbitResources computeEssValuesInInterval(boolean includeSilent, double percentManLeft, long startTime,
			long endTime, TreeMap<Long, EnergyAssociatedToTask> acqTreemap,
			TreeMap<Long, EnergyAssociatedToTask> silTreemap, TreeMap<Long, Maneuver> allMan) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		OrbitResources orbitValues = null;
		try {

			// get the submap of ess from start and stop
			NavigableMap<Long, EnergyAssociatedToTask> subMap = acqTreemap.subMap(startTime, true, endTime, true);

			// get submap of maneuver from start and stop
			NavigableMap<Long, Maneuver> subMapMan = allMan.subMap(startTime, true, endTime, false);

			// initialize all the variable to
			// track the ess and the time
			double totalEssLeft = 0;
			double totalEssRight = 0;
			long totalTimeRight = 0;
			long totalTimeLeft = 0;

			// set up the startTime
			long startTimeLocal = startTime;

			// get the previous element, if exists
			Object prevKey = acqTreemap.lowerKey(startTime);

			// there is a prev acq
			if (prevKey != null) {
				EnergyAssociatedToTask previousOutSide = acqTreemap.get(prevKey); // extract
																					// the
																					// EnergyAssociatedToTask
				Acquisition acqStartsOutsideInterval = (Acquisition) previousOutSide.getTask();

				// logger.info("acq outside interval :" +
				// acqStartsOutsideInterval);
				// logger.info("start interval :" + new Date(startTime));

				// compute borderline case
				if (acqStartsOutsideInterval.getEndTime().getTime() > (startTime)) {
					long updatedStartTime = acqStartsOutsideInterval.getStartTime().getTime();
					subMap = acqTreemap.subMap(updatedStartTime, true, endTime, true);
				}
			}
			// iterate over the element of the submap
			for (Map.Entry<Long, EnergyAssociatedToTask> elementsOfSubMap : subMap.entrySet()) {
				// get the current element
				Acquisition extractedAcq = (Acquisition) elementsOfSubMap.getValue().getTask();
				logger.info("acq in interval :" + extractedAcq);
				if (extractedAcq.getLookSide().equalsIgnoreCase("left")) {
					// compute ess
					totalEssLeft = addEnergy(totalEssLeft, extractedAcq, includeSilent, silTreemap, startTime, endTime);

					// compute time
					// totalTimeLeft = totalTimeLeft + durationOfAcq;
				}
				// if is a right acq
				else {
					// compute ess
					totalEssRight = addEnergy(totalEssRight, extractedAcq, includeSilent, silTreemap, startTime,
							endTime);

					// compute time
					// totalTimeRight = totalTimeRight + durationOfAcq;
				}
			}

			// if there aren't elements in submap of man
			if (subMapMan.size() == 0) {
				// if there are elements left
				if (totalEssLeft > 0) {
					// set the time as total in left
					totalTimeLeft = endTime - startTime;
				} else {
					// set the time as total in right
					totalTimeRight = endTime - startTime;
				}
			}
			// there are maneuvers in interval
			else {
				// initialize the maneuver
				Maneuver man = null;

				// iterate over the maneuver
				for (Map.Entry<Long, Maneuver> elementsOfSubMapMan : subMapMan.entrySet()) {
					// get the i-esim maneuver
					man = elementsOfSubMapMan.getValue();

					long manDuration = man.getEndTime().getTime() - man.getStartTime().getTime();
					long partManToAdd = manDuration;
					// if man is right to left
					if (man.isRightToLeftFlag()) {
						partManToAdd = (long) ((manDuration / 100) * (100 - percentManLeft));
						totalTimeRight = totalTimeRight + (man.getStartTime().getTime() - startTimeLocal)
								+ partManToAdd;
						totalTimeLeft = totalTimeLeft + (manDuration - partManToAdd);

					}

					// if man is left to right
					else {
						partManToAdd = (long) ((manDuration / 100) * (percentManLeft));

						totalTimeLeft = totalTimeLeft + (man.getStartTime().getTime() - startTimeLocal) + partManToAdd;
						totalTimeRight = totalTimeRight + (manDuration - partManToAdd);

					}
					startTimeLocal = man.getEndTime().getTime();
				}

				// if the last man was a R2L
				if (man.isRightToLeftFlag()) {
					// if the end time of maneuver is inside interval
					if (man.getEndTime().getTime() < endTime) {
						System.out.println(
								"adding " + ((endTime - man.getEndTime().getTime()) / 1000) + "to left period");

						// compute the residual side of interval as all left
						// period
						totalTimeLeft = totalTimeLeft + (endTime - man.getEndTime().getTime());
					}
				}
				// if the last man was a L2R
				else {
					// if the end time of the maneuver is inside interval
					if (man.getEndTime().getTime() < endTime) {
						// compute the residual side of interval as all right
						// period
						System.out.println(
								"adding " + ((endTime - man.getEndTime().getTime()) / 1000) + "to right period");
						totalTimeRight = totalTimeRight + (endTime - man.getEndTime().getTime());
					}

				}
			}
			orbitValues = new OrbitResources(totalEssRight, totalEssLeft, totalTimeLeft / 60000, totalTimeRight / 60000,
					new Date(startTime), new Date(endTime));
		} catch (Exception e) {

			logger.error("ERROR : start time of period seems to be after the end time.");
			e.printStackTrace();
			throw new Exception("ERROR : start time of period seems to be after the end time.");
		}

		return orbitValues;
	}

	/**
	 * Find end of next orbit.
	 *
	 * @param from       the from
	 * @param maxTo      the max to
	 * @param acqTreemap the acq treemap
	 * @param manTreemap the man treemap
	 * @return the long
	 */
	protected long findEndOfNextOrbit(long from, long maxTo, TreeMap<Long, EnergyAssociatedToTask> acqTreemap,
			TreeMap<Long, Maneuver> manTreemap) {
		long endOfNextPeriod = maxTo;
		Maneuver manR2L = null;
		Long keyOfNextLeftAcq = null;
		keyOfNextLeftAcq = getNextMan(manTreemap, new Date(from));
		if (keyOfNextLeftAcq != null) {
			manR2L = manTreemap.get(keyOfNextLeftAcq);
			if (manR2L.getStartTime().before(new Date(maxTo))) {
				endOfNextPeriod = manR2L.getStartTime().getTime();
			} else {
				endOfNextPeriod = maxTo;
			}
		}
		return endOfNextPeriod;
	}

	/**
	 * Adds the energy.
	 *
	 * @param partialTotal  the partial total
	 * @param acq           the acq
	 * @param includeSilent the include silent
	 * @param silTreemap    the sil treemap
	 * @param startTime     the start time
	 * @param stopTime      the stop time
	 * @return the double
	 */
	public double addEnergy(double partialTotal, Acquisition acq, boolean includeSilent,
			TreeMap<Long, EnergyAssociatedToTask> silTreemap, long startTime, long stopTime) {
		// initialize the return value
		double total = 0;

		double amountEssForAcq = acq.getEss();
		long durationAcq = (acq.getEndTime().getTime() - acq.getStartTime().getTime());
		long durationInInterval = durationAcq;

		if (acq.getStartTime().getTime() < startTime) {
			durationInInterval = (acq.getEndTime().getTime() - startTime);
		} else if (acq.getEndTime().getTime() > stopTime) {
			durationInInterval = (stopTime - acq.getStartTime().getTime());
		}

		amountEssForAcq = (acq.getEss() * durationInInterval) / durationAcq;

		// if the silent must be included
		if (includeSilent) {
			// extract the energy related to the silent of the acq
			// System.out.println(silTreemap);
			double energyForSilent = silTreemap.lowerEntry(acq.getStartTime().getTime()).getValue().getEssValue();

			// add energy and silent
			total = partialTotal + amountEssForAcq + energyForSilent;
		}
		// if the silent mustn't be included
		else {
			// add only the ess
			total = partialTotal + amountEssForAcq;
		}
		return total;
	}

	/**
	 * Gets the all elements involved.
	 *
	 * @param localStart the local start
	 * @param localEnd   the local end
	 * @param allAcq     the all acq
	 * @return the all elements involved
	 */
	public static List<String> getAllElementsInvolved(long localStart, long localEnd,
			TreeMap<Long, EnergyAssociatedToTask> allAcq) {
		List<String> allAcqInvolved = new ArrayList<>();
		SortedMap<Long, EnergyAssociatedToTask> subMap = allAcq.subMap(localStart, localEnd);
		for (Map.Entry<Long, EnergyAssociatedToTask> subElements : subMap.entrySet()) {
			allAcqInvolved.add(subElements.getValue().getTask().getIdTask());
		}
		return allAcqInvolved;
	}

	/**
	 * Gets the last left acq.
	 *
	 * @param acq        the acq
	 * @param acqTreemap the acq treemap
	 * @param prev       the prev
	 * @return the last left acq
	 */
	public Acquisition getPrevLeftPeriod(Acquisition acq, TreeMap<Long, EnergyAssociatedToTask> acqTreemap,
			boolean prev) {
		// initialize previous acq
		Acquisition previousAcqInLeft = null;

		boolean found = false;

		if (prev) {
			long key = acq.getStartTime().getTime();
			while ((acqTreemap.lowerEntry(key) != null) && !found) {
				previousAcqInLeft = (Acquisition) acqTreemap.lowerEntry(key).getValue().getTask();
				if (previousAcqInLeft.getLookSide().equalsIgnoreCase("left")) {
					found = true;
				} else {
					key = previousAcqInLeft.getStartTime().getTime();
					previousAcqInLeft = null;
				}
			}
		} else {

			long key = acq.getEndTime().getTime();
			while ((acqTreemap.higherEntry(key) != null) && !found) {
				previousAcqInLeft = (Acquisition) acqTreemap.higherEntry(key).getValue().getTask();
				if (previousAcqInLeft.getLookSide().equalsIgnoreCase("left")) {
					found = true;
				} else {
					key = previousAcqInLeft.getEndTime().getTime();
					previousAcqInLeft = null;
				}
			}
		}

		return previousAcqInLeft;
	}

	/**
	 * Gets the last left acq.
	 *
	 * @param acq        the acq
	 * @param manTreemap the man treemap
	 * @param acqTreemap the acq treemap
	 * @return the last left acq
	 */
	protected Acquisition getNextLeftPeriod(Acquisition acq, TreeMap<Long, Maneuver> manTreemap,
			TreeMap<Long, EnergyAssociatedToTask> acqTreemap) {

		// initialize previous maneuver
		Maneuver manL2R = null;

		// initialize previous acq
		Acquisition nextAcqInLeft = null;

		// initialize the key of previous acq
		Object keyOfNextLeftMan = null;

		if (acq.getLookSide().equalsIgnoreCase("left")) {
			// make 2 jumps on maneuvers treemap (first one is for the man l2r
			// that bring back the satellite in right attitude and the second
			// one is the r2l that came back on left attitude. We need to
			// retrieve the first left acquisition in this left period)

			Object nextManKey = getNextMan(manTreemap, acq.getStartTime());

			keyOfNextLeftMan = manTreemap.higherKey(acq.getStartTime().getTime());
			// logger.info("first step : found a man at time " +
			// keyOfNextLeftAcq);
			// if there is a next maneuver
			if (nextManKey != null) {
				keyOfNextLeftMan = manTreemap.higherKey(manTreemap.higherKey(acq.getStartTime().getTime()));
				// logger.info("second step : found a man at time " +
				// keyOfNextLeftAcq);
			}
		} else {
			// make a single jump on maneuvers treemap (one because the first
			// maneuver we meet is the man l2r that bring back the satellite in
			// left attitude. We need to retrieve the first left acquisition in
			// this left period)

			// get the key of next acq
			keyOfNextLeftMan = manTreemap.higherKey(acq.getStartTime().getTime());
		}

		// if there is a next maneuver
		if (keyOfNextLeftMan != null) {

			long time = manTreemap.higherKey(acq.getStartTime().getTime());
			// logger.info("keyOFNextLeftAcq is not null , value :" + time);

			// extract the man
			manL2R = manTreemap.get(time);

			// logger.info("extracted man : " + manL2R);
			// get the acquisition previous to the man just extracted
			Object nextLeftAcqObj = acqTreemap.higherKey(manL2R.getStartTime().getTime());

			// if exist previous
			if (nextLeftAcqObj != null) {
				// extract the acquisition
				nextAcqInLeft = (Acquisition) acqTreemap.higherEntry(manL2R.getStartTime().getTime()).getValue()
						.getTask();

			}
		}
		return nextAcqInLeft;
	}

	/**
	 * Gets the prev man.
	 *
	 * @param manTreemap the man treemap
	 * @param startTime  the start time
	 * @return the prev man
	 */
	public Long getPrevMan(TreeMap<Long, Maneuver> manTreemap, Date startTime) {
		Long nextManId = null;
		boolean found = false;
		if ((manTreemap != null) && !manTreemap.isEmpty()) {
			nextManId = manTreemap.lowerKey(startTime.getTime());
			while (!found && (nextManId != null)) {
				nextManId = manTreemap.lowerKey(startTime.getTime());
				if (nextManId != null) {
					Maneuver man = manTreemap.lowerEntry(startTime.getTime()).getValue();
					if (man.getType().compareTo(ManeuverType.PitchCPS) != 0) {
						found = true;
					} else {
						startTime = man.getStartTime();
					}
				}
			}
		}
		return nextManId;
	}

	/**
	 * Gets the next man.
	 *
	 * @param manTreemap the man treemap
	 * @param startTime  the start time
	 * @return the next man
	 */
	public Long getNextMan(TreeMap<Long, Maneuver> manTreemap, Date startTime) {
		Long nextManId = null;
		boolean found = false;
		if ((manTreemap != null) && !manTreemap.isEmpty()) {
			nextManId = manTreemap.higherKey(startTime.getTime());
			while (!found && (nextManId != null)) {
				nextManId = manTreemap.higherKey(startTime.getTime());
				if (nextManId != null) {
					Maneuver man = manTreemap.higherEntry(startTime.getTime()).getValue();
					if (!man.getType().toString().startsWith("Pitch")) {
						found = true;
					} else {
						startTime = man.getStartTime();
					}
				}
			}
		}
		return nextManId;
	}

	/**
	 * Gets the nearest left time.
	 *
	 * @param listPossibleRows the list possible rows
	 * @param totalEssLeft     the total ess left
	 * @return the nearest left time
	 */
	protected static MinTimeRight getNearestLeftTime(List<MinTimeRight> listPossibleRows, double totalEssLeft) {
		// initialize the element that must be returned
		MinTimeRight nearestEssL = null;

		// sort the element given as input based on ess left
		Collections.sort(listPossibleRows, compareEssL);

		// iterate over the ordered set
		for (int i = 0; i < listPossibleRows.size(); i++) {
			// if the value is more or equal to the referred max time
			if (listPossibleRows.get(i).getOnlyEssL() >= totalEssLeft) {
				// add it to the list
				nearestEssL = listPossibleRows.get(i);

				// exit
				break;
			}
		}
		return nearestEssL;
	}

}
