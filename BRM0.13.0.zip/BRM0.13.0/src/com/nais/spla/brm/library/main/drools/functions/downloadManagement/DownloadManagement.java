/**
 *
 * MODULE FILE NAME: DownloadManagement.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        26 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 26 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.drools.functions.downloadManagement;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.slf4j.Logger;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
import com.nais.spla.brm.library.main.drools.rules.DtoToAcqRule;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.DownloadLogic;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SectorAndVisForPartner;
import com.nais.spla.brm.library.main.ontology.resourceData.SizeOfSectorDwl;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

// TODO: Auto-generated Javadoc
/**
 * The Class DownloadManagement.
 *
 * @author fpedrola
 */
public class DownloadManagement {

	/** The dwl utils. */
	Logger logger = DroolsParameters.getLogger();

	/**
	 * Insert in I download structure.
	 *
	 * @param downloadOrPT            the download or PT
	 * @param allVisInOverlapWithTask the all vis in overlap with task
	 * @param dwlTreeMap              the dwl tree map
	 */
	public void insertInIDownloadStructure(Task downloadOrPT, List<Visibility> allVisInOverlapWithTask,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap) {
		// get the satellite id
		String satId = downloadOrPT.getSatelliteId();

		// create an empty list of string to store where the pt will be stored
		// (on which link)
		List<String> plannedOnLinkOfVis = new ArrayList<>();

		String dwlOrPtUniqueKey = null;

		// detect the type of download
		DownloadLogic dwlLogic = null;

		// if the task is a download
		if (downloadOrPT instanceof Download) {
			// extract and cast to download
			Download dwl = (Download) downloadOrPT;
			dwlOrPtUniqueKey = concatVisIdFromDownload(dwl);

			// if is a gps
			if (dwl.getRelatedTask().startsWith("GPS")) {
				// set the correct DownloadLogic
				dwlLogic = DownloadLogic.GPS;
			}
			// normal download
			else {
				// set the correct DownloadLogic
				dwlLogic = DownloadLogic.DWL;
			}
			// if the download is stored on l2
			if (dwl.isCarrierL2Selection()) {
				// add 2 to the list of used link
				plannedOnLinkOfVis.add("2");
			}
			// if the download is stored on l1
			else {
				// add 1 to the list of used link
				plannedOnLinkOfVis.add("1");
			}
		}
		// if the task is a pt
		else if (downloadOrPT instanceof PassThrough) {
			// set the correct DownloadLogic
			dwlLogic = DownloadLogic.PT;

			// extract and cast to pt
			PassThrough pt = (PassThrough) downloadOrPT;
			dwlOrPtUniqueKey = concatVisIdFromPt(pt);

			// if is stored in double polarization
			if (pt.isDoublePol()) {
				// add both links to the arraylist
				plannedOnLinkOfVis.add("1");
				plannedOnLinkOfVis.add("2");
			}
			// if is stored in single polarization on L2
			else if (pt.isPlannedOnL2()) {
				// add link L2 to the arraylist
				plannedOnLinkOfVis.add("2");
			}
			// if is stored in single polarization on L1
			else {
				// add link L1 to the arraylist
				plannedOnLinkOfVis.add("1");
			}
		}
		// if the task is a paw
		else {
			// set the correct DownloadLogic
			dwlLogic = DownloadLogic.PAW;

			// add both links to the arraylist (nothing can be in overlap with
			// paw)
			plannedOnLinkOfVis.add("1");
			plannedOnLinkOfVis.add("2");
		}

		boolean storedOnVis = false;

		if (downloadOrPT.isDummy()) {
			// this means that is a dummy task, that is not really
			// stored on vis but it's only used to avoid the multiple
			// downlink on same vis and link

			storedOnVis = false;
		} else {
			// this means that is a real task stored on visibility
			storedOnVis = true;
		}

		// if is the
		// first time
		// that the
		// visibility
		// is inserted
		// into the treemap
		// create a new IDownload object
		Date startTimeTask = downloadOrPT.getStartTime();
		Date endTimeTask = downloadOrPT.getEndTime();

		for (int i = 0; i < allVisInOverlapWithTask.size(); i++) {
			Visibility currentVis = allVisInOverlapWithTask.get(i);
			// concatenate the contact counter
			String contactCounterForVis = concatVisId(satId, currentVis);
			// logger.debug("inserting in download treemap partition :" +
			// contactCounterForVis);
			// create a new Idownload
			IDownload newIdwl = new IDownload();

			// et all the parameters
			newIdwl.setRelatedToTask(downloadOrPT.getRelatedTask());
			newIdwl.setTypeOfDwl(dwlLogic);
			newIdwl.setStartTime(startTimeTask);
			newIdwl.setStopTime(endTimeTask);

			if (startTimeTask.getTime() < allVisInOverlapWithTask.get(i).getStartTime().getTime()) {
				newIdwl.setStartTime(allVisInOverlapWithTask.get(i).getStartTime());
			}

			if (endTimeTask.getTime() > allVisInOverlapWithTask.get(i).getEndTime().getTime()) {
				newIdwl.setStopTime(allVisInOverlapWithTask.get(i).getEndTime());
			}

			newIdwl.setDwlOrPt(downloadOrPT);
			newIdwl.setPlannedOn(storedOnVis);

			// if there is a match
			if ((dwlOrPtUniqueKey != null) && dwlOrPtUniqueKey.equalsIgnoreCase(contactCounterForVis)) {
				// flag as realy planned
				newIdwl.setReallyPlanned(true);
			} else {
				// used only as a semaphore, to avoid overlap of dwl/pt/paw
				newIdwl.setReallyPlanned(false);
			}

			// iterate over the plannedOnLinkOfVis
			for (int j = 0; j < plannedOnLinkOfVis.size(); j++) {
				if ((currentVis.getAvailableStartTime(plannedOnLinkOfVis.get(j)).getTime() >= newIdwl.getStartTime()
						.getTime())
						&& (currentVis.getAvailableStartTime(plannedOnLinkOfVis.get(j)).getTime() <= newIdwl
								.getStopTime().getTime())) {
					currentVis.setAvailableStartTime(plannedOnLinkOfVis.get(j), newIdwl.getStopTime());
				}

				if (!dwlTreeMap.containsKey(contactCounterForVis)) {
					/* creating a treemap substructure */
					TreeMap<String, TreeMap<Long, IDownload>> firstTimeforVisInTreeMap = new TreeMap<>();

					/* creating a new download */
					TreeMap<Long, IDownload> newDwl = new TreeMap<>();
					// String keyOfTreeMap = getKeyTreeMap(newIdwl);

					newDwl.put(newIdwl.getStartTime().getTime(), newIdwl);

					/* inserting into the treemap */

					firstTimeforVisInTreeMap.put(plannedOnLinkOfVis.get(j), newDwl);

					/* inserting into the treemap */
					dwlTreeMap.put(contactCounterForVis, firstTimeforVisInTreeMap);

				}

				else { // it isn't the first
						// time that the visibility
						// is insert intreemap

					if (dwlTreeMap.get(contactCounterForVis).containsKey(plannedOnLinkOfVis.get(j))) {
						// if isn't the first time that
						// the link is inserted in
						// treemap, add the new dwl to it
						// String keyOfTreeMap = getKeyTreeMap(newIdwl);
						dwlTreeMap.get(contactCounterForVis).get(plannedOnLinkOfVis.get(j))
								.put(newIdwl.getStartTime().getTime(), newIdwl);

					} else {
						// the link choosen for dwl was
						// never inserted before in
						// treemap, creating a treemap substructure

						TreeMap<Long, IDownload> newDwl = new TreeMap<>();

						// creating a new downloads
						// and add it to treemap
						// String keyOfTreeMap = getKeyTreeMap(newIdwl);

						newDwl.put(newIdwl.getStartTime().getTime(), newIdwl);
						dwlTreeMap.get(contactCounterForVis).put(plannedOnLinkOfVis.get(j), newDwl);
						// logger.trace("DWL inserted in DWL structure ");
					}
				}
			}
		}

	}

	/**
	 * Inits the plan download.
	 *
	 * @param acq                   the acq
	 * @param relatedSto            the related sto
	 * @param allDwlAssociatedToSto the all dwl associated to sto
	 * @param droolsParams          the drools params
	 * @param downloadPriorityQueue the download priority queue
	 * @return true, if successful
	 * @throws Exception the exception
	 */
	public boolean initPlanDownload(Acquisition acq, Storage relatedSto, List<Download> allDwlAssociatedToSto,
			DroolsParameters droolsParams, TreeMap<String, PriorityQueue> downloadPriorityQueue) throws Exception {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// initialized the variable to check if the element is inserted into the
		// priority queue or not
		boolean insertedInQueue = false;

		// initialize a new instance of pdhtManagement
		PdhtManagement pdhtMng = new PdhtManagement();

		// create an instance of dwlUtils
		DownloadUtils dwlUtils = new DownloadUtils();

		// extract the partners related to the acq
		List<Partner> allPartnersRelatedToAcq = dwlUtils.extractAllPartnersRelativeToAcq(acq.getUserInfo(),
				droolsParams);

		logger.info("************* init plan : all partners relative to the current acq :" + allPartnersRelatedToAcq);

		// if there aren't downloads associated with the acq
		if (allDwlAssociatedToSto.size() == 0) {
			logger.info("************* init plan : there aren't previously planned download for this acq");

			// insert the acq in the priority queue
			pdhtMng.insertInPriorityQueue(acq, relatedSto, downloadPriorityQueue, droolsParams);

			insertedInQueue = true;
		}
		// there are others downloads for the current acq
		else {
			logger.info(
					"************* init plan : there are previously planned download for this acq...check for download with delete strategy");

			// create an empty list of associated downloads
			List<Download> onlyDeleteDwlForSto = new ArrayList<>();

			// get the dwl with downlinkStrategy DELETE related to the acq
			onlyDeleteDwlForSto = dwlUtils.getOnlyDeleteDwl(allDwlAssociatedToSto);

			logger.info("************* init plan : get the download delete relative to current acq : "
					+ onlyDeleteDwlForSto);
			// logger.debug("************* init plan : check if exist the
			// download delete relative to current packet store : " +
			// onlyDeleteDwlForSto);

			// iterate over the packets associated
			// to storage relative to acq
			for (int i = 0; i < relatedSto.getPacketsAssociated().size(); i++) {
				// extract i-esim packet
				PacketStore packet = relatedSto.getPacketsAssociated().get(i);
				logger.info("************* init plan for packet : " + packet);

				// for the current packet store check if
				// there is a related download with delete strategy
				Download lastDwlForPs = dwlUtils.checkIfContainsDeleteDwlRelatedToPs(onlyDeleteDwlForSto, packet);
				logger.info("************* init plan lastDwlForPs for packet : " + lastDwlForPs);

				// if there isn't a delete download
				// for this polarization
				if (lastDwlForPs == null) {
					logger.info(
							"************* init plan : the delete download doesn't exists, process residual sectors to download");

					// compute the residual part of download
					processPacketStore(acq, packet, allPartnersRelatedToAcq, allDwlAssociatedToSto,
							downloadPriorityQueue);

					insertedInQueue = true;
				}
				// if there is an associated delete download
				else {
					// nothing to do
					logger.info("************* init plan : the delete download exists, nothing to process");
				}
			}
		}

		return insertedInQueue;
	}

//    public String getKeyTreeMap(IDownload newIdwl)
//    {
//        String key = null;
//        key = newIdwl.getStartTime().getTime() + "";
//        // is a DWL
//        if (newIdwl.getTypeOfDwl().compareTo(DownloadLogic.DWL) == 0)
//        {
//            Download dwl = (Download) newIdwl.getDwlOrPt();
//            key = key + "_" + DownloadLogic.DWL.toString() + "_" + dwl.getContactCounter();
//        }
//        // is a PT
//        else if (newIdwl.getTypeOfDwl().compareTo(DownloadLogic.PT) == 0)
//        {
//            PassThrough pt = (PassThrough) newIdwl.getDwlOrPt();
//            key = key + "_" + DownloadLogic.PT.toString() + "_" + pt.getContactCounterVis();
//        }
//        
//        return key;
//    }

	/**
	 * Gets the key tree map downloads.
	 *
	 * @param newDwl the new dwl
	 * @return the key tree map downloads
	 */
	public String getKeyTreeMapDownloads(Download newDwl) {
		String key = null;
		key = newDwl.getIdTask() + "_" + newDwl.getStartTime().getTime() + "_" + newDwl.getContactCounter() + "_"
				+ newDwl.getUnivoqueVisId();
		return key;
	}

	/**
	 * Removes the from I download structure.
	 *
	 * @param downloadsToRemove the downloads to remove
	 * @param droolsParams      the drools params
	 * @param dwlTreeMap        the dwl tree map
	 */
	/*
	 * remove a download and all the others downloads (dummies) related to the
	 * removed one
	 */
	public void removeFromIDownloadStructure(List<Download> downloadsToRemove, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap) {
		DownloadUtils dwlUtils = new DownloadUtils();

		Logger logger = DroolsParameters.getLogger();

		for (int i = 0; i < downloadsToRemove.size(); i++) {
			List<Visibility> allVisInOverlap = new ArrayList<>();
			List<String> storedOnLink = new ArrayList<>();

			if (downloadsToRemove.get(i) instanceof Download) {
				/* detect in which link the download was stored */

				String plannedOnLink = null;
				Download currentDwl = downloadsToRemove.get(i);
				if (currentDwl.isCarrierL2Selection()) {
					plannedOnLink = "2";
				} else {
					plannedOnLink = "1";
				}
				storedOnLink.add(plannedOnLink);
			}

			// logger.trace("element must be removed from : " + storedOnLink + "
			// link");
			allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(downloadsToRemove.get(i).getStartTime(),
					downloadsToRemove.get(i).getEndTime(), droolsParams.getAllVisibilities(),
					downloadsToRemove.get(i).getSatelliteId());
			logger.debug("get visibility in overlap..." + allVisInOverlap);

			for (int j = 0; j < allVisInOverlap.size(); j++) {
				/*
				 * extract the list of downloads planned on the same link of the one that we
				 * must remove
				 */
				String contactCountForSat = concatVisId(downloadsToRemove.get(i).getSatelliteId(),
						allVisInOverlap.get(j));
				logger.debug("for visibility :" + contactCountForSat);

				for (int k = 0; k < storedOnLink.size(); k++) {
					TreeMap<Long, IDownload> downloadsRelatedToVisAndLink = dwlTreeMap.get(contactCountForSat)
							.get(storedOnLink.get(k));
					if ((downloadsRelatedToVisAndLink != null) && !downloadsRelatedToVisAndLink.isEmpty()) {
						logger.debug("removing element from link :" + storedOnLink.get(k));

						downloadsRelatedToVisAndLink.remove(downloadsToRemove.get(i).getStartTime().getTime());
					}
					Date availableStartTimeForChosenLink = allVisInOverlap.get(j)
							.getAvailableStartTime(storedOnLink.get(k));

					/*
					 * if the task to remove was the last one, update the available start time of
					 * the visibility
					 */
					if (availableStartTimeForChosenLink.getTime() == downloadsToRemove.get(i).getEndTime().getTime()) {
						allVisInOverlap.get(j).setAvailableStartTime(storedOnLink.get(k),
								downloadsToRemove.get(i).getStartTime());
					}
				}
			}
		}
	}

	/**
	 * Removes the from I download structure pt.
	 *
	 * @param ptToRemove   the pt to remove
	 * @param droolsParams the drools params
	 * @param dwlTreeMap   the dwl tree map
	 */
	/*
	 * remove a download and all the others downloads (dummies) related to the
	 * removed one
	 */
	public void removeFromIDownloadStructurePt(List<Task> ptToRemove, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap) {
		// TODO : aggiungere questo metodo quando andiamo a rimuovere tutti gli
		// elementi dal treemap
		DownloadUtils dwlUtils = new DownloadUtils();

		for (int i = 0; i < ptToRemove.size(); i++) {
			List<Visibility> allVisInOverlap = new ArrayList<>();
			List<String> storedOnLink = new ArrayList<>();

			if (ptToRemove.get(i) instanceof PassThrough) {
				/* detect in which link the download was stored */

				PassThrough currentPt = (PassThrough) ptToRemove.get(i);
				if (currentPt.isDoublePol()) {
					storedOnLink.add("1");
					storedOnLink.add("2");
				} else if (currentPt.isPlannedOnL2()) {
					storedOnLink.add("2");
				} else {
					storedOnLink.add("1");
				}
			}

			// logger.trace("element must be removed from : " + storedOnLink + "
			// link");
			allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(ptToRemove.get(i).getStartTime(),
					ptToRemove.get(i).getEndTime(), droolsParams.getAllVisibilities(),
					ptToRemove.get(i).getSatelliteId());
			// logger.trace("get visibility in overlap..." + allVisInOverlap);

			for (int j = 0; j < allVisInOverlap.size(); j++) {
				/*
				 * extract the list of downloads planned on the same link of the one that we
				 * must remove
				 */
				String contactCountForSat = concatVisId(ptToRemove.get(i).getSatelliteId(), allVisInOverlap.get(j));
				// logger.trace("for visibility :" + contactCountForSat);

				for (int k = 0; k < storedOnLink.size(); k++) {
					TreeMap<Long, IDownload> downloadsRelatedToVisAndLink = dwlTreeMap.get(contactCountForSat)
							.get(storedOnLink.get(k));
					if ((downloadsRelatedToVisAndLink != null) && !downloadsRelatedToVisAndLink.isEmpty()) {
						// logger.trace("removing element from link :" +
						// storedOnLink.get(k));

						downloadsRelatedToVisAndLink.remove(ptToRemove.get(i).getStartTime().getTime());
					}
					Date availableStartTimeForChosenLink = allVisInOverlap.get(j)
							.getAvailableStartTime(storedOnLink.get(k));

					/*
					 * if the task to remove was the last one, update the available start time of
					 * the visibility
					 */
					if (availableStartTimeForChosenLink.getTime() == ptToRemove.get(i).getEndTime().getTime()) {
						allVisInOverlap.get(j).setAvailableStartTime(storedOnLink.get(k),
								ptToRemove.get(i).getStartTime());
					}
				}
			}
		}
	}

	/**
	 * Concat vis id.
	 *
	 * @param satelliteId the satellite id
	 * @param visibility  the visibility
	 * @return the string
	 */
	public static String concatVisId(String satelliteId, Visibility visibility) {
		String visId = null;
		if (visibility.getAcqStatId() != null) {
			visId = visibility.getAcqStatId() + "_" + visibility.getContactCounter() + "_"
					+ visibility.getSatelliteId();
		} else {
			DroolsParameters.getLogger().error("acquisition station cannot be null!");
			throw new NullPointerException();
		}
		return visId;
	}

	/**
	 * Concat vis id from download.
	 *
	 * @param dwl the dwl
	 * @return the string
	 */
	public String concatVisIdFromDownload(Download dwl) {
		String visId = dwl.getAcqStatId() + "_" + dwl.getContactCounter() + "_" + dwl.getSatelliteId();

		return visId;
	}

	/**
	 * Concat vis id from pt.
	 *
	 * @param pt the pt
	 * @return the string
	 */
	public String concatVisIdFromPt(PassThrough pt) {
		String visId = pt.getGroundStationId() + "_" + pt.getContactCounterVis() + "_" + pt.getSatelliteId();

		return visId;
	}

	/**
	 * Process packet store.
	 *
	 * @param acq                       the acq
	 * @param packet                    the packet
	 * @param allPartnerAssociatedToAcq the all partner associated to acq
	 * @param allDwl                    the all dwl
	 * @param downloadPriorityQueue     the download priority queue
	 */
	public void processPacketStore(Acquisition acq, PacketStore packet, List<Partner> allPartnerAssociatedToAcq,
			List<Download> allDwl, TreeMap<String, PriorityQueue> downloadPriorityQueue) {
		Logger logger = DroolsParameters.getLogger();
		// create an empty hashmap
		HashMap<String, SectorAndVisForPartner> partnersStillNeedssectors = new HashMap<>();
		String downloadKey = getPriorityKey(acq);

		for (int i = 0; i < allDwl.size(); i++) {
			logger.debug("************* RELATED DWL in INIT PLAN :" + allDwl.get(i));
		}
			// get the size of packet store
			int packetSize = packet.getSize();
			logger.debug("************* polarization :" + packet.getPolarization());

			// iterate over the partners associated to acq
			for (int i = 0; i < allPartnerAssociatedToAcq.size(); i++) {

				// get the i-esim partner
				Partner partner = allPartnerAssociatedToAcq.get(i);
				// logger.debug("partner :" + partner);

				// declare the residual sector to dwl
				int residualSectorToDwl = packetSize;

				// iterate over all the downloads associated with the current
				// acq
				for (int j = 0; j < allDwl.size(); j++) {

					// extract the i-esim download
					Download dwl = allDwl.get(j);
					// logger.debug("RELATED DWL in INIT PLAN :" + dwl);

					// if the download is related to the polarization of the
					// packet
					// store and the
					// list of partners that the download serve is compliant
					// with
					// the list of
					// partners associated with the acq

					// if
					// (dwl.getUgsOwnerList().contains(partner.getPartnerId())&&
					// dwl.getPol().equals(packet.getPolarization())) {
					if (dwl.getUgsOwnerList() != null && dwl.getUgsOwnerList().contains(partner.getPartnerId())
							&& dwl.getPol().equals(packet.getPolarization())) {

						// update the residual sectors to download
						residualSectorToDwl = residualSectorToDwl - dwl.getDownloadedSize();
					}

					if (residualSectorToDwl == 0) {
						break;
					}
				}

				// if the partner still has sectors to download
				if (residualSectorToDwl > 0) {

					// create a new SizeOfSectorDwl element
					SizeOfSectorDwl residualSectors = new SizeOfSectorDwl(residualSectorToDwl, residualSectorToDwl,
							packet.getPolarization());

					// set the effective size with the size of the packet store
					residualSectors.setEffectiveSize(packetSize);

					logger.debug("effective size : " + packetSize);
					// mark as start in previous mission horizon so the related
					// element will not be
					// deleted
					residualSectors.setStartInPrevMh(true);
					logger.debug("partnersStillNeedssectors :" + partnersStillNeedssectors);
					if (!partnersStillNeedssectors.isEmpty()) {
						
						//if there are elements inside the download priority queue
						if (!downloadPriorityQueue.isEmpty() && downloadPriorityQueue.get(downloadKey) != null) {
							logger.debug("download key : " + downloadKey);
								PriorityQueue priority = downloadPriorityQueue.get(downloadKey);
								logger.debug("priority : " + priority);
								if (priority.getSectorsNeededForPartners()
										.containsKey(partner.getPartnerId()) == true) {
									priority.getSectorsNeededForPartners().get(partner.getPartnerId())
											.getSectorsForPartner().add(residualSectors);
									logger.debug("priority with new partner : " + priority);

								} else {
									List<SizeOfSectorDwl> residualSectorsList = new ArrayList<>();
									residualSectorsList.add(residualSectors);

									SectorAndVisForPartner newSectorsForPartner = new SectorAndVisForPartner(
											partner.getAllVisForPartner(), residualSectorsList);
									priority.getSectorsNeededForPartners().put(partner.getPartnerId(),
											newSectorsForPartner);
									logger.debug("priority with new partner : " + priority);

								}
								priority.setPol(packet.getPolarization());
								priority.setRelatedAcq(acq);
								priority.setPriority(downloadKey);
								// priority.getSectorsNeededForPartners().put(partnersStillNeedssectors);
								logger.debug("priority updated : " + priority);
								downloadPriorityQueue.put(downloadKey, priority);

						} 
						//if there aren't elements inside the priority queue
						else {
							PriorityQueue priority = new PriorityQueue();
							priority.setPol(packet.getPolarization());
							priority.setRelatedAcq(acq);
							priority.setPriority(downloadKey);
							priority.setSectorsNeededForPartners(partnersStillNeedssectors);
							downloadPriorityQueue.put(downloadKey, priority);
							logger.debug("priority added 2 : " + priority);

						}

					}
					
					else {
						//if there is a downaload priority for the acq
						if (downloadPriorityQueue.get(downloadKey) != null) {
							PriorityQueue priority = downloadPriorityQueue.get(downloadKey);
							if (priority.getSectorsNeededForPartners().containsKey(partner.getPartnerId()) == true) {
								priority.getSectorsNeededForPartners().get(partner.getPartnerId())
										.getSectorsForPartner().add(residualSectors);

							} 
							//if there isn't a downaload priority for the acq
							else {
								List<SizeOfSectorDwl> residualSectorsList = new ArrayList<>();
								residualSectorsList.add(residualSectors);

								SectorAndVisForPartner newSectorsForPartner = new SectorAndVisForPartner(
										partner.getAllVisForPartner(), residualSectorsList);
								priority.getSectorsNeededForPartners().put(partner.getPartnerId(),
										newSectorsForPartner);
							}
						} else {
							List<SizeOfSectorDwl> residualSectorsList = new ArrayList<>();
							residualSectorsList.add(residualSectors);
							SectorAndVisForPartner newSectorsForPartner = new SectorAndVisForPartner(
									partner.getAllVisForPartner(), residualSectorsList);

							partnersStillNeedssectors.put(partner.getPartnerId(), newSectorsForPartner);

							PriorityQueue priority = new PriorityQueue();
							priority.setPol(packet.getPolarization());
							priority.setRelatedAcq(acq);
							priority.setPriority(downloadKey);
							priority.setSectorsNeededForPartners(partnersStillNeedssectors);
							downloadPriorityQueue.put(downloadKey, priority);
						}
					}
				}
			}

	}

	/**
	 * Creates the dwl.
	 *
	 * @param dwl                 the dwl
	 * @param relatedAcq          the related acq
	 * @param currentVis          the current vis
	 * @param downloadableSectors the downloadable sectors
	 * @param neededPol           the needed pol
	 * @param initialPs           the initial ps
	 * @param finalPs             the final ps
	 * @param partner             the partner
	 * @param numberPs            the number ps
	 * @param carrierL2Selection  the carrier L 2 selection
	 */
	private void createDwl(Download dwl, Acquisition relatedAcq, Visibility currentVis, int downloadableSectors,
			Polarization neededPol, int initialPs, int finalPs, Partner partner, int numberPs,
			boolean carrierL2Selection) {

		// set IdTask
		dwl.setIdTask(relatedAcq.getIdTask());
		// set RelatedTaskId
		dwl.setRelatedTaskId(relatedAcq.getIdTask());

		// set AcqStatId
		dwl.setAcqStatId(currentVis.getAcqStatId());
		// set ContactCounter
		dwl.setContactCounter(currentVis.getContactCounter());
		// set DownloadedSize
		dwl.setDownloadedSize(downloadableSectors);
		// set Pol
		dwl.setPol(neededPol);
		// set InitialSector
		dwl.setInitialSector(initialPs);
		// set FinalSector
		dwl.setFinalSector(finalPs);
		// set PacketStoreStrategy
		dwl.setPacketStoreStrategy(DownlinkStrategy.RETAIN);
		// add partner id to the list of
		// ugsID
		dwl.getUgsOwnerList().add(partner.getPartnerId());
		// set PacketStoreNumber
		dwl.setPacketStoreNumber(numberPs);
		// set CarrierL2Selection
		dwl.setCarrierL2Selection(carrierL2Selection);

	}

	/**
	 * Process delete dwl.
	 *
	 * @param droolsParams   the drools params
	 * @param resFunc        the res func
	 * @param acq            the acq
	 * @param localDownloads the local downloads
	 * @param priority       the priority
	 * @return the list
	 */
	public List<Task> processDeleteDwl(DroolsParameters droolsParams, ResourceFunctions resFunc, Acquisition acq,
			List<Task> localDownloads, PriorityQueue priority) {
		// System.out.println("process delete dwl ");
		List<Task> dwlOnlyH = new ArrayList<>();
		List<Task> dwlOnlyV = new ArrayList<>();
		List<Task> allDownloadsDelete = new ArrayList<>();
		DownloadUtils dwlUtils = new DownloadUtils();
		String polarization = acq.getPolarization().toString();
		polarization = polarization.replace("_", "");

		if (polarization.contains("HV") || polarization.contains("VH")) {
			dwlOnlyH = dwlUtils.getOnlyDwlForPol(localDownloads, Polarization.HH);
			dwlOnlyV = dwlUtils.getOnlyDwlForPol(localDownloads, Polarization.VV);
			allDownloadsDelete.addAll(markDwlAsDeleteIfIsTheLastOne(droolsParams, resFunc,
					priority.getSectorsNeededForPartners(), dwlOnlyH, Polarization.HH));
			allDownloadsDelete.addAll(markDwlAsDeleteIfIsTheLastOne(droolsParams, resFunc,
					priority.getSectorsNeededForPartners(), dwlOnlyV, Polarization.VV));
		} else if (acq.getPolarization().toString().startsWith(Polarization.HH.toString())
				|| acq.getPolarization().toString().startsWith(Polarization.H_H.toString())
				|| acq.getPolarization().toString().startsWith(Polarization.HH_HH.toString())) {
			// System.out.println();
			dwlOnlyH = dwlUtils.getOnlyDwlForPol(localDownloads, Polarization.HH);
			allDownloadsDelete.addAll(markDwlAsDeleteIfIsTheLastOne(droolsParams, resFunc,
					priority.getSectorsNeededForPartners(), dwlOnlyH, Polarization.HH));
		} else {
			dwlOnlyV = dwlUtils.getOnlyDwlForPol(localDownloads, Polarization.VV);
			allDownloadsDelete.addAll(markDwlAsDeleteIfIsTheLastOne(droolsParams, resFunc,
					priority.getSectorsNeededForPartners(), dwlOnlyV, Polarization.VV));
		}
		return allDownloadsDelete;
	}

	/**
	 * Mark dwl as delete if is the last one.
	 *
	 * @param droolsParams             the drools params
	 * @param resFunc                  the res func
	 * @param sectorsNeededForPartners the sectors needed for partners
	 * @param dwlForPolarization       the dwl for polarization
	 * @param polarization             the polarization
	 * @return the list
	 */
	public List<Download> markDwlAsDeleteIfIsTheLastOne(DroolsParameters droolsParams, ResourceFunctions resFunc,
			HashMap<String, SectorAndVisForPartner> sectorsNeededForPartners, List<Task> dwlForPolarization,
			Polarization polarization) {

		List<Download> allDeletedDwl = new ArrayList<>();
		if (dwlForPolarization.size() > 0) {
			DownloadUtils.sortTasksByStartTime(dwlForPolarization);
			int contDonePartner = 0;
			for (Map.Entry<String, SectorAndVisForPartner> sectorsForPartner : sectorsNeededForPartners.entrySet()) {
				// logger.debug("for partner id : " +
				// sectorsForPartner.getKey());

				// System.out.println(sectorsForPartner.getValue().getSectorsForPartner().get(0));
				// logger.debug("polarization : " +
				// sectorsForPartner.getValue().getSectorsForPartner());

				int sectorsRelatedToPartner = 0;

				if (sectorsForPartner.getValue().getSectorsForPartner().get(0).getPol() == polarization) {
					sectorsRelatedToPartner = sectorsForPartner.getValue().getSectorsForPartner().get(0).getTotalSize();
				} else {
					sectorsRelatedToPartner = sectorsForPartner.getValue().getSectorsForPartner().get(1).getTotalSize();
					//
					// if
					// ((sectorsForPartner.getValue().getSectorsForPartner().size()
					// > 1) &&
					// (sectorsForPartner.getValue().getSectorsForPartner().get(1)
					// != null))
					// {
					// sectorsRelatedToPartner =
					// sectorsForPartner.getValue().getSectorsForPartner().get(1).getTotalSize();
					// }
				}

				int totalSectorsDownloaded = 0;
				// logger.debug("sectors needed : " +
				// sectorsForPartner.getValue());
				for (int i = 0; i < dwlForPolarization.size(); i++) {
					Download dwl = (Download) dwlForPolarization.get(i);

					if (dwl.getUgsOwnerList().contains(sectorsForPartner.getKey())) {
						// logger.debug("dwl final sector : " +
						// dwl.getFinalSector());

						if (dwl.getFinalSector() == sectorsRelatedToPartner) {
							totalSectorsDownloaded = sectorsRelatedToPartner;
						} else {
							totalSectorsDownloaded = totalSectorsDownloaded
									+ (dwl.getFinalSector() - dwl.getInitialSector());
						}
					}

					List<Download> allDwl = resFunc.getDownloadAssociatedToSat(dwl.getSatelliteId());
					// logger.debug("add dwl to list " + allDwl);
					if (!allDwl.contains(dwl)) {
						allDwl.add(dwl);
					}
				}
				if (totalSectorsDownloaded == sectorsRelatedToPartner) {
					contDonePartner++;
				}
			}
			if (contDonePartner == sectorsNeededForPartners.size()) {
				// done for allpartners
				Download lastDwl = (Download) dwlForPolarization.get(dwlForPolarization.size() - 1);
				lastDwl.setPacketStoreStrategy(DownlinkStrategy.DELETE);
				allDeletedDwl.add(lastDwl);
				// resFunc.getAcqNeedsDownloads(lastDwl.getSatelliteId()).remove(lastDwl.get)
			}
		}
		return allDeletedDwl;
	}

	/**
	 * Download with priority queue.
	 *
	 * @param elementPriority the element priority
	 * @param droolsParams    the drools params
	 * @param downloadTreeMap the download tree map
	 * @param resFunc         the res func
	 * @param satId           the sat id
	 * @return the list
	 */
	public List<Task> downloadWithPriorityQueue(PriorityQueue elementPriority, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, ResourceFunctions resFunc,
			String satId) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get the satellite properties
		// relative to the current sat id
		SatelliteProperties satProp = droolsParams.getSatWithId(satId).getSatelliteProperties();

		// get the rate of downlinkChannel
		double downlinkPerChannel = satProp.getDownlinkPerChannel();
		DownloadUtils dwlUtils = new DownloadUtils();
		Date updatedAvailableStart = null;

		// initialize the carrierL2selection
		// to false (first download will be on
		// L1)
		boolean carrierL2Selection = false;

		// create an empty list of tasks
		List<Task> localDownloads = new ArrayList<>();

		// initialize first usable packet
		// store number (from 1 to 4 are reserved
		// for gps data)
		int numberPs = 5;

		// receive the acquisition
		Acquisition relatedAcq = elementPriority.getRelatedAcq();
		BicUtils bu = new BicUtils();

		// iterate over all the partners associated
		// with the current element in priority
		for (Map.Entry<String, SectorAndVisForPartner> elementsInHashMap : elementPriority.getSectorsNeededForPartners()
				.entrySet()) {
			// extract all the sector for i-esim
			// partner for the current polarization
			for (int i = 0; i < elementsInHashMap.getValue().getSectorsForPartner().size(); i++) {
				// extract the SizeOfSectorDwl
				// for the current partner for current pol
				SizeOfSectorDwl elementSize = elementsInHashMap.getValue().getSectorsForPartner().get(i);
				logger.debug("residual sectors to dwl for partner : " + elementsInHashMap.getKey() + ":"
						+ elementSize.getResidualSize());
				// logger.debug("for polarization : " + elementSize.getPol());

				// extract the partner
				Partner partner;
					partner = bu.findPartnerInList(elementsInHashMap.getKey(), droolsParams.getAllPartners());
					// logger.debug("for partner : " + partner.getPartnerId());

					TreeMap<String, Visibility> visAssociatedToDtoMap = dwlUtils
							.getAllVisFromADate(relatedAcq.getStartTime(), relatedAcq, partner, droolsParams);

					boolean retryOnSameLink = true;
					logger.debug("retryOnSameLink" + retryOnSameLink);
					// get the total size to download
					// for the current partner
					double totalSize = elementSize.getTotalSize();

					// get the residual size that must be
					// download for the current partner
					double residualSize = elementSize.getResidualSize();

					// get the polarization
					Polarization neededPol = elementSize.getPol();
					// logger.debug("packet size : " + residualSize);

					// if there is at least a visibility associated
					if (!visAssociatedToDtoMap.isEmpty()) {
						// iterate over all the visibilities
						for (Map.Entry<String, Visibility> visibilityIterator : visAssociatedToDtoMap.entrySet()) {
							// if the partner must still download something
							if (residualSize > 0) {
								// get the current vis
								Visibility currentVis = visibilityIterator.getValue();
								// logger.trace("current vis : " + currentVis);

								// if extracted vis is in overlap or is next to
								// acq
								if ((((currentVis.getSatelliteId()
										.contains(elementPriority.getRelatedAcq().getSatelliteId()))
										&& (((currentVis.getStartTime().getTime() <= relatedAcq.getEndTime().getTime())
												&& (currentVis.getEndTime()
														.getTime() >= (relatedAcq.getStartTime().getTime())))
												|| (currentVis.getStartTime().getTime() >= relatedAcq.getStartTime()
														.getTime()))))) {
//                                      
//                                        while(retryOnSameLink)
//                                        {
									if (residualSize > 0) {
										boolean existAnotherPartOfDwlOnExternalStation = false;

										// if the visibility has the
										// current partner as owner
										if ((!currentVis.isExternal()
												&& partner.getPartnerId().equalsIgnoreCase(currentVis.getOwnerId()))
												|| currentVis.isBackUp()) {
											// check if exists another
											// part of the same download
											// on other external visibilities
											existAnotherPartOfDwlOnExternalStation = dwlUtils
													.findIfThereArePartOfDownloadOnExternalStation(
															elementPriority.getRelatedAcq().getIdTask(),
															elementSize.getPol(), partner.getPartnerId(),
															droolsParams.getAllVisibilities(), localDownloads);
										}

										// if the visibility is external or
										// has the current partner as owner
										if (currentVis.isBackUp() || ((currentVis.getOwnerId() == null)
												|| partner.getPartnerId().equalsIgnoreCase(currentVis.getOwnerId())
												|| currentVis.isExternal())) {
											// if there aren't others part of dwl on
											// other vis
											if (!existAnotherPartOfDwlOnExternalStation) {
												double downloadableSectors = residualSize;

												int initialPs = 1;
												int finalPs = 1;

												if (elementSize.isStartInPrevMh()) {
													initialPs = elementSize.getEffectiveSize()
															- elementSize.getResidualSize();
												}

												if (totalSize > residualSize) {
													initialPs = (int) (totalSize - residualSize);
												}
												Download anotherDwlOnVis = dwlUtils
														.findIfThereAreAnotherDownloadForSamePsOnSameVis(
																relatedAcq.getIdTask(), neededPol, initialPs,
																currentVis, localDownloads);
												if (anotherDwlOnVis == null) {
													long gapTillNextPtOrEndOfVis = 0;
													String maxLink = null;
													carrierL2Selection = false;
													maxLink = "1";
													if (currentVis.getAvailableStartTimeL1()
															.after(currentVis.getAvailableStartTimeL2())) {
														maxLink = "2";
														carrierL2Selection = true;
													}
													Date availableStartTime = currentVis.getAvailableStartTime(maxLink);
													updatedAvailableStart = currentVis.getAvailableStartTime(maxLink);
													List<Date> startOfNextPT = dwlUtils.findNextPtOnSameVisAndSameLink(
															relatedAcq.getStartTime(), relatedAcq.getSatelliteId(),
															currentVis, maxLink, downloadTreeMap);
													List<Date> startOfNextPTAfterNextPt = new ArrayList<>();
													boolean useNextptOrPawAsStart = false;
													if (updatedAvailableStart.before(relatedAcq.getEndTime())) {
														updatedAvailableStart = relatedAcq.getEndTime();
													}
													if (startOfNextPT.get(0).getTime() <= availableStartTime
															.getTime()) {
														updatedAvailableStart = startOfNextPT.get(1);
														startOfNextPTAfterNextPt = dwlUtils
																.findNextPtOnSameVisAndSameLink(startOfNextPT.get(1),
																		relatedAcq.getSatelliteId(), currentVis,
																		maxLink, downloadTreeMap);
														gapTillNextPtOrEndOfVis = startOfNextPTAfterNextPt.get(0)
																.getTime() - updatedAvailableStart.getTime();
														useNextptOrPawAsStart = true;
													}

													else {
														gapTillNextPtOrEndOfVis = startOfNextPT.get(0).getTime()
																- updatedAvailableStart.getTime();
													}

													long psDurationInMilliSec = (long) (((downloadableSectors
															* satProp.getSingleSectorDimension())
															/ (downlinkPerChannel / 8)) * 1000);

													double sectorsOfVis = java.lang.Math
															.floor((((gapTillNextPtOrEndOfVis / 1000)
																	* (downlinkPerChannel / 8))
																	/ satProp.getSingleSectorDimension()));

													Download dwl = new Download(relatedAcq.getSatelliteId());
													dwl.setUnivoqueVisId(carrierL2Selection + "");

													// check if there are others
													// downloads with same start
													// time or if the previous
													// download for same visibility
													// and link is a pt or a retain
													// one.

													updatedAvailableStart = checkDownloadConstraintOnVis(
															updatedAvailableStart, carrierL2Selection, downloadTreeMap,
															currentVis, maxLink, satProp.getMinTimeDownloadDelay(),
															droolsParams);

													dwl.setStartTime(updatedAvailableStart);

													boolean possibleToDwl = true;
													if (gapTillNextPtOrEndOfVis <= 0 || psDurationInMilliSec < 1000) {
														possibleToDwl = false;
														retryOnSameLink = false;
														dwl.setEndTime(dwl.getStartTime());
													} else if (gapTillNextPtOrEndOfVis < psDurationInMilliSec)

													{
														dwl.setEndTime(startOfNextPT.get(0));
														if (useNextptOrPawAsStart) {
															dwl.setEndTime(startOfNextPTAfterNextPt.get(0));
															updatedAvailableStart = startOfNextPTAfterNextPt.get(1);
														} else {
															updatedAvailableStart = startOfNextPT.get(1);
														}
														residualSize = residualSize - sectorsOfVis;
														downloadableSectors = totalSize - residualSize;
														finalPs = (int) (initialPs + downloadableSectors);
														elementSize.setResidualSize((int) residualSize);
													} else {

														dwl.setEndTime(new Date(
																dwl.getStartTime().getTime() + psDurationInMilliSec));

														updatedAvailableStart = dwl.getEndTime();
														if (residualSize < totalSize) {
															// not the first
															// download
															// for this ps for this
															// partner

															finalPs = (int) (initialPs + downloadableSectors);
														}
														finalPs = (int) (initialPs + downloadableSectors);
														residualSize = 0;

														elementSize.setResidualSize((int) residualSize);
														retryOnSameLink = false;
													}

													long gap = dwl.getEndTime().getTime()
															- dwl.getStartTime().getTime();

													if (possibleToDwl && (downloadableSectors > 0) && gap >= 1000) {

														createDwl(dwl, relatedAcq, currentVis,
																(int) downloadableSectors, neededPol, initialPs,
																finalPs, partner, numberPs, carrierL2Selection);

														if (carrierL2Selection) {
															currentVis.setAvailableStartTimeL2(dwl.getEndTime());
														} else {
															currentVis.setAvailableStartTimeL1(dwl.getEndTime());
														}
														dwl.setPriority(relatedAcq.getPriority());

														// add the new dwl to the
														// list
														localDownloads.add(dwl);
//                                                            
//                                                            // IF BOTH CARRIER LINK
//                                                            // STARTED AT SAME TIME :
//                                                            // UPDATE THE UNUSED ONE OF
//                                                            // THE MINTIMEDOWNLOADDELAY
//                                                            if (currentVis.getAvailableStartTimeL1().getTime() == currentVis.getAvailableStartTimeL2().getTime())
//                                                            {
//                                                                Date newStarTTime = new Date(
//                                                                        currentVis.getAvailableStartTimeL1().getTime() + satProp.getMinTimeDownloadDelay());
//                                                                
//                                                                if (maxLink.contains("1"))
//                                                                {
//                                                                    currentVis.setAvailableStartTimeL2(newStarTTime);
//                                                                }
//                                                                else
//                                                                {
//                                                                    currentVis.setAvailableStartTimeL1(newStarTTime);
//                                                                }
//                                                            }
//                                                            
														// update available start
														// time
														currentVis.setAvailableStartTime(maxLink,
																updatedAvailableStart);

														//
														numberPs++;

														// detect all the
														// visibilities in overlap
														// with the
														// just created download
														List<Visibility> allVisInOverlapWithDwl = dwlUtils
																.findAllVisInOverlapWithDate(dwl.getStartTime(),
																		dwl.getEndTime(),
																		droolsParams.getAllVisibilities(), satId);

														// insert into the dwl
														// treemap (1 instance for
														// every
														// visibility in overlap
														// with the download)
														insertInIDownloadStructure(dwl, allVisInOverlapWithDwl,
																downloadTreeMap);
													} else {
														possibleToDwl = false;
													}
												}

												// there is another download on same vis
												else {
													// logger.trace("another dwl ugs
													// owner list : " +
													// anotherDwlOnVis.getUgsOwnerList());
													// update residual size
													elementSize.setResidualSize(elementSize.getResidualSize()
															- (anotherDwlOnVis.getFinalSector()
																	- anotherDwlOnVis.getInitialSector()));
													residualSize = elementSize.getResidualSize();

													if (residualSize == 0) {
														retryOnSameLink = false;
													}
													// if the acq hasx a i2s info
													if (elementPriority.getRelatedAcq().getDi2sInfo() != null) {
														// extract the slave id
														String slaveId = elementPriority.getRelatedAcq().getDi2sInfo()
																.getPartnerId();
														String currentPartnerId = partner.getPartnerId();
														// if opther dwl is reerred
														// to
														// the slave and the current
														// not
														if ((anotherDwlOnVis.getUgsOwnerList().contains(slaveId)
																&& !currentPartnerId.equalsIgnoreCase(slaveId))
																|| (!anotherDwlOnVis.getUgsOwnerList().contains(slaveId)
																		&& currentPartnerId
																				.equalsIgnoreCase(slaveId))) {
															// add di2s info
															anotherDwlOnVis.setDi2sInfo(
																	elementPriority.getRelatedAcq().getDi2sInfo());
														}
													}
													// add the partner id to the
													// list of the other dwl
													anotherDwlOnVis.getUgsOwnerList().add(partner.getPartnerId());
												}
											}

										} else {
											// annot dwl on this vis, try with next.
											// logger.trace("cannot dwl on this vis,
											// try with next.");
											continue;
										}

									} else {
										retryOnSameLink = false;
									}
									// }

								}

							}
						}
					} else {
						logger.info("NO VALID VIS FOR ACQ");
					}
			}
		}
		processDeleteDwl(droolsParams, resFunc, relatedAcq, localDownloads, elementPriority);

		return localDownloads;
	}

	/**
	 * Check download constraint on vis.
	 *
	 * @param updatedAvailableStart the updated available start
	 * @param carrierL2Selection    the carrier L 2 selection
	 * @param downloadTreeMap       the download tree map
	 * @param currentVis            the current vis
	 * @param maxLink               the max link
	 * @param minTimeDownloadDelay  the min time download delay
	 * @param droolsParams          the drools params
	 * @return the date
	 */
	public Date checkDownloadConstraintOnVis(Date updatedAvailableStart, boolean carrierL2Selection,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, Visibility currentVis,
			String maxLink, int minTimeDownloadDelay, DroolsParameters droolsParams) {
		// check if there are other downloads closer than configurable time for
		// the same satellite
		Date downloadTooClose = getDownloadCloserThanGivenTime(updatedAvailableStart, carrierL2Selection,
				downloadTreeMap, currentVis, maxLink, minTimeDownloadDelay, droolsParams);

		// if there is a download too close (or with the same start time of the
		// current one) to the current one
		if (downloadTooClose != null) {
			// add millisec to a date
			// downloadTooClose = addMillisecToDate(downloadTooClose, minTimeDownloadDelay);
		} else {
			// invoke the method to check if the previous download is a retain one or a
			// passthrough
			boolean previousIsRetainOrPt = checkIfPreviousIsRetainOrPt(updatedAvailableStart, downloadTreeMap,
					currentVis, maxLink, minTimeDownloadDelay);

			// if the previous download is a valid one
			if (previousIsRetainOrPt) {
				// add the gap time
				downloadTooClose = addMillisecToDate(updatedAvailableStart, minTimeDownloadDelay);
			} else {
				downloadTooClose = updatedAvailableStart;
			}
		}
		return DroolsUtils.getDateInMilliseconds(downloadTooClose);
	}

	/**
	 * Check if previous is retain or pt.
	 *
	 * @param updatedAvailableStart the updated available start
	 * @param downloadTreeMap       the download tree map
	 * @param currentVis            the current vis
	 * @param maxLink               the max link
	 * @param minTimeDownloadDelay  the min time download delay
	 * @return true, if successful
	 */
	private boolean checkIfPreviousIsRetainOrPt(Date updatedAvailableStart,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, Visibility currentVis,
			String maxLink, int minTimeDownloadDelay) {
		// initialize the boolean variable that must be returned
		boolean previsPtOrRetain = false;

		// create an univoque id for the current satellite
		String contactCounterForVis = concatVisId(currentVis.getSatelliteId(), currentVis);

		// if there are downloads related to the current vis
		if (downloadTreeMap.containsKey(contactCounterForVis)) {
			//
			TreeMap<String, TreeMap<Long, IDownload>> allDwlForVis = downloadTreeMap.get(contactCounterForVis);
			if (allDwlForVis.get(maxLink) != null) {
				TreeMap<Long, IDownload> allDwlForLink = allDwlForVis.get(maxLink);
				if (!allDwlForLink.isEmpty() && allDwlForLink.lowerEntry(updatedAvailableStart.getTime()) != null) {
					IDownload previousDwl = allDwlForLink.lowerEntry(updatedAvailableStart.getTime()).getValue();
					if (previousDwl.getDwlOrPt() instanceof Download) {
						// check if is a RETAIN one
						Download dwl = (Download) previousDwl.getDwlOrPt();
						if (dwl.getPacketStoreStrategy().compareTo(DownlinkStrategy.RETAIN) == 0) {
							previsPtOrRetain = true;
						}
					} else if (previousDwl.getDwlOrPt() instanceof PassThrough) {
						previsPtOrRetain = true;
					}
				}
			}
		}
		return previsPtOrRetain;
	}

	/**
	 * Gets the download closer than given time.
	 *
	 * @param updatedAvailableStart the updated available start
	 * @param carrierL2Selection    the carrier L 2 selection
	 * @param downloadTreeMap       the download tree map
	 * @param currentVis            the current vis
	 * @param maxLink               the max link
	 * @param minTimeDownloadDelay  the min time download delay
	 * @param droolsParams          the drools params
	 * @return the download closer than given time
	 */
	private Date getDownloadCloserThanGivenTime(Date updatedAvailableStart, boolean carrierL2Selection,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, Visibility currentVis,
			String maxLink, int minTimeDownloadDelay, DroolsParameters droolsParams) {
		// initialize the returned date with the date given as input
		Date returnedDate = null;

		// create a new treemap where will be inserted the downloads ordered by time
		TreeMap<Long, Download> allDownloadOrderedByTime = new TreeMap<Long, Download>();

		// get all the downloads planned for the satellite of the vis
		TreeMap<String, Download> allDwl = getAllFromTreeMap(currentVis.getSatelliteId(), droolsParams, downloadTreeMap,
				null);

		// iterate over the downloads
		for (Map.Entry<String, Download> downloadIterator : allDwl.entrySet()) {
			// insert into the new download treemap
			allDownloadOrderedByTime.put(downloadIterator.getValue().getStartTime().getTime(),
					downloadIterator.getValue());
		}

		// get the element with the start time equals or immediatly before the date
		// given as input
		if (allDownloadOrderedByTime.floorEntry(updatedAvailableStart.getTime()) != null) {
			// if exist a download, extract it
			Download previousDwl = allDownloadOrderedByTime.floorEntry(updatedAvailableStart.getTime()).getValue();

			//
			if (previousDwl.isCarrierL2Selection() == carrierL2Selection) {
				double gap = updatedAvailableStart.getTime() - previousDwl.getEndTime().getTime();

				if (gap <= minTimeDownloadDelay) {
					if (updatedAvailableStart.getTime() < previousDwl.getEndTime().getTime()) {
						updatedAvailableStart = previousDwl.getEndTime();
					}
					returnedDate = addMillisecToDate(updatedAvailableStart, minTimeDownloadDelay);
				}
			} else {
				double gap = updatedAvailableStart.getTime() - previousDwl.getStartTime().getTime();
				if (gap < minTimeDownloadDelay) {
					returnedDate = addMillisecToDate(updatedAvailableStart, minTimeDownloadDelay);
				}
			}
		}
		return DroolsUtils.getDateInMilliseconds(returnedDate);
	}

	/**
	 * Conver date from long.
	 *
	 * @param timeInLong the time in long
	 * @return the date
	 */
	public static Date converDateFromLong(long timeInLong) {
		// Converting milliseconds to Date using Calendar
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timeInLong);

		return cal.getTime();
	}

	/**
	 * Adds the millisec to date.
	 *
	 * @param date       the date
	 * @param timeInLong the time in long
	 * @return the date
	 */
	public static Date addMillisecToDate(Date date, long timeInLong) {
		Calendar timeout = Calendar.getInstance();
		timeout.setTimeInMillis(date.getTime() + timeInLong);
		return DroolsUtils.getDateInMilliseconds(timeout.getTime());
	}

	/**
	 * Persist dwl.
	 *
	 * @param localDwlAssociatedToElement the local dwl associated to element
	 * @param downloadTreeMap             the download tree map
	 * @param droolsParams                the drools params
	 * @param satId                       the sat id
	 */
	public void persistDwl(List<Task> localDwlAssociatedToElement,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, DroolsParameters droolsParams,
			String satId) {
		DownloadUtils dwlUtils = new DownloadUtils();

		// if the acquisition has associated downloads
		if (!localDwlAssociatedToElement.isEmpty()) {
			// insert all the new downloads in dwl treeMap
			for (int i = 0; i < localDwlAssociatedToElement.size(); i++) {
				// extract the i-esim download
				Download currentDwl = (Download) localDwlAssociatedToElement.get(i);

				// detect all the visibilities in overlap with the
				// just created download
				List<Visibility> allVisInOverlapWithDwl = dwlUtils.findAllVisInOverlapWithDate(
						currentDwl.getStartTime(), currentDwl.getEndTime(), droolsParams.getAllVisibilities(), satId);

				// insert into the dwl treemap (1 instance for every
				// visibility in overlap with the download)
				this.insertInIDownloadStructure(localDwlAssociatedToElement.get(i), allVisInOverlapWithDwl,
						downloadTreeMap);
			}
		}
	}

//    /**
//     * Removes the download.
//     *
//     * @param download
//     *            the download
//     * @param allVis
//     *            the all vis
//     */
//    public void removeDownload(Download download, List<Visibility> allVis)
//    {
//        String choosenLink = "1";
//        for (int i = 0; i < allVis.size(); i++)
//        {
//            if (allVis.get(i).getContactCounter() == download.getContactCounter())
//            {
//                if (download.isCarrierL2Selection())
//                {
//                    choosenLink = "2";
//                }
//                if (download.getEndTime().getTime() == allVis.get(i).getAvailableStartTime(choosenLink).getTime())
//                {
//                    long downloadDuration = download.getEndTime().getTime() - download.getStartTime().getTime();
//                    allVis.get(i).setAvailableStartTime(choosenLink, new Date(allVis.get(i).getAvailableStartTime(choosenLink).getTime() - downloadDuration));
//                }
//            }
//        }
//    }
//    
	/**
	 * Removes the all downloads except PT.
	 *
	 * @param satId           the sat id
	 * @param droolsParams    the drools params
	 * @param downloadTreeMap the download tree map
	 * @param resFunc         the res func
	 * @return the list
	 */
	public List<Download> removeAllDownloadsExceptPT(String satId, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, ResourceFunctions resFunc) {

		// get the satellite relative to the current satId
		Satellite sat = droolsParams.getSatWithId(satId);

		// create an empty list of downloads
		List<Download> removedDwl = new ArrayList<>();
		// get the list of downloads planned for the current satellite
		List<Download> allDwlAsList = resFunc.getDownloadAssociatedToSat(satId);

		// if the list of downloads contains at least an element
		if ((downloadTreeMap != null) && !downloadTreeMap.isEmpty()) {
			// iterate over the visibilty associated to the satellite
			for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {
				// get the current vis
				Visibility currentVis = droolsParams.getAllVisibilities().get(i);
				if (currentVis.getSatelliteId().contains(satId)) {
					// if (currentVis.getStartTime().getTime() >=
					// droolsParams.getCurrentMH().getStart().getTime())
					// {
					// create an unique identifier for the current
					// visibility
					// (satId + contact counter)
					String visIdForSat = concatVisId(sat.getSatelliteId(), currentVis);

					// clear the available start time for both link,
					// restoring
					// them to their initial value
					currentVis.setAvailableStartTimeL1(currentVis.getStartTime());
					currentVis.setAvailableStartTimeL2(currentVis.getStartTime());

					// if there are elements planned on the current
					// visibility
					if (downloadTreeMap.containsKey(visIdForSat)) {
						// extract the element relative to the current vis
						TreeMap<String, TreeMap<Long, IDownload>> elementsOnVis = downloadTreeMap.get(visIdForSat);

						// iterate over them
						for (Map.Entry<String, TreeMap<Long, IDownload>> allElementsInVis : elementsOnVis.entrySet()) {
							// create a list of start time of element that
							// must
							// be removed from map
							List<Long> keyAssociatedToDwlToRemove = new ArrayList<>();

							// iterate over the tasks planned on current
							// link
							for (Map.Entry<Long, IDownload> allDwl : allElementsInVis.getValue().entrySet()) {
								// if the i-esim task is a download
								if (allDwl.getValue().getTypeOfDwl().equals(DownloadLogic.DWL)) {
									// if it is correctly populated
									if (allDwl.getValue().getDwlOrPt() != null) {
										// if it isn't a dummy task (dummy
										// task
										// : task used only in case of
										// multiple
										// visibilities overlapped, to
										// ensure
										// that is avoided the case of
										// multiple
										// download on same link at same
										// time
										// if
										// (allDwl.getValue().isReallyPlanned())
										// {
										// cast and extract the download
										Download currentDwl = (Download) allDwl.getValue().getDwlOrPt();

										// if the download is removable
										if ((currentDwl.isRemovableFlag() == true) && !currentDwl.isPreviousMh()) {
											// add to the list of element
											// that must be removed
											removedDwl.add(currentDwl);

											// removing element from treemap
											// logger.debug("\n key
											// associated to dwl to remove :
											// " +
											// allDwl.getKey());

											// track the start time of the
											// element that must be removed
											// and insert it into the list
											// of keys
											keyAssociatedToDwlToRemove.add(allDwl.getKey());

											// iterate over the list of
											// download relative to the
											// current satellite
											for (int j = 0; j < allDwlAsList.size(); j++) {
												// if the i-esim element
												// match with the current
												// download to remove
												if (allDwlAsList.get(j).equals(currentDwl)) {
													// remove also from list
													allDwlAsList.remove(j);

													// escape
													break;
												}
											}
										}
										// }
									}
								}
							}
							// if there are elements to remove
							if (!keyAssociatedToDwlToRemove.isEmpty()) {
								// iterate over them
								for (int j = 0; j < keyAssociatedToDwlToRemove.size(); j++) {

									elementsOnVis.get(allElementsInVis.getKey())
											.remove(keyAssociatedToDwlToRemove.get(j));
								}
							}
						}
					}
					// }
				}
			}
		}
		return removedDwl;
	}

	/**
	 * Gets the all dwl from tree map.
	 *
	 * @param satId           the sat id
	 * @param droolsParams    the drools params
	 * @param downloadTreeMap the download tree map
	 * @return the all dwl from tree map
	 */
	public List<Download> getAllDwlFromTreeMap(String satId, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap) {

		// get the satellite with the id given as input
		Satellite sat = droolsParams.getSatWithId(satId);

		// create an empty list of downloads
		List<Download> removedDwl = new ArrayList<>();

		// if there are elements
		if ((downloadTreeMap != null) && !downloadTreeMap.isEmpty()) {
			// iterate over all the visibilities
			for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {
				// concatenate the satId with the contact counter of the
				// visibility
				String visIdForSat = concatVisId(sat.getSatelliteId(), droolsParams.getAllVisibilities().get(i));

				// if there are other downloads for the current vis
				if (downloadTreeMap.containsKey(visIdForSat)) {

					// get the elements related to the current vis
					TreeMap<String, TreeMap<Long, IDownload>> elementsOnVis = downloadTreeMap.get(visIdForSat);

					// iterate over them
					for (Map.Entry<String, TreeMap<Long, IDownload>> allElementsInVis : elementsOnVis.entrySet()) {
						// get all downloads
						for (Map.Entry<Long, IDownload> allDwl : allElementsInVis.getValue().entrySet()) {

							// if the element is a download
							if ((allDwl.getValue().getTypeOfDwl().compareTo(DownloadLogic.DWL) == 0)
									&& allDwl.getValue().isReallyPlanned()) {
								// extract the download
								Download currentDwl = (Download) allDwl.getValue().getDwlOrPt();

								// if is not contained in list
								if (!removedDwl.contains(currentDwl)) {
									// add to the list
									removedDwl.add(currentDwl);
								}
							}
						}
					}
				}
			}
		}
		return removedDwl;
	}

	/**
	 * Gets the all dwl from tree map GPS.
	 *
	 * @param satId           the sat id
	 * @param droolsParams    the drools params
	 * @param downloadTreeMap the download tree map
	 * @return the all dwl from tree map GPS
	 */
	public static List<Download> getAllDwlFromTreeMapGPS(String satId, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap) {

		// get the satellite with the id given as input
		Satellite sat = droolsParams.getSatWithId(satId);

		// create an empty list of downloads
		List<Download> removedDwl = new ArrayList<>();

		// if there are elements
		if ((downloadTreeMap != null) && !downloadTreeMap.isEmpty()) {
			// iterate over all the visibilities
			for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {

				// concatenate the satId with the contact counter of the
				// visibility
				String visIdForSat = concatVisId(sat.getSatelliteId(), droolsParams.getAllVisibilities().get(i));

				// if there are other downloads for the current vis
				if (downloadTreeMap.containsKey(visIdForSat)) {

					// get the elements related to the current vis
					TreeMap<String, TreeMap<Long, IDownload>> elementsOnVis = downloadTreeMap.get(visIdForSat);

					// iterate over them
					for (Map.Entry<String, TreeMap<Long, IDownload>> allElementsInVis : elementsOnVis.entrySet()) {
						// get all downloads
						for (Map.Entry<Long, IDownload> allDwl : allElementsInVis.getValue().entrySet()) {

							// if the element is a download
							if (allDwl.getValue().getTypeOfDwl().equals(DownloadLogic.GPS)) {

								// extract the download
								Download currentDwl = (Download) allDwl.getValue().getDwlOrPt();

								// if is not contained in list
								if (!removedDwl.contains(currentDwl)) {
									// add to the list
									removedDwl.add(currentDwl);
								}
							}
						}
					}
				}
			}
		}
		return removedDwl;
	}

	/**
	 * Gets the all from tree map.
	 *
	 * @param satId            the sat id
	 * @param droolsParams     the drools params
	 * @param downloadTreeMap  the download tree map
	 * @param dwlLogicToReturn the dwl logic to return
	 * @return the all from tree map
	 */
	public TreeMap<String, Download> getAllFromTreeMap(String satId, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap,
			DownloadLogic dwlLogicToReturn) {
		Satellite sat = droolsParams.getSatWithId(satId);
		TreeMap<String, Download> removedDwl = new TreeMap<>();
		if ((downloadTreeMap != null) && !downloadTreeMap.isEmpty()) {
			// System.out.println("SAT : " + sat);
			for (int i = 0; i < droolsParams.getAllVisibilities().size(); i++) {

				if (droolsParams.getAllVisibilities().get(i).getSatelliteId().contains(sat.getSatelliteId())) {
					String visIdForSat = concatVisId(sat.getSatelliteId(), droolsParams.getAllVisibilities().get(i));

					if (downloadTreeMap.containsKey(visIdForSat)) {
						TreeMap<String, TreeMap<Long, IDownload>> elementsOnVis = downloadTreeMap.get(visIdForSat);
						for (Map.Entry<String, TreeMap<Long, IDownload>> allElementsInVis : elementsOnVis.entrySet()) {
							for (Map.Entry<Long, IDownload> allDwl : allElementsInVis.getValue().entrySet()) {
								if ((dwlLogicToReturn == null
										|| allDwl.getValue().getTypeOfDwl().equals(dwlLogicToReturn))
										&& allDwl.getValue().isReallyPlanned()) {
									Download currentDwl = (Download) allDwl.getValue().getDwlOrPt();
									if (!removedDwl.containsValue(currentDwl)) {
										String keyDwl = getKeyTreeMapDownloads(currentDwl);
										removedDwl.put(keyDwl, currentDwl);
									}
								}
							}
						}
					}
				}

			}
		}
		return removedDwl;
	}

	/**
	 * Gets the all PT from tree map.
	 *
	 * @param satId           the sat id
	 * @param droolsParams    the drools params
	 * @param downloadTreeMap the download tree map
	 * @return the all PT from tree map
	 */
	public List<PassThrough> getAllPTFromTreeMap(String satId, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap) {
		Satellite sat = droolsParams.getSatWithId(satId);
		List<PassThrough> allPt = new ArrayList<>();
		if (!downloadTreeMap.isEmpty()) {
			for (int i = 0; i < sat.getVisibilityList().size(); i++) {
				String visIdForSat = concatVisId(sat.getSatelliteId(), sat.getVisibilityList().get(i));

				if (downloadTreeMap.get(visIdForSat) != null) {
					TreeMap<String, TreeMap<Long, IDownload>> elementsOnVis = downloadTreeMap.get(visIdForSat);
					for (Map.Entry<String, TreeMap<Long, IDownload>> allElementsInVis : elementsOnVis.entrySet()) {
						for (Map.Entry<Long, IDownload> allDwl : allElementsInVis.getValue().entrySet()) {
							if (allDwl.getValue().getTypeOfDwl().equals(DownloadLogic.PT)) {
								PassThrough currentpt = (PassThrough) allDwl.getValue().getDwlOrPt();
								// System.out.println("CURRENT PT IN TREEMAP " +
								// currentpt);
								if (!allPt.contains(currentpt)) {
									allPt.add(currentpt);

								}
							}
						}
					}
				}
			}
		}
		return allPt;
	}

	/**
	 * Gets the priority key.
	 *
	 * @param acq the acq
	 * @return the priority key
	 */
	public String getPriorityKey(Acquisition acq) {
		String priorityKey = null;
		int points = DtoToAcqRule.setPrTypePoints(acq);
		String complementedPriority = complementPriority(acq.getPriority() + "");

		String missionHorizon = "1";
		if (acq.isTimePerformance()) {
			missionHorizon = "-1";
		} else if (acq.isPreviousMh()) {
			acq.setPriority(0);
			missionHorizon = "0";

		}
		priorityKey = points + "_" + missionHorizon + "_" + complementedPriority + "_" + acq.getStartTime().getTime();

		return priorityKey;
	}

	/**
	 * Complement priority.
	 *
	 * @param priority the priority
	 * @return the string
	 */
	private String complementPriority(String priority) {
		String complementedPriority = priority;
		if (priority.length() < 15) {
			for (int j = priority.length(); j < 15; j++) {
				complementedPriority = "0".concat(complementedPriority);
			}
		}
		return complementedPriority;
	}

	/**
	 * Clear download map and priority queue.
	 *
	 * @param satId            the sat id
	 * @param droolsParams     the drools params
	 * @param downloadTreeMap  the download tree map
	 * @param resFunc          the res func
	 * @param downloadPriority the download priority
	 */
	public void clearDownloadMapAndPriorityQueue(String satId, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, ResourceFunctions resFunc,
			TreeMap<String, PriorityQueue> downloadPriority) {
		removeAllDownloadsExceptPT(satId, droolsParams, downloadTreeMap, resFunc);
		PdhtManagement pdhtMng = new PdhtManagement();
		// reset the sector downloaded on vis for every download in the priority queue
		pdhtMng.restorePriorityQueue(downloadPriority);
	}

	/**
	 * Process download from priority queue.
	 *
	 * @param allCreatedDwl    the all created dwl
	 * @param downloadPriority the download priority
	 * @param droolsParams     the drools params
	 * @param downloadTreeMap  the download tree map
	 * @param resFunc          the res func
	 * @param satId            the sat id
	 * @return the list
	 */
	public List<Task> processDownloadFromPriorityQueue(List<Task> allCreatedDwl,
			TreeMap<String, PriorityQueue> downloadPriority, DroolsParameters droolsParams,
			TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap, ResourceFunctions resFunc,
			String satId) {
		for (Map.Entry<String, PriorityQueue> allPriorities : downloadPriority.entrySet()) {
			// extract the i-esim element
			PriorityQueue currentElement = allPriorities.getValue();

			// create an empty list of downloads associated to the
			// current elements
			List<Task> localDwlAssociatedToElement = downloadWithPriorityQueue(currentElement, droolsParams,
					downloadTreeMap, resFunc, satId);
			// logger.trace("created DWL " + localDwlAssociatedToElement);

			DownloadUtils dwlUtils = new DownloadUtils();
			// if the acquisition has associated downloads
			if (!localDwlAssociatedToElement.isEmpty()) {
				// insert all the new downloads in dwl treeMap
				for (int i = 0; i < localDwlAssociatedToElement.size(); i++) {
					// extract the i-esim download
					Download currentDwl = (Download) localDwlAssociatedToElement.get(i);
					// if the download is planned before the start time
					// of current mh
					if (currentDwl.getStartTime().getTime() < droolsParams.getCurrentMH().getStart().getTime()) {
						// set it as previously processed
						currentDwl.setPreviousMh(true);
					}
					// detect all the visibilities in overlap with the
					// just created download
					List<Visibility> allVisInOverlapWithDwl = dwlUtils.findAllVisInOverlapWithDate(
							currentDwl.getStartTime(), currentDwl.getEndTime(), droolsParams.getAllVisibilities(),
							satId);

					// logger.info("vis in overlap :" +
					// allVisInOverlapWithDwl);
					// insert into the dwl treemap (1 instance for every
					// visibility in overlap with the download)
					insertInIDownloadStructure(localDwlAssociatedToElement.get(i), allVisInOverlapWithDwl,
							downloadTreeMap);
				}
				allCreatedDwl.addAll(localDwlAssociatedToElement);

			}
		}
		return allCreatedDwl;
	}

	/**
	 * Gets the last position for gps.
	 *
	 * @param droolsParams    the drools params
	 * @param allGpsDownloads the all gps downloads
	 * @param external        the external
	 * @return the last position for gps
	 */
	public static int getLastPositionForGps(DroolsParameters droolsParams, List<Download> allGpsDownloads,
			boolean external) {
		// set las position for download GPS
		int lastPositionGps = 0;

		// sort download gps by start time
		DownloadUtils.sortDownloadByStartTime(allGpsDownloads);

		// iterate over the sorted elements
		for (int j = allGpsDownloads.size() - 1; j > 0; j--) {
			// extract the i-esim download
			Download currentDwl = allGpsDownloads.get(j);

			// get the associated vis
			Visibility relativeVis = DownloadUtils.getRelativeVis(currentDwl, droolsParams);

			// if the visibility is
			if (!relativeVis.getAcqStatId().equalsIgnoreCase(droolsParams.getPraticaDiMareId())
					&& !relativeVis.getAcqStatId().equalsIgnoreCase(droolsParams.getMateraId())) {
				if (external) {
					lastPositionGps = currentDwl.getFinalSector();
					break;
				}
			} else {
				if (!external) {
					lastPositionGps = currentDwl.getFinalSector();
					break;
				}
			}
		}
		return lastPositionGps;
	}

}
