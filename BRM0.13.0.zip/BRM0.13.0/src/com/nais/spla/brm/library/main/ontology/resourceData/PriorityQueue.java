/**
 *
 * MODULE FILE NAME: PriorityQueue.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.HashMap;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * The Class PriorityQueue.
 */
public class PriorityQueue implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** The priority. */
	private String priority;

	/** The pol. */
	private Polarization pol;

	/** The sectors needed for partners. */
	private HashMap<String, SectorAndVisForPartner> sectorsNeededForPartners;

	/** The related acq. */
	private Acquisition relatedAcq;

	/**
	 * Sets the pol.
	 *
	 * @param pol the new pol
	 */
	public void setPol(Polarization pol) {
		this.pol = pol;
	}

	/**
	 * Gets the related acq.
	 *
	 * @return the related acq
	 */
	public Acquisition getRelatedAcq() {
		return this.relatedAcq;
	}

	/**
	 * Sets the related acq.
	 *
	 * @param relatedAcq the new related acq
	 */
	public void setRelatedAcq(Acquisition relatedAcq) {
		this.relatedAcq = relatedAcq;
	}

	/**
	 * Gets the sectors needed for partners.
	 *
	 * @return the sectors needed for partners
	 */
	public HashMap<String, SectorAndVisForPartner> getSectorsNeededForPartners() {
		return this.sectorsNeededForPartners;
	}

	/**
	 * Sets the sectors needed for partners.
	 *
	 * @param sectorsNeededForPartners the sectors needed for partners
	 */
	public void setSectorsNeededForPartners(HashMap<String, SectorAndVisForPartner> sectorsNeededForPartners) {
		this.sectorsNeededForPartners = sectorsNeededForPartners;
	}

	/**
	 * Instantiates a new priority queue.
	 */
	public PriorityQueue() {
		super();
	}

	/**
	 * Sets the priority.
	 *
	 * @param priority the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the PriorityQueue
	 */
	@Override
	public String toString() {
		return "PriorityQueue [priority=" + this.priority + ", relatedAcq=" + this.relatedAcq.getIdTask() + ", pol="
				+ this.pol + ", sectorsNeededForPartners=" + this.sectorsNeededForPartners + "]";
	}

}
