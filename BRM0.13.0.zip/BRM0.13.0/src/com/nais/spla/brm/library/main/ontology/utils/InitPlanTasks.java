/**
*
* MODULE FILE NAME:	InitPlanTasks.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		25 apr 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 25 apr 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.utils;

import java.util.ArrayList;
import java.util.List;

import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;

// TODO: Auto-generated Javadoc
/**
 * The Class InitPlanTasks.
 *
 * @author francesca
 */
public class InitPlanTasks {

	/** The all init acq. */
	private List<Acquisition> allInitAcq = null;

	/** The all init man. */
	private List<Maneuver> allInitMan = null;

	/** The all init ramp. */
	private List<RampCMGA> allInitRamp = null;

	/** The all init dwl. */
	private List<Download> allInitDwl = null;

	/** The all init sto. */
	private List<Storage> allInitSto = null;

	/** The all init sil. */
	private List<Silent> allInitSil = null;

	/** The all init store aux. */
	private List<StoreAUX> allInitStoreAux = null;

	/** The all init bite. */
	private List<Bite> allInitBite = null;

	/** The all init cmg axis. */
	private List<CMGAxis> allInitCmgAxis = null;

	/** The all init cmg axis. */
	private List<EquivalentDTO> allInitEquivDTO = null;

	/** The all init pt. */
	private List<PassThrough> allInitPt = null;

	/**
	 * Instantiates a new inits the plan tasks.
	 *
	 * @param allInitAcq      the all init acq
	 * @param allInitMan      the all init man
	 * @param allInitRamp     the all init ramp
	 * @param allInitDwl      the all init dwl
	 * @param allInitSto      the all init sto
	 * @param allInitSil      the all init sil
	 * @param allInitPt       the all init pt
	 * @param allInitCmgAxis  the all init cmg axis
	 * @param allInitBite     the all init bite
	 * @param allInitStoreAux the all init store aux
	 * @param allInitEquivDTO the all init equiv DTO
	 */
	public InitPlanTasks(List<Acquisition> allInitAcq, List<Maneuver> allInitMan, List<RampCMGA> allInitRamp,
			List<Download> allInitDwl, List<Storage> allInitSto, List<Silent> allInitSil, List<PassThrough> allInitPt,
			List<CMGAxis> allInitCmgAxis, List<Bite> allInitBite, List<StoreAUX> allInitStoreAux,
			List<EquivalentDTO> allInitEquivDTO) {
		super();
		// set the previously processed acq
		this.allInitAcq = allInitAcq;

		// set the previously processed man
		this.allInitMan = allInitMan;

		// set the previously processed ramp
		this.allInitRamp = allInitRamp;

		// set the previously processed dwl
		this.allInitDwl = allInitDwl;

		// set the previously processed sto
		this.allInitSto = allInitSto;

		// set the previously processed sil
		this.allInitSil = allInitSil;

		// set the previously processed pt
		this.allInitPt = allInitPt;

		// set the previously processed cmgAxis
		this.allInitCmgAxis = allInitCmgAxis;

		// set the previously processed bite
		this.allInitBite = allInitBite;

		// set the previously processed storeAux
		this.allInitStoreAux = allInitStoreAux;

		// set the previously processed equivalentDTO
		this.allInitEquivDTO = allInitEquivDTO;
	}

	/**
	 * Instantiates a new inits the plan tasks.
	 */
	public InitPlanTasks() {
		super();
		// initialize the array of previously processed acq
		this.allInitAcq = new ArrayList<>();

		// initialize the array of previously processed man
		this.allInitMan = new ArrayList<>();

		// initialize the array of previously processed ramp
		this.allInitRamp = new ArrayList<>();

		// initialize the array of previously processed download
		this.allInitDwl = new ArrayList<>();

		// initialize the array of previously processed sto
		this.allInitSto = new ArrayList<>();

		// initialize the array of previously processed sil
		this.allInitSil = new ArrayList<>();

		// initialize the array of previously processed pt
		this.allInitPt = new ArrayList<>();

		// initialize the array of previously processed cmgAxis
		this.allInitCmgAxis = new ArrayList<>();

		// initialize the array of previously processed bite
		this.allInitBite = new ArrayList<>();

		// initialize the array of previously processed storeAux
		this.allInitStoreAux = new ArrayList<>();

		this.allInitEquivDTO = new ArrayList<>();
	}

	/**
	 * Gets the all init store aux.
	 *
	 * @return the allInitStoreAux
	 */
	public List<StoreAUX> getAllInitStoreAux() {
		return this.allInitStoreAux;
	}

	/**
	 * Gets the all init bite.
	 *
	 * @return the allInitBite
	 */
	public List<Bite> getAllInitBite() {
		return this.allInitBite;
	}

	/**
	 * Gets the all init cmg axis.
	 *
	 * @return the allInitCmgAxis
	 */
	public List<CMGAxis> getAllInitCmgAxis() {
		return this.allInitCmgAxis;
	}

	/**
	 * Gets the all init acq.
	 *
	 * @return the allInitAcq
	 */
	public List<Acquisition> getAllInitAcq() {
		return this.allInitAcq;
	}

	/**
	 * Gets the all init man.
	 *
	 * @return the allInitMan
	 */
	public List<Maneuver> getAllInitMan() {
		return this.allInitMan;
	}

	/**
	 * Gets the all init ramp.
	 *
	 * @return the allInitRamp
	 */
	public List<RampCMGA> getAllInitRamp() {
		return this.allInitRamp;
	}

	/**
	 * Gets the all init dwl.
	 *
	 * @return the allInitDwl
	 */
	public List<Download> getAllInitDwl() {
		return this.allInitDwl;
	}

	/**
	 * Gets the all init sto.
	 *
	 * @return the allInitSto
	 */
	public List<Storage> getAllInitSto() {
		return this.allInitSto;
	}

	/**
	 * Gets the all init sil.
	 *
	 * @return the allInitSil
	 */
	public List<Silent> getAllInitSil() {
		return this.allInitSil;
	}

	/**
	 * Gets the all init pt.
	 *
	 * @return the allInitPt
	 */
	public List<PassThrough> getAllInitPt() {
		return this.allInitPt;
	}

	/**
	 * Gets the all init equiv DTO.
	 *
	 * @return the all init equiv DTO
	 */
	public List<EquivalentDTO> getAllInitEquivDTO() {
		return this.allInitEquivDTO;
	}

}
