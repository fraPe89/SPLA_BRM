/**
*
* MODULE FILE NAME:	MemoryModule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		28 apr 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 28 apr 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resources;

import java.io.Serializable;

/**
 * The Class MemoryModule.
 *
 * @author fpedrola
 */
@SuppressWarnings("serial")
public class MemoryModule implements Serializable {

	/** The id. */
	private String id;

	/** The free sectors. */
	private long freeSectors;

	/** The in use. */
	private boolean inUse;

	/**
	 * Instantiates a new memory module.
	 *
	 * @param id          the id
	 * @param freeSectors the free sectors
	 */
	public MemoryModule(String id, long freeSectors) {
		super();
		this.id = id;
		this.freeSectors = freeSectors;
		this.inUse = false;
	}

	/**
	 * Instantiates a new memory module.
	 *
	 * @param id the id
	 */
	public MemoryModule(String id) {
		super();
		this.id = id;
		this.inUse = false;
	}

	/**
	 * Gets the free sectors.
	 *
	 * @return the freeSectors
	 */
	public long getFreeSectors() {
		return this.freeSectors;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Checks if is in use.
	 *
	 * @return the inUse
	 */
	public boolean isInUse() {
		return this.inUse;
	}

	/**
	 * Sets the free sectors.
	 *
	 * @param freeSectors the freeSectors to set
	 */
	public void setFreeSectors(long freeSectors) {
		this.freeSectors = freeSectors;
	}

	/**
	 * Sets the in use.
	 *
	 * @param inUse the inUse to set
	 */
	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() { /**
								 * toString del metodo
								 */
		return "MemoryModule [id=" + this.id + ", freeSectors=" + this.freeSectors + ", inUse=" + this.inUse + "]";
	}
}
