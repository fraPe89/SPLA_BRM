/**
*
* MODULE FILE NAME:	MissionHorizon.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		05 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 05 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.util.Date;

/**
 * The Class MissionHorizon.
 *
 * @author fpedrola
 */
public class MissionHorizon {

	/** The start. */
	private Date start;

	/** The stop. */
	private Date stop;

	/**
	 * Instantiates a new mission horizon.
	 */
	public MissionHorizon() {
		super();
	}

	/**
	 * Instantiates a new mission horizon.
	 *
	 * @param start the start
	 * @param stop  the stop
	 */
	public MissionHorizon(Date start, Date stop) {
		super();
		this.start = start;
		this.stop = stop;
	}

	/**
	 * Gets the start.
	 *
	 * @return the start
	 */
	public Date getStart() {
		return this.start;
	}

	/**
	 * Gets the stop.
	 *
	 * @return the stop
	 */
	public Date getStop() {
		return this.stop;
	}

	/**
	 * Sets the start.
	 *
	 * @param start the start to set
	 */
	public void setStart(Date start) {
		this.start = start;
	}

	/**
	 * Sets the stop.
	 *
	 * @param stop the stop to set
	 */
	public void setStop(Date stop) {
		this.stop = stop;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the missionHorizon
	 */
	@Override
	public String toString() {
		return "MissionHorizon [start=" + this.start + ", stop=" + this.stop + "]";
	}

}
