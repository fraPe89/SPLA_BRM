/**
*
* MODULE FILE NAME:	ResourceMaxValue.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		30 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 30 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.utils;

// TODO: Auto-generated Javadoc
/**
 * The Class ResourceMaxValue.
 *
 * @author fpedrola
 */
public class ResourceMaxValue {

	/** The minutes for orbit. */
	private double minutesForOrbit;

	/** The max silent. */
	private double maxSilent;

	/** The max threshold. */
	private double maxThreshold;

	/** The max maneuvers. */
	private int maxManeuvers;

	/** The max maneuvers RW. */
	private int maxManeuversRW;

	/** The max maneuvers CMGA. */
	private int maxManeuversCMGA;

	/** The min time in eclipse. */
	private double minTimeInEclipse;

	/** The max theatre. */
	private int maxTheatre;

	/**
	 * Instantiates a new resource max value.
	 *
	 * @param minutesForOrbit  the minutes for orbit
	 * @param maxSilent        the max silent
	 * @param maxThreshold     the max threshold
	 * @param maxManeuvers     the max maneuvers
	 * @param maxManeuversRW   the max maneuvers RW
	 * @param maxManeuversCMGA the max maneuvers CMGA
	 * @param minTimeInEclipse the min time in eclipse
	 */
	public ResourceMaxValue(double minutesForOrbit, double maxSilent, double maxThreshold, int maxManeuvers,
			int maxManeuversRW, int maxManeuversCMGA, double minTimeInEclipse) {
		super();
		// set the minutes for an orbit
		this.minutesForOrbit = minutesForOrbit;

		// set the max value of silent
		this.maxSilent = maxSilent;

		// set the max value of ess threshold
		this.maxThreshold = maxThreshold;

		// set the max value of total maneuvers
		this.maxManeuvers = maxManeuvers;

		// set the max value of maneuvers RW
		this.maxManeuversRW = maxManeuversRW;

		// set the max value of maneuvers CMGA
		this.maxManeuversCMGA = maxManeuversCMGA;

		// set the min time necessary to declare an orbit of eclipse
		this.minTimeInEclipse = minTimeInEclipse;
	}

	/**
	 * Instantiates a new resource max value.
	 */
	public ResourceMaxValue() {
		super();
	}

	/**
	 * Gets the max maneuvers.
	 *
	 * @return the maxManeuvers
	 */
	public int getMaxManeuvers() {
		return this.maxManeuvers;
	}

	/**
	 * Gets the max maneuvers CMGA.
	 *
	 * @return the maxManeuversCMGA
	 */
	public int getMaxManeuversCMGA() {
		return this.maxManeuversCMGA;
	}

	/**
	 * Gets the max maneuvers RW.
	 *
	 * @return the maxManeuversRW
	 */
	public int getMaxManeuversRW() {
		return this.maxManeuversRW;
	}

	/**
	 * Gets the max silent.
	 *
	 * @return the maxSilent
	 */
	public double getMaxSilent() {
		return this.maxSilent;
	}

	/**
	 * Gets the max threshold.
	 *
	 * @return the maxThreshold
	 */
	public double getMaxThreshold() {
		return this.maxThreshold;
	}

	/**
	 * Gets the min time in eclipse.
	 *
	 * @return the min time in eclipse
	 */
	public double getMinTimeInEclipse() {
		return this.minTimeInEclipse;
	}

	/**
	 * Sets the max threshold.
	 *
	 * @param maxThreshold the maxThreshold to set
	 */
	public void setMaxThreshold(double maxThreshold) {
		this.maxThreshold = maxThreshold;
	}

	/**
	 * Gets the minutes for orbit.
	 *
	 * @return the minutes for orbit
	 */
	public double getMinutesForOrbit() {
		return this.minutesForOrbit;
	}

	/**
	 * Sets the minutes for orbit.
	 *
	 * @param minutesForOrbit the new minutes for orbit
	 */
	public void setMinutesForOrbit(double minutesForOrbit) {
		this.minutesForOrbit = minutesForOrbit;
	}

	/**
	 * Gets the max theatre.
	 *
	 * @return the max theatre
	 */
	public int getMaxTheatre() {
		return this.maxTheatre;
	}

	/**
	 * Sets the max theatre.
	 *
	 * @param maxTheatre the new max theatre
	 */
	public void setMaxTheatre(int maxTheatre) {
		this.maxTheatre = maxTheatre;
	}

	/**
	 * Sets the max silent.
	 *
	 * @param maxSilent the maxSilent to set
	 */
	public void setMaxSilent(double maxSilent) {
		this.maxSilent = maxSilent;
	}

	/**
	 * Sets the max maneuvers.
	 *
	 * @param maxManeuvers the maxManeuvers to set
	 */
	public void setMaxManeuvers(int maxManeuvers) {
		this.maxManeuvers = maxManeuvers;
	}

	/**
	 * Sets the max maneuvers RW.
	 *
	 * @param maxManeuversRW the maxManeuversRW to set
	 */
	public void setMaxManeuversRW(int maxManeuversRW) {
		this.maxManeuversRW = maxManeuversRW;
	}

	/**
	 * Sets the max maneuvers CMGA.
	 *
	 * @param maxManeuversCMGA the maxManeuversCMGA to set
	 */
	public void setMaxManeuversCMGA(int maxManeuversCMGA) {
		this.maxManeuversCMGA = maxManeuversCMGA;
	}

	/**
	 * Sets the min time in eclipse.
	 *
	 * @param minTimeInEclipse the minTimeInEclipse to set
	 */
	public void setMinTimeInEclipse(double minTimeInEclipse) {
		this.minTimeInEclipse = minTimeInEclipse;
	}

	
	
	/** 
	 * toString method
	 */
	@Override
	public String toString() {
		return "ResourceMaxValue [minutesForOrbit=" + this.minutesForOrbit + ", maxSilent=" + this.maxSilent
				+ ", maxThreshold=" + this.maxThreshold + ", maxManeuvers=" + this.maxManeuvers + ", maxManeuversRW="
				+ this.maxManeuversRW + ", maxManeuversCMGA=" + this.maxManeuversCMGA + ", minTimeInEclipse="
				+ this.minTimeInEclipse + ", maxTheatre=" + this.maxTheatre + "]";
	}

}
