/**
*
* MODULE FILE NAME: DebitCard.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        30 ago 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 30 ago 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;

/**
 * The Class DebitCard.
 *
 * @author fpedrola
 */
public class DebitCard implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Partner that give me some of his BIC. */
	private String creditorId;

	/** amount of BIC that the Creditor give to Debitor. */
	private double BICBorrowed;

	/** debit for the acq with id. */
	private String forAcq;

	/** The donation. */
	private boolean donation;

	/** The is previous. */
	private boolean isPrevious;

	/**
	 * Instantiates a new debit card.
	 *
	 * @param creditorId  the creditor id
	 * @param BICBorrowed the BIC borrowed
	 * @param forAcq      the for acq
	 */
	public DebitCard(String creditorId, double BICBorrowed, String forAcq) {
		super();
		this.creditorId = creditorId;
		this.BICBorrowed = BICBorrowed;
		this.forAcq = forAcq;
		this.donation = false;
		this.isPrevious = false;
	}

	/**
	 * Gets the BIC borrowed.
	 *
	 * @return the bICBorrowed
	 */
	public double getBICBorrowed() {
		return this.BICBorrowed;
	}

	/**
	 * Sets the BIC borrowed.
	 *
	 * @param bICBorrowed the new BIC borrowed
	 */
	public void setBICBorrowed(double bICBorrowed) {
		this.BICBorrowed = bICBorrowed;
	}

	/**
	 * Gets the creditor.
	 *
	 * @return the creditor
	 */
	public String getCreditor() {
		return this.creditorId;
	}

	/**
	 * Gets the for acq.
	 *
	 * @return the for acq
	 */
	public String getForAcq() {
		return this.forAcq;
	}

	/**
	 * Checks if is donation.
	 *
	 * @return true, if is donation
	 */
	public boolean isDonation() {
		return this.donation;
	}

	/**
	 * Sets the donation.
	 *
	 * @param donation the new donation
	 */
	public void setDonation(boolean donation) {
		this.donation = donation;
	}

	/**
	 *  
	 * toString method.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DebitCard [creditorId=" + this.creditorId + ", BICBorrowed=" + this.BICBorrowed + ", forAcq="
				+ this.forAcq + ", donation=" + this.donation + "]";
	}

	/**
	 * Checks if is previous.
	 *
	 * @return true, if is previous
	 */
	public boolean isPrevious() {
		return this.isPrevious;
	}

	/**
	 * Sets the previous.
	 *
	 * @param isPrevious the new previous
	 */
	public void setPrevious(boolean isPrevious) {
		this.isPrevious = isPrevious;
	}

}
