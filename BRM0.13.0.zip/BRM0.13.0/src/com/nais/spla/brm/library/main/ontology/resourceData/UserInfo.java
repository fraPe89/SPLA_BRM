/**
 *
 * MODULE FILE NAME: UserInfo.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.resourceData;

import java.io.Serializable;
import java.util.List;

/**
 * The Class UserInfo.
 */
public class UserInfo implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The acquisition station id list. */
	private List<String> acquisitionStationIdList;

	/** The is subscriber. */
	private boolean isSubscriber;

	/** The is slave. */
	private boolean isSlave;

	/** The owner id. */
	private String ownerId;

	/** The ugs id. */
	private String ugsId;

	/**
	 * Gets the acquisition station id list.
	 *
	 * @return the acquisition station id list
	 */
	public List<String> getAcquisitionStationIdList() {
		return this.acquisitionStationIdList;
	}

	/**
	 * Sets the acquisition station id list.
	 *
	 * @param acquisitionStationIdList the new acquisition station id list
	 */
	public void setAcquisitionStationIdList(List<String> acquisitionStationIdList) {
		this.acquisitionStationIdList = acquisitionStationIdList;
	}

	/**
	 * Sets the subscriber.
	 *
	 * @param isSubscriber the new subscriber
	 */
	public void setSubscriber(boolean isSubscriber) {
		this.isSubscriber = isSubscriber;
	}

	/**
	 * Gets the owner id.
	 *
	 * @return the owner id
	 */
	public String getOwnerId() {
		return this.ownerId;
	}

	/**
	 * Sets the owner id.
	 *
	 * @param ownerId the new owner id
	 */
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	/**
	 * Gets the ugs id.
	 *
	 * @return the ugs id
	 */
	public String getUgsId() {
		return this.ugsId;
	}

	/**
	 * Sets the ugs id.
	 *
	 * @param ugsId the new ugs id
	 */
	public void setUgsId(String ugsId) {
		this.ugsId = ugsId;
	}

	/**
	 * Instantiates a new user info.
	 *
	 * @param acquisitionStationIdList the acquisition station id list
	 * @param isSubscriber             the is subscriber
	 * @param ownerId                  the owner id
	 * @param ugsId                    the ugs id
	 */
	public UserInfo(List<String> acquisitionStationIdList, boolean isSubscriber, String ownerId, String ugsId) {
		super();
		this.acquisitionStationIdList = acquisitionStationIdList;
		this.isSubscriber = isSubscriber;
		this.ownerId = ownerId;
		this.ugsId = ugsId;
		this.isSlave = false;
	}

	/**
	 * Checks if is slave.
	 *
	 * @return the isSlave
	 */
	public boolean isSlave() {
		return this.isSlave;
	}

	/**
	 * Instantiates a new user info.
	 */
	public UserInfo() {
		super();
	}

	/**
	 * Instantiates a new user info.
	 *
	 * @param ownerId the owner id
	 */
	public UserInfo(String ownerId) {
		super();
		this.acquisitionStationIdList = null;
		this.isSubscriber = false;
		this.ownerId = ownerId;
		this.ugsId = null;
		this.isSlave = false;
	}

	/**
	 * method to Sring
	 * 
	 * @return the string with all the info about the userInfo
	 */
	@Override
	public String toString() {
		return "UserInfo [acquisitionStationIdList=" + this.acquisitionStationIdList + ", isSubscriber="
				+ this.isSubscriber + ", ownerId=" + this.ownerId + ", ugsId=" + this.ugsId + "]";
	}

	/**
	 * Sets the slave.
	 *
	 * @param isSlave the isSlave to set
	 */
	public void setSlave(boolean isSlave) {
		this.isSlave = isSlave;
	}

}
