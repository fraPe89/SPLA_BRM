/**
*
* MODULE FILE NAME:	CMGAxis.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		28 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 28 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.ontology.tasks;

import java.util.Date;

import com.nais.spla.brm.library.main.ontology.enums.TaskType;

/**
 * The Class CMGAxis.
 *
 * @author francesca
 */
@SuppressWarnings("serial")
public class CMGAxis extends Task {

	/** The roll to pitch. */
	private boolean rollToPitch = false;

	/**
	 * Instantiates a new CMG axis.
	 *
	 * @param startTime the start time
	 * @param endTime   the end time
	 */
	public CMGAxis(Date startTime, Date endTime) {
		// set the task type
		super.setTaskType(TaskType.AXES_RECONF);

		// set the start time
		super.setStartTime(startTime);

		// set the stop time
		super.setEndTime(endTime);
	}

	/**
	 *
	 */
	public CMGAxis() {
		super();

	}

	/**
	 * toString del metodo
	 */
	@Override
	public String toString() { /**
								 * toString del metodo
								 */
		return "CMGAxis [getTaskType()=" + getTaskType() + ", taskId :" + getIdTask() + " , getStartTime()= "
				+ getStartTime() + ", getEndTime()=" + getEndTime() + ", rollToPitch =" + this.isRollToPitch()
				+ ", getSatelliteId()=" + getSatelliteId() + "]";
	}

	/**
	 * Checks if is roll to pitch.
	 *
	 * @return the rollToPitch
	 */
	public boolean isRollToPitch() {
		return this.rollToPitch;
	}

	/**
	 * Sets the roll to pitch.
	 *
	 * @param rollToPitch the rollToPitch to set
	 */
	public void setRollToPitch(boolean rollToPitch) {
		this.rollToPitch = rollToPitch;
	}

}
