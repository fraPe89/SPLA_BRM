/**
*
* MODULE FILE NAME:	ManeuverUtils.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		23 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 23 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.TreeMap;

import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PlanningResources;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;

// TODO: Auto-generated Javadoc
/**
 * The Class ManeuverUtils.
 *
 * @author francesca
 */
public class ManeuverUtils {

	/**
	 * All man in interval.
	 *
	 * @param from               the from
	 * @param to                 the to
	 * @param allManRelatedToSat the all man related to sat
	 * @return the list
	 */
	public List<Maneuver> allManInInterval(long from, long to, TreeMap<Long, Maneuver> allManRelatedToSat) {
		// create a list of man
		List<Maneuver> allManInInterval = new ArrayList<>();

		// get the submap delimited by the input parameters
		NavigableMap<Long, Maneuver> subMapIntervalMap = allManRelatedToSat.subMap(from, true, to, true);

		// if there is a previous element
		if (allManRelatedToSat.lowerKey(from) != null) {
			// if the previous man is borderline
			if (allManRelatedToSat.lowerEntry(from).getValue().getEndTime().getTime() > from) {
				// borderline case, man included in count
				allManInInterval.add(allManRelatedToSat.lowerEntry(from).getValue());
			}
		}
		// iterate over the map
		for (Map.Entry<Long, Maneuver> elementInInterval : subMapIntervalMap.entrySet()) {
			// add each element
			allManInInterval.add(elementInInterval.getValue());
		}
		return allManInInterval;
	}

	/**
	 * Clear man res.
	 *
	 * @param manRes the man res
	 */
	public void clearManRes(ManeuverResources manRes) {
		// clean new ramps
		manRes.getNewRumps().clear();

		// clean new mans
		manRes.getNewMans().clear();

		// clean old mans
		manRes.getOldMans().clear();

		// clean old ramps
		manRes.getOldRumps().clear();
	}

	/**
	 * Find element.
	 *
	 * @param dateRes      the date res
	 * @param startAndStop the start and stop
	 * @param startWithRw  the start with rw
	 * @param timeForRw    the time for rw
	 * @param timeForCMGA  the time for CMGA
	 * @param ascending    the ascending
	 * @return the date resource
	 */
	public DateResource findElement(DateResource dateRes, TreeMap<Date, Date> startAndStop, boolean startWithRw,
			long timeForRw, long timeForCMGA, boolean ascending) {
		boolean found = false;

		NavigableSet<Date> orderedMapAscendingOrDescending = null;

		// if the order is asccending
		if (ascending) {
			// order the map in input in crescent order
			orderedMapAscendingOrDescending = startAndStop.navigableKeySet();
		}
		// if is discending
		else {
			// order the map in input in reverse order
			orderedMapAscendingOrDescending = startAndStop.descendingKeySet();
		}
		// while is not found a valid match
		while (!found) {
			// iterate over the map
			for (Date key : orderedMapAscendingOrDescending) {
				// extract the date
				Date value = startAndStop.get(key);

				// compute the gap
				long gap = (value.getTime() - key.getTime()) / 1000;

				// if the first choice is rw
				if (startWithRw) {
					// if the gap is enough
					if (gap > timeForRw) {
						found = true;
						// set start and stop time
						dateRes.setStart(key);
						dateRes.setStop(value);
						break;
					}
				}
				// if the first choice is a cmg
				else {
					// if the gap is enough
					if (gap > timeForCMGA) {
						found = true;
						// set start and stop time
						dateRes.setStart(key);
						dateRes.setStop(value);
						break;
					}
				}
			}

			// if not found a match
			if (!found) {
				// if the first choice was rw
				if (startWithRw) {
					// sedt the cmg as first choice
					startWithRw = false;
				}
			}
		}
		return dateRes;
	}

	/**
	 * Compute ascending or discending.
	 *
	 * @param current  the current
	 * @param otherAcq the other acq
	 * @param toDate   the to date
	 * @return true, if successful
	 */
	public boolean computeAscendingOrDiscending(Acquisition current, Acquisition otherAcq, Date toDate) {
		// initialize the asset to ascending
		boolean ascending = true;

		// if both acquisitions are not null
		if ((current != null) && (otherAcq != null)) {
			// if current is after the other acq
			if (current.getStartTime().after(otherAcq.getStartTime())) {
				// if corrent is left
				if (current.getLookSide().equalsIgnoreCase("left")) {
					// invert the asset to false
					ascending = false;
				}
				// if corrent is right
				else {
					// invert the asset to true
					ascending = true;
				}
			}

			// if current is before the other acq
			else {
				// if current is left
				if (current.getLookSide().equalsIgnoreCase("left")) {
					// invert the asset to true
					ascending = true;
				}
				// if current is right
				else {
					// invert the asset to false
					ascending = false;
				}
			}

		}
		// if other acq is null
		else {
			// if toDate is before the current
			if ((toDate != null) && toDate.before(current.getStartTime())) {
				// if current is left
				if (current.getLookSide().equalsIgnoreCase("left")) {
					// invert the asset to false
					ascending = false;
				}
				// if current is right
				else {
					// invert the asset to true
					ascending = true;
				}
			}
			// if toDate is after the current
			else {
				// if current is left
				if (current.getLookSide().equalsIgnoreCase("left")) {
					// invert the asset to true
					ascending = true;
				}
				// if current is right
				else {
					// invert the asset to false
					ascending = false;
				}
			}
		}
		return ascending;
	}

	/**
	 * Gets the sat id.
	 *
	 * @param prev    the prev
	 * @param current the current
	 * @return the sat id
	 */
	public String getSatId(Acquisition prev, Acquisition current) {
		// initialize the satellite id
		String satId = null;

		// if there is a prev acq
		if (prev != null) {
			// extract the satellite of prev
			satId = prev.getSatelliteId();
		} else {
			// extract the satellite of current
			satId = current.getSatelliteId();
		}
		return satId;
	}

	/**
	 * Receive actuator type.
	 *
	 * @param checkToPerform the check to perform
	 * @return the actuator
	 * @throws Exception the exception
	 */
	public Actuator receiveActuatorType(String checkToPerform) throws Exception {
		// initialize the actuator
		Actuator manType = Actuator.ReactionWheels;

		// if the check is cmga
		if (checkToPerform.equalsIgnoreCase("CMGA")) {
			// set with the correct actuator
			manType = Actuator.CMGA;
		}
		// if the check is rw
		else if (checkToPerform.equalsIgnoreCase("rw")) {
			// set with the correct actuator
			manType = Actuator.ReactionWheels;
		} else {
			// set with the correct actuator
			manType = Actuator.total;
		}
		return manType;
	}

	/**
	 * Sort overlapped element list.
	 *
	 * @param elementsInOVerlap the elements in O verlap
	 */
	public void sortOverlappedElementList(List<PlanningResources> elementsInOVerlap) {
		// given two planning resources
		Collections.sort(elementsInOVerlap, new Comparator<PlanningResources>() {

			@Override
			public int compare(PlanningResources el1, PlanningResources el2) {
				// sort them by
				// start time
				return (el1.getStartTime().compareTo(el2.getStartTime()));
			}
		});
	}

	/**
	 * Merge list overlapped elements.
	 *
	 * @param allVisInOverlap the all vis in overlap
	 * @param allPawInOverlap the all paw in overlap
	 * @return the list
	 */
	public List<PlanningResources> mergeListOverlappedElements(List<Visibility> allVisInOverlap,
			List<PAW> allPawInOverlap) {
		// create a new list of planning resources
		List<PlanningResources> allOverlappedEl = new ArrayList<>();

		// if there are visibilities in overlap
		if (!allVisInOverlap.isEmpty()) {
			// add all visibilities
			allOverlappedEl.addAll(allVisInOverlap);
		}
		// if there are paws in overlap
		if (!allPawInOverlap.isEmpty()) {
			// add all paws
			allOverlappedEl.addAll(allPawInOverlap);
		}
		return allOverlappedEl;
	}

	/**
	 * Insert ne man inman res.
	 *
	 * @param newMan the new man
	 * @param manRes the man res
	 */
	public void insertNeManInmanRes(Maneuver newMan, ManeuverResources manRes) {
		// initialize the returned variable to false
		boolean found = false;

		// iterate over the new mans
		for (int i = 0; i < manRes.getNewMans().size(); i++) {
			// if there is a match
			if (manRes.getNewMans().get(i).equals(newMan)) {
				// set the variable to true
				found = true;
			}
		}
		// if not found
		if (!found) {
			// add to the list
			manRes.getNewMans().add(newMan);
		}
	}

	/**
	 * Check borderline case start.
	 *
	 * @param manExtracted the man extracted
	 * @param startCheck   the start check
	 * @param start        the start
	 * @return true, if successful
	 */
	public boolean checkBorderlineCaseStart(Maneuver manExtracted, long startCheck, boolean start) {
		// initialize the boolean variable to false
		boolean insertable = false;

		// if the man is in borderline state
		if (manExtracted.getEndTime().getTime() >= startCheck) {
			// mark as insertable
			insertable = true;
		}
		return insertable;
	}

	/**
	 * Adds the gap to list if is valid.
	 *
	 * @param timeForCmga  the time for cmga
	 * @param startAndStop the start and stop
	 * @param from         the from
	 * @param gap          the gap
	 */
	public void addGapToListIfIsValid(long timeForCmga, TreeMap<Date, Date> startAndStop, Date from, long gap) {
		// if the gap is enough
		if (gap > timeForCmga) {
			// insert the valid date into the treemap
			startAndStop.put(new Date(from.getTime()), new Date(from.getTime() + (gap * 1000)));
		}
	}

	/**
	 * Gets the man with second member id.
	 *
	 * @param maneuverFunctionAssociatedToSat 
	 * the maneuver function associated to sat
	 * @param idTask the id task
	 * @return the man with second member id
	 */
	public static Maneuver getManWithSecondMemberId(TreeMap<Long, Maneuver> maneuverFunctionAssociatedToSat,
			String idTask) {
		//initialize the man
		Maneuver man = null;
		for (Map.Entry<Long, Maneuver> allEntryMan : maneuverFunctionAssociatedToSat.entrySet()) {
			if (allEntryMan.getValue().getAcq2Id().equalsIgnoreCase(idTask)) {
				man = allEntryMan.getValue();
				break;
			}
		}
		return man;
	}

	/**
	 * Gets the man with first member id.
	 *
	 * @param maneuverFunctionAssociatedToSat 
	 * the maneuver function associated to sat
	 * @param idTask the id task
	 * @return the man with first member id
	 */
	public static Maneuver getManWithFirstMemberId(TreeMap<Long, Maneuver> maneuverFunctionAssociatedToSat,
			String idTask) {
		//initialize the man
		Maneuver man = null;
		for (Map.Entry<Long, Maneuver> allEntryMan : maneuverFunctionAssociatedToSat.entrySet()) {
			if (allEntryMan.getValue().getAcq1Id().equalsIgnoreCase(idTask)) {
				man = allEntryMan.getValue();
				break;
			}
		}
		return man;
	}
}
