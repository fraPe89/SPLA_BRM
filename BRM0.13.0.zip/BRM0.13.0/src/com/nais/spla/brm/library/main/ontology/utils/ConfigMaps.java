/**
 *
 * MODULE FILE NAME: ConfigMaps.java
 *
 * MODULE TYPE:      Class definition
 *
 * FUNCTION:     <Functional description of the DDC>
 *
 * PURPOSE:
 *
 * CREATION DATE:        18 set 2017
 *
 * AUTHORS:      fpedrola
 *
 * DESIGN ISSUE:     1.0
 *
 * INTERFACES:
 *
 * SUBORDINATES:
 *
 * MODIFICATION HISTORY:
 *
 *  Date            |  Name      | New ver.    | Description
 * -----------------+------------+-------------+-------------------------------
 * 18 set 2017          | fpedrola    | 1.0         | first issue
 * -----------------+------------+-------------+-------------------------------
 *
 */

package com.nais.spla.brm.library.main.ontology.utils;

import java.util.Map;

import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;

/**
 * The Class ConfigMaps.
 */
public class ConfigMaps {

	/** The power sensor mode. */
	private Map<TypeOfAcquisition, Double> powerSensorMode;

	/** The min distance map. */
	private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap;

	/** The t standardmap. */
	private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tStandardmap;

	/** The t threshold map. */
	private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tThresholdMap;

	/** The max duration sensor mode. */
	private Map<TypeOfAcquisition, Double> maxDurationSensorMode;

	/** The max hp bic for fixed orbit map. */
	private Map<Integer, Double> maxHpBicForFixedOrbitMap;

	/**
	 * Instantiates a new config maps.
	 */
	public ConfigMaps() {
		super();
	}

	/**
	 * Gets the min distance map.
	 *
	 * @return the min distance map
	 */
	public Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> getMinDistanceMap() {
		return this.minDistanceMap;
	}

	/**
	 * Sets the min distance map.
	 *
	 * @param minDistanceMap the min distance map
	 */
	public void setMinDistanceMap(Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap) {
		this.minDistanceMap = minDistanceMap;
	}

	/**
	 * Gets the t standardmap.
	 *
	 * @return the t standardmap
	 */
	public Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> gettStandardmap() {
		return this.tStandardmap;
	}

	/**
	 * Sett standardmap.
	 *
	 * @param tStandardmap the t standardmap
	 */
	public void settStandardmap(Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tStandardmap) {
		this.tStandardmap = tStandardmap;
	}

	/**
	 * Gets the t threshold map.
	 *
	 * @return the t threshold map
	 */
	public Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> gettThresholdMap() {
		return this.tThresholdMap;
	}

	/**
	 * Sett threshold map.
	 *
	 * @param tThresholdMap the t threshold map
	 */
	public void settThresholdMap(Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tThresholdMap) {
		this.tThresholdMap = tThresholdMap;
	}

	/**
	 * Gets the power sensor mode.
	 *
	 * @return the power sensor mode
	 */
	public Map<TypeOfAcquisition, Double> getPowerSensorMode() {
		return this.powerSensorMode;
	}

	/**
	 * Sets the power sensor mode.
	 *
	 * @param powerSensorMode the power sensor mode
	 */
	public void setPowerSensorMode(Map<TypeOfAcquisition, Double> powerSensorMode) {
		this.powerSensorMode = powerSensorMode;
	}

	/**
	 * Gets the max duration sensor mode.
	 *
	 * @return the max duration sensor mode
	 */
	public Map<TypeOfAcquisition, Double> getMaxDurationSensorMode() {
		return this.maxDurationSensorMode;
	}

	/**
	 * Sets the max duration sensor mode.
	 *
	 * @param maxDurationSensorMode the max duration sensor mode
	 */
	public void setMaxDurationSensorMode(Map<TypeOfAcquisition, Double> maxDurationSensorMode) {
		this.maxDurationSensorMode = maxDurationSensorMode;
	}

	/**
	 * Gets the max hp bic for fixed orbit map.
	 *
	 * @return the max hp bic for fixed orbit map
	 */
	public Map<Integer, Double> getMaxHpBicForFixedOrbitMap() {
		return this.maxHpBicForFixedOrbitMap;
	}

	/**
	 * Sets the max hp bic for fixed orbit map.
	 *
	 * @param maxHpBicForFixedOrbitMap the max hp bic for fixed orbit map
	 */
	public void setMaxHpBicForFixedOrbitMap(Map<Integer, Double> maxHpBicForFixedOrbitMap) {
		this.maxHpBicForFixedOrbitMap = maxHpBicForFixedOrbitMap;
	}
}
