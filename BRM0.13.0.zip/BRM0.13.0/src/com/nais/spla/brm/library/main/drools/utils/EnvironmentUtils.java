/**
*
* MODULE FILE NAME:	EnvironmentUtils.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		25 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 25 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TreeMap;

import org.kie.api.runtime.KieSession;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.exception.ConfigurationException;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.utils.MinTimeRight;

/**
 * The Class EnvironmentUtils.
 *
 * @author francesca
 */
public class EnvironmentUtils {

	/**
	 * Check null value.
	 *
	 * @param value        the value
	 * @param errorMessage the error message
	 * @throws ConfigurationException the configuration exception
	 */
	public void checkNullValue(final String value, String errorMessage) throws ConfigurationException {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		// if the name passed as input is null or empty
		if ((value == null) || value.isEmpty()) {
			// throw a configuration exception
			logger.error(errorMessage);
			throw new ConfigurationException(errorMessage);
		}
	}

	/**
	 * Process type of paw excluded from store aux.
	 *
	 * @param allTypeOfPawExcludedFromStoreAux the all type of paw excluded from
	 *                                         store aux
	 * @param satelliteConstraint              the satellite constraint
	 */
	public void processTypeOfPawExcludedFromStoreAux(String allTypeOfPawExcludedFromStoreAux,
			SatelliteProperties satelliteConstraint) {
		// create an empty list of pawType
		List<PAWType> allPawTypeExcluded = new ArrayList<>();

		// get the logger
		Logger logger = DroolsParameters.getLogger();

		// get all the paw types
		PAWType[] pawTypes = PAWType.values();

		// if the string with paws is not empty
		if (allTypeOfPawExcludedFromStoreAux != null) {
			// separate each paw from each other
			String[] pawAsArray = allTypeOfPawExcludedFromStoreAux.split(",");

			// iterate over them
			for (int i = 0; i < pawAsArray.length; i++) {
				// check versus all the paw types
				for (int j = 0; j < pawTypes.length; j++) {
					// if there is a match
					if (pawAsArray[i].trim().equalsIgnoreCase(pawTypes[j].toString().trim())) {
						logger.debug("paw type : " + pawTypes[j] + " is excluded from storeAux computation");

						// add the pawType to the returned list
						allPawTypeExcluded.add(pawTypes[j]);
						break;
					}
				}
			}
		}
		satelliteConstraint.setPawExclusionList(allPawTypeExcluded);
	}

	/**
	 * Sets the all resources.
	 *
	 * @param droolsParams the drools params
	 * @param resFunc      the res func
	 * @param kie          the kie
	 * @param satProp1     the sat prop 1
	 * @param satProp2     the sat prop 2
	 */
	public void setAllResources(DroolsParameters droolsParams, ResourceFunctions resFunc, KieSession kie,
			SatelliteProperties satProp1, SatelliteProperties satProp2) {
		SetResources satRes = new SetResources();
		// set all the satellites
		satRes.setSatellites(droolsParams, kie, satProp1, satProp2);

		// set all the visibilities
		satRes.setVisibilities(droolsParams, resFunc, kie);

		// set all the paws
		satRes.setPaws(droolsParams, kie, resFunc, satProp1, satProp2);

		// set all the pdht
		satRes.setPDHT(droolsParams, kie);

		// set all the eclipses
		satRes.setEclipses(droolsParams, kie);

		// set all the unavailability windows
		satRes.setSatellitesUnavailability(droolsParams, kie);

		// set all the partners
		satRes.setPartners(droolsParams, kie);

	}

	/**
	 * Load properties file.
	 *
	 * @param CONFIG_FILENAME the config filename
	 * @param property        the property
	 * @param localPath       the local path
	 * @param completePath    the complete path
	 * @param moduleName      the module name
	 * @param useLocalPath    the use local path
	 * @throws ConfigurationException the configuration exception
	 */
	public void loadPropertiesFile(String CONFIG_FILENAME, Properties property, String localPath, String completePath,
			String moduleName, boolean useLocalPath) throws ConfigurationException {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		InputStream input = null;
		String propertiesFilePath = null;
		try {
			// if the scope is to test, set the boolean variable to true so will
			// be used the local path for configurations files
			if (useLocalPath) {
				propertiesFilePath = concatenePath(localPath, CONFIG_FILENAME);
				logger.debug("concatenated path : " + propertiesFilePath);
			}

			// otherwise will be used the official path
			else {
				propertiesFilePath = concatenePath(completePath, CONFIG_FILENAME);
				logger.debug("concatenated path : " + propertiesFilePath);
			}
			input = new FileInputStream(propertiesFilePath);

			// store all the properties taken from file with path given as input
			property.load(input);
			input.close();
		} catch (Exception e) {
			// this exception will occur if the
			// config file or the path is incorrect
			logger.debug(moduleName + " read " + propertiesFilePath + " Failed");

			throw new ConfigurationException(moduleName + " read " + propertiesFilePath + " Failed");
		}
	}

	/**
	 * Concatene path.
	 *
	 * @param path the path
	 * @param name the name
	 * @return the string
	 */
	public static String concatenePath(String path, String name) {
		String tmp = path;
		// check the last part of path to see if ends with the / char
		if (!path.endsWith(File.separator)) {
			// if not, add it
			tmp += File.separator;
		}
		// concatenate the filename
		tmp += name;

		return tmp;
	}

	/**
	 * Compute orbit values.
	 *
	 * @param minutesForSingleOrbit the minutes for single orbit
	 * @param orbits                the orbits
	 * @return the double[]
	 */
	public double[] computeOrbitValues(int minutesForSingleOrbit, String[] orbits) {
		// get the logger
		Logger logger = DroolsParameters.getLogger();
		double[] orbitsValues = null;
		try {
			// create an empty array for orbit values
			orbitsValues = new double[orbits.length];
			for (int i = 0; i < orbits.length; i++) {
				logger.debug("processing " + orbits[i]);

				// try to parse the property
				Double d = Double.parseDouble(orbits[i].trim());
				orbitsValues[i] = d * minutesForSingleOrbit;
			}
		} catch (NumberFormatException exception1) {
			// error in conversion, NumberFormatException
			exception1.printStackTrace();
			logger.debug("the value : cannot be casted into a double");
		} catch (NullPointerException exception2) {
			exception2.printStackTrace();

			// empty value , NullPointerException
			logger.debug("the value :  is empty");
		}
		return orbitsValues;
	}

	/**
	 * Gets the properties by name.
	 *
	 * @param propName        the prop name
	 * @param property        the property
	 * @param CONFIG_FILENAME the config filename
	 * @param splaEnv         the spla env
	 * @return the properties by name
	 * @throws ConfigurationException the configuration exception
	 */
	public String getPropertiesByName(String propName, Properties property, final String CONFIG_FILENAME,
			String splaEnv) throws ConfigurationException {

		// get the path for the property to read
		// String key = splaEnv + "." + propName;
		String key = propName;
		// initialize the related value
		String value = null;
		// read the property
		value = property.getProperty(key, null);

		// check if is null
		checkNullValue(value, key + " not configurated");

		return value;
	}

	/**
	 * Read file of max left time.
	 *
	 * @param minTimeRight        the min time right
	 * @param maxTimeLeftFilename the max time left filename
	 */
	public void readFileOfMaxLeftTime(TreeMap<Double, List<MinTimeRight>> minTimeRight, String maxTimeLeftFilename) {
		try {
			// Creates a buffering character-input stream that uses a
			// default-sized input buffer.
			BufferedReader reader = new BufferedReader(new FileReader(maxTimeLeftFilename));
			String line;

			// until the lines are not finished
			while ((line = reader.readLine()) != null) {
				// get the tokenizer
				StringTokenizer st = new StringTokenizer(line, ",");

				// initialize the list of elements
				List<Double> elementInLine = new ArrayList<>();
				double element = 0;

				// iterate over the tokens
				while (st.hasMoreTokens()) {
					try {
						// extract the token
						element = Double.parseDouble(st.nextToken().trim());

						// add to the list
						elementInLine.add(element);
					} catch (NumberFormatException nfe) {
						// System.out.println(nfe.getMessage());
					}
				}

				if (elementInLine.size() == 4) {
					// struttura : time left ->
					// tot ess(left + right) -> ess
					// left -> time right

					double tot = elementInLine.get(0);
					if (minTimeRight.containsKey(elementInLine.get(2))) {
						MinTimeRight minTime = new MinTimeRight(tot, elementInLine.get(1), elementInLine.get(3));
						minTimeRight.get(elementInLine.get(2)).add(minTime);
					} else {
						// create a new array of min timesx
						List<MinTimeRight> minTimeList = new ArrayList<>();

						// setting them with parameters
						MinTimeRight minTime = new MinTimeRight(tot, elementInLine.get(1), elementInLine.get(3));

						// add he new element to the table
						minTimeList.add(minTime);
						minTimeRight.put(elementInLine.get(2), minTimeList);
					}
				}
			}
			System.out.println(minTimeRight);
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Gets the all vis for sat.
	 *
	 * @param allVis     the all vis
	 * @param currentSat the current sat
	 * @return the all vis for sat
	 */
	public static List<Visibility> getAllVisForSat(List<Visibility> allVis, String satId) {
		// create an empty list of visibilities
		List<Visibility> allVisForSat = new ArrayList<>();

		// iterate over all the vis
		for (int i = 0; i < allVis.size(); i++) {
			// if the i-esim vis is linked to the satellite given as input
			if (allVis.get(i).getSatelliteId().equalsIgnoreCase(satId)) {
				// add the visibility to the returned list
				allVisForSat.add(allVis.get(i));
			}
		}
		return allVisForSat;
	}
}
