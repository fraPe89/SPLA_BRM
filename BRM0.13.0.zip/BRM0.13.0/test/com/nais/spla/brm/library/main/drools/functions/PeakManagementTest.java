//
// package com.nais.spla.brm.library.main.drools.functions;
//
// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertFalse;
// import static org.junit.Assert.assertTrue;
// import java.util.ArrayList;
// import java.util.Date;
// import java.util.List;
// import java.util.Map;
// import java.util.TreeMap;
// import org.junit.Before;
// import org.junit.Test;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import com.nais.spla.brm.library.main.drools.DroolsParameters;
// import com.nais.spla.brm.library.main.drools.ResourceFunctions;
// import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
// import com.nais.spla.brm.library.main.ontology.enums.PRType;
// import com.nais.spla.brm.library.main.ontology.resourceData.BicHpPeakOrbit;
// import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
// import com.nais.spla.brm.library.main.ontology.resources.Satellite;
// import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
// import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
//
// public class PeakManagementTest
// {
//
// PeakManagement peakMng = new PeakManagement();
// TreeMap<Long, BicHpPeakOrbit> bicHpPeakOrbitFunction = null;
// DroolsUtils du = new DroolsUtils();
// Logger logger = null;
//
// @Before
// public void setUp()
// {
// this.bicHpPeakOrbitFunction = new TreeMap<Long, BicHpPeakOrbit>();
// logger = LoggerFactory.getLogger(PeakManagementTest.class);
// }
//
// @Test
// public void violatedPeakHpBicInFunction_Test() throws Exception
// {
// double imgBic = 2;
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "right", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setImageBIC(imgBic);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 0;
//
// long startPlusSlidingWindow = acq.getStartTime().getTime() + (minutesForOrbit
// * 60000);
// long endPlusSlidingWindow = acq.getEndTime().getTime() + (minutesForOrbit *
// 60000);
//
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
// ResourceFunctions resFunc = new ResourceFunctions();
// resFunc.setBicHpPeakOrbitFunctionSat1(this.bicHpPeakOrbitFunction);
// boolean insertable = this.peakMng.violatedPeakHpBicInFunction(acq,
// droolsParams,resFunc, sat1, false, false);
// System.out.println("overhead? " + insertable);
// assertFalse(insertable);
// System.out.println(this.bicHpPeakOrbitFunction);
//
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getStartTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getEndTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(startPlusSlidingWindow));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(endPlusSlidingWindow));
//
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()).getTotalEss(),
// 0);
// assertEquals(imgBic,
// this.bicHpPeakOrbitFunction.get(acq.getEndTime().getTime()).getTotalEss(),
// 0);
// assertEquals(imgBic,
// this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow).getTotalEss(), 0);
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow).getTotalEss(), 0);
//
// }
//
// @Test
// public void violatedPeakHpBicInFunction_Test2() throws Exception
// {
// double imgBic = 2;
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setImageBIC(imgBic);
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 0;
//
// long startPlusSlidingWindow = acq.getStartTime().getTime() + (minutesForOrbit
// * 60000);
// long endPlusSlidingWindow = acq.getEndTime().getTime() + (minutesForOrbit *
// 60000);
//
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// MissionHorizon mh = new MissionHorizon();
// mh.setStart(du.createDate("17/01/2018 06:21:00"));
// mh.setStop(du.createDate("17/01/2018 18:21:00"));
// droolsParams.setCurrentMH(mh);
//
// droolsParams.getAllSat().add(sat1);
// ResourceFunctions resFunc = new ResourceFunctions();
//
// TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = new TreeMap<>();
// essFunctionSat1.put(acq.getStartTime().getTime(), new
// EnergyAssociatedToTask(acq, acq.getEss()));
// resFunc.setEssFunctionSat1(essFunctionSat1);
// resFunc.setBicHpPeakOrbitFunctionSat1(this.bicHpPeakOrbitFunction);
// boolean insertable = this.peakMng.violatedPeakHpBicInFunction(acq,
// droolsParams, resFunc, sat1, false, false);
// System.out.println("overhead? " + insertable);
// System.out.println(this.bicHpPeakOrbitFunction);
//
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getStartTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getEndTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(startPlusSlidingWindow));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(endPlusSlidingWindow));
//
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()).getTotalEss(),
// 0);
// assertEquals(imgBic,
// this.bicHpPeakOrbitFunction.get(acq.getEndTime().getTime()).getTotalEss(),
// 0);
// assertEquals(imgBic,
// this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow).getTotalEss(), 0);
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow).getTotalEss(), 0);
//
// }
//
// @Test
// public void insertAndRemoveFromFunction_Test() throws Exception
// {
// double essAssociatedToAcq = 21;
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setImageBIC(essAssociatedToAcq);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 2;
//
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
//
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// long startPlusSlidingWindow = acq.getStartTime().getTime() + (minutesForOrbit
// * 60000);
// long endPlusSlidingWindow = acq.getEndTime().getTime() + (minutesForOrbit *
// 60000);
//
// boolean violated = this.peakMng.violatedPeakHpBicInFunction(acq,
// droolsParams, this.bicHpPeakOrbitFunction, sat1, false, false);
// assertFalse(violated);
// System.out.println("violated . " + violated);
// System.out.println(this.bicHpPeakOrbitFunction);
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getStartTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getEndTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(startPlusSlidingWindow));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(endPlusSlidingWindow));
//
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()).getTotalEss(),
// 0);
// assertEquals(essAssociatedToAcq,
// this.bicHpPeakOrbitFunction.get(acq.getEndTime().getTime()).getTotalEss(),
// 0);
// assertEquals(essAssociatedToAcq,
// this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow).getTotalEss(), 0);
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow).getTotalEss(), 0);
//
// violated = this.peakMng.violatedPeakHpBicInFunction(acq, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, true, false);
//
// assertEquals(0, this.bicHpPeakOrbitFunction.size());
// assertFalse(this.bicHpPeakOrbitFunction.containsKey(acq.getStartTime().getTime()));
// assertFalse(this.bicHpPeakOrbitFunction.containsKey(acq.getEndTime().getTime()));
// assertFalse(this.bicHpPeakOrbitFunction.containsKey(startPlusSlidingWindow));
// assertFalse(this.bicHpPeakOrbitFunction.containsKey(endPlusSlidingWindow));
// }
//
// @Test
// public void receivePreviousElement_exists_previous_Test() throws Exception
// {
// double essAssociatedToAcq = 2;
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setEss(essAssociatedToAcq);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 2;
//
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
//
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// boolean violated = this.peakMng.violatedPeakHpBicInFunction(acq,
// droolsParams, this.bicHpPeakOrbitFunction, sat1, false, false);
// assertFalse(violated);
//
// long keyToSearch = acq.getEndTime().getTime();
//
// double expectedValue =
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()).getTotalEss();
// double returnedValue = this.peakMng.receivePreviousElement(keyToSearch,
// this.bicHpPeakOrbitFunction);
// assertEquals(expectedValue, returnedValue, 0);
// }
//
// @Test
// public void receivePreviousElement_doesn_t_exists_previousTest() throws
// Exception
// {
// double essAssociatedToAcq = 2;
// assertEquals(0, this.bicHpPeakOrbitFunction.size());
//
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setEss(essAssociatedToAcq);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 2;
//
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
//
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// boolean violated = this.peakMng.violatedPeakHpBicInFunction(acq,
// droolsParams, this.bicHpPeakOrbitFunction, sat1, false, false);
//
// assertEquals(false, violated);
//
// long keyToSearch = acq.getStartTime().getTime();
//
// double expectedValue = 0.0;
// double returnedValue = this.peakMng.receivePreviousElement(keyToSearch,
// this.bicHpPeakOrbitFunction);
// assertEquals(expectedValue, returnedValue, 0);
//
// }
//
// @Test
// public void testComputePeakOrbitInInterval() throws Exception
// {
//
// }
//
// @Test
// public void updateMapTest() throws Exception
// {
// double essAssociatedToAcq1 = 2;
// double essAssociatedToAcq2 = 4;
// assertEquals(0, this.bicHpPeakOrbitFunction.size());
//
// Acquisition acq1 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq1.setPrType(PRType.HP);
// acq1.setImageBIC(essAssociatedToAcq1);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 2;
//
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
//
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// boolean violated = this.peakMng.violatedPeakHpBicInFunction(acq1,
// droolsParams, this.bicHpPeakOrbitFunction, sat1, false, false);
//
// assertFalse(violated);
//
// Acquisition acq2 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:13:03", "17/01/2018 11:14:00", "left", "SAT_1");
// acq2.setPrType(PRType.HP);
// acq2.setImageBIC(essAssociatedToAcq2);
//
// violated = this.peakMng.violatedPeakHpBicInFunction(acq2, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false, false);
// assertFalse(violated);
//
// for (Map.Entry<Long, BicHpPeakOrbit> elements :
// this.bicHpPeakOrbitFunction.entrySet())
// {
// System.out.println("at time " + new Date(elements.getKey()) + " there is : "
// + elements.getValue());
// }
//
// long startPlusSlidingWindow1 = acq1.getStartTime().getTime() +
// (minutesForOrbit * 60000);
// long endPlusSlidingWindow1 = acq1.getEndTime().getTime() + (minutesForOrbit *
// 60000);
//
// long startPlusSlidingWindow2 = acq2.getStartTime().getTime() +
// (minutesForOrbit * 60000);
// long endPlusSlidingWindow2 = acq2.getEndTime().getTime() + (minutesForOrbit *
// 60000);
//
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(acq1.getStartTime().getTime()).getTotalEss(),
// 0);
// assertEquals(essAssociatedToAcq1,
// this.bicHpPeakOrbitFunction.get(acq1.getEndTime().getTime()).getTotalEss(),
// 0);
// assertEquals(essAssociatedToAcq1,
// this.bicHpPeakOrbitFunction.get(acq2.getStartTime().getTime()).getTotalEss(),
// 0);
// assertEquals((essAssociatedToAcq1 + essAssociatedToAcq2),
// this.bicHpPeakOrbitFunction.get(acq2.getEndTime().getTime()).getTotalEss(),
// 0);
// assertEquals((essAssociatedToAcq1 + essAssociatedToAcq2),
// this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow1).getTotalEss(), 0);
// assertEquals(essAssociatedToAcq2,
// this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow1).getTotalEss(), 0);
// assertEquals(essAssociatedToAcq2,
// this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow2).getTotalEss(), 0);
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow2).getTotalEss(), 0);
//
// int reachedValue = this.peakMng.updateMap(droolsParams, acq1,
// acq1.getStartTime().getTime(), endPlusSlidingWindow1, 5,
// this.bicHpPeakOrbitFunction);
// System.out.println(reachedValue);
// }
//
// @Test
// public void updateEssTotalTest() throws Exception
// {
// double essAssociatedToAcq1 = 2;
// int threshold = 1;
//
// assertEquals(0, this.bicHpPeakOrbitFunction.size());
//
// Acquisition acq1 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq1.setPrType(PRType.HP);
// acq1.setImageBIC(essAssociatedToAcq1);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 2;
//
// DroolsParameters droolsParams = new DroolsParameters();
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// DroolsParameters.setLogger(logger);
//
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// boolean violated = this.peakMng.violatedPeakHpBicInFunction(acq1,
// droolsParams, this.bicHpPeakOrbitFunction, sat1, false, false);
// assertFalse(violated);
//
// for (Map.Entry<Long, BicHpPeakOrbit> elements :
// this.bicHpPeakOrbitFunction.entrySet())
// {
// System.out.println("at time " + new Date(elements.getKey()) + " there is : "
// + elements.getValue());
// }
// List<String> elementsInvolved = new ArrayList<String>();
// BicHpPeakOrbit bicHpElement =
// this.bicHpPeakOrbitFunction.get(acq1.getEndTime().getTime());
// int exceedeedThreshold = this.peakMng.updateBicTotal(droolsParams, acq1,
// acq1.getEndTime().getTime(), bicHpElement, this.bicHpPeakOrbitFunction,
// threshold, elementsInvolved);
// System.out.println(exceedeedThreshold);
// assertEquals(1, exceedeedThreshold);
// }
//
// @Test
// public void checkOnDailySlidingWindowTest() throws Exception
// {
// int minutesForOrbit = 97;
// Acquisition acq1 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq1.setId("dto1");
// acq1.setPrType(PRType.HP);
// acq1.setImageBIC(14);
//
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 2;
//
// DroolsParameters droolsParams = new DroolsParameters();
// DroolsParameters.setLogger(logger);
//
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// this.peakMng.violatedPeakHpBicInFunction(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false, false);
// this.peakMng.overheadOnDailySlidingWindow(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false);
//
// Acquisition acq2 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 12:10:03", "17/01/2018 12:12:00", "left", "SAT_1");
// acq2.setId("dto2");
// acq2.setPrType(PRType.HP);
// acq2.setImageBIC(7);
// this.peakMng.violatedPeakHpBicInFunction(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false, false);
// this.peakMng.overheadOnDailySlidingWindow(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false);
//
// Acquisition acq3 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:30:03", "17/01/2018 11:32:00", "left", "SAT_1");
// acq3.setId("dto3");
// acq3.setPrType(PRType.HP);
// acq3.setImageBIC(2);
// this.peakMng.violatedPeakHpBicInFunction(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false, false);
// this.peakMng.overheadOnDailySlidingWindow(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false);
//
// Acquisition acq4 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "18/01/2018 11:10:03", "18/01/2018 11:12:00", "left", "SAT_1");
// acq4.setId("dto4");
// acq4.setPrType(PRType.HP);
// acq4.setImageBIC(10);
// this.peakMng.violatedPeakHpBicInFunction(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false, false);
//
// Acquisition acq5 =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "18/01/2018 08:10:03", "18/01/2018 08:12:00", "left", "SAT_1");
// acq5.setId("dto5");
// acq5.setPrType(PRType.HP);
// acq5.setImageBIC(10);
// this.peakMng.violatedPeakHpBicInFunction(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false, false);
//
// this.peakMng.overheadOnDailySlidingWindow(acq1, droolsParams,
// this.bicHpPeakOrbitFunction, sat1, false);
// }
//
// @Test
// public void removeFromFunctionTest() throws Exception
// {
// double essAssociatedToAcq = 2;
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setImageBIC(essAssociatedToAcq);
//
// int minutesForOrbit = 97;
// int minPeakForOrbit = 18;
// int maxPeakForOrbit = 24;
// int maxNumberDailyPeak = 0;
//
// long startPlusSlidingWindow = acq.getStartTime().getTime() + (minutesForOrbit
// * 60000);
// long endPlusSlidingWindow = acq.getEndTime().getTime() + (minutesForOrbit *
// 60000);
//
// DroolsParameters droolsParams = new DroolsParameters();
// droolsParams.setMinutesForOrbit(minutesForOrbit);
// DroolsParameters.setLogger(logger);
//
// Satellite sat1 = new Satellite("SAT_1", "satellite_1", null, null, null,
// "right");
// sat1.getSatelliteProperties().setUpperBoundPeakOrbit(maxPeakForOrbit);
// sat1.getSatelliteProperties().setLowerBoundPeakOrbit(minPeakForOrbit);
// sat1.getSatelliteProperties().setMaxNumberDailyPeak(maxNumberDailyPeak);
//
// droolsParams.getAllSat().add(sat1);
//
// boolean violated = this.peakMng.violatedPeakHpBicInFunction(acq,
// droolsParams, this.bicHpPeakOrbitFunction, sat1, false, false);
//
// assertFalse(violated);
// System.out.println(this.bicHpPeakOrbitFunction);
//
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getStartTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(acq.getEndTime().getTime()));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(startPlusSlidingWindow));
// assertTrue(this.bicHpPeakOrbitFunction.containsKey(endPlusSlidingWindow));
//
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()).getTotalEss(),
// 0);
// assertEquals(essAssociatedToAcq,
// this.bicHpPeakOrbitFunction.get(acq.getEndTime().getTime()).getTotalEss(),
// 0);
// assertEquals(essAssociatedToAcq,
// this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow).getTotalEss(), 0);
// assertEquals(0,
// this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow).getTotalEss(), 0);
//
// this.peakMng.removeFromFunction(droolsParams, acq,
// this.bicHpPeakOrbitFunction, acq.getStartTime().getTime(),
// acq.getEndTime().getTime(), startPlusSlidingWindow, endPlusSlidingWindow,
// maxPeakForOrbit);
//
// assertEquals(0, this.bicHpPeakOrbitFunction.size());
//
// assertEquals(null,
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()));
// assertEquals(null,
// this.bicHpPeakOrbitFunction.get(acq.getEndTime().getTime()));
// assertEquals(null, this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow));
// assertEquals(null, this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow));
//
// System.out.println("function after remove :" + this.bicHpPeakOrbitFunction);
//
// }
//
// @Test
// public void removeFromFunction_nothing_To_remove_Test() throws Exception
// {
// DroolsParameters droolsParams = new DroolsParameters();
//
// double essAssociatedToAcq = 2;
// Acquisition acq =
// this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
// "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
// acq.setPrType(PRType.HP);
// acq.setImageBIC(essAssociatedToAcq);
//
// double minutesForOrbit = 97;
// int maxPeakForOrbit = 24;
//
// long startPlusSlidingWindow = (long) (acq.getStartTime().getTime() +
// (minutesForOrbit * 60000));
// long endPlusSlidingWindow = (long) (acq.getEndTime().getTime() +
// (minutesForOrbit * 60000));
//
// this.peakMng.removeFromFunction(droolsParams, acq,
// this.bicHpPeakOrbitFunction, acq.getStartTime().getTime(),
// acq.getEndTime().getTime(), startPlusSlidingWindow, endPlusSlidingWindow,
// maxPeakForOrbit);
//
// assertEquals(0, this.bicHpPeakOrbitFunction.size());
//
// assertEquals(null,
// this.bicHpPeakOrbitFunction.get(acq.getStartTime().getTime()));
// assertEquals(null,
// this.bicHpPeakOrbitFunction.get(acq.getEndTime().getTime()));
// assertEquals(null, this.bicHpPeakOrbitFunction.get(startPlusSlidingWindow));
// assertEquals(null, this.bicHpPeakOrbitFunction.get(endPlusSlidingWindow));
// System.out.println("function after remove :" + this.bicHpPeakOrbitFunction);
// }
//
// @Test
// public void testGetPreviousSh() throws Exception
// {
//
// }
//
// }
