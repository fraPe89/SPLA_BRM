
package com.nais.spla.brm.library.main.drools.rules;

import static org.junit.Assert.assertEquals;

import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class InsertCmgaRuleTest
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestTheatre";
        this.maxBicForTest = 200;
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void insedrtCmgRule_insideAPlateau() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:30", "left", satelliteId);
        dto2.setImageBIC(2);
        dto2.setPrType(PRType.PP);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);
    }

}
