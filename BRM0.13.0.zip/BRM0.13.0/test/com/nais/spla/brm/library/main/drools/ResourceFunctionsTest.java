
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.TreeMap;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.ElementsTillThreshold;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class ResourceFunctionsTest {

	ResourceFunctions resFunc = new ResourceFunctions();
	DroolsUtils du = new DroolsUtils();

	@Test
	public void testCalculateLocalMax() throws Exception {
		Date fromAsDate = DroolsUtils.createDate("10/10/2017 17:00:00");
		Date toAsDate = DroolsUtils.createDate("10/10/2017 19:00:00");

		Acquisition borderlineStartAcq = this.du.createParametricAcquisition("borderlineStartAcq",
				"10/10/2017 16:56:00", "10/10/2017 17:02:00", "right", "SAT_1");
		Acquisition acqInsideInterval1 = this.du.createParametricAcquisition("acqInsideInterval1",
				"10/10/2017 17:37:00", "10/10/2017 17:38:00", "right", "SAT_1");
		Acquisition acqInsideInterval2 = this.du.createParametricAcquisition("acqInsideInterval2",
				"10/10/2017 18:52:13", "10/10/2017 18:56:00", "right", "SAT_1");
		Acquisition borderlineEndAcq = this.du.createParametricAcquisition("borderlineEndAcq", "10/10/2017 18:59:00",
				"10/10/2017 19:03:00", "right", "SAT_1");
		Acquisition totallyOutsideAcq = this.du.createParametricAcquisition("totallyOutsideAcq", "10/10/2017 20:52:13",
				"10/10/2017 20:56:00", "right", "SAT_1");

		long from = fromAsDate.getTime();
		long to = toAsDate.getTime();

		TreeMap<Long, EnergyAssociatedToTask> energyFunction = new TreeMap<>();
		energyFunction.put(borderlineStartAcq.getStartTime().getTime(),
				new EnergyAssociatedToTask(borderlineStartAcq, 10));
		energyFunction.put(acqInsideInterval1.getStartTime().getTime(),
				new EnergyAssociatedToTask(acqInsideInterval1, 20));
		energyFunction.put(acqInsideInterval2.getStartTime().getTime(),
				new EnergyAssociatedToTask(acqInsideInterval2, 30));
		energyFunction.put(borderlineEndAcq.getStartTime().getTime(), new EnergyAssociatedToTask(borderlineEndAcq, 40));
		energyFunction.put(totallyOutsideAcq.getStartTime().getTime(),
				new EnergyAssociatedToTask(totallyOutsideAcq, 50));

		ElementsTillThreshold maxReachedValue = this.resFunc.calculateLocalMax(from, to, energyFunction);
		System.out.println("max reached value : " + maxReachedValue);

		assertEquals(100, maxReachedValue.getReachedValue(), 0);
		assertTrue(maxReachedValue.getElementsChecked().contains(borderlineStartAcq.getIdTask()));
		assertTrue(maxReachedValue.getElementsChecked().contains(acqInsideInterval1.getIdTask()));
		assertTrue(maxReachedValue.getElementsChecked().contains(acqInsideInterval2.getIdTask()));
		assertTrue(maxReachedValue.getElementsChecked().contains(borderlineEndAcq.getIdTask()));
		assertFalse(maxReachedValue.getElementsChecked().contains(totallyOutsideAcq.getIdTask()));

	}

	@Test
	public void testSetDownloadPriorityQueueForSat() throws Exception {
		TreeMap<String, PriorityQueue> downloadPriorityQueue1 = new TreeMap<String, PriorityQueue>();
		TreeMap<String, PriorityQueue> downloadPriorityQueue2 = new TreeMap<String, PriorityQueue>();

		resFunc.setDownloadPriorityQueueForSat("1", downloadPriorityQueue1);
		resFunc.setDownloadPriorityQueueForSat("2", downloadPriorityQueue2);

		TreeMap<String, PriorityQueue> returnedPriorityQueue1 = resFunc.getDownloadPriorityQueueForSat("1");
		assertEquals(returnedPriorityQueue1,downloadPriorityQueue1);
		

		TreeMap<String, PriorityQueue> returnedPriorityQueue2 = resFunc.getDownloadPriorityQueueForSat("2");
		assertEquals(returnedPriorityQueue2,downloadPriorityQueue2);
	}
	
	@Test
	public void testSetDownloadPriorityQueueSatInitPlanSat() throws Exception {
		TreeMap<String, PriorityQueue> downloadPriorityQueue1 = new TreeMap<String, PriorityQueue>();
		TreeMap<String, PriorityQueue> downloadPriorityQueue2 = new TreeMap<String, PriorityQueue>();

		resFunc.setDownloadPriorityQueueSatInitPlanSat("1", downloadPriorityQueue1);
		resFunc.setDownloadPriorityQueueSatInitPlanSat("2", downloadPriorityQueue2);

		TreeMap<String, PriorityQueue> returnedPriorityQueue1 = resFunc.getDownloadPriorityQueueSatInitPlan1();
		assertEquals(returnedPriorityQueue1,downloadPriorityQueue1);
		
		resFunc.setDownloadPriorityQueueSatInitPlan2(downloadPriorityQueue2);

		TreeMap<String, PriorityQueue> returnedPriorityQueue2 = resFunc.getDownloadPriorityQueueSatInitPlan2();
		assertEquals(returnedPriorityQueue2,downloadPriorityQueue2);
	}

}
