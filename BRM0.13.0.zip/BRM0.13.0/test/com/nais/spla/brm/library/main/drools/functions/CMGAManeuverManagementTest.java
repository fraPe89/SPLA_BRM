
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.LoggerFactory;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.utils.CmgaResources;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

public class CMGAManeuverManagementTest
{

    private DroolsUtils du = null;
    private CMGAManeuverManagement cmgaMng = null;
    private SimpleDateFormat formatter = null;
    private DroolsParameters droolsParams = null;
    private TreeMap<Long, Maneuver> allManForSatellite = null;
    private TreeMap<Long, RampCMGA> allRumps = null;
    private List<CMGA> allCmgaForSatellite = null;
    private Satellite sat = null;
    private long tAcc = 0;

    @Before
    public void setUp() throws ParseException
    {
        this.du = new DroolsUtils();
        this.cmgaMng = new CMGAManeuverManagement();
        this.formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        this.allManForSatellite = new TreeMap<>();
        this.allRumps = new TreeMap<>();
        this.allCmgaForSatellite = new ArrayList<>();
        this.tAcc = 180;
        this.sat = new Satellite("SAT_1", "satellite_1", null, null, null, "right");
        this.droolsParams = new DroolsParameters();
        this.droolsParams.setMinutesForOrbit(97);
        this.droolsParams.getAllSat().add(this.sat);
        Map<Double, ResourceMaxValue> allChecks = new HashMap<>();
        allChecks.put(1.0, new ResourceMaxValue());
        ResourceMaxValue resource = new ResourceMaxValue(97d, 0l, 0d, 0, 0, 0, 0d);
        allChecks.put(1d, resource);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(allChecks);
        DroolsParameters.setLogger(LoggerFactory.getLogger(CMGAManeuverManagementTest.class));
        Date startTime = DroolsUtils.createDate("17/01/2018 06:21:00");
        Date endTime = DroolsUtils.createDate("17/01/2018 18:21:00");
        MissionHorizon mh = new MissionHorizon(startTime, endTime);
        this.droolsParams.setCurrentMH(mh);
    }

    @Test
    public void testCreateACmgManeuver_Case_previous_Is_Left() throws Exception
    {
        System.out.println("\n\nRUNNING TEST : testCreateACmgManeuver_Case_previous_Is_Left");
        String satelliteIdForTest = "SAT_1";
        Maneuver createdMan = null;
        long tranquillizationTime = 20;
        long timeForCmgManeuver = 240; // expressed in seconds

        Acquisition acqPrev = this.du.createParametricAcquisition("acq_prev", "17/01/2018 15:55:00", "17/01/2018 16:00:00", "left", satelliteIdForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_next", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "right", satelliteIdForTest);

        Date maxEndMan = DroolsUtils.createDate("17/01/2018 18:55:00");

        DateResource dateRes = new DateResource();
        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(new Date(maxEndMan.getTime() - tranquillizationTime));
        createdMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, acqNext, timeForCmgManeuver, tranquillizationTime);

        /*
         * expectedStart = formatter.parse("17/01/2018 16:00:03"); expectedEnd =
         * formatter.parse("17/01/2018 16:04:03");
         *
         * assertEquals(expectedStart, createdMan.getStartTime());
         * assertEquals(expectedEnd, createdMan.getEndTime());
         */
        assertEquals("acq_prev", createdMan.getAcq1Id());
        assertEquals("acq_next", createdMan.getAcq2Id());
        assertEquals(satelliteIdForTest, createdMan.getSatelliteId());
        assertEquals(Actuator.CMGA, createdMan.getActuator());

    }

    @Test
    public void testCreateACmgManeuver_Case_previous_Is_Right() throws Exception
    {
        System.out.println("\n\nRUNNING TEST : testCreateACmgManeuver_Case_previous_Is_Right");
        String satelliteIdForTest = "SAT_1";
        Maneuver createdMan = null;

        long timeForCmgManeuver = 240; // expressed in seconds

        Acquisition acqPrev = this.du.createParametricAcquisition("acq_prev", "17/01/2018 15:55:00", "17/01/2018 16:00:00", "right", satelliteIdForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_next", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "left", satelliteIdForTest);

        long tranquillizationTime = 20;
        DateResource dateRes = new DateResource();
        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(new Date(acqNext.getStartTime().getTime() - tranquillizationTime));
        createdMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, acqNext, timeForCmgManeuver, tranquillizationTime);

        System.out.println("man created : " + createdMan);

        // assertEquals(expectedStart, createdMan.getStartTime());
        // assertEquals(expectedEnd, createdMan.getEndTime());
        assertEquals("acq_prev", createdMan.getAcq1Id());
        assertEquals("acq_next", createdMan.getAcq2Id());
        assertEquals(satelliteIdForTest, createdMan.getSatelliteId());
        assertEquals(Actuator.CMGA, createdMan.getActuator());

    }

    @Test
    public void testCreateACmgManeuver_Case_previous_Is_Null() throws Exception
    {
        System.out.println("\n\nRUNNING TEST : testCreateACmgManeuver_Case_previous_Is_Null");
        String satelliteIdForTest = "SAT_1";
        Maneuver createdMan = null;
        Date expectedEnd = DroolsUtils.createDate("17/01/2018 16:59:40");

        long timeForCmgManeuver = 240; // expressed in seconds

        Acquisition acqPrev = null;
        Acquisition acqNext = this.du.createParametricAcquisition("acq_next", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "left", satelliteIdForTest);
        acqNext.setSensorMode(TypeOfAcquisition.PINGPONG);

        Date missionHorizonStart = DroolsUtils.createDate("17/01/2018 15:00:00");

        long tranquillizationTime = 20000;
        DateResource dateRes = new DateResource();
        dateRes.setStart(missionHorizonStart);
        dateRes.setStop(new Date(acqNext.getStartTime().getTime() - tranquillizationTime));
        dateRes.setEnd(true);
        createdMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, acqNext, timeForCmgManeuver, tranquillizationTime);

        System.out.println(createdMan);
        assertEquals(expectedEnd.getTime(), createdMan.getEndTime().getTime());
        assertEquals("x", createdMan.getAcq1Id());
        assertEquals("acq_next", createdMan.getAcq2Id());
        assertEquals(satelliteIdForTest, createdMan.getSatelliteId());
        assertEquals(Actuator.CMGA, createdMan.getActuator());

    }

    @Test
    public void testCreateACmgManeuver_Case_next_Is_null() throws Exception
    {
        System.out.println("\n\nRUNNING TEST : testCreateACmgManeuver_Case_next_Is_null");
        String satelliteIdForTest = "SAT_1";
        Maneuver createdMan = null;
        Date expectedStart = null;
        Date expectedEnd = null;
        long tranquillizationTime = 20;
        long timeForCmgManeuver = 240; // expressed in seconds

        Acquisition acqPrev = this.du.createParametricAcquisition("acq_prev", "17/01/2018 15:55:00", "17/01/2018 16:00:00", "right", satelliteIdForTest);
        Date maxEndMan = DroolsUtils.createDate("17/01/2018 18:55:00");

        DateResource dateRes = new DateResource();
        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(new Date(maxEndMan.getTime() - tranquillizationTime));
        createdMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, null, timeForCmgManeuver, tranquillizationTime);

        expectedStart = this.formatter.parse("17/01/2018 16:00:00");
        expectedEnd = this.formatter.parse("17/01/2018 16:04:00");

        assertEquals(expectedStart, createdMan.getStartTime());
        assertEquals(expectedEnd, createdMan.getEndTime());
        assertEquals("acq_prev", createdMan.getAcq1Id());
        assertEquals("x", createdMan.getAcq2Id());
        assertEquals(satelliteIdForTest, createdMan.getSatelliteId());
        assertEquals(Actuator.CMGA, createdMan.getActuator());

    }

    @Test
    public void testFindIfThereAreManeuverTooClose_only_one_man() throws Exception
    {
        String satelliteForTest = "SAT_1";
        long timeForCmgManeuver = 240;
        long tAcc = 180;
        long tranquillizationTime = 20;

        Maneuver existingMan1 = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:56:00", "17/01/2018 11:00:00", satelliteForTest, Actuator.CMGA);
        RampCMGA rumpUpMan1 = this.du.createRamp("17/01/2018 10:53:00", true);
        RampCMGA rumpDownMan1 = this.du.createRamp("17/01/2018 11:00:00", false);

        this.allManForSatellite.put(existingMan1.getStartTime().getTime(), existingMan1);
        this.allRumps.put(rumpUpMan1.getStartTime().getTime(), rumpUpMan1);
        this.allRumps.put(rumpDownMan1.getStartTime().getTime(), rumpDownMan1);

        Acquisition acqPrev = this.du.createParametricAcquisition("acq_1", "17/01/2018 11:00:03", "17/01/2018 11:02:00", "left", satelliteForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_2", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "right", satelliteForTest);

        DateResource dateRes = new DateResource();
        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(new Date(acqNext.getStartTime().getTime() - tranquillizationTime));
        Maneuver newMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, acqNext, timeForCmgManeuver, tranquillizationTime);

        System.out.println("new man created : " + newMan);
        List<Maneuver> resultMan = new ArrayList<>();

        resultMan = this.cmgaMng.findIfThereAreManeuverTooClose(newMan, this.allManForSatellite, this.allRumps, tAcc);
        System.out.println("man returned from the method : " + resultMan);
        assertEquals(existingMan1, resultMan.get(0));
        assertEquals(1, resultMan.size());
    }

    @Test
    public void testFindIfThereAreManeuverTooClose_null_case() throws Exception
    {
        String satelliteForTest = "SAT_1";
        long timeForCmgManeuver = 240;
        long minTimeToMergeAcq = 360;
        long tranquillizationTime = 20;

        Maneuver existingMan1 = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:00:00", "17/01/2018 10:04:00", satelliteForTest, Actuator.CMGA);
        RampCMGA rumpUpMan1 = this.du.createRamp("17/01/2018 09:57:00", true);
        RampCMGA rumpDownMan1 = this.du.createRamp("17/01/2018 10:04:00", false);

        this.allManForSatellite.put(existingMan1.getStartTime().getTime(), existingMan1);
        this.allRumps.put(rumpUpMan1.getStartTime().getTime(), rumpUpMan1);
        this.allRumps.put(rumpDownMan1.getStartTime().getTime(), rumpDownMan1);

        Acquisition acqPrev = this.du.createParametricAcquisition("acq_1", "17/01/2018 11:00:03", "17/01/2018 11:02:00", "left", satelliteForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_2", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "right", satelliteForTest);

        DateResource dateRes = new DateResource();
        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(new Date(acqNext.getStartTime().getTime() - tranquillizationTime));
        Maneuver newMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, acqNext, timeForCmgManeuver, tranquillizationTime);

        this.allManForSatellite.put(newMan.getStartTime().getTime(), newMan);
        List<Maneuver> resultMan = this.cmgaMng.findIfThereAreManeuverTooClose(newMan, this.allManForSatellite, this.allRumps, minTimeToMergeAcq);
        System.out.println("man returned from the method : " + resultMan);
        assertEquals(0, resultMan.size());
    }

    @Test
    public void testFindIfThereAreManeuverTooClosemore_than_one() throws Exception
    {
        String satelliteForTest = "SAT_1";
        long timeForCmgManeuver = 240;
        long minTimeToMergeAcq = 360;
        Maneuver existingMan1 = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:53:00", "17/01/2018 10:57:00", satelliteForTest, Actuator.CMGA);
        RampCMGA rumpUpMan1 = this.du.createRamp("17/01/2018 10:50:00", true);
        RampCMGA rumpDownMan1 = this.du.createRamp("17/01/2018 10:57:00", false);

        this.allManForSatellite.put(existingMan1.getStartTime().getTime(), existingMan1);
        this.allRumps.put(rumpUpMan1.getStartTime().getTime(), rumpUpMan1);
        this.allRumps.put(rumpDownMan1.getStartTime().getTime(), rumpDownMan1);

        Maneuver existingMan2 = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 11:10:00", "17/01/2018 11:14:00", satelliteForTest, Actuator.CMGA);
        RampCMGA rumpUpMan2 = this.du.createRamp("17/01/2018 11:07:00", true);
        RampCMGA rumpDownMan2 = this.du.createRamp("17/01/2018 11:14:00", false);

        this.allManForSatellite.put(existingMan2.getStartTime().getTime(), existingMan2);
        this.allRumps.put(rumpUpMan2.getStartTime().getTime(), rumpUpMan2);
        this.allRumps.put(rumpDownMan2.getStartTime().getTime(), rumpDownMan2);

        Acquisition acqPrev = this.du.createParametricAcquisition("acq_1", "17/01/2018 11:00:03", "17/01/2018 11:02:00", "left", satelliteForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_2", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "right", satelliteForTest);

        DateResource dateRes = new DateResource();
        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(new Date(acqNext.getStartTime().getTime() - 20));
        Maneuver newMan = this.cmgaMng.createACmgManeuver(dateRes, acqPrev, acqNext, timeForCmgManeuver, 20);

        List<Maneuver> resultMan = new ArrayList<>();

        resultMan = this.cmgaMng.findIfThereAreManeuverTooClose(newMan, this.allManForSatellite, this.allRumps, minTimeToMergeAcq);
        System.out.println("man returned from the method :\n " + resultMan + "\n" + resultMan.get(1));
        assertEquals(2, resultMan.size());

        assertEquals(true, resultMan.contains(existingMan1));
        assertEquals(true, resultMan.contains(existingMan2));

    }

    @Test
    public void testRemoveAcqWithManInSinglePlateau()
    {
        System.out.println("RUNNING TEST : testRemoveAcqWithManInSinglePlateau");
        ResourceFunctions resourceFunctions = new ResourceFunctions();

        String satelliteForTest = "SAT_1";

        // creating the cmga units for the satellite
        // where the parameters are : String cmgaId, double wAcc, double tAcc,
        // double wPlat, double wRest, double maxPowerForOrbit,boolean operative
        CMGA cmga1 = new CMGA("cmga1", 25, 180, 25, 15, true, satelliteForTest);
        CMGA cmga2 = new CMGA("cmga2", 25, 180, 25, 15, false, satelliteForTest);
        CMGA cmga3 = new CMGA("cmga3", 25, 180, 25, 15, true, satelliteForTest);
        this.allCmgaForSatellite.add(cmga1);
        this.allCmgaForSatellite.add(cmga2);
        this.allCmgaForSatellite.add(cmga3);

        TreeMap<Long, Maneuver> allManForSatellite = new TreeMap<>();
        TreeMap<Long, RampCMGA> allRumps = new TreeMap<>();

        Maneuver manToRemoveForTest = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:56:00", "17/01/2018 11:00:00", satelliteForTest, Actuator.CMGA);
        allManForSatellite.put(manToRemoveForTest.getStartTime().getTime(), manToRemoveForTest);

        // creating the rumps up and down related to the maneuver under test
        RampCMGA rumpUpRelatedToManToRemove = this.du.createRamp("17/01/2018 10:53:00", true);
        RampCMGA rumpDownRelatedToManToRemove = this.du.createRamp("17/01/2018 11:00:00", false);
        allRumps.put(rumpUpRelatedToManToRemove.getStartTime().getTime(), rumpUpRelatedToManToRemove);
        allRumps.put(rumpDownRelatedToManToRemove.getStartTime().getTime(), rumpDownRelatedToManToRemove);

        System.out.println("maneuvers function contains : " + allManForSatellite.size() + " elements");
        System.out.println("rumps function contains : " + allRumps.size() + " elements");

        System.out.println("scenario 1 : the man that must be removed was involved in a single cmga plateau");
        resourceFunctions.setAllManeuversSat1(allManForSatellite);
        resourceFunctions.setAllRampsSat1(allRumps);
        this.cmgaMng.removeCMGA(manToRemoveForTest, resourceFunctions, this.allCmgaForSatellite, this.tAcc);

        assertEquals(0, resourceFunctions.getAllManeuversSat1().size());
        assertEquals(0, resourceFunctions.getAllRampsSat1().size());
        System.out.println("after delete, maneuvers function contains : " + allManForSatellite.size() + " elements");
        System.out.println("after delete, rumps function contains : " + allRumps.size() + " elements");

    }

    @Test
    public void testRemoveAcqWithManThatIsTheFirstOfATrainOfCmg()
    {
        System.out.println("RUNNING TEST : testRemoveAcqWithManThatIsTheFirstOfATrainOfCmg");
        ResourceFunctions resourceFunctions = new ResourceFunctions();
        String satelliteForTest = "SAT_1";
        double secondsForRumpUp = 180;
        // creating the cmga units for the satellite
        // where the parameters are : String cmgaId, double wAcc, double tAcc,
        // double wPlat, double wRest, double maxPowerForOrbit,boolean operative
        CMGA cmga1 = new CMGA("cmga1", 25, 180, 25, 15, true, satelliteForTest);
        CMGA cmga2 = new CMGA("cmga2", 25, 180, 25, 15, false, satelliteForTest);
        CMGA cmga3 = new CMGA("cmga3", 25, 180, 25, 15, true, satelliteForTest);
        this.allCmgaForSatellite.add(cmga1);
        this.allCmgaForSatellite.add(cmga2);
        this.allCmgaForSatellite.add(cmga3);

        TreeMap<Long, Maneuver> allManForSatellite = new TreeMap<>();
        TreeMap<Long, RampCMGA> allRumps = new TreeMap<>();

        Maneuver manToRemoveForTest = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:56:00", "17/01/2018 11:00:00", satelliteForTest, Actuator.CMGA);
        allManForSatellite.put(manToRemoveForTest.getStartTime().getTime(), manToRemoveForTest);

        Acquisition acqBetweenMan = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "right", satelliteForTest);
        Maneuver anotherManInTheTrainOfMan = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 11:12:00", "17/01/2018 11:19:00", satelliteForTest, Actuator.CMGA);
        allManForSatellite.put(anotherManInTheTrainOfMan.getStartTime().getTime(), anotherManInTheTrainOfMan);

        // creating the rumps up and down related to the maneuver under test
        RampCMGA rumpUpRelatedToManToRemove = this.du.createRamp("17/01/2018 10:53:00", true);
        RampCMGA rumpDownRelatedToManToRemove = this.du.createRamp("17/01/2018 11:19:00", false);
        allRumps.put(rumpUpRelatedToManToRemove.getStartTime().getTime(), rumpUpRelatedToManToRemove);
        allRumps.put(rumpDownRelatedToManToRemove.getStartTime().getTime(), rumpDownRelatedToManToRemove);

        System.out.println("maneuvers function contains : " + allManForSatellite.size() + " elements");
        System.out.println("rumps function contains : " + allRumps.size() + " elements");

        System.out.println("scenario 2 : the man that must be removed was involved in a multiple cmga plateau -> was the first");
        System.out.println("the rump up related to the cancelled man is shifted forward till the start of the next cmg man");
        resourceFunctions.setAllManeuversSat1(allManForSatellite);
        resourceFunctions.setAllRampsSat1(allRumps);
        this.cmgaMng.removeCMGA(manToRemoveForTest, resourceFunctions, this.allCmgaForSatellite, this.tAcc);

        Date expectedNewStartTimeForRump = new Date((long) (anotherManInTheTrainOfMan.getStartTime().getTime() - (secondsForRumpUp * 1000)));
        System.out.println("expected start time : " + expectedNewStartTimeForRump);

        assertEquals(1, resourceFunctions.getAllManeuversSat1().size());
        assertEquals(2, resourceFunctions.getAllRampsSat1().size());
        assertTrue(resourceFunctions.getAllRampsSat1().get(expectedNewStartTimeForRump.getTime()) != null);
        // the acquisition between these two maneuver will be on the rump down
        assertTrue(acqBetweenMan.getStartTime().after(expectedNewStartTimeForRump));
        System.out.println("after delete, maneuvers function contains : " + allManForSatellite.size() + " elements");
        System.out.println("after delete, rumps function contains : " + allRumps.size() + " elements");

    }

    @Test
    public void testRemoveAcqWithManThatIsThelastOfATrainOfCmg()
    {
        System.out.println("RUNNING TEST : testRemoveAcqWithManThatIsThelastOfATrainOfCmg");
        ResourceFunctions resourceFunctions = new ResourceFunctions();
        String satelliteForTest = "SAT_1";
        // creating the cmga units for the satellite
        // where the parameters are : String cmgaId, double wAcc, double tAcc,
        // double wPlat, double wRest, double maxPowerForOrbit,boolean operative
        CMGA cmga1 = new CMGA("cmga1", 25, 180, 25, 15, true, satelliteForTest);
        CMGA cmga2 = new CMGA("cmga2", 25, 180, 25, 15, false, satelliteForTest);
        CMGA cmga3 = new CMGA("cmga3", 25, 180, 25, 15, true, satelliteForTest);
        this.allCmgaForSatellite.add(cmga1);
        this.allCmgaForSatellite.add(cmga2);
        this.allCmgaForSatellite.add(cmga3);

        TreeMap<Long, Maneuver> allManForSatellite = new TreeMap<>();
        TreeMap<Long, RampCMGA> allRumps = new TreeMap<>();

        Maneuver previousMan = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:56:00", "17/01/2018 11:00:00", satelliteForTest, Actuator.CMGA);
        allManForSatellite.put(previousMan.getStartTime().getTime(), previousMan);

        Acquisition acqBetweenMan = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "right", satelliteForTest);
        Maneuver manToRemoveForTest = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 11:12:00", "17/01/2018 11:19:00", satelliteForTest, Actuator.CMGA);
        allManForSatellite.put(manToRemoveForTest.getStartTime().getTime(), manToRemoveForTest);

        // creating the rumps up and down related to the maneuver under test
        RampCMGA rumpUpRelatedToManToRemove = this.du.createRamp("17/01/2018 10:53:00", true);
        RampCMGA rumpDownRelatedToManToRemove = this.du.createRamp("17/01/2018 11:19:00", false);
        allRumps.put(rumpUpRelatedToManToRemove.getStartTime().getTime(), rumpUpRelatedToManToRemove);
        allRumps.put(rumpDownRelatedToManToRemove.getStartTime().getTime(), rumpDownRelatedToManToRemove);

        System.out.println("maneuvers function contains : " + allManForSatellite.size() + " elements");
        System.out.println("rumps function contains : " + allRumps.size() + " elements");

        System.out.println("scenario 3 : the man that must be removed was involved in a multiple cmga plateau -> was the last");
        System.out.println("the rump down related to the cancelled man is shifted forward till the start of the next cmg man");
        resourceFunctions.setAllManeuversSat1(allManForSatellite);
        resourceFunctions.setAllRampsSat1(allRumps);
        this.cmgaMng.removeCMGA(manToRemoveForTest, resourceFunctions, this.allCmgaForSatellite, this.tAcc);

        Date expectedNewStartTimeForRump = new Date((previousMan.getEndTime().getTime()));
        System.out.println("expected start time : " + expectedNewStartTimeForRump);

        assertEquals(1, resourceFunctions.getAllManeuversSat1().size());
        assertEquals(2, resourceFunctions.getAllRampsSat1().size());
        assertTrue(resourceFunctions.getAllRampsSat1().get(expectedNewStartTimeForRump.getTime()) != null);
        // the acquisition between these two maneuver will be on the rump down
        assertTrue(acqBetweenMan.getStartTime().after(expectedNewStartTimeForRump));
        System.out.println("after delete, maneuvers function contains : " + allManForSatellite.size() + " elements");
        System.out.println("after delete, rumps function contains : " + allRumps.size() + " elements");

    }

    @Test
    public void testRemoveAcqWithManThatIsInTheMiddleOfATrainOfCmg()
    {
        System.out.println("RUNNING TEST : testRemoveAcqWithManThatIsInTheMiddleOfATrainOfCmg");
        ResourceFunctions resourceFunctions = new ResourceFunctions();
        String satelliteForTest = "SAT_1";
        // creating the cmga units for the satellite
        // where the parameters are : String cmgaId, double wAcc, double tAcc,
        // double wPlat, double wRest, double maxPowerForOrbit,boolean operative
        CMGA cmga1 = new CMGA("cmga1", 25, 180, 25, 15, true, satelliteForTest);
        CMGA cmga2 = new CMGA("cmga2", 25, 180, 25, 15, false, satelliteForTest);
        CMGA cmga3 = new CMGA("cmga3", 25, 180, 25, 15, true, satelliteForTest);
        this.allCmgaForSatellite.add(cmga1);
        this.allCmgaForSatellite.add(cmga2);
        this.allCmgaForSatellite.add(cmga3);

        Maneuver previousMan = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:56:00", "17/01/2018 11:00:00", satelliteForTest, Actuator.CMGA);
        this.allManForSatellite.put(previousMan.getStartTime().getTime(), previousMan);

        Acquisition acqBetweenMan = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "right", satelliteForTest);
        Maneuver manToRemoveForTest = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 11:12:00", "17/01/2018 11:19:00", satelliteForTest, Actuator.CMGA);
        this.allManForSatellite.put(manToRemoveForTest.getStartTime().getTime(), manToRemoveForTest);

        // creating the rumps up and down related to the maneuver under test
        RampCMGA rumpUpRelatedToManToRemove = this.du.createRamp("17/01/2018 10:53:00", true);
        RampCMGA rumpDownRelatedToManToRemove = this.du.createRamp("17/01/2018 11:19:00", false);
        this.allRumps.put(rumpUpRelatedToManToRemove.getStartTime().getTime(), rumpUpRelatedToManToRemove);
        this.allRumps.put(rumpDownRelatedToManToRemove.getStartTime().getTime(), rumpDownRelatedToManToRemove);

        System.out.println("maneuvers function contains : " + this.allManForSatellite.size() + " elements");
        System.out.println("rumps function contains : " + this.allRumps.size() + " elements");

        System.out.println("scenario 3 : the man that must be removed was involved in a multiple cmga plateau -> was the last");
        System.out.println("the rump down related to the cancelled man is shifted forward till the start of the next cmg man");
        resourceFunctions.setAllManeuversSat1(this.allManForSatellite);
        resourceFunctions.setAllRampsSat1(this.allRumps);
        this.cmgaMng.removeCMGA(manToRemoveForTest, resourceFunctions, this.allCmgaForSatellite, this.tAcc);

        Date expectedNewStartTimeForRump = new Date((previousMan.getEndTime().getTime()));
        System.out.println("expected start time : " + expectedNewStartTimeForRump);

        assertEquals(1, resourceFunctions.getAllManeuversSat1().size());
        assertEquals(2, resourceFunctions.getAllRampsSat1().size());
        assertTrue(resourceFunctions.getAllRampsSat1().get(expectedNewStartTimeForRump.getTime()) != null);
        // the acquisition between these two maneuver will be on the rump up
        assertTrue(acqBetweenMan.getStartTime().after(expectedNewStartTimeForRump));
        System.out.println("after delete, maneuvers function contains : " + this.allManForSatellite.size() + " elements");
        System.out.println("after delete, rumps function contains : " + this.allRumps.size() + " elements");
    }

    @Test
    public void testGetMaxTimeTacc() throws Exception
    {
        List<CMGA> allCmgaForSatellite = new ArrayList<>();

        double tAccCmga1 = 130;
        double tAccCmga2 = 200;
        double tAccCmga3 = 20;
        CMGA cmga1 = new CMGA("cmga1", 25, tAccCmga1, 25, 15, true, "SAT_1");
        CMGA cmga2 = new CMGA("cmga2", 25, tAccCmga2, 25, 15, false, "SAT_1");
        CMGA cmga3 = new CMGA("cmga3", 25, tAccCmga3, 25, 15, true, "SAT_1");

        allCmgaForSatellite.add(cmga1);
        allCmgaForSatellite.add(cmga2);
        allCmgaForSatellite.add(cmga3);

        double maxTacc = this.cmgaMng.getMaxTimeTacc(allCmgaForSatellite);
        assertEquals(tAccCmga1, maxTacc, 0);
    }

    @Test
    public void testTryToSplitInTwoDifferentCmg_too_close_dont_divide() throws Exception
    {
        Maneuver previous = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(previous.getStartTime().getTime(), previous);
        Maneuver next = this.du.createManeuver("next", "acq_1", "acq_2", "17/01/2018 11:39:00", "17/01/2018 11:43:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(next.getStartTime().getTime(), next);

        RampCMGA rampUpForMergedPlateau = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rampDownForMergedPlateau = this.du.createRamp("17/01/2018 11:43:00", false);

        this.allRumps.put(rampUpForMergedPlateau.getStartTime().getTime(), rampUpForMergedPlateau);
        this.allRumps.put(rampDownForMergedPlateau.getStartTime().getTime(), rampDownForMergedPlateau);

        assertEquals(2, this.allRumps.size());

        this.cmgaMng.tryToSplitInTwoDifferentCmg(previous, next, this.tAcc, this.allRumps);

        assertEquals(2, this.allRumps.size());
        assertTrue(this.allRumps.get(rampUpForMergedPlateau.getStartTime().getTime()) != null);
        assertTrue(this.allRumps.get(rampDownForMergedPlateau.getStartTime().getTime()) != null);
    }

    @Test
    public void testTryToSplitInTwoDifferentCmg_ok_divide() throws Exception
    {
        Maneuver previous = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:28:00", "17/01/2018 11:32:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(previous.getStartTime().getTime(), previous);
        Maneuver next = this.du.createManeuver("next", "acq_1", "acq_2", "17/01/2018 11:39:00", "17/01/2018 11:43:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(next.getStartTime().getTime(), next);

        RampCMGA rampUpForMergedPlateau = this.du.createRamp("17/01/2018 11:25:00", true);
        RampCMGA rampDownForMergedPlateau = this.du.createRamp("17/01/2018 11:43:00", false);

        this.allRumps.put(rampUpForMergedPlateau.getStartTime().getTime(), rampUpForMergedPlateau);
        this.allRumps.put(rampDownForMergedPlateau.getStartTime().getTime(), rampDownForMergedPlateau);

        assertEquals(2, this.allRumps.size());

        this.cmgaMng.tryToSplitInTwoDifferentCmg(previous, next, this.tAcc, this.allRumps);

        RampCMGA expectedRampDownForPrev = this.du.createRamp("17/01/2018 11:32:00", false);
        RampCMGA expectedRampUpForNext = this.du.createRamp("17/01/2018 11:36:00", true);

        assertEquals(4, this.allRumps.size());
        assertTrue(this.allRumps.get(expectedRampDownForPrev.getStartTime().getTime()) != null);
        assertTrue(this.allRumps.get(expectedRampUpForNext.getStartTime().getTime()) != null);

        for (Map.Entry<Long, RampCMGA> rampElements : this.allRumps.entrySet())
        {
            System.out.println("\n " + rampElements.getValue());
        }
    }

    @Test
    public void testCheckCMGFormula_reject_for_both() throws Exception
    {
        List<CMGA> allCmgaForSatellite = new ArrayList<>();

        double tAccCmga1 = 130;
        double tAccCmga2 = 200;
        double tAccCmga3 = 20;
        CMGA cmga1 = new CMGA("cmga1", 12, tAccCmga1, 12, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG1 = new HashMap<>();
        allPowersForOrbitCMG1.put(1.0, 14.0);
        cmga1.setAllPowersForOrbit(allPowersForOrbitCMG1);

        CMGA cmga2 = new CMGA("cmga2", 20, tAccCmga2, 18, 15, false, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG2 = new HashMap<>();
        allPowersForOrbitCMG2.put(1.0, 19.2);
        cmga2.setAllPowersForOrbit(allPowersForOrbitCMG2);

        CMGA cmga3 = new CMGA("cmga3", 22, tAccCmga3, 20, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG3 = new HashMap<>();
        allPowersForOrbitCMG3.put(1.0, 11.2);
        cmga3.setAllPowersForOrbit(allPowersForOrbitCMG3);

        allCmgaForSatellite.add(cmga1);
        allCmgaForSatellite.add(cmga2);
        allCmgaForSatellite.add(cmga3);

        CmgaResources cmgRes = new CmgaResources();
        cmgRes.settPlat(90);
        cmgRes.setTRamp(450);

        /*
         * operative are cmga1 and cga3
         *
         * computation for cmg 1 = 15.78 with powerLimit = 15.2 -> not ok
         * computation for cmg 3 = 15.76 with powerLimit = 11.2 -> not ok
         */
        double orbitTocheck = 1.0;
        long periodToCheck = (long) (orbitTocheck * this.droolsParams.getMinutesForOrbit() * 60000);
        List<CMGA> invalidCmga = this.cmgaMng.checkCMGFormula(orbitTocheck, periodToCheck, allCmgaForSatellite, this.tAcc, cmgRes, this.droolsParams.getSatWithId("1").getSatelliteProperties());
        assertFalse(invalidCmga.isEmpty());
        assertEquals(cmga1, invalidCmga.get(0));
        assertEquals(cmga3, invalidCmga.get(1));
    }

    @Test
    public void testCheckCMGFormula_reject_for_only_one() throws Exception
    {
        List<CMGA> allCmgaForSatellite = new ArrayList<>();

        double tAccCmga1 = 130;
        double tAccCmga2 = 200;
        double tAccCmga3 = 20;

        CMGA cmga1 = new CMGA("cmga1", 12, tAccCmga1, 12, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG1 = new HashMap<>();
        allPowersForOrbitCMG1.put(1.0, 16.2);
        cmga1.setAllPowersForOrbit(allPowersForOrbitCMG1);

        CMGA cmga2 = new CMGA("cmga2", 20, tAccCmga2, 18, 15, false, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG2 = new HashMap<>();
        allPowersForOrbitCMG2.put(1.0, 19.2);
        cmga2.setAllPowersForOrbit(allPowersForOrbitCMG2);

        CMGA cmga3 = new CMGA("cmga3", 22, tAccCmga3, 20, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG3 = new HashMap<>();
        allPowersForOrbitCMG3.put(1.0, 11.2);
        cmga3.setAllPowersForOrbit(allPowersForOrbitCMG3);

        allCmgaForSatellite.add(cmga1);
        allCmgaForSatellite.add(cmga2);
        allCmgaForSatellite.add(cmga3);

        CmgaResources cmgRes = new CmgaResources();
        cmgRes.settPlat(60);
        cmgRes.setTRamp(400);

        /*
         * operative are cmga1 and cga3
         *
         * computation for cmg 1 = 15.74 with powerLimit = 16.2 -> ok
         * computation for cmg 3 = 15.73 with powerLimit = 11.2 -> not ok
         */
        double orbitTocheck = 1.0;
        long periodToCheck = (long) (orbitTocheck * this.droolsParams.getMinutesForOrbit() * 60000);
        List<CMGA> invalidCmga = this.cmgaMng.checkCMGFormula(orbitTocheck, periodToCheck, allCmgaForSatellite, this.tAcc, cmgRes, this.droolsParams.getSatWithId("1").getSatelliteProperties());
        assertFalse(invalidCmga.isEmpty());
        assertEquals(cmga3, invalidCmga.get(0));
    }

    @Test
    public void testCheckCMGFormula_both_operative_unit_are_ok() throws Exception
    {
        List<CMGA> allCmgaForSatellite = new ArrayList<>();

        double tAccCmga1 = 130;
        double tAccCmga2 = 200;
        double tAccCmga3 = 20;
        CMGA cmga1 = new CMGA("cmga1", 25, tAccCmga1, 12, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG1 = new HashMap<>();
        allPowersForOrbitCMG1.put(1.0, 16.2);
        cmga1.setAllPowersForOrbit(allPowersForOrbitCMG1);

        CMGA cmga2 = new CMGA("cmga2", 20, tAccCmga2, 18, 15, false, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG2 = new HashMap<>();
        allPowersForOrbitCMG2.put(1.0, 19.2);
        cmga2.setAllPowersForOrbit(allPowersForOrbitCMG2);

        CMGA cmga3 = new CMGA("cmga3", 22, tAccCmga3, 20, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG3 = new HashMap<>();
        allPowersForOrbitCMG3.put(1.0, 15.75);
        cmga3.setAllPowersForOrbit(allPowersForOrbitCMG3);

        allCmgaForSatellite.add(cmga1);
        allCmgaForSatellite.add(cmga2);
        allCmgaForSatellite.add(cmga3);

        CmgaResources cmgRes = new CmgaResources();
        cmgRes.settPlat(20);
        cmgRes.setTRamp(400);

        /*
         * operative are cmga1 and cga3
         *
         * computation for cmg 1 = 15.74 with powerLimit = 16.2 -> ok
         * computation for cmg 3 = 15.73 with powerLimit = 15.75 -> not ok
         */
        double orbitTocheck = 1.0;
        long periodToCheck = (long) (orbitTocheck * this.droolsParams.getMinutesForOrbit() * 60000);
        List<CMGA> invalidCmga = this.cmgaMng.checkCMGFormula(1.0, periodToCheck, allCmgaForSatellite, this.tAcc, cmgRes, this.droolsParams.getSatWithId("1").getSatelliteProperties());
        assertTrue(invalidCmga.isEmpty());
    }

    @Test
    public void testCheckCMGFormula_check_not_operative_cmg_is_unused() throws Exception
    {
        Map<String, Double> maxPowerCmg = new HashMap<>();

        maxPowerCmg.put("cmga1", 16.2);
        maxPowerCmg.put("cmga2", 0.0); // also if I set the max power to zero,
                                       // this cmg is not operative, the acq
                                       // mustn't be descarded for it
        maxPowerCmg.put("cmga3", 15.75);
        List<CMGA> allCmgaForSatellite = new ArrayList<>();

        double tAccCmga1 = 130;
        double tAccCmga2 = 200;
        double tAccCmga3 = 20;
        CMGA cmga1 = new CMGA("cmga1", 25, tAccCmga1, 12, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG1 = new HashMap<>();
        allPowersForOrbitCMG1.put(1.0, 16.2);
        cmga1.setAllPowersForOrbit(allPowersForOrbitCMG1);

        CMGA cmga2 = new CMGA("cmga2", 20, tAccCmga2, 18, 15, false, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG2 = new HashMap<>();
        allPowersForOrbitCMG2.put(1.0, 0.0);
        cmga2.setAllPowersForOrbit(allPowersForOrbitCMG2);

        CMGA cmga3 = new CMGA("cmga3", 22, tAccCmga3, 20, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG3 = new HashMap<>();
        allPowersForOrbitCMG3.put(1.0, 15.75);
        cmga3.setAllPowersForOrbit(allPowersForOrbitCMG3);

        allCmgaForSatellite.add(cmga1);
        allCmgaForSatellite.add(cmga2);
        allCmgaForSatellite.add(cmga3);

        CmgaResources cmgRes = new CmgaResources();
        cmgRes.settPlat(20);
        cmgRes.setTRamp(400);

        /*
         * operative are cmga1 and cga3
         *
         * computation for cmg 1 = 15.74 with powerLimit = 16.2 -> ok
         * computation for cmg 3 = 15.73 with powerLimit = 15.75 -> not ok
         */

        double orbitTocheck = 1.0;
        long periodToCheck = (long) (orbitTocheck * this.droolsParams.getMinutesForOrbit() * 60000);
        List<CMGA> invalidCmga = this.cmgaMng.checkCMGFormula(orbitTocheck, periodToCheck, allCmgaForSatellite, this.tAcc, cmgRes, this.droolsParams.getSatWithId("1").getSatelliteProperties());
        assertTrue(invalidCmga.isEmpty());
    }

    @Test
    public void testComputeResourcesInInterval() throws Exception
    {
        double tAcc = 180;

        Maneuver previous = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(previous.getStartTime().getTime(), previous);

        RampCMGA rampUpForPrevious = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rampDownForPrevious = this.du.createRamp("17/01/2018 11:34:00", false);

        Maneuver rwMan = this.du.createManeuver("current", "acq_1", "acq_2", "17/01/2018 11:05:00", "17/01/2018 11:11:00", "SAT_1", Actuator.ReactionWheels);
        this.allManForSatellite.put(rwMan.getStartTime().getTime(), rwMan);

        Maneuver current = this.du.createManeuver("current", "acq_1", "acq_2", "17/01/2018 11:58:00", "17/01/2018 12:02:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(current.getStartTime().getTime(), current);

        RampCMGA rampUpForCurrent = this.du.createRamp("17/01/2018 11:55:00", true);
        RampCMGA rampDownForCurrent = this.du.createRamp("17/01/2018 12:02:00", false);

        this.allRumps.put(rampUpForPrevious.getStartTime().getTime(), rampUpForPrevious);
        this.allRumps.put(rampDownForPrevious.getStartTime().getTime(), rampDownForPrevious);
        this.allRumps.put(rampUpForCurrent.getStartTime().getTime(), rampUpForCurrent);
        this.allRumps.put(rampDownForCurrent.getStartTime().getTime(), rampDownForCurrent);

        Date startCheck = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 13:00:00");

        CmgaResources cmgaRes = this.cmgaMng.computeResourcesInInterval(tAcc, this.allManForSatellite, this.allRumps, startCheck, endCheck);
        System.out.println("cmga tPlat : " + (cmgaRes.gettPlat() / 1000));
        System.out.println("cmga tRamp : " + (cmgaRes.getTRamp() / 1000));
    }

    @Test
    public void testComputeResourcesRampOutSideRangeStart() throws Exception
    {
        double tAcc = 180;

        Maneuver previous = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        previous.setRightToLeftFlag(false);

        this.allManForSatellite.put(previous.getStartTime().getTime(), previous);

        Maneuver rwMan = this.du.createManeuver("current", "acq_1", "acq_2", "17/01/2018 11:01:00", "17/01/2018 11:05:00", "SAT_1", Actuator.CMGA);
        rwMan.setRightToLeftFlag(true);
        this.allManForSatellite.put(rwMan.getStartTime().getTime(), rwMan);

        Maneuver current = this.du.createManeuver("current", "acq_1", "acq_2", "17/01/2018 11:58:00", "17/01/2018 12:01:00", "SAT_1", Actuator.CMGA);
        current.setRightToLeftFlag(false);
        this.allManForSatellite.put(current.getStartTime().getTime(), current);

        RampCMGA rampUpForCurrent = this.du.createRamp("17/01/2018 10:58:00", true);
        RampCMGA rampDownForCurrent = this.du.createRamp("17/01/2018 12:01:00", false);

        this.allRumps.put(rampUpForCurrent.getStartTime().getTime(), rampUpForCurrent);
        this.allRumps.put(rampDownForCurrent.getStartTime().getTime(), rampDownForCurrent);

        Date startCheck = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 13:00:00");

        CmgaResources cmgaRes = this.cmgaMng.computeResourcesInInterval(tAcc, this.allManForSatellite, this.allRumps, startCheck, endCheck);
        System.out.println("cmga tPlat : " + (cmgaRes.gettPlat() / 1000));
        System.out.println("cmga tRamp : " + (cmgaRes.getTRamp() / 1000));
        System.out.println(cmgaRes);
    }

    @Test
    public void testComputeResourcesRampOutSideRangeEnd() throws Exception
    {
        double tAcc = 180;

        Maneuver previous = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(previous.getStartTime().getTime(), previous);

        RampCMGA rampUpForPrevious = this.du.createRamp("17/01/2018 11:27:00", true);

        Maneuver rwMan = this.du.createManeuver("current", "acq_1", "acq_2", "17/01/2018 11:01:00", "17/01/2018 11:05:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(rwMan.getStartTime().getTime(), rwMan);

        Maneuver current = this.du.createManeuver("current", "acq_1", "acq_2", "17/01/2018 11:58:00", "17/01/2018 12:02:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(current.getStartTime().getTime(), current);

        RampCMGA rampDownForCurrent = this.du.createRamp("17/01/2018 13:02:00", false);

        this.allRumps.put(rampUpForPrevious.getStartTime().getTime(), rampUpForPrevious);
        this.allRumps.put(rampDownForCurrent.getStartTime().getTime(), rampDownForCurrent);

        Date startCheck = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 13:00:00");

        CmgaResources cmgaRes = this.cmgaMng.computeResourcesInInterval(tAcc, this.allManForSatellite, this.allRumps, startCheck, endCheck);
        System.out.println("cmga tPlat : " + (cmgaRes.gettPlat() / 1000));
        System.out.println("cmga tRamp : " + (cmgaRes.getTRamp() / 1000));
    }

    @Test
    public void testComputeResourcesInInterval_only_one_cmg_totally_included() throws Exception
    {
        double tAcc = 180;

        Maneuver previous = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        this.allManForSatellite.put(previous.getStartTime().getTime(), previous);

        RampCMGA rampUpForPrevious = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rampDownForPrevious = this.du.createRamp("17/01/2018 11:34:00", false);

        this.allRumps.put(rampUpForPrevious.getStartTime().getTime(), rampUpForPrevious);
        this.allRumps.put(rampDownForPrevious.getStartTime().getTime(), rampDownForPrevious);

        Date startCheck = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 13:00:00");

        CmgaResources cmgaRes = this.cmgaMng.computeResourcesInInterval(tAcc, this.allManForSatellite, this.allRumps, startCheck, endCheck);
        System.out.println("cmga tPlat : " + (cmgaRes.gettPlat() / 1000));
        System.out.println("cmga tRamp : " + (cmgaRes.getTRamp() / 1000));
        System.out.println("cmga tRest : " + (cmgaRes.gettRest() / 1000));
    }

    @Test
    public void testComputeResourcesInInterval_no_cmg_in_interval() throws Exception
    {
        double tAcc = 180;

        Date startCheck = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 13:00:00");

        CmgaResources cmgaRes = this.cmgaMng.computeResourcesInInterval(tAcc, this.allManForSatellite, this.allRumps, startCheck, endCheck);
        System.out.println("cmga tPlat : " + (cmgaRes.gettPlat() / 1000));
        System.out.println("cmga tRamp : " + (cmgaRes.getTRamp() / 1000));
        System.out.println("cmga tRest : " + (cmgaRes.gettRest() / 1000)); // all
                                                                           // in
                                                                           // tRest
        assertEquals(endCheck.getTime(), startCheck.getTime() + cmgaRes.gettRest(), 0);
    }

    @Test
    public void test_fail_cmg_because_one_orbit_exceeds_the_formula()
    {
        System.out.println(" Running test : test_fail_cmg_because_one_orbit_exceeds_the_formula");
        List<CMGA> allCmgaForSatellite = new ArrayList<>();

        double tAccCmga1 = 130;
        double tAccCmga2 = 200;
        double tAccCmga3 = 20;
        CMGA cmga1 = new CMGA("cmga1", 25, tAccCmga1, 12, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG1 = new HashMap<>();
        allPowersForOrbitCMG1.put(1.0, 20.0);
        allPowersForOrbitCMG1.put(3.0, 25.0);
        cmga1.setAllPowersForOrbit(allPowersForOrbitCMG1);

        CMGA cmga2 = new CMGA("cmga2", 20, tAccCmga2, 18, 15, false, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG2 = new HashMap<>();
        allPowersForOrbitCMG2.put(1.0, 26.0);
        allPowersForOrbitCMG2.put(3.0, 32.0);
        cmga2.setAllPowersForOrbit(allPowersForOrbitCMG2);

        CMGA cmga3 = new CMGA("cmga3", 22, tAccCmga3, 20, 15, true, "SAT_1");
        Map<Double, Double> allPowersForOrbitCMG3 = new HashMap<>();
        allPowersForOrbitCMG3.put(1.0, 11.0);
        allPowersForOrbitCMG3.put(3.0, 32.0);
        cmga3.setAllPowersForOrbit(allPowersForOrbitCMG3);

        allCmgaForSatellite.add(cmga1);
        allCmgaForSatellite.add(cmga2);
        allCmgaForSatellite.add(cmga3);

        CmgaResources cmgRes = new CmgaResources();
        cmgRes.settPlat(60);
        cmgRes.setTRamp(400);

        /*
         * operative are cmga1 and cga3
         *
         * computation for cmg 1 = 15.74 with powerLimit = 16.2 -> ok
         * computation for cmg 3 = 15.73 with powerLimit = 11.2 -> not ok
         */
        double orbitToCheck = 1.0;
        long interval = (long) (97 * orbitToCheck * 60000);
        List<CMGA> invalidCmga = this.cmgaMng.checkCMGFormula(1.0, interval, allCmgaForSatellite, this.tAcc, cmgRes, this.droolsParams.getSatWithId("1").getSatelliteProperties());
        assertFalse(invalidCmga.isEmpty());
        assertEquals(cmga3, invalidCmga.get(0));
    }

    @Test
    public void testRemoveOrReduceRump_singlePlateau() throws Exception
    {
        double timeForRump = 180;
        ManeuverResources manRes = new ManeuverResources();
        TreeMap<Long, RampCMGA> localAllRumps = new TreeMap<>();
        TreeMap<Long, Maneuver> localAllMan = new TreeMap<>();
        System.out.println();
        Maneuver manToRemove = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:15:00", "17/01/2018 11:19:00", "sat_1", Actuator.CMGA);
        RampCMGA rampUpMan = this.du.createRamp("17/01/2018 11:12:00", true);
        RampCMGA rampDownMan = this.du.createRamp("17/01/2018 11:19:00", false);

        localAllMan.put(manToRemove.getStartTime().getTime(), manToRemove);
        localAllRumps.put(rampUpMan.getStartTime().getTime(), rampUpMan);
        localAllRumps.put(rampDownMan.getStartTime().getTime(), rampDownMan);
        assertEquals(2, localAllRumps.size());

        manRes = this.cmgaMng.removeOrReduceRump(this.droolsParams, manToRemove, localAllMan, localAllRumps, manRes, timeForRump);
        assertEquals(2, manRes.getOldRumps().size());
        assertEquals(0, localAllRumps.size());
        System.out.println("man res : " + manRes);
    }

    @Test
    public void testRemoveOrReduceRump_FirstManInPlateau() throws Exception
    {
        double timeForRump = 180;
        ManeuverResources manRes = new ManeuverResources();
        TreeMap<Long, RampCMGA> localAllRumps = new TreeMap<>();
        TreeMap<Long, Maneuver> localAllMan = new TreeMap<>();

        Maneuver manToRemove = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:15:00", "17/01/2018 11:19:00", "sat_1", Actuator.CMGA);
        Maneuver secondManInPlateau = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:21:00", "17/01/2018 11:25:00", "sat_1", Actuator.CMGA);

        RampCMGA rampUpPlateau = this.du.createRamp("17/01/2018 11:12:00", true);
        RampCMGA rampDownMPlateau = this.du.createRamp("17/01/2018 11:25:00", false);

        localAllMan.put(manToRemove.getStartTime().getTime(), manToRemove);
        localAllMan.put(secondManInPlateau.getStartTime().getTime(), secondManInPlateau);

        localAllRumps.put(rampUpPlateau.getStartTime().getTime(), rampUpPlateau);
        localAllRumps.put(rampDownMPlateau.getStartTime().getTime(), rampDownMPlateau);

        manRes = this.cmgaMng.removeOrReduceRump(this.droolsParams, manToRemove, localAllMan, localAllRumps, manRes, timeForRump);

        System.out.println("man res : " + manRes);

    }

    @Test
    public void testRemoveOrReduceRump_LastManInPlateau() throws Exception
    {
        double timeForRump = 180;
        ManeuverResources manRes = new ManeuverResources();
        TreeMap<Long, RampCMGA> localAllRumps = new TreeMap<>();
        TreeMap<Long, Maneuver> localAllMan = new TreeMap<>();

        Maneuver firstManInPlateau = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:15:00", "17/01/2018 11:19:00", "sat_1", Actuator.CMGA);
        Maneuver manToRemove = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:21:00", "17/01/2018 11:25:00", "sat_1", Actuator.CMGA);

        RampCMGA rampUpPlateau = this.du.createRamp("17/01/2018 11:12:00", true);
        RampCMGA rampDownPlateau = this.du.createRamp("17/01/2018 11:25:00", false);

        localAllMan.put(firstManInPlateau.getStartTime().getTime(), firstManInPlateau);
        localAllMan.put(manToRemove.getStartTime().getTime(), manToRemove);

        localAllRumps.put(rampUpPlateau.getStartTime().getTime(), rampUpPlateau);
        localAllRumps.put(rampDownPlateau.getStartTime().getTime(), rampDownPlateau);

        manRes = this.cmgaMng.removeOrReduceRump(this.droolsParams, manToRemove, localAllMan, localAllRumps, manRes, timeForRump);

        assertEquals(1, manRes.getOldRumps().size());
        assertEquals(1, manRes.getNewRumps().size());
        assertEquals(2, localAllRumps.size());
        System.out.println("man res : " + manRes);

    }

    @Test
    public void testRemoveOrReduceRump_MiddleManInPlateau() throws Exception
    {
        double timeForRump = 180;
        ManeuverResources manRes = new ManeuverResources();
        TreeMap<Long, RampCMGA> localAllRumps = new TreeMap<>();
        TreeMap<Long, Maneuver> localAllMan = new TreeMap<>();

        Maneuver firstManInPlateau = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:09:00", "17/01/2018 11:12:00", "sat_1", Actuator.CMGA);
        Maneuver manToRemove = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:15:00", "17/01/2018 11:19:00", "sat_1", Actuator.CMGA);
        Maneuver manPRW = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:21:00", "17/01/2018 11:24:00", "sat_1", Actuator.ReactionWheels);

        Maneuver secondManInPlateau = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:28:00", "17/01/2018 11:29:00", "sat_1", Actuator.CMGA);

        RampCMGA rampUpPlateau = this.du.createRamp("17/01/2018 11:06:00", true);
        RampCMGA rampDownPlateau = this.du.createRamp("17/01/2018 11:29:20", false);

        localAllMan.put(firstManInPlateau.getStartTime().getTime(), firstManInPlateau);
        localAllMan.put(manToRemove.getStartTime().getTime(), manToRemove);
        localAllMan.put(secondManInPlateau.getStartTime().getTime(), secondManInPlateau);
        localAllMan.put(manPRW.getStartTime().getTime(), manPRW);

        localAllRumps.put(rampUpPlateau.getStartTime().getTime(), rampUpPlateau);
        localAllRumps.put(rampDownPlateau.getStartTime().getTime(), rampDownPlateau);

        manRes = this.cmgaMng.removeOrReduceRump(this.droolsParams, manToRemove, localAllMan, localAllRumps, manRes, timeForRump);

        assertEquals(0, manRes.getOldRumps().size());
        assertEquals(0, manRes.getNewRumps().size());
        assertEquals(2, localAllRumps.size());
        System.out.println("man res : " + manRes);

    }

    @Test
    public void findNextRampDown_found()
    {
        TreeMap<Long, RampCMGA> allRampsRelatedToSat = new TreeMap<>();
        RampCMGA rampUpTest = this.du.createRamp("17/01/2018 11:06:00", true);
        RampCMGA rampDownTest = this.du.createRamp("17/01/2018 11:25:00", false);

        allRampsRelatedToSat.put(rampUpTest.getStartTime().getTime(), rampUpTest);
        allRampsRelatedToSat.put(rampDownTest.getStartTime().getTime(), rampDownTest);

        Maneuver manTooClose = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:00:00", "17/01/2018 11:03:00", "sat_1", Actuator.CMGA);
        RampCMGA returnedRamp = this.cmgaMng.findNextOrPrevRamp(allRampsRelatedToSat, manTooClose, "next", "down");
        System.out.println("returned ramp : " + returnedRamp);

        assertEquals(rampDownTest, returnedRamp);
    }

    @Test
    public void findNextRampDown_not_found()
    {
        TreeMap<Long, RampCMGA> allRampsRelatedToSat = new TreeMap<>();
        RampCMGA rampUpTest = this.du.createRamp("17/01/2018 11:06:00", true);
        RampCMGA rampDownTest = this.du.createRamp("17/01/2018 11:25:00", false);

        allRampsRelatedToSat.put(rampUpTest.getStartTime().getTime(), rampUpTest);
        allRampsRelatedToSat.put(rampDownTest.getStartTime().getTime(), rampDownTest);

        Maneuver manTooClose = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 11:30:00", "17/01/2018 11:32:00", "sat_1", Actuator.CMGA);
        RampCMGA returnedRamp = this.cmgaMng.findNextOrPrevRamp(allRampsRelatedToSat, manTooClose, "next", "down");
        System.out.println("returned ramp : " + returnedRamp);

        assertEquals(null, returnedRamp);
    }

    @Test
    public void findPrevRampUp_found()
    {
        TreeMap<Long, RampCMGA> allRampsRelatedToSat = new TreeMap<>();
        RampCMGA rampUpTest = this.du.createRamp("17/01/2018 11:06:00", true);
        RampCMGA rampDownTest = this.du.createRamp("17/01/2018 11:25:00", false);

        allRampsRelatedToSat.put(rampUpTest.getStartTime().getTime(), rampUpTest);
        allRampsRelatedToSat.put(rampDownTest.getStartTime().getTime(), rampDownTest);

        Maneuver manTooClose = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 12:30:00", "17/01/2018 12:32:00", "sat_1", Actuator.CMGA);
        RampCMGA returnedRamp = this.cmgaMng.findNextOrPrevRamp(allRampsRelatedToSat, manTooClose, "previous", "up");
        System.out.println("returned ramp : " + returnedRamp);

        assertEquals(rampUpTest, returnedRamp);
    }

    @Test
    public void findPrevRampUp_not_found()
    {
        TreeMap<Long, RampCMGA> allRampsRelatedToSat = new TreeMap<>();
        RampCMGA rampUpTest = this.du.createRamp("17/01/2018 11:06:00", true);
        RampCMGA rampDownTest = this.du.createRamp("17/01/2018 11:25:00", false);

        allRampsRelatedToSat.put(rampUpTest.getStartTime().getTime(), rampUpTest);
        allRampsRelatedToSat.put(rampDownTest.getStartTime().getTime(), rampDownTest);

        Maneuver manTooClose = this.du.createManeuver("man01", "dto1", "dto2", "17/01/2018 10:30:00", "17/01/2018 10:32:00", "sat_1", Actuator.CMGA);
        RampCMGA returnedRamp = this.cmgaMng.findNextOrPrevRamp(allRampsRelatedToSat, manTooClose, "previous", "up");
        System.out.println("returned ramp : " + returnedRamp);

        assertEquals(null, returnedRamp);
    }

    @Test
    public void testFindNextOrPrevCmgaMan_prev_found() throws Exception
    {
        TreeMap<Long, Maneuver> allMansRelatedToSat = new TreeMap<>();
        Maneuver man1 = this.du.createManeuver("man1", null, null, "17/01/2018 11:06:00", "17/01/2018 11:10:00", "SAT_1", Actuator.CMGA);
        Maneuver man2 = this.du.createManeuver("man1", null, null, "17/01/2018 11:45:00", "17/01/2018 11:51:00", "SAT_1", Actuator.ReactionWheels);

        Maneuver manUnderTest = this.du.createManeuver("man1", null, null, "17/01/2018 11:57:00", "17/01/2018 12:01:00", "SAT_1", Actuator.CMGA);

        allMansRelatedToSat.put(man1.getStartTime().getTime(), man1);
        allMansRelatedToSat.put(man2.getStartTime().getTime(), man2);

        Maneuver returnedMan = this.cmgaMng.findNextOrPrevCmgaMan(allMansRelatedToSat, manUnderTest, "previous");
        System.out.println("returned ramp : " + returnedMan);

        assertEquals(man1, returnedMan);
    }

    @Test
    public void testFindNextOrPrevCmgaMan_prev_not_found() throws Exception
    {

        TreeMap<Long, Maneuver> allMansRelatedToSat = new TreeMap<>();
        Maneuver man1 = this.du.createManeuver("man1", null, null, "17/01/2018 11:06:00", "17/01/2018 11:10:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver man2 = this.du.createManeuver("man1", null, null, "17/01/2018 11:45:00", "17/01/2018 11:51:00", "SAT_1", Actuator.ReactionWheels);

        Maneuver manUnderTest = this.du.createManeuver("man1", null, null, "17/01/2018 11:57:00", "17/01/2018 12:01:00", "SAT_1", Actuator.CMGA);

        allMansRelatedToSat.put(man1.getStartTime().getTime(), man1);
        allMansRelatedToSat.put(man2.getStartTime().getTime(), man2);

        Maneuver returnedMan = this.cmgaMng.findNextOrPrevCmgaMan(allMansRelatedToSat, manUnderTest, "previous");
        System.out.println("returned ramp : " + returnedMan);

        assertEquals(null, returnedMan);
    }

    @Test
    public void testFindNextOrPrevCmgaMan_next_found() throws Exception
    {
        TreeMap<Long, Maneuver> allMansRelatedToSat = new TreeMap<>();
        Maneuver man1 = this.du.createManeuver("man1", null, null, "17/01/2018 11:06:00", "17/01/2018 11:10:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver man2 = this.du.createManeuver("man1", null, null, "17/01/2018 11:45:00", "17/01/2018 11:51:00", "SAT_1", Actuator.CMGA);

        Maneuver manUnderTest = this.du.createManeuver("man1", null, null, "17/01/2018 10:57:00", "17/01/2018 11:01:00", "SAT_1", Actuator.CMGA);

        allMansRelatedToSat.put(man1.getStartTime().getTime(), man1);
        allMansRelatedToSat.put(man2.getStartTime().getTime(), man2);

        Maneuver returnedMan = this.cmgaMng.findNextOrPrevCmgaMan(allMansRelatedToSat, manUnderTest, "next");
        System.out.println("returned ramp : " + returnedMan);

        assertEquals(man2, returnedMan);
    }

    @Test
    public void testFindNextOrPrevCmgaMan_next_not_found() throws Exception
    {
        TreeMap<Long, Maneuver> allMansRelatedToSat = new TreeMap<>();
        Maneuver man1 = this.du.createManeuver("man1", null, null, "17/01/2018 11:06:00", "17/01/2018 11:10:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver man2 = this.du.createManeuver("man1", null, null, "17/01/2018 11:45:00", "17/01/2018 11:51:00", "SAT_1", Actuator.ReactionWheels);

        Maneuver manUnderTest = this.du.createManeuver("man1", null, null, "17/01/2018 11:57:00", "17/01/2018 11:04:00", "SAT_1", Actuator.CMGA);

        allMansRelatedToSat.put(man1.getStartTime().getTime(), man1);
        allMansRelatedToSat.put(man2.getStartTime().getTime(), man2);

        Maneuver returnedMan = this.cmgaMng.findNextOrPrevCmgaMan(allMansRelatedToSat, manUnderTest, "next");
        System.out.println("returned ramp : " + returnedMan);

        assertEquals(null, returnedMan);
    }

    @Test
    public void testFindIfThereAreManeuverTooClose() throws Exception
    {
        String satelliteForTest = "SAT_1";
        long tAcc = 180;
        Maneuver existingMan1 = this.du.createManeuver("man1", null, "acq_1", "17/01/2018 10:56:00", "17/01/2018 11:00:00", satelliteForTest, Actuator.CMGA);
        Maneuver newMan = this.du.createManeuver("man2", null, "acq_1", "17/01/2018 10:50:00", "17/01/2018 10:54:00", satelliteForTest, Actuator.CMGA);

        RampCMGA rumpUpMan1 = this.du.createRamp("17/01/2018 10:53:00", true);
        RampCMGA rumpDownMan1 = this.du.createRamp("17/01/2018 11:00:00", false);

        this.allManForSatellite.put(existingMan1.getStartTime().getTime(), existingMan1);
        this.allRumps.put(rumpUpMan1.getStartTime().getTime(), rumpUpMan1);
        this.allRumps.put(rumpDownMan1.getStartTime().getTime(), rumpDownMan1);

        List<Maneuver> resultMan = new ArrayList<>(); // List<RampCMGA>
                                                      // rumpRelatedToNewMan,
        // TreeMap<Long, Maneuver>
        // allManRelatedToSat,
        resultMan = this.cmgaMng.findIfThereAreManeuverTooClose(newMan, this.allManForSatellite, this.allRumps, tAcc);
        System.out.println("man returned from the method : " + resultMan);
        assertEquals(existingMan1, resultMan.get(0));
        assertEquals(1, resultMan.size());
    }

    @Test
    public void testCreateRampUpOrDown_RampUp() throws Exception
    {
        Maneuver newManCmga = this.du.createManeuver("man2", null, "acq_1", "17/01/2018 10:50:00", "17/01/2018 10:54:00", "SAT_1", Actuator.CMGA);
        long timeForRamp = 180;
        boolean createRumpUp = true;

        SatelliteProperties satProp1 = new SatelliteProperties();
        satProp1.setWaitTimeBetweenRampAndCmg(10);
        this.droolsParams.getSatWithId("SAT_1").setSatelliteProperties(satProp1);
        this.cmgaMng.createRampUpOrDown(this.droolsParams, newManCmga, timeForRamp, createRumpUp);
    }

    @Test
    public void testCreateRampUpOrDown_RampDown() throws Exception
    {
        Maneuver newManCmga = this.du.createManeuver("man2", null, "acq_1", "17/01/2018 10:50:00", "17/01/2018 10:54:00", "SAT_1", Actuator.CMGA);
        long timeForRamp = 180;
        boolean createRumpUp = false;
        SatelliteProperties satProp1 = new SatelliteProperties();
        satProp1.setWaitTimeBetweenRampAndCmg(10);
        this.droolsParams.getSatWithId("SAT_1").setSatelliteProperties(satProp1);
        this.cmgaMng.createRampUpOrDown(this.droolsParams, newManCmga, timeForRamp, createRumpUp);
    }

    @Test
    public void testCheckCmgaFormula() throws Exception
    {
        Maneuver newManCmga = this.du.createManeuver("man2", null, "acq_1", "17/01/2018 10:50:00", "17/01/2018 10:54:00", "SAT_1", Actuator.CMGA);
        TreeMap<Long, Maneuver> allManRelativeToSat = new TreeMap<>();
        TreeMap<Long, RampCMGA> allRampRelativeToSat = new TreeMap<>();

        ResourceFunctions resourceFunctions = new ResourceFunctions();
        resourceFunctions.setAllManeuversSat1(allManRelativeToSat);
        resourceFunctions.setAllRampsSat1(allRampRelativeToSat);

        double wAccForTestCmg1 = 25; // expressed in watt
        double tAccForTestCmg1 = 180; // expressed in seconds
        double wPlatForTestCmg1 = 25; // expressed in watt
        double wRestForTestCmg1 = 15; // expressed in watt

        double wAccForTestCmg2 = 25; // expressed in watt
        double tAccForTestCmg2 = 180; // expressed in seconds
        double wPlatForTestCmg2 = 25; // expressed in watt
        double wRestForTestCmg2 = 15; // expressed in watt

        double wAccForTestCmg3 = 5; // expressed in watt
        double tAccForTestCmg3 = 50; // expressed in seconds
        double wPlatForTestCmg3 = 5; // expressed in watt
        double wRestForTestCmg3 = 3; // expressed in watt

        CMGA cmga1 = new CMGA("cmga1", wAccForTestCmg1, tAccForTestCmg1, wPlatForTestCmg1, wRestForTestCmg1, true, "SAT_1");
        Map<Double, Double> allPowersForOrbit = new HashMap<>();
        allPowersForOrbit.put(1.0, 20.0);
        cmga1.setAllPowersForOrbit(allPowersForOrbit);
        CMGA cmga2 = new CMGA("cmga2", wAccForTestCmg2, tAccForTestCmg2, wPlatForTestCmg2, wRestForTestCmg2, true, "SAT_1");
        cmga2.setAllPowersForOrbit(allPowersForOrbit);

        CMGA cmga3 = new CMGA("cmga3", wAccForTestCmg3, tAccForTestCmg3, wPlatForTestCmg3, wRestForTestCmg3, false, "SAT_1");
        cmga3.setAllPowersForOrbit(allPowersForOrbit);

        // create all the CMGA related to sat
        List<CMGA> allCMGA = new ArrayList<>(Arrays.asList(cmga1, cmga2, cmga3));
        this.droolsParams.setAllCMGA(allCMGA);

        boolean violated = this.cmgaMng.checkCmgaFormula(newManCmga, this.droolsParams, resourceFunctions);
        assertFalse(violated);
    }

    // TODO: ripristinare test cmga
    /*
     * @Test public void testCheckCmgaFormula_Overhead() throws Exception {
     * Maneuver newManCmga1 = this.du.createManeuver("man2", null, "acq_1",
     * "17/01/2018 10:50:00", "17/01/2018 10:54:00", "SAT_1", Actuator.CMGA);
     * newManCmga1.setRightToLeftFlag(false);
     *
     * Maneuver newManCmga2 = this.du.createManeuver("man2", null, "acq_1",
     * "17/01/2018 11:15:00", "17/01/2018 11:19:00", "SAT_1", Actuator.CMGA);
     * newManCmga2.setRightToLeftFlag(true);
     *
     * Maneuver newManCmga3 = this.du.createManeuver("man2", null, "acq_1",
     * "17/01/2018 11:40:00", "17/01/2018 11:44:00", "SAT_1", Actuator.CMGA);
     * newManCmga3.setRightToLeftFlag(false);
     *
     * TreeMap<Long, Maneuver> allManRelativeToSat = new TreeMap<Long,
     * Maneuver>();
     * allManRelativeToSat.put(newManCmga2.getStartTime().getTime(),
     * newManCmga2);
     * allManRelativeToSat.put(newManCmga3.getStartTime().getTime(),
     * newManCmga3);
     *
     * RampCMGA rumpUpMan2 = this.du.createRamp("17/01/2018 11:12:00", true);
     * RampCMGA rumpDownMan3 = this.du.createRamp("17/01/2018 11:44:00", false);
     *
     * TreeMap<Long, RampCMGA> allRampRelativeToSat = new TreeMap<Long,
     * RampCMGA>();
     * allRampRelativeToSat.put(rumpUpMan2.getStartTime().getTime(),
     * rumpUpMan2);
     * allRampRelativeToSat.put(rumpDownMan3.getStartTime().getTime(),
     * rumpDownMan3);
     *
     *
     * ResourceFunctions resourceFunctions = new ResourceFunctions();
     * resourceFunctions.setAllManeuversSat1(allManRelativeToSat);
     * resourceFunctions.setAllRampsSat1(allRampRelativeToSat);
     *
     * double wAccForTestCmg1 = 25; // expressed in watt double tAccForTestCmg1
     * = 180; // expressed in seconds double wPlatForTestCmg1 = 25; // expressed
     * in watt double wRestForTestCmg1 = 15; // expressed in watt
     *
     * double wAccForTestCmg2 = 25; // expressed in watt double tAccForTestCmg2
     * = 180; // expressed in seconds double wPlatForTestCmg2 = 25; // expressed
     * in watt double wRestForTestCmg2 = 15; // expressed in watt
     *
     * double wAccForTestCmg3 = 5; // expressed in watt double tAccForTestCmg3 =
     * 50; // expressed in seconds double wPlatForTestCmg3 = 5; // expressed in
     * watt double wRestForTestCmg3 = 3; // expressed in watt
     *
     * CMGA cmga1 = new CMGA("cmga1", wAccForTestCmg1, tAccForTestCmg1,
     * wPlatForTestCmg1, wRestForTestCmg1, true, "SAT_1"); Map<Double, Double>
     * allPowersForOrbit = new HashMap<Double, Double>();
     * allPowersForOrbit.put(1.0, 20.0);
     * cmga1.setAllPowersForOrbit(allPowersForOrbit); CMGA cmga2 = new
     * CMGA("cmga2", wAccForTestCmg2, tAccForTestCmg2, wPlatForTestCmg2,
     * wRestForTestCmg2, true, "SAT_1");
     * cmga2.setAllPowersForOrbit(allPowersForOrbit);
     *
     * CMGA cmga3 = new CMGA("cmga3", wAccForTestCmg3, tAccForTestCmg3,
     * wPlatForTestCmg3, wRestForTestCmg3, false, "SAT_1");
     * cmga3.setAllPowersForOrbit(allPowersForOrbit);
     *
     * // create all the CMGA related to sat List<CMGA> allCMGA = new
     * ArrayList<CMGA>(Arrays.asList(cmga1, cmga2, cmga3));
     * this.droolsParams.setAllCMGA(allCMGA);
     *
     * boolean violated = this.cmgaMng.checkCmgaFormula(newManCmga1,
     * this.droolsParams, resourceFunctions); assertTrue(violated); }
     */
    @Test
    public void testTryWithCmgaMan() throws Exception
    {
        DateResource dateRes = new DateResource();
        String satelliteIdForTest = "sat_1";
        Acquisition acqPrev = this.du.createParametricAcquisition("acq_prev", "17/01/2018 15:55:00", "17/01/2018 16:00:00", "left", satelliteIdForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_next", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "right", satelliteIdForTest);

        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(acqNext.getStartTime());
        DroolsParameters droolsParams = new DroolsParameters();

        droolsParams.setTimeForManeuverCmga(240);
        Maneuver cmgMan = this.cmgaMng.tryWithCmgaMan(dateRes, "SAT_1", acqPrev, acqNext, droolsParams);
        System.out.println(cmgMan);
    }

    @Test
    public void testTryWithCmgaMan_noTime() throws Exception
    {
        DateResource dateRes = new DateResource();
        String satelliteIdForTest = "sat_1";
        Acquisition acqPrev = this.du.createParametricAcquisition("acq_prev", "17/01/2018 15:55:00", "17/01/2018 16:00:00", "left", satelliteIdForTest);
        Acquisition acqNext = this.du.createParametricAcquisition("acq_next", "17/01/2018 17:00:00", "17/01/2018 17:01:20", "right", satelliteIdForTest);

        dateRes.setStart(acqPrev.getEndTime());
        dateRes.setStop(acqNext.getStartTime());
        DroolsParameters droolsParams = new DroolsParameters();

        droolsParams.setTimeForManeuverCmga(240);
        Maneuver cmgMan = this.cmgaMng.tryWithCmgaMan(dateRes, "SAT_1", acqPrev, acqNext, droolsParams);
        System.out.println(cmgMan);
    }

    // @Test
    // public void testCreateRamps() throws Exception
    // {
    // String sessionIdConcat = DroolsParameters.concatenateSession(sessionId,
    // sessionInstance);
    //
    // KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdConcat);
    //
    // cmgaMng.createRamps(man, droolsParams, resourceFunctions, sessionId,
    // sessionInstance);
    // }

}
