
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

public class SatellitePropertiesTest
{

    @Test
    public void testSatelliteProperties() throws Exception
    {

        String satId = "satId";

        int maxNumberDailyPeak = 1;

        List<PAWType> pawExclusionList = new ArrayList<>();

        int maxTheatreOnADay = 2;
        int includeSilentInLeftAttitudeFormulaC1 = 1;

        Map<Double, ResourceMaxValue> allChecksOnOrbits = null;

        int lowerBoundPeakOrbit = 3;

        double percentManLeftC2 = 4;

        int maxNumberOfPacketStore = 5;

        double maxContinuativeTimePDHT = 6;

        double maxCumulativeTimePDHT = 7;

        int maxNumberOfSwitchesPDHT = 8;

        double axesReconfigurationTime = 9;

        double defaultMinTimeRight = 10;

        double maxEssInLeftPeriod = 11;

        double maxTimeInAllTheLeftPeriod = 12;

        double maxTimeBetweenTwoLeftAcquisitions = 13;

        double minPercDownloadOnVis = 14;

        int activateUrgentRule = 15;

        double downlinkPerChannel = 16;

        double maxPercEclipseAvailable = 17;

        double percentEffectiveEclipse = 18;

        double timeBeforeAndAfterEclipse = 19;

        List<Visibility> allVisForSat = null;

        SatelliteProperties satProp = new SatelliteProperties();
        satProp.setSatId(satId);
        satProp.setActivateUrgentRule(activateUrgentRule);
        satProp.setAllChecksOnOrbits(allChecksOnOrbits);
        satProp.setAllVisForSat(allVisForSat);
        satProp.setAxesReconfigurationTime(axesReconfigurationTime);
        satProp.setDefaultMinTimeRight(defaultMinTimeRight);
        satProp.setDownlinkPerChannel(downlinkPerChannel);
        satProp.setIncludeSilentInLeftAttitudeFormulaC1(includeSilentInLeftAttitudeFormulaC1);
        satProp.setLowerBoundPeakOrbit(lowerBoundPeakOrbit);
        satProp.setMaxContinuativeTimePDHT(maxContinuativeTimePDHT);
        satProp.setMaxCumulativeTimePDHT(maxCumulativeTimePDHT);
        satProp.setMaxEssInLeftPeriod(maxEssInLeftPeriod);
        satProp.setMaxNumberDailyPeak(maxNumberDailyPeak);
        satProp.setMaxNumberOfPacketStore(maxNumberOfPacketStore);
        satProp.setMaxNumberOfSwitchesPDHT(maxNumberOfSwitchesPDHT);
        satProp.setMaxPercEclipseAvailable(maxPercEclipseAvailable);
        satProp.setMaxTheatreOnADay(maxTheatreOnADay);
        satProp.setMaxTimeBetweenTwoLeftAcquisitions(maxTimeBetweenTwoLeftAcquisitions);
        satProp.setMaxTimeInAllTheLeftPeriod(maxTimeInAllTheLeftPeriod);
        satProp.setMinPercDownloadOnVis(minPercDownloadOnVis);
        satProp.setPawExclusionList(pawExclusionList);
        satProp.setPercentEffectiveEclipse(percentEffectiveEclipse);
        satProp.setPercentManLeftC2(percentManLeftC2);
        satProp.setTimeBeforeAndAfterEclipse(timeBeforeAndAfterEclipse);
        satProp.setMinimumDistanceBetweenTasks(3);
        satProp.setUseExtraSectorsPt(100);
        satProp.setMaxAvailableBufferSizePt(400);
        assertEquals(satId, satProp.getSatId());
        assertEquals(timeBeforeAndAfterEclipse, satProp.getTimeBeforeAndAfterEclipse(), 0);
        assertEquals(activateUrgentRule, satProp.getActivateUrgentRule());
        assertEquals(allVisForSat, satProp.getAllVisForSat());
        assertEquals(minPercDownloadOnVis, satProp.getMinPercDownloadOnVis(), 0);
        assertEquals(maxNumberOfPacketStore, satProp.getMaxNumberOfPacketStore(), 0);
        assertEquals(400, satProp.getMaxAvailableBufferSizePt());
        assertEquals(100, satProp.getUseExtraSectorsPt());

        assertEquals(3, satProp.getMinimumDistanceBetweenTasks());

        assertEquals(maxContinuativeTimePDHT, satProp.getMaxContinuativeTimePDHT(), 0);
        assertEquals(maxCumulativeTimePDHT, satProp.getMaxCumulativeTimePDHT(), 0);
        assertEquals(maxNumberOfSwitchesPDHT, satProp.getMaxNumberOfSwitchesPDHT());
        assertEquals(percentEffectiveEclipse, satProp.getPercentEffectiveEclipse(), 0);
    }

}
