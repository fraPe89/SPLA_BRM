
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class BicManagementTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private BicUtils bicUtils = new BicUtils();
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private List<Acquisition> allAcq = null;
    private BicManagement bicMng = null;

    @Before
    public void setUp() throws ParseException, Exception
    {
        this.sessionId = "BicManagementTest";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.allAcq = new ArrayList<>();
        this.bicMng = new BicManagement();
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

    }

    @Test
    public void testCheckIfContainsArId_not_contained() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create an ar
        String arTest = "AR-003";

        // extract a partner and set the ar associated to him
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        List<String> arAssociatedToPartner = new ArrayList<>(Arrays.asList("ar1", arTest));
        p1.setArIdForPartner(arAssociatedToPartner);
        assertEquals(2, p1.getArIdForPartner().size());
        assertFalse(p1.isFinished());

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        // create an array of partner id linked to the new acq just created

        List<String> acquisitionStationIdList = new ArrayList<>();
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo = new UserInfo(acquisitionStationIdList, true, p1.getPartnerId(), "KIR");
        userInfoList.add(userInfo);

        acq1.setUserInfo(userInfoList);

        // invoke the method to check if an ar is contained into the list of ar
        // associated to acq
        boolean contained = this.bicUtils.checkIfContainsArId(acq1, p1, DroolsParameters.getSplitChar());
        assertFalse(contained);
        assertEquals(2, p1.getArIdForPartner().size());
        assertFalse(p1.isFinished());
    }

    @Test
    public void checkIfContainsArId_contained_not_last_one_Test() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create an ar
        String arTest = "AR-001";

        // extract a partner and set the ar associated to him
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        List<String> arAssociatedToPartner = new ArrayList<>(Arrays.asList("ar1", arTest));
        p1.setArIdForPartner(arAssociatedToPartner);
        assertEquals(2, p1.getArIdForPartner().size());
        assertFalse(p1.isFinished());

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        userInfoList.add(userInfo1);

        acq1.setUserInfo(userInfoList);

        // invoke the method to check if an ar is contained into the list of ar
        // associated to acq
        boolean contained = this.bicUtils.checkIfContainsArId(acq1, p1, DroolsParameters.getSplitChar());
        assertTrue(contained);
        assertFalse(p1.isFinished());
        assertEquals(1, p1.getArIdForPartner().size());
    }

    @Test
    public void checkIfContainsArId_contained_no_others_ar_Test() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create an ar
        String arTest = "AR-001";

        // extract a partner and set the ar associated to him
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        List<String> arAssociatedToPartner = new ArrayList<>(Arrays.asList(arTest));
        p1.setArIdForPartner(arAssociatedToPartner);
        assertEquals(1, p1.getArIdForPartner().size());
        assertFalse(p1.isFinished());

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        // create an array of partner id linked to the new acq just created
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        userInfoList.add(userInfo1);

        acq1.setUserInfo(userInfoList);

        // invoke the method to check if an ar is contained into the list of ar
        // associated to acq
        boolean contained = this.bicUtils.checkIfContainsArId(acq1, p1, DroolsParameters.getSplitChar());
        assertTrue(contained);
        assertTrue(p1.isFinished());
        assertEquals(0, p1.getArIdForPartner().size());
    }

    @Test
    public void testGetPartnerForLoan() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();

        double imageBicForTest = 80;

        Partner p0 = allPartners.get(0);
        p0.setUsedBIC(0);
        p0.setMaxBICAvailable(50);

        double loan = imageBicForTest - (p0.getMaxBICAvailable() - p0.getUsedBIC());
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(imageBicForTest);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p0.getPartnerId(), p0.getUgsId());
        userInfoList.add(userInfo1);

        acq1.setUserInfo(userInfoList);

        Map<Partner, Double> partnersForLoan = this.bicMng.getPartnerForLoan(DroolsParameters.getLogger(), loan, p0, this.droolsParams.getAllPartners());
        System.out.println("partners for loan : " + partnersForLoan);
    }

    @Test
    public void testSortPartnersForMaxBICAvailable() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner p0 = allPartners.get(0);
        Partner p1 = allPartners.get(1);
        Partner p2 = allPartners.get(2);
        Partner p3 = allPartners.get(3);

        // set max bic for all extracted partners
        p0.setMaxBICAvailable(30);
        p1.setMaxBICAvailable(50);
        p2.setMaxBICAvailable(60);
        p3.setMaxBICAvailable(100);

        System.out.println("allPartners : " + allPartners.size());
        System.out.println("allPartners : " + allPartners);

        this.bicUtils.sortPartnersForMaxBICAvailable(allPartners);

        System.out.println("all partners ordered :  " + allPartners);
        assertEquals(p3, allPartners.get(0));
        assertEquals(p2, allPartners.get(1));
        assertEquals(p1, allPartners.get(2));
        assertEquals(p0, allPartners.get(3));
    }

    @Test
    public void testCorrectImageBicUsedForAcq_Not_neo() throws Exception
    {

        double leftLookingCost = 10;
        double imageBicAcq1 = 20; // 10 derived from leftLookingCost
        double differenceToRestore = 0;

        List<String> partnersAssociatedId = new ArrayList<>();
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        Partner p1 = allPartners.get(0);
        Partner p2 = allPartners.get(1);

        partnersAssociatedId.add(p1.getPartnerId());
        partnersAssociatedId.add(p2.getPartnerId());

        List<Acquisition> allConsecutiveAcq = new ArrayList<>();

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(imageBicAcq1);

        List<UserInfo> userInfoListAcq1 = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoListAcq1.add(userInfo1);
        userInfoListAcq1.add(userInfo2);

        acq1.setUserInfo(userInfoListAcq1);

        p1.getAcqPerformed().add(acq1.getIdTask());
        p2.getAcqPerformed().add(acq1.getIdTask());

        allConsecutiveAcq.add(acq1);
        acq1.setPrMode(PRMode.Standard);

        differenceToRestore = leftLookingCost / allConsecutiveAcq.size();
        System.out.println("difference to restore : " + differenceToRestore);
        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, false, null, false, 0);

        assertEquals(0.0, p1.getUsedBIC(), 0);
        assertEquals(0.0, p2.getUsedBIC(), 0);

        assertEquals(0.0, p2.getUsedNeoBic(), 0);
        assertEquals(0.0, p2.getUsedNeoBic(), 0);
    }

    @Test
    public void testCorrectImageBicUsedForAcq_neo() throws Exception
    {
        List<String> partnersAssociatedToAcq = new ArrayList<>();
        double leftLookingCost = 10;
        double imageBicAcq1 = 20; // 10 derived from leftLookingCost
        double differenceToRestore = 0;

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        Partner p1 = allPartners.get(0);
        Partner p2 = allPartners.get(1);

        partnersAssociatedToAcq.add(p1.getPartnerId());
        partnersAssociatedToAcq.add(p2.getPartnerId());
        double usedBic = (imageBicAcq1) / partnersAssociatedToAcq.size();

        p1.setUsedBIC(usedBic);
        p1.setUsedNeoBic(usedBic);

        p2.setUsedBIC(usedBic);
        p2.setUsedNeoBic(usedBic);

        List<UserInfo> userInfoListAcq1 = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoListAcq1.add(userInfo1);
        userInfoListAcq1.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(imageBicAcq1);
        acq1.setNeo(true);
        acq1.setUserInfo(userInfoListAcq1);
        acq1.setExtraLeft(leftLookingCost);
        acq1.setPrMode(PRMode.Standard);

        p1.getAcqPerformed().add(acq1.getIdTask());
        p2.getAcqPerformed().add(acq1.getIdTask());

        differenceToRestore = leftLookingCost / userInfoListAcq1.size();
        System.out.println("difference to restore : " + differenceToRestore);
        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, true, null, false, 0);

        assertEquals(usedBic - differenceToRestore, p1.getUsedBIC(), 0);
        assertEquals(usedBic - differenceToRestore, p2.getUsedBIC(), 0);

        assertEquals(usedBic - differenceToRestore, p1.getUsedNeoBic(), 0);
        assertEquals(usedBic - differenceToRestore, p2.getUsedNeoBic(), 0);
    }

    @Test
    public void testCorrectImageBicUsedForAcq_noBIcToRes() throws Exception
    {
        double imageBicAcq1 = 0;
        double differenceToRestore = 0;

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        Partner p1 = allPartners.get(0);
        System.out.println("partner : " + p1);
        p1.setMaxBICAvailable(4);
        p1.setMaxNEOBicAvailable(6);

        Partner p2 = allPartners.get(1);
        p2.setMaxBICAvailable(11);
        p2.setMaxNEOBicAvailable(11);

        System.out.println("partner : " + p2);

        Partner p3 = allPartners.get(2);
        p3.setFinished(true);
        p3.getBorrowingBic().add(p1.getPartnerId());
        p3.getBorrowingBic().add(p2.getPartnerId());

        Partner p4 = allPartners.get(3);
        p4.setFinished(true);
        p4.getBorrowingBic().add(p1.getPartnerId());
        p4.getBorrowingBic().add(p2.getPartnerId());

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 11:10:03", "10/10/2017 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(imageBicAcq1);
        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);

        TreeMap<Long, EnergyAssociatedToTask> allAcqTreeMap = new TreeMap<>();
        allAcqTreeMap.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));

        TreeMap<Long, Maneuver> allManTreeMap = new TreeMap<>();

        this.bicMng.decrementBicAndNeoBic(acq1, this.droolsParams, null, false, allAcqTreeMap, allManTreeMap, false, true);

        assertEquals(0, p1.getLoanList().size());

        assertEquals(0, p4.getGivenLoan().size());

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedBIC(), 0);
        assertEquals(0, p4.getUsedBIC(), 0);

        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);
        assertEquals(0, p3.getUsedNeoBic(), 0);
        assertEquals(0, p4.getUsedNeoBic(), 0);

        System.out.println("difference to restore : " + differenceToRestore);
        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, true, null, false, 0);

        System.out.println("partner 1 : " + p1);
        System.out.println("partner 2 : " + p2);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedBIC(), 0);
        assertEquals(0, p4.getUsedBIC(), 0);

        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);
        assertEquals(0, p3.getUsedNeoBic(), 0);
        assertEquals(0, p4.getUsedNeoBic(), 0);

        assertEquals(0, p1.getLoanList().size());
        assertEquals(0, p4.getGivenLoan().size());
    }

    @Test
    public void testCorrectImageBicUsedForAcq_With_loan_refill_total_in_loan() throws Exception
    {
        double leftLookingCost = 10;
        double imageBicAcq1 = 10 + leftLookingCost;
        double differenceToRestore = 0;

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        Partner p1 = allPartners.get(0);
        System.out.println("partner : " + p1);
        p1.setMaxBICAvailable(4);
        p1.setMaxNEOBicAvailable(6);

        Partner p2 = allPartners.get(1);
        p2.setMaxBICAvailable(11);
        p2.setMaxNEOBicAvailable(11);

        System.out.println("partner : " + p2);

        Partner p3 = allPartners.get(2);
        p3.setFinished(true);
        p3.getBorrowingBic().add(p1.getPartnerId());
        p3.getBorrowingBic().add(p2.getPartnerId());

        Partner p4 = allPartners.get(3);
        p4.setFinished(true);
        p4.getBorrowingBic().add(p1.getPartnerId());
        p4.getBorrowingBic().add(p2.getPartnerId());

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 11:10:03", "10/10/2017 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(imageBicAcq1);
        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);

        TreeMap<Long, EnergyAssociatedToTask> allAcqTreeMap = new TreeMap<>();
        allAcqTreeMap.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));

        TreeMap<Long, Maneuver> allManTreeMap = new TreeMap<>();

        this.bicMng.decrementBicAndNeoBic(acq1, this.droolsParams, null, false, allAcqTreeMap, allManTreeMap, false, true);

        assertEquals(1, p1.getLoanList().size());
        assertEquals(6, p1.getLoanList().get(0).getBICBorrowed(), 0);
        assertEquals(p4.getPartnerId(), p1.getLoanList().get(0).getCreditor());

        assertEquals(1, p4.getGivenLoan().size());
        assertEquals(6, p4.getGivenLoan().get(0).getBICLent(), 0);
        assertEquals(p1.getPartnerId(), p4.getGivenLoan().get(0).getDebitor());

        assertEquals(4.0, p1.getUsedBIC(), 0);
        assertEquals(10.0, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedBIC(), 0);
        assertEquals(6, p4.getUsedBIC(), 0);

        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);
        assertEquals(0.0, p3.getUsedNeoBic(), 0);
        assertEquals(0.0, p4.getUsedNeoBic(), 0);

        System.out.println("difference to restore : " + differenceToRestore);
        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, true, null, false, 0);

        System.out.println("partner 1 : " + p1);
        System.out.println("partner 2 : " + p2);

        assertEquals(4, p1.getUsedBIC(), 0);
        assertEquals(5, p2.getUsedBIC(), 0);
        assertEquals(0.0, p3.getUsedBIC(), 0);
        assertEquals(1.0, p4.getUsedBIC(), 0);

        System.out.println("loan list of p1 :" + p1.getLoanList());

        assertEquals(0.0, p1.getUsedNeoBic(), 0);
        assertEquals(0.0, p2.getUsedNeoBic(), 0);
        assertEquals(0.0, p3.getUsedNeoBic(), 0);
        assertEquals(0.0, p4.getUsedNeoBic(), 0);

        assertEquals(1, p1.getLoanList().size());
        assertEquals(1, p1.getLoanList().get(0).getBICBorrowed(), 0);
        assertEquals(p4.getPartnerId(), p1.getLoanList().get(0).getCreditor());

        assertEquals(1, p4.getGivenLoan().size());
        assertEquals(1, p4.getGivenLoan().get(0).getBICLent(), 0);
        assertEquals(p1.getPartnerId(), p4.getGivenLoan().get(0).getDebitor());
    }

    @Test
    public void testCorrectImageBicUsedForAcq_With_loan_refill_partially_in_loan() throws Exception
    {
        double leftLookingCost = 10;
        double imageBicAcq1 = 10 + leftLookingCost;
        double imageBicAcq2 = 6 + leftLookingCost;
        double differenceToRestore = 0;

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        Partner p1 = allPartners.get(0);
        System.out.println("partner : " + p1);
        p1.setMaxBICAvailable(15);
        p1.setMaxNEOBicAvailable(15);

        Partner p2 = allPartners.get(1);
        p2.setMaxBICAvailable(11);
        p2.setMaxNEOBicAvailable(11);

        System.out.println("partner : " + p2);

        Partner p3 = allPartners.get(2);
        p3.setFinished(true);
        p3.getBorrowingBic().add(p1.getPartnerId());
        p3.getBorrowingBic().add(p2.getPartnerId());

        Partner p4 = allPartners.get(3);
        p4.setFinished(true);
        p4.getBorrowingBic().add(p1.getPartnerId());
        p4.getBorrowingBic().add(p2.getPartnerId());

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 11:10:03", "10/10/2017 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(imageBicAcq1);
        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);
        acq1.setExtraLeft(leftLookingCost / 2);

        Acquisition acq2 = this.du.createParametricAcquisition("acq2", "10/10/2017 12:10:03", "10/10/2017 12:12:00", "left", "SAT_1");
        acq2.setNeo(true);
        acq2.setImageBIC(imageBicAcq2);
        acq2.setUserInfo(userInfoList);
        acq2.setPrMode(PRMode.Standard);
        acq2.setExtraLeft(leftLookingCost / 2);
        differenceToRestore = leftLookingCost / userInfoList.size(); // = 5
                                                                     // for
                                                                     // each
                                                                     // consec
                                                                     // acquisition

        TreeMap<Long, EnergyAssociatedToTask> allAcqTreeMap = new TreeMap<>();
        allAcqTreeMap.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));

        TreeMap<Long, Maneuver> allManTreeMap = new TreeMap<>();

        this.bicMng.decrementBicAndNeoBic(acq1, this.droolsParams, null, false, allAcqTreeMap, allManTreeMap, false, true);
        allAcqTreeMap.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, acq2.getEss()));

        this.bicMng.decrementBicAndNeoBic(acq2, this.droolsParams, null, false, allAcqTreeMap, allManTreeMap, false, true);

        assertEquals(1, p2.getLoanList().size());
        assertEquals(2, p2.getLoanList().get(0).getBICBorrowed(), 0);
        assertEquals(p4.getPartnerId(), p2.getLoanList().get(0).getCreditor());

        assertEquals(1, p4.getGivenLoan().size());
        assertEquals(2, p4.getGivenLoan().get(0).getBICLent(), 0);
        assertEquals(p2.getPartnerId(), p4.getGivenLoan().get(0).getDebitor());

        assertEquals(13.0, p1.getUsedBIC(), 0);
        assertEquals(11.0, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedBIC(), 0);
        assertEquals(2, p4.getUsedBIC(), 0);

        assertEquals(5.5, p1.getUsedNeoBic(), 0);
        assertEquals(5.5, p2.getUsedNeoBic(), 0);
        assertEquals(0.0, p3.getUsedNeoBic(), 0);
        assertEquals(0.0, p4.getUsedNeoBic(), 0);

        System.out.println("difference to restore : " + differenceToRestore);
        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, true, null, false, 0);

        System.out.println("partner 1 : " + p1);
        System.out.println("partner 2 : " + p2);

        assertEquals(10.5, p1.getUsedBIC(), 0);
        assertEquals(8.5, p2.getUsedBIC(), 0);
        assertEquals(0.0, p3.getUsedBIC(), 0);
        assertEquals(2.0, p4.getUsedBIC(), 0);

        this.bicMng.restoreBicAndLoanToPartner(acq2, this.droolsParams, true, null, false, 0);
        System.out.println("partner 1 : " + p1);
        System.out.println("partner 2 : " + p2);

        assertEquals(8.0, p1.getUsedBIC(), 0);
        assertEquals(8, p2.getUsedBIC(), 0);
        assertEquals(0.0, p3.getUsedBIC(), 0);
        assertEquals(0.0, p4.getUsedBIC(), 0);

        System.out.println("loan list of p1 :" + p1.getLoanList());

        assertEquals(3.0, p1.getUsedNeoBic(), 0);
        assertEquals(3.0, p2.getUsedNeoBic(), 0);
        assertEquals(0.0, p3.getUsedNeoBic(), 0);
        assertEquals(0.0, p4.getUsedNeoBic(), 0);

        assertEquals(0, p1.getGivenLoan().size());
        assertEquals(0, p2.getGivenLoan().size());
        assertEquals(0, p3.getGivenLoan().size());
        assertEquals(0, p4.getGivenLoan().size());

        assertEquals(0, p1.getLoanList().size());
        assertEquals(0, p2.getLoanList().size());
        assertEquals(0, p3.getLoanList().size());
        assertEquals(0, p4.getLoanList().size());
    }

    @Test
    public void findAllAcqRelatedToRejectedPartners_Test() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);

        Partner p0 = allPartners.get(0);
        Partner p1 = allPartners.get(1);
        Partner p2 = allPartners.get(2);
        Partner p3 = allPartners.get(3);

        List<Partner> allPartnersWithInvalidBic = new ArrayList<>();
        allPartnersWithInvalidBic.add(p1);
        allPartnersWithInvalidBic.add(p2);

        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "left", "SAT_1");
        List<UserInfo> userInfoListAcq1 = new ArrayList<>(Arrays.asList(new UserInfo(p0.getPartnerId())));
        acq1.setUserInfo(userInfoListAcq1);

        Acquisition acq2 = this.du.createParametricAcquisition("acq2", "17/01/2018 15:10:03", "17/01/2018 15:12:00", "left", "SAT_1");
        List<UserInfo> userInfoListAcq2 = new ArrayList<>(Arrays.asList(new UserInfo(p1.getPartnerId()), new UserInfo(p3.getPartnerId())));
        acq2.setUserInfo(userInfoListAcq2);

        Acquisition acq3 = this.du.createParametricAcquisition("acq3", "17/01/2018 10:10:03", "17/01/2018 10:12:00", "left", "SAT_1");
        List<UserInfo> userInfoListAcq3 = new ArrayList<>(Arrays.asList(new UserInfo(p1.getPartnerId()), new UserInfo(p2.getPartnerId())));
        acq3.setUserInfo(userInfoListAcq3);

        Acquisition acq4 = this.du.createParametricAcquisition("acq4", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        List<UserInfo> userInfoListAcq4 = new ArrayList<>(Arrays.asList(new UserInfo(p3.getPartnerId()), new UserInfo(p2.getPartnerId())));
        acq4.setUserInfo(userInfoListAcq4);

        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, 20));
        allAcq.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, 20));
        allAcq.put(acq3.getStartTime().getTime(), new EnergyAssociatedToTask(acq3, 20));
        allAcq.put(acq4.getStartTime().getTime(), new EnergyAssociatedToTask(acq4, 20));

        List<String> allAcqInvolvedWithThesePartners = this.bicMng.findAllAcqRelatedToRejectedPartners(allPartnersWithInvalidBic, allAcq);

        System.out.println("all acq involved : " + allAcqInvolvedWithThesePartners);
        assertTrue(allAcqInvolvedWithThesePartners.contains(acq2.getId()));
        assertTrue(allAcqInvolvedWithThesePartners.contains(acq3.getId()));
        assertTrue(allAcqInvolvedWithThesePartners.contains(acq4.getId()));
        assertFalse(allAcqInvolvedWithThesePartners.contains(acq1.getId()));

    }

    /*
    @Test(expected = java.lang.NullPointerException.class)
    public void checkBicAndNeoBicForAcq_cannot_found_partner_Test() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);

        String invalidPartnerId = "DummyPartner";

        double bicForImg = 10;
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "left", "SAT_1");
        acq1.setImageBIC(bicForImg);
        acq1.setNeo(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, invalidPartnerId, "ugsId");
        userInfoList.add(userInfo1);
        acq1.setPrMode(PRMode.Standard);

        acq1.setUserInfo(userInfoList);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        List<Partner> partnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, null);
        assertEquals(0, partnerWithInvalidBic.size());
    }
*/
    @Test
    public void checkBicAndNeoBicForAcq_valid_neo_and_bic_for_all_Test() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);

        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(15);
        p1.setMaxBICAvailable(14);

        Partner p2 = allPartners.get(2);
        p2.setMaxNEOBicAvailable(15);
        p2.setMaxBICAvailable(16);

        List<Partner> partnerAssociatedToAcq = new ArrayList<>();
        partnerAssociatedToAcq.addAll(Arrays.asList(p1, p2));

        double bicForImg = 11;
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 12:10:03", "10/10/2017 12:12:00", "left", "SAT_1");
        acq1.setImageBIC(bicForImg);
        acq1.setNeo(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq1.setPrMode(PRMode.Standard);
        acq1.setUserInfo(userInfoList);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));
        TreeMap<Long, Maneuver> allMan = new TreeMap<>();

        List<Partner> partnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, allMan);
        double expectedUsedBic = (bicForImg) / partnerAssociatedToAcq.size();
        assertEquals(0, partnerWithInvalidBic.size());
        assertEquals(partnerAssociatedToAcq.size(), acq1.getUserInfo().size());
        assertEquals(expectedUsedBic, p1.getUsedBIC(), 0);
        assertEquals(expectedUsedBic, p2.getUsedBIC(), 0);
        assertEquals(expectedUsedBic, p1.getUsedNeoBic(), 0);
        assertEquals(expectedUsedBic, p2.getUsedNeoBic(), 0);
        assertTrue(p1.getLoanList().isEmpty());
        assertTrue(p2.getLoanList().isEmpty());
    }

    @Test
    public void testRestoreBic_leftAcq() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(15);
        p1.setMaxBICAvailable(24);

        Partner p2 = allPartners.get(2);
        p2.setMaxNEOBicAvailable(15);
        p2.setMaxBICAvailable(26);

        Partner p3 = allPartners.get(3);
        System.out.println("p3 " + p3);
        p3.setFinished(true);

        double bicForImg = 10;
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 12:10:03", "10/10/2017 12:12:00", "left", "SAT_1");
        acq1.setImageBIC(bicForImg);
        acq1.setNeo(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));
        TreeMap<Long, Maneuver> allMan = new TreeMap<>();

        List<Partner> invalidPartners = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, allMan);
        assertEquals(0, invalidPartners.size());

        System.out.println("partner 1 associated ; " + p1);
        System.out.println("partner 2 associated ; " + p2);

        double usedBic = (acq1.getImageBIC()) / userInfoList.size();
        assertEquals(usedBic, p1.getUsedBIC(), 0);
        assertEquals(usedBic, p1.getUsedNeoBic(), 0);
        assertEquals(true, p1.getLoanList().isEmpty());
        assertEquals(true, p3.getGivenLoan().isEmpty());
        assertEquals(usedBic, p2.getUsedBIC(), 0);
        assertEquals(usedBic, p2.getUsedNeoBic(), 0);

        System.out.println("p1 : " + p1);
        System.out.println("p2 : " + p2);
        System.out.println("p3 : " + p3);
        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, false, null, false, 0);
        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(true, p1.getLoanList().isEmpty());
        assertEquals(true, p3.getGivenLoan().isEmpty());
        assertEquals(0, p2.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);

        System.out.println("p1 : " + p1);
        System.out.println("p2 : " + p2);
        System.out.println("p3 : " + p3);

    }

    @Test
    public void testRestoreBic_RightAcq() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(15);
        p1.setMaxBICAvailable(4);

        Partner p2 = allPartners.get(2);
        p2.setMaxNEOBicAvailable(15);
        p2.setMaxBICAvailable(16);

        Partner p3 = allPartners.get(3);
        System.out.println("p3 " + p3);
        p3.getBorrowingBic().add(p1.getPartnerId());
        p3.setFinished(true);

        double bicForImg = 10;
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "right", "SAT_1");
        acq1.setImageBIC(bicForImg);
        acq1.setNeo(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        List<Partner> invalidPartners = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, null);

        System.out.println("p1 :" + p1);
        System.out.println("p2 :" + p2);
        System.out.println("p3 :" + p3);

        assertEquals(0, invalidPartners.size());

        double usedBic = acq1.getImageBIC() / userInfoList.size();
        assertEquals(usedBic - p1.getLoanList().get(0).getBICBorrowed(), p1.getUsedBIC(), 0);
        assertEquals(usedBic, p1.getUsedNeoBic(), 0);
        assertEquals(false, p1.getLoanList().isEmpty());
        assertEquals(usedBic, p2.getUsedBIC(), 0);
        assertEquals(usedBic, p2.getUsedNeoBic(), 0);

        System.out.println("p1 : " + p1);
        System.out.println("p2 : " + p2);
        System.out.println("p3 :" + p3);

        this.bicMng.restoreBicAndLoanToPartner(acq1, this.droolsParams, false, null, false, 0);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(true, p1.getLoanList().isEmpty());
        assertEquals(true, p3.getGivenLoan().isEmpty());
        assertEquals(0, p2.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);

        System.out.println("p1 : " + p1);
        System.out.println("p2 : " + p2);
        System.out.println("p3 : " + p3);
        System.out.println("p0 : " + allPartners.get(0));

    }

    @Test
    public void testDivideForAnInteger() throws Exception
    {

        double extraCostLeft = 5.6;
        double diff = extraCostLeft / 2;
        System.out.println("difference : " + diff);
    }

    @Test
    public void testRestoreBicAndLoanToPartner() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(15);
        p1.setMaxBICAvailable(4);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        userInfoList.add(userInfo1);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setImageBIC(10);
        acq1.setPrMode(PRMode.Standard);

        acq1.setUserInfo(userInfoList);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, null);
    }

    @Test
    public void A_testCheckBicAndNeoBicForAcq_invalid_neo_bic_both_partners() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);

        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(3);
        p1.setMaxBICAvailable(6);

        Partner p2 = allPartners.get(2);
        p2.setMaxNEOBicAvailable(2);
        p2.setMaxBICAvailable(16);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "left", "SAT_1");
        acq1.setImageBIC(10);
        acq1.setNeo(true);
        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        List<Partner> partnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, null);

        assertEquals(2, partnerWithInvalidBic.size());
        assertTrue(p1.getUsedBIC() == 0);
        assertTrue(p1.getUsedNeoBic() == 0);
        assertTrue(p2.getUsedBIC() == 0);
        assertTrue(p2.getUsedNeoBic() == 0);
        assertTrue(acq1.getUserInfo().size() == 0);
    }

    @Test
    public void testCheckBicAndNeoBicForAcq_invalid_bic_one_partner() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        System.out.println("partner p0 : " + allPartners.get(0));

        Partner p0 = allPartners.get(0);
        Partner p3 = allPartners.get(3);
        p0.getBorrowingBic().add(allPartners.get(1).getPartnerId());
        p0.getBorrowingBic().add(allPartners.get(2).getPartnerId());

        p3.getBorrowingBic().add(allPartners.get(1).getPartnerId());
        p3.getBorrowingBic().add(allPartners.get(2).getPartnerId());

        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(100);
        p1.setMaxBICAvailable(2);
        System.out.println("partner p1 : " + p1);

        Partner p2 = allPartners.get(2);
        p2.setMaxNEOBicAvailable(100);
        p2.setMaxBICAvailable(100);
        System.out.println("partner p2 : " + p2);

        System.out.println("partner p3 : " + allPartners.get(3));

        System.out.println("partner subscribers : " + p1.getPartnerId());
        System.out.println("partner subscribers : " + p2.getPartnerId());

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "left", "SAT_1");
        acq1.setImageBIC(80);
        acq1.setNeo(true);
        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        TreeMap<Long, Maneuver> allMan = new TreeMap<>();
        List<Partner> partnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, allMan);
        if (!partnerWithInvalidBic.isEmpty())
        {
            System.out.println("only valid partners : " + acq1.getUserInfo());
        }
        System.out.println("partner p1 " + p1);
        System.out.println("partner p2 " + p2);
        assertTrue(!partnerWithInvalidBic.isEmpty());
    }

    @Test
    public void checkBicAndNeoBicForAcq_invalid_neo_bic_one_partner_Test() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        double imageBic = 10;

        Partner p0 = allPartners.get(0);
        System.out.println("partner p0 : " + p0);

        Partner p1 = allPartners.get(1);
        p1.setMaxNEOBicAvailable(3);
        p1.setMaxBICAvailable(6);
        System.out.println("partner p1 : " + p1);

        Partner p2 = allPartners.get(2);
        p2.setMaxNEOBicAvailable(15);
        p2.setMaxBICAvailable(16);
        System.out.println("partner p2 : " + p2);

        Partner p3 = allPartners.get(3);
        System.out.println("partner p3 : " + p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "right", "SAT_1");
        acq1.setImageBIC(imageBic);
        acq1.setNeo(true);
        acq1.setUserInfo(userInfoList);
        acq1.setPrMode(PRMode.Standard);
        this.allAcq.add(acq1);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        List<Partner> partnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, null);
        System.out.println("partner p1 " + p1);
        System.out.println("partner p2 " + p2);
        System.out.println("partner with invalid bic : " + partnerWithInvalidBic);
        assertTrue(partnerWithInvalidBic.size() == 1);
    }

    @Test
    public void getAllelementsInInterval_Test() throws Exception
    {
        Date from = DroolsUtils.createDate("17/01/2018 12:10:03");
        Date to = DroolsUtils.createDate("17/01/2018 13:00:00");

        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        TreeMap<Long, EnergyAssociatedToTask> allAcqReturnedByFunction = new TreeMap<>();

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");
        Acquisition acq2 = this.du.createParametricAcquisition("acq2", "17/01/2018 12:19:03", "17/01/2018 12:21:00", "right", "SAT_1");
        Acquisition acq3 = this.du.createParametricAcquisition("acq3", "17/01/2018 12:45:03", "17/01/2018 12:48:00", "right", "SAT_1");
        Acquisition acq4 = this.du.createParametricAcquisition("acq4", "17/01/2018 13:00:01", "17/01/2018 13:05:00", "right", "SAT_1");

        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, 100));
        allAcq.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, 60));
        allAcq.put(acq3.getStartTime().getTime(), new EnergyAssociatedToTask(acq3, 90));
        allAcq.put(acq4.getStartTime().getTime(), new EnergyAssociatedToTask(acq4, 150));

        allAcqReturnedByFunction = this.bicUtils.getAllelementsInInterval(from, to, allAcq);
        assertTrue(allAcqReturnedByFunction.size() == 3);
        List<Acquisition> acqInInterval = new ArrayList<>();
        for (Map.Entry<Long, EnergyAssociatedToTask> elementsReturnedByFunction : allAcqReturnedByFunction.entrySet())
        {
            acqInInterval.add((Acquisition) elementsReturnedByFunction.getValue().getTask());
        }
        assertTrue(acqInInterval.contains(acq1));
        assertTrue(acqInInterval.contains(acq2));
        assertTrue(acqInInterval.contains(acq3));

    }

    @Test
    public void testInitializeBIC_partner_has_debit() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner partnerUnderTest = allPartners.get(0);
        Partner partnerCreditor = allPartners.get(1);
        System.out.println("partner under test : " + partnerUnderTest);
        partnerUnderTest.getLoanList().add(new DebitCard(partnerCreditor.getPartnerId(), 20, "acqForTest"));
        partnerCreditor.getGivenLoan().add(new CreditCard(partnerUnderTest.getPartnerId(), 20, "acqForTest"));

        this.bicMng.initializeBIC(partnerUnderTest);

    }

    @Test
    public void testInitializeBIC_partner_has_credit() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner partnerUnderTest = allPartners.get(0);
        Partner partnerDebitor = allPartners.get(1);
        System.out.println("partner under test : " + partnerUnderTest);
        partnerUnderTest.getGivenLoan().add(new CreditCard(partnerDebitor.getPartnerId(), 20, "acqForTest"));
        partnerDebitor.getLoanList().add(new DebitCard(partnerUnderTest.getPartnerId(), 20, "acqForTest"));

        this.bicMng.initializeBIC(partnerUnderTest);

    }

    @Test
    public void testInitializeBIC_partner_without_debit_and_credit() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner partnerUnderTest = allPartners.get(0);

        this.bicMng.initializeBIC(partnerUnderTest);

    }

    @Test
    public void testCheckBicAndNeoBicForAcq_no_partners_associated() throws Exception
    {
        double imageBIC = 10;
        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);

        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");
        acq.setImageBIC(imageBIC);
        acq.setPrMode(PRMode.Standard);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        List<Partner> allPartnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq, null, allAcq, null);

        assertEquals(0, allPartnerWithInvalidBic.size());
        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedBIC(), 0);
        assertTrue(p1.getLoanList().isEmpty());
        assertTrue(p2.getLoanList().isEmpty());
    }

    @Test
    public void testCheckBicAndNeoBicForAcq_ok_for_all_partners() throws Exception
    {
        double imageBIC = 10;
        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);

        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();

        // List<String> acquisitionStationIdList, boolean isSubscriber, String
        // ownerId, String ugsId)
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setPrMode(PRMode.Standard);
        acq.setUserInfo(userInfoList);
        acq.setImageBIC(imageBIC);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        List<Partner> allPartnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq, null, allAcq, null);

        assertEquals(0, allPartnerWithInvalidBic.size());
        assertEquals(imageBIC / acq.getUserInfo().size(), p1.getUsedBIC(), 0);
        assertEquals(imageBIC / acq.getUserInfo().size(), p2.getUsedBIC(), 0);
        assertTrue(p1.getLoanList().isEmpty());
        assertTrue(p2.getLoanList().isEmpty());

        System.out.println("invalid bic : " + allPartnerWithInvalidBic);
        System.out.println(" p1 : " + p1);
        System.out.println(" p2 : " + p2);
    }

    @Test
    public void testFindIfContainsPartner_contained() throws Exception
    {
        double imageBIC = 10;

        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);

        String partnerIdToSearch = p1.getPartnerId();
        boolean contained = false;

        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();

        // List<String> acquisitionStationIdList, boolean isSubscriber, String
        // ownerId, String ugsId)
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq.setUserInfo(userInfoList);
        acq.setImageBIC(imageBIC);

        contained = this.bicUtils.findIfContainsPartner(userInfoList, partnerIdToSearch);
        assertEquals(true, contained);
    }

    @Test
    public void testFindIfContainsPartner_not_contained() throws Exception
    {
        double imageBIC = 10;

        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);

        String partnerIdToSearch = "fakePartnerId";
        boolean contained = false;

        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();

        // List<String> acquisitionStationIdList, boolean isSubscriber, String
        // ownerId, String ugsId)
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq.setUserInfo(userInfoList);
        acq.setImageBIC(imageBIC);

        contained = this.bicUtils.findIfContainsPartner(userInfoList, partnerIdToSearch);
        assertEquals(false, contained);
    }

    @Test
    public void testDecrementBicAndNeoBic_partner_need_a_loan() throws Exception
    {
        double imageBIC = 10;
        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");

        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);
        System.out.println("partner associated p1 : " + p1);
        System.out.println("partner associated p2 : " + p2);

        p1.setMaxBICAvailable(3);
        p2.setMaxBICAvailable(10);
        // p1.getArIdForPartner().add(e)

        List<UserInfo> userInfoList = new ArrayList<>();

        // List<String> acquisitionStationIdList, boolean isSubscriber, String
        // ownerId, String ugsId)
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq.setUserInfo(userInfoList);
        acq.setImageBIC(imageBIC);
        acq.setPrMode(PRMode.Standard);
        // this.bicMng.decrementBicAndNeoBic(acq,
        // this.droolsParams.getAllPartners(), this.droolsParams, 1, null,
        // false,0);
    }

    @Test
    public void testDecrementBicAndNeoBic_partner_need_a_loanTotal() throws Exception
    {
        double imageBIC = 10;
        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");

        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);
        System.out.println("partner associated p1 : " + p1);
        System.out.println("partner associated p2 : " + p2);

        p1.setMaxBICAvailable(3);
        p1.setUsedBIC(4);
        p2.setMaxBICAvailable(10);
        // p1.getArIdForPartner().add(e)

        List<UserInfo> userInfoList = new ArrayList<>();

        // List<String> acquisitionStationIdList, boolean isSubscriber, String
        // ownerId, String ugsId)
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq.setUserInfo(userInfoList);
        acq.setImageBIC(imageBIC);
        acq.setPrMode(PRMode.Standard);
        this.bicMng.decrementBicAndNeoBic(acq, this.droolsParams, null, false, null, null, false, false);
    }

    @Test
    public void testDecrementBicAndNeoBic() throws Exception
    {
        double imageBIC = 10;
        // create an acq
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "right", "SAT_1");

        // create a list of partners associated to acq
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        Partner p2 = this.droolsParams.getAllPartners().get(2);
        System.out.println("partner associated p1 : " + p1);
        System.out.println("partner associated p2 : " + p2);

        p1.setMaxBICAvailable(3);
        p1.setUsedBIC(3);
        p2.setMaxBICAvailable(10);
        // p1.getArIdForPartner().add(e)

        List<UserInfo> userInfoList = new ArrayList<>();

        // List<String> acquisitionStationIdList, boolean isSubscriber, String
        // ownerId, String ugsId)
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq.setUserInfo(userInfoList);
        acq.setImageBIC(imageBIC);
        acq.setPrMode(PRMode.Standard);

        this.bicMng.decrementBicAndNeoBic(acq, this.droolsParams, null, false, null, null, false, false);
    }

    @Test
    public void testCheckBicAndNeoBicForAcq_no_own_bic_available() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);

        Partner partnerAssociated = allPartners.get(0);

        Partner otherPt1 = allPartners.get(1);
        otherPt1.getBorrowingBic().add(partnerAssociated.getPartnerId());
        otherPt1.setFinished(true);

        Partner otherPt2 = allPartners.get(2);
        otherPt2.getBorrowingBic().add(partnerAssociated.getPartnerId());
        otherPt2.setFinished(true);

        // saturated the bic for the chosen partner
        partnerAssociated.setUsedBIC(partnerAssociated.getMaxBICAvailable());

        double bicForImg = 10;
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 12:10:03", "17/01/2018 12:12:00", "left", "SAT_1");
        acq1.setImageBIC(bicForImg);
        acq1.setNeo(false);
        acq1.setPrMode(PRMode.Standard);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, partnerAssociated.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        acq1.setPrMode(PRMode.Standard);

        acq1.setUserInfo(userInfoList);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        TreeMap<Long, Maneuver> allMan = new TreeMap<>();

        List<Partner> partnerWithInvalidBic = this.bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq1, null, allAcq, allMan);
        System.out.println("partner : " + this.droolsParams.getAllPartners());
        assertEquals(0, partnerWithInvalidBic.size());

        System.out.println("partner associated : " + partnerAssociated);
        System.out.println("otherPt1 : " + otherPt1);
        System.out.println("potherPt2: " + otherPt2);

    }

    @Test
    public void testCheckIfIsOfExpectedType_Contained() throws Exception
    {
        PRMode prModeOfTheAcquisition = PRMode.Standard;
        PRMode prModeToSearch = PRMode.Standard;
        boolean samePrMode = this.bicUtils.checkIfIsOfExpectedType(prModeOfTheAcquisition, prModeToSearch);
        assertTrue(samePrMode);
    }

    @Test
    public void testCheckIfIsOfExpectedType_Not_Contained() throws Exception
    {
        PRMode prModeOfTheAcquisition = PRMode.DI2S;
        PRMode prModeToSearch = PRMode.Standard;
        boolean samePrMode = this.bicUtils.checkIfIsOfExpectedType(prModeOfTheAcquisition, prModeToSearch);
        assertFalse(samePrMode);
    }

    // @Test
    // public void testDecrementBicDi2s() throws Exception
    // {
    // this.du.setUpDrools(this.sessionId, this.droolsParams,
    // this.droolsInstance);
    // this.droolsInstance = this.du.setUpSession(this.sessionId,
    // SessionType.premium, this.droolsParams, this.droolsInstance,
    // this.currentKieSession, "_");
    //
    // List<Partner> allPartners = this.droolsParams.getAllPartners();
    // System.out.println("all partners :" + allPartners);
    //
    // Partner master = allPartners.get(0);
    // Partner slave = allPartners.get(1);
    //
    // double bicForImg = 10;
    // Acquisition acqDi2s =
    // this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
    // "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
    // acqDi2s.setImageBIC(bicForImg);
    // acqDi2s.setNeo(false);
    //
    // List<UserInfo> userInfoList = new ArrayList<UserInfo>();
    // UserInfo userInfo1 = new UserInfo(null, false, master.getPartnerId(),
    // "ugsId");
    // userInfoList.add(userInfo1);
    // acqDi2s.setUserInfo(userInfoList);
    //
    // String slaveId = "100_PR-ITA-001-HP_AR-001_DTO-";
    //
    // Di2sInfo dis2InfoForTest = new Di2sInfo();
    // dis2InfoForTest.setRelativeMasterId(acqDi2s.getIdTask());
    // dis2InfoForTest.setRelativeSlaveId(slaveId);
    //
    // dis2InfoForTest.setUgsId("ugsForTest");
    // dis2InfoForTest.setPartnerId(slave.getPartnerId());
    //
    // acqDi2s.setDi2sInfo(dis2InfoForTest);
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // TreeMap<Long, Maneuver> manTreemap = new TreeMap<Long, Maneuver>();
    //
    //
    // this.bicMng.decrementBicDi2s(acqDi2s,
    // this.droolsParams,allAcq,manTreemap);
    // }

    // @Test
    // public void testDecrementBicDi2s_loanTotal() throws Exception
    // {
    // this.du.setUpDrools(this.sessionId, this.droolsParams,
    // this.droolsInstance);
    // this.droolsInstance = this.du.setUpSession(this.sessionId,
    // SessionType.premium, this.droolsParams, this.droolsInstance,
    // this.currentKieSession, "_");
    //
    // List<Partner> allPartners = this.droolsParams.getAllPartners();
    // System.out.println("all partners :" + allPartners);
    //
    // Partner master = allPartners.get(0);
    // master.setMaxBICAvailable(100);
    // master.setUsedBIC(100);
    // Partner slave = allPartners.get(1);
    //
    // double bicForImg = 10;
    // Acquisition acqDi2s =
    // this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
    // "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
    // acqDi2s.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);
    // acqDi2s.setImageBIC(bicForImg);
    // acqDi2s.setNeo(false);
    //
    // List<UserInfo> userInfoList = new ArrayList<UserInfo>();
    // UserInfo userInfo1 = new UserInfo(null, false, master.getPartnerId(),
    // "ugsId");
    // userInfoList.add(userInfo1);
    // acqDi2s.setUserInfo(userInfoList);
    //
    // String slaveId = "100_PR-ITA-001-HP_AR-001_DTO-";
    //
    // Di2sInfo dis2InfoForTest = new Di2sInfo();
    // dis2InfoForTest.setRelativeMasterId(acqDi2s.getIdTask());
    // dis2InfoForTest.setRelativeSlaveId(slaveId);
    //
    // dis2InfoForTest.setUgsId("ugsForTest");
    // dis2InfoForTest.setPartnerId(slave.getPartnerId());
    //
    // acqDi2s.setDi2sInfo(dis2InfoForTest);
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // TreeMap<Long, Maneuver> manTreemap = new TreeMap<Long, Maneuver>();
    //
    //
    // this.bicMng.decrementBicDi2s(acqDi2s,
    // this.droolsParams,allAcq,manTreemap);
    // }

    // TODO ripristinare test su bic DI2S

    // @Test
    // public void testDecrementBicDi2s_loanpartial() throws Exception
    // {
    // this.du.setUpDrools(this.sessionId, this.droolsParams,
    // this.droolsInstance);
    // this.droolsInstance = this.du.setUpSession(this.sessionId,
    // SessionType.premium, this.droolsParams, this.droolsInstance,
    // this.currentKieSession, "_");
    //
    // List<Partner> allPartners = this.droolsParams.getAllPartners();
    // System.out.println("all partners :" + allPartners);
    //
    // Partner master = allPartners.get(0);
    // master.setMaxBICAvailable(100);
    // master.setUsedBIC(98);
    // Partner slave = allPartners.get(1);
    //
    // double bicForImg = 15;
    // Acquisition acqDi2s =
    // this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
    // "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
    // acqDi2s.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);
    // acqDi2s.setImageBIC(bicForImg);
    // acqDi2s.setNeo(false);
    //
    // List<UserInfo> userInfoList = new ArrayList<UserInfo>();
    // UserInfo userInfo1 = new UserInfo(null, false, master.getPartnerId(),
    // "ugsId");
    // userInfoList.add(userInfo1);
    // acqDi2s.setUserInfo(userInfoList);
    //
    // String slaveId = "100_PR-ITA-001-HP_AR-001_DTO-";
    //
    // Di2sInfo dis2InfoForTest = new Di2sInfo();
    // dis2InfoForTest.setRelativeMasterId(acqDi2s.getIdTask());
    // dis2InfoForTest.setRelativeSlaveId(slaveId);
    //
    // dis2InfoForTest.setUgsId("ugsForTest");
    // dis2InfoForTest.setPartnerId(slave.getPartnerId());
    //
    // acqDi2s.setDi2sInfo(dis2InfoForTest);
    // TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // TreeMap<Long, Maneuver> manTreemap = new TreeMap<Long, Maneuver>();
    //
    //
    // this.bicMng.decrementBicDi2s(acqDi2s,
    // this.droolsParams,allAcq,manTreemap);
    // }

    // @Test
    // public void testDecrementBicDi2s_neo() throws Exception
    // {
    // this.du.setUpDrools(this.sessionId, this.droolsParams,
    // this.droolsInstance);
    // this.droolsInstance = this.du.setUpSession(this.sessionId,
    // SessionType.premium, this.droolsParams, this.droolsInstance,
    // this.currentKieSession, "_");
    //
    // List<Partner> allPartners = this.droolsParams.getAllPartners();
    // System.out.println("all partners :" + allPartners);
    //
    // Partner master = allPartners.get(0);
    // Partner slave = allPartners.get(1);
    //
    // double bicForImg = 10;
    // Acquisition acqDi2s =
    // this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
    // "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
    // acqDi2s.setImageBIC(bicForImg);
    // acqDi2s.setNeo(true);
    //
    // List<UserInfo> userInfoList = new ArrayList<UserInfo>();
    // UserInfo userInfo1 = new UserInfo(null, false, master.getPartnerId(),
    // "ugsId");
    // userInfoList.add(userInfo1);
    // acqDi2s.setUserInfo(userInfoList);
    //
    // String slaveId = "100_PR-ITA-001-HP_AR-001_DTO-";
    //
    // Di2sInfo dis2InfoForTest = new Di2sInfo();
    // dis2InfoForTest.setRelativeMasterId(acqDi2s.getIdTask());
    // dis2InfoForTest.setRelativeSlaveId(slaveId);
    //
    // dis2InfoForTest.setUgsId("ugsForTest");
    // dis2InfoForTest.setPartnerId(slave.getPartnerId());
    //
    // acqDi2s.setDi2sInfo(dis2InfoForTest);
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // TreeMap<Long, Maneuver> manTreemap = new TreeMap<Long, Maneuver>();
    //
    // this.bicMng.decrementBicDi2s(acqDi2s,
    // this.droolsParams,allAcq,manTreemap);
    // }

    // @Test
    // public void testDecrementBicDi2s_neo_notAvailable() throws Exception
    // {
    // this.du.setUpDrools(this.sessionId, this.droolsParams,
    // this.droolsInstance);
    // this.droolsInstance = this.du.setUpSession(this.sessionId,
    // SessionType.premium, this.droolsParams, this.droolsInstance,
    // this.currentKieSession, "_");
    //
    // List<Partner> allPartners = this.droolsParams.getAllPartners();
    // System.out.println("all partners :" + allPartners);
    //
    // Partner master = allPartners.get(0);
    // master.setUsedNeoBic(master.getMaxNEOBicAvailable());
    // Partner slave = allPartners.get(1);
    //
    // double bicForImg = 10;
    // Acquisition acqDi2s =
    // this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-",
    // "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
    // acqDi2s.setImageBIC(bicForImg);
    // acqDi2s.setNeo(true);
    //
    // List<UserInfo> userInfoList = new ArrayList<UserInfo>();
    // UserInfo userInfo1 = new UserInfo(null, false, master.getPartnerId(),
    // "ugsId");
    // userInfoList.add(userInfo1);
    // acqDi2s.setUserInfo(userInfoList);
    //
    // String slaveId = "100_PR-ITA-001-HP_AR-001_DTO-";
    //
    // Di2sInfo dis2InfoForTest = new Di2sInfo();
    // dis2InfoForTest.setRelativeMasterId(acqDi2s.getIdTask());
    // dis2InfoForTest.setRelativeSlaveId(slaveId);
    //
    // dis2InfoForTest.setUgsId("ugsForTest");
    // dis2InfoForTest.setPartnerId(slave.getPartnerId());
    //
    // acqDi2s.setDi2sInfo(dis2InfoForTest);
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // TreeMap<Long, Maneuver> manTreemap = new TreeMap<Long, Maneuver>();
    //
    // this.bicMng.decrementBicDi2s(acqDi2s,
    // this.droolsParams,allAcq,manTreemap);
    // }

    @Test
    public void testDecrement_BIC_Associated_To_Partners() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Logger logger = DroolsParameters.getLogger();
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners :" + allPartners);

        Partner master = allPartners.get(0);
        master.setUsedBIC(master.getMaxBICAvailable());
        List<String> allpartnersId = new ArrayList<>();
        for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++)
        {
            this.droolsParams.getAllPartners().get(i).setFinished(true);
            allpartnersId.add(this.droolsParams.getAllPartners().get(i).getPartnerId());
        }

        for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++)
        {
            this.droolsParams.getAllPartners().get(i).getBorrowingBic().addAll(allpartnersId);
            this.droolsParams.getAllPartners().get(i).setDonation(allpartnersId);
        }
        double bicForImg = 10;
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq.setImageBIC(bicForImg);
        acq.setNeo(false);

        double loan = 10;

        Map<Partner, Double> PartnersChoosenForLoan = new HashMap<>();
        PartnersChoosenForLoan.put(this.droolsParams.getAllPartners().get(2), 20.0);

        this.bicMng.decrement_BIC_Associated_To_Partners(logger, acq, loan, master, PartnersChoosenForLoan);
    }

    @Test
    public void testCheckBicAndNeoBicForAcqDi2s_possible_needLoan_totally() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners :" + allPartners);

        Partner master = allPartners.get(0);
        master.setMaxBICAvailable(100);
        master.setUsedBIC(master.getMaxBICAvailable());
        Partner slave = allPartners.get(1);

        List<String> allpartnersId = new ArrayList<>();
        for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++)
        {
            this.droolsParams.getAllPartners().get(i).setFinished(true);
            allpartnersId.add(this.droolsParams.getAllPartners().get(i).getPartnerId());
        }

        for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++)
        {
            this.droolsParams.getAllPartners().get(i).getBorrowingBic().addAll(allpartnersId);
            this.droolsParams.getAllPartners().get(i).setDonation(allpartnersId);
        }
        double bicForImg = 10;

        DTO dto = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        dto.setImageBIC(bicForImg);
        dto.setNeoAvailable(false);

        double bicReservedToMaster = (bicForImg / 100) * this.droolsParams.getPercentBicDi2sMasterMSOR();
        boolean possibleForMaster = this.bicMng.checkBicAndNeoBicForAcqDi2s(this.droolsParams, dto, master, bicReservedToMaster);
        assertTrue(possibleForMaster);

        double bicReservedToSlave = (bicForImg / 100) * this.droolsParams.getPercentBicDi2sSlaveMSOR();
        boolean possibleForSlave = this.bicMng.checkBicAndNeoBicForAcqDi2s(this.droolsParams, dto, slave, bicReservedToSlave);
        assertTrue(possibleForSlave);
    }

    @Test
    public void testCheckBicAndNeoBicForAcqDi2s_possible_needLoan_partially() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners :" + allPartners);

        Partner master = allPartners.get(0);
        master.setMaxBICAvailable(100);
        master.setUsedBIC(master.getMaxBICAvailable());
        Partner slave = allPartners.get(1);

        List<String> allpartnersId = new ArrayList<>();
        for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++)
        {
            this.droolsParams.getAllPartners().get(i).setFinished(true);
            allpartnersId.add(this.droolsParams.getAllPartners().get(i).getPartnerId());
        }

        for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++)
        {
            this.droolsParams.getAllPartners().get(i).getBorrowingBic().addAll(allpartnersId);
            this.droolsParams.getAllPartners().get(i).setDonation(allpartnersId);
        }

        double bicForImg = 10;

        DTO dto = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        dto.setImageBIC(bicForImg);
        dto.setNeoAvailable(false);

        double bicReservedToMaster = (bicForImg / 100) * this.droolsParams.getPercentBicDi2sMasterMSOR();
        boolean possibleForMaster = this.bicMng.checkBicAndNeoBicForAcqDi2s(this.droolsParams, dto, master, bicReservedToMaster);
        assertTrue(possibleForMaster);

        double bicReservedToSlave = (bicForImg / 100) * this.droolsParams.getPercentBicDi2sSlaveMSOR();
        boolean possibleForSlave = this.bicMng.checkBicAndNeoBicForAcqDi2s(this.droolsParams, dto, slave, bicReservedToSlave);
        assertTrue(possibleForSlave);
    }

    @Test
    public void testCheckBicAndNeoBicForAcqDi2s_impossible_neo() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners :" + allPartners);

        Partner master = allPartners.get(0);
        master.setMaxNEOBicAvailable(100);
        master.setUsedNeoBic(master.getMaxNEOBicAvailable());

        Partner slave = allPartners.get(1);
        slave.setMaxNEOBicAvailable(100);
        slave.setMaxBICAvailable(100);
        slave.setUsedNeoBic(0);

        double bicForImg = 10;

        DTO dto = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        dto.setImageBIC(bicForImg);
        dto.setNeoAvailable(true);

        double bicReservedToMaster = (bicForImg / 100) * this.droolsParams.getPercentBicDi2sMasterMSOR();
        boolean possibleForMaster = this.bicMng.checkBicAndNeoBicForAcqDi2s(this.droolsParams, dto, master, bicReservedToMaster);
        assertFalse(possibleForMaster);

        double bicReservedToSlave = (bicForImg / 100) * this.droolsParams.getPercentBicDi2sSlaveMSOR();
        boolean possibleForSlave = this.bicMng.checkBicAndNeoBicForAcqDi2s(this.droolsParams, dto, slave, bicReservedToSlave);
        assertTrue(possibleForSlave);
    }

    @Test
    public void testRestoreBicAndLoanForTheatre() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.setExtraCostLeft(3);
        System.out.println("\n\n\n\n running test : testRestoreBicAndLoanForTheatre");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(5);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:40", "10/10/2017 16:55:50", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(6);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:10", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(7);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        manInsideTheatre.setReferredEquivalentDto(equivDto.getEquivalentDtoId());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);
        double extraCostTheatre = 3;

        Acquisition acq1 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        Acquisition acq2 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);
        Acquisition acq3 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        List<Acquisition> allAcqInThreatre = new ArrayList<>(Arrays.asList(acq1, acq2, acq3));
        this.bicMng.restoreBicAndLoanForTheatre(equivDto.getEquivalentDtoId(), allAcqInThreatre, extraCostTheatre, this.droolsParams);

        System.out.println(allAcqInThreatre);
    }

    @Test
    public void testRestoreBicAndLoan_NOTTheatre() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.setExtraCostLeft(3);
        System.out.println("\n\n\n\n running test : testRestoreBicAndLoanForTheatre");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(5);
        dto1.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchSlew);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Exp);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto1.getEndTime());
        equivDto.setEquivType(PRMode.Theatre);
        manInsideTheatre.setReferredEquivalentDto(equivDto.getEquivalentDtoId());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);
        double extraCostTheatre = 3;

        Acquisition acq1 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        List<Acquisition> allAcqInThreatre = new ArrayList<>(Arrays.asList(acq1));
        this.bicMng.restoreBicAndLoanForTheatre(equivDto.getEquivalentDtoId(), allAcqInThreatre, extraCostTheatre, this.droolsParams);

        System.out.println(allAcqInThreatre);
    }

    @Test
    public void testAllLinkedPartnersForIDUGS_notAllForIdus() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        String ugsIdIDUGS = this.droolsParams.getIdugsid();
        String anotherUgsId = "fakeUgsid";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUgsId(ugsIdIDUGS);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUgsId(anotherUgsId);

        Partner p3 = new Partner("Partner_1", null, 100, 20);
        p3.setUgsId(anotherUgsId);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);
        acq1.setUserInfo(userInfoList);

        boolean allForIdugs = this.bicMng.allLinkedPartnersForIDUGS(acq1, this.droolsParams);
        assertFalse(allForIdugs);
    }

    @Test
    public void testAllLinkedPartnersForIDUGS_allForIdus() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        String ugsIdIDUGS = this.droolsParams.getIdugsid();

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUgsId(ugsIdIDUGS);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUgsId(ugsIdIDUGS);

        Partner p3 = new Partner("Partner_1", null, 100, 20);
        p3.setUgsId(ugsIdIDUGS);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);
        acq1.setUserInfo(userInfoList);

        boolean allForIdugs = this.bicMng.allLinkedPartnersForIDUGS(acq1, this.droolsParams);
        assertTrue(allForIdugs);
    }

    @Test
    public void testDecrementDelta_error() throws Exception
    {
        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUsedBIC(10);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUsedBIC(8);

        Partner p3 = new Partner("Partner_3", null, 100, 20);
        p3.setUsedBIC(6);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllPartners().add(p2);
        this.droolsParams.getAllPartners().add(p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);
        acq1.setUserInfo(userInfoList);

        this.bicMng.decrementDelta(acq1, this.droolsParams, 3);
        // assertEquals(11, p1.getUsedBIC(),0);
        // assertEquals(9, p2.getUsedBIC(),0);
        // assertEquals(7, p3.getUsedBIC(),0);

    }

    @Test
    public void testDecrementDelta() throws Exception
    {
        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUsedBIC(10);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUsedBIC(8);

        Partner p3 = new Partner("Partner_3", null, 100, 20);
        p3.setUsedBIC(6);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllPartners().add(p2);
        this.droolsParams.getAllPartners().add(p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);
        acq1.setUserInfo(userInfoList);

        this.bicMng.decrementDelta(acq1, this.droolsParams, 3);
        // assertEquals(11, p1.getUsedBIC(),0);
        // assertEquals(9, p2.getUsedBIC(),0);
        // assertEquals(7, p3.getUsedBIC(),0);

    }

    @Test
    public void testDecrementDelta_DI2S_Same_partners() throws Exception
    {
        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");
        acq1.setPrMode(PRMode.DI2S);
        acq1.getUserInfo().clear();
        acq1.setNeo(true);
        
        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUsedBIC(10);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUsedBIC(8);

        UserInfo userInfoMaster = new UserInfo(p1.getPartnerId());
        userInfoMaster.setUgsId(p1.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(p2.getPartnerId());
        userInfoSlave.setUgsId(p2.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(acq1.getIdTask());
        di2sInfo.setRelativeSlaveId(null);
        di2sInfo.setSlaveDto(null);
        di2sInfo.setPartnerId(p2.getPartnerId());

        acq1.setDi2sInfo(di2sInfo);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllPartners().add(p2);

        this.bicMng.decrementDelta(acq1, this.droolsParams, 3);
        // assertEquals(11, p1.getUsedBIC(),0);
        // assertEquals(9, p2.getUsedBIC(),0);
    }

    @Test
    public void testDecrementDelta_DI2S_Different_partners_SPOTLIGHT_1_MSOR() throws Exception
    {
        this.droolsParams.setPercentBicDi2sMasterMSOR(20);
        this.droolsParams.setPercentBicDi2sSlaveMSOR(80);

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");
        acq1.setPrMode(PRMode.DI2S);
        acq1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1_MSOR);
        acq1.getUserInfo().clear();

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUsedBIC(10);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUsedBIC(8);

        UserInfo userInfoMaster = new UserInfo(p1.getPartnerId());
        userInfoMaster.setUgsId(p1.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(p2.getPartnerId());
        userInfoSlave.setUgsId(p2.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(acq1.getIdTask());
        di2sInfo.setRelativeSlaveId(null);
        di2sInfo.setSlaveDto(null);
        di2sInfo.setPartnerId(p2.getPartnerId());

        acq1.setDi2sInfo(di2sInfo);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllPartners().add(p2);

        this.bicMng.decrementDelta(acq1, this.droolsParams, 3);
        assertEquals(10.6, p1.getUsedBIC(), 0); // 10
        assertEquals(10.4, p2.getUsedBIC(), 0); // 8

    }

    
    
    @Test
    public void testDecrementDelta_DI2S_Different_partners_SPOTLIGHT_2_MOS() throws Exception
    {
        this.droolsParams.setPercentBicDi2sMasterMSOR(20);
        this.droolsParams.setPercentBicDi2sSlaveMSOR(80);

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");
        acq1.setPrMode(PRMode.DI2S);
        acq1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MOS);
        acq1.getUserInfo().clear();

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUsedBIC(10);

        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUsedBIC(8);

        UserInfo userInfoMaster = new UserInfo(p1.getPartnerId());
        userInfoMaster.setUgsId(p1.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(p2.getPartnerId());
        userInfoSlave.setUgsId(p2.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(acq1.getIdTask());
        di2sInfo.setRelativeSlaveId(null);
        di2sInfo.setSlaveDto(null);
        di2sInfo.setPartnerId(p2.getPartnerId());

        acq1.setDi2sInfo(di2sInfo);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllPartners().add(p2);

        this.bicMng.decrementDelta(acq1, this.droolsParams, 3);
        assertEquals(10.6, p1.getUsedBIC(), 0); // 10
        assertEquals(10.4, p2.getUsedBIC(), 0); // 8

    }

    
    @Test
    public void testDecrementDelta_DI2S_Different_partners_SPOTLIGHT_2_MOS_noBic() throws Exception
    {
        this.droolsParams.setPercentBicDi2sMasterMSOR(20);
        this.droolsParams.setPercentBicDi2sSlaveMSOR(80);

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");
        acq1.setPrMode(PRMode.DI2S);
        acq1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MOS);
        acq1.getUserInfo().clear();
        acq1.setImageBIC(4);
        
        Partner p1 = new Partner("Partner_1", null, 100, 20);
        p1.setUsedBIC(13);
        p1.setMaxBICAvailable(12);
        Partner p2 = new Partner("Partner_2", null, 100, 20);
        p2.setUsedBIC(11);
        p2.setMaxBICAvailable(12);

        UserInfo userInfoMaster = new UserInfo(p1.getPartnerId());
        userInfoMaster.setUgsId(p1.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(p2.getPartnerId());
        userInfoSlave.setUgsId(p2.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(null);
        acq1.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(acq1.getIdTask());
        di2sInfo.setRelativeSlaveId(null);
        di2sInfo.setSlaveDto(null);
        di2sInfo.setPartnerId(p2.getPartnerId());

        acq1.setDi2sInfo(di2sInfo);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllPartners().add(p2);

        this.bicMng.decrementDelta(acq1, this.droolsParams, 3);

    }

    
    @Test
    public void testUpdateBicForOtherAcqInTrainLeft() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:55:40", "10/10/2017 16:55:50", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(6);
        dto1.setSizeH(4000);

    }

}
