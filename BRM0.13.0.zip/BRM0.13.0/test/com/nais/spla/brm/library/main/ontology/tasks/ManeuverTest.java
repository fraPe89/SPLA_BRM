
package com.nais.spla.brm.library.main.ontology.tasks;

public class ManeuverTest
{

}
