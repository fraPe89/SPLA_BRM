
package com.nais.spla.brm.library.main.ontology.resources;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;

public class PartnerTest
{

    @Test
    public void TestPartner()
    {

        /** The partner id. */
        String partnerId = "PartnerTest";

        /** The ugs id. */
        String ugsId = "1000";

        /** The max BIC available. */
        double maxBICAvailable = 100;

        /** The max NEO bic available. */
        double maxNEOBicAvailable = 50;

        /** The pay offs. */
        int payOffs = 1;

        /** The max perc loan bic. */
        double maxPercLoanBic = 30;

        /** The new bic setup. */
        boolean newBicSetup = false;

        /** The loan list. */
        List<DebitCard> loanList = new ArrayList<>();

        /** The given loan. */
        List<CreditCard> givenLoan = new ArrayList<>();

        /** The cannot give credit. */
        List<String> borrowingBic = new ArrayList<>();

        /** The donation. */
        List<String> donation = new ArrayList<>();

        /** The finished. */
        boolean finished = false;

        /** The ar id for partner. */
        List<String> arIdForPartner = new ArrayList<>();

        /** The acq performed. */
        List<String> acqPerformed = new ArrayList<>();

        Partner p1 = new Partner(partnerId, arIdForPartner, maxBICAvailable, maxPercLoanBic);
        p1.setFinished(finished);
        p1.setPayOffs(payOffs);
        p1.setAcqPerformed(acqPerformed);
        p1.setDonation(donation);
        p1.setBorrowingBic(borrowingBic);
        p1.setPartnerId(partnerId);
        p1.setGivenLoan(givenLoan);
        p1.setLoanList(loanList);
        p1.setNewBicSetup(newBicSetup);
        p1.setUgsId(ugsId);
        p1.setMaxBICAvailable(maxBICAvailable);
        p1.setMaxNEOBicAvailable(maxNEOBicAvailable);
        assertEquals(payOffs, p1.getPayOffs());
        assertEquals(partnerId, p1.getPartnerId());

    }

}
