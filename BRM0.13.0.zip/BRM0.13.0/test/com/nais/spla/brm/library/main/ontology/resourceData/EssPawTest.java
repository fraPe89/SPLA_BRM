
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.PAWType;

public class EssPawTest
{

    @Test
    public void testEssPaw() throws Exception
    {

        PAWType paw = PAWType.CAL;

        double essPaw = 23.2;

        EssPaw essPawStructure = new EssPaw(paw, essPaw);

        assertEquals(essPaw, essPawStructure.getEssPaw(), 0);
        assertEquals(paw, essPawStructure.getPaw());
    }

}
