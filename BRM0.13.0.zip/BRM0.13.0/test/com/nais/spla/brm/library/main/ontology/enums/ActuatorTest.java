
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ActuatorTest
{

    @Test
    public void testEnumActuator()
    {
        List<Actuator> allActuatorsForTest = new ArrayList<>(Arrays.asList(Actuator.CMGA, Actuator.CMGA, Actuator.total));
        Actuator[] allactuators = Actuator.values();
        for (int i = 0; i < allactuators.length; i++)
        {
            for (int j = 0; j < allActuatorsForTest.size(); j++)
            {
                if (allactuators[i].equals(allActuatorsForTest.get(j)))
                {
                    allActuatorsForTest.remove(j);
                    j--;
                }
            }
        }

        Actuator type;
        type = Actuator.valueOf("CMGA");
        System.out.println("Selected : " + type);

        assertEquals(0, allActuatorsForTest.size());
    }
}
