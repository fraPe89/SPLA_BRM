
package com.nais.spla.brm.library.main.drools.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class BicUtilsTest
{

    private BicUtils bicUtils = new BicUtils();
    private DroolsUtils du = new DroolsUtils();

    @Test
    public void testCheckIfContainsArId_moreThanOneAr() throws Exception
    {
        String ugsIdIDUGS = "200";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        List<String> arList = new ArrayList<>(Arrays.asList("AR-001", "AR-002", "AR-003"));

        Partner p1 = new Partner("Partner_1", arList, 100, 20);
        p1.setUgsId(ugsIdIDUGS);

        Partner p2 = new Partner("Partner_2", arList, 100, 20);
        p2.setUgsId(ugsIdIDUGS);

        Partner p3 = new Partner("Partner_1", arList, 100, 20);
        p3.setUgsId(ugsIdIDUGS);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);
        acq1.setUserInfo(userInfoList);

        p2.getAcqPerformed().add(acq1.getIdTask());
        assertTrue(p2.getArIdForPartner().size() == 3);
        this.bicUtils.checkIfContainsArId(acq1, p2, "_");
        assertTrue(p2.getArIdForPartner().size() == 2);

    }

    @Test
    public void testCheckIfContainsArId_lastAr() throws Exception
    {
        String ugsIdIDUGS = "200";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        List<String> arListP1 = new ArrayList<>(Arrays.asList("AR-001", "AR-002"));
        List<String> arListP2 = new ArrayList<>(Arrays.asList("AR-001"));
        List<String> arListP3 = new ArrayList<>();

        Partner p1 = new Partner("Partner_1", arListP1, 100, 20);
        p1.setUgsId(ugsIdIDUGS);

        Partner p2 = new Partner("Partner_2", arListP2, 100, 20);
        p2.setUgsId(ugsIdIDUGS);

        Partner p3 = new Partner("Partner_1", arListP3, 100, 20);
        p3.setUgsId(ugsIdIDUGS);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);
        acq1.setUserInfo(userInfoList);

        p1.getAcqPerformed().add(acq1.getIdTask());
        p2.getAcqPerformed().add(acq1.getIdTask());
        p3.getAcqPerformed().add(acq1.getIdTask());

        assertTrue(p1.getArIdForPartner().size() == 2);
        assertTrue(p2.getArIdForPartner().size() == 1);
        assertTrue(p3.getArIdForPartner().size() == 0);

        this.bicUtils.checkIfContainsArId(acq1, p1, "_");
        this.bicUtils.checkIfContainsArId(acq1, p2, "_");
        this.bicUtils.checkIfContainsArId(acq1, p3, "_");

        assertTrue(p1.getArIdForPartner().size() == 1);
        assertTrue(p2.getArIdForPartner().size() == 0);
        assertTrue(p3.getArIdForPartner().size() == 0);

        assertFalse(p1.isFinished());
        assertTrue(p2.isFinished());
        assertTrue(p3.isFinished());

    }

    @Test
    public void testGetAllelementsInInterval_elements_and_borderline() throws Exception
    {
        Date from = DroolsUtils.createDate("17/01/2018 11:10:03");
        Date to = DroolsUtils.createDate("17/01/2018 11:11:03");

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:08:03", "17/01/2018 11:08:50", "left", "SAT_1");

        // create a new acquisition
        Acquisition acq2 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:09:03", "17/01/2018 11:10:04", "left", "SAT_1");

        // create a new acquisition
        Acquisition acq3 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");

        // create a new acquisition
        Acquisition acq4 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:12:00", "17/01/2018 11:12:10", "left", "SAT_1");

        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, 2));
        allAcq.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, 2));
        allAcq.put(acq3.getStartTime().getTime(), new EnergyAssociatedToTask(acq3, 2));
        allAcq.put(acq4.getStartTime().getTime(), new EnergyAssociatedToTask(acq4, 2));

        TreeMap<Long, EnergyAssociatedToTask> returnedElements = this.bicUtils.getAllelementsInInterval(from, to, allAcq);

        assertFalse(returnedElements.containsKey(acq1.getStartTime().getTime()));
        assertTrue(returnedElements.containsKey(acq2.getStartTime().getTime()));
        assertTrue(returnedElements.containsKey(acq3.getStartTime().getTime()));
        assertFalse(returnedElements.containsKey(acq4.getStartTime().getTime()));

        assertEquals(2, returnedElements.size());

    }

    @Test
    public void testGetAllelementsInInterval_no_Eelements() throws Exception
    {
        Date from = DroolsUtils.createDate("17/01/2018 10:10:03");
        Date to = DroolsUtils.createDate("17/01/2018 10:11:03");

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:08:03", "17/01/2018 11:08:50", "left", "SAT_1");

        // create a new acquisition
        Acquisition acq2 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:09:03", "17/01/2018 11:10:04", "left", "SAT_1");

        // create a new acquisition
        Acquisition acq3 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");

        // create a new acquisition
        Acquisition acq4 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:12:00", "17/01/2018 11:12:10", "left", "SAT_1");

        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();
        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, 2));
        allAcq.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, 2));
        allAcq.put(acq3.getStartTime().getTime(), new EnergyAssociatedToTask(acq3, 2));
        allAcq.put(acq4.getStartTime().getTime(), new EnergyAssociatedToTask(acq4, 2));

        TreeMap<Long, EnergyAssociatedToTask> returnedElements = this.bicUtils.getAllelementsInInterval(from, to, allAcq);

        assertFalse(returnedElements.containsKey(acq1.getStartTime().getTime()));
        assertFalse(returnedElements.containsKey(acq2.getStartTime().getTime()));
        assertFalse(returnedElements.containsKey(acq3.getStartTime().getTime()));
        assertFalse(returnedElements.containsKey(acq4.getStartTime().getTime()));

        assertEquals(0, returnedElements.size());
    }

    @Test
    public void testFindIfContainsPartner_contained() throws Exception
    {
        Partner p1 = new Partner("Partner_1", null, 100, 20);

        Partner p2 = new Partner("Partner_2", null, 100, 20);

        Partner p3 = new Partner("Partner_3", null, 100, 20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        userInfoList.add(userInfo3);

        boolean contained = this.bicUtils.findIfContainsPartner(userInfoList, p3.getPartnerId());
        assertTrue(contained);
    }

    @Test
    public void testFindIfContainsPartner_NotContained() throws Exception
    {
        Partner p1 = new Partner("Partner_1", null, 100, 20);

        Partner p2 = new Partner("Partner_2", null, 100, 20);

        Partner p3 = new Partner("Partner_3", null, 100, 20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        boolean contained = this.bicUtils.findIfContainsPartner(userInfoList, p3.getPartnerId());
        assertFalse(contained);
    }

    @Test
    public void testCheckIfIsOfExpectedType_equals() throws Exception
    {
        PRMode prModeOfAcq = PRMode.DI2S;
        PRMode prToCheck = PRMode.DI2S;

        boolean equals = this.bicUtils.checkIfIsOfExpectedType(prModeOfAcq, prToCheck);

        assertTrue(equals);

    }

    @Test
    public void testCheckIfIsOfExpectedType_notEquals() throws Exception
    {
        PRMode prModeOfAcq = PRMode.DI2S;
        PRMode prToCheck = PRMode.Exp;

        boolean equals = this.bicUtils.checkIfIsOfExpectedType(prModeOfAcq, prToCheck);

        assertFalse(equals);
    }

    @Test
    public void testFindPartnerInList() throws Exception
    {

        Partner p1 = new Partner("Partner_1", null, 100, 20);

        Partner p2 = new Partner("Partner_2", null, 100, 20);

        Partner p3 = new Partner("Partner_3", null, 100, 20);

        List<Partner> allPartners = new ArrayList<>(Arrays.asList(p1, p2, p3));
        Partner returnedPartner = this.bicUtils.findPartnerInList(p3.getPartnerId(), allPartners);
        assertEquals(p3.toString(), returnedPartner.toString());
    }

    /*
    @Test(expected = java.lang.NullPointerException.class)
    public void testFindPartnerInList_notFound() throws Exception
    {

        Partner p1 = new Partner("Partner_1", null, 100, 20);

        Partner p2 = new Partner("Partner_2", null, 100, 20);

        Partner p3 = new Partner("Partner_3", null, 100, 20);

        List<Partner> allPartners = new ArrayList<>(Arrays.asList(p1, p2, p3));
        Partner returnedPartner = this.bicUtils.findPartnerInList("fakePartnerToSearch", allPartners);
        assertEquals(null, returnedPartner);
    }*/

    @Test
    public void testSortPartnersForMaxBICAvailable() throws Exception
    {
        Partner p1 = new Partner("Partner_1", null, 20, 20);

        Partner p2 = new Partner("Partner_2", null, 50, 20);

        Partner p3 = new Partner("Partner_3", null, 100, 20);

        List<Partner> allPartners = new ArrayList<>(Arrays.asList(p1, p2, p3));
        this.bicUtils.sortPartnersForMaxBICAvailable(allPartners);

        assertEquals(p3, allPartners.get(0));
        assertEquals(p2, allPartners.get(1));
        assertEquals(p1, allPartners.get(2));

    }

    @Test
    public void testCheckIfMustBeDecrementBic_premium() throws Exception
    {
        SessionType sessionType = SessionType.premium;
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.HP);
        boolean decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertTrue(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.PP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertTrue(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.CRISIS);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertTrue(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.CIVILIAN_HP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertTrue(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.RANKED_ROUTINE);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.UNRANKED_ROUTINE);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.VU);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.LMP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);
    }

    @Test
    public void testCheckIfMustBeDecrementBic_routine() throws Exception
    {
        SessionType sessionType = SessionType.routine;
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.HP);
        boolean decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.PP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.CRISIS);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.CIVILIAN_HP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.RANKED_ROUTINE);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertTrue(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.UNRANKED_ROUTINE);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertTrue(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.VU);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.LMP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);
    }

    @Test
    public void testCheckIfMustBeDecrementBic_urgent() throws Exception
    {
        SessionType sessionType = SessionType.urgent;
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.HP);
        boolean decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.PP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.CRISIS);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.CIVILIAN_HP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.RANKED_ROUTINE);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.UNRANKED_ROUTINE);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.VU);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);

        acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:11:00", "17/01/2018 11:11:10", "left", "SAT_1");
        acq1.setPrType(PRType.LMP);
        decrement = this.bicUtils.checkIfMustBeDecrementBic(sessionType, acq1);
        assertFalse(decrement);
    }
}
