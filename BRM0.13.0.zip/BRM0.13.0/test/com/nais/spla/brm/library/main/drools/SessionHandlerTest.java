
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;

public class SessionHandlerTest
{

    static TreeMap<String, KieSession> kieSessionsMap = new TreeMap<>();

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "initPlan";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void SessionHan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        SessionHandler session = new SessionHandler();
        System.out.println(session);

        String sessionKey = this.sessionId + "_" + this.currentKieSession;
        KieSession currentKie = SessionHandler.getKieSessionsMap().get(sessionKey);
        assertTrue(currentKie != null);

        // remove current kieSession
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
        currentKie = SessionHandler.getKieSessionsMap().get(sessionKey);
        assertTrue(currentKie == null);
    }

}
