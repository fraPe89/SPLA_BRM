
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;

public class ComplexReasonTest
{

    @Test
    public void testComplexReason() throws Exception
    {

        /** The reason. */
        ReasonOfReject reason = ReasonOfReject.acqInconsistentWithPaw;

        /** The id. */
        int id = 2;

        /** The reason description. */
        String reasonDescription = "acq inconsistent with paw";

        ComplexReason complexReas = new ComplexReason(reason, id, reasonDescription);

        assertEquals(id, complexReas.getId());
        assertEquals(reason, complexReas.getReason());
        assertEquals(reasonDescription, complexReas.getReasonDescription());
        System.out.println(complexReas.toString());
    }

}
