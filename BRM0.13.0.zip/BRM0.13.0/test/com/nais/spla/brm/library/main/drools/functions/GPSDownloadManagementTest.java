
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;

public class GPSDownloadManagementTest
{

    DroolsUtils du = new DroolsUtils();
    StubResources stub = new StubResources();
    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "Test_GPS";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    @Test
    public void planGpsSectorsForCurrentVis() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

    }

    @Test
    public void testCheckLastPeriodAvailableOnVis_paw_at_end() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        long durationGps = 300;
        String linkForGps = "2";
        Visibility currentVis = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

        GPSDownloadManagement.checkLastPeriodAvailableOnVis(durationGps, linkForGps, currentVis, dwlTreeMap);

    }

    @Test
    public void testCreateDownloadGPS() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getAllVisibilities().clear();

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int cont = 0;
        String packet = "4";
        Visibility currentVis = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");
        int downloadSize = 200;
        this.droolsParams.getAllVisibilities().add(currentVis);

        System.out.println(resourceFunctions.getDownloadsAssociatedToSat("SAT_1"));
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwl = resourceFunctions.getDownloadsAssociatedToSat("SAT_1");
        assertEquals(0, allDwl.size());

        this.droolsParams.setSpaceWireForGps(0.14);
        this.droolsParams.setGpsAlwaysPlannedOnLink("2");

        GPSDownloadManagement.createDownloadGPS(cont, downloadSize, packet, currentVis, downloadSize, resourceFunctions, this.droolsParams);
        allDwl = resourceFunctions.getDownloadsAssociatedToSat("SAT_1");
        assertEquals(1, allDwl.size());
        System.out.println(resourceFunctions.getDownloadAssociatedToSat("SAT_1"));
    }

    @Test
    public void testPlanGpsSectorsForCurrentVis() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 10:00:00", "10/10/2017 10:15:00", PAWType.CAL);
        
        Visibility currentVis = this.stub.createVisibility(2, "SAT_1","1200", "1200", "10/10/2017 15:55:00", "10/10/2017 16:10:00");
        Visibility extVis = this.stub.createVisibility(3, "SAT_1", "1000", null, "10/10/2017 16:55:00", "10/10/2017 17:10:00");
        Visibility nextVis = this.stub.createVisibility(3, "SAT_1", "1200", "1200", "10/10/2017 17:55:00", "10/10/2017 18:10:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(currentVis,extVis, nextVis));
        
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3));
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        GPSDownloadManagement gpsMng = new GPSDownloadManagement();
        int cont = 0;
        List<Visibility> allExternalVisibilities = this.droolsParams.getAllVisibilities();
        HashMap<String, Visibility> allVisAsMap = new HashMap<>();
        for (int i = 0; i < allExternalVisibilities.size(); i++)
        {
            Visibility vis = allExternalVisibilities.get(i);
            allVisAsMap.put(vis.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis), vis);
        }

        List<PAW> allPAWS = this.droolsParams.getAllPAWS();
        boolean external = true;
        ResourceFunctions resFuncs = (ResourceFunctions) droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        String satId = "SAT_1";
        //resFuncs.getAllStoAuxForSatellite(satId).clear();
       gpsMng.planGpsSectorsForCurrentVis(cont, allVisAsMap, allPAWS, this.droolsParams, external, resFuncs, satId);
 
        List<StoreAUX> allStoAux = resFuncs.getAllStoAuxForSatellite(satId);
        for(int i=0;i<allStoAux.size();i++)
        {
            System.out.println(allStoAux.get(i));

        }
        assertEquals(4, allStoAux.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testPlanGpsSectorsForCurrentVis_GPS() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 18:00:00", "10/10/2017 18:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 16:05:00", "10/10/2017 16:25:00", PAWType.CAL);

        Visibility currentVis = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");
        Visibility nextVis = this.stub.createVisibility(3, "SAT_1", "1100", null, "10/10/2017 17:55:00", "10/10/2017 18:10:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(currentVis, nextVis));
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3));
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        GPSDownloadManagement gpsMng = new GPSDownloadManagement();
        int cont = 0;
        List<Visibility> allExternalVisibilities = this.droolsParams.getAllVisibilities();
        HashMap<String, Visibility> allVisAsMap = new HashMap<>();
        for (int i = 0; i < allExternalVisibilities.size(); i++)
        {
            Visibility vis = allExternalVisibilities.get(i);
            allVisAsMap.put(vis.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis), vis);
        }

        List<PAW> allPAWS = this.droolsParams.getAllPAWS();
        boolean external = true;
        ResourceFunctions resFuncs = (ResourceFunctions) droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        String satId = "SAT_1";
       gpsMng.planGpsSectorsForCurrentVis(cont, allVisAsMap, allPAWS, this.droolsParams, external, resFuncs, satId);
        resFuncs.getDownloadAssociatedToSat("1");
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>  allDwl = resFuncs.getDownloadsAssociatedToSat("1");
        
        List<Download>  onlyGPS = DownloadManagement.getAllDwlFromTreeMapGPS(satId, droolsParams, allDwl);
        
        for(int i=0;i<onlyGPS.size();i++)
        	{
        		System.out.println(onlyGPS.get(i));
        	}
        
       // assertEquals(2,onlyGPS.size());
        System.out.println( resFuncs.getDownloadsAssociatedToSat("1"));

        List<StoreAUX> allStoAux = resFuncs.getAllStoAuxForSatellite(satId);
        System.out.println(allStoAux);
        assertEquals(4, allStoAux.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
    

    @Test
    public void testCheckLastPeriodAvailableOnVis() throws Exception
    {

        long durationGps = 300;
        String linkForGps = "2";
        Visibility currentVis = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

        GPSDownloadManagement.checkLastPeriodAvailableOnVis(durationGps, linkForGps, currentVis, dwlTreeMap);
    }

    @Test
    public void testResizeVisForPaw() throws Exception
    {

        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");
        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);
        allExternalVisibilities.put(vis2.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis2), vis2);
        allExternalVisibilities.put(vis3.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis3), vis3);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 10:00:00", "10/10/2017 10:15:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        for (Map.Entry<String, Visibility> allVis : allVisFiltered.entrySet())
        {
            System.out.println(allVis.getValue());
        }
    }

    @Test
    public void testResizeVisForPaw_No_overlap() throws Exception
    {

        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 10:00:00", "10/10/2017 10:15:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        for (Map.Entry<String, Visibility> allVis : allVisFiltered.entrySet())
        {
            System.out.println(allVis.getKey());

            System.out.println(allVis.getValue());
        }
        assertEquals(1, allVisFiltered.size());
        assertEquals(vis1.getStartTime(), allVisFiltered.firstEntry().getValue().getStartTime());
        assertEquals(vis1.getEndTime(), allVisFiltered.firstEntry().getValue().getEndTime());

    }

    @Test
    public void testResizeVisForPaw_OverlapStart() throws Exception
    {
        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 15:00:00", "10/10/2017 16:00:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        for (Map.Entry<String, Visibility> allVis : allVisFiltered.entrySet())
        {
            System.out.println(allVis.getValue());
        }

        assertEquals(1, allVisFiltered.size());
        Visibility vis = allVisFiltered.firstEntry().getValue();

        assertEquals(vis.getStartTime(), paw3.getEndTime());
        assertEquals(vis.getAvailableStartTimeL1(), paw3.getEndTime());
        assertEquals(vis.getAvailableStartTimeL2(), paw3.getEndTime());

        assertEquals(vis.getEndTime(), vis1.getEndTime());

    }

    @Test
    public void testResizeVisForPaw_OverlapStartStop() throws Exception
    {
        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 16:08:00", "10/10/2017 16:16:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 15:00:00", "10/10/2017 16:00:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        for (Map.Entry<String, Visibility> allVis : allVisFiltered.entrySet())
        {
            System.out.println(allVis.getValue());
        }

        assertEquals(1, allVisFiltered.size());
        Visibility vis = allVisFiltered.firstEntry().getValue();

        assertEquals(vis.getStartTime(), paw3.getEndTime());
        assertEquals(vis.getAvailableStartTimeL1(), paw3.getEndTime());
        assertEquals(vis.getAvailableStartTimeL2(), paw3.getEndTime());

        assertEquals(vis.getEndTime(), paw2.getStartTime());

    }

    @Test
    public void testResizeVisForPaw_OverlapEnd() throws Exception
    {
        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 16:00:00", "10/10/2017 16:30:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        for (Map.Entry<String, Visibility> allVis : allVisFiltered.entrySet())
        {
            System.out.println(allVis.getValue());
        }

        assertEquals(1, allVisFiltered.size());
        Visibility vis = allVisFiltered.firstEntry().getValue();

        assertEquals(vis.getStartTime(), vis1.getStartTime());
        assertEquals(vis.getAvailableStartTimeL1(), vis1.getStartTime());
        assertEquals(vis.getAvailableStartTimeL2(), vis1.getStartTime());

        assertEquals(vis.getEndTime(), paw3.getStartTime());

    }

    @Test
    public void testResizeVisForPaw_OverlapMiddle() throws Exception
    {
    	Date visEndTime = DroolsUtils.createDate("10/10/2017 16:10:00");

        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 15:58:00", "10/10/2017 16:02:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        assertEquals(2, allVisFiltered.size());
        Visibility returnedVis1 = allVisFiltered.firstEntry().getValue();
        Visibility returnedVis2 = allVisFiltered.lastEntry().getValue();

        System.out.println("returnedVis1 "+ returnedVis1);

        
        assertEquals(returnedVis1.getStartTime(), vis1.getStartTime());
        assertEquals(returnedVis1.getAvailableStartTimeL1(), vis1.getStartTime());
        assertEquals(returnedVis1.getAvailableStartTimeL2(), vis1.getStartTime());
        assertEquals(returnedVis1.getEndTime(), paw3.getStartTime());

        System.out.println("returnedVis2 "+ returnedVis2);

        assertEquals(paw3.getEndTime(),returnedVis2.getStartTime());
        assertEquals( paw3.getEndTime(),returnedVis2.getAvailableStartTimeL1());
        assertEquals(paw3.getEndTime(),returnedVis2.getAvailableStartTimeL2());
        assertEquals( visEndTime.getTime(),returnedVis2.getEndTime().getTime());

    }

    @Test
    public void testResizeVisForPaw_OverlapMiddle2() throws Exception
    {
    	Date endTimevis = DroolsUtils.createDate("10/10/2017 16:10:00");
        Visibility vis1 = this.stub.createVisibility(2, "SAT_1", "1100", null, "10/10/2017 15:55:00", "10/10/2017 16:10:00");

        HashMap<String, Visibility> allExternalVisibilities = new HashMap<>();
        allExternalVisibilities.put(vis1.getStartTime().getTime() + DownloadManagement.concatVisId("1", vis1), vis1);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 15:00:00", "10/10/2017 15:56:00", PAWType.SWM);
        PAW paw3 = this.stub.createPaw(3, "SAT_1", "10/10/2017 15:59:00", "10/10/2017 16:02:00", PAWType.CAL);
        List<PAW> allPAWS = new ArrayList<>(Arrays.asList(paw1, paw2, paw3));

        TreeMap<String, Visibility> allVisFiltered = GPSDownloadManagement.resizeVisForPaw(allExternalVisibilities, allPAWS);

        for (Map.Entry<String, Visibility> allVis : allVisFiltered.entrySet())
        {
            System.out.println(allVis.getValue());
        }

        assertEquals(2, allVisFiltered.size());
        Visibility returnedVis1 = allVisFiltered.firstEntry().getValue();
        Visibility returnedVis2 = allVisFiltered.lastEntry().getValue();

        assertEquals(returnedVis1.getStartTime(), paw2.getEndTime());
        assertEquals(returnedVis1.getAvailableStartTimeL1(), paw2.getEndTime());
        assertEquals(returnedVis1.getAvailableStartTimeL2(), paw2.getEndTime());
        assertEquals(returnedVis1.getEndTime(), paw3.getStartTime());

        assertEquals(returnedVis2.getStartTime(), paw3.getEndTime());
        assertEquals(returnedVis2.getAvailableStartTimeL1(), paw3.getEndTime());
        assertEquals(returnedVis2.getAvailableStartTimeL2(), paw3.getEndTime());
        assertEquals(returnedVis2.getEndTime(), endTimevis);

    }

}
