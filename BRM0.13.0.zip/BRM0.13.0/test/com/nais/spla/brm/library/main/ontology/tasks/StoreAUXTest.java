
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.functions.CreateTaskManagement;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;

public class StoreAUXTest
{

    @Test
    public void testStoreAUX() throws Exception
    {
        boolean enableFlag = false;

        /** The packet store id. */
        String currentPs = "psID";

        PAWType pawType = PAWType.SWM;
        StubResources stub = new StubResources();
        PAW paw1 = stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:25:00", pawType);
        StoreAUX storeAuxTest = CreateTaskManagement.createStoreAux(paw1, enableFlag, currentPs);

        
        assertEquals(pawType, storeAuxTest.getPawType());
        assertEquals(enableFlag, storeAuxTest.isEnableFlag());
        assertEquals(paw1.getStartTime().getTime(), storeAuxTest.getStartTime().getTime());    
        assertEquals(paw1.getStartTime().getTime(), storeAuxTest.getEndTime().getTime());    
        
        
        
         enableFlag = true;
        StoreAUX storeAuxTest2 = CreateTaskManagement.createStoreAux(paw1, enableFlag, currentPs);

        
        assertEquals(pawType, storeAuxTest2.getPawType());
        assertEquals(enableFlag, storeAuxTest2.isEnableFlag());
        assertEquals(paw1.getEndTime().getTime(), storeAuxTest2.getStartTime().getTime());    
        assertEquals(paw1.getEndTime().getTime(), storeAuxTest2.getEndTime().getTime());   
        }

}
