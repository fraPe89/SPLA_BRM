
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;

public class SatelliteStateTest
{

    @Test
    public void testSatelliteState() throws Exception
    {
        DroolsUtils du = new DroolsUtils();
        Date startUnavailability = DroolsUtils.createDate("10/10/2017 08:00:00");
        Date endUnavailability = DroolsUtils.createDate("10/10/2017 09:00:00");
        String satId = "SAT_1";

        SatelliteState satState = new SatelliteState(satId, startUnavailability, endUnavailability);
        assertEquals(satId, satState.getSatelliteId());
        assertEquals(startUnavailability, satState.getStartUnavailability());
        assertEquals(endUnavailability, satState.getEndUnavailability());

    }

}
