
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;

public class CMGAxisTest
{

    @Test
    public void testCreateCmgAxis() throws Exception
    {
        DroolsUtils du = new DroolsUtils();

        String satelliteId = "SAT_1";
        Date startTime = DroolsUtils.createDate("10/10/2017 18:00:00");
        Date endTime = DroolsUtils.createDate("10/10/2017 18:00:00");
        boolean rollToPitch = false;

        CMGAxis cmgAxis = new CMGAxis(startTime, endTime);
        cmgAxis.setRollToPitch(rollToPitch);
        cmgAxis.setSatelliteId(satelliteId);

        CMGAxis cmgAxis2 = new CMGAxis();
        cmgAxis2.setEndTime(endTime);
        cmgAxis2.setStartTime(startTime);
        cmgAxis2.setRollToPitch(rollToPitch);
        cmgAxis2.setSatelliteId(satelliteId);
        cmgAxis2.setTaskType(TaskType.AXES_RECONF);
        assertEquals(cmgAxis.toString(), cmgAxis2.toString());
        assertEquals(cmgAxis.getEndTime(), cmgAxis2.getEndTime());
        assertEquals(cmgAxis.getStartTime(), cmgAxis2.getStartTime());
        assertEquals(cmgAxis.isRollToPitch(), cmgAxis2.isRollToPitch());
        assertEquals(cmgAxis.getSatelliteId(), cmgAxis2.getSatelliteId());

    }
}
