
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;

public class ConfigMapsTest
{

    @Test
    public void testConfigMaps() throws Exception
    {
        Map<TypeOfAcquisition, Double> powerSensorMode = new HashMap<>();
        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap = new HashMap<>();
        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tStandardmap = new HashMap<>();
        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tThresholdMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> maxDurationSensorMode = new HashMap<>();
        Map<Integer, Double> maxHpBicForFixedOrbitMap = new HashMap<>();

        ConfigMaps configMap1 = new ConfigMaps();
        configMap1.setMaxDurationSensorMode(maxDurationSensorMode);
        configMap1.setMaxHpBicForFixedOrbitMap(maxHpBicForFixedOrbitMap);
        configMap1.setMinDistanceMap(minDistanceMap);
        configMap1.setPowerSensorMode(powerSensorMode);
        configMap1.settStandardmap(tStandardmap);
        configMap1.settThresholdMap(tThresholdMap);

        assertEquals(powerSensorMode, configMap1.getPowerSensorMode());
        assertEquals(minDistanceMap, configMap1.getMinDistanceMap());
        assertEquals(tStandardmap, configMap1.gettStandardmap());
        assertEquals(tThresholdMap, configMap1.gettThresholdMap());
        assertEquals(maxDurationSensorMode, configMap1.getMaxDurationSensorMode());
        assertEquals(maxHpBicForFixedOrbitMap, configMap1.getMaxHpBicForFixedOrbitMap());

    }

}
