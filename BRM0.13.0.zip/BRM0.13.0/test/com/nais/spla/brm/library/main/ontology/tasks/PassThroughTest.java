
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;

public class PassThroughTest
{

    @Test
    public void createPassThroughTest()
    {
        BigDecimal deliberateDelay = new BigDecimal(0);
        int packetStoreSizeH = 30;
        String idTask = "idTask";
        String prReqId = "prReqId";
        String arReqId = "arReqId";
        String satId = "Sat_1";
        List<String> groundStatId = new ArrayList<>(Arrays.asList("grStatId"));

        PassThrough pt = new PassThrough(idTask, prReqId, arReqId, satId, null, "psId", packetStoreSizeH,0,packetStoreSizeH, deliberateDelay);

        boolean dataStrategyH = true;
        boolean dataStrategyV = false;
        boolean carrierL2SelectionH = true;
        boolean carrierL2SelectionV = false;
        List<String> ugsOwnerList = new ArrayList<>();

        assertEquals(idTask, pt.getIdTask());

        pt.setGroundStationId(groundStatId);
        assertEquals(groundStatId, pt.getGroundStationId());

        pt.setPacketStoreSizeH(packetStoreSizeH);
        assertEquals(packetStoreSizeH, pt.getPacketStoreSizeH());

        pt.setUgsOwnerList(ugsOwnerList);
        assertEquals(ugsOwnerList, pt.getUgsOwnerList());

        // ar id
        pt.setAcquisitionRequestId("arId");
        assertEquals("arId", pt.getAcquisitionRequestId());

        pt.setReferredEquivalentDto("refEquivDto");

        // data strategy H
        pt.setDataStrategyH(dataStrategyH);
        assertTrue(pt.isDataStrategyH());

        // data strategy V
        pt.setDataStrategyV(dataStrategyV);
        assertFalse(pt.isDataStrategyV());

        // carrier L2 selection H
        pt.setCarrierL2SelectionH(carrierL2SelectionH);
        assertTrue(pt.isCarrierL2SelectionH());

        // carrier L2 selection V
        pt.setCarrierL2SelectionV(carrierL2SelectionV);
        assertFalse(pt.isCarrierL2SelectionV());

        pt.setDeliberateDelay(deliberateDelay);
        assertEquals(deliberateDelay, pt.getDeliberateDelay());

        // packet store id
        pt.setPacketStoreId("packetStoreId");
        assertEquals("packetStoreId", pt.getPacketStoreId());

        // task mark
        pt.setTaskMark(TaskMarkType.NEW);
        assertEquals(TaskMarkType.NEW, pt.getTaskMark());

    }

}
