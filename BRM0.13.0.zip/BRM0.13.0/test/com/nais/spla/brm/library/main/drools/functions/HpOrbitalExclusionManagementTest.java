
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class HpOrbitalExclusionManagementTest
{

    HpOrbitalExclusionManagement hpOrbitMng = new HpOrbitalExclusionManagement();
    DroolsUtils du = new DroolsUtils();
    long timeForRw = 240;
    StubResources stub = new StubResources();

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;

    @Before
    public void setUp() throws ParseException, Exception
    {
        this.sessionId = "PassThroughManagementTest";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

    }

    @Test
    public void testCheckIfSegmentIsInInterval_activeA_but_no_time_for_man() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("1", "01/01/2018 06:29:00", "right", "01/01/2018 06:32:00", "left", "SAT_1", true, true);
        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_1", this.timeForRw);
        assertFalse(inInterval);
    }

    @Test
    public void testCheckIfSegmentIsInInterval_active_deltaFat() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("15/09/2016 06:21:00", "15/09/2016 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("1", "30/08/2016 11:00:00", "right", "30/08/2016 11:10:00", "left", "SAT_1", true, true);
        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_1", this.timeForRw);
        assertTrue(inInterval);
    }

    @Test
    public void testCheckIfSegmentIsInInterval_activeAndInOverlap() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("1", "01/01/2018 06:29:00", "right", "01/01/2018 06:39:00", "left", "SAT_1", true, true);
        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_1", this.timeForRw);
        assertTrue(inInterval);
    }

    @Test
    public void testCheckIfSegmentIsInInterval_unactive() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("2", "14/01/2018 06:29:00", "right", "14/01/2018 06:32:00", "left", "SAT_1", true, true);
        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_1", this.timeForRw);
        assertFalse(inInterval);
    }

    @Test
    public void testCheckIfSegmentIsInInterval_activeAndNotOverlap() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("1", "14/01/2018 06:29:00", "right", "14/01/2018 06:32:00", "left", "SAT_1", true, true);
        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_1", this.timeForRw);
        assertFalse(inInterval);
    }

    @Test
    public void testCheckIfSegmentIsInInterval_different_satellite() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("1", "14/01/2018 06:29:00", "right", "14/01/2018 06:32:00", "left", "SAT_1", true, true);
        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_2", this.timeForRw);
        assertFalse(inInterval);
    }

    @Test
    public void testCheckIfSegmentIsInInterval_not_enabled() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");
        HPExclusion segment = this.stub.createHPExclusion("1", "14/01/2018 06:29:00", "right", "14/01/2018 06:36:00", "left", "SAT_1", false, true);

        boolean inInterval = this.hpOrbitMng.checkIfSegmentIsInInterval(mh, segment, "SAT_1", this.timeForRw);
        assertFalse(inInterval);
    }

    @Test
    public void testComputeTime() throws Exception
    {
        Date dateToCheck = DroolsUtils.createDate("17/01/2018 11:10:00");
        String returnedTime = this.hpOrbitMng.computeTime(dateToCheck);
        String expectedTime = "11:10:00";
        assertEquals(expectedTime, returnedTime);
    }

    @Test
    public void testCheckIfThereAreElementsInInterval() throws Exception
    {
        // long id, String startTimeAsString, String startLookSide, String
        // endTimeAsString, String endLookSide, String satelliteId,boolean
        // isEnabled, boolean isPeriodic )
        MissionHorizon mh = this.stub.createMH("17/01/2018 06:21:00", "17/01/2018 18:21:00");

        HPExclusion segment1 = this.stub.createHPExclusion("1", "01/01/2018 06:29:00", "right", "01/01/2018 06:42:00", "left", "SAT_1", true, true);
        HPExclusion segment2 = this.stub.createHPExclusion("2", "13/01/2018 07:29:00", "left", "13/01/2018 06:38:00", "left", "SAT_1", true, true);
        HPExclusion segment3 = this.stub.createHPExclusion("3", "17/01/2018 09:29:00", null, "17/01/2018 09:39:00", "left", "SAT_1", true, false);
        HPExclusion segment4 = this.stub.createHPExclusion("4", "17/01/2018 11:29:00", "left", "17/01/2018 11:31:00", null, "SAT_1", false, false);
        HPExclusion segment5 = this.stub.createHPExclusion("5", "17/01/2018 06:00:00", "left", "17/01/2018 06:38:00", "left", "SAT_1", true, true);
        HPExclusion segment6 = this.stub.createHPExclusion("6", "17/01/2018 18:00:00", "left", "17/01/2018 18:38:00", "left", "SAT_1", true, true);

        List<HPExclusion> allPawInMh = new ArrayList<>();
        allPawInMh.add(segment1);
        allPawInMh.add(segment2);
        allPawInMh.add(segment3);
        allPawInMh.add(segment4);
        allPawInMh.add(segment5);
        allPawInMh.add(segment6);

        List<HPExclusion> onlyPawInInterval = new ArrayList<>();

        onlyPawInInterval = this.hpOrbitMng.checkIfThereAreElementsInInterval(mh, allPawInMh, "SAT_1", this.timeForRw);
        System.out.println("only valid segments : " + onlyPawInInterval);
        assertTrue(onlyPawInInterval.size() == 4);
        assertTrue(onlyPawInInterval.contains(segment1));
        assertTrue(onlyPawInInterval.contains(segment3));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeHpExclusionAtEnd_HP_thereIsTime_RW() throws Exception
    {

        Acquisition acq = this.du.createParametricAcquisition("acq_prev", "17/01/2018 15:55:00", "17/01/2018 16:00:00", "left", "SAT_1");
        acq.setPrType(PRType.HP);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getHpExclusionList().clear();

        HPExclusion hpSeg = this.stub.createHPExclusion("5", "10/10/2017 06:00:00", "left", "10/10/2017 06:38:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:43:00", "10/10/2017 06:44:00", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");

        rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");
        assertTrue(rejected.get(dto1.getDtoId()) == null);

        System.out.println("REJECTED : " + rejected);
        System.out.println("all TASKS : ");
        Map<String, Task> tasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> allAccepted : tasksAccepted.entrySet())
        {
            System.out.println(allAccepted.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeHpExclusionAtEnd_HP_thereIsTime_CMGA_possible() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getHpExclusionList().clear();

        HPExclusion hpSeg = this.stub.createHPExclusion("5", "10/10/2017 06:00:00", "left", "10/10/2017 06:38:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:43:00", "10/10/2017 06:44:00", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");

        rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");
        assertTrue(rejected.get(dto1.getDtoId()) == null);

        System.out.println("REJECTED : " + rejected);
        System.out.println("all TASKS : ");
        Map<String, Task> tasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> allAccepted : tasksAccepted.entrySet())
        {
            System.out.println(allAccepted.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeHpExclusionAtEnd_HP_thereIsTime_CMGA_impossible() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1d).setMaxManeuversCMGA(0);

        Acquisition acq = this.du.createParametricAcquisition("acq_prev", "17/01/2018 06:43:00", "17/01/2018 06:44:00", "right", "SAT_1");
        acq.setPrType(PRType.HP);
        HPExclusion hpSeg = this.stub.createHPExclusion("5", "17/01/2018 06:00:00", "left", "17/01/2018 06:38:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");
        this.hpOrbitMng.computeHpExclusionAtEnd(acq, hpSeg, this.droolsParams, resourceFunctions, rejected);

        System.out.println("all TASKS : " + this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeHpExclusionAtEnd_HP_thereIsNOTTime() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Acquisition acq = this.du.createParametricAcquisition("acq_prev", "17/01/2018 06:40:00", "17/01/2018 06:41:00", "right", "SAT_1");
        acq.setPrType(PRType.HP);
        HPExclusion hpSeg = this.stub.createHPExclusion("5", "17/01/2018 06:00:00", "left", "17/01/2018 06:38:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");
        this.hpOrbitMng.computeHpExclusionAtEnd(acq, hpSeg, this.droolsParams, resourceFunctions, rejected);

        System.out.println("all TASKS : " + this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeHpExclusionAtEnd_HP_sameLookSide() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Acquisition acq = this.du.createParametricAcquisition("acq_prev", "17/01/2018 06:40:00", "17/01/2018 06:41:00", "left", "SAT_1");
        acq.setPrType(PRType.HP);
        HPExclusion hpSeg = this.stub.createHPExclusion("5", "17/01/2018 06:00:00", "left", "17/01/2018 06:38:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");
        this.hpOrbitMng.computeHpExclusionAtEnd(acq, hpSeg, this.droolsParams, resourceFunctions, rejected);

        System.out.println("all TASKS : " + this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeHpExclusionAtEnd_VU_thereIsNOTTime() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Acquisition acq = this.du.createParametricAcquisition("acq_prev", "17/01/2018 06:40:00", "17/01/2018 06:41:00", "right", "SAT_1");
        acq.setPrType(PRType.VU);
        HPExclusion hpSeg = this.stub.createHPExclusion("5", "17/01/2018 06:00:00", "left", "17/01/2018 06:38:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) kie.getGlobal("rejected");
        this.hpOrbitMng.computeHpExclusionAtEnd(acq, hpSeg, this.droolsParams, resourceFunctions, rejected);

        System.out.println("all TASKS : " + this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }
}
