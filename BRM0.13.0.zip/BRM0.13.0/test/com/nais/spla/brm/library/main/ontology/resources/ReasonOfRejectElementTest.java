
package com.nais.spla.brm.library.main.ontology.resources;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.utils.ElementsInvolvedOnOrbit;

public class ReasonOfRejectElementTest
{

    private ReasonOfRejectElement reasonofRejEl = null;

    @Test
    public void testAddElementInvolved_orbitStillpresent() throws Exception
    {
        ReasonOfRejectElement reasonofRejEl = new ReasonOfRejectElement();
        int id = 100;
        String description = "acquisition Inconsistent With Paw";

        double onOrbit = 1.0;
        List<String> elementsInvolvedId = new ArrayList<>();
        elementsInvolvedId.add("dto1");
        ElementsInvolvedOnOrbit elements1 = new ElementsInvolvedOnOrbit();
        elements1.setSlidingWindow(1);
        elements1.setElementsInvolved(elementsInvolvedId);

        reasonofRejEl.addElementInvolved(onOrbit, elements1);

        ElementsInvolvedOnOrbit elements2 = new ElementsInvolvedOnOrbit();
        elements2.setSlidingWindow(2);
        elementsInvolvedId.add("dto2");
        elements2.setElementsInvolved(elementsInvolvedId);
        reasonofRejEl.addElementInvolved(onOrbit, elements2);

        reasonofRejEl.setId(id);
        reasonofRejEl.setDescription(description);

        assertEquals(id, reasonofRejEl.getId());
        assertEquals(description, reasonofRejEl.getDescription());

        Map<Double, List<ElementsInvolvedOnOrbit>> elements = reasonofRejEl.getElementsInvolved();
        System.out.println(elements);
        System.out.println(reasonofRejEl.toString());
    }

    @Test
    public void testAddElementInvolved_orbitStillpresent_null() throws Exception
    {
        ReasonOfRejectElement reasonofRejEl = new ReasonOfRejectElement();
        int id = 100;
        String description = "acquisition Inconsistent With Paw";

        double onOrbit = 1.0;
        List<String> elementsInvolvedId = new ArrayList<>();
        elementsInvolvedId.add("dto1");
        ElementsInvolvedOnOrbit elements1 = new ElementsInvolvedOnOrbit();
        elements1.setSlidingWindow(1);
        elements1.setElementsInvolved(elementsInvolvedId);

        // reasonofRejEl.addElementInvolved(onOrbit, elements1);

        ElementsInvolvedOnOrbit elements2 = null;
        reasonofRejEl.addElementInvolved(onOrbit, elements2);

        reasonofRejEl.setId(id);
        reasonofRejEl.setDescription(description);

        assertEquals(id, reasonofRejEl.getId());
        assertEquals(description, reasonofRejEl.getDescription());

        Map<Double, List<ElementsInvolvedOnOrbit>> elements = reasonofRejEl.getElementsInvolved();
        System.out.println(elements);
        System.out.println(reasonofRejEl.toString());
    }

    @Test
    public void testAddElementInvolved() throws Exception
    {
        int id = 100;
        ReasonOfReject reason = ReasonOfReject.acqInconsistentWithPaw;
        String description = "acquisition Inconsistent With Paw";
        this.reasonofRejEl = new ReasonOfRejectElement(reason, id, description, null);

        ReasonOfRejectElement reasonofRejEl2 = new ReasonOfRejectElement();
        reasonofRejEl2.setDescription(description);
        reasonofRejEl2.setId(id);
        reasonofRejEl2.setReason(reason);

        assertEquals(this.reasonofRejEl.getId(), reasonofRejEl2.getId());
        assertEquals(this.reasonofRejEl.getDescription(), reasonofRejEl2.getDescription());
        assertEquals(this.reasonofRejEl.getReason(), reasonofRejEl2.getReason());
    }

}
