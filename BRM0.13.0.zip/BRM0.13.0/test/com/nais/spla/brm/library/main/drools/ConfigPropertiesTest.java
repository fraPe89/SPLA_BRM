/**
*
* MODULE FILE NAME:	TestConfigProperties.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		29 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 29 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.exception.ConfigurationException;

// TODO: Auto-generated Javadoc
/**
 * The Class ConfigPropertiesTest.
 *
 * @author fpedrola
 */
public class ConfigPropertiesTest
{

    /** The config properties path. */
    private String configPropertiesPath = "config" + File.separator + "brm.properties";

    /** The config. */
    private ConfigProperties config = null;

    /**
     * Test.
     */
    @Before
    public void test()
    {
        this.config = new ConfigProperties();
    }

    /**
     * Inits the test.
     *
     * @throws ConfigurationException the configuration exception
     */
    @Test
    public void initTest() throws ConfigurationException
    {
            this.config.init(this.configPropertiesPath);
            String property = this.config.getPropertiesByName("minutesForOrbit");
            String expectedProperty = "97";
            assertEquals(expectedProperty, property);
    }


    /**
     * Load fake file.
     *
     * @throws ConfigurationException the configuration exception
     */
    @Test(expected = NullPointerException.class)
    public void loadFakeFile() throws ConfigurationException
    {
        this.config.init(this.configPropertiesPath);
        String property = this.config.getPropertiesByName("minutesForOrbitssss");
        String expectedProperty = "97";
        assertEquals(expectedProperty, property);
    }

    /**
     * Test check null value.
     *
     * @throws Exception the exception
     */
    @Test(expected = java.lang.NullPointerException.class)
    public void TestCheckNullValueNull() throws Exception
    {
        this.config.init(this.configPropertiesPath);
        String property = null;
        this.config.checkNullValue(property, "not configured");
    }

    /**
     * Test check null value.
     *
     * @throws Exception the exception
     */
    @Test
    public void TestCheckNullValueNotNull() throws Exception
    {
        this.config.init(this.configPropertiesPath);
        String property = "notNull";
        this.config.checkNullValue(property, "not configured");
    }

    
	/**
	 * Test load properties file.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testLoadPropertiesFile() throws Exception {
        this.config.init(this.configPropertiesPath);
        this.config.loadPropertiesFile(this.configPropertiesPath);
	}
	

    /**
     * Test load properties file null.
     *
     * @throws Exception the exception
     */
    @Test(expected = ConfigurationException.class)
	public void testLoadPropertiesFileNull() throws Exception {
        this.config.init(this.configPropertiesPath);
        this.config.loadPropertiesFile("this.configPropertiesPathFake");
	}
}
