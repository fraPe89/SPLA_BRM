
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;

public class SilentTest
{

    @Test
    public void testSilent()
    {
        /** The associated acq. */
        String associatedAcq = "dto1Test";

        /** The energy. */
        double energy = 80;

        /** The loan from ess. */
        double loanFromEss = 2;

        Silent sil = new Silent(associatedAcq, energy);
        sil.setLoanFromEss(loanFromEss);

        sil.setTaskMark(TaskMarkType.CONFIRMED);
        sil.setTaskType(TaskType.SILENT);

        assertEquals(TaskMarkType.CONFIRMED, sil.getTaskMark());
        assertEquals(TaskType.SILENT, sil.getTaskType());

    }

}
