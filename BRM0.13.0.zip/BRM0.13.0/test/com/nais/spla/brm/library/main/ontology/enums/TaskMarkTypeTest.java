
package com.nais.spla.brm.library.main.ontology.enums;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * The Class TaskMarkTypeTest.
 */
public class TaskMarkTypeTest
{

    /**
     * Test enum task mark type.
     */
    @Test
    public void testEnumTaskMarkType()
    {
        List<TaskMarkType> allTaskMarkTypeForTest = new ArrayList<>();
        TaskMarkType[] allTaskMarkType = TaskMarkType.values();
        for (int i = 0; i < allTaskMarkType.length; i++)
        {

            allTaskMarkTypeForTest.add(allTaskMarkType[i]);
        }
        TaskMarkType type;
        type = TaskMarkType.valueOf("CONFIRMED");
        System.out.println("Selected : " + type);

    }

}
