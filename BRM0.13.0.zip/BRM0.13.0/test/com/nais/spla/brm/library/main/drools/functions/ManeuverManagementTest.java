/**
*
* MODULE FILE NAME: TstManeuverManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        24 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 24 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PlanningResources;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

/**
 * @author fpedrola
 *
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ManeuverManagementTest
{

    private String sessionId = null;
    private ManeuverManagement manMng = new ManeuverManagement();
    TaskPlanned taskPlanned = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private StubResources stub = new StubResources();

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "SilentManagementTest";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.taskPlanned = new TaskPlanned();
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    public Maneuver findPrevOrNextDifferentMan(Maneuver man, TreeMap<Long, Maneuver> manFunctions, boolean prev)
    {
        // set as default that there isn't a previous man cmg
        boolean foundPrevCmg = false;
        Maneuver prevOrNextMan = null;
        
        List<ManeuverType> manToCheck = null;
        
        // if the maneuver type is roll
        if (man.getType().equals(ManeuverType.RollSlew))
        {
            // the complementar manType are pitchCSPS and PitchSlew
            manToCheck = new ArrayList<>(Arrays.asList(ManeuverType.PitchCPS, ManeuverType.PitchSlew));
        }
        
        // if the maneuver type is pitch
        else
        {
            /// the complementar manType is pitch
            manToCheck = new ArrayList<>(Arrays.asList(ManeuverType.RollSlew));
        }
        
        // initialize the first element to search,
        // based on the maneuver passed as input
        long startMan = man.getStartTime().getTime();
        while (!foundPrevCmg)
        {
            // if the method must search a
            // previous cmga maneuver (prev == true)
            if (prev)
            {
                // if there is a previous man
                if (manFunctions.lowerKey(startMan) != null)
                {
                    // extract the previous man
                    prevOrNextMan = manFunctions.lowerEntry(startMan).getValue();
                    
                    // if the previous man is of the type that we search
                    if (manToCheck.contains(prevOrNextMan.getType()))
                    {
                        // foundPrevCmg = true
                        foundPrevCmg = true;
                    }
                    else
                    {
                        // continue to search, go back to previous man, if
                        // exists
                        startMan = prevOrNextMan.getStartTime().getTime();
                    }
                }
                else
                {
                    // if there aren't previous man exit from the cycle
                    prevOrNextMan = null;
                    break;
                }
            }
            // if the method must search a next
            // cmga maneuver (prev == true)
            else
            {
                // if there is a next man
                if (manFunctions.higherKey(startMan) != null)
                {
                    // get the next man
                    prevOrNextMan = manFunctions.higherEntry(startMan).getValue();
                    
                    // if the next man is a cmga
                    if (prevOrNextMan.getActuator().equals(Actuator.CMGA))
                    {
                        // if we are searching for a cmg
                        if (manToCheck.contains(prevOrNextMan.getType()))
                        {
                            // found man
                            foundPrevCmg = true;
                        }
                        // we are searching a rw,
                        // go to next maneuver
                        else
                        {
                            // update start man
                            startMan = prevOrNextMan.getStartTime().getTime();
                        }
                    }
                    // if the next man is a rw
                    else
                    {
                        // we are searching a cmg,
                        // go to next maneuver
                        startMan = prevOrNextMan.getStartTime().getTime();
                    }
                }
                else
                {
                    prevOrNextMan = null;
                    break;
                }
            }
        }
        return prevOrNextMan;
    }
    
    @SuppressWarnings("unchecked")
    private void axisReconfig(Maneuver man)
    {
        System.out.println("rule check axes reconfiguration for" + man);
        String satId = man.getSatelliteId();
        SatelliteProperties satProp = this.droolsParams.getSatWithId(satId).getSatelliteProperties();
        System.out.println("maneuver under analysis:" + man);
        
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        boolean reject = false;
        Acquisition acqToRemove = DroolsParameters.getLastAcq();
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) kie.getGlobal("rejected");
        TreeMap<Long, Maneuver> manFunctions = resourceFunctions.getManeuverFunctionAssociatedToSat(satId);
        Maneuver previousMan = null;
        Maneuver nextMan = null;
        // check if there gap with previous man is enough for plan an axis
        // reconf
        
        previousMan = findPrevOrNextDifferentMan(man, manFunctions, true);
        
        if (previousMan != null)
        {
            long gapWithPrev = man.getStartTime().getTime() - previousMan.getEndTime().getTime();
            if (gapWithPrev < (satProp.getAxesReconfigurationTime() * 1000))
            {
                // remove the last acq because there isn't time for axes reconf
                rejected.put(acqToRemove.getId(), acqToRemove);
                acqToRemove.addReasonOfReject(1, ReasonOfReject.noTimeForAxesReconf, "", 0, 0, null);
                acqToRemove.setRejected(true);
                System.out.println("ACQ rejected : " + acqToRemove.getId() + "because :  noTimeForAxesReconf");
                reject = true;
            }
            else
            {
                // plan axes reconf between maneuvers
                Date endTimeAxisRec = man.getStartTime();
                long startTimeAsLong = ((long) (man.getStartTime().getTime() - (satProp.getAxesReconfigurationTime() * 1000)));
                Date startTimeAxisRec = new Date(startTimeAsLong);
                CMGAxis newCmgAxis = new CMGAxis(startTimeAxisRec, endTimeAxisRec);
                resourceFunctions.getCmgaAxisAssociatedToSat(satId).put(newCmgAxis.getStartTime().getTime(), newCmgAxis);
            }
        }
        
        if (!reject)
        {
            nextMan = findPrevOrNextDifferentMan(man, manFunctions, false);
            if (nextMan != null)
            {
                long gapWithNext = nextMan.getStartTime().getTime() - man.getEndTime().getTime();
                
                // check if there gap with previous man is enough for plan an
                // axis reconf
                if (gapWithNext < (satProp.getAxesReconfigurationTime() * 1000))
                {
                    // remove the last acq because there isn't time for axes
                    // reconf
                    rejected.put(acqToRemove.getId(), acqToRemove);
                    acqToRemove.addReasonOfReject(1, ReasonOfReject.noTimeForAxesReconf, "", 0, 0, null);
                    acqToRemove.setRejected(true);
                    System.out.println("ACQ rejected : " + acqToRemove.getId() + "because :  noTimeForAxesReconf");
                }
                else
                {
                    // plan axes reconf between maneuvers
                    Date endTimeAxisRec = nextMan.getStartTime();
                    long startTimeAsLong = ((long) (nextMan.getStartTime().getTime() - (satProp.getAxesReconfigurationTime() * 1000)));
                    Date startTimeAxisRec = new Date(startTimeAsLong);
                    CMGAxis newCmgAxis = new CMGAxis(startTimeAxisRec, endTimeAxisRec);
                    resourceFunctions.getCmgaAxisAssociatedToSat(satId).put(newCmgAxis.getStartTime().getTime(), newCmgAxis);
                }
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_ImpossibleContermaneuver() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/ImpossibleContermaneuver.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(1);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(0);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println(rejected);
        assertFalse(accepted);
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        assertEquals(0,resFunc.getAllManeuversSat1().size());
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_AcqLeft_differentInitialLookside() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/ImpossibleContermaneuver.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("right");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(3);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(3);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println(rejected);
        assertTrue(accepted);
        
        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> alltasks : alltasksAccepted.entrySet())
        {
            System.out.println(alltasks.getValue());
        }
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        assertEquals(2, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
        
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedByCsps);
        assertEquals(0, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
        
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_AcqRight_differentInitialLookside() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/ImpossibleContermaneuver.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("left");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(3);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(3);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println(rejected);
        assertTrue(accepted);
        
        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> alltasks : alltasksAccepted.entrySet())
        {
            System.out.println(alltasks.getValue());
        }
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        assertEquals(1, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
        
        Maneuver manInitial = resFunc.getAllManeuversSat1().firstEntry().getValue();
        
        System.out.println(manInitial);
        
        assertEquals("x", manInitial.getAcq1Id());
        assertEquals(dto1.getDtoId(), manInitial.getAcq2Id());
        assertEquals(false, manInitial.isRightToLeftFlag());
        
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedByCsps);
        assertEquals(0, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
        
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_AcqLeft_sameInitialLookSide() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/ImpossibleContermaneuver.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("left");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(3);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(3);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println(rejected);
        assertTrue(accepted);
        
        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> alltasks : alltasksAccepted.entrySet())
        {
            System.out.println(alltasks.getValue());
        }
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        assertEquals(3, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
        
        Date middleManStarTTime = DroolsUtils.createDate("10/10/2017 17:43:20");
        Maneuver manInitial = resFunc.getAllManeuversSat1().firstEntry().getValue();
        Maneuver middleMan = resFunc.getAllManeuversSat1().get(middleManStarTTime.getTime());
        Maneuver manFinal = resFunc.getAllManeuversSat1().lastEntry().getValue();
        
        System.out.println(manInitial);
        System.out.println(middleMan);
        System.out.println(manFinal);
        
        assertEquals("mhStart", manInitial.getAcq1Id());
        assertEquals(dto1.getDtoId(), manInitial.getAcq2Id());
        assertEquals(false, manInitial.isRightToLeftFlag());
        
        assertEquals("x", middleMan.getAcq1Id());
        assertEquals(dto1.getDtoId(), middleMan.getAcq2Id());
        assertEquals(true, middleMan.isRightToLeftFlag());
        
        assertEquals(dto1.getDtoId(), manFinal.getAcq1Id());
        assertEquals("x", manFinal.getAcq2Id());
        assertEquals(false, manFinal.isRightToLeftFlag());
        
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedByCsps);
        assertEquals(0, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_AcqLeft_noTimeTillEndOfMh() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/ImpossibleContermaneuver.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("left");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(3);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(3);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:20", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println(rejected);
        assertTrue(accepted);
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        DroolsOperations.retractSingleAcq(droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedByCsps);
        assertEquals(0, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_AcqLeft_differentInitialLookSide() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/ImpossibleContermaneuver.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("right");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(3);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(3);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println(rejected);
        assertTrue(accepted);
        
        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> alltasks : alltasksAccepted.entrySet())
        {
            System.out.println(alltasks.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        assertEquals(2, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
        
        // Date middleManStarTTime = DroolsUtils.createDate("10/10/2017
        // 17:43:20");
        Maneuver manInitial = resFunc.getAllManeuversSat1().firstEntry().getValue();
        Maneuver manFinal = resFunc.getAllManeuversSat1().lastEntry().getValue();
        
        System.out.println(manInitial);
        System.out.println(manFinal);
        
        assertEquals("x", manInitial.getAcq1Id());
        assertEquals(dto1.getDtoId(), manInitial.getAcq2Id());
        assertEquals(true, manInitial.isRightToLeftFlag());
        
        assertEquals(dto1.getDtoId(), manFinal.getAcq1Id());
        assertEquals("x", manFinal.getAcq2Id());
        assertEquals(false, manFinal.isRightToLeftFlag());
        
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedByCsps);
        assertEquals(0, resFunc.getAllManeuversSat1().size());
        assertEquals(0, resFunc.getAllManeuversSat2().size());
    }
    
    @Test
    public void test_axisReconfig_thereIsPrevMan_enough_time() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);
        
        resourceFunctions.getManeuverFunctionAssociatedToSat("SAT_1").put(man1.getStartTime().getTime(), man1);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        resourceFunctions.getManeuverFunctionAssociatedToSat("SAT_1").put(man2.getStartTime().getTime(), man2);
        
        axisReconfig(man1);
        TreeMap<Long, CMGAxis> cmgAxisReconf = resourceFunctions.getAllCmgAxisRecSat1();
        System.out.println("cmga axis reconf : " + cmgAxisReconf);
        assertFalse(cmgAxisReconf.isEmpty());
        
    }
    
    // TODO : decommentare metodo test_axisReconfig_thereIsPrevMan_no_time (dto2
    // deve tornare a left)
    // TODO : decommentare metodo test_Maneuver_Rw (dto3 deve tornare a left e
    // decommentare dto6)
    
    public void removeMan(Maneuver man, ResourceFunctions resourceFunctions, KieSession kie)
    {
        String satelliteId = man.getSatelliteId();
        TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(satelliteId);
        
        RemoveTasksManagement removeTasks = new RemoveTasksManagement();
        
        // initialize the variable used to understand if the aq rejection is
        // caused by csps to false
        boolean deletedByCsps = false;
        
        List<Maneuver> allInvolvedMan = new ArrayList<>();
        allInvolvedMan.add(man);
        
        allMan.remove(man.getStartTime().getTime());
        
        FactHandle factMan = kie.getFactHandle(man);
        if (factMan != null)
        {
            removeTasks.removeManeuver(satelliteId, allInvolvedMan, this.droolsParams, resourceFunctions, this.sessionId, this.currentKieSession, deletedByCsps,
                    false, null);
        }
        
        QueryResults resultsMan = kie.getQueryResults("getObjectsOfManeuver", man.getSatelliteId());
        if (resultsMan.size() > 0)
        {
            allMan.clear();
            for (QueryResultsRow rowMan : resultsMan)
            {
                Maneuver manExtracted = (Maneuver) rowMan.get("$allMan");
                allMan.put(manExtracted.getStartTime().getTime(), manExtracted);
            }
        }
        
    }
    
    public void removeMan1(Maneuver man, ResourceFunctions resourceFunctions, KieSession kie)
    {
        String satelliteId = man.getSatelliteId();
        TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(satelliteId);
        
        RemoveTasksManagement removeTasks = new RemoveTasksManagement();
        
        // initialize the variable used to understand if the aq rejection is
        // caused by csps to false
        boolean deletedByCsps = false;
        
        List<Maneuver> allInvolvedMan = new ArrayList<>();
        allInvolvedMan.add(man);
        
        if (allMan.get(man.getStartTime().getTime()) != null)
        {
            Maneuver extractedMan = allMan.get(man.getStartTime().getTime());
            if ((extractedMan.getIdTask() == man.getIdTask()) && extractedMan.getActuator().equals(man.getActuator()))
            {
                removeTasks.removeManeuver(satelliteId, allInvolvedMan, this.droolsParams, resourceFunctions, this.sessionId, this.currentKieSession,
                        deletedByCsps, false, null);
            }
            
        }
        else
        {
            QueryResults resultsMan = kie.getQueryResults("getManeuverWithId", man.getIdTask());
            if (resultsMan.size() > 0)
            {
                removeTasks.removeManeuver(satelliteId, allInvolvedMan, this.droolsParams, resourceFunctions, this.sessionId, this.currentKieSession,
                        deletedByCsps, false, null);
            }
        }
        
        QueryResults resultsMan = kie.getQueryResults("getObjectsOfManeuver", man.getSatelliteId());
        if (resultsMan.size() > 0)
        {
            allMan.clear();
            for (QueryResultsRow rowMan : resultsMan)
            {
                Maneuver manExtracted = (Maneuver) rowMan.get("$allMan");
                allMan.put(manExtracted.getStartTime().getTime(), manExtracted);
            }
        }
        
    }
    
    @Test
    public void removeManList() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_axisReconfig_thereIsPrevMan_no_time");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:50:00", "10/10/2017 14:52:00", "right", "SAT_1");
        double imageBicDto2 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        TreeMap<Long, Maneuver> allManSat1 = resourceFunctions.getAllManeuversSat1();
        Maneuver manToRemove = allManSat1.firstEntry().getValue();
        Maneuver manToRemove2 = allManSat1.lastEntry().getValue();
        
        assertEquals(2, allManSat1.size());
        System.out.println("MAN 1 " + manToRemove);
        System.out.println("MAN 2 " + manToRemove2);
        
        List<Maneuver> allInvolvedMan = new ArrayList<>();
        allInvolvedMan.add(manToRemove);
        allInvolvedMan.add(manToRemove2);
        
        RemoveTasksManagement removeTasks = new RemoveTasksManagement();
        removeTasks.removeManeuver(manToRemove.getSatelliteId(), allInvolvedMan, this.droolsParams, resourceFunctions, this.sessionId, this.currentKieSession,
                false, false, null);
        
        allManSat1 = resourceFunctions.getAllManeuversSat1();
        assertEquals(0, allManSat1.size());
        
    }
    
    @Test
    public void removeMan() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_axisReconfig_thereIsPrevMan_no_time");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:50:00", "10/10/2017 14:52:00", "right", "SAT_1");
        double imageBicDto2 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        TreeMap<Long, Maneuver> allManSat1 = resourceFunctions.getAllManeuversSat1();
        Maneuver manToRemove = allManSat1.firstEntry().getValue();
        
        removeMan1(manToRemove, resourceFunctions, kie);
        
    }
    
    @Test
    public void removeManNotInList() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_axisReconfig_thereIsPrevMan_no_time");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:50:00", "10/10/2017 14:52:00", "right", "SAT_1");
        double imageBicDto2 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        TreeMap<Long, Maneuver> allManSat1 = resourceFunctions.getAllManeuversSat1();
        Maneuver manToRemove = allManSat1.firstEntry().getValue();
        
        allManSat1.remove(manToRemove.getStartTime().getTime());
        removeMan1(manToRemove, resourceFunctions, kie);
    }
    
    @Test
    public void test_axisReconfig_thereIsPrevMan_no_time() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_axisReconfig_thereIsPrevMan_no_time");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:50:00", "10/10/2017 14:52:00", "right", "SAT_1");
        double imageBicDto2 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);
        man1.setAcq1Id(dto1.getDtoId());
        man1.setAcq2Id(dto2.getDtoId());
        
        resourceFunctions.getManeuverFunctionAssociatedToSat("SAT_1").put(man1.getStartTime().getTime(), man1);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:47:00", "10/10/2017 12:49:55", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        resourceFunctions.getManeuverFunctionAssociatedToSat("SAT_1").put(man2.getStartTime().getTime(), man2);
        
        axisReconfig(man1);
        TreeMap<Long, CMGAxis> cmgAxisReconf = resourceFunctions.getAllCmgAxisRecSat1();
        System.out.println("cmga axis reconf : " + cmgAxisReconf);
        assertTrue(cmgAxisReconf.isEmpty());
        
        System.out.println("all MAn : " + resourceFunctions.getManeuverFunctionAssociatedToSat("SAT_1"));
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + rejected);
    }
    
    @Test
    public void test_cannotPerformSatLeftAcq() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : cannotPerformSatLeftAcq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Satellite sat = this.droolsParams.getSatWithId("1");
        sat.setLeftLookingAvailable(false);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:50:00", "10/10/2017 13:52:00", "left", sat.getSatelliteId());
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition rejectedAcqDto = rejected.get(dto1.getDtoId());
        
        ReasonOfReject expectedReason = ReasonOfReject.cannotPerformSatLeftAcq;
        ReasonOfRejectElement reasonContained = rejectedAcqDto.findReasonOfReject(expectedReason);
        assertTrue(reasonContained != null);
    }
    
    @Test
    public void test_Maneuver_Reached_Limit_RW_Left_Looking_() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        
        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;
        
        String satUnderTest = "SAT_1";
        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:50:00", "10/10/2017 13:52:00", "left", satUnderTest);
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition rejectedAcqDto = rejected.get(dto1.getDtoId());
        
        ReasonOfReject expectedReason = ReasonOfReject.maxNumberOfRWManeuverReached;
        ReasonOfRejectElement reasonContained = rejectedAcqDto.findReasonOfReject(expectedReason);
        assertTrue(reasonContained != null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_Prev_curr() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 16:50:00", "10/10/2017 16:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:56:30", "10/10/2017 17:56:50", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_train_cmga_remove_last_one() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_first_one");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 16:50:00", "10/10/2017 16:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:58:30", "10/10/2017 16:58:45", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
    }
    
    @Test
    public void test_Maneuver_CMGA_createRamp() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_first_one");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 16:50:00", "10/10/2017 16:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:30", "10/10/2017 16:57:45", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSat = resFunc.getManeuverFunctionAssociatedToSat(dto2.getSatelliteId());
        assertEquals(2, allManForSat.size());
        Maneuver R2L = allManForSat.firstEntry().getValue();
        Maneuver L2R = allManForSat.lastEntry().getValue();
        
        assertEquals(true, R2L.isRightToLeftFlag());
        assertEquals(Actuator.ReactionWheels, R2L.getActuator());
        
        assertEquals(false, L2R.isRightToLeftFlag());
        assertEquals(Actuator.CMGA, L2R.getActuator());
        
        TreeMap<Long, RampCMGA> allRampsForSat = resFunc.getRampFunctionAssociatedToSat(dto2.getSatelliteId());
        assertEquals(2, allRampsForSat.size());
        
    }
    
    @Test
    public void test_Maneuver_CMGA_train_cmga_remove_First() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_middle_one");
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsParams.getAllEclipses().clear();
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:50:00", "10/10/2017 12:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 12:57:30", "10/10/2017 12:58:45", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto3 = 2;
        
        DTO dto5 = this.du.createSingleDto("10/10/2017 13:13:50", "10/10/2017 13:14:45", "right", "SAT_1");
        dto5.setPrType(PRType.HP);
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto5.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto4 = this.du.createSingleDto("10/10/2017 13:07:55", "10/10/2017 13:08:45", "left", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto4.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 13:06:50", "10/10/2017 13:07:45", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_train_cmga_remove_middle_one() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_middle_one");
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsParams.getAllEclipses().clear();
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:50:00", "10/10/2017 12:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 12:57:30", "10/10/2017 12:58:45", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto3 = 2;
        
        DTO dto5 = this.du.createSingleDto("10/10/2017 13:13:50", "10/10/2017 13:14:45", "right", "SAT_1");
        dto5.setPrType(PRType.HP);
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto5.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto4 = this.du.createSingleDto("10/10/2017 13:07:50", "10/10/2017 13:08:45", "left", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto4.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 13:03:50", "10/10/2017 13:04:45", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_train_cmga_remove_single_case() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_single_case");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 16:50:00", "10/10/2017 16:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:58:30", "10/10/2017 16:58:45", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_train_cmga_remove_first_one() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_first_one");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 16:50:00", "10/10/2017 16:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:58:30", "10/10/2017 16:58:45", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_conterman() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_train_cmga_remove_first_one");
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 06:50:00", "10/10/2017 06:52:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println( resFunc.getAllManeuversSat1());
        
        assertEquals(2, resFunc.getAllManeuversSat1().size());
        // Date middleManStarTTime = DroolsUtils.createDate("10/10/2017
        // 17:43:20");
        Maneuver manInitial = resFunc.getAllManeuversSat1().firstEntry().getValue();
        Maneuver manFinal = resFunc.getAllManeuversSat1().lastEntry().getValue();
        
        System.out.println(manInitial);
        System.out.println(manFinal);
        
        assertEquals("x", manInitial.getAcq1Id());
        assertEquals(dto1.getDtoId(), manInitial.getAcq2Id());
        assertEquals(true, manInitial.isRightToLeftFlag());
        
        assertEquals(dto1.getDtoId(), manFinal.getAcq1Id());
        assertEquals("x", manFinal.getAcq2Id());
        assertEquals(false, manFinal.isRightToLeftFlag());
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:58:30", "10/10/2017 16:58:45", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        // droolsInstance.retractSingleAcq(dto1.getDtoId(), currentKieSession);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected :" + rejected);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_RW_conterman() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman");
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(true);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 06:50:00", "10/10/2017 06:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:59:30", "10/10/2017 17:00:45", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        // droolsInstance.retractSingleAcq(dto1.getDtoId(), currentKieSession);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        System.out.println("REJECTED : " + this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("res Func all man : " + resFunc.getAllManeuversSat1());
        System.out.println("res Func all ramps : " + resFunc.getAllRampsSat1());
    }
    
    @Test
    public void test_Maneuver_CMGA_curr_next() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        double imageBicDto2 = 9;
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:56:30", "10/10/2017 17:56:50", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks);
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        // droolsInstance.retractSingleAcq(dto2.getDtoId(), currentKieSession);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
    }
    
    @Test
    public void test_Maneuver_CMGA_LR() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getAllVisibilities().clear();
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:56:30", "10/10/2017 17:56:50", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        assertEquals(2, resFunc.getAllManeuversSat1().size());
        Maneuver man1 = resFunc.getAllManeuversSat1().firstEntry().getValue();
        Maneuver man2 = resFunc.getAllManeuversSat1().lastEntry().getValue();
        
        Date startTimeFirstMan = DroolsUtils.createDate("10/10/2017 17:43:20");
        Date startTimeLastMan = DroolsUtils.createDate("10/10/2017 17:52:00");
        
        assertEquals(startTimeFirstMan, man1.getStartTime());
        assertEquals("x", man1.getAcq1Id());
        assertEquals(dto1.getDtoId(), man1.getAcq2Id());
        assertEquals(true, man1.isRightToLeftFlag());
        assertEquals(Actuator.ReactionWheels, man1.getActuator());
        
        assertEquals(startTimeLastMan, man2.getStartTime());
        assertEquals(dto1.getDtoId(), man2.getAcq1Id());
        assertEquals(dto2.getDtoId(), man2.getAcq2Id());
        assertEquals(false, man2.isRightToLeftFlag());
        assertEquals(Actuator.CMGA, man2.getActuator());
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        assertEquals(2, allManInDrools.size());
        
        List<RampCMGA> allramps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        assertEquals(2, allramps.size());
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        assertEquals(0, allManInDrools.size());
        
        allramps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        assertEquals(0, allramps.size());
    }
    
    @Test
    public void test_Maneuver_CMGA_RL() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getAllVisibilities().clear();
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:56:30", "10/10/2017 17:56:50", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        List<RampCMGA> allramps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allramps.size(); i++)
        {
            System.out.println("RETURNED RAMP DROOLS:" + allramps.get(i));
        }
        
        // this.droolsInstance.retractSingleAcq(this.droolsParams,
        // dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        allramps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allramps.size(); i++)
        {
            System.out.println("RETURNED RAMP DROOLS:" + allramps.get(i));
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_InvalidFormula() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_CMGA_InvalidFormula");
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setStartWithRw(false);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        double imageBicDto2 = 9;
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:56:30", "10/10/2017 17:56:50", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:51:00", "10/10/2017 17:51:20", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 17:50:30", "10/10/2017 17:50:50", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(3);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto4 = this.du.createSingleDto("10/10/2017 17:45:30", "10/10/2017 17:45:50", "right", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto4.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto5 = this.du.createSingleDto("10/10/2017 16:40:30", "10/10/2017 16:40:50", "right", "SAT_1");
        dto5.setPrType(PRType.HP);
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto5.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto6 = this.du.createSingleDto("10/10/2017 16:41:30", "10/10/2017 16:41:50", "right", "SAT_1");
        dto6.setPrType(PRType.HP);
        dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto6.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto6.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks);
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        // droolsInstance.retractSingleAcq(dto2.getDtoId(), currentKieSession);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
    }
    
    @Test
    public void test_Maneuver_Rw_RL() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:50:00", "10/10/2017 15:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:56:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        List<RampCMGA> allRamps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        System.out.println("all ramp  : " + allRamps);
        
        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        allRamps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        
        Date expectedStartTime = DroolsUtils.createDate("10/10/2017 17:44:00");
        Date expectedEndTime = DroolsUtils.createDate("10/10/2017 17:50:00");
        
        assertEquals(2, allManRes.size());
        Maneuver returnedMan = allManRes.firstEntry().getValue();
        assertEquals(Actuator.ReactionWheels, allManRes.get(returnedMan.getStartTime().getTime()).getActuator());
        assertEquals(dto1.getDtoId(), allManRes.get(returnedMan.getStartTime().getTime()).getAcq1Id());
        assertEquals(dto2.getDtoId(), allManRes.get(returnedMan.getStartTime().getTime()).getAcq2Id());
        assertEquals(expectedStartTime, allManRes.get(returnedMan.getStartTime().getTime()).getStartTime());
        assertEquals(expectedEndTime, allManRes.get(returnedMan.getStartTime().getTime()).getEndTime());
        
        // droolsInstance.retractSingleAcq(dto2.getDtoId(), currentKieSession);
        
        double imageBicDto3 = 2;
        DTO dto3 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:02:00", "left", "SAT_1");
        dto3.setPrType(PRType.PP);
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setImageBIC(imageBicDto3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        allRamps = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
    }
    
    @Test
    public void test_Maneuver_Rw_RL_impossibleForMaxNumTotMan() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        
        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 0;
        
        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:50:00", "10/10/2017 15:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        
        assertEquals(0, allManRes.size());
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test_Maneuver_Rw_RL_impossibleForMaxNumRW() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw_RL_impossibleForMaxNumRW");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        
        int maxNumRw = 0;
        int maxNumCmga = 1;
        int maxNumTotMan = 1;
        
        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        String satUnderTest = "SAT_1";
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:50:00", "10/10/2017 15:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:56:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        rejected = (Map<String, Acquisition>) droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertTrue(rejected.containsKey(dto2.getDtoId()));
        
        Acquisition acq = rejected.get(dto2.getDtoId());
        assertEquals(ReasonOfReject.maxNumberOfTotalManeuverReached, acq.getReasonOfReject().get(0).getReason());
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        
        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
        
    }
    
    @Test
    public void test_Maneuver_Rw_RL_impossibleForMaxNumCMGA() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        
        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;
        
        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        String satUnderTest = "SAT_1";
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();
        
        this.droolsParams.getSatWithId(satUnderTest).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:49:00", "10/10/2017 17:50:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertFalse(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        TreeMap<Long, EnergyAssociatedToTask> allEssRes = resFunc.getEssFunctionSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        System.out.println("all ess res : " + allEssRes);
        
        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        resFunc.getAllManeuversSat1();
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
        
    }
    
    @Test
    public void test_Maneuver_Rw_RL_no_time_for_rw_reject_current() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:50:00", "10/10/2017 15:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertFalse(accepted);
        
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition rejectedAcqDto2 = rejected.get(dto2.getDtoId());
        
        ReasonOfReject expectedReason = ReasonOfReject.noTimeForAManeuver;
        ReasonOfRejectElement reasonContained = rejectedAcqDto2.findReasonOfReject(expectedReason);
        assertTrue(reasonContained != null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        System.out.println("REJECTED : " + this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(0, allManRes.size());
    }
    
    @Test
    public void test_Maneuver_Rw_RL_no_time_for_rw_reject_prev() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 14:55:00", "10/10/2017 14:55:30", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:50:00", "10/10/2017 14:52:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition rejectedAcqDto2 = rejected.get(dto2.getDtoId());
        
        ReasonOfReject expectedReason = ReasonOfReject.noTimeForAManeuver;
        ReasonOfRejectElement reasonContained = rejectedAcqDto2.findReasonOfReject(expectedReason);
        assertTrue(reasonContained != null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
    }
    
    @Test
    public void test_Maneuver_RW_conterman_removed_for_another_acq() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LRL() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getSatelliteState().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:20:00", "10/10/2017 15:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(4, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:15:00", "10/10/2017 14:16:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_RLR_removeFirstRight() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(0, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_RLR_removeLeft() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(0, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_RLR_removeSecondRight() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(0, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LLR_removeRight() throws IOException, Exception
    {
        this.sessionId = "test_Maneuver_LLR_removeRight";
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_LLR_removeRight");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LLR_removeFirstLeft_manOverlapDlo() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LLR_removeFirstLeft() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LLR_removeSecondLeft() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LRL_removeRight() throws IOException, Exception
    {
        this.sessionId = "test_Maneuver_LRL_removeRight";
        
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        for (Map.Entry<Long, Maneuver> allMans : allManRes.entrySet())
        {
            System.out.println(allMans.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LRL_removeFirstLeft() throws IOException, Exception
    {
        this.sessionId = "test_Maneuver_LRL_removeFirstLeft";
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        for (Map.Entry<Long, Maneuver> allMans : allManRes.entrySet())
        {
            System.out.println(allMans.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_LRL_removeSecondLeft() throws IOException, Exception
    {
        this.sessionId = "test_Maneuver_LRL_removeSecondLeft";
        
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        for (Map.Entry<Long, Maneuver> allMans : allManRes.entrySet())
        {
            System.out.println(allMans.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_RRL_removeFirstRight() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_RRL_removeLeft() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_RRL_removeSecondRight() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(0, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        assertEquals(2, allManRes.size());
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapPAW);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }

    @Test
    public void test_Maneuver_LLL() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_RW_conterman_removed_for_another_acq");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(4, allManRes.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:11:00", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void test_Maneuver_ProblemsWithSov() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        Date mhStartTime = DroolsUtils.createDate("16/09/2016 18:21:00");
        Date mhStopTime = DroolsUtils.createDate("17/09/2016 06:21:00");

        MissionHorizon currentMH = new MissionHorizon();
        currentMH.setStart(mhStartTime);
        currentMH.setStop(mhStopTime);

        this.droolsParams.setCurrentMH(currentMH);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("left");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("17/09/2016 04:05:36", "17/09/2016 04:05:45", "left", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        dto1.setImageBIC(1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("17/09/2016 04:50:03", "17/09/2016 04:50:20", "right", "SAT_2");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto2.setImageBIC(1);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        
        DTO dto3 = this.du.createSingleDto("17/09/2016 04:02:05", "17/09/2016 04:02:23", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto3.setImageBIC(1);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto4 = this.du.createSingleDto("17/09/2016 04:04:36", "17/09/2016 04:04:44", "left", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto4.setImageBIC(1);
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted); 
        
        
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
        
        droolsInstance.writeToFile(this.sessionId, this.currentKieSession, droolsParams);
    }
    
    
    
    @Test
    public void test_Maneuver_Rw_RL_no_time_for_rw_create_conterman_cmga() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:05:00", "10/10/2017 14:07:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
    }
    
    
    @Test
    public void test_Maneuver_Rw_RL_impossible_for_overlapVis() throws IOException, Exception
    {
        StubResources stub = new StubResources();
        
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        Visibility visInoverlapWithCreatedman1 = stub.createVisibility(221, "SAT_1", "KIR", null, "10/10/2017 15:40:00", "10/10/2017 15:55:00");
        Visibility visInoverlapWithCreatedman2 = stub.createVisibility(222, "SAT_1", "KIR", null, "10/10/2017 15:59:00", "10/10/2017 16:20:00");
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().add(visInoverlapWithCreatedman1);
        this.droolsParams.getAllVisibilities().add(visInoverlapWithCreatedman2);
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:50:00", "10/10/2017 15:52:00", "right", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:10:00", "10/10/2017 16:12:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition rejectedAcqDto2 = rejected.get(dto2.getDtoId());
        
        ReasonOfReject expectedReason = ReasonOfReject.maneuverOverlapDloOrPaw;
        ReasonOfRejectElement reasonContained = rejectedAcqDto2.findReasonOfReject(expectedReason);
        assertTrue(reasonContained != null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(0, allManRes.size());
    }
    
    @Test
    public void test_Maneuver_Rw_LR_impossible_for_overlapVis() throws IOException, Exception
    {
        StubResources stub = new StubResources();
        
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        Visibility visInoverlapWithCreatedman1 = stub.createVisibility(221, "SAT_1", "KIR", null, "10/10/2017 10:40:00", "10/10/2017 10:55:00");
        Visibility visInoverlapWithCreatedman2 = stub.createVisibility(222, "SAT_1", "KIR", null, "10/10/2017 10:59:00", "10/10/2017 11:20:00");
        
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().add(visInoverlapWithCreatedman1);
        this.droolsParams.getAllVisibilities().add(visInoverlapWithCreatedman2);
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 10:50:00", "10/10/2017 10:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 11:10:00", "10/10/2017 11:12:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition rejectedAcqDto2 = rejected.get(dto2.getDtoId());
        
        ReasonOfReject expectedReason = ReasonOfReject.maneuverOverlapDloOrPaw;
        ReasonOfRejectElement reasonContained = rejectedAcqDto2.findReasonOfReject(expectedReason);
        assertTrue(reasonContained != null);
        
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all ramp res : " + allRampRes);
        assertEquals(2, allManRes.size());
    }
    
    @Test
    public void test_Maneuver_CMGA_LRL() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        ResourceFunctions resFunc = (ResourceFunctions) SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession)
                .getGlobal("resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:50:00", "10/10/2017 07:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        /*
         * expected man : 2 x_dto1 dto1_x
         */
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        double imageBicDto3 = 25;
        DTO dto3 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:02:00", "left", "SAT_1");
        dto3.setPrType(PRType.PP);
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setImageBIC(imageBicDto3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
    }
    
    @Test
    public void test_Maneuver_CMGA_LRL_ninoScenario() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        ResourceFunctions resFunc = (ResourceFunctions) SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession)
                .getGlobal("resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:50:00", "10/10/2017 07:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        /*
         * expected man : 2 x_dto1 dto1_x
         */
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 07:40:00", "10/10/2017 07:41:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        double imageBicDto3 = 25;
        DTO dto3 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:02:00", "left", "SAT_1");
        dto3.setPrType(PRType.PP);
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setImageBIC(imageBicDto3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
    }
    
    // @Test
    // public void date()
    // {
    // Calendar cal = new Calendar();
    // }
    
    @Test
    public void test_Maneuver_649() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_649");
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        ResourceFunctions resFunc = (ResourceFunctions) SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession)
                .getGlobal("resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:24:41.454", "10/10/2017 07:24:46.545", "Right", "SAT_1");
        double imageBicDto1 = 2;
        dto1.setDtoId("200_639_1_5_");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        /*
         * expected man : 2 x_dto1 dto1_x
         */
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:15:03.56", "10/10/2017 14:15:12.393", "Left", "SAT_1");
        dto2.setDtoId("200_648_1_2_");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(1);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 17:01:31.591", "10/10/2017 17:01:40.416", "Left", "SAT_1");
        dto3.setDtoId("200_637_1_1_");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto4 = this.du.createSingleDto("10/10/2017 14:12:13.435", "10/10/2017 14:12:22.522", "Left", "SAT_1");
        dto4.setDtoId("200_635_1_1_");
        dto4.setPrType(PRType.HP);
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto4.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
      //  assertTrue(accepted);
        
        DTO dto5 = this.du.createSingleDto("10/10/2017 14:07:35.891", "10/10/2017 14:07:43.093", "Left", "SAT_1");
        dto5.setDtoId("200_634_1_1_");
        dto5.setPrType(PRType.HP);
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto5.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto6 = this.du.createSingleDto("10/10/2017 12:01:59.716", "10/10/2017 12:02:30.296", "Left", "SAT_1");
        dto6.setDtoId("200_630_1_2_");
        dto6.setPrType(PRType.HP);
        dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto6.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto6.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto7 = this.du.createSingleDto("10/10/2017 08:13:11", "10/10/2017 08:13:27", "Left", "SAT_1");
        dto7.setDtoId("100_3084_1_1_");
        dto7.setPrType(PRType.HP);
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto7.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto7.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto8 = this.du.createSingleDto("10/10/2017 17:00:50", "10/10/2017 17:01:00", "Right", "SAT_1");
        dto8.setDtoId("100_3080_1_1_");
        dto8.setPrType(PRType.HP);
        dto8.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto8.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto8.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        List<Task> alltasksList = new ArrayList<>();
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
            alltasksList.add(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
    }
    
    @Test
    public void test_Maneuver_AR() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_AR");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        
        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        
        ResourceFunctions resFunc = (ResourceFunctions) SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession)
                .getGlobal("resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setDtoId("100_2282_1_1_");
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        /*
         * expected man : 2 x_dto1 dto1_x
         */
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res : " + allManRes);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setDtoId("100_2188_1_1_");
        dto2.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto4 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(400);
        dto4.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto4.setPrType(PRType.HP);
        dto4.setDtoId("100_2178_1_1_");
        dto4.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto5 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(400);
        dto5.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto5.setPrType(PRType.HP);
        dto5.setDtoId("100_2179_1_1_");
        dto5.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto6 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", "SAT_1");
        imageBicDto1 = 1;
        dto6.setPol(Polarization.HH);
        dto6.setSizeH(400);
        dto6.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto6.setPrType(PRType.HP);
        dto6.setDtoId("100_2271_1_1_");
        dto6.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto7 = this.du.createSingleDto("10/10/2017 11:44:14", "10/10/2017 11:44:21", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto7.setPol(Polarization.HH);
        dto7.setSizeH(400);
        dto7.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto7.setPrType(PRType.HP);
        dto7.setDtoId("100_2180_1_3_");
        dto7.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto8 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", "SAT_1");
        imageBicDto1 = 1;
        dto8.setPol(Polarization.HH);
        dto8.setSizeH(400);
        dto8.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto8.setPrType(PRType.HP);
        dto8.setDtoId("100_2281_1_1_");
        dto8.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto9 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto9.setPol(Polarization.HH);
        dto9.setSizeH(400);
        dto9.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto9.setPrType(PRType.HP);
        dto9.setDtoId("100_2183_1_1_");
        dto9.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto10 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto10.setPol(Polarization.HH);
        dto10.setSizeH(400);
        dto10.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto10.setPrType(PRType.HP);
        dto10.setDtoId("100_2184_1_1_");
        dto10.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        
        DTO dto11 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", "SAT_1");
        imageBicDto1 = 1;
        dto11.setPol(Polarization.HH);
        dto11.setSizeH(400);
        dto11.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto11.setPrType(PRType.HP);
        dto11.setDtoId("100_2181_1_2_");
        dto11.setImageBIC(imageBicDto1);
        
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");
        
        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
        
        allManRes = resFunc.getAllManeuversSat1();
        System.out.println("all man res size : " + allManRes.size());
        System.out.println("all man res : " + allManRes);
        
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }
        
        allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_next_roll_cmga_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:50:00", "10/10/2017 13:54:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = false;
        Maneuver nextMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("next man : " + nextMan);
        assertEquals(man4, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_prev_cmga_roll_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:06:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:50:00", "10/10/2017 13:54:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = true;
        Maneuver nextMan = findPrevOrNextDifferentMan(man3, manTreemap, checkPrev);
        System.out.println("prev man : " + nextMan);
        assertEquals(man1, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_next_cmga_roll_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:06:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:50:00", "10/10/2017 13:54:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = false;
        Maneuver nextMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("prev man : " + nextMan);
        assertEquals(man4, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_next_roll_cmga_not_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        
        boolean checkPrev = false;
        Maneuver nextMan = findPrevOrNextDifferentMan(man3, manTreemap, checkPrev);
        System.out.println("next man : " + nextMan);
        assertEquals(null, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_next_pitch_cmga_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.PitchCPS);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = false;
        Maneuver nextMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("returned man :" + nextMan);
        assertEquals(man4, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_prev_pitch_cmga_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.CMGA);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = true;
        Maneuver nextMan = findPrevOrNextDifferentMan(man4, manTreemap, checkPrev);
        System.out.println("returned man :" + nextMan);
        assertEquals(man1, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_prev_pitch_cmga_not_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 10:56:00", "10/10/2017 11:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = true;
        Maneuver prevMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("returned man :" + prevMan);
        assertEquals(man1, prevMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_pre_not_exists_prev() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = true;
        Maneuver nextMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("returned man :" + nextMan);
        assertEquals(null, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_prev_pitch_cmgafound() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.PitchCPS);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = false;
        Maneuver nextMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("returned man :" + nextMan);
        assertEquals(man4, nextMan);
    }
    
    @Test
    public void testFindPrevOrNextCmga_check_next_pitch_cmga_not_found() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);
        
        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);
        
        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.RollSlew);
        
        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.ReactionWheels);
        man4.setType(ManeuverType.RollSlew);
        
        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        
        boolean checkPrev = false;
        Maneuver nextMan = findPrevOrNextDifferentMan(man2, manTreemap, checkPrev);
        System.out.println("returned man :" + nextMan);
        assertEquals(null, nextMan);
    }
    
    @Test
    public void testCheckIfManIsAvailableRW_fail_on_3_orb() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = new ResourceFunctions();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);
        DroolsParameters droolsParams = new DroolsParameters();
        Actuator checkToPerform = Actuator.ReactionWheels;
        ReasonOfReject reason = ReasonOfReject.maxNumberOfRWManeuverReached;
        int minutesForOrbit = 97;
        droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 1;
        int maxNumCmga = 2;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        Acquisition current = this.du.createParametricAcquisition("current", "17/01/2018 13:10:03", "17/01/2018 13:12:00", "left", "SAT_1");
        allAcq.put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "17/01/2018 15:10:03", "17/01/2018 15:12:00", "right", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "17/01/2018 13:04:00", "17/01/2018 13:10:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);
        Maneuver manL2R = this.du.createManeuver("manL2R", "current", "next", "17/01/2018 15:44:00", "17/01/2018 15:50:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manL2R.getStartTime().getTime(), manL2R);
        DroolsParameters.setLastAcq(current);
        List<String> elementInRejectMan = new ArrayList<>();
        boolean accepted = this.manMng.checkIfManIsAvailable(manRw, current, this.droolsParams, resFunc, checkToPerform, reason);
        System.out.println("acq :" + current.getReasonOfReject());

        assertEquals(current.getReasonOfReject().get(0).getReason(), reason);
        assertTrue(elementInRejectMan.isEmpty());
        assertFalse(accepted);
    }

    @Test
    public void B_testCheckIfManIsAvailable_RW_not_available_for_total_man() throws Exception
    {
        DroolsParameters.setLogger(LoggerFactory.getLogger(DroolsOperations.class));
        this.droolsParams.setMinutesForOrbit(97);
        // cancel all the check on orbit from droolsParams
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        boolean startWithRw = true;

        ResourceFunctions resourceFunc = new ResourceFunctions();
        TreeMap<Long, Maneuver> allMan = resourceFunc.getAllManeuversSat1();

        // prepare the environment with all these values for test
        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long timeForRwForTest = 240;
        long maxSilentForTest = 3000;
        double maxThresholdForTest = 2000;
        int maxManForTest = 0;
        int maxManRWForTest = 1;
        int maxManCMGAForTest = 5;
        double minTimeEclipse = 700;
        double minutesForOrbit = 97;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);

        // add the values to the check to perform
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(startWithRw);

        Date date = DroolsUtils.createDate("10/10/2017 06:42:00");
        Date end = DroolsUtils.createDate("10/10/2017 06:49:00");
        DateResource dateRes = new DateResource();
        dateRes.setStart(date);
        dateRes.setStop(end);
        dateRes.setEnd(false);
        // create a man like in the test above
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "right", "SAT_1");
        Maneuver createdMan = this.manMng.tryToPlanRwMan(dateRes, prev, curr, timeForRwForTest, this.droolsParams);
        allMan.put(createdMan.getStartTime().getTime(), createdMan);

        DroolsParameters.setLastAcq(curr);

        List<String> elementsInvolvedOnReject = new ArrayList<>();
        boolean possible = this.manMng.checkIfManIsAvailable(createdMan, curr, this.droolsParams, resourceFunc, Actuator.total, ReasonOfReject.maxNumberOfTotalManeuverReached);

        System.out.println("acq :" + curr.getReasonOfReject());
        System.out.println("acq :" + prev.getReasonOfReject());
        assertEquals(curr.getReasonOfReject().get(0).getReason(), ReasonOfReject.maxNumberOfTotalManeuverReached);
        assertEquals(true, elementsInvolvedOnReject.isEmpty());
        assertFalse(possible);
    }

    @Test
    public void B_testCheckIfManIsAvailable_RW_not_available_for_rw_man() throws Exception
    {
        DroolsParameters.setLogger(LoggerFactory.getLogger(DroolsOperations.class));
        this.droolsParams.setMinutesForOrbit(97);
        // cancel all the check on orbit from droolsParams
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        boolean startWithRw = true;

        ResourceFunctions resourceFunc = new ResourceFunctions();
        TreeMap<Long, Maneuver> allMan = resourceFunc.getAllManeuversSat1();

        // prepare the environment with all these values for test
        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long timeForRwForTest = 240;
        long maxSilentForTest = 3000;
        double maxThresholdForTest = 2000;
        int maxManForTest = 6;
        int maxManRWForTest = 0;
        int maxManCMGAForTest = 5;
        double minTimeEclipse = 700;
        double minutesForOrbit = 97;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);

        // add the values to the check to perform
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(startWithRw);

        Date date = DroolsUtils.createDate("10/10/2017 06:42:00");
        Date end = DroolsUtils.createDate("10/10/2017 06:49:00");
        DateResource dateRes = new DateResource();
        dateRes.setStart(date);
        dateRes.setStop(end);
        dateRes.setEnd(false);
        // create a man like in the test above
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "right", "SAT_1");
        Maneuver createdMan = this.manMng.tryToPlanRwMan(dateRes, prev, curr, timeForRwForTest, this.droolsParams);
        allMan.put(createdMan.getStartTime().getTime(), createdMan);

        DroolsParameters.setLastAcq(curr);

        List<String> elementsInvolvedOnReject = new ArrayList<>();
        boolean possible = this.manMng.checkIfManIsAvailable(createdMan, curr, this.droolsParams, resourceFunc, Actuator.ReactionWheels, ReasonOfReject.maxNumberOfRWManeuverReached);

        System.out.println("acq :" + curr.getReasonOfReject());
        System.out.println("acq :" + prev.getReasonOfReject());
        assertTrue(curr.getReasonOfReject().get(0).getReason().compareTo(ReasonOfReject.maxNumberOfRWManeuverReached) == 0);
        assertEquals(true, elementsInvolvedOnReject.isEmpty());
        assertFalse(possible);
    }

    @Test
    public void C_testCheckIfManIsAvailable_CMGA_not_available_for_cmga_barrel() throws Exception
    {
        DroolsParameters.setLogger(LoggerFactory.getLogger(DroolsOperations.class));
        this.droolsParams.setMinutesForOrbit(97);
        // cancel all the check on orbit from droolsParams
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        boolean startWithRw = true;

        ResourceFunctions resourceFunc = new ResourceFunctions();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunc.getEssFunctionSat1();
        TreeMap<Long, Maneuver> allMan = resourceFunc.getAllManeuversSat1();

        // prepare the environment with all these values for test
        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 3000;
        double maxThresholdForTest = 2000;
        int maxManForTest = 6;
        int maxManRWForTest = 1;
        int maxManCMGAForTest = 1;
        double minTimeEclipse = 700;
        double minutesForOrbit = 97;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);

        // add the values to the check to perform
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(startWithRw);

        // create a man like in the test above
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "right", "SAT_1");

        allAcq.put(prev.getStartTime().getTime(), new EnergyAssociatedToTask(prev, prev.getEss()));
        allAcq.put(curr.getStartTime().getTime(), new EnergyAssociatedToTask(curr, curr.getEss()));

        Maneuver createdMan = this.du.createManeuver("manL2R", "Dto1", "Dto2", "10/10/2017 06:42:00", "10/10/2017 06:46:00", "SAT_1", Actuator.CMGA);

        DroolsParameters.setLastAcq(curr);
        allMan.put(createdMan.getStartTime().getTime(), createdMan);

        List<String> elementsInvolvedInRejectMan = new ArrayList<>();

        boolean possible = this.manMng.checkIfManIsAvailable(createdMan, curr, this.droolsParams, resourceFunc, Actuator.CMGA, ReasonOfReject.maxNumberOfCMGAManeuverReached);
        assertTrue(possible);

        Maneuver createdMan2 = this.du.createManeuver("manL2R", "Dto1", "Dto2", "10/10/2017 06:37:40", "10/10/2017 06:41:40", "SAT_1", Actuator.CMGA);
        allMan.put(createdMan2.getStartTime().getTime(), createdMan2);

        System.out.println("acq :" + curr.getReasonOfReject());

        possible = this.manMng.checkIfManIsAvailable(createdMan2, curr, this.droolsParams, resourceFunc, Actuator.CMGA, ReasonOfReject.maxNumberOfCMGAManeuverReached);
        assertFalse(possible);
        System.out.println("elementsInvolvedInRejectMan " + elementsInvolvedInRejectMan);
        assertFalse(curr.getReasonOfReject().get(0).getElementsInvolved().get(1.0).get(1).getElementsInvolved().isEmpty());

        assertTrue(curr.getReasonOfReject().get(0).getReason().compareTo(ReasonOfReject.maxNumberOfCMGAManeuverReached) == 0);
    }

    @Test
    public void testCheckIfManIsAvailable_no_check_planned() throws Exception
    {
        // cancel all the check on orbit from droolsParams
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        boolean startWithRw = true;

        ResourceFunctions resourceFunc = new ResourceFunctions();
        TreeMap<Long, Maneuver> allMan = resourceFunc.getAllManeuversSat1();

        // prepare the environment with all these values for test
        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 3000;
        double maxThresholdForTest = 2000;
        int maxManForTest = -1;
        int maxManRWForTest = -1;
        int maxManCMGAForTest = -1;
        double minTimeEclipse = 700;
        double minutesForOrbit = 97;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);

        // add the values to the check to perform
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(startWithRw);
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "right", "SAT_1");

        Maneuver createdMan = this.du.createManeuver("manL2R", "Dto1", "Dto2", "10/10/2017 06:42:00", "10/10/2017 06:46:00", "SAT_1", Actuator.CMGA);

        allMan.put(createdMan.getStartTime().getTime(), createdMan);
        List<String> elementsInvolvedInRejectMan = new ArrayList<>();
        boolean possible = this.manMng.checkIfManIsAvailable(createdMan, curr, this.droolsParams, resourceFunc, Actuator.CMGA, ReasonOfReject.maxNumberOfCMGAManeuverReached);

        assertEquals(true, elementsInvolvedInRejectMan.isEmpty());
        assertTrue(possible);
    }

    @Test
    public void testCalculateLocalMaxManeuver_CMGA() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        int receivedNumberOfCMGA = 0;
        String satelliteId = "SAT_1";
        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();

        MissionHorizon mh = this.stub.createMH("17/01/2018 11:08:00", "17/01/2018 14:05:00");

        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:06:00", "17/01/2018 11:10:00", satelliteId, Actuator.CMGA);
        Maneuver secondMan = this.du.createManeuver("man2", "acq1", "acq2", "17/01/2018 13:15:00", "17/01/2018 13:19:00", satelliteId, Actuator.CMGA);
        Maneuver thirdMan = this.du.createManeuver("man3", "acq2", "acq3", "17/01/2018 13:23:00", "17/01/2018 13:29:00", satelliteId, Actuator.ReactionWheels);
        Maneuver fourthMan = this.du.createManeuver("man4", "acq3", "acq4", "17/01/2018 13:41:00", "17/01/2018 13:44:00", satelliteId, Actuator.CMGA);

        allManRelatedToSat.put(firstMan.getStartTime().getTime(), firstMan);
        allManRelatedToSat.put(secondMan.getStartTime().getTime(), secondMan);
        allManRelatedToSat.put(thirdMan.getStartTime().getTime(), thirdMan);
        allManRelatedToSat.put(fourthMan.getStartTime().getTime(), fourthMan);

        receivedNumberOfCMGA = this.manMng.calculateLocalMaxManeuver(mh.getStart().getTime(), mh.getStop().getTime(), allManRelatedToSat, DroolsParameters.getLogger(), Actuator.CMGA);
        assertEquals(3, receivedNumberOfCMGA);
    }

    @Test
    public void testCalculateLocalMaxManeuver_total() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        int receivedNumberTotalMan = 0;
        String satelliteId = "SAT_1";
        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();

        MissionHorizon mh = this.stub.createMH("17/01/2018 11:09:00", "17/01/2018 14:05:00");

        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:06:00", "17/01/2018 11:10:00", satelliteId, Actuator.CMGA);
        Maneuver secondMan = this.du.createManeuver("man2", "acq1", "acq2", "17/01/2018 13:15:00", "17/01/2018 13:19:00", satelliteId, Actuator.CMGA);
        Maneuver thirdMan = this.du.createManeuver("man3", "acq2", "acq3", "17/01/2018 13:23:00", "17/01/2018 13:29:00", satelliteId, Actuator.ReactionWheels);
        Maneuver fourthMan = this.du.createManeuver("man4", "acq3", "acq4", "17/01/2018 13:41:00", "17/01/2018 13:44:00", satelliteId, Actuator.CMGA);

        allManRelatedToSat.put(firstMan.getStartTime().getTime(), firstMan);
        allManRelatedToSat.put(secondMan.getStartTime().getTime(), secondMan);
        allManRelatedToSat.put(thirdMan.getStartTime().getTime(), thirdMan);
        allManRelatedToSat.put(fourthMan.getStartTime().getTime(), fourthMan);

        receivedNumberTotalMan = this.manMng.calculateLocalMaxManeuver(mh.getStart().getTime(), mh.getStop().getTime(), allManRelatedToSat, DroolsParameters.getLogger(), Actuator.total);
        assertEquals(4, receivedNumberTotalMan);
    }

    @Test
    public void testCalculateLocalMaxManeuver_rw() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        int receivedNumberOfRw = 0;
        Logger logger = DroolsParameters.getLogger();
        String satelliteId = "SAT_1";
        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();

        MissionHorizon mh = this.stub.createMH("17/01/2018 11:07:00", "17/01/2018 13:25:00");

        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:06:00", "17/01/2018 11:10:00", satelliteId, Actuator.CMGA);
        Maneuver secondMan = this.du.createManeuver("man2", "acq1", "acq2", "17/01/2018 13:15:00", "17/01/2018 13:19:00", satelliteId, Actuator.CMGA);
        Maneuver thirdMan = this.du.createManeuver("man3", "acq2", "acq3", "17/01/2018 13:23:00", "17/01/2018 13:29:00", satelliteId, Actuator.ReactionWheels);
        Maneuver fourthMan = this.du.createManeuver("man4", "acq3", "acq4", "17/01/2018 13:41:00", "17/01/2018 13:44:00", satelliteId, Actuator.CMGA);

        allManRelatedToSat.put(firstMan.getStartTime().getTime(), firstMan);
        allManRelatedToSat.put(secondMan.getStartTime().getTime(), secondMan);
        allManRelatedToSat.put(thirdMan.getStartTime().getTime(), thirdMan);
        allManRelatedToSat.put(fourthMan.getStartTime().getTime(), fourthMan);

        receivedNumberOfRw = this.manMng.calculateLocalMaxManeuver(mh.getStart().getTime(), mh.getStop().getTime(), allManRelatedToSat, logger, Actuator.ReactionWheels);
        assertEquals(1, receivedNumberOfRw);
    }

    @Test
    public void testCheckIfOverlapDLOOrPaw_prev_and_next_exists_no_overlap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:21:00", "10/10/2017 08:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        // insert these resources in Drools
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw4);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis4);

        new DateResource();

        Date tillOrFromDate = null; // this param is used only for
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:48:00", "10/10/2017 07:52:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 09:00:00", "10/10/2017 09:02:00", "right", "SAT_1");
        TreeMap<Date,Date> allperiods = this.manMng.checkIfOverlapDLOOrPaw(prev, curr, tillOrFromDate, this.droolsParams);
        System.out.println("valid spaces : " + allperiods);

    }

    @Test
    public void testCheckIfOverlapDLOOrPaw_prevOrNExtNotExists() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:21:00", "10/10/2017 08:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        // insert these resources in Drools
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw4);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis4);

        new DateResource();

        Date tillOrFromDate = DroolsUtils.createDate("10/10/2017 07:00:00"); // this
                                                                         // param
                                                                         // is
                                                                         // used
                                                                         // only
                                                                         // for
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 09:00:00", "10/10/2017 09:02:00", "right", "SAT_1");
        TreeMap<Date,Date> allperiods = this.manMng.checkIfOverlapDLOOrPaw(null, curr, tillOrFromDate, this.droolsParams);
        System.out.println("valid spaces : " + allperiods);

    }

    @Test
    public void testCheckIfOverlapDLOOrPaw_prev_and_next_exists_with_overlap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 10:21:00", "10/10/2017 10:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 06:50:00", "10/10/2017 07:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 11:10:00", "10/10/2017 11:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        // insert these resources in Drools
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw4);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis4);

        new DateResource();

        Date tillOrFromDate = null; // this param is used only for
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:48:00", "10/10/2017 07:52:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 09:00:00", "10/10/2017 09:02:00", "right", "SAT_1");
        TreeMap<Date,Date> allperiods = this.manMng.checkIfOverlapDLOOrPaw(prev, curr, tillOrFromDate, this.droolsParams);
        System.out.println("valid spaces : " + allperiods);

    }

    @Test
    public void testCheckIfOverlapDLOOrPaw_no_overlapped_resources() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:21:00", "10/10/2017 08:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        // insert these resources in Drools
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw4);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis4);


        Date tillOrFromDate = null; // this param is used only for
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:48:00", "10/10/2017 06:52:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 07:00:00", "10/10/2017 07:02:00", "right", "SAT_1");
        TreeMap<Date,Date> allperiods = this.manMng.checkIfOverlapDLOOrPaw(prev, curr, tillOrFromDate, this.droolsParams);
        System.out.println("valid spaces : " + allperiods);

    }

    @Test
    public void testCheckIfOverlapDLOOrPaw_between_acq_and_mhStart() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:21:00", "10/10/2017 08:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        // insert these resources in Drools
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw4);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis4);

        Acquisition next = null;
        Date tillOrFromDate = this.droolsParams.getCurrentMH().getStart();

        System.out.println("from date : " + tillOrFromDate);
        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:48:00", "10/10/2017 07:52:00", "left", "SAT_1");
        TreeMap<Date,Date> allperiods = this.manMng.checkIfOverlapDLOOrPaw(next, curr, tillOrFromDate, this.droolsParams);
        
        System.out.println("valid spaces : " + allperiods);

    }

    @Test
    public void testCheckIfOverlapDLOOrPaw_between_acq_and_mhStop() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:21:00", "10/10/2017 08:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        // insert these resources in Drools
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(paw4);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis1);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis2);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis3);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(vis4);

        Date tillOrFromDate = this.droolsParams.getCurrentMH().getStop();
        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:48:00", "10/10/2017 07:52:00", "left", "SAT_1");
        TreeMap<Date,Date> allperiods = this.manMng.checkIfOverlapDLOOrPaw(null, curr, tillOrFromDate, this.droolsParams);
        System.out.println("valid spaces : " + allperiods);

    }

    @Test
    public void testCreateMan_RL_RW_SOV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("09/10/2017 18:21:00.000"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("10/10/2017 06:21:00.000"));

        boolean startWithRw = true;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 03:53:19.645", "10/10/2017 03:53:27.241", "right", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 04:05:35.315", "10/10/2017 04:05:44.636", "left", "SAT_1");

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);
    }
    
    @Test
    public void testCreateMan_RL_RW() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        boolean startWithRw = true;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "left", "SAT_1");

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);
    }

    @Test
    public void testCreateMan_LR_CMGA() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        Date expectedDateOfStartMan = DroolsUtils.createDate("10/10/2017 06:42:00");
        Date expectedDateOfEndMan = DroolsUtils.createDate("10/10/2017 06:46:00");
        boolean expectedLookSideRightToLeft = false;
        Actuator expectedActuator = Actuator.CMGA;

        boolean startWithRw = false;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "right", "SAT_1");

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);

        assertEquals(true, manRes.isPossible());
        assertEquals(expectedActuator, manRes.getNewMans().get(0).getActuator());
        assertEquals(expectedLookSideRightToLeft, manRes.getNewMans().get(0).isRightToLeftFlag());
        assertEquals(expectedDateOfStartMan, manRes.getNewMans().get(0).getStartTime());
        assertEquals(expectedDateOfEndMan, manRes.getNewMans().get(0).getEndTime());

    }

    @Test
    public void testCreateMan_RL_impossibleForTime() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        boolean startWithRw = false;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:45:00", "10/10/2017 06:46:00", "left", "SAT_1");
        DroolsParameters.setLastAcq(curr);
        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);

        assertEquals(false, manRes.isPossible());
    }

    @Test
    public void testCreateMan_RL_CMGA() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        Date expectedDateOfStartMan = DroolsUtils.createDate("10/10/2017 06:44:40");
        Date expectedDateOfEndMan = DroolsUtils.createDate("10/10/2017 06:48:40");
        boolean expectedLookSideRightToLeft = true;
        Actuator expectedActuator = Actuator.CMGA;

        boolean startWithRw = false;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "left", "SAT_1");

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);

        assertEquals(true, manRes.isPossible());
        assertEquals(expectedActuator, manRes.getNewMans().get(0).getActuator());
        assertEquals(expectedLookSideRightToLeft, manRes.getNewMans().get(0).isRightToLeftFlag());
        assertEquals(expectedDateOfStartMan, manRes.getNewMans().get(0).getStartTime());
        assertEquals(expectedDateOfEndMan, manRes.getNewMans().get(0).getEndTime());

    }

    @Test
    public void testCreateMan_LR_impossible_for_time() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        boolean startWithRw = true;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:45:00", "10/10/2017 06:47:00", "right", "SAT_1");
        DroolsParameters.setLastAcq(curr);

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);
        assertEquals(false, manRes.isPossible());

        assertEquals(false, manRes.isPossible());
        assertEquals(0, manRes.getNewMans().size());
    }

    @Test
    public void testCreateMan_LR_impossible_with_rw_try_with_cmga() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        boolean startWithRw = true;
        int cont = 0;

        Date expectedDateOfStartMan = DroolsUtils.createDate("10/10/2017 06:42:00");
        Date expectedDateOfEndMan = DroolsUtils.createDate("10/10/2017 06:46:00");
        boolean expectedLookSideRightToLeft = false;
        Actuator expectedActuator = Actuator.CMGA;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:47:00", "10/10/2017 06:48:00", "right", "SAT_1");

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
        assertEquals(expectedActuator, manRes.getNewMans().get(0).getActuator());
        assertEquals(expectedLookSideRightToLeft, manRes.getNewMans().get(0).isRightToLeftFlag());
        assertEquals(expectedDateOfStartMan, manRes.getNewMans().get(0).getStartTime());
        assertEquals(expectedDateOfEndMan, manRes.getNewMans().get(0).getEndTime());
    }

    @Test
    public void testCreateContermaneuver() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 08:45:00", "10/10/2017 08:48:00", "left", "SAT_1");
        manRes = this.manMng.createContermaneuver(prev, curr, this.droolsParams, resourceFunctions, manRes);
        System.out.println("man res : " + manRes);
    }

    @Test
    public void testCreateContermaneuver_noPrev() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("left");
        Acquisition prev = null;
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 08:45:00", "10/10/2017 08:48:00", "left", "SAT_1");
        manRes = this.manMng.createContermaneuver(prev, curr, this.droolsParams, resourceFunctions, manRes);
        System.out.println("man res : " + manRes);
    }

    @Test
    public void testCreateMan_NR_CMGA() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = false;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStart().getTime();
        int cont = 0;

        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:30:00", "10/10/2017 07:31:00", "right", "SAT_1");
        DroolsParameters.setLastAcq(curr);

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, curr, manRes, this.droolsParams, resourceFunctions,true, cont);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
    }

    @Test
    public void testCreateMan_NR_impossible() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = false;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStart().getTime();
        int cont = 0;

        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:30:00", "10/10/2017 07:31:00", "right", "SAT_1");
        DroolsParameters.setLastAcq(curr);

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, curr, manRes, this.droolsParams, resourceFunctions, false,cont);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
    }

    @Test
    public void testCreateMan_NR_RW() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = false;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStart().getTime();
        int cont = 0;

        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:30:00", "10/10/2017 07:31:00", "right", "SAT_1");
        DroolsParameters.setLastAcq(curr);

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, curr, manRes, this.droolsParams, resourceFunctions,false, cont);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
    }

    @Test
    public void testCreateMan_NL_RW() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();

        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("right");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = true;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStart().getTime();
        int cont = 0;

        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:30:00", "10/10/2017 07:31:00", "left", "SAT_1");

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, curr, manRes, this.droolsParams, resourceFunctions,false, cont);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
    }

    @Test
    public void testCreateMan_NL_CMGA() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("right");

        int maxNumRw = 0;
        int maxNumCmga = 1;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = true;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStart().getTime();
        int cont = 0;

        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:30:00", "10/10/2017 07:31:00", "left", "SAT_1");
        DroolsParameters.setLastAcq(curr);

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, curr, manRes, this.droolsParams, resourceFunctions,false, cont);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
    }

    @Test
    public void testCreateMan_NL_impossible() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("right");
        int maxNumRw = 1;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = true;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStart().getTime();
        int cont = 0;

        Acquisition curr = this.du.createParametricAcquisition("Dto1", "10/10/2017 07:30:00", "10/10/2017 07:31:00", "left", "SAT_1");

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, curr, manRes, this.droolsParams, resourceFunctions,false, cont);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
    }

    @Test
    public void testCreateMan_LN_RW() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("right");
        int maxNumRw = 1;
        int maxNumCmga = 1;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = true;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStop().getTime();
        int cont = 0;

        Date expectedDateOfStartMan = DroolsUtils.createDate("10/10/2017 06:30:00");
        Date expectedDateOfEndMan = DroolsUtils.createDate("10/10/2017 06:36:00");
        boolean expectedLookSideRightToLeft = false;
        Actuator expectedActuator = Actuator.ReactionWheels;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:20:00", "10/10/2017 06:22:00", "left", "SAT_1");

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, prev, manRes, this.droolsParams, resourceFunctions, true,cont);
        System.out.println("manRes : " + manRes);

        assertEquals(true, manRes.isPossible());
        assertEquals(expectedActuator, manRes.getNewMans().get(0).getActuator());
        assertEquals(expectedLookSideRightToLeft, manRes.getNewMans().get(0).isRightToLeftFlag());
        assertEquals(expectedDateOfStartMan.getTime(), manRes.getNewMans().get(0).getStartTime().getTime());
        assertEquals(expectedDateOfEndMan.getTime(), manRes.getNewMans().get(0).getEndTime().getTime());
    }

    @Test
    public void testCreateMan_LN_impossible() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        int maxNumRw = 0;
        int maxNumCmga = 0;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = true;
        long impossibleBeforeOrAfterDate = this.droolsParams.getCurrentMH().getStop().getTime();
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:20:00", "10/10/2017 06:22:00", "left", "SAT_1");
        DroolsParameters.setLastAcq(prev);

        manRes = this.manMng.createManBetweenAcqAndInterval(startWithRw, impossibleBeforeOrAfterDate, prev, manRes, this.droolsParams, resourceFunctions, false,cont);
        System.out.println("manRes : " + manRes);

        assertEquals(false, manRes.isPossible());
        assertEquals(0, manRes.getNewMans().size());
    }

    @Test
    public void testCreateMan_LN_CMGA() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();

        int maxNumRw = 0;
        int maxNumCmga = 3;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 10:22:00", "10/10/2017 10:23:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        TreeMap<Long, Maneuver>  allMans = resourceFunctions.getManeuverFunctionAssociatedToSat("1");
        Maneuver firstManRl = allMans.ceilingEntry(droolsParams.getCurrentMH().getStart().getTime()).getValue();
        Maneuver secondManRl = allMans.floorEntry(droolsParams.getCurrentMH().getStop().getTime()).getValue();

        assertEquals(2, allMans.size());
        //        DTO dto1 = this.du.createSingleDto("10/10/2017 10:22:00", "10/10/2017 10:23:00", "left", "SAT_1");

        assertEquals(Actuator.CMGA, firstManRl.getActuator());
        assertEquals(true, firstManRl.isRightToLeftFlag());
        assertEquals( DroolsUtils.createDate("10/10/2017 10:17:40").getTime(), firstManRl.getStartTime().getTime());
        assertEquals( DroolsUtils.createDate("10/10/2017 10:21:40").getTime(), firstManRl.getEndTime().getTime());
        
        assertEquals(Actuator.CMGA, secondManRl.getActuator());
        assertEquals(false, secondManRl.isRightToLeftFlag());
        assertEquals( DroolsUtils.createDate("10/10/2017 10:23:00").getTime(), secondManRl.getStartTime().getTime());
        assertEquals( DroolsUtils.createDate("10/10/2017 10:27:00").getTime(), secondManRl.getEndTime().getTime());
    }

    @Test
    public void testCreateMan_LR_RW() throws Exception
    {
        /*
         * Visibility vis1 = createVisibility(0, "SAT_1", "KIR", null,
         * "10/10/2017 06:00:00", "10/10/2017 06:30:00");
         */
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ManeuverResources manRes = new ManeuverResources();

        int maxNumRw = 0;
        int maxNumCmga = 1;
        int maxNumTotMan = 1;

        Date expectedDateOfStartMan = DroolsUtils.createDate("10/10/2017 06:30:00");
        Date expectedDateOfEndMan = DroolsUtils.createDate("10/10/2017 06:34:00");
        boolean expectedLookSideRightToLeft = false;
        Actuator expectedActuator = Actuator.CMGA;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        boolean startWithRw = false;
        int cont = 0;

        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:20:00", "10/10/2017 06:22:00", "left", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:45:00", "10/10/2017 06:48:00", "right", "SAT_1");

        manRes = this.manMng.createManBetweenAcq(startWithRw, prev, curr, manRes, this.droolsParams, resourceFunctions, cont, false, false);
        System.out.println("manRes : " + manRes);
        assertEquals(true, manRes.isPossible());
        assertEquals(expectedActuator, manRes.getNewMans().get(0).getActuator());
        assertEquals(expectedLookSideRightToLeft, manRes.getNewMans().get(0).isRightToLeftFlag());
        assertEquals(expectedDateOfStartMan.toString(), manRes.getNewMans().get(0).getStartTime().toString());
        assertEquals(expectedDateOfEndMan.toString(), manRes.getNewMans().get(0).getEndTime().toString());
    }

    @Test
    public void testProcessOverlappedVis_start_With_RW() throws Exception
    {
        TreeMap<Date, Date> returnedEmptySpaces = new TreeMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(false);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:21:00", "10/10/2017 08:26:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Date from = DroolsUtils.createDate("10/10/2017 08:00:00");
        Date to = DroolsUtils.createDate("10/10/2017 09:00:00");

        List<PlanningResources> allVisInOverlap = new ArrayList<>(Arrays.asList(paw1, paw2, paw3, vis1));

        returnedEmptySpaces = this.manMng.processOverlappedVis(from, to, allVisInOverlap, this.droolsParams);
        System.out.println("empty spaces " + returnedEmptySpaces);

        assertEquals(2,returnedEmptySpaces.size());

        //first interval from 8:15 to 8:21
        assertEquals(DroolsUtils.createDate("10/10/2017 08:15:00").getTime(),returnedEmptySpaces.firstEntry().getKey().getTime());
        assertEquals(DroolsUtils.createDate("10/10/2017 08:21:00").getTime(),returnedEmptySpaces.firstEntry().getValue().getTime());

        //last interval from 8:26 to 9:00
        assertEquals(DroolsUtils.createDate("10/10/2017 08:26:00").getTime(),returnedEmptySpaces.lastEntry().getKey().getTime());
        assertEquals(DroolsUtils.createDate("10/10/2017 09:00:00").getTime(),returnedEmptySpaces.lastEntry().getValue().getTime());

        
    }

    @Test
    public void testProcessOverlappedVis_pawStartOutside() throws Exception
    {
        TreeMap<Date, Date> returnedEmptySpaces = new TreeMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(false);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 07:50:00", "10/10/2017 08:07:00", PAWType.GENERIC);
      //  Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Date from = DroolsUtils.createDate("10/10/2017 08:00:00");
        Date to = DroolsUtils.createDate("10/10/2017 09:00:00");

        List<PlanningResources> allVisInOverlap = new ArrayList<>();
        allVisInOverlap.add(paw3);
        
        returnedEmptySpaces = this.manMng.processOverlappedVis(from, to, allVisInOverlap, this.droolsParams);
        System.out.println("empty spaces " + returnedEmptySpaces);

        assertEquals(1,returnedEmptySpaces.size());

        //first interval from 8:07 to 9:00
        assertEquals(DroolsUtils.createDate("10/10/2017 08:07:00").getTime(),returnedEmptySpaces.firstEntry().getKey().getTime());
        assertEquals(DroolsUtils.createDate("10/10/2017 09:00:00").getTime(),returnedEmptySpaces.firstEntry().getValue().getTime());

    }
    
    
    @Test
    public void testProcessOverlappedVis_pawEndOutside() throws Exception
    {
        TreeMap<Date, Date> returnedEmptySpaces = new TreeMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(false);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:50:00", "10/10/2017 09:07:00", PAWType.GENERIC);
      //  Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Date from = DroolsUtils.createDate("10/10/2017 08:00:00");
        Date to = DroolsUtils.createDate("10/10/2017 09:00:00");

        List<PlanningResources> allVisInOverlap = new ArrayList<>();
        allVisInOverlap.add(paw3);
        
        returnedEmptySpaces = this.manMng.processOverlappedVis(from, to, allVisInOverlap, this.droolsParams);
        System.out.println("empty spaces " + returnedEmptySpaces);

        
        assertEquals(1,returnedEmptySpaces.size());
        //first interval from 8:07 to 9:00
        assertEquals(DroolsUtils.createDate("10/10/2017 08:00:00").getTime(),returnedEmptySpaces.firstEntry().getKey().getTime());
        assertEquals(DroolsUtils.createDate("10/10/2017 08:50:00").getTime(),returnedEmptySpaces.firstEntry().getValue().getTime());

    }
    
    
    @Test
    public void testProcessOverlappedVis_pawTotallyIncluded() throws Exception
    {
        TreeMap<Date, Date> returnedEmptySpaces = new TreeMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(false);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:40:00", "10/10/2017 08:50:00", PAWType.GENERIC);
      //  Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Date from = DroolsUtils.createDate("10/10/2017 08:00:00");
        Date to = DroolsUtils.createDate("10/10/2017 09:00:00");

        List<PlanningResources> allVisInOverlap = new ArrayList<>();
        allVisInOverlap.add(paw3);
        
        returnedEmptySpaces = this.manMng.processOverlappedVis(from, to, allVisInOverlap, this.droolsParams);
        System.out.println("empty spaces " + returnedEmptySpaces);

        
        assertEquals(2,returnedEmptySpaces.size());
        //first interval from 8:00 to 8:40
        assertEquals(DroolsUtils.createDate("10/10/2017 08:00:00").getTime(),returnedEmptySpaces.firstEntry().getKey().getTime());
        assertEquals(DroolsUtils.createDate("10/10/2017 08:40:00").getTime(),returnedEmptySpaces.firstEntry().getValue().getTime());

        //last interval from 8:50 to 9:00
        assertEquals(DroolsUtils.createDate("10/10/2017 08:50:00").getTime(),returnedEmptySpaces.lastEntry().getKey().getTime());
        assertEquals(DroolsUtils.createDate("10/10/2017 09:00:00").getTime(),returnedEmptySpaces.lastEntry().getValue().getTime());

        
        
    }
    
    @Test
    public void testProcessOverlappedVis_periodTotallyIncludedInPaw() throws Exception
    {
        TreeMap<Date, Date> returnedEmptySpaces = new TreeMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(false);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // create paw and visibilities for test
        PAW paw3 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:40:00", "10/10/2017 08:50:00", PAWType.GENERIC);
      //  Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Date from = DroolsUtils.createDate("10/10/2017 08:41:00");
        Date to = DroolsUtils.createDate("10/10/2017 08:49:00");

        List<PlanningResources> allVisInOverlap = new ArrayList<>();
        allVisInOverlap.add(paw3);
        
        returnedEmptySpaces = this.manMng.processOverlappedVis(from, to, allVisInOverlap, this.droolsParams);
        System.out.println("empty spaces " + returnedEmptySpaces);

        
        assertEquals(0,returnedEmptySpaces.size());    
    }
    
    @Test
    public void testCheckManeuversBarrelsRW() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = new ResourceFunctions();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);
        DroolsParameters droolsParams = new DroolsParameters();
        Actuator checkToPerform = Actuator.ReactionWheels;
        ReasonOfReject reason = ReasonOfReject.maxNumberOfRWManeuverReached;
        int minutesForOrbit = 97;
        droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 1;
        int maxNumCmga = 2;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        Acquisition current = this.du.createParametricAcquisition("current", "17/01/2018 13:10:03", "17/01/2018 13:12:00", "left", "SAT_1");
        allAcq.put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "17/01/2018 15:10:03", "17/01/2018 15:12:00", "right", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "17/01/2018 13:04:00", "17/01/2018 13:10:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);
        Maneuver manL2R = this.du.createManeuver("manL2R", "current", "next", "17/01/2018 15:44:00", "17/01/2018 15:50:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manL2R.getStartTime().getTime(), manL2R);
        DroolsParameters.setLastAcq(current);
        List<String> elementInRejectMan = new ArrayList<>();

        String currentSess = DroolsParameters.concatenateSession(this.sessionId, this.currentKieSession);
        System.out.println(currentSess);
        boolean accepted = this.manMng.checkManeuversBarrels(manRw, currentSess, this.droolsParams, resFunc, checkToPerform);
        System.out.println("acq :" + current.getReasonOfReject());

        assertEquals(reason, current.getReasonOfReject().get(0).getReason());
        assertTrue(elementInRejectMan.isEmpty());
        assertFalse(accepted);

    }

    @Test
    public void testCheckManeuversBarrelsTotal() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = new ResourceFunctions();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);
        DroolsParameters droolsParams = new DroolsParameters();
        Actuator checkToPerform = Actuator.total;
        ReasonOfReject reason = ReasonOfReject.maxNumberOfTotalManeuverReached;
        int minutesForOrbit = 97;
        droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 1;
        int maxNumCmga = 2;
        int maxNumTotMan = 0;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        Acquisition current = this.du.createParametricAcquisition("current", "17/01/2018 13:10:03", "17/01/2018 13:12:00", "left", "SAT_1");
        allAcq.put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "17/01/2018 15:10:03", "17/01/2018 15:12:00", "right", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "17/01/2018 13:04:00", "17/01/2018 13:10:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);
        Maneuver manL2R = this.du.createManeuver("manL2R", "current", "next", "17/01/2018 15:44:00", "17/01/2018 15:50:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manL2R.getStartTime().getTime(), manL2R);
        DroolsParameters.setLastAcq(current);
        List<String> elementInRejectMan = new ArrayList<>();

        String currentSess = DroolsParameters.concatenateSession(this.sessionId, this.currentKieSession);
        System.out.println(currentSess);
        boolean accepted = this.manMng.checkManeuversBarrels(manRw, currentSess, this.droolsParams, resFunc, checkToPerform);
        System.out.println("acq :" + current.getReasonOfReject());

        assertEquals(reason, current.getReasonOfReject().get(0).getReason());
        assertTrue(elementInRejectMan.isEmpty());
        assertFalse(accepted);

    }

    @Test
    public void testCheckManeuversBarrelsCMGA() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = new ResourceFunctions();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);
        DroolsParameters droolsParams = new DroolsParameters();
        Actuator checkToPerform = Actuator.CMGA;
        ReasonOfReject reason = ReasonOfReject.maxNumberOfCMGAManeuverReached;
        int minutesForOrbit = 97;
        droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        Acquisition current = this.du.createParametricAcquisition("current", "17/01/2018 13:10:03", "17/01/2018 13:12:00", "left", "SAT_1");
        allAcq.put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "17/01/2018 15:10:03", "17/01/2018 15:12:00", "right", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "17/01/2018 13:04:00", "17/01/2018 13:10:00", "SAT_1", Actuator.CMGA);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);
        Maneuver manL2R = this.du.createManeuver("manL2R", "current", "next", "17/01/2018 15:44:00", "17/01/2018 15:50:00", "SAT_1", Actuator.ReactionWheels);
        allManRelatedTOSat.put(manL2R.getStartTime().getTime(), manL2R);
        DroolsParameters.setLastAcq(current);
        List<String> elementInRejectMan = new ArrayList<>();

        String currentSess = DroolsParameters.concatenateSession(this.sessionId, this.currentKieSession);
        System.out.println(currentSess);
        boolean accepted = this.manMng.checkManeuversBarrels(manRw, currentSess, this.droolsParams, resFunc, checkToPerform);
        System.out.println("acq :" + current.getReasonOfReject());

        assertEquals(reason, current.getReasonOfReject().get(0).getReason());
        assertTrue(elementInRejectMan.isEmpty());
        assertFalse(accepted);

    }

    @Test
    public void testCreateManWithNext_LR() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 6;
        int maxNumCmga = 0;
        int maxNumTotMan = 6;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03", "10/10/2017 13:12:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        
        
        Acquisition curr = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        
        
        allAcq.put(curr.getStartTime().getTime(), new EnergyAssociatedToTask(curr, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "17/01/2018 15:10:03", "17/01/2018 15:12:00", "right", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "10/10/2017 13:12:00", "10/10/2017 13:16:00", "SAT_1", Actuator.CMGA);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);

        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(manRw);
        DroolsParameters.setLastAcq(curr);

        ManeuverResources  manRes = this.manMng.createManWithNext(curr, next, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        assertTrue(manRes.isPossible());
        assertTrue(manRes.getOldMans().size()>0);
        assertEquals(1,manRes.getNewMans().size());
        assertEquals(DroolsUtils.createDate("10/10/2017 13:12:00"), manRes.getNewMans().get(0).getStartTime());
        assertEquals(Actuator.ReactionWheels, manRes.getNewMans().get(0).getActuator());

    }

    @Test
    public void testCreateManWithNext_RL() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 6;
        int maxNumCmga = 0;
        int maxNumTotMan = 6;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03", "10/10/2017 13:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        
        
        Acquisition curr = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        allAcq.put(curr.getStartTime().getTime(), new EnergyAssociatedToTask(curr, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "10/10/2017 15:10:03", "10/10/2017 15:12:00", "left", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "10/10/2017 13:12:00", "10/10/2017 13:16:00", "SAT_1", Actuator.CMGA);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);

        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(manRw);
        DroolsParameters.setLastAcq(curr);

        ManeuverResources  manRes = this.manMng.createManWithNext(curr, next, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        assertTrue(manRes.isPossible());
        assertTrue(manRes.getOldMans().size()>0);
        assertEquals(1,manRes.getNewMans().size());
        assertEquals(DroolsUtils.createDate("10/10/2017 15:03:43"), manRes.getNewMans().get(0).getStartTime());
        assertEquals(Actuator.ReactionWheels, manRes.getNewMans().get(0).getActuator());

}

    @Test
    public void testCreateManWithNext_RL_NoTime() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 6;
        int maxNumCmga = 0;
        int maxNumTotMan = 6;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03", "10/10/2017 13:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        
        
        Acquisition curr = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        allAcq.put(curr.getStartTime().getTime(), new EnergyAssociatedToTask(curr, 20));
        Acquisition next = this.du.createParametricAcquisition("next", "10/10/2017 13:14:03", "10/10/2017 13:14:40", "left", "SAT_1");
        allAcq.put(next.getStartTime().getTime(), new EnergyAssociatedToTask(next, 20));

        this.droolsParams.getSatWithId(curr.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "10/10/2017 13:12:00", "10/10/2017 13:16:00", "SAT_1", Actuator.CMGA);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);

        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(manRw);
        DroolsParameters.setLastAcq(curr);

        ManeuverResources  manRes = this.manMng.createManWithNext(curr, next, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        assertFalse(manRes.isPossible());
        assertTrue(manRes.getOldMans().size()>0);
        assertEquals(0,manRes.getNewMans().size());
        System.out.println(curr);
        assertTrue(curr.getReasonOfReject().size()>0);
    }
    
    
    @Test
    public void testCreateManWithNext_LL() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition next = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        Acquisition current = this.du.createParametricAcquisition("current", "17/01/2018 13:10:03", "17/01/2018 13:12:00", "left", "SAT_1");
        allAcq.put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        Maneuver manRw = this.du.createManeuver("man1", null, "current", "17/01/2018 13:04:00", "17/01/2018 13:10:00", "SAT_1", Actuator.CMGA);
        allManRelatedTOSat.put(manRw.getStartTime().getTime(), manRw);

        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(manRw);

        ManeuverResources manRes = this.manMng.createManWithNext(current, next, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
   
        System.out.println(manRes);
    }

    @Test
    public void testCreateManWithNext_RR() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = new TreeMap<>();

        TreeMap<Long, Maneuver> allManRelatedTOSat = new TreeMap<>();
        resFunc.setEssFunctionSat1(allAcq);
        resFunc.setAllManeuversSat1(allManRelatedTOSat);

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition next = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        Acquisition current = this.du.createParametricAcquisition("current", "17/01/2018 13:10:03", "17/01/2018 13:12:00", "right", "SAT_1");
        allAcq.put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        List<Maneuver> involvedMan = new ArrayList<>();

        this.manMng.createManWithNext(current, next, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
    }

    @Test
    public void testCreateManWithPrev_exist_prevRL() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:10:03", "10/10/2017 13:12:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        Acquisition prev = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(allManSat1.firstEntry().getValue());

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    @Test
    public void testCreateManWithPrev_exist_prevLR() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));
       
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
  
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        Acquisition prev = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(allManSat1.firstEntry().getValue());

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    @Test
    public void testCreateManWithPrev_exist_prevRR() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));
       
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
  
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        Acquisition prev = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    @Test
    public void testCreateManWithPrev_exist_prevLL_conterman() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));
       
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
  
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:00:03", "10/10/2017 15:01:00", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        Acquisition prev = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(allManSat1.firstEntry().getValue());

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    @Test
    public void testCreateManWithPrev_exist_prevLL_stayInLeft() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));
       
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
  
        DTO dto2 = this.du.createSingleDto("10/10/2017 13:15:03", "10/10/2017 13:15:30", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        Acquisition prev = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(allManSat1.firstEntry().getValue());

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    
    
    @Test
    public void testCreateManWithPrev_not_Exist_prev_L() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();
        int maxNumRw = 2;
        int maxNumCmga = 0;
        int maxNumTotMan = 2;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        checkOnSingleOrbit.put(3.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, 0, maxNumCmga, 20));
       
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "Left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
  
        DTO dto2 = this.du.createSingleDto("10/10/2017 13:15:03", "10/10/2017 13:15:30", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.HP);
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        Acquisition prev = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(allManSat1.firstEntry().getValue());

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    @Test
    public void testCreateManWithPrev_not_Exist_prev_R_initialLookSide_R() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);

        this.droolsParams.getSatWithId("1").setInitialLookSide("right");

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
  
        Acquisition prev =null;

        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }
    
    
    @Test
    public void testCreateManWithPrev_not_Exist_prev_R_initialLookSide_L() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setMinutesForOrbit(97);
        // clear all the resources of type paw and visibilities setted as
        // default
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        this.droolsParams.getSatWithId("1").setInitialLookSide("left");
        int minutesForOrbit = 97;
        this.droolsParams.setMinutesForOrbit(minutesForOrbit);
        
        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:03","10/10/2017 13:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Acquisition current = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        Acquisition prev = null;


        TreeMap<Long, Maneuver> allManSat1 = resFunc.getAllManeuversSat1();
        for(Map.Entry<Long,Maneuver> allmans : allManSat1.entrySet())
        {
            System.out.println(allmans.getValue());
        }
        List<Maneuver> involvedMan = new ArrayList<>();
        involvedMan.add(allManSat1.firstEntry().getValue());

        ManeuverResources manRes = this.manMng.createManWithPrev(prev, current, involvedMan, this.sessionId, this.currentKieSession, this.droolsParams, resFunc);
        System.out.println(manRes);
    
    }

}
