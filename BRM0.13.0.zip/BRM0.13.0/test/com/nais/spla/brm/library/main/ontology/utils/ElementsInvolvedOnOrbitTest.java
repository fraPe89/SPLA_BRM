
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class ElementsInvolvedOnOrbitTest
{

    @Test
    public void testElementsInvolvedOnOrbit() throws Exception
    {
        List<String> elementsInvolvedAsString = new ArrayList<>();
        int slidingWindowFailed = 3;

        ElementsInvolvedOnOrbit elementsInvolved1 = new ElementsInvolvedOnOrbit();
        elementsInvolved1.setElementsInvolved(elementsInvolvedAsString);
        elementsInvolved1.setSlidingWindow(slidingWindowFailed);

        assertEquals(elementsInvolvedAsString, elementsInvolved1.getElementsInvolved());
        assertEquals(slidingWindowFailed, elementsInvolved1.getSlidingWindow());

        ElementsInvolvedOnOrbit elementsInvolved2 = new ElementsInvolvedOnOrbit(slidingWindowFailed, elementsInvolvedAsString);

        assertEquals(elementsInvolved1.toString(), elementsInvolved2.toString());
    }
}
