
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CmgaResourcesTest
{

    @Test
    public void testCmgaResources() throws Exception
    {
        double tPlatForTest = 40;
        double tRampForTest = 35;
        double tRestForTest = 12;

        CmgaResources cmgaRes1 = new CmgaResources();
        cmgaRes1.settPlat(tPlatForTest);
        cmgaRes1.setTRamp(tRampForTest);
        cmgaRes1.settRest(tRestForTest);

        assertEquals(tPlatForTest, cmgaRes1.gettPlat(), 0);
        assertEquals(tRampForTest, cmgaRes1.getTRamp(), 0);
        assertEquals(tRestForTest, cmgaRes1.gettRest(), 0);

        CmgaResources cmgaRes2 = new CmgaResources(tPlatForTest, tRampForTest, tRestForTest);
        assertEquals(cmgaRes2.toString(), cmgaRes2.toString());

    }

}
