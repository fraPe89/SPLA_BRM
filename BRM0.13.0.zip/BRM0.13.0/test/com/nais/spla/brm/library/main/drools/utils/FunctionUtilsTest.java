
package com.nais.spla.brm.library.main.drools.utils;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * The Class FunctionUtilsTest.
 */
public class FunctionUtilsTest {

	/** The du. */
	DroolsUtils du = new DroolsUtils();
	
	/** The fu. */
	FunctionUtils fu = new FunctionUtils();

	/**
	 * Sets the up.
	 *
	 * @throws Exception the exception
	 */
	@Before
	public void setUp() throws Exception {
		this.du = new DroolsUtils();
	}

	/**
	 * Test extract ar from dto.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testExtractArFromDto() throws Exception {
		String splitChar = "_";
		String id = "100_PR-ITA-001-HP_AR-001_DTO-2";
		String returnedAr = FunctionUtils.extractArFromDto(id, splitChar);
		System.out.println("returned ar :" + returnedAr);
		String expected = "AR-001";
		assertEquals(expected, returnedAr);
	}

	/**
	 * Test extract pr from dto.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testExtractPrFromDto() throws Exception {
		String id = "100_PR-ITA-001-HP_AR-001_DTO-";
		String expectedPr = "PR-ITA-001-HP";
		String splitChar = "_";
		String returnedPr = FunctionUtils.extractPrFromDto(id, splitChar);
		assertEquals(expectedPr, returnedPr);
	}

	/**
	 * Test sort acq by priority different pr type.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testSortAcqByPriority_differentPrType() throws Exception {
		FunctionUtils funcUtils = new FunctionUtils();

		Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO1", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq1.setPrType(PRType.LMP);
		acq1.setPriority(3);

		Acquisition acq2 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO2", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq2.setPrType(PRType.VU);
		acq2.setPriority(2);

		Acquisition acq3 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO3", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq3.setPrType(PRType.HP);
		acq3.setPriority(1);

		List<Acquisition> acqList = new ArrayList<>(Arrays.asList(acq1, acq2, acq3));

		assertEquals(acq1, acqList.get(0));
		assertEquals(acq2, acqList.get(1));
		assertEquals(acq3, acqList.get(2));

		funcUtils.sortAcqByPriority(acqList);

		for (int i = 0; i < acqList.size(); i++) {
			System.out.println(acqList.get(i));
		}

		assertEquals(acq2, acqList.get(0));
		assertEquals(acq1, acqList.get(1));
		assertEquals(acq3, acqList.get(2));

	}

	/**
	 * Test sort acq by priority same pr type.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testSortAcqByPriority_SamePrType() throws Exception {
		FunctionUtils funcUtils = new FunctionUtils();

		Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO1", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq1.setPrType(PRType.VU);
		acq1.setPriority(3);

		Acquisition acq2 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO2", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq2.setPrType(PRType.VU);
		acq2.setPriority(2);

		Acquisition acq3 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO3", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq3.setPrType(PRType.LMP);
		acq3.setPriority(1);

		List<Acquisition> acqList = new ArrayList<>(Arrays.asList(acq1, acq2, acq3));

		assertEquals(acq1, acqList.get(0));
		assertEquals(acq2, acqList.get(1));
		assertEquals(acq3, acqList.get(2));

		funcUtils.sortAcqByPriority(acqList);

		assertEquals(acq2, acqList.get(0));
		assertEquals(acq1, acqList.get(1));
		assertEquals(acq3, acqList.get(2));

	}

	/**
	 * Test rank up down.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testRankUpDown() throws Exception {
		Partner p1 = new Partner("p1", null, 100, 100);
		Partner p2 = new Partner("p2", null, 100, 100);
		Partner p3 = new Partner("p3", null, 100, 100);
		Partner p4 = new Partner("p4", null, 100, 100);

		Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO1", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq1.setPriority(3);
		List<UserInfo> userInfoListAcq1 = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
		userInfoListAcq1.add(userInfo1);
		userInfoListAcq1.add(userInfo2);
		acq1.setUserInfo(userInfoListAcq1);

		Acquisition acq2 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO2", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq2.setPriority(2);
		List<UserInfo> userInfoListAcq2 = new ArrayList<>();
		UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());
		UserInfo userInfo4 = new UserInfo(null, false, p4.getPartnerId(), p4.getUgsId());
		userInfoListAcq2.add(userInfo3);
		userInfoListAcq2.add(userInfo4);
		acq2.setUserInfo(userInfoListAcq2);

		Acquisition acq3 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO3", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq3.setPriority(1);
		List<UserInfo> userInfoListAcq3 = new ArrayList<>();
		userInfoListAcq3.add(userInfo1);
		userInfoListAcq3.add(userInfo3);
		acq3.setUserInfo(userInfoListAcq3);

		Acquisition acq4 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO4", "08/10/2017 03:00:00",
				"08/10/2017 03:05:00", "left", "SAT_2");
		acq4.setPriority(0);
		List<UserInfo> userInfoListAcq4 = new ArrayList<>();
		userInfoListAcq4.add(userInfo1);
		userInfoListAcq4.add(userInfo4);
		acq3.setUserInfo(userInfoListAcq4);

		List<String> elementsInvolved = new ArrayList<>(
				Arrays.asList(acq2.getIdTask(), acq3.getIdTask(), acq4.getIdTask()));
		acq1.setRejected(true);
		acq1.addReasonOfReject(1, ReasonOfReject.acqOverlapWithAcquisition, "", 1, 1, elementsInvolved);

		// String rankUp = funcUtils.rankUpDown(, acq1, true);
		// String rankDown = funcUtils.rankUpDown( acq1, false);
		//
		// assertEquals(acq2.getIdTask(),rankUp);
		// assertEquals(acq4.getIdTask(),rankDown);
	}

	/**
	 * Cet to utc.
	 *
	 * @param timeInCet the time in cet
	 * @return the local date time
	 */
	public static LocalDateTime cetToUtc(LocalDateTime timeInCet) {
		ZonedDateTime cetTimeZoned = ZonedDateTime.of(timeInCet, ZoneId.of("CET"));
		return cetTimeZoned.withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();
	}

	/**
	 * Utc to cet.
	 *
	 * @param timeInUtc the time in utc
	 * @return the local date time
	 */
	public static LocalDateTime utcToCet(LocalDateTime timeInUtc) {
		ZonedDateTime utcTimeZoned = ZonedDateTime.of(timeInUtc, ZoneId.of("UTC"));
		return utcTimeZoned.withZoneSameInstant(ZoneId.of("CET")).toLocalDateTime();
	}

	/*
	 * @Test public void parseDtoFromFileTest() throws ParseException, Exception {
	 * this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
	 *
	 * MissionHorizon currentMH = new MissionHorizon();
	 * currentMH.setStart(du.createDate("16/09/2016 06:21:00"));
	 * currentMH.setStop(du.createDate("16/09/2016 18:21:00"));
	 * droolsParams.setCurrentMH(currentMH);
	 *
	 * droolsParams.getAllPAWS().clear(); this.droolsInstance =
	 * this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
	 * this.droolsInstance, this.currentKieSession, "_");
	 *
	 * double extraCostLeft = 2; droolsParams.setExtraCostLeft(extraCostLeft);
	 *
	 * String fileString =
	 * "  � 100_2282_1_1_, startTime :Fri Sep 16 11:23:22 UTC 2016, endTime : Fri Sep 16 11:23:32 UTC 2016, lookSide :Left, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2271_1_1_, startTime :Fri Sep 16 11:42:49 UTC 2016, endTime : Fri Sep 16 11:43:05 UTC 2016, lookSide :Left, sensorMode :SCANSAR_1 , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2289_1_1_, startTime :Fri Sep 16 17:24:53 UTC 2016, endTime : Fri Sep 16 17:25:01 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2288_1_1_, startTime :Fri Sep 16 17:24:50 UTC 2016, endTime : Fri Sep 16 17:24:58 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2516_1_1_, startTime :Fri Sep 16 18:00:30 UTC 2016, endTime : Fri Sep 16 18:00:40 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_2 added\r\n"
	 * +
	 * "	 � 100_2498_1_1_, startTime :Fri Sep 16 16:00:48 UTC 2016, endTime : Fri Sep 16 16:00:58 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_2 added\r\n"
	 * +
	 * "	 � 100_2297_1_1_, startTime :Fri Sep 16 18:18:52 UTC 2016, endTime : Fri Sep 16 18:39:43 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_2 added\r\n"
	 * +
	 * "	 � 100_2294_1_1_, startTime :Fri Sep 16 11:12:36 UTC 2016, endTime : Fri Sep 16 11:12:44 UTC 2016, lookSide :Left, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2296_1_1_, startTime :Fri Sep 16 18:19:30 UTC 2016, endTime : Fri Sep 16 18:19:43 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2294_1_2_, startTime :Fri Sep 16 11:12:37 UTC 2016, endTime : Fri Sep 16 11:12:44 UTC 2016, lookSide :Left, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2281_1_1_, startTime :Fri Sep 16 11:33:15 UTC 2016, endTime : Fri Sep 16 11:33:26 UTC 2016, lookSide :Left, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2499_1_1_, startTime :Fri Sep 16 17:20:19 UTC 2016, endTime : Fri Sep 16 17:20:27 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2188_1_1_, startTime :Fri Sep 16 11:34:59 UTC 2016, endTime : Fri Sep 16 11:35:07 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2184_1_1_, startTime :Fri Sep 16 11:53:30 UTC 2016, endTime : Fri Sep 16 11:53:37 UTC 2016, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2184_1_2_, startTime :Fri Sep 16 11:53:30 UTC 2016, endTime : Fri Sep 16 11:53:37 UTC 2016, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2183_1_1_, startTime :Fri Sep 16 11:50:13 UTC 2016, endTime : Fri Sep 16 11:50:44 UTC 2016, lookSide :Right, sensorMode :SCANSAR_2 , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2179_1_1_, startTime :Fri Sep 16 11:41:09 UTC 2016, endTime : Fri Sep 16 11:41:14 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2178_1_1_, startTime :Fri Sep 16 11:38:01 UTC 2016, endTime : Fri Sep 16 11:38:11 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2181_1_2_, startTime :Fri Sep 16 11:47:15 UTC 2016, endTime : Fri Sep 16 11:47:31 UTC 2016, lookSide :Right, sensorMode :SCANSAR_1 , prType : PP, sat : SAT_1 added\r\n"
	 * +
	 * "	 � 100_2180_1_3_, startTime :Fri Sep 16 11:44:14 UTC 2016, endTime : Fri Sep 16 11:44:21 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_1 added "
	 * ;
	 *
	 * FunctionUtils fu = new FunctionUtils(); List<DTO> dtoList =
	 * fu.parseDtoFromFile(fileString); System.out.println(dtoList);
	 *
	 * for (int i = 0; i < dtoList.size(); i++) {
	 *
	 * this.droolsInstance.insertDto(this.droolsParams, dtoList.get(i), sessionId,
	 * this.currentKieSession); }
	 *
	 * droolsInstance.writeToFile(sessionId, currentKieSession, droolsParams); }
	 *
	 *
	 */
}
