
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class ElementsTillThresholdTest
{

    @Test
    public void testElementsTillThreshold() throws Exception
    {
        double reachedValue = 200;
        List<String> elementsChecked = new ArrayList<>();

        ElementsTillThreshold elements1 = new ElementsTillThreshold(reachedValue, elementsChecked);

        assertEquals(reachedValue, elements1.getReachedValue(), 0);
        assertEquals(elementsChecked.toString(), elements1.getElementsChecked().toString());

        ElementsTillThreshold elements2 = new ElementsTillThreshold();
        elements2.setElementsChecked(elementsChecked);
        elements2.setReachedValue(reachedValue);

    }
}
