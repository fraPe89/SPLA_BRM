
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;

public class InitPlanTasksTest
{

    @Test
    public void testInitPlanTasks() throws Exception
    {
        List<Acquisition> allInitAcq = new ArrayList<>();
        List<Maneuver> allInitMan = new ArrayList<>();
        List<RampCMGA> allInitRamp = new ArrayList<>();
        List<Download> allInitDwl = new ArrayList<>();
        List<Storage> allInitSto = new ArrayList<>();
        List<Silent> allInitSil = new ArrayList<>();
        List<PassThrough> allInitPt = new ArrayList<>();
        List<Bite> allinitBite = new ArrayList<>();
        List<CMGAxis> allInitcmgAxis = new ArrayList<>();
        List<StoreAUX> allInitStoreAux = new ArrayList<>();
        List<EquivalentDTO> allEquivDto = new ArrayList<>();
        
        InitPlanTasks initPlan1 = new InitPlanTasks(allInitAcq, allInitMan, allInitRamp, allInitDwl, allInitSto, allInitSil, allInitPt, allInitcmgAxis, allinitBite, allInitStoreAux, allEquivDto);
        assertEquals(allInitAcq, initPlan1.getAllInitAcq());
        assertEquals(allInitMan, initPlan1.getAllInitMan());
        assertEquals(allInitRamp, initPlan1.getAllInitRamp());
        assertEquals(allInitDwl, initPlan1.getAllInitDwl());
        assertEquals(allInitSto, initPlan1.getAllInitSto());
        assertEquals(allInitSil, initPlan1.getAllInitSil());
        assertEquals(allInitPt, initPlan1.getAllInitPt());
        assertEquals(allinitBite, initPlan1.getAllInitBite());
        assertEquals(allInitcmgAxis, initPlan1.getAllInitCmgAxis());
        assertEquals(allInitStoreAux, initPlan1.getAllInitStoreAux());
        assertEquals(allEquivDto, initPlan1.getAllInitEquivDTO());

    }
}
