
package com.nais.spla.brm.library.main.ontology.resources;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;

/**
 * The Class EclipseTest.
 */
public class EclipseTest
{

    /**
     * Test eclipse.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testEclipse() throws Exception
    {
        DroolsUtils du = new DroolsUtils();
        Date start = DroolsUtils.createDate("");
        Date stop = DroolsUtils.createDate("");
        String satelliteId = "SAT_1";

        Eclipse eclipse = new Eclipse(start, stop, satelliteId);
        assertEquals(start, eclipse.getStartTime());
        assertEquals(stop, eclipse.getEndTime());
        assertEquals(satelliteId, eclipse.getSatelliteId());
    }

}
