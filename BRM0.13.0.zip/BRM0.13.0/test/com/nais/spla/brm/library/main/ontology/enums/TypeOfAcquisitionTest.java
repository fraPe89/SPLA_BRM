
package com.nais.spla.brm.library.main.ontology.enums;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * The Class TypeOfAcquisitionTest.
 */
public class TypeOfAcquisitionTest
{

    /**
     * Test enum type of action.
     */
    @Test
    public void testEnumTypeOfAction()
    {
        List<PRMode> allTypeOfActionForTest = new ArrayList<>();
        PRMode[] allTypeOfAction = PRMode.values();
        for (int i = 0; i < allTypeOfAction.length; i++)
        {
            allTypeOfActionForTest.add(allTypeOfAction[i]);
        }

        PRMode type;
        type = PRMode.valueOf("Theatre");
        System.out.println("Selected : " + type);
    }

}
