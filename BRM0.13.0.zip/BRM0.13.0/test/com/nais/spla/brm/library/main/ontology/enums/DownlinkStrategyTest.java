
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * The Class DownlinkStrategyTest.
 */
public class DownlinkStrategyTest
{

    /**
     * Test enum downlink strategy.
     */
    @Test
    public void testEnumDownlinkStrategy()
    {
        List<DownlinkStrategy> allDownlinkStrategyForTest = new ArrayList<>(Arrays.asList(DownlinkStrategy.DELETE, DownlinkStrategy.RETAIN));
        DownlinkStrategy[] allDownlinkStrategy = DownlinkStrategy.values();
        for (int i = 0; i < allDownlinkStrategy.length; i++)
        {
            for (int j = 0; j < allDownlinkStrategyForTest.size(); j++)
            {
                if (allDownlinkStrategy[i].equals(allDownlinkStrategyForTest.get(j)))
                {
                    allDownlinkStrategyForTest.remove(j);
                    j--;
                }
            }
        }

        DownlinkStrategy type;
        type = DownlinkStrategy.valueOf("DELETE");
        System.out.println("Selected : " + type);

        assertEquals(0, allDownlinkStrategyForTest.size());
    }

}
