
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;

public class HPExclusionTest
{

    @Test
    public void testGetHpExclusionListId() throws Exception
    {

        DroolsUtils du = new DroolsUtils();
        /** The id. */
        String hpExclusionListId = "oidTest";

        String satelliteId = "satId";

        /** The look side initial. */
        String startLookSide = "left";

        /** The look side final. */
        String stopLookSide = "right";

        /** The activation flag. */
        boolean isEnabled = true;

        /** The activation flag. */
        boolean isPeriodic = true;

        Date start = DroolsUtils.createDate("");
        Date end = DroolsUtils.createDate("");

        HPExclusion hpExcl = new HPExclusion(hpExclusionListId, start, startLookSide, end, stopLookSide, satelliteId, isEnabled, isPeriodic);
        hpExcl.setEnabled(isEnabled);
        hpExcl.setEndTime(end);
        hpExcl.setHpExclusionListId(hpExclusionListId);
        hpExcl.setSatelliteId(satelliteId);
        hpExcl.setStartTime(start);
        hpExcl.setStartLookSide(startLookSide);
        hpExcl.setStopLookSide(stopLookSide);
        hpExcl.setPeriodic(isPeriodic);

        assertEquals(hpExclusionListId, hpExcl.getHpExclusionListId());
        assertEquals(stopLookSide, hpExcl.getStopLookSide());
        assertEquals(end, hpExcl.getEndTime());
        assertEquals(start, hpExcl.getStartTime());
        assertEquals(startLookSide, hpExcl.getStartLookSide());
        assertEquals(satelliteId, hpExcl.getSatelliteId());
        assertEquals(isEnabled, hpExcl.isEnabled());
        assertEquals(isPeriodic, hpExcl.isPeriodic());

        HPExclusion hpExcl2 = hpExcl;
        assertEquals(hpExcl.toString(), hpExcl2.toString());

    }

}
