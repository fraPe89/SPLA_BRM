
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class EnergyAssociatedToTaskTest
{

    @Test
    public void testEnergyAssociatedToTask() throws Exception
    {
        Task taskForTest = new Task();
        double essValue = 300;
        EnergyAssociatedToTask energyForTest1 = new EnergyAssociatedToTask();
        energyForTest1.setEssValue(essValue);
        energyForTest1.setTask(taskForTest);

        EnergyAssociatedToTask energyForTest2 = new EnergyAssociatedToTask(taskForTest, essValue);
        assertEquals(energyForTest1.toString(), energyForTest2.toString());
        assertEquals(essValue, energyForTest2.getEssValue(), 0);
        assertEquals(taskForTest, energyForTest2.getTask());

    }

}
