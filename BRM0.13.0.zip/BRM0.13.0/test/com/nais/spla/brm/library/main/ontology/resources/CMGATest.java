
package com.nais.spla.brm.library.main.ontology.resources;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class CMGATest
{

    @Test
    public void createCMGA()
    {
        String cmgaIdForTest = "idTest";

        double wAccForTest = 20;

        double tAccForTest = 10;

        double wPlatForTest = 15;

        double wRestForTest = 17;

        boolean isOperative = true;
        String satelliteId = "sat_1";
        Map<Double, Double> allPowersForOrbitCmga1 = new HashMap<>();
        Map<Double, Double> allPowersForOrbitCmga2 = new HashMap<>();

        CMGA newCMGA1 = new CMGA();
        newCMGA1.setCmgaId(cmgaIdForTest);
        newCMGA1.setwAcc(wAccForTest);
        newCMGA1.settAcc(tAccForTest);
        newCMGA1.setwPlat(wPlatForTest);
        newCMGA1.setwRest(wRestForTest);
        newCMGA1.setOperative(isOperative);
        newCMGA1.setSatelliteId(satelliteId);
        newCMGA1.setAllPowersForOrbit(allPowersForOrbitCmga1);
        assertEquals(allPowersForOrbitCmga1, newCMGA1.getAllPowersForOrbit());

        CMGA newCMGA2 = new CMGA(cmgaIdForTest, wAccForTest, tAccForTest, wPlatForTest, wRestForTest, isOperative, satelliteId);
        newCMGA2.setAllPowersForOrbit(allPowersForOrbitCmga2);
        assertEquals(cmgaIdForTest, newCMGA2.getCmgaId());
        assertEquals(wAccForTest, newCMGA2.getwAcc(), 0);
        assertEquals(tAccForTest, newCMGA2.gettAcc(), 0);
        assertEquals(wPlatForTest, newCMGA2.getwPlat(), 0);
        assertEquals(wRestForTest, newCMGA2.getwRest(), 0);
        assertEquals(isOperative, newCMGA2.isOperative());
        assertEquals(satelliteId, newCMGA2.getSatelliteId());
        assertEquals(allPowersForOrbitCmga2, newCMGA2.getAllPowersForOrbit());
        assertEquals(true, newCMGA2.isOperative());

        assertEquals(newCMGA1.toString(), newCMGA2.toString());
        assertTrue(newCMGA1.toString().equals(newCMGA2.toString()));
        newCMGA2.addAllPowersForOrbit(1.0, 52);

        System.out.println("all powers for orbits for cmga1 : " + newCMGA1.getAllPowersForOrbit());
        System.out.println("all powers for orbits for cmga2 : " + newCMGA2.getAllPowersForOrbit());

        System.out.println("cmga1 : " + newCMGA1.toString());
        System.out.println("cmga2 : " + newCMGA2.toString());

        assertFalse(newCMGA1.toString().equals(newCMGA2.toString()));

    }
}
