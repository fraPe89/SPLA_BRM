
package com.nais.spla.brm.library.main.drools.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;

// TODO: Auto-generated Javadoc
/**
 * The Class SetResourcesTest.
 */
public class SetResourcesTest
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestDroolsBicManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.maxBicForTest = 100;
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test bic rule.
     *
     * @throws Exception the exception
     */
    @Test
    public void testSetSatellites() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        SatelliteProperties satProp1 = this.droolsParams.getSatWithId("1").getSatelliteProperties();
        SatelliteProperties satProp2 = this.droolsParams.getSatWithId("2").getSatelliteProperties();
        SetResources satRes = new SetResources();
        satRes.setSatellites(this.droolsParams, kie, satProp1, satProp2);
    }

    /**
     * Test set visibilities.
     *
     * @throws Exception the exception
     */
    @Test
    public void testSetVisibilities() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        SetResources setRes = new SetResources();
        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(1, "SAT_1", "1200", p1.getPartnerId(), "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(2, "SAT_1", "KOR", p1.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Visibility vis3 = stubRes.createVisibility(3, "SAT_1", "1100", p1.getPartnerId(), "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = stubRes.createVisibility(4, "SAT_2", "1100", null, "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        vis4.setExternal(true);

        Visibility vis5 = stubRes.createVisibility(5, "SAT_2", "KIR", p1.getPartnerId(), "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(6, "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(7, "SAT_2", "1100", null, "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        vis7.setExternal(true);
        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7));
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resFunc = new ResourceFunctions();
        setRes.populateResourceFunctions(resFunc, this.droolsParams);
        this.droolsParams.setAllVisibilities(allVisForTest);
        setRes.setVisibilities(this.droolsParams, resFunc, kie);

    }

    
    /**
     * Sets the PDHT.
     *
     * @throws Exception the exception
     */
    @Test
    public void setPDHT() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        SetResources setRes = new SetResources();
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        setRes.setPDHT(droolsParams, kie);
    }
    
    /**
     * Sets the PDHT null.
     *
     * @throws Exception the exception
     */
    @Test
    public void setPDHTNull() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        droolsParams.getAllPDHT().clear();
        SetResources setRes = new SetResources();
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        setRes.setPDHT(droolsParams, kie);
    }
    

    /**
     * Sets the PDHT null.
     *
     * @throws Exception the exception
     */
    @Test
    public void setSatellitesNull() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        droolsParams.getAllPDHT().clear();
        SetResources setRes = new SetResources();
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        setRes.setSatellites(droolsParams, kie, droolsParams.getSatWithId("1").getSatelliteProperties(),droolsParams.getSatWithId("2").getSatelliteProperties());
    }
    
    /**
     * Test set visibilities GP S BACKUP.
     *
     * @throws Exception the exception
     */
    @Test
    public void testSetVisibilities_GPS_BACKUP() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        SetResources setRes = new SetResources();
        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(1, "SAT_1", "1100", p1.getPartnerId(), "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(2, "SAT_1", "KOR", p1.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:15:00");

        Visibility vis3 = stubRes.createVisibility(3, "SAT_1", "1100", p1.getPartnerId(), "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = stubRes.createVisibility(4, "SAT_2", "1100", p1.getPartnerId(), "10/10/2017 06:00:00", "10/10/2017 06:40:00");

        Visibility vis5 = stubRes.createVisibility(5, "SAT_2", "KIR", p1.getPartnerId(), "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(6, "SAT_1", "KOR", p1.getPartnerId(), "10/10/2017 17:55:00", "10/10/2017 18:01:00");

        Visibility vis7 = stubRes.createVisibility(7, "SAT_2", "1100", p1.getPartnerId(), "10/10/2017 16:10:00", "10/10/2017 16:57:00");

        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7));
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resFunc = new ResourceFunctions();
        setRes.populateResourceFunctions(resFunc, this.droolsParams);
        this.droolsParams.setAllVisibilities(allVisForTest);
        setRes.setVisibilities(this.droolsParams, resFunc, kie);

    }

}
