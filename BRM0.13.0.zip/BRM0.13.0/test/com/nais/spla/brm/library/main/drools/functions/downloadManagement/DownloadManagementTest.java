
package com.nais.spla.brm.library.main.drools.functions.downloadManagement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.DownloadLogic;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SectorAndVisForPartner;
import com.nais.spla.brm.library.main.ontology.resourceData.SizeOfSectorDwl;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class DownloadManagementTest.
 */
public class DownloadManagementTest {

	/** The session id. */
	private String sessionId = null;

	/** The current kie session. */
	private int currentKieSession = 0;

	/** The PDHT max memory. */
	private Long PDHTMaxMemory = 0l;

	/** The drools params. */
	private DroolsParameters droolsParams = null;

	/** The drools instance. */
	private DroolsOperations droolsInstance = null;

	private PdhtManagement pdhtMng = new PdhtManagement();

	/** The du. */
	private DroolsUtils du = null;

	private StubResources stub = new StubResources();

	/** The dwl utils. */
	private DownloadUtils dwlUtils = new DownloadUtils();

	/** The dwl management. */
	private DownloadManagement dwlManagement = new DownloadManagement();

	/**
	 * Sets the up.
	 *
	 * @throws ParseException the parse exception
	 */
	@Before
	public void setUp() throws ParseException {
		this.sessionId = "TestDownloadThresholdRule";
		this.droolsParams = new DroolsParameters();
		this.PDHTMaxMemory = 5000000L;
		this.currentKieSession = 1;
		this.du = new DroolsUtils();
		double maxBicForTest = 100;
		double extraCostLeft = 10;
		this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession,
				this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
	}

	/*
	 * after each test, all the sessions of Drools will be closed
	 */
	@After
	public void tearDown() {
		this.droolsInstance.closeAllInstancesForSession(this.sessionId);
	}

	/**
	 * Update pdht till end.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void updatePdhtTillEnd() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Satellite satForTest = this.droolsParams.getSatWithId("1");
		satForTest.getSatelliteProperties().setMinPercDownloadOnVis(30);
		satForTest.getSatelliteProperties().setDownlinkPerChannel(260);
		satForTest.getSatelliteProperties().setSingleSectorDimension(4);

		List<Partner> allPartners = this.droolsParams.getAllPartners();
		Partner p0 = allPartners.get(0);
		Partner p2 = allPartners.get(2);
		System.out.println("partner associated p0 :" + p0);
		System.out.println("partner associated p2 :" + p2);

		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00",
				"left", "SAT_1");
		acq1.setPolarization(Polarization.HH);
		acq1.setImageBIC(20);
		acq1.setSizeH(4000);
		acq1.setSizeV(0);

		List<UserInfo> userInfoAssociated = new ArrayList<>();
		UserInfo userInfop1 = new UserInfo(p0.getPartnerId());
		userInfop1.setUgsId(p0.getPartnerId());
		UserInfo userInfop2 = new UserInfo(p2.getPartnerId());
		userInfop2.setUgsId(p2.getPartnerId());
		userInfoAssociated.add(userInfop1);
		userInfoAssociated.add(userInfop2);

		acq1.setUserInfo(userInfoAssociated);

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 06:00:00",
				"17/01/2018 06:30:00");
		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "Kir", null, "17/01/2018 08:10:00",
				"17/01/2018 08:15:00");
		vis2.setExternal(true);
		Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "Kir", null, "17/01/2018 11:00:00",
				"17/01/2018 12:50:00");
		vis3.setExternal(true);
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", "Partner_2", "17/01/2018 18:00:00",
				"17/01/2018 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		// droolsInstance.updatePdhtTillEnd(0,
		// droolsParams.getCurrentMH().getStart(), droolsParams,"SAT_1");

		// List<Download> onlyValidDwl = dwlManagement.processDownloads(packet,
		// allDownloads, allVisibilitiesSat1);
		// System.out.println("all dwl valid: " + onlyValidDwl);
	}

	@Test
	public void testPlanDownloads() throws Exception {
		DroolsOperations droolsInstance = new DroolsOperations();
		this.du.setUpDrools(this.sessionId, this.droolsParams, droolsInstance);
		this.droolsParams.getHpExclusionList().clear();
		droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, droolsInstance,
				this.currentKieSession, "_");
		System.out.println("\n\n I'm running test O_initialAndFinalMan");
		System.out.println(" mission horizon : " + this.droolsParams.getCurrentMH());

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
		boolean accepted = droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
		assertEquals(true, accepted);

		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);

		System.out.println("returned acq : " + acqRelatedToDto);
		boolean overhead = this.pdhtMng.updatePdhtTillEnd(this.sessionId, this.currentKieSession, acqRelatedToDto, null,
				this.droolsParams, "SAT_1");
		System.out.println("overhead?" + overhead);
	}

	/**
	 * Test update pdht till end no overhead double pol HV.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdatePdhtTillEnd_no_overhead_doublePol_HV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HV);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		System.out.println("I'm inserting dto : " + dto1.toString());

		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);

		System.out.println("returned acq : " + acqRelatedToDto);
		boolean overhead = this.pdhtMng.updatePdhtTillEnd(this.sessionId, this.currentKieSession, acqRelatedToDto, null,
				this.droolsParams, "SAT_1");
		System.out.println("overhead?" + overhead);
	}

	/**
	 * Test update pdht till end overhead.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdatePdhtTillEnd_overhead() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(4000);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);

		assertTrue(accepted);

		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);
		System.out.println("returned acq : " + acqRelatedToDto);

		TreeMap<String, Storage> allstorages = resFunc.getStoragesAssociatedToSat(dto1.getSatelliteId());
		Storage stoRelatedToAcq = allstorages.get(dto1.getDtoId());
		boolean overhead = this.pdhtMng.updatePdhtTillEnd(this.sessionId, this.currentKieSession, acqRelatedToDto, null,
				this.droolsParams, "SAT_1");
		System.out.println("overhead?" + overhead);
		PDHT pdhtAfterInsert = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(stoRelatedToAcq.getStartTime().getTime()).getPdht();
		System.out.println(pdhtAfterInsert.toString());
		System.out.println(pdhtAfterInsert.getMemoryModuleWithId("1"));
		assertEquals(0, pdhtAfterInsert.getMemoryModuleWithId("1").getFreeSectors());
		assertEquals(0, pdhtAfterInsert.getMemoryModuleWithId("2").getFreeSectors());
		assertEquals(0, pdhtAfterInsert.getMemoryModuleWithId("3").getFreeSectors());
		assertEquals(0, pdhtAfterInsert.getMemoryModuleWithId("4").getFreeSectors());
		assertEquals(1000, pdhtAfterInsert.getMemoryModuleWithId("5").getFreeSectors());
		assertEquals(1000, pdhtAfterInsert.getMemoryModuleWithId("6").getFreeSectors());

	}

	/**
	 * Test update pdht till end overhead.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdatePdhtTillEnd_overheadAtNextTime() throws Exception {
		StubResources stubRes = new StubResources();
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		Visibility vis5 = stubRes.createVisibility(4, "SAT_1", "KIR", null, "10/10/2017 16:00:00",
				"10/10/2017 16:40:00");
		Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 18:00:00",
				"10/10/2017 18:20:00");

		this.droolsParams.getAllVisibilities().clear();
		this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis3, vis5, vis6));

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(4000);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);
		assertTrue(inserted);

		System.out.println(acqRelatedToDto);
		DTO dto2 = this.du.createSingleDto("10/10/2017 10:55:00", "10/10/2017 10:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(4000);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		// assertFalse(inserted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		// TODO : risolvere bug su memoria pdht su questo test _ non ripristina
		// lo stato a prima del fallimenti della dto2
		/*
		 * System.out.println("returnedpdht"+resFunc.
		 * getPDHTFunctionAssociatedToSat("SAT_1")+"done"); PDHT pdhtAfterInsertDto1 =
		 * resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(acqRelatedToDto.
		 * getStartTime().getTime()).getPdht();
		 * System.out.println(pdhtAfterInsertDto1.toString());
		 *
		 * System.out.println(pdhtAfterInsertDto1.getMemoryModuleWithId("1"));
		 * assertEquals(0,pdhtAfterInsertDto1.getMemoryModuleWithId("1").
		 * getFreeSectors());
		 * assertEquals(0,pdhtAfterInsertDto1.getMemoryModuleWithId("2").
		 * getFreeSectors());
		 * assertEquals(0,pdhtAfterInsertDto1.getMemoryModuleWithId("3").
		 * getFreeSectors());
		 * assertEquals(0,pdhtAfterInsertDto1.getMemoryModuleWithId("4").
		 * getFreeSectors());
		 * assertEquals(1000,pdhtAfterInsertDto1.getMemoryModuleWithId("5").
		 * getFreeSectors());
		 * assertEquals(1000,pdhtAfterInsertDto1.getMemoryModuleWithId("6").
		 * getFreeSectors());
		 */
	}

	/**
	 * Test update pdht till end no overhead double pol VH.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdatePdhtTillEnd_no_overhead_doublePol_VH() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.VH);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		System.out.println("I'm inserting dto : " + dto1.toString());

		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);

		System.out.println("returned acq : " + acqRelatedToDto);

		System.out.println("returned acq : " + acqRelatedToDto);
		boolean overhead = this.pdhtMng.updatePdhtTillEnd(this.sessionId, this.currentKieSession, acqRelatedToDto, null,
				this.droolsParams, "SAT_1");
		System.out.println("overhead?" + overhead);
	}

	/**
	 * Test update pdht till end no overhead single pol VV.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdatePdhtTillEnd_no_overhead_singlePol_VV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.VV);
		dto1.setSizeH(0);
		dto1.setSizeV(4000);

		System.out.println("I'm inserting dto : " + dto1.toString());

		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);

		System.out.println("returned acq : " + acqRelatedToDto);
		boolean overhead = this.pdhtMng.updatePdhtTillEnd(this.sessionId, this.currentKieSession, acqRelatedToDto, null,
				this.droolsParams, "SAT_1");
		System.out.println("overhead?" + overhead);
	}

	@Test
	public void testInitPlanDownload_partially_Dwl_for_storage() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00",
				"left", "SAT_1");
		acq.setPolarization(Polarization.HH_HH);
		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);

		Storage relatedSto = this.du.createStorage("sto", "10/10/2017 06:00:00", "10/10/2017 06:00:00", "SAT_1", 200,
				20, Polarization.HH);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");

		List<Download> allDwlAssociatedToSto = new ArrayList<>();
		this.dwlManagement.initPlanDownload(acq, relatedSto, allDwlAssociatedToSto, this.droolsParams,
				downloadPriority);
		downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(downloadPriority);
	}

	/**
	 * Test init plan download no dwl for storage.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testInitPlanDownload_no_Dwl_for_storage() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00",
				"left", "SAT_1");
		Storage relatedSto = this.du.createStorage("sto", "10/10/2017 06:00:00", "10/10/2017 06:00:00", "SAT_1", 200,
				20, Polarization.HH);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");

		List<Download> allDwlAssociatedToSto = new ArrayList<>();
		this.dwlManagement.initPlanDownload(acq, relatedSto, allDwlAssociatedToSto, this.droolsParams,
				downloadPriority);
	}

	/**
	 * Test update pdht till end no overhead single pol HH.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testUpdatePdhtTillEnd_no_overhead_singlePol_HH() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(4000);
		dto1.setSizeV(0);

		System.out.println("I'm inserting dto : " + dto1.toString());

		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
		Acquisition acqRelatedToDto = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),
				this.sessionId, this.currentKieSession);

		System.out.println("returned acq : " + acqRelatedToDto);
		boolean overhead = this.pdhtMng.updatePdhtTillEnd(this.sessionId, this.currentKieSession, acqRelatedToDto, null,
				this.droolsParams, "SAT_1");
		System.out.println("overhead?" + overhead);
	}

	/**
	 * Test find if there are part of download on external station.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testFindIfThereArePartOfDownloadOnExternalStation() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("Running Test : testFindIfThereArePartOfDownloadOnExternalStation \n\n");
	}

	/**
	 * Test find if there are another download for same ps on same vis.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testFindIfThereAreAnotherDownloadForSamePsOnSameVis() throws Exception {

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("Running Test : testFindIfThereAreAnotherDownloadForSamePsOnSameVis \n\n");
		String relatedTaskId = "acqTest";

		int initialPacketStore = 0;
		long contactCounter = 1;
		Visibility vis1 = this.stub.createVisibility(contactCounter, "SAT_1", "Kir", "Partner_3", "17/01/2018 06:00:00",
				"17/01/2018 06:30:00");
		List<Task> allDwlOnVis = new ArrayList<>();

		Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00",
				DownlinkStrategy.RETAIN, false);
		dwl1.setInitialSector(0);
		dwl1.setAcqStatId("Kir");
		dwl1.setPol(Polarization.HH);
		dwl1.setRelatedTaskId(relatedTaskId);
		dwl1.setContactCounter(contactCounter);

		Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00",
				DownlinkStrategy.RETAIN, false);
		dwl2.setInitialSector(30);
		dwl2.setContactCounter(3);

		Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00",
				DownlinkStrategy.DELETE, true);
		dwl3.setInitialSector(15);
		dwl3.setPol(Polarization.HH);
		dwl3.setRelatedTaskId(relatedTaskId);
		dwl3.setContactCounter(contactCounter);

		Download dwl4 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00",
				DownlinkStrategy.RETAIN, false);
		dwl4.setInitialSector(0);
		dwl4.setAcqStatId("Kir");
		dwl4.setPol(Polarization.HH);
		dwl4.setRelatedTaskId(relatedTaskId);
		dwl4.setContactCounter(contactCounter);

		allDwlOnVis.add(dwl1);
		allDwlOnVis.add(dwl2);
		allDwlOnVis.add(dwl3);
		allDwlOnVis.add(dwl4);

		Download existDwl = this.dwlUtils.findIfThereAreAnotherDownloadForSamePsOnSameVis(relatedTaskId, dwl1.getPol(),
				initialPacketStore, vis1, allDwlOnVis);
		assertTrue(existDwl != null);
		System.out.println("exist downlo ? " + existDwl);
	}

	/**
	 * Test return max link available.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testReturnMaxLinkAvailable() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("Running Test : testFindIfThereAreAnotherDownloadForSamePsOnSameVis \n\n");
	}

	/**
	 * Test remove download.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testRemoveDownload() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("Running Test : testFindIfThereAreAnotherDownloadForSamePsOnSameVis \n\n");
		// Acquisition acq = du.create
		/*
		 *
		 * String choosenLink = "l1"; for (int i = 0; i < allVis.size(); i++) { if
		 * (allVis.get(i).getContactCounter() == download.getContactCounter()) { if
		 * (download.isCarrierL2Selection()) { choosenLink = "l2"; } if
		 * (download.getEndTime().getTime() ==
		 * allVis.get(i).getAvailableStartTime(choosenLink).getTime()) { long
		 * downloadDuration = download.getEndTime().getTime() -
		 * download.getStartTime().getTime();
		 * allVis.get(i).setAvailableStartTime(choosenLink, new
		 * Date(allVis.get(i).getAvailableStartTime(choosenLink).getTime() -
		 * downloadDuration)); } System.out.println("amount related to download : " +
		 * download.getDownloadedSize());
		 * System.out.println("capacity of link before remove : " +
		 * allVis.get(i).getCapacity(choosenLink)); double updatedCapacity =
		 * allVis.get(i).getCapacity(choosenLink) + download.getDownloadedSize();
		 * allVis.get(i).setCapacity(choosenLink, updatedCapacity);
		 * System.out.println("capacity of link after remove : " +
		 * allVis.get(i).getCapacity(choosenLink)); } } }
		 */
	}

	/**
	 * TODO : ripristinare test Test download with priority queue init plan.
	 *
	 * @throws Exception the exception
	 */
	/*
	 * @Test public void testDownloadWithPriorityQueue_initPlan() throws Exception {
	 * this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
	 *
	 * Partner p0 = this.droolsParams.getAllPartners().get(0); Partner p1 =
	 * this.droolsParams.getAllPartners().get(1);
	 * this.droolsParams.getAllVisibilities().clear(); Visibility vis1 =
	 * this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00",
	 * "10/10/2017 06:30:00"); Visibility vis2 = this.stub.createVisibility(1,
	 * "SAT_1", "KOR", p1.getPartnerId(), "10/10/2017 08:10:00",
	 * "10/10/2017 08:15:00"); Visibility vis3 = this.stub.createVisibility(2,
	 * "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
	 * Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT",
	 * p1.getPartnerId(), "10/10/2017 18:00:00", "10/10/2017 18:21:00");
	 * List<Visibility> allVis = new ArrayList<Visibility>(Arrays.asList(vis1, vis2,
	 * vis3, vis4)); List<String> allVisId = new
	 * ArrayList<String>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(),
	 * vis3.getAcqStatId(), vis4.getAcqStatId()));
	 *
	 * this.droolsParams.setAllVisibilities(allVis);
	 * this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
	 *
	 * this.droolsInstance = this.du.setUpSession(this.sessionId,
	 * SessionType.premium, this.droolsParams, this.droolsInstance,
	 * this.currentKieSession, "_"); Acquisition acq =
	 * this.du.createParametricAcquisition("acq1", "10/10/2017 06:00:00",
	 * "10/10/2017 06:10:00", "left", "SAT_1");
	 * acq.setPolarization(Polarization.HH); acq.setId("acqId");
	 * acq.setPreferredVis(allVisId);
	 *
	 * System.out.println("partners associated to acq : " + p0);
	 * System.out.println("partners associated to acq : " + p1);
	 *
	 * PriorityQueue elementPriority = new PriorityQueue(); HashMap<String,
	 * SectorAndVisForPartner> sectorsforPartner = new HashMap<String,
	 * SectorAndVisForPartner>(); sectorsforPartner.put(p0.getPartnerId(), new
	 * SectorAndVisForPartner(null, new ArrayList<SizeOfSectorDwl>(Arrays.asList(new
	 * SizeOfSectorDwl(300, 100, Polarization.HH)))));
	 * sectorsforPartner.put(p1.getPartnerId(), new SectorAndVisForPartner(null, new
	 * ArrayList<SizeOfSectorDwl>(Arrays.asList(new SizeOfSectorDwl(300, 100,
	 * Polarization.HH)))));
	 * elementPriority.setSectorsNeededForPartners(sectorsforPartner);
	 * elementPriority.setRelatedAcq(acq); elementPriority.setPol(Polarization.HH);
	 *
	 * TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap =
	 * new TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>();
	 * ResourceFunctions resFunc = new ResourceFunctions();
	 *
	 * List<Task> allDwlPlanned =
	 * this.dwlManagement.downloadWithPriorityQueue(elementPriority,
	 * this.droolsParams, downloadTreeMap, resFunc, "SAT_1");
	 * System.out.println("allDwl : " + allDwlPlanned);
	 *
	 * Download returnedDwl = (Download) allDwlPlanned.get(0);
	 * assertEquals(vis1.getContactCounter(), returnedDwl.getContactCounter());
	 * assertEquals(200, returnedDwl.getInitialSector()); assertEquals(300,
	 * returnedDwl.getFinalSector()); assertEquals(DownlinkStrategy.DELETE,
	 * returnedDwl.getPacketStoreStrategy()); assertEquals(true,
	 * returnedDwl.getUgsOwnerList().contains(p0.getPartnerId()));
	 * assertEquals(true,
	 * returnedDwl.getUgsOwnerList().contains(p1.getPartnerId())); }
	 */

	/**
	 * Test download with priority queue single partner.
	 *
	 * @throws Exception the exception
	 */
	/*
	 * @Test public void testDownloadWithPriorityQueue_single_partner() throws
	 * Exception { this.du.setUpDrools(this.sessionId, this.droolsParams,
	 * this.droolsInstance);
	 *
	 * Partner p0 = this.droolsParams.getAllPartners().get(0); Partner p1 =
	 * this.droolsParams.getAllPartners().get(1);
	 * this.droolsParams.getAllVisibilities().clear(); Visibility vis1 =
	 * this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00",
	 * "10/10/2017 06:30:00"); Visibility vis2 = this.stub.createVisibility(1,
	 * "SAT_1", "KOR", p1.getPartnerId(), "10/10/2017 08:10:00",
	 * "10/10/2017 08:15:00"); Visibility vis3 = this.stub.createVisibility(2,
	 * "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
	 * Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT",
	 * p1.getPartnerId(), "10/10/2017 18:00:00", "10/10/2017 18:21:00");
	 * List<Visibility> allVis = new ArrayList<Visibility>(Arrays.asList(vis1, vis2,
	 * vis3, vis4)); List<String> allVisId = new
	 * ArrayList<String>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(),
	 * vis3.getAcqStatId(), vis4.getAcqStatId()));
	 *
	 * this.droolsParams.setAllVisibilities(allVis);
	 * this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
	 *
	 * this.droolsInstance = this.du.setUpSession(this.sessionId,
	 * SessionType.premium, this.droolsParams, this.droolsInstance,
	 * this.currentKieSession, "_"); Acquisition acq =
	 * this.du.createParametricAcquisition("acq", "10/10/2017 06:22:00",
	 * "10/10/2017 06:28:00", "left", "SAT_1");
	 * acq.setPolarization(Polarization.HH); acq.setId("acqId");
	 * acq.setPreferredVis(allVisId);
	 *
	 * System.out.println("partners associated to acq : " + p0);
	 *
	 * PriorityQueue elementPriority = new PriorityQueue(); HashMap<String,
	 * SectorAndVisForPartner> sectorsforPartner = new HashMap<String,
	 * SectorAndVisForPartner>();
	 *
	 * List<String> allVisAssociated = new ArrayList<String>();
	 * List<SizeOfSectorDwl> sizeOfNeededDwl = new ArrayList<SizeOfSectorDwl>();
	 * SizeOfSectorDwl sizeForPartner = new SizeOfSectorDwl(3000, 3000,
	 * Polarization.HH); sizeOfNeededDwl.add(sizeForPartner);
	 *
	 * sectorsforPartner.put(p0.getPartnerId(), new
	 * SectorAndVisForPartner(allVisAssociated, sizeOfNeededDwl));
	 * elementPriority.setSectorsNeededForPartners(sectorsforPartner);
	 * elementPriority.setRelatedAcq(acq); elementPriority.setPol(Polarization.HH);
	 * TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap =
	 * new TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>();
	 * ResourceFunctions resFunc = new ResourceFunctions();
	 *
	 * List<Task> allDwlPlanned =
	 * this.dwlManagement.downloadWithPriorityQueue(elementPriority,
	 * this.droolsParams, downloadTreeMap, resFunc, acq.getSatelliteId());
	 * System.out.println("allDwl : " + allDwlPlanned); }
	 *
	 *
	 * @Test public void testDownloadWithPriorityQueue_multiple_partner() throws
	 * Exception { this.du.setUpDrools(this.sessionId, this.droolsParams,
	 * this.droolsInstance);
	 *
	 * Partner p1 = this.droolsParams.getAllPartners().get(1); Partner p2 =
	 * this.droolsParams.getAllPartners().get(2);
	 *
	 * this.droolsParams.getAllVisibilities().clear(); Visibility vis1 =
	 * this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00",
	 * "10/10/2017 06:30:00");
	 *
	 * Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR",
	 * p1.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:15:00"); Visibility
	 * vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null,
	 * "10/10/2017 12:00:00", "10/10/2017 12:50:00"); Visibility vis4 =
	 * this.stub.createVisibility(3, "SAT_1", "MAT", p1.getPartnerId(),
	 * "10/10/2017 18:00:00", "10/10/2017 18:21:00"); Visibility vis5 =
	 * this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 06:00:00",
	 * "10/10/2017 06:40:00"); List<Visibility> allVis = new
	 * ArrayList<Visibility>(Arrays.asList(vis1, vis2, vis3, vis4, vis5));
	 *
	 * this.droolsParams.setAllVisibilities(allVis);
	 *
	 * this.droolsInstance = this.du.setUpSession(this.sessionId,
	 * SessionType.premium, this.droolsParams, this.droolsInstance,
	 * this.currentKieSession, "_");
	 *
	 * Acquisition acq = this.du.createParametricAcquisition("acq",
	 * "10/10/2017 06:00:00", "10/10/2017 06:10:00", "left", "SAT_1");
	 * acq.setPolarization(Polarization.HH); List<String> acquisitionStationIdListP1
	 * = new ArrayList<String>(Arrays.asList(vis2.getAcqStatId(),
	 * vis3.getAcqStatId(), vis4.getAcqStatId())); // List<String>
	 * acquisitionStationIdList, boolean isSubscriber, String // ownerId, String
	 * ugsId)
	 *
	 * UserInfo user1 = new UserInfo(acquisitionStationIdListP1, false,
	 * p1.getPartnerId(), null); UserInfo user2 = new UserInfo(null, false,
	 * p2.getPartnerId(), null); List<UserInfo> allUserInfoForAcq = new
	 * ArrayList<UserInfo>(Arrays.asList(user1, user2));
	 * acq.setUserInfo(allUserInfoForAcq);
	 * System.out.println("partners1 associated to acq : " + p1);
	 * System.out.println("partners2 associated to acq : " + p2);
	 *
	 * PriorityQueue elementPriority = new PriorityQueue(); HashMap<String,
	 * SectorAndVisForPartner> sectorsforPartner = new HashMap<String,
	 * SectorAndVisForPartner>(); sectorsforPartner.put(p2.getPartnerId(), new
	 * SectorAndVisForPartner(null, new ArrayList<SizeOfSectorDwl>(Arrays.asList(new
	 * SizeOfSectorDwl(300, 100, Polarization.HH)))));
	 * sectorsforPartner.put(p1.getPartnerId(), new SectorAndVisForPartner(null, new
	 * ArrayList<SizeOfSectorDwl>(Arrays.asList(new SizeOfSectorDwl(300, 100,
	 * Polarization.HH)))));
	 * elementPriority.setSectorsNeededForPartners(sectorsforPartner);
	 * elementPriority.setRelatedAcq(acq); elementPriority.setPol(Polarization.HH);
	 * TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap =
	 * new TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>();
	 * ResourceFunctions resFunc = new ResourceFunctions();
	 *
	 * List<Task> allDwlPlanned =
	 * this.dwlManagement.tryToPlanOnVis(elementPriority,vis2,p2, this.droolsParams,
	 * downloadTreeMap, resFunc, acq.getSatelliteId()); for(int
	 * i=0;i<allDwlPlanned.size();i++) { System.out.println("\n allDwl : " +
	 * allDwlPlanned.get(i)); } }
	 *
	 *
	 * @Test public void testDownloadWithPriorityQueue_MoreDownloads() throws
	 * Exception { this.du.setUpDrools(this.sessionId, this.droolsParams,
	 * this.droolsInstance);
	 *
	 * Partner p1 = this.droolsParams.getAllPartners().get(1); Partner p2 =
	 * this.droolsParams.getAllPartners().get(2);
	 *
	 * this.droolsParams.getAllVisibilities().clear(); Visibility vis1 =
	 * this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:30:00",
	 * "10/10/2017 06:45:00"); Visibility vis2 = this.stub.createVisibility(0,
	 * "SAT_1", "KIR2", p1.getPartnerId(), "10/10/2017 16:00:00",
	 * "10/10/2017 16:30:00");
	 *
	 * List<Visibility> allVis = new
	 * ArrayList<Visibility>(Arrays.asList(vis1,vis2));
	 *
	 * this.droolsParams.setAllVisibilities(allVis);
	 *
	 * this.droolsInstance = this.du.setUpSession(this.sessionId,
	 * SessionType.premium, this.droolsParams, this.droolsInstance,
	 * this.currentKieSession, "_");
	 *
	 *
	 * Acquisition acq1 = this.du.createParametricAcquisition("acq1",
	 * "10/10/2017 06:00:00", "10/10/2017 06:02:00", "left", "SAT_1");
	 * acq1.setPolarization(Polarization.HH); acq1.setSizeH(600);
	 *
	 * List<String> acquisitionStationIdListP1 = new
	 * ArrayList<String>(Arrays.asList(vis1.getAcqStatId())); UserInfo user1 = new
	 * UserInfo(acquisitionStationIdListP1, false, p1.getPartnerId(), null);
	 * UserInfo user2 = new UserInfo(null, false, p2.getPartnerId(), null);
	 * List<UserInfo> allUserInfoForAcq = new
	 * ArrayList<UserInfo>(Arrays.asList(user1, user2));
	 * acq1.setUserInfo(allUserInfoForAcq); acq1.setPriority(8);
	 *
	 * PriorityQueue elementPriorityAcq1 =
	 * this.du.createPriorityElement(acq1,Polarization.HH);
	 * TreeMap<String,PriorityQueue> orderedPriority = new TreeMap<String,
	 * PriorityQueue>();
	 * orderedPriority.put(acq1.getPriority()+"_"+acq1.getIdTask(),
	 * elementPriorityAcq1);
	 * System.out.println("elementPriorityAcq1 "+elementPriorityAcq1);
	 *
	 * Acquisition acq2 = this.du.createParametricAcquisition("acq2",
	 * "10/10/2017 06:10:00", "10/10/2017 06:11:00", "left", "SAT_1");
	 * acq2.setPolarization(Polarization.HH); acq2.setSizeH(300); List<String>
	 * acquisitionStationIdListP2 = new
	 * ArrayList<String>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));
	 * UserInfo user1Acq2 = new UserInfo(acquisitionStationIdListP2, false,
	 * p1.getPartnerId(), null); List<UserInfo> allUserInfoForAcq2 = new
	 * ArrayList<UserInfo>(Arrays.asList(user1Acq2));
	 * acq2.setUserInfo(allUserInfoForAcq2); acq2.setPriority(2);
	 *
	 * PriorityQueue elementPriorityAcq2 =
	 * this.du.createPriorityElement(acq2,Polarization.HH);
	 * orderedPriority.put(acq2.getPriority()+"_"+acq2.getIdTask(),
	 * elementPriorityAcq2);
	 *
	 * Acquisition acq3 = this.du.createParametricAcquisition("acq3",
	 * "10/10/2017 06:05:00", "10/10/2017 06:05:20", "left", "SAT_1");
	 * acq3.setPolarization(Polarization.HH); acq3.setSizeH(400); List<String>
	 * acquisitionStationIdListP3 = new
	 * ArrayList<String>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));
	 * UserInfo user1Acq3 = new UserInfo(acquisitionStationIdListP3, false,
	 * p1.getPartnerId(), null); List<UserInfo> allUserInfoForAcq3 = new
	 * ArrayList<UserInfo>(Arrays.asList(user1Acq3));
	 * acq3.setUserInfo(allUserInfoForAcq3); acq3.setPriority(0);
	 *
	 * PriorityQueue elementPriorityAcq3 =
	 * this.du.createPriorityElement(acq3,Polarization.HH);
	 * orderedPriority.put(acq3.getPriority()+"_"+acq3.getIdTask(),
	 * elementPriorityAcq3);
	 *
	 * TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap =
	 * new TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>();
	 * ResourceFunctions resFunc = new ResourceFunctions();
	 *
	 * List<Task> allDwlPlanned = new ArrayList<Task>(); for (Map.Entry<String,
	 * PriorityQueue> priority: orderedPriority.entrySet()) { // extract the i-esim
	 * element PriorityQueue currentElement = priority.getValue();
	 * System.out.println("try to create dwl for " +
	 * currentElement.getRelatedAcq().getIdTask());
	 * System.out.println("with priority " +
	 * currentElement.getRelatedAcq().getPriority());
	 *
	 * // create an empty list of downloads associated to the // current elements
	 * List<Task> localDwlAssociatedToElement = new ArrayList<>();
	 *
	 * // populate the list with downloads // associated, if exists
	 * localDwlAssociatedToElement =
	 * this.dwlManagement.downloadWithPriorityQueue(currentElement, droolsParams,
	 * downloadTreeMap, resFunc, acq1.getSatelliteId());
	 *
	 * // add the downloads just created to the list
	 * allDwlPlanned.addAll(localDwlAssociatedToElement); }
	 *
	 * for(int i=0;i<allDwlPlanned.size();i++) { System.out.println("\n allDwl : " +
	 * allDwlPlanned.get(i)); }
	 *
	 * Storage relatedSto = du.createStorage(acq3.getIdTask(),
	 * "10/10/2017 06:05:00", "10/10/2017 06:06:00", acq3.getSatelliteId(), 300,
	 * 300, Polarization.HH); dwlManagement.createDwl(sessionId, currentKieSession,
	 * acq3, relatedSto, droolsParams, resFunc, acq3.getSatelliteId()); }
	 *
	 *
	 * @Test public void testDownloadWithPriorityQueue_Split() throws Exception {
	 * this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
	 *
	 * Partner p1 = this.droolsParams.getAllPartners().get(1); Partner p2 =
	 * this.droolsParams.getAllPartners().get(2);
	 *
	 * this.droolsParams.getAllVisibilities().clear(); Visibility vis1 =
	 * this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00",
	 * "10/10/2017 06:30:00"); List<Visibility> allVis = new
	 * ArrayList<Visibility>(Arrays.asList(vis1));
	 *
	 * this.droolsParams.setAllVisibilities(allVis);
	 *
	 * this.droolsInstance = this.du.setUpSession(this.sessionId,
	 * SessionType.premium, this.droolsParams, this.droolsInstance,
	 * this.currentKieSession, "_"); Acquisition acq =
	 * this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00",
	 * "10/10/2017 06:05:00", "left", "SAT_1");
	 * acq.setPolarization(Polarization.HH); List<String> acquisitionStationIdListP1
	 * = new ArrayList<String>(Arrays.asList(vis1.getAcqStatId())); // List<String>
	 * acquisitionStationIdList, boolean isSubscriber, String // ownerId, String
	 * ugsId)
	 *
	 * UserInfo user1 = new UserInfo(acquisitionStationIdListP1, false,
	 * p1.getPartnerId(), null); UserInfo user2 = new UserInfo(null, false,
	 * p2.getPartnerId(), null); List<UserInfo> allUserInfoForAcq = new
	 * ArrayList<UserInfo>(Arrays.asList(user1, user2));
	 * acq.setUserInfo(allUserInfoForAcq);
	 * System.out.println("partners1 associated to acq : " + p1);
	 * System.out.println("partners2 associated to acq : " + p2);
	 *
	 * PriorityQueue elementPriority = new PriorityQueue(); HashMap<String,
	 * SectorAndVisForPartner> sectorsforPartner = new HashMap<String,
	 * SectorAndVisForPartner>(); sectorsforPartner.put(p2.getPartnerId(), new
	 * SectorAndVisForPartner(null, new ArrayList<SizeOfSectorDwl>(Arrays.asList(new
	 * SizeOfSectorDwl(300, 300, Polarization.HH)))));
	 * sectorsforPartner.put(p1.getPartnerId(), new SectorAndVisForPartner(null, new
	 * ArrayList<SizeOfSectorDwl>(Arrays.asList(new SizeOfSectorDwl(300, 200,
	 * Polarization.HH)))));
	 * elementPriority.setSectorsNeededForPartners(sectorsforPartner);
	 * elementPriority.setRelatedAcq(acq); elementPriority.setPol(Polarization.HH);
	 * TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap =
	 * new TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>>();
	 * ResourceFunctions resFunc = new ResourceFunctions();
	 *
	 * List<Task> allDwlPlanned =
	 * this.dwlManagement.downloadWithPriorityQueue(elementPriority,
	 * this.droolsParams, downloadTreeMap, resFunc, acq.getSatelliteId()); for(int
	 * i=0;i<allDwlPlanned.size();i++) { System.out.println("\n allDwl : " +
	 * allDwlPlanned.get(i)); } }
	 */

	/**
	 * Test insert in I download structure DWL.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testInsertInIDownloadStructure_DWL() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();
		this.droolsParams.getAllPAWS().clear();

		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "COR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "MAT", null, "10/10/2017 08:12:00",
				"10/10/2017 08:16:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", "Partner_2", "10/10/2017 08:14:00",
				"10/10/2017 08:25:00");

		List<Visibility> allVisAsList = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		this.droolsParams.setAllVisibilities(allVisAsList);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Download downloadOrPT = this.du.createDownload("SAT_1", "10/10/2017 08:12:00", "10/10/2017 08:16:00",
				DownlinkStrategy.RETAIN, true);
		downloadOrPT.setAcqStatId("COR");
		downloadOrPT.setContactCounter(0);
		downloadOrPT.setRelatedTaskId("relatedTaskTest");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

		List<Visibility> allVisInOverlapWithTask = this.dwlUtils.findAllVisInOverlapWithDate(
				downloadOrPT.getStartTime(), downloadOrPT.getEndTime(), this.droolsParams.getAllVisibilities(),
				downloadOrPT.getSatelliteId());
		System.out.println("overlap with " + allVisInOverlapWithTask.size());

		assertEquals(0, dwlTreeMap.size());
		this.dwlManagement.insertInIDownloadStructure(downloadOrPT, allVisInOverlapWithTask, dwlTreeMap);
		System.out.println(dwlTreeMap);
		assertEquals(3, dwlTreeMap.size());

		System.out.println(dwlTreeMap);
	}

	/**
	 * Test insert in I download structure P T planned on L 1.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testInsertInIDownloadStructure_PT_PlannedOnL1() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 08:12:00",
				"10/10/2017 08:16:00");
		Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 08:14:00",
				"10/10/2017 08:25:00");

		List<Visibility> allVisAsList = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		this.droolsParams.setAllVisibilities(allVisAsList);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		Date startTimePt = DroolsUtils.createDate("10/10/2017 08:12:00");
		Date endTimePt = DroolsUtils.createDate("10/10/2017 08:16:00");

		PassThrough pt = new PassThrough();
		pt.setSatelliteId("SAT_1");
		pt.setAcquisitionRequestId("ar_for_test");
		pt.setProgrammingRequestId("pr_for_test");
		pt.setStartTime(startTimePt);
		pt.setEndTime(endTimePt);
		pt.setDoublePol(false);
		pt.setIdTask("idTaskTest");

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

		List<Visibility> allVisInOverlapWithTask = this.dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(),
				pt.getEndTime(), this.droolsParams.getAllVisibilities(), pt.getSatelliteId());

		assertEquals(0, dwlTreeMap.size());
		this.dwlManagement.insertInIDownloadStructure(pt, allVisInOverlapWithTask, dwlTreeMap);
		assertEquals(3, dwlTreeMap.size());

		System.out.println(dwlTreeMap);
	}

	/**
	 * Test insert in I download structure P T double pol.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testInsertInIDownloadStructure_PT_Double_Pol() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 08:12:00",
				"10/10/2017 08:16:00");
		Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 08:14:00",
				"10/10/2017 08:25:00");

		List<Visibility> allVisAsList = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		this.droolsParams.setAllVisibilities(allVisAsList);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		Date startTimePt = DroolsUtils.createDate("10/10/2017 08:12:00");
		Date endTimePt = DroolsUtils.createDate("10/10/2017 08:16:00");

		PassThrough pt = new PassThrough();
		pt.setSatelliteId("SAT_1");
		pt.setAcquisitionRequestId("ar_for_test");
		pt.setProgrammingRequestId("pr_for_test");
		pt.setStartTime(startTimePt);
		pt.setEndTime(endTimePt);
		pt.setDoublePol(true);
		pt.setIdTask("idTaskTest");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

		List<Visibility> allVisInOverlapWithTask = this.dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(),
				pt.getEndTime(), this.droolsParams.getAllVisibilities(), pt.getSatelliteId());

		assertEquals(0, dwlTreeMap.size());
		this.dwlManagement.insertInIDownloadStructure(pt, allVisInOverlapWithTask, dwlTreeMap);
		assertEquals(3, dwlTreeMap.size());

		System.out.println(dwlTreeMap);

		List<Task> tasksToRemove = new ArrayList<>();
		tasksToRemove.add(pt);
		DownloadManagement dwlMng = new DownloadManagement();
		dwlMng.removeFromIDownloadStructurePt(tasksToRemove, this.droolsParams, dwlTreeMap);

		System.out.println("after remove : " + dwlTreeMap);
	}

	/**
	 * Test insert in I download structure P T planned on L 2.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testInsertInIDownloadStructure_PT_PlannedOnL2() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 08:12:00",
				"10/10/2017 08:16:00");
		Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 08:14:00",
				"10/10/2017 08:25:00");

		List<Visibility> allVisAsList = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		this.droolsParams.setAllVisibilities(allVisAsList);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		Date startTimePt = DroolsUtils.createDate("10/10/2017 08:12:00");
		Date endTimePt = DroolsUtils.createDate("10/10/2017 08:16:00");

		PassThrough pt = new PassThrough();
		pt.setSatelliteId("SAT_1");
		pt.setAcquisitionRequestId("ar_for_test");
		pt.setProgrammingRequestId("pr_for_test");
		pt.setStartTime(startTimePt);
		pt.setEndTime(endTimePt);
		pt.setDoublePol(false);
		pt.setIdTask("idTaskTest");
		pt.setPlannedOnL2(true);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

		List<Visibility> allVisInOverlapWithTask = this.dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(),
				pt.getEndTime(), this.droolsParams.getAllVisibilities(), pt.getSatelliteId());

		assertEquals(0, dwlTreeMap.size());
		this.dwlManagement.insertInIDownloadStructure(pt, allVisInOverlapWithTask, dwlTreeMap);
		assertEquals(3, dwlTreeMap.size());

		System.out.println(dwlTreeMap);
	}

	/**
	 * Test insert in I download structure PAW.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testInsertInIDownloadStructure_PAW() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 08:12:00",
				"10/10/2017 08:16:00");
		Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 08:14:00",
				"10/10/2017 08:25:00");

		List<Visibility> allVisAsList = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		this.droolsParams.setAllVisibilities(allVisAsList);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Task dummyTask = this.du.createGenericTask("SAT_1", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
		dummyTask.setDummy(true);

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

		List<Visibility> allVisInOverlapWithTask = this.dwlUtils.findAllVisInOverlapWithDate(dummyTask.getStartTime(),
				dummyTask.getEndTime(), this.droolsParams.getAllVisibilities(), dummyTask.getSatelliteId());

		System.out.println("all vis in overlap : " + allVisInOverlapWithTask);
		assertEquals(0, dwlTreeMap.size());
		this.dwlManagement.insertInIDownloadStructure(dummyTask, allVisInOverlapWithTask, dwlTreeMap);
		assertEquals(3, dwlTreeMap.size());

		System.out.println(dwlTreeMap);
	}

	/**
	 * Test remove from I download structure.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testRemoveFromIDownloadStructure() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 08:12:00",
				"10/10/2017 08:16:00");
		Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 08:14:00",
				"10/10/2017 08:25:00");

		List<Visibility> allVisAsList = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		this.droolsParams.setAllVisibilities(allVisAsList);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Download downloadOrPT = this.du.createDownload("SAT_1", "10/10/2017 08:12:00", "10/10/2017 08:16:00",
				DownlinkStrategy.RETAIN, true);
		downloadOrPT.setRelatedTaskId("relatedTaskTest");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = new TreeMap<>();

		List<Visibility> allVisInOverlapWithTask = this.dwlUtils.findAllVisInOverlapWithDate(
				downloadOrPT.getStartTime(), downloadOrPT.getEndTime(), this.droolsParams.getAllVisibilities(),
				downloadOrPT.getSatelliteId());

		assertEquals(0, dwlTreeMap.size());
		this.dwlManagement.insertInIDownloadStructure(downloadOrPT, allVisInOverlapWithTask, dwlTreeMap);
		assertEquals(3, dwlTreeMap.size());

		System.out.println(dwlTreeMap);

		List<Task> dwlToRemove = new ArrayList<>();
		dwlToRemove.add(downloadOrPT);
		this.dwlManagement.removeFromIDownloadStructurePt(dwlToRemove, this.droolsParams, dwlTreeMap);

		System.out.println("download treemap after remove : " + dwlTreeMap);
	}

	/**
	 * Test remove all downloads except P T empty sat.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testRemoveAllDownloadsExceptPT_emptySat() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		Satellite satForTest = this.droolsParams.getAllSat().get(0);
		ResourceFunctions resFunc = new ResourceFunctions();

		System.out.println("download treemap before the delete : " + downloadTreeMap);
		List<Download> allRemovedDownload = this.dwlManagement.removeAllDownloadsExceptPT(satForTest.getSatelliteId(),
				this.droolsParams, downloadTreeMap, resFunc);

		for (int i = 0; i < allRemovedDownload.size(); i++) {
			System.out.println(allRemovedDownload.get(i));
		}

		System.out.println("download treemap after the delete : " + downloadTreeMap);

		assertEquals(0, allRemovedDownload.size());
	}

	/*
	 *
	 * @Test public void testTimePerformanceTest() throws Exception {
	 * this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
	 *
	 * droolsParams.getAllVisibilities().clear();
	 *
	 * StubResources stubRes = new StubResources(); Visibility vis1 =
	 * stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00",
	 * "10/10/2017 06:30:00"); Visibility vis2 = stubRes.createVisibility(1,
	 * "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
	 * Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d",
	 * "10/10/2017 12:00:00", "10/10/2017 12:50:00"); Visibility vis4 =
	 * stubRes.createVisibility(3, "SAT_1", "KIR", null, "10/10/2017 17:59:00",
	 * "10/10/2017 18:02:00"); vis4.setExternal(true); Visibility vis5 =
	 * stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00",
	 * "10/10/2017 06:40:00"); Visibility vis6 = stubRes.createVisibility(5,
	 * "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
	 * vis6.setExternal(true); Visibility vis7 = stubRes.createVisibility(6,
	 * "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00", "10/10/2017 16:57:00");
	 * List<Visibility> allVisForTest = new
	 * ArrayList<Visibility>(Arrays.asList(vis1,vis2,vis3,vis4,vis5,vis6,vis7));
	 *
	 * droolsParams.setAllVisibilities(allVisForTest);
	 * droolsParams.getAllPAWS().clear(); this.droolsInstance =
	 * this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
	 * this.droolsInstance, this.currentKieSession, "_");
	 *
	 * double extraCostLeft = 2; droolsParams.setExtraCostLeft(extraCostLeft);
	 *
	 * Partner p1 = droolsParams.getAllPartners().get(0); Partner p2 =
	 * droolsParams.getAllPartners().get(1);
	 *
	 * System.out.println("p1 before dto1: " + p1);
	 * System.out.println("p2 before dto1: " + p2);
	 *
	 * DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00",
	 * "10/10/2017 18:00:10", "right", "SAT_1"); dto1.setSizeH(330);
	 * dto1.setDtoId("DTO1"); dto1.setImageBIC(3); dto1.setPrType(PRType.PP);
	 * dto1.setPriority(3); List<UserInfo> userInfoList = new ArrayList<UserInfo>();
	 * UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(),
	 * p1.getUgsId()); UserInfo userInfo2 = new UserInfo(null, false,
	 * p2.getPartnerId(), p2.getUgsId()); userInfoList.add(userInfo1);
	 * userInfoList.add(userInfo2); dto1.setUserInfo(userInfoList);
	 *
	 * System.out.println("I'm inserting dto : " + dto1.toString());
	 *
	 * boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1,
	 * sessionId, this.currentKieSession); assertEquals(true, accepted);
	 *
	 *
	 * DTO dto2 = this.du.createSingleDto("10/10/2017 11:57:00",
	 * "10/10/2017 11:57:10", "right", "SAT_1"); dto2.setSizeH(400);
	 * dto2.setDtoId("DTO2"); dto2.setImageBIC(3); dto2.setPrType(PRType.PP);
	 * dto2.setPriority(2);
	 *
	 * accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, sessionId,
	 * this.currentKieSession); assertEquals(true, accepted);
	 *
	 *
	 * DTO dto3 = this.du.createSingleDto("10/10/2017 11:37:00",
	 * "10/10/2017 11:38:50", "right", "SAT_1"); dto3.setSizeH(400);
	 * dto3.setDtoId("DTO3"); dto3.setImageBIC(3); dto3.setPrType(PRType.PP);
	 * dto2.setPriority(4);
	 *
	 * accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, sessionId,
	 * this.currentKieSession); assertEquals(true, accepted);
	 *
	 * Map<String, Task> allTasks =
	 * DroolsOperations.getAllTasksAcceptedAsMap(droolsParams, sessionId,
	 * currentKieSession); for(Map.Entry<String, Task> elements :
	 * allTasks.entrySet()) { System.out.println(elements.getValue()); } }
	 *
	 */
	@Test
	public void testRemoveAllDownloadsExceptPT_drools() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		StubResources stubRes = new StubResources();
		Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");
		Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		Visibility vis4 = stubRes.createVisibility(3, "SAT_1", "KIR", null, "10/10/2017 17:59:00",
				"10/10/2017 18:02:00");
		vis4.setExternal(true);
		Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00",
				"10/10/2017 06:40:00");
		Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00",
				"10/10/2017 18:01:00");
		vis6.setExternal(true);
		Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00",
				"10/10/2017 16:57:00");
		List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7));

		this.droolsParams.setAllVisibilities(allVisForTest);
		this.droolsParams.getAllPAWS().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		double extraCostLeft = 2;
		this.droolsParams.setExtraCostLeft(extraCostLeft);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		System.out.println("p1 before dto1: " + p1);
		System.out.println("p2 before dto1: " + p2);

		DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
		dto1.setSizeH(330);

		dto1.setImageBIC(3);
		dto1.setPtAvailable(true);
		dto1.setPrType(PRType.PP);

		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertEquals(true, accepted);

		// standard acq

		DTO dto2 = this.du.createSingleDto("10/10/2017 17:57:00", "10/10/2017 17:57:10", "right", "SAT_1");
		dto2.setSizeH(400);

		dto2.setImageBIC(3);
		dto2.setPrType(PRType.PP);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertEquals(true, accepted);

		// second pt

		DTO dto3 = this.du.createSingleDto("10/10/2017 17:59:00", "10/10/2017 17:59:50", "right", "SAT_1");
		dto3.setSizeH(400);

		dto3.setImageBIC(3);
		dto3.setPtAvailable(true);
		dto3.setPrType(PRType.PP);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertEquals(true, accepted);
		boolean validCheck = false;
		List<PassThrough> allPt = new ArrayList<>();
		allPt = this.dwlUtils.getAllPt(this.sessionId + "_" + this.currentKieSession, "SAT_1");

		// allPt = DownloadUtils.getAllPt(this.sessionId,
		// this.currentKieSession, "SAT_1");
		System.out.println(allPt);
		assertEquals(allPt.size(), 2);
		if ((allPt.get(0).getIdTask().equalsIgnoreCase(dto3.getDtoId())
				|| allPt.get(0).getIdTask().equalsIgnoreCase(dto1.getDtoId()))
				&& (allPt.get(1).getIdTask().equalsIgnoreCase(dto3.getDtoId())
						|| allPt.get(1).getIdTask().equalsIgnoreCase(dto1.getDtoId()))) {
			validCheck = true;
		}
		assertTrue(validCheck);

		String sessionInstance = DroolsParameters.concatenateSession(this.sessionId, this.currentKieSession);

		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
				.getDownloadsAssociatedToSat("SAT_1");

		System.out.println(dwlTreeMap);
		List<Download> allRemovedDownload = this.dwlManagement.removeAllDownloadsExceptPT("SAT_1", this.droolsParams,
				dwlTreeMap, resFunc);
		System.out.println(allRemovedDownload);

	}

	/**
	 * Test remove all downloads except PT.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testRemoveAllDownloadsExceptPT() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		Visibility vis1ForTest = this.droolsParams.getAllVisibilities().get(0);
		Visibility vis2ForTest = this.droolsParams.getAllVisibilities().get(1);

		/*
		 * modify the start available time for the chosen visibilities to check that the
		 * method under test will be restore the startTime correctly
		 */
		vis1ForTest.setAvailableStartTimeL1(vis1ForTest.getEndTime());
		vis2ForTest.setAvailableStartTimeL1(vis2ForTest.getEndTime());

		Satellite satForTest = this.droolsParams.getAllSat().get(0);

		Download dwlForTest1 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:05:00",
				DownlinkStrategy.DELETE, false);
		Download dwlForTest2 = this.du.createDownload("SAT_1", "17/01/2018 07:15:00", "17/01/2018 07:20:00",
				DownlinkStrategy.DELETE, false);
		Download dwlForTest3 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:05:00",
				DownlinkStrategy.DELETE, false);
		Download dwlForTest4 = this.du.createDownload("SAT_1", "17/01/2018 07:15:00", "17/01/2018 07:20:00",
				DownlinkStrategy.DELETE, false);
		dwlForTest4.setDummy(true);

		PassThrough ptForTest1 = this.du.createPassThrough("SAT_1", "17/01/2018 07:19:00", "17/01/2018 07:21:00");
		Task dummyPaw = this.du.createGenericTask("SAT_1", "17/01/2018 07:22:00", "17/01/2018 07:26:00");

		IDownload dwl1 = new IDownload("task1", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 06:00:00"),
				DroolsUtils.createDate("17/01/2018 06:05:00"), dwlForTest1);
		IDownload pt1 = new IDownload("task2", DownloadLogic.PT, true, DroolsUtils.createDate("17/01/2018 07:00:00"),
				DroolsUtils.createDate("17/01/2018 07:05:00"), ptForTest1);
		IDownload dwl2 = new IDownload("task3", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 07:15:00"),
				DroolsUtils.createDate("17/01/2018 07:20:00"), dwlForTest2);
		IDownload paw1 = new IDownload("task4", DownloadLogic.PAW, true, DroolsUtils.createDate("17/01/2018 08:37:00"),
				DroolsUtils.createDate("17/01/2018 08:38:00"), dummyPaw);

		IDownload dwl3 = new IDownload("task5", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 06:00:00"),
				DroolsUtils.createDate("17/01/2018 06:05:00"), dwlForTest3);
		IDownload pt2 = new IDownload("task6", DownloadLogic.PT, true, DroolsUtils.createDate("17/01/2018 07:00:00"),
				DroolsUtils.createDate("17/01/2018 07:05:00"), ptForTest1);
		IDownload dwl4 = new IDownload("task7", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 07:15:00"),
				DroolsUtils.createDate("17/01/2018 07:20:00"), dwlForTest4);
		IDownload paw2 = new IDownload("task8", DownloadLogic.PAW, true, DroolsUtils.createDate("17/01/2018 08:37:00"),
				DroolsUtils.createDate("17/01/2018 08:38:00"), null);

		TreeMap<Long, IDownload> elementOnLink1 = new TreeMap<>();
		elementOnLink1.put(dwl1.getStartTime().getTime(), dwl1);
		elementOnLink1.put(pt1.getStartTime().getTime(), pt1);
		elementOnLink1.put(dwl2.getStartTime().getTime(), dwl2);
		elementOnLink1.put(paw1.getStartTime().getTime(), paw1);

		TreeMap<Long, IDownload> elementOnLink2 = new TreeMap<>();
		elementOnLink2.put(dwl3.getStartTime().getTime(), dwl3);
		elementOnLink2.put(pt2.getStartTime().getTime(), pt2);
		elementOnLink2.put(dwl4.getStartTime().getTime(), dwl4);
		elementOnLink2.put(paw2.getStartTime().getTime(), paw2);

		TreeMap<String, TreeMap<Long, IDownload>> subTreeMapL1 = new TreeMap<>();
		subTreeMapL1.put("1", elementOnLink1);

		TreeMap<String, TreeMap<Long, IDownload>> subTreeMapL2 = new TreeMap<>();
		subTreeMapL2.put("2", elementOnLink2);
		String vis1IdForSat = DownloadManagement.concatVisId(vis1ForTest.getSatelliteId(), vis1ForTest);
		String vis2IdForSat = DownloadManagement.concatVisId(vis2ForTest.getSatelliteId(), vis2ForTest);

		downloadTreeMap.put(vis1IdForSat, subTreeMapL1);
		downloadTreeMap.put(vis2IdForSat, subTreeMapL2);
		ResourceFunctions resFunc = new ResourceFunctions();

		System.out.println("download treemap before the delete : " + downloadTreeMap);
		List<Download> allRemovedDownload = this.dwlManagement.removeAllDownloadsExceptPT(satForTest.getSatelliteId(),
				this.droolsParams, downloadTreeMap, resFunc);

		for (int i = 0; i < allRemovedDownload.size(); i++) {
			System.out.println(allRemovedDownload.get(i));
		}

		System.out.println("download treemap after the delete : " + downloadTreeMap);

		assertEquals(4, allRemovedDownload.size());
		assertEquals(true, allRemovedDownload.contains(dwlForTest1));
		assertEquals(true, allRemovedDownload.contains(dwlForTest2));
		assertEquals(true, allRemovedDownload.contains(dwlForTest3));
		assertEquals(true, allRemovedDownload.contains(dwlForTest4));
		/*
		 * assert that the modified visibilities are restored to their initial values
		 */
		assertEquals(vis1ForTest.getStartTime(), vis1ForTest.getAvailableStartTimeL1());
		assertEquals(vis1ForTest.getStartTime(), vis1ForTest.getAvailableStartTimeL2());
		assertEquals(vis2ForTest.getStartTime(), vis2ForTest.getAvailableStartTimeL1());
		assertEquals(vis2ForTest.getStartTime(), vis2ForTest.getAvailableStartTimeL2());

	}

	/**
	 * Test find next pt on same vis and same link not found.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testFindNextPtOnSameVisAndSameLink_found_DWL() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00",
				"left", "SAT_1");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		// String relatedToTask, DownloadLogic typeOfDwl, boolean plannedOn,
		// Date startTime, Date stopTime, Task dwlOrPt)
		Date startDwl1 = DroolsUtils.createDate("10/10/2017 06:13:00");
		Date endDwl1 = DroolsUtils.createDate("10/10/2017 06:14:00");

		IDownload idwl1 = new IDownload("acqForTest1", DownloadLogic.DWL, false, startDwl1, endDwl1, null);

		Date startDwl2 = DroolsUtils.createDate("10/10/2017 06:17:00");
		Date endDwl2 = DroolsUtils.createDate("10/10/2017 06:18:00");
		IDownload idwl2 = new IDownload("acqForTest2", DownloadLogic.DWL, false, startDwl2, endDwl2, null);

		Date startDwl3 = DroolsUtils.createDate("10/10/2017 06:21:00");
		Date endDwl3 = DroolsUtils.createDate("10/10/2017 06:24:00");
		IDownload idwl3 = new IDownload("acqForTest3", DownloadLogic.DWL, false, startDwl3, endDwl3, null);

		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");

		TreeMap<Long, IDownload> downloadsByDate = new TreeMap<>();
		downloadsByDate.put(idwl1.getStartTime().getTime(), idwl1);
		downloadsByDate.put(idwl2.getStartTime().getTime(), idwl2);
		downloadsByDate.put(idwl3.getStartTime().getTime(), idwl3);

		TreeMap<String, TreeMap<Long, IDownload>> downloadsOnLink = new TreeMap<>();
		downloadsOnLink.put(vis3.getLinkMoreEmpty(), downloadsByDate);
		String visIdForSat = DownloadManagement.concatVisId(vis3.getSatelliteId(), vis3);

		downloadTreeMap.put(visIdForSat, downloadsOnLink);

		List<Date> dateOfNextPt = this.dwlUtils.findNextPtOnSameVisAndSameLink(acq.getStartTime(), acq.getSatelliteId(),
				vis3, vis3.getLinkMoreEmpty(), downloadTreeMap);
		System.out.println("date of next pt : " + dateOfNextPt);

		// Date expectedDateIsEndOfVis = startDwl1;
		assertEquals(startDwl1, dateOfNextPt.get(0));
		assertEquals(endDwl1, dateOfNextPt.get(1));
	}

	/**
	 * Test find next pt on same vis and same link not found.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testFindNextPtOnSameVisAndSameLink_not_found() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00",
				"left", "SAT_1");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");

		TreeMap<Long, IDownload> downloadsByDate = new TreeMap<>();

		TreeMap<String, TreeMap<Long, IDownload>> downloadsOnLink = new TreeMap<>();
		downloadsOnLink.put(vis3.getLinkMoreEmpty(), downloadsByDate);
		String visIdForSat = DownloadManagement.concatVisId(vis3.getSatelliteId(), vis3);

		downloadTreeMap.put(visIdForSat, downloadsOnLink);

		List<Date> dateOfNextPt = this.dwlUtils.findNextPtOnSameVisAndSameLink(acq.getStartTime(), acq.getSatelliteId(),
				vis3, vis3.getLinkMoreEmpty(), downloadTreeMap);
		System.out.println("date of next pt : " + dateOfNextPt);

		Date expectedDateIsEndOfVis = vis3.getEndTime();
		assertEquals(expectedDateIsEndOfVis, dateOfNextPt.get(0));
		assertEquals(expectedDateIsEndOfVis, dateOfNextPt.get(1));
	}

	/**
	 * Test find next pt on same vis and same link found PAW.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testFindNextPtOnSameVisAndSameLink_found_PAW() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00",
				"left", "SAT_1");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		// String relatedToTask, DownloadLogic typeOfDwl, boolean plannedOn,
		// Date startTime, Date stopTime, Task dwlOrPt)
		Date startPaw = DroolsUtils.createDate("10/10/2017 06:13:00");
		Date endPaw = DroolsUtils.createDate("10/10/2017 06:14:00");

		IDownload idwl1 = new IDownload("acqForTest1", DownloadLogic.PAW, false, startPaw, endPaw, null);

		Date startDwl = DroolsUtils.createDate("10/10/2017 06:17:00");
		Date endDwl = DroolsUtils.createDate("10/10/2017 06:18:00");
		IDownload idwl2 = new IDownload("acqForTest2", DownloadLogic.DWL, false, startDwl, endDwl, null);

		Date startPt = DroolsUtils.createDate("10/10/2017 06:21:00");
		Date endPt = DroolsUtils.createDate("10/10/2017 06:24:00");
		IDownload idwl3 = new IDownload("acqForTest3", DownloadLogic.PT, false, startPt, endPt, null);

		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");

		TreeMap<Long, IDownload> downloadsByDate = new TreeMap<>();
		downloadsByDate.put(idwl1.getStartTime().getTime(), idwl1);
		downloadsByDate.put(idwl2.getStartTime().getTime(), idwl2);
		downloadsByDate.put(idwl3.getStartTime().getTime(), idwl3);

		TreeMap<String, TreeMap<Long, IDownload>> downloadsOnLink = new TreeMap<>();
		downloadsOnLink.put(vis3.getLinkMoreEmpty(), downloadsByDate);

		String contactCounterForVis = DownloadManagement.concatVisId(vis3.getSatelliteId(), vis3);

		downloadTreeMap.put(contactCounterForVis, downloadsOnLink);

		List<Date> dateOfNextPt = this.dwlUtils.findNextPtOnSameVisAndSameLink(acq.getStartTime(), acq.getSatelliteId(),
				vis3, vis3.getLinkMoreEmpty(), downloadTreeMap);
		System.out.println("date of next pt : " + dateOfNextPt);

		assertEquals(startPaw, dateOfNextPt.get(0));
		assertEquals(endPaw, dateOfNextPt.get(1));

	}

	/**
	 * Test find next pt on same vis and same link found PT.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testFindNextPtOnSameVisAndSameLink_found_PT() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00",
				"left", "SAT_1");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		// String relatedToTask, DownloadLogic typeOfDwl, boolean plannedOn,
		// Date startTime, Date stopTime, Task dwlOrPt)
		Date startPaw = DroolsUtils.createDate("10/10/2017 06:28:00");
		Date endPaw = DroolsUtils.createDate("10/10/2017 06:34:00");

		IDownload idwl1 = new IDownload("acqForTest1", DownloadLogic.PAW, false, startPaw, endPaw, null);

		Date startPt = DroolsUtils.createDate("10/10/2017 06:21:00");
		Date endPt = DroolsUtils.createDate("10/10/2017 06:24:00");
		IDownload idwl3 = new IDownload("acqForTest3", DownloadLogic.PT, false, startPt, endPt, null);

		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");

		TreeMap<Long, IDownload> downloadsByDate = new TreeMap<>();
		downloadsByDate.put(idwl1.getStartTime().getTime(), idwl1);
		downloadsByDate.put(idwl3.getStartTime().getTime(), idwl3);

		TreeMap<String, TreeMap<Long, IDownload>> downloadsOnLink = new TreeMap<>();
		downloadsOnLink.put(vis3.getLinkMoreEmpty(), downloadsByDate);
		String contactCounterForVis = DownloadManagement.concatVisId(vis3.getSatelliteId(), vis3);

		downloadTreeMap.put(contactCounterForVis, downloadsOnLink);

		List<Date> dateOfNextPt = this.dwlUtils.findNextPtOnSameVisAndSameLink(acq.getStartTime(), acq.getSatelliteId(),
				vis3, vis3.getLinkMoreEmpty(), downloadTreeMap);
		System.out.println("date of next pt : " + dateOfNextPt);

		assertEquals(startPt, dateOfNextPt.get(0));
		assertEquals(endPt, dateOfNextPt.get(1));

	}

	/**
	 * Test process delete dwl HH.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testProcessDeleteDwl_HH() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 11:10:03", "10/10/2017 11:12:00",
				"left", "SAT_1");
		acq1.setPolarization(Polarization.HH);
		acq1.setImageBIC(20);
		acq1.setSizeH(4000);
		acq1.setSizeV(0);

		PriorityQueue elementPriority = new PriorityQueue();
		HashMap<String, SectorAndVisForPartner> sectorsforPartner = new HashMap<>();
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(0).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(1).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		elementPriority.setSectorsNeededForPartners(sectorsforPartner);
		elementPriority.setRelatedAcq(acq1);
		elementPriority.setPol(acq1.getPolarization());

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();
		ResourceFunctions resFunc = new ResourceFunctions();

		List<Task> allDwlPlanned = this.dwlManagement.downloadWithPriorityQueue(elementPriority, this.droolsParams,
				downloadTreeMap, resFunc, acq1.getSatelliteId());
		List<Task> allDwlDelete = this.dwlManagement.processDeleteDwl(this.droolsParams, resFunc, acq1, allDwlPlanned,
				elementPriority);
		System.out.println(allDwlDelete);
	}

	/**
	 * Test process delete dwl VH.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testProcessDeleteDwl_VH() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00",
				"left", "SAT_1");
		acq1.setPolarization(Polarization.VH);
		acq1.setImageBIC(20);
		acq1.setSizeH(4000);
		acq1.setSizeV(4000);

		PriorityQueue elementPriority = new PriorityQueue();
		HashMap<String, SectorAndVisForPartner> sectorsforPartner = new HashMap<>();
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(0).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(1).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		elementPriority.setSectorsNeededForPartners(sectorsforPartner);
		elementPriority.setRelatedAcq(acq1);
		elementPriority.setPol(acq1.getPolarization());
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();
		ResourceFunctions resFunc = new ResourceFunctions();

		List<Task> allDwlPlanned = this.dwlManagement.downloadWithPriorityQueue(elementPriority, this.droolsParams,
				downloadTreeMap, resFunc, acq1.getSatelliteId());
		this.dwlManagement.processDeleteDwl(this.droolsParams, resFunc, acq1, allDwlPlanned, elementPriority);
	}

	/**
	 * Test process delete dwl HV.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testProcessDeleteDwl_HV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00",
				"left", "SAT_1");
		acq1.setPolarization(Polarization.HV);
		acq1.setImageBIC(20);
		acq1.setSizeH(4000);
		acq1.setSizeV(4000);

		PriorityQueue elementPriority = new PriorityQueue();
		HashMap<String, SectorAndVisForPartner> sectorsforPartner = new HashMap<>();
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(0).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(1).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		elementPriority.setSectorsNeededForPartners(sectorsforPartner);
		elementPriority.setRelatedAcq(acq1);
		elementPriority.setPol(acq1.getPolarization());
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();
		ResourceFunctions resFunc = new ResourceFunctions();

		List<Task> allDwlPlanned = this.dwlManagement.downloadWithPriorityQueue(elementPriority, this.droolsParams,
				downloadTreeMap, resFunc, acq1.getSatelliteId());
		this.dwlManagement.processDeleteDwl(this.droolsParams, resFunc, acq1, allDwlPlanned, elementPriority);
	}

	/**
	 * Test process delete dwl VV.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testProcessDeleteDwl_VV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00",
				"left", "SAT_1");
		acq1.setPolarization(Polarization.VV);
		acq1.setImageBIC(20);
		acq1.setSizeH(4000);
		acq1.setSizeV(0);

		PriorityQueue elementPriority = new PriorityQueue();
		HashMap<String, SectorAndVisForPartner> sectorsforPartner = new HashMap<>();
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(0).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		sectorsforPartner.put(this.droolsParams.getAllPartners().get(1).getPartnerId(), new SectorAndVisForPartner(null,
				new ArrayList<>(Arrays.asList(new SizeOfSectorDwl(300, 100, Polarization.HH)))));
		elementPriority.setSectorsNeededForPartners(sectorsforPartner);
		elementPriority.setRelatedAcq(acq1);
		elementPriority.setPol(acq1.getPolarization());
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		ResourceFunctions resFunc = new ResourceFunctions();
		List<Task> allDwlPlanned = this.dwlManagement.downloadWithPriorityQueue(elementPriority, this.droolsParams,
				downloadTreeMap, resFunc, acq1.getSatelliteId());
		this.dwlManagement.processDeleteDwl(this.droolsParams, resFunc, acq1, allDwlPlanned, elementPriority);
	}

	@Test
	public void testGetAllDwlFromTreeMap() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllVisibilities().clear();
		StubResources stubRes = new StubResources();

		Visibility vis1 = stubRes.createVisibility(0, "SAT_2", "KIR", null, "10/10/2017 11:00:00",
				"10/10/2017 11:30:00");
		Visibility vis2 = stubRes.createVisibility(1, "SAT_2", "KOR", null, "10/10/2017 10:10:00",
				"10/10/2017 11:02:00");
		Visibility vis3 = stubRes.createVisibility(2, "SAT_2", "MAT", null, "10/10/2017 11:02:00",
				"10/10/2017 11:13:00");

		List<Visibility> allVisinOverlap = new ArrayList<>();
		allVisinOverlap.add(vis1);
		allVisinOverlap.add(vis2);
		allVisinOverlap.add(vis3);
		this.droolsParams.setAllVisibilities(allVisinOverlap);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00",
				"left", "SAT_2");

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = resFunc
				.getDownloadsAssociatedToSat("2");
		Download dwl1 = this.du.createDownload("SAT_2", "17/01/2018 11:10:03", "17/01/2018 11:10:03",
				DownlinkStrategy.DELETE, false);
		dwl1.setAcqStatId(vis3.getAcqStatId());
		dwl1.setContactCounter(vis3.getContactCounter());
		dwl1.setRelatedTaskId(acq1.getIdTask());
		this.dwlManagement.insertInIDownloadStructure(dwl1, allVisinOverlap, downloadTreeMap);

		Download dwl2 = this.du.createDownload("SAT_2", "17/01/2018 11:10:03", "17/01/2018 11:10:03",
				DownlinkStrategy.DELETE, true);
		dwl2.setRelatedTaskId(acq1.getIdTask());
		dwl2.setAcqStatId(vis3.getAcqStatId());
		dwl2.setContactCounter(vis3.getContactCounter());
		dwl2.setCarrierL2Selection(true);
		this.dwlManagement.insertInIDownloadStructure(dwl2, allVisinOverlap, downloadTreeMap);

		List<Task> alltasks = new ArrayList<Task>(Arrays.asList(dwl1, dwl2));
		this.dwlManagement.persistDwl(alltasks, downloadTreeMap, this.droolsParams, "2");

		List<Download> allVis = this.dwlManagement.getAllDwlFromTreeMap("2", this.droolsParams, downloadTreeMap);
		System.out.println(allVis);
		assertEquals(2, allVis.size());
		assertEquals(true, allVis.contains(dwl1));
		assertEquals(true, allVis.contains(dwl2));

	}

	@Test
	public void testGetAllDwlListFromTreeMap() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		StubResources stubRes = new StubResources();

		Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 11:00:00",
				"10/10/2017 11:30:00");
		Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 10:10:00",
				"10/10/2017 11:02:00");
		Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 11:02:00",
				"10/10/2017 11:13:00");

		List<Visibility> allVisinOverlap = new ArrayList<>();
		allVisinOverlap.add(vis1);
		allVisinOverlap.add(vis2);
		allVisinOverlap.add(vis3);

		Acquisition acq1 = this.du.createParametricAcquisition("acq1", "17/01/2018 11:10:03", "17/01/2018 11:12:00",
				"left", "SAT_1");

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();
		Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 11:10:03", "17/01/2018 11:10:03",
				DownlinkStrategy.DELETE, false);

		dwl1.setRelatedTaskId(acq1.getIdTask());
		this.dwlManagement.insertInIDownloadStructure(dwl1, allVisinOverlap, downloadTreeMap);

		Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 11:10:03", "17/01/2018 11:10:03",
				DownlinkStrategy.DELETE, true);
		dwl2.setRelatedTaskId(acq1.getIdTask());
		this.dwlManagement.insertInIDownloadStructure(dwl2, allVisinOverlap, downloadTreeMap);
		//
		// List<Task> allVis =
		// dwlManagement.getAllDwlListFromTreeMap(downloadTreeMap);
		// assertEquals(2, allVis.size());
		// assertEquals(true, allVis.contains(dwl1));
		// assertEquals(true, allVis.contains(dwl2));

	}

	@Test
	public void testGetAllPTFromTreeMap() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().clear();

		StubResources stubRes = new StubResources();
		Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00",
				"10/10/2017 06:30:00");
		Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00",
				"10/10/2017 08:15:00");
		Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		Visibility vis4 = stubRes.createVisibility(3, "SAT_1", "KIR", null, "10/10/2017 17:59:00",
				"10/10/2017 18:02:00");
		vis4.setExternal(true);
		Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00",
				"10/10/2017 06:40:00");
		Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00",
				"10/10/2017 18:01:00");
		vis6.setExternal(true);
		Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00",
				"10/10/2017 16:57:00");
		List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7));

		this.droolsParams.setAllVisibilities(allVisForTest);
		this.droolsParams.getAllPAWS().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		double extraCostLeft = 2;
		this.droolsParams.setExtraCostLeft(extraCostLeft);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		System.out.println("p1 before dto1: " + p1);
		System.out.println("p2 before dto1: " + p2);

		// primo pt
		DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
		dto1.setSizeH(330);

		dto1.setImageBIC(3);
		dto1.setPtAvailable(true);
		dto1.setPrType(PRType.PP);

		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertEquals(true, accepted);

		// standard acq

		DTO dto2 = this.du.createSingleDto("10/10/2017 17:57:00", "10/10/2017 17:57:10", "right", "SAT_1");
		dto2.setSizeH(400);

		dto2.setImageBIC(3);
		dto2.setPrType(PRType.PP);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertEquals(true, accepted);

		// second pt

		DTO dto3 = this.du.createSingleDto("10/10/2017 17:59:00", "10/10/2017 17:59:50", "right", "SAT_1");
		dto3.setSizeH(400);
		dto3.setImageBIC(3);
		dto3.setPtAvailable(true);
		dto3.setPrType(PRType.PP);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertEquals(true, accepted);
		String sessionInstance = DroolsParameters.concatenateSession(this.sessionId, this.currentKieSession);

		KieSession kieSession = SessionHandler.getKieSessionsMap().get(sessionInstance);
		ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc
				.getDownloadsAssociatedToSat("SAT_1");

		List<PassThrough> allPtOldMethod = this.dwlManagement.getAllPTFromTreeMap("SAT_1", this.droolsParams,
				dwlTreeMap);
		List<PassThrough> allPtNewMethod = this.dwlUtils.getAllPt(this.sessionId + "_" + this.currentKieSession,
				"SAT_1");

		System.out.println("allPtOldMethod" + allPtOldMethod);
		System.out.println("allPtNewMethod" + allPtNewMethod);
		assertEquals(allPtOldMethod.size(), allPtNewMethod.size());

	}

	// to test : clear visibility
	// to test : add to list only elements not prev processed
	// to test : add to list only elements with isRemovableFlag to true
	// to test : use as submap only the downloads in interval (startTime and
	// stopTime)
	@Test
	public void testGetAllDwlAfterEventDrools() throws Exception {

	}

	/*
	 * @Test public void testRestorePriorityQueueOfRelatedAmount() throws Exception
	 * {
	 *
	 * this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
	 * this.droolsInstance = this.du.setUpSession(this.sessionId,
	 * SessionType.premium, this.droolsParams, this.droolsInstance,
	 * this.currentKieSession, "_");
	 *
	 * Acquisition acq1 = this.du.createParametricAcquisition("acq1",
	 * "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1"); // get the
	 * current active session String sessionIdInstance =
	 * DroolsParameters.concatenateSession(sessionId, currentKieSession);
	 *
	 * KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
	 * kie.insert(acq1); HashMap<String, Acquisition> allAccepted = new
	 * HashMap<String, Acquisition>() ; allAccepted.put(acq1.getIdTask(), acq1);
	 * kie.setGlobal("allAccepted",allAccepted);
	 *
	 *
	 * TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<String,
	 * PriorityQueue>(); PriorityQueue priority = new PriorityQueue();
	 * HashMap<String, SectorAndVisForPartner> sectorsNeededForPartners = new
	 * HashMap<String, SectorAndVisForPartner>(); List<String> allVisForPartner =
	 * null;
	 *
	 * List<SizeOfSectorDwl> sectorsForPartner = new ArrayList<SizeOfSectorDwl>();
	 * SizeOfSectorDwl singleSectors = new
	 * SizeOfSectorDwl(1000,100,Polarization.HH);
	 * sectorsForPartner.add(singleSectors); String downloadKey =
	 * dwlManagement.getPriorityKey(acq1);
	 *
	 * SectorAndVisForPartner sectors = new SectorAndVisForPartner(allVisForPartner,
	 * sectorsForPartner);
	 *
	 * sectorsNeededForPartners.put("Partner_1", sectors);
	 * priority.setSectorsNeededForPartners(sectorsNeededForPartners);
	 * downloadPriority.put(downloadKey, priority); Download dwl1 =
	 * this.du.createDownload("SAT_1", "10/10/2017 17:50:00", "10/10/2017 17:52:00",
	 * DownlinkStrategy.DELETE, true); dwl1.setRelatedTaskId("acq1"); List<String>
	 * partnersToRestore = new ArrayList<String>();
	 * partnersToRestore.add("Partner_1"); dwl1.setUgsOwnerList(partnersToRestore);
	 * dwl1.setDownloadedSize(300);
	 *
	 * assertEquals(100,
	 * downloadPriority.get(downloadKey).getSectorsNeededForPartners().get(
	 * "Partner_1").getSectorsForPartner().get(0).getResidualSize());
	 *
	 * priority = dwlUtils.restorePriorityQueueOfRelatedAmount(downloadPriority,
	 * dwl1,allAccepted, 1);
	 * assertEquals(400,priority.getSectorsNeededForPartners().get("Partner_1").
	 * getSectorsForPartner().get(0).getResidualSize());
	 *
	 * }
	 *
	 *
	 * @Test public void
	 * testRestorePriorityQueueOfRelatedAmount_decrement_not_exists() throws
	 * Exception { this.du.setUpDrools(this.sessionId, this.droolsParams,
	 * this.droolsInstance); this.droolsInstance =
	 * this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
	 * this.droolsInstance, this.currentKieSession, "_");
	 *
	 * Acquisition acq1 = this.du.createParametricAcquisition("acq1",
	 * "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1"); // get the
	 * current active session String sessionIdInstance =
	 * DroolsParameters.concatenateSession(sessionId, currentKieSession); String
	 * priorityKey = dwlManagement.getPriorityKey(acq1);
	 *
	 * KieSession kie = SessionHandler.getKieSessionsMap().get(sessionIdInstance);
	 * kie.insert(acq1); HashMap<String, Acquisition> allAccepted = new
	 * HashMap<String, Acquisition>() ; allAccepted.put(acq1.getIdTask(), acq1);
	 * kie.setGlobal("allAccepted",allAccepted);
	 *
	 * TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<String,
	 * PriorityQueue>(); PriorityQueue priority = new PriorityQueue();
	 * HashMap<String, SectorAndVisForPartner> sectorsNeededForPartners = new
	 * HashMap<String, SectorAndVisForPartner>(); List<String> allVisForPartner =
	 * null;
	 *
	 * List<SizeOfSectorDwl> sectorsForPartner = new ArrayList<SizeOfSectorDwl>();
	 * SizeOfSectorDwl singleSectors = new
	 * SizeOfSectorDwl(1000,100,Polarization.HH);
	 * sectorsForPartner.add(singleSectors);
	 *
	 * SectorAndVisForPartner sectors = new SectorAndVisForPartner(allVisForPartner,
	 * sectorsForPartner);
	 *
	 * sectorsNeededForPartners.put("Partner_1", sectors);
	 * priority.setSectorsNeededForPartners(sectorsNeededForPartners);
	 * downloadPriority.put(priorityKey, priority); Download dwl1 =
	 * this.du.createDownload("SAT_1", "10/10/2017 17:50:00", "10/10/2017 17:52:00",
	 * DownlinkStrategy.DELETE, true); dwl1.setRelatedTaskId("acq1"); List<String>
	 * partnersToRestore = new ArrayList<String>();
	 * partnersToRestore.add("Partner_1"); dwl1.setUgsOwnerList(partnersToRestore);
	 * dwl1.setDownloadedSize(300);
	 *
	 * assertEquals(100,
	 * downloadPriority.get(priorityKey).getSectorsNeededForPartners().get(
	 * "Partner_1").getSectorsForPartner().get(0).getResidualSize());
	 *
	 * priority = dwlUtils.restorePriorityQueueOfRelatedAmount(downloadPriority,
	 * dwl1,allAccepted,1); assertEquals(400,
	 * priority.getSectorsNeededForPartners().get("Partner_1").
	 * getSectorsForPartner().get(0).getResidualSize());
	 *
	 * }
	 */

	@Test
	public void testCreateDWL() throws Exception {

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);

		assertTrue(inserted);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		// acq = DroolsQueries.getAcqWithId(sessionId, currentKieSession,
		// dto2.getDtoId());
		// sto = dq.getStoWithGivenid(sessionId, currentKieSession,
		// droolsParams, dto2.getDtoId());
		// dwlMng.createDwl(sessionId, currentKieSession, acq, sto,
		// droolsParams, resFunc, dto2.getSatelliteId());

		DTO dto3 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
		inserted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(inserted);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DTO dto4 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");

		dto4.setPriority(2);
		inserted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
		// assertFalse(inserted);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId,
				this.currentKieSession);
		System.out.println("rejected : " + acqRejected);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void testGetAllFromTreeMap() throws Exception {

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

		Visibility vis1ForTest = this.droolsParams.getAllVisibilities().get(0);
		Visibility vis2ForTest = this.droolsParams.getAllVisibilities().get(1);

		/*
		 * modify the start available time for the chosen visibilities to check that the
		 * method under test will be restore the startTime correctly
		 */
		vis1ForTest.setAvailableStartTimeL1(vis1ForTest.getEndTime());
		vis2ForTest.setAvailableStartTimeL1(vis2ForTest.getEndTime());

		Satellite satForTest = this.droolsParams.getAllSat().get(0);
		System.out.println(satForTest);
		Download dwlForTest1 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:05:00",
				DownlinkStrategy.DELETE, false);
		Download dwlForTest2 = this.du.createDownload("SAT_1", "17/01/2018 07:15:00", "17/01/2018 07:20:00",
				DownlinkStrategy.DELETE, false);
		Download dwlForTest3 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:05:00",
				DownlinkStrategy.DELETE, false);
		Download dwlForTest4 = this.du.createDownload("SAT_1", "17/01/2018 07:15:00", "17/01/2018 07:20:00",
				DownlinkStrategy.DELETE, false);
		dwlForTest4.setDummy(true);

		PassThrough ptForTest1 = this.du.createPassThrough("SAT_1", "17/01/2018 07:19:00", "17/01/2018 07:21:00");
		Task dummyPaw = this.du.createGenericTask("SAT_1", "17/01/2018 07:22:00", "17/01/2018 07:26:00");

		IDownload dwl1 = new IDownload("task1", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 06:00:00"),
				DroolsUtils.createDate("17/01/2018 06:05:00"), dwlForTest1);
		IDownload pt1 = new IDownload("task2", DownloadLogic.PT, true, DroolsUtils.createDate("17/01/2018 07:00:00"),
				DroolsUtils.createDate("17/01/2018 07:05:00"), ptForTest1);
		IDownload dwl2 = new IDownload("task3", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 07:15:00"),
				DroolsUtils.createDate("17/01/2018 07:20:00"), dwlForTest2);
		IDownload paw1 = new IDownload("task4", DownloadLogic.PAW, true, DroolsUtils.createDate("17/01/2018 08:37:00"),
				DroolsUtils.createDate("17/01/2018 08:38:00"), dummyPaw);

		IDownload dwl3 = new IDownload("task5", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 06:00:00"),
				DroolsUtils.createDate("17/01/2018 06:05:00"), dwlForTest3);
		IDownload pt2 = new IDownload("task6", DownloadLogic.PT, true, DroolsUtils.createDate("17/01/2018 07:00:00"),
				DroolsUtils.createDate("17/01/2018 07:05:00"), ptForTest1);
		IDownload dwl4 = new IDownload("task7", DownloadLogic.DWL, true, DroolsUtils.createDate("17/01/2018 07:15:00"),
				DroolsUtils.createDate("17/01/2018 07:20:00"), dwlForTest4);
		IDownload paw2 = new IDownload("task8", DownloadLogic.PAW, true, DroolsUtils.createDate("17/01/2018 08:37:00"),
				DroolsUtils.createDate("17/01/2018 08:38:00"), null);

		TreeMap<Long, IDownload> elementOnLink1 = new TreeMap<>();
		elementOnLink1.put(dwl1.getStartTime().getTime(), dwl1);
		elementOnLink1.put(pt1.getStartTime().getTime(), pt1);
		elementOnLink1.put(dwl2.getStartTime().getTime(), dwl2);
		elementOnLink1.put(paw1.getStartTime().getTime(), paw1);

		TreeMap<Long, IDownload> elementOnLink2 = new TreeMap<>();
		elementOnLink2.put(dwl3.getStartTime().getTime(), dwl3);
		elementOnLink2.put(pt2.getStartTime().getTime(), pt2);
		elementOnLink2.put(dwl4.getStartTime().getTime(), dwl4);
		elementOnLink2.put(paw2.getStartTime().getTime(), paw2);

		TreeMap<String, TreeMap<Long, IDownload>> subTreeMapL1 = new TreeMap<>();
		subTreeMapL1.put("1", elementOnLink1);

		TreeMap<String, TreeMap<Long, IDownload>> subTreeMapL2 = new TreeMap<>();
		subTreeMapL2.put("2", elementOnLink2);
		String vis1IdForSat = DownloadManagement.concatVisId(vis1ForTest.getSatelliteId(), vis1ForTest);
		String vis2IdForSat = DownloadManagement.concatVisId(vis2ForTest.getSatelliteId(), vis2ForTest);

		downloadTreeMap.put(vis1IdForSat, subTreeMapL1);
		downloadTreeMap.put(vis2IdForSat, subTreeMapL2);

		List<Download> returnedDwl = this.dwlManagement.getAllDwlFromTreeMap("1", this.droolsParams, downloadTreeMap);
		System.out.println(returnedDwl);
		System.out.println(returnedDwl.size());

		this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
	}

	@Test
	public void testTryToPlanOnVis_noSpaceInVis() throws Exception {
		List<Download> allDwlPlanned = new ArrayList<>();
		// allDwlPlanned = dwlManagement.tryToPlanOnVis(elementPriority,
		// currentVis, partner, residualSize, elementSize, localDownloads,
		// downloadTreeMap, droolsParams)
	}

	@Test
	public void testTryToPlanOnVis_plannedSingleLink() throws Exception {
		List<Download> allDwlPlanned = new ArrayList<>();
		// allDwlPlanned = dwlManagement.tryToPlanOnVis(elementPriority,
		// currentVis, partner, residualSize, elementSize, localDownloads,
		// downloadTreeMap, droolsParams)
	}

	@Test
	public void testTryToPlanOnVis_PlannedBothLink() throws Exception {
		List<Download> allDwlPlanned = new ArrayList<>();
		// allDwlPlanned = dwlManagement.tryToPlanOnVis(elementPriority,
		// currentVis, partner, residualSize, elementSize, localDownloads,
		// downloadTreeMap, droolsParams)
	}

	@Test
	public void testTryToPlanOnVis_plannedRetain() throws Exception {
		List<Download> allDwlPlanned = new ArrayList<>();
		// allDwlPlanned = dwlManagement.tryToPlanOnVis(elementPriority,
		// currentVis, partner, residualSize, elementSize, localDownloads,
		// downloadTreeMap, droolsParams)
	}

	@Test
	public void testConverDateFromLong() throws Exception {
		Long now = System.currentTimeMillis();

		System.out.println("current time :" + new Date(now));
		Date nowDate = DownloadManagement.converDateFromLong(now);
		System.out.println("now :" + now);

		System.out.println("nowDate :" + nowDate);
	}

	@Test
	public void testAddMillisecToDate() throws Exception {
		Date start = DroolsUtils.createDate("17/01/2018 06:00:00.020");
		Date nowDate = DownloadManagement.addMillisecToDate(start, 10000l);
		System.out.println(nowDate);
	}

	@Test
	public void testCheckDownloadConstraintOnVis_PreviousIsPassThrough() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(400);
		dto1.setPtAvailable(true);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);
		Date start = DroolsUtils.createDate("10/10/2017 18:00:00.000");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, false, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);

		System.out.println(returnedDate);
	}

	@Test
	public void testCheckDownloadConstraintOnVis_PreviousIsRetain() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);
		Date start = DroolsUtils.createDate("10/10/2017 18:00:00.000");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, false, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);

		System.out.println(returnedDate);
	}

	@Test
	public void testCheckDownloadConstraintOnVis_PreviousIsASimpleDownload() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);
		Date start = DroolsUtils.createDate("10/10/2017 18:00:00.000");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, false, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);

		System.out.println(returnedDate);
	}

	@Test
	public void testCheckDownloadConstraintOnVis_NotExistPrevious() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);
		Date start = DroolsUtils.createDate("10/10/2017 18:00:00.000");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, false, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);

		System.out.println(returnedDate);
	}

	@Test
	public void testCheckDownloadConstraintOnVis_DownloadNOTCloserThan125ms() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);

		// DWL1 18:00:00.000 - 18:00:49.230 L1
		// DWL2 18:00:00.125 - 18:00:45.355 L2
		Date start = DroolsUtils.createDate("10/10/2017 18:00:45.355");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, false, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);
		Date expectedDate = DroolsUtils.createDate("10/10/2017 18:00:45.355");

		System.out.println(returnedDate);
		assertEquals(expectedDate, returnedDate);
	}

	@Test
	public void testCheckDownloadConstraintOnVis_DownloadCloserThan125ms() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();

		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(4000);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDwlFunctionAssociatedToSat("1");
		System.out.println(downloadTreeMap2);
		DTO dto2 = this.du.createSingleDto("10/10/2017 18:01:00", "10/10/2017 18:01:50", "right", "SAT_1");
		dto2.setPol(Polarization.HV);
		dto2.setPtAvailable(true);
		dto2.setSizeH(400);
		dto2.setSizeV(400);

		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 17:01:00", "10/10/2017 17:01:50", "right", "SAT_1");
		dto3.setPol(Polarization.HV);
		dto3.setSizeH(400);
		dto3.setSizeV(400);

		System.out.println("I'm inserting dto : " + dto3.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);

		// DWL1 18:00:00.000 - 18:00:49.230 L1
		// DWL2 18:00:00.125 - 18:00:45.355 L2

		Date start = DroolsUtils.createDate("10/10/2017 18:01:00.100");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, true, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);
		Date expectedDate = DroolsUtils.createDate("10/10/2017 18:01:00.225");

		System.out.println(returnedDate);
		assertEquals(expectedDate.getTime(), returnedDate.getTime());
	}

	@Test
	public void testCheckDownloadConstraintOnVis_DownloadCloserThan125ms_beforeAvailableTime() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPAWS().clear();
		Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00",
				"10/10/2017 18:21:00");

		List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
		this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1")
				.get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
		for (int i = 0; i < pdht.getMMList().size(); i++) {
			pdht.getMMList().get(i).setFreeSectors(1000);
		}

		DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto1.toString());

		boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(inserted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:30", "right", "SAT_1");
		dto2.setPol(Polarization.HH);
		dto2.setSizeH(400);
		System.out.println("I'm inserting dto : " + dto2.toString());

		inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(inserted);
		TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc
				.getDownloadsAssociatedToSat("1");

		System.out.println(downloadTreeMap2);

		// DWL1 18:00:00.000 - 18:00:49.230 L1
		// DWL2 18:00:00.125 - 18:00:45.355 L2

		Date start = DroolsUtils.createDate("10/10/2017 18:00:49.300");
		DownloadManagement dwlMng = new DownloadManagement();
		Date returnedDate = dwlMng.checkDownloadConstraintOnVis(start, true, downloadTreeMap2, vis4, "1", 125,
				this.droolsParams);
		Date expectedDate = DroolsUtils.createDate("10/10/2017 18:00:49.480");

		System.out.println(returnedDate);
		assertEquals(expectedDate, returnedDate);
	}

	@Test
	public void downloadTest_PDHT() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		this.droolsParams.getAllPDHT().get(0).setFreeMemory(50000);
		this.droolsParams.getAllPDHT().get(0).setCapacity(null);

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertEquals(true, accepted);

		Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId,
				this.currentKieSession);
		assertEquals(0, rejected.size());

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		System.out.println("all tasks : " + allTasks.size());
		// assertEquals(4, allTasks.size());

	}

	/**
	 * Download test.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void downloadTest_PDHT_noSpace() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllPDHT().get(0).setFreeMemory(0);
		this.droolsParams.getAllPDHT().get(0).setCapacity(null);

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertEquals(false, accepted);

		Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId,
				this.currentKieSession);
		boolean containReason = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected,
				ReasonOfReject.noSpaceInPdht);
		assertEquals(true, containReason);
	}

	/**
	 * Download test.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void downloadTest_double_pol() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
		dto1.setPol(Polarization.VH);
		dto1.setSizeH(2000);
		dto1.setSizeV(2000);
		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

	}

	/**
	 * Download test.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void downloadTest() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DTO dto3 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DTO dto4 = this.du.createSingleDto("10/10/2017 10:25:00", "10/10/2017 10:25:10", "left", "SAT_2");
		this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DroolsOperations.retractSingleAcq(this.droolsParams, dto4.getDtoId(), this.sessionId, this.currentKieSession,
				null);

		DTO dto5 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		DTO dto6 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

		DTO dto7 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:20:10", "left", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

		DTO dto8 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:00:10", "left", "SAT_2");
		this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

		DTO dto9 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:10:10", "right", "SAT_1");
		this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

		Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId,
				this.currentKieSession);
		System.out.println("rejected : " + acqRejected);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		System.out.println("current session : " + this.currentKieSession);
		System.out.println("--------------------------------------------");
		System.out.println(this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1"));

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task SAT : " + elements.getValue());
		}

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	@Test
	public void downloadTest_Partial_initPlan_doublePol() throws Exception {
		this.sessionId = "downloadTest_Partial_initPlan_doublePol";

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00",
				"10/10/2017 19:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setPol(Polarization.H_V);
		dto1.setSizeV(400);
		dto1.setSizeH(400);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		List<Download> allDwlassoc = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlassoc.size(); i++) {
			System.out.println(allDwlassoc.get(i));
		}
		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(400);
		dto2.setSizeH(400);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(400);
		dto3.setSizeH(400);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.filterTasksForMh(allTasks, this.droolsParams);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "downloadTest_Partial_initPlan_doublePol_InitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 19:30:00",
				"10/10/2017 19:59:00");
		allVis = new ArrayList<>(Arrays.asList(vis2, vis3, vis4));
		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);
		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00",
				"10/10/2017 19:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_HV_singlePartner() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00",
				"10/10/2017 19:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HV);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_HV_totalRetain() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 07:45:00", "10/10/2017 07:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HV);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false,
		// p2.getPartnerId(),p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		TreeMap<String, Storage> allProcessedSto = resFunc.getStoragesAssociatedToSat("SAT_1");
		Acquisition acq = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId,
				this.currentKieSession);
		DroolsQueries dq = new DroolsQueries();

		// get the storage previously inserted relative to the current
		// acq
		Storage relatedSto = dq.getStoWithGivenid(allProcessedSto, acq.getId());

		List<Download> allDwlAssociatedToSto = new ArrayList<>();
		this.dwlManagement.initPlanDownload(acq, relatedSto, allDwlAssociatedToSto, this.droolsParams,
				downloadPriority);
		downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");

		PriorityQueue priorityElement = downloadPriority.firstEntry().getValue();
		assertEquals(acq.getIdTask(), priorityElement.getRelatedAcq().getIdTask());

		List<SizeOfSectorDwl> sectorsForPartner = priorityElement.getSectorsNeededForPartners().get(p1.getPartnerId())
				.getSectorsForPartner();
		assertEquals(2, sectorsForPartner.size());
		SizeOfSectorDwl allSectorsForPolH = getSectorsForPolarization(sectorsForPartner, Polarization.HH);
		SizeOfSectorDwl allSectorsForPolV = getSectorsForPolarization(sectorsForPartner, Polarization.VV);

		assertEquals(4000, allSectorsForPolH.getResidualSize());
		assertEquals(4000, allSectorsForPolV.getResidualSize());

		System.out.println(downloadPriority);

	}

	@Test
	public void downloadTest_Partial_initPlan_HV_partialRetainH() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 07:45:00", "10/10/2017 07:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HV);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false,
		// p2.getPartnerId(),p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		TreeMap<String, Storage> allProcessedSto = resFunc.getStoragesAssociatedToSat("SAT_1");
		Acquisition acq = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId,
				this.currentKieSession);
		DroolsQueries dq = new DroolsQueries();

		// get the storage previously inserted relative to the current
		// acq
		Storage relatedSto = dq.getStoWithGivenid(allProcessedSto, acq.getId());

		List<Download> allDwlAssociatedToSto = new ArrayList<>();
		this.dwlManagement.initPlanDownload(acq, relatedSto, allDwlAssociatedToSto, this.droolsParams,
				downloadPriority);
		downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");

		PriorityQueue priorityElement = downloadPriority.firstEntry().getValue();
		assertEquals(acq.getIdTask(), priorityElement.getRelatedAcq().getIdTask());

		List<SizeOfSectorDwl> sectorsForPartner = priorityElement.getSectorsNeededForPartners().get(p1.getPartnerId())
				.getSectorsForPartner();
		assertEquals(2, sectorsForPartner.size());
		SizeOfSectorDwl allSectorsForPolH = getSectorsForPolarization(sectorsForPartner, Polarization.HH);
		SizeOfSectorDwl allSectorsForPolV = getSectorsForPolarization(sectorsForPartner, Polarization.VV);

		assertEquals(4000, allSectorsForPolH.getResidualSize());
		assertEquals(4000, allSectorsForPolV.getResidualSize());

		System.out.println(downloadPriority);

	}

	@Test
	public void downloadTest_Partial_initPlan_HV_partialRetainV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 07:45:00", "10/10/2017 07:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HV);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false,
		// p2.getPartnerId(),p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		TreeMap<String, Storage> allProcessedSto = resFunc.getStoragesAssociatedToSat("SAT_1");
		Acquisition acq = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId,
				this.currentKieSession);
		DroolsQueries dq = new DroolsQueries();

		// get the storage previously inserted relative to the current
		// acq
		Storage relatedSto = dq.getStoWithGivenid(allProcessedSto, acq.getId());
		List<String> allPartners = new ArrayList<String>(Arrays.asList(p1.getPartnerId()));
		downloadPriority.clear();
		List<Download> allDwlAssociatedToSto = new ArrayList<>();
		Download dwl1 = du.createDownload("SAT_1", "10/10/2017 07:45:00", "10/10/2017 07:45:00",
				DownlinkStrategy.DELETE, false);
		dwl1.setDownloadedSize(4000);
		dwl1.setPol(Polarization.HH);
		dwl1.setRelatedTaskId(acq.getIdTask());
		dwl1.setUgsOwnerList(allPartners);

		Download dwl2 = du.createDownload("SAT_1", "10/10/2017 07:45:00", "10/10/2017 07:45:00",
				DownlinkStrategy.RETAIN, false);
		dwl2.setDownloadedSize(1000);
		dwl2.setRelatedTaskId(acq.getIdTask());
		dwl2.setPol(Polarization.VV);
		dwl2.setUgsOwnerList(allPartners);
		allDwlAssociatedToSto.add(dwl1);
		allDwlAssociatedToSto.add(dwl2);

		this.dwlManagement.initPlanDownload(acq, relatedSto, allDwlAssociatedToSto, this.droolsParams,
				downloadPriority);
		downloadPriority = resFunc.getDownloadPriorityQueueForSat("SAT_1");

		PriorityQueue priorityElement = downloadPriority.firstEntry().getValue();
		assertEquals(acq.getIdTask(), priorityElement.getRelatedAcq().getIdTask());

		List<SizeOfSectorDwl> sectorsForPartner = priorityElement.getSectorsNeededForPartners().get(p1.getPartnerId())
				.getSectorsForPartner();
		System.out.println(sectorsForPartner);
		assertEquals(1, sectorsForPartner.size());

		SizeOfSectorDwl allSectorsForPolV = getSectorsForPolarization(sectorsForPartner, Polarization.VV);
		SizeOfSectorDwl allSectorsForPolH = getSectorsForPolarization(sectorsForPartner, Polarization.HH);

		assertEquals(3000, allSectorsForPolV.getResidualSize());
		assertTrue(allSectorsForPolH == null);

		System.out.println(downloadPriority);

	}

	/**
	 * @param sectorsForPartner
	 * @param hh
	 * @return
	 */
	private SizeOfSectorDwl getSectorsForPolarization(List<SizeOfSectorDwl> sectorsForPartner, Polarization pol) {
		SizeOfSectorDwl sectors = null;
		for (int i = 0; i < sectorsForPartner.size(); i++) {
			if (sectorsForPartner.get(i).getPol().compareTo(pol) == 0) {
				sectors = sectorsForPartner.get(i);
				break;
			}
		}
		return sectors;
	}

	@Test
	public void downloadTest_Partial_initPlan_H_V_singlePartner_totalRetain() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.H_V);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.RETAIN);
		assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.RETAIN);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
		assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_H_V_singlePartner_partialRetainH() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00",
				"10/10/2017 11:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(1000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
		dto2.setPol(Polarization.H_V);
		dto2.setSizeH(4000);
		dto2.setSizeV(1900);

		dto2.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
		assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.RETAIN);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());

		DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_1");
		dto3.setPol(Polarization.H_V);
		dto3.setSizeH(4000);
		dto3.setSizeV(1900);

		dto3.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto3.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_H_V_singlePartner_partialRetainV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00.800",
				"10/10/2017 07:16:00.800");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 18:10:00",
				"10/10/2017 18:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00",
				"10/10/2017 19:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 07:10:00.800", "10/10/2017 07:10:50.800", "right", "SAT_1");
		dto1.setPol(Polarization.H_V);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:50:00.800", "10/10/2017 06:50:50.800", "right", "SAT_1");
		dto2.setPol(Polarization.H_V);
		dto2.setSizeH(4000);
		dto2.setSizeV(4000);

		dto2.setPreferredVis(allVisId);

		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_H_V_singlePartner_prova() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00.800",
				"10/10/2017 07:16:00.800");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 18:10:00",
				"10/10/2017 18:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00",
				"10/10/2017 19:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 07:10:00.800", "10/10/2017 07:10:50.800", "right", "SAT_1");
		dto1.setPol(Polarization.H_V);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:50:00.800", "10/10/2017 06:50:50.800", "right", "SAT_1");
		dto2.setPol(Polarization.H_V);
		dto2.setSizeH(4000);
		dto2.setSizeV(4000);

		dto2.setPreferredVis(allVisId);

		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	@Test
	public void testPriority() {
		TreeMap<String, Integer> priority = new TreeMap<>();
		String p1 = "0_2_0000000015_61";
		String p2 = "-1_2_0000000015_61";
		String p3 = "0_2_0000000011_61";
		String p4 = "3_2_0000000015_61";
		String p5 = "2_2_0000000015_62";
		priority.put(p1, 0);
		priority.put(p2, 1);
		priority.put(p3, 2);
		priority.put(p1, 3);
		priority.put(p4, 4);
		priority.put(p5, 5);

		System.out.println(priority);

	}

	@Test
	public void downloadTest_downloadPriority() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00",
				"10/10/2017 11:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(1000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
		dto2.setPol(Polarization.V_H);
		dto2.setSizeH(4000);
		dto2.setSizeV(1900);

		dto2.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.RETAIN, allDwlForAcq.get(0).getPacketStoreStrategy());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(1).getPacketStoreStrategy());
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
		PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
		System.out.println(pdhtSat1);
		System.out.println(pdhtSat2);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPDHT().clear();

		this.droolsParams.getAllPDHT().add(pdhtSat1);
		this.droolsParams.getAllPDHT().add(pdhtSat2);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(0).getPacketStoreStrategy());

		DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_1");
		dto3.setPol(Polarization.H_V);
		dto3.setSizeH(4000);
		dto3.setSizeV(1900);

		dto3.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto3.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_H_V_singlePartner_totalDwl_HV() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00",
				"10/10/2017 11:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(1000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}

		Download dwlForDto1 = allDwlForAcq.get(0);
		assertEquals(DroolsUtils.createDate("10/10/2017 11:10:00").getTime(), dwlForDto1.getStartTime().getTime());

		assertEquals(1, dwlForDto1.getInitialSector());
		assertEquals(1001, dwlForDto1.getFinalSector());
		assertEquals(DownlinkStrategy.DELETE, dwlForDto1.getPacketStoreStrategy());

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
		dto2.setPol(Polarization.HV);
		dto2.setSizeH(552);
		dto2.setSizeV(552);

		dto2.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(0).getPacketStoreStrategy());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(1).getPacketStoreStrategy());
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
		PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
		System.out.println(pdhtSat1);
		System.out.println(pdhtSat2);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPDHT().clear();

		this.droolsParams.getAllPDHT().add(pdhtSat1);
		this.droolsParams.getAllPDHT().add(pdhtSat2);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(0, allDwlForAcq.size());
		// assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(0).getPacketStoreStrategy());

		DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_1");
		dto3.setPol(Polarization.H_V);
		dto3.setSizeH(4000);
		dto3.setSizeV(1900);

		dto3.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto3.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto3.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);
		assertEquals(0, allDwlForAcq.size());

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_V_H_singlePartner_partialRetain() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00",
				"10/10/2017 11:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(1000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
		dto2.setPol(Polarization.V_H);
		dto2.setSizeH(4000);
		dto2.setSizeV(1900);

		dto2.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.RETAIN, allDwlForAcq.get(0).getPacketStoreStrategy());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(1).getPacketStoreStrategy());
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
		PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
		System.out.println(pdhtSat1);
		System.out.println(pdhtSat2);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPDHT().clear();

		this.droolsParams.getAllPDHT().add(pdhtSat1);
		this.droolsParams.getAllPDHT().add(pdhtSat2);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(0).getPacketStoreStrategy());

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_V_H_singlePartner_2() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00",
				"10/10/2017 11:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:20:00");
		Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT2", null, "10/10/2017 19:00:00",
				"10/10/2017 19:20:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(1000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:10", "left", "SAT_1");
		dto2.setPol(Polarization.HH_VV);
		dto2.setSizeH(552);
		dto2.setSizeV(552);

		dto2.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(0, allDwlForAcq.size());
		// assertEquals(DownlinkStrategy.RETAIN,allDwlForAcq.get(0).getPacketStoreStrategy());
		// assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(1).getPacketStoreStrategy());
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
		PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
		System.out.println(pdhtSat1);
		System.out.println(pdhtSat2);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsParams.getAllPDHT().clear();

		this.droolsParams.getAllPDHT().add(pdhtSat1);
		this.droolsParams.getAllPDHT().add(pdhtSat2);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);
		this.droolsParams.getAllVisibilities().add(vis4);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		DTO dto3 = this.du.createSingleDto("10/10/2017 18:55:00", "10/10/2017 18:56:00", "left", "SAT_1");
		dto3.setPol(Polarization.HH_VV);
		dto3.setSizeH(552);
		dto3.setSizeV(552);

		dto3.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto3.setUserInfo(userInfoList);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		// assertTrue(accepted);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(0).getPacketStoreStrategy());

		// allDwlForAcq =
		// this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(),
		// this.sessionId, this.currentKieSession, droolsParams);
		//
		// for(int i=0;i<allDwlForAcq.size();i++)
		// {
		// System.out.println(allDwlForAcq.get(i));
		//
		// }
		// assertEquals(1,allDwlForAcq.size());
		//
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_H_V_singlePartner_totalDownloaded() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis3));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.H_V);
		dto1.setSizeH(4000);
		dto1.setSizeV(4000);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
		assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.DELETE);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(0, allDwlForAcq.size());
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_initPlan_HH_singlePartner() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:16:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00",
				"10/10/2017 19:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(4000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

	@Test
	public void downloadTest_Partial_Time_Performance() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
	}

	@Test
	public void downloadTest_NoSpaceOnVis_Shift_Latest_noSpace() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:15:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:15:00");
		Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 13:00:00",
				"10/10/2017 13:15:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId(), vis4.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		DroolsQueries dq = new DroolsQueries();

		Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
		System.out.println("returned acq : " + returnedAcq);
		assertTrue(returnedAcq != null);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(false);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		// droolsInstance.retractSingleAcq(droolsParams, dto3.getDtoId(),
		// sessionId, currentKieSession, ReasonOfReject.brmError);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(priorityQueue);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		List<Task> allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}
		// droolsInstance.initPlan(droolsParams, allPrevTask, null, sessionId,
		// currentKieSession, false);

		resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession,
				"resourceFunctions");
		priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(priorityQueue);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task INITPLAN : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}
	}

	@Test
	public void downloadTest_NoSpaceOnVis_Shift_Latest() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:15:00");
		Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 13:00:00",
				"10/10/2017 13:15:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId(), vis4.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		DroolsQueries dq = new DroolsQueries();

		Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
		System.out.println("returned acq : " + returnedAcq);
		assertTrue(returnedAcq != null);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(false);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
	}

	@Test
	public void downloadTest_NoSpaceOnVis_Shift_And_Retract() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:15:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:15:00");
		Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 13:00:00",
				"10/10/2017 13:15:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId(), vis4.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		DroolsQueries dq = new DroolsQueries();

		Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
		System.out.println("returned acq : " + returnedAcq);
		assertTrue(returnedAcq != null);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(false);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession,
				ReasonOfReject.internallyInconsistent);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(priorityQueue);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		List<Task> allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}
		// droolsInstance.initPlan(droolsParams, allPrevTask, null, sessionId,
		// currentKieSession, false);

		resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession,
				"resourceFunctions");
		priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(priorityQueue);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task INITPLAN : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}
	}

	@Test
	public void downloadTest_useBackUpStation() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p2.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00",
				"10/10/2017 07:20:00");

		Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(0, "SAT_1", "MAT", p2.getPartnerId(), "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");

		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.getHpExclusionList().clear();
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
		this.droolsParams.setAllVisibilities(allVis);
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);

		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		userInfoList.add(userInfo1);
		dto1.setUserInfo(userInfoList);
		dto1.setBackupVis(allVisId);
		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setBackupVis(allVisId);

		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setBackupVis(allVisId);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setPriority(-20);
		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		DTO dto4 = this.du.createSingleDto("10/10/2017 07:10:00", "10/10/2017 07:10:10", "right", "SAT_1");
		dto4.setTimePerformance(false);
		dto4.setPreferredVis(allVisId);
		dto4.setUserInfo(userInfoList);
		dto4.setBackupVis(allVisId);
		dto4.setPol(Polarization.HH);
		dto4.setSizeV(0);
		dto4.setPriority(0);
		dto4.setSizeH(100);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(priorityQueue);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		List<Task> allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}

		List<Task> fromTreemapToList = DroolsUtils.fromTreemapToList(allTasks);
		Date startMh = DroolsUtils.createDate("10/10/2017 18:21:00");
		Date stopMh = DroolsUtils.createDate("11/10/2017 06:21:00");

		this.droolsParams.getCurrentMH().setStart(startMh);
		this.droolsParams.getCurrentMH().setStop(stopMh);
		Visibility vis5 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 19:10:00",
				"10/10/2017 19:12:00");
		Visibility vis6 = this.stub.createVisibility(0, "SAT_1", "MAT", null, "10/10/2017 20:00:00",
				"10/10/2017 20:50:00");
		this.droolsParams.getAllVisibilities().add(vis5);
		this.droolsParams.getAllVisibilities().add(vis6);

		this.droolsInstance.initPlan(this.droolsParams, fromTreemapToList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	@Test
	public void downloadTest_NoSpaceOnVis_Shift_Previous_on_next_vis_1() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00",
				"10/10/2017 07:20:00");

		Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(0, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis4, vis3));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());

		userInfoList.add(userInfo2);
		dto1.setPrType(PRType.LMP); // 1111507610700000
									// 1321507610100000
									// 1031507609320000
									// 1041507612200000
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		// this.droolsInstance.writeToFile(this.sessionId,
		// this.currentKieSession, this.droolsParams);
		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(false);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPrType(PRType.RANKED_ROUTINE);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000); // 151507610100000

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setPrType(PRType.VU); // 1_1_3_1507609320000

		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		DTO dto4 = this.du.createSingleDto("10/10/2017 07:10:00", "10/10/2017 07:10:10", "right", "SAT_1");
		dto4.setTimePerformance(false);
		dto4.setPreferredVis(allVisId);
		dto4.setUserInfo(userInfoList);
		dto4.setPol(Polarization.HH);
		dto4.setSizeV(0);
		dto4.setPrType(PRType.VU); // 1_1_0_1507612200000

		// dto4.setPriority(0);
		dto4.setSizeH(100);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println("PRIORITY :" + priorityQueue);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		List<Task> allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}
	}

	@Test
	public void downloadTest_NoSpaceOnVis_Shift_Previous_retainInitPlan() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00",
				"10/10/2017 07:20:00");

		Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis4));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setTimePerformance(false);
		dto3.setPreferredVis(allVisId);
		dto3.setUserInfo(userInfoList);
		dto3.setPol(Polarization.H_V);
		dto3.setSizeV(4000);
		dto3.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		DTO dto4 = this.du.createSingleDto("10/10/2017 07:10:00", "10/10/2017 07:10:10", "right", "SAT_1");
		dto4.setTimePerformance(false);
		dto4.setPreferredVis(allVisId);
		dto4.setUserInfo(userInfoList);
		dto4.setPol(Polarization.HH);
		dto4.setSizeV(0);
		dto4.setPriority(0);
		dto4.setSizeH(100);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
		System.out.println(priorityQueue);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		List<Task> allPrevTask = new ArrayList<>();
		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
			allPrevTask.add(elements.getValue());
		}

		List<Task> fromTreemapToList = DroolsUtils.fromTreemapToList(allTasks);
		Date startMh = DroolsUtils.createDate("10/10/2017 18:21:00");
		Date stopMh = DroolsUtils.createDate("11/10/2017 06:21:00");

		System.out.println("DTO 1 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams));

		System.out.println("DTO 2 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto2.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams));

		System.out.println("DTO 3 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto3.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams));

		System.out.println("DTO 4 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto4.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams));

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		// assertEquals(3,
		// this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
		// this.sessionId, this.currentKieSession, this.droolsParams).size());
		// assertEquals(5,
		// this.droolsInstance.receiveAllDownloadAssociatedToDto(dto2.getDtoId(),
		// this.sessionId, this.currentKieSession, this.droolsParams).size());
		// assertEquals(4,
		// this.droolsInstance.receiveAllDownloadAssociatedToDto(dto3.getDtoId(),
		// this.sessionId, this.currentKieSession, this.droolsParams).size());
		// assertEquals(2,
		// this.droolsInstance.receiveAllDownloadAssociatedToDto(dto4.getDtoId(),
		// this.sessionId, this.currentKieSession, this.droolsParams).size());

		// PDHT lastPDHT =
		// resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();

		this.droolsParams.getCurrentMH().setStart(startMh);
		this.droolsParams.getCurrentMH().setStop(stopMh);
		Visibility vis5 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 19:10:00",
				"10/10/2017 19:12:00");
		Visibility vis6 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 20:00:00",
				"10/10/2017 20:50:00");
		this.droolsParams.getAllVisibilities().add(vis5);
		this.droolsParams.getAllVisibilities().add(vis6);
		this.sessionId = "newSession";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance.initPlan(this.droolsParams, fromTreemapToList, null, this.sessionId, this.currentKieSession,
				true);
		this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);

		DTO dto5 = this.du.createSingleDto("10/10/2017 19:10:00", "10/10/2017 19:10:10", "right", "SAT_1");
		dto5.setTimePerformance(false);
		dto5.setPreferredVis(allVisId);
		dto5.setUserInfo(userInfoList);
		dto5.setPol(Polarization.HH);
		dto5.setSizeV(0);
		dto5.setPriority(0);
		dto5.setSizeH(100);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	@Test
	public void downloadTest_NoSpaceOnVis_Shift_Previous_on_next_vis_2() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00",
				"10/10/2017 07:20:00");

		Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(0, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis4, vis3));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
	}

	@Test
	public void downloadTest_NoSpaceOnVis_Plan_partially() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:22:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto2.setTimePerformance(true);
		dto2.setPreferredVis(allVisId);
		dto2.setUserInfo(userInfoList);
		dto2.setPol(Polarization.H_V);
		dto2.setSizeV(4000);
		dto2.setSizeH(4000);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
	}

	@Test
	public void downloadTest_Partial_start_on_own_vis_ends_in_external() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:12:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:12:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
		List<String> allVisId = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();
		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
	}

	@Test
	public void downloadTest_Partial_start_on_external_ends_in_external() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		TaskPlanned taskPlanned = new TaskPlanned();
		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00",
				"10/10/2017 06:51:00");
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:12:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:13:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

		List<String> allVisAdId = new ArrayList<>(
				Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
		this.droolsParams.getHpExclusionList().clear();
		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisAdId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession,
				this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		// assertEquals(5, allDwl.size());

		assertEquals(DownlinkStrategy.RETAIN, allDwl.get(0).getPacketStoreStrategy());
		assertEquals(DownlinkStrategy.DELETE, allDwl.get(1).getPacketStoreStrategy());

		assertEquals(true, allDwl.get(0).getUgsOwnerList().contains(p1.getPartnerId()));
		assertEquals(true, allDwl.get(0).getUgsOwnerList().contains(p2.getPartnerId()));

		assertEquals(true, allDwl.get(1).getUgsOwnerList().contains(p2.getPartnerId()));
		assertEquals(true, allDwl.get(1).getUgsOwnerList().contains(p1.getPartnerId()));
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
		System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession));
	}

	@Test
	public void downloadTest_RankedAfterAnHp() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		TaskPlanned taskPlanned = new TaskPlanned();
		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:40:00",
				"10/10/2017 06:51:00");
		Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00",
				"10/10/2017 07:12:00");
		Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00",
				"10/10/2017 08:13:00");
		Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00",
				"10/10/2017 12:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

		List<String> allVisAdId = new ArrayList<>(
				Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

		List<String> allVisAsString = new ArrayList<>(
				Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
		this.droolsParams.getHpExclusionList().clear();
		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisAdId);
		dto1.setPrType(PRType.HP);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession,
				this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		// assertEquals(5, allDwl.size());

		// assertEquals(DownlinkStrategy.RETAIN,
		// allDwl.get(0).getPacketStoreStrategy());
		// assertEquals(DownlinkStrategy.DELETE,
		// allDwl.get(1).getPacketStoreStrategy());
		//
		// assertEquals(true,
		// allDwl.get(0).getUgsOwnerList().contains(p1.getPartnerId()));
		// assertEquals(true,
		// allDwl.get(0).getUgsOwnerList().contains(p2.getPartnerId()));
		//
		// assertEquals(true,
		// allDwl.get(1).getUgsOwnerList().contains(p1.getPartnerId()));
		// assertEquals(true,
		// allDwl.get(1).getUgsOwnerList().contains(p2.getPartnerId()));
		//
		DTO dto2 = this.du.createSingleDto("10/10/2017 06:30:00", "10/10/2017 06:31:10", "right", "SAT_1");
		dto2.setPreferredVis(allVisAdId);
		dto2.setUserInfo(userInfoList);
		dto2.setPrType(PRType.RANKED_ROUTINE);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		DTO dto3 = this.du.createSingleDto("10/10/2017 06:21:10", "10/10/2017 06:22:10", "right", "SAT_1");
		dto3.setPreferredVis(allVisAdId);
		dto3.setUserInfo(userInfoList);
		dto3.setPrType(PRType.HP);

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		// assertEquals(5, allDwl.size());
		//
		// assertEquals(DownlinkStrategy.RETAIN,
		// allDwl.get(0).getPacketStoreStrategy());
		// assertEquals(DownlinkStrategy.DELETE,
		// allDwl.get(1).getPacketStoreStrategy());
		//
		// assertEquals(true,
		// allDwl.get(0).getUgsOwnerList().contains(p1.getPartnerId()));
		// assertEquals(true,
		// allDwl.get(0).getUgsOwnerList().contains(p2.getPartnerId()));
		//
		// assertEquals(true,
		// allDwl.get(1).getUgsOwnerList().contains(p1.getPartnerId()));
		// assertEquals(true,
		// allDwl.get(1).getUgsOwnerList().contains(p2.getPartnerId()));
		//
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
		System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession));
	}

	@Test
	public void downloadTest_download_not_overlap_paw_retain_sameMh() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		TaskPlanned taskPlanned = new TaskPlanned();
		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		this.droolsParams.getAllPAWS().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:05:00",
				"10/10/2017 08:13:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));

		PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:08:00", PAWType.GENERIC);
		List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1));

		List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.setAllPAWS(allPaws);

		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		this.droolsParams.getHpExclusionList().clear();
		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisAdId);
		dto1.setPol(Polarization.HV);
		dto1.setSizeH(200);
		dto1.setSizeV(200);

		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAdId, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAdId, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession,
				this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		assertEquals(3, allDwl.size());

		assertEquals(DownlinkStrategy.DELETE, allDwl.get(0).getPacketStoreStrategy());

		Map<String, Task> previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> previousTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> prevElements : previousTasks.entrySet()) {
			previousTasksAsList.add(prevElements.getValue());
		}
		this.currentKieSession = 4;

		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 12:05:00",
				"10/10/2017 12:13:00");
		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
		assertTrue(accepted);
		allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		assertEquals(4, allDwl.size());
		System.out.println(previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession));
	}

	@Test
	public void downloadTest_download_not_overlap_paw_retain_newMh() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		TaskPlanned taskPlanned = new TaskPlanned();
		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		this.droolsParams.getAllPAWS().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:05:00",
				"10/10/2017 08:13:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));

		PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:08:00", PAWType.GENERIC);
		List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1));

		List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.setAllPAWS(allPaws);

		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		PDHT startPdht = this.droolsParams.getAllPDHT().get(0);

		this.droolsParams.getHpExclusionList().clear();
		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisAdId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAdId, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAdId, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession,
				this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		assertEquals(2, allDwl.size());

		assertEquals(DownlinkStrategy.RETAIN, allDwl.get(0).getPacketStoreStrategy());

		Map<String, Task> previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> previousTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> prevElements : previousTasks.entrySet()) {
			previousTasksAsList.add(prevElements.getValue());
		}
		PDHT lastPdht = this.droolsInstance.getPDHTStatus(this.droolsParams.getCurrentMH().getStop(), "SAT_1",
				this.sessionId, this.currentKieSession);
		System.out.println("last pdht was : " + lastPdht);
		this.currentKieSession = 4;

		Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 19:05:00",
				"10/10/2017 19:13:00");
		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllPDHT().clear();
		this.droolsParams.getAllPDHT().add(lastPdht);
		this.droolsParams.getAllPDHT().add(startPdht);
		Date mhNewStart = DroolsUtils.createDate("10/10/2017 18:21:00");
		Date mhNewEnd = DroolsUtils.createDate("11/10/2017 06:21:00");
		MissionHorizon newMh = new MissionHorizon(mhNewStart, mhNewEnd);
		this.droolsParams.setCurrentMH(newMh);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsInstance.initPlan(this.droolsParams, previousTasksAsList, null, this.sessionId,
				this.currentKieSession, true);
		allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		System.out.println(previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession));
	}

	@Test
	public void downloadTest_download_not_overlap_GPS() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		TaskPlanned taskPlanned = new TaskPlanned();

		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		this.droolsParams.getAllPAWS().clear();

		Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Pdr", "1100", "10/10/2017 08:05:00",
				"10/10/2017 08:13:00");

		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));

		PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:08:00", PAWType.GENERIC);
		List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1));

		List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.setAllPAWS(allPaws);

		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
		dto1.setPreferredVis(allVisAdId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisAdId, false, p1.getPartnerId(), p1.getUgsId());
		UserInfo userInfo2 = new UserInfo(allVisAdId, false, p2.getPartnerId(), p2.getUgsId());
		userInfoList.add(userInfo1);
		userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

		Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}
		List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession,
				this.droolsParams, "SAT_1");
		for (int i = 0; i < allDwl.size(); i++) {
			System.out.println("allDwl : " + allDwl.get(i));
		}

		// assertEquals(1, allDwl.size());

		// assertEquals(DownlinkStrategy.RETAIN,
		// allDwl.get(0).getPacketStoreStrategy());

		Map<String, Task> previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);

		List<Task> previousTasksAsList = new ArrayList<>();
		for (Map.Entry<String, Task> elements : previousTasks.entrySet()) {
			previousTasksAsList.add(elements.getValue());
		}

		this.currentKieSession = 4;
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Visibility vis4 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 12:05:00",
				"10/10/2017 12:13:00");
		this.droolsParams.getAllVisibilities().add(vis4);

		this.droolsInstance.initPlan(this.droolsParams, previousTasksAsList, null, this.sessionId,
				this.currentKieSession, false);

		System.out.println(previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession));
	}

	/*
	 * @Test public void parseTaskReportDifferentFormat() throws ParseException,
	 * Exception { sessionId = "parseTaskReportDifferentFormat";
	 * this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
	 *
	 * MissionHorizon currentMH = new MissionHorizon();
	 * currentMH.setStart(du.createDate("16/09/2016 06:21:00"));
	 * currentMH.setStop(du.createDate("16/09/2016 18:21:00"));
	 * droolsParams.setCurrentMH(currentMH);
	 *
	 * droolsParams.getAllPAWS().clear(); this.droolsInstance =
	 * this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
	 * this.droolsInstance, this.currentKieSession, "_");
	 *
	 * double extraCostLeft = 2; droolsParams.setExtraCostLeft(extraCostLeft);
	 *
	 * String fileString =
	 * "� 200_702_1_1_, startTime :2016-09-16 11:42:43.86, endTime :2016-09-16 11:42:51.083, lookSide :Right, sensorMode :STRIPMAP , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3258_1_1_, startTime :2016-09-16 17:21:57.374, endTime :2016-09-16 17:22:04.65, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3249_1_1_, startTime :2016-09-16 17:24:51.879, endTime :2016-09-16 17:25:00.138, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3247_1_1_, startTime :2016-09-16 18:08:47.967, endTime :2016-09-16 18:08:55.059, lookSide :Right, sensorMode :QUADPOL , prType : PP, sat :SSAR2 added\n"
	 * +
	 * "     � 100_3229_1_1_, startTime :2016-09-16 18:18:50.975, endTime :2016-09-16 18:19:42.008, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3230_1_1_, startTime :2016-09-16 07:13:11.463, endTime :2016-09-16 07:13:27.535, lookSide :Left, sensorMode :SCANSAR_1 , prType : PP, sat :SSAR2 added\n"
	 * +
	 * "     � 100_3252_1_1_, startTime :2016-09-16 11:56:33.898, endTime :2016-09-16 11:56:41.108, lookSide :Right, sensorMode :QUADPOL , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3246_1_1_, startTime :2016-09-16 11:50:12.498, endTime :2016-09-16 11:50:43.485, lookSide :Right, sensorMode :SCANSAR_2 , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3244_1_1_, startTime :2016-09-16 11:34:57.855, endTime :2016-09-16 11:35:06.13, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3232_1_1_, startTime :2016-09-16 11:37:59.614, endTime :2016-09-16 11:38:10.319, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3228_1_1_, startTime :2016-09-16 11:53:29.208, endTime :2016-09-16 11:53:36.789, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3256_1_2_, startTime :2016-09-16 11:47:14.494, endTime :2016-09-16 11:47:30.464, lookSide :Right, sensorMode :SCANSAR_1 , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3251_1_1_, startTime :2016-09-16 11:41:08.255, endTime :2016-09-16 11:41:13.669, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3233_1_3_, startTime :2016-09-16 11:44:13.319, endTime :2016-09-16 11:44:20.616, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3224_1_2_, startTime :2016-09-16 13:40:52.081, endTime :2016-09-16 13:41:01.92, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3222_1_1_, startTime :2016-09-16 08:52:26.951, endTime :2016-09-16 08:52:35.046, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3227_1_2_, startTime :2016-09-16 13:42:25.0, endTime :2016-09-16 13:42:31.0, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3226_1_1_, startTime :2016-09-16 07:13:10.876, endTime :2016-09-16 07:13:19.123, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3223_1_2_, startTime :2016-09-16 07:12:25.461, endTime :2016-09-16 07:12:35.539, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3225_4_1_, startTime :2016-09-16 12:04:15.441, endTime :2016-09-16 12:04:24.559, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3225_3_1_, startTime :2016-09-16 08:50:38.601, endTime :2016-09-16 08:50:47.397, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3225_2_1_, startTime :2016-09-16 13:41:09.918, endTime :2016-09-16 13:41:21.084, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3225_1_1_, startTime :2016-09-16 07:13:50.481, endTime :2016-09-16 07:13:59.517, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
	 * +
	 * "     � 200_704_1_1_, startTime :2016-09-16 17:20:24.63, endTime :2016-09-16 17:20:40.391, lookSide :Right, sensorMode :SCANSAR_1 , prType : HP, sat :SSAR1 added\n"
	 * +
	 * "     � 200_703_1_1_, startTime :2016-09-16 11:45:41.497, endTime :2016-09-16 11:45:57.454, lookSide :Right, sensorMode :SCANSAR_1 , prType : HP, sat :SSAR1 added\n"
	 * +
	 * "     � 200_701_1_1_, startTime :2016-09-16 09:39:06.429, endTime :2016-09-16 09:39:11.57, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : HP, sat :SSAR2 added\n"
	 * +
	 * "     � 200_697_1_1_, startTime :2016-09-16 13:07:35.891, endTime :2016-09-16 13:07:43.093, lookSide :Left, sensorMode :STRIPMAP , prType : HP, sat :SSAR2 added\n"
	 * +
	 * "     � 200_696_1_1_, startTime :2016-09-16 15:25:08.407, endTime :2016-09-16 15:25:15.584, lookSide :Right, sensorMode :STRIPMAP , prType : HP, sat :SSAR1 added\n"
	 * +
	 * "     � 200_693_1_2_, startTime :2016-09-16 11:01:59.716, endTime :2016-09-16 11:02:30.296, lookSide :Left, sensorMode :SCANSAR_2 , prType : HP, sat :SSAR2 added\n"
	 * +
	 * "     � 200_708_1_3_, startTime :2016-09-16 11:55:05.286, endTime :2016-09-16 11:55:12.717, lookSide :Right, sensorMode :PINGPONG , prType : HP, sat :SSAR1 added\n"
	 * +
	 * "     � 200_707_1_2_, startTime :2016-09-16 10:22:02.906, endTime :2016-09-16 10:22:10.085, lookSide :Left, sensorMode :QUADPOL , prType : HP, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3243_1_1_, startTime :Fri Sep 16 11:39:48 GMT 2016, endTime :Fri Sep 16 11:39:57 GMT 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3240_1_1_, startTime :Fri Sep 16 11:36:30 GMT 2016, endTime :Fri Sep 16 11:36:37 GMT 2016, lookSide :Right, sensorMode :STRIPMAP , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3238_1_1_, startTime :Fri Sep 16 11:39:48 GMT 2016, endTime :Fri Sep 16 11:39:57 GMT 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
	 * +
	 * "     � 100_3237_1_1_, startTime :Fri Sep 16 12:30:33 GMT 2016, endTime :Fri Sep 16 12:31:04 GMT 2016, lookSide :Left, sensorMode :SCANSAR_2 , prType : RANKED_ROUTINE, sat :SSAR1 added"
	 * ; FunctionUtils fu = new FunctionUtils(); List<DTO> dtoList =
	 * fu.parseDtoFromFile(fileString); System.out.println(dtoList);
	 *
	 * for (int i = 0; i < dtoList.size(); i++) {
	 *
	 * this.droolsInstance.insertDto(this.droolsParams, dtoList.get(i), sessionId,
	 * this.currentKieSession); }
	 *
	 * droolsInstance.writeToFile(sessionId, currentKieSession, droolsParams); }
	 */
	@Test
	public void A_Test_Dwl_Init_plan() throws Exception {
		System.out.println("running test : A_Test_Dwl_Init_plan");
		this.droolsParams.getAllVisibilities().clear();
		TaskPlanned taskPlanned = new TaskPlanned();

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		// to be sure that other maneuvers will not be planned outside the ones
		// expected for the test, I will set the initial lookside for both
		// satellites to right, as the first acquisition that I put into the
		// rule engine
		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		assertEquals(0,
				taskPlanned
						.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1")
						.size());
		assertEquals(0, taskPlanned
				.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());

		// inserting a valid dto
		DTO dto1 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:12", "right", "SAT_1");
		dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		List<Task> alltasksOfPreviousSession = this.droolsInstance.receiveDtoAccepted(this.sessionId,
				this.currentKieSession, this.droolsParams, dto1.getSatelliteId());
		System.out.println("all tasks : " + alltasksOfPreviousSession);

		DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession,
				null);
		List<Maneuver> numberOfManeuvers = taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession,
				this.droolsParams, "SAT_1");
		System.out.println("number of maneuvers : " + numberOfManeuvers);

		this.currentKieSession = 2;

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		// this.droolsInstance.initPreviousPlan(alltasksOfPreviousSession,
		// this.currentKieSession);

	}

	@Test
	public void testConcatVisId() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Visibility vis4 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 12:05:00",
				"10/10/2017 12:13:00");
		this.droolsParams.getAllVisibilities().add(vis4);

		// visibility.getAcqStatId() + "_" + visibility.getContactCounter() +
		// "_" + visibility.getSatelliteId()
		String expectedVis = "KOR_2_SAT_1";
		String concatVis = DownloadManagement.concatVisId("SAT_1", vis4);

		assertEquals(expectedVis, concatVis);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testConcatVisId_nullAcqStat() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		Visibility vis4 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 12:05:00",
				"10/10/2017 12:13:00");
		this.droolsParams.getAllVisibilities().add(vis4);

		vis4.setAcqStatId(null);
		DownloadManagement.concatVisId("SAT_1", vis4);

	}

	@Test
	public void testProcessPacketStore_noDwl_totalSectors() throws Exception {

		System.out.println("running test : A_Test_Dwl_Init_plan");
		this.droolsParams.getAllVisibilities().clear();
		TaskPlanned taskPlanned = new TaskPlanned();

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		// to be sure that other maneuvers will not be planned outside the ones
		// expected for the test, I will set the initial lookside for both
		// satellites to right, as the first acquisition that I put into the
		// rule engine
		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		assertEquals(0,
				taskPlanned
						.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1")
						.size());
		assertEquals(0, taskPlanned
				.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());

		// inserting a valid dto
		DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:12", "right", "SAT_1");
		dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto1.setPol(Polarization.VH);
		dto1.setSizeH(200);
		dto1.setSizeV(400);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId,
				this.currentKieSession);
		Storage sto = this.droolsInstance
				.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());
		List<Download> allDwlAssociatedToSto = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, droolsParams);
		System.out.println(acq);

		System.out.println(sto);
		System.out.println(allDwlAssociatedToSto);

		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriorityQueue = resFunc
				.getDownloadPriorityQueueForSat(dto1.getSatelliteId());

		downloadPriorityQueue.clear();
		// extract the partners related to the acq
		List<Partner> allPartnersRelatedToAcq = dwlUtils.extractAllPartnersRelativeToAcq(acq.getUserInfo(),
				droolsParams);
		acq.setPriority(1);
		dwlManagement.processPacketStore(acq, sto.getPacketsStore(Polarization.HH), allPartnersRelatedToAcq,
				allDwlAssociatedToSto, downloadPriorityQueue);
		
		
//		
//		System.out.println(downloadPriorityQueue);
//		HashMap<String, SectorAndVisForPartner> sectors = downloadPriorityQueue.get("2_1_000000000000001_1507651200000")
//				.getSectorsNeededForPartners();
//		List<SizeOfSectorDwl> sectorsForP1 = sectors.get("Partner_1").getSectorsForPartner();
//		List<SizeOfSectorDwl> sectorsForP3 = sectors.get("Partner_3").getSectorsForPartner();
//		assertEquals(1, sectorsForP1.size());
//		assertEquals(1, sectorsForP3.size());
//		assertEquals(Polarization.HH, sectorsForP1.get(0).getPol());
//		assertEquals(Polarization.HH, sectorsForP3.get(0).getPol());
//		assertEquals(200, sectorsForP1.get(0).getEffectiveSize());
//		assertEquals(200, sectorsForP3.get(0).getEffectiveSize());
//		assertEquals(200, sectorsForP1.get(0).getResidualSize());
//		assertEquals(200, sectorsForP3.get(0).getResidualSize());
//		
//		System.out.println(sectors);
		dwlManagement.processPacketStore(acq, sto.getPacketsStore(Polarization.VV), allPartnersRelatedToAcq,
				allDwlAssociatedToSto, downloadPriorityQueue);
//		assertEquals(2, sectorsForP1.size());
//		assertEquals(2, sectorsForP3.size());
//		assertEquals(Polarization.HH, sectorsForP1.get(0).getPol());
//		assertEquals(Polarization.HH, sectorsForP3.get(0).getPol());
//		assertEquals(Polarization.VV, sectorsForP1.get(1).getPol());
//		assertEquals(Polarization.VV, sectorsForP3.get(1).getPol());
//		assertEquals(200, sectorsForP1.get(0).getEffectiveSize());
//		assertEquals(200, sectorsForP3.get(0).getEffectiveSize());
//		assertEquals(200, sectorsForP1.get(0).getResidualSize());
//		assertEquals(200, sectorsForP3.get(0).getResidualSize());
//		assertEquals(400, sectorsForP1.get(1).getEffectiveSize());
//		assertEquals(400, sectorsForP3.get(1).getEffectiveSize());
//		assertEquals(400, sectorsForP1.get(1).getResidualSize());
//		assertEquals(400, sectorsForP3.get(1).getResidualSize());
//		System.out.println(downloadPriorityQueue);

	}
	

	@Test
	public void testProcessPacketStore_partialV() throws Exception {

		System.out.println("running test : A_Test_Dwl_Init_plan");
		TaskPlanned taskPlanned = new TaskPlanned();

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		// to be sure that other maneuvers will not be planned outside the ones
		// expected for the test, I will set the initial lookside for both
		// satellites to right, as the first acquisition that I put into the
		// rule engine
		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		assertEquals(0,
				taskPlanned
						.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1")
						.size());
		assertEquals(0, taskPlanned
				.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());

		// inserting a valid dto
		DTO dto1 = this.du.createSingleDto("10/10/2017 12:00:00", "10/10/2017 12:00:12", "right", "SAT_1");
		dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto1.setPol(Polarization.VH);
		dto1.setSizeH(200);
		dto1.setSizeV(400);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId,
				this.currentKieSession);
		Storage sto = this.droolsInstance
				.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());
		List<Download> allDwlAssociatedToSto = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, droolsParams);
		System.out.println(acq);

		System.out.println(sto);
		System.out.println(allDwlAssociatedToSto);
		allDwlAssociatedToSto.get(0).setPol(Polarization.VV);
		allDwlAssociatedToSto.get(0).setDownloadedSize(100);
		allDwlAssociatedToSto.get(0).setFinalSector(allDwlAssociatedToSto.get(0).getInitialSector()+ 100);
		allDwlAssociatedToSto.get(0).setPacketStoreStrategy(DownlinkStrategy.RETAIN);
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriorityQueue = resFunc
				.getDownloadPriorityQueueForSat(dto1.getSatelliteId());

		downloadPriorityQueue.clear();
		// extract the partners related to the acq
		List<Partner> allPartnersRelatedToAcq = dwlUtils.extractAllPartnersRelativeToAcq(acq.getUserInfo(),
				droolsParams);

		dwlManagement.processPacketStore(acq, sto.getPacketsStore(Polarization.HH), allPartnersRelatedToAcq,
				allDwlAssociatedToSto, downloadPriorityQueue);
		System.out.println(downloadPriorityQueue);
		
		//nothign will be inserted inside the priority queue, download for polarization HH is DELETE
		assertEquals(0, downloadPriorityQueue.size());
		dwlManagement.processPacketStore(acq, sto.getPacketsStore(Polarization.VV), allPartnersRelatedToAcq,
				allDwlAssociatedToSto, downloadPriorityQueue);
		
		System.out.println(downloadPriorityQueue);
//
//		HashMap<String, SectorAndVisForPartner> sectors = downloadPriorityQueue.get("2_1_000000000000001_1507629600000")
//				.getSectorsNeededForPartners();
//		System.out.println(sectors);
//
//		List<SizeOfSectorDwl> sectorsForP1 = sectors.get("Partner_1").getSectorsForPartner();
//		List<SizeOfSectorDwl> sectorsForP3 = sectors.get("Partner_3").getSectorsForPartner();
//		assertEquals(1, sectorsForP1.size());
//		assertEquals(1, sectorsForP3.size());
//		assertEquals(Polarization.VV, sectorsForP1.get(0).getPol());
//		assertEquals(Polarization.VV, sectorsForP3.get(0).getPol());
//		
//		System.out.println(sectorsForP1.get(0));
//		assertEquals(300, sectorsForP1.get(0).getTotalSize());
//		assertEquals(300, sectorsForP3.get(0).getTotalSize());
//		assertEquals(300, sectorsForP1.get(0).getResidualSize());
//		assertEquals(300, sectorsForP3.get(0).getResidualSize());
//		System.out.println(downloadPriorityQueue);

	}
	
	@Test
	public void testProcessPacketStore_partialVH() throws Exception {

		System.out.println("running test : A_Test_Dwl_Init_plan");
		TaskPlanned taskPlanned = new TaskPlanned();

		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

		// to be sure that other maneuvers will not be planned outside the ones
		// expected for the test, I will set the initial lookside for both
		// satellites to right, as the first acquisition that I put into the
		// rule engine
		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");
		assertEquals(0,
				taskPlanned
						.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1")
						.size());
		assertEquals(0, taskPlanned
				.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());

		// inserting a valid dto
		DTO dto1 = this.du.createSingleDto("10/10/2017 12:00:00", "10/10/2017 12:00:12", "right", "SAT_1");
		dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto1.setPol(Polarization.VH);
		dto1.setSizeH(200);
		dto1.setSizeV(400);

		boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);

		Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId,
				this.currentKieSession);
		Storage sto = this.droolsInstance
				.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());
		List<Download> allDwlAssociatedToSto = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, droolsParams);
		System.out.println(acq);

		System.out.println(sto);
		System.out.println(allDwlAssociatedToSto);
		allDwlAssociatedToSto.get(0).setPol(Polarization.VV);
		allDwlAssociatedToSto.get(0).setDownloadedSize(100);
		allDwlAssociatedToSto.get(0).setFinalSector(allDwlAssociatedToSto.get(0).getInitialSector()+ 100);
		allDwlAssociatedToSto.get(0).setPacketStoreStrategy(DownlinkStrategy.RETAIN);
		
		allDwlAssociatedToSto.get(1).setPol(Polarization.HH);
		allDwlAssociatedToSto.get(1).setDownloadedSize(100);
		allDwlAssociatedToSto.get(1).setFinalSector(allDwlAssociatedToSto.get(1).getInitialSector()+ 100);
		allDwlAssociatedToSto.get(1).setPacketStoreStrategy(DownlinkStrategy.RETAIN);
		
		
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<String, PriorityQueue> downloadPriorityQueue = resFunc
				.getDownloadPriorityQueueForSat(dto1.getSatelliteId());

		downloadPriorityQueue.clear();
		// extract the partners related to the acq
		List<Partner> allPartnersRelatedToAcq = dwlUtils.extractAllPartnersRelativeToAcq(acq.getUserInfo(),
				droolsParams);
		
		//nothign will be inserted inside the priority queue, download for polarization HH is DELETE
		assertEquals(0, downloadPriorityQueue.size());
		dwlManagement.processPacketStore(acq, sto.getPacketsStore(Polarization.VV), allPartnersRelatedToAcq,
				allDwlAssociatedToSto, downloadPriorityQueue);
		
		System.out.println(downloadPriorityQueue);
//
//		HashMap<String, SectorAndVisForPartner> sectors = downloadPriorityQueue.get("2_1_000000000000001_1507629600000")
//				.getSectorsNeededForPartners();
//		System.out.println(sectors);
//
//		List<SizeOfSectorDwl> sectorsForP1 = sectors.get("Partner_1").getSectorsForPartner();
//		List<SizeOfSectorDwl> sectorsForP3 = sectors.get("Partner_3").getSectorsForPartner();
//		assertEquals(1, sectorsForP1.size());
//		assertEquals(1, sectorsForP3.size());
//		assertEquals(Polarization.VV, sectorsForP1.get(0).getPol());
//		assertEquals(Polarization.VV, sectorsForP3.get(0).getPol());
//		
//		System.out.println(sectorsForP1.get(0));
//		assertEquals(300, sectorsForP1.get(0).getTotalSize());
//		assertEquals(300, sectorsForP3.get(0).getTotalSize());
//		assertEquals(300, sectorsForP1.get(0).getResidualSize());
//		assertEquals(300, sectorsForP3.get(0).getResidualSize());
//		System.out.println(downloadPriorityQueue);
//		

		dwlManagement.processPacketStore(acq, sto.getPacketsStore(Polarization.HH), allPartnersRelatedToAcq,
				allDwlAssociatedToSto, downloadPriorityQueue);
		System.out.println(downloadPriorityQueue);
//		TODO: decommentare test su metodo processPacketStore
//		assertEquals(2, sectorsForP1.size());
//		assertEquals(2, sectorsForP3.size());
//		assertEquals(Polarization.VV, sectorsForP1.get(0).getPol());
//		assertEquals(Polarization.VV, sectorsForP3.get(0).getPol());
//		assertEquals(Polarization.HH, sectorsForP1.get(1).getPol());
//		assertEquals(Polarization.HH, sectorsForP3.get(1).getPol());
//		
//		System.out.println(sectorsForP1.get(0));
//		assertEquals(300, sectorsForP1.get(0).getTotalSize());
//		assertEquals(300, sectorsForP3.get(0).getTotalSize());
//		assertEquals(300, sectorsForP1.get(0).getResidualSize());
//		assertEquals(300, sectorsForP3.get(0).getResidualSize());
//		
//		assertEquals(100, sectorsForP1.get(1).getTotalSize());
//		assertEquals(100, sectorsForP3.get(1).getTotalSize());
//		assertEquals(100, sectorsForP1.get(1).getResidualSize());
//		assertEquals(100, sectorsForP3.get(1).getResidualSize());

	}

}
