
package com.nais.spla.brm.library.main.ontology.enums;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * The Class TaskTypeTest.
 */
public class TaskTypeTest
{

    /**
     * Test enum task type.
     */
    @Test
    public void testEnumTaskType()
    {
        List<TaskType> allTaskTypeForTest = new ArrayList<>();
        TaskType[] allTaskType = TaskType.values();
        for (int i = 0; i < allTaskType.length; i++)
        {
            allTaskTypeForTest.add(allTaskType[i]);
        }

        TaskType type;
        type = TaskType.valueOf("ACQUISITION");
        System.out.println("Selected : " + type);
    }

}
