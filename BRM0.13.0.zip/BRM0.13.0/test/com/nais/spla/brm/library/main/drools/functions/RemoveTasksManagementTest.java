
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class RemoveTasksManagementTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestManeuverRules";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_SameLookSide_Left() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_SameLookSide_Left");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allTasks : allTasksAccepted.entrySet())
        {
            System.out.println(allTasks.getValue());
        }

        DroolsQueries dq = new DroolsQueries();
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();

        allMan = resourceFunctions.getAllManeuversSat1();
        assertEquals(2, allMan.size());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        ManeuverResources manRes = remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        System.out.println(manRes);
        assertEquals(manRes.getNewMans().size(), 0);
        assertEquals(manRes.getNewRumps().size(), 0);
        assertEquals(manRes.getOldRumps().size(), 0);
        assertEquals(manRes.getOldMans().size(), 2);
        assertEquals(dto2.getDtoId() + "_" + dto1.getDtoId(), manRes.getOldMans().get(0).getIdTask());
        assertEquals(dto1.getDtoId() + "_" + dto3.getDtoId(), manRes.getOldMans().get(1).getIdTask());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        allMan = resourceFunctions.getAllManeuversSat1();
        assertEquals(0, allMan.size());

    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_SameLookSide_Right() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_SameLookSide_Right");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allTasks : allTasksAccepted.entrySet())
        {
            System.out.println(allTasks.getValue());
        }

        DroolsQueries dq = new DroolsQueries();
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();

        allMan = resourceFunctions.getAllManeuversSat1();
        assertEquals(2, allMan.size());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        ManeuverResources manRes = remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        System.out.println(manRes);
        assertEquals(manRes.getNewMans().size(), 0);
        assertEquals(manRes.getNewRumps().size(), 0);
        assertEquals(manRes.getOldRumps().size(), 0);
        assertEquals(manRes.getOldMans().size(), 2);
        assertEquals(dto2.getDtoId() + "_" + dto1.getDtoId(), manRes.getOldMans().get(0).getIdTask());
        assertEquals(dto1.getDtoId() + "_" + dto3.getDtoId(), manRes.getOldMans().get(1).getIdTask());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        allMan = resourceFunctions.getAllManeuversSat1();
        assertEquals(0, allMan.size());

    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_SameLookSide_Right_FailedBeforeMan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_SameLookSide_Right");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        StubResources stub = new StubResources();
        PAW newPaw = stub.createPaw(3, "SAT_1", "10/10/2017 12:39:00", "10/10/2017 12:41:00", PAWType.GENERIC);
        this.droolsParams.getAllPAWS().add(newPaw);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allTasks : allTasksAccepted.entrySet())
        {
            System.out.println(allTasks.getValue());
        }
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();

        allMan = resourceFunctions.getAllManeuversSat1();
        assertEquals(0, allMan.size());

        Acquisition acq = this.du.createParametricAcquisition(dto1.getDtoId(), "10/10/2017 12:39:00", "10/10/2017 12:40:00", dto1.getLookSide(), dto1.getSatelliteId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        ManeuverResources manRes = remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        System.out.println(manRes);
        assertEquals(0, manRes.getNewMans().size());
        assertEquals(0, manRes.getNewRumps().size());
        assertEquals(0, manRes.getOldRumps().size());
        assertEquals(0, manRes.getOldMans().size());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        allMan = resourceFunctions.getAllManeuversSat1();
        assertEquals(0, allMan.size());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsOnlyPrevious() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : testCreateRepairingManBetweenPreviousAndNext_existsOnlyPrevious");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsQueries dq = new DroolsQueries();

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto3.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        assertEquals(2, allMan.size());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsOnlyNextL() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : testCreateRepairingManBetweenPreviousAndNext_existsOnlyNext");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);


        DroolsQueries dq = new DroolsQueries();

        //DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto2.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        assertEquals(2, allMan.size());
    }

    

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsOnlyNextR() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : testCreateRepairingManBetweenPreviousAndNext_existsOnlyNext");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsQueries dq = new DroolsQueries();

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto3.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        assertEquals(2, allMan.size());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_DifferentLookSideLR() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsQueries dq = new DroolsQueries();

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto3.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        assertEquals(2, allMan.size());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_DifferentLookSideRL() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsQueries dq = new DroolsQueries();

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto3.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        assertEquals(2, allMan.size());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsPrevAndNext_DifferentLookSideRL_CMGA() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().clear();

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsQueries dq = new DroolsQueries();

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto3.getDtoId());
        System.out.println(acq);

        RemoveTasksManagement remTaskMng = new RemoveTasksManagement();
        remTaskMng.createRepairingManBetweenPreviousAndNext(acq, this.sessionId, this.currentKieSession, this.droolsParams, resourceFunctions);

        TreeMap<Long, Maneuver> allMan = resourceFunctions.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat("!");

        System.out.println(allMan);
        System.out.println(allAcq);

        assertEquals(2, allMan.size());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsOnlyPrevRight() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsOnlyNextRight() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());
    }

    @Test
    public void testCreateRepairingManBetweenPreviousAndNext_existsOnlyNextLeft() throws Exception
    {

        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());
    }

    @Test
    public void testRemoveManeuver() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_Maneuver_Rw");
        this.droolsParams.getAllPAWS().clear();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:30:00", "10/10/2017 12:31:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:01:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        ResourceFunctions resourceFunctions = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        System.out.println(resourceFunctions.getAllManeuversSat1());

        TreeMap<Long, Maneuver> allManSat = resourceFunctions.getAllManeuversSat1();
        assertEquals(2, allManSat.size());
        RemoveTasksManagement rmvTasks = new RemoveTasksManagement();
        List<Maneuver> associatedMan = new ArrayList<>();

        associatedMan.add(allManSat.firstEntry().getValue());
        associatedMan.add(allManSat.lastEntry().getValue());

        rmvTasks.removeManeuver("1", associatedMan, this.droolsParams, resourceFunctions, this.sessionId, this.currentKieSession, false, false, null);
    }

}
