
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.text.ParseException;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;

public class DroolsEnvironmentTest
{

    private DroolsOperations droolsInstance = null;
    private DroolsParameters droolsParams = null;
    private DroolsUtils du = null;
    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private double maxBicForTest = 0;
    private double extraCostLeft = 0;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestMaxNumberPrType";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        this.du = new DroolsUtils();
        this.extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, this.extraCostLeft);
    }

    @Test
    public void testConcatenePath() throws Exception
    {
        String testPath = "test";
        String testName = "Environment";
        String result = DroolsEnvironment.concatenePath(testPath, testName);
        String expectedResults = testPath.concat(File.separator).concat(testName).concat(File.separator).concat("config");
        assertEquals(expectedResults, result);
    }

    @Test
    public void testConcatenePathSeparator() throws Exception
    {
        String testPath = "test/";
        String testName = "Environment";
        String result = DroolsEnvironment.concatenePath(testPath, testName);
        String expectedResults = testPath.concat(testName).concat(File.separator).concat("config");
        assertEquals(expectedResults, result);
    }

    @Test
    public void testCreateKieContainer_useInternalDrlFile() throws Exception
    {
        String sessionId = "testSession";
        int numberOfSessions = 12;
        this.du.setUpDrools(sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().createKieContainer(sessionId, numberOfSessions, this.droolsParams);
    }

    @Test
    public void testCreateKieContainer_useExternalDrlFile() throws Exception
    {
        String sessionId = "testSession";
        int numberOfSessions = 12;
        this.du.setUpDrools(sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().createKieContainer(sessionId, numberOfSessions, this.droolsParams);
    }

    @Test
    public void testSetUpDroolsException() throws Exception
    {
        String sessionId = "sessionIdTest";
        DroolsOperations droolsInstance = new DroolsOperations();
        this.du.setUpDrools(sessionId, this.droolsParams, droolsInstance);
    }

    @Test
    public void TestGetPowerAssociatedWithSensorModeUL_lowerBound() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        TypeOfAcquisition sensorModeToSearch = TypeOfAcquisition.SPOTLIGHT_1_MSOR;
        boolean lowerBound = true;
        double expectedValue = 18603.59;
        double returnedValue = this.droolsParams.getPowerAssociatedWithSensorModeUL(sensorModeToSearch, lowerBound);
        assertEquals(expectedValue, returnedValue, 0);
    }

    @Test
    public void TestGetPowerAssociatedWithSensorModeUL_upperBound() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        TypeOfAcquisition sensorModeToSearch = TypeOfAcquisition.SPOTLIGHT_1_MSOR;
        boolean lowerBound = false;
        double expectedValue = 23635.73;
        double returnedValue = this.droolsParams.getPowerAssociatedWithSensorModeUL(sensorModeToSearch, lowerBound);
        assertEquals(expectedValue, returnedValue, 0);
    }

    @Test
    public void testSetUpSession() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
    }

    @Test
    public void testSetUpSession_VU_session() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
    }

    @Test
    public void testSetUpSession_noSessionAvailable() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
    }

    @Test
    public void testInit_localPath() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("testInit_localPath");

        System.out.println("sat properties : " + this.droolsParams.getPercentBicDi2sMasterMSOR());
        String pathForTest = "config";
        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, true);

        System.out.println("sat properties : " + this.droolsParams.getPercentBicDi2sMasterMSOR());
        SatelliteProperties satProp1 = this.droolsParams.getSatWithId("1").getSatelliteProperties();
        System.out.println("sat prop : " + satProp1);

        SatelliteProperties satProp2 = this.droolsParams.getSatWithId("2").getSatelliteProperties();
        System.out.println("sat prop : " + satProp2);
    }

    @Test
    public void testInit_completePath() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testInit_completePath");
        String pathForTest = "config";
        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, false);
    }

    @Test
    public void testSetUpFixedOrbitHpMap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testSetUpFixedOrbitHpMap");
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams,this.droolsInstance);
    }
    

    @Test
    public void testSetUpFixedOrbitHpMapVU() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.urgent, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testSetUpFixedOrbitHpMap");
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams,this.droolsInstance);
    }

    @Test
    public void testCreateKieContainer_errorInDrlFile() throws Exception
    {
        String sessionId = "testSession";
        int numberOfSessions = 12;
        this.du.setUpDrools(sessionId, this.droolsParams, this.droolsInstance);
        String drlRuleFileWithError = "C:\\Users\\fpedrola\\git\\SPLA_BRM_NEW\\configTest\\droolsRulesFake.drl";
        this.droolsParams.setDrlRulesFile(drlRuleFileWithError);
        this.droolsInstance.getDroolsEnvironment().createKieContainer(sessionId, numberOfSessions, this.droolsParams);
    }

    @Test
    public void testPopulateDroolsParameters() throws Exception
    {
        String sessionId = "testSession";
        int numberOfSessions = 12;
        this.du.setUpDrools(sessionId, this.droolsParams, this.droolsInstance);
        String pathforTest ="configTest/";
        this.droolsInstance.getDroolsEnvironment().init(droolsParams, pathforTest, true);
        this.droolsInstance.getDroolsEnvironment().createKieContainer(sessionId, numberOfSessions, this.droolsParams);
        this.droolsInstance.getDroolsEnvironment().populateDroolsParameters(this.droolsParams);
    }
    
    @Test
    public void testPopulateDroolsParameters_bicSlaveMoreThan100() throws Exception
    {
        String sessionId = "testSession";
        int numberOfSessions = 12;
        this.du.setUpDrools(sessionId, this.droolsParams, this.droolsInstance);
        String pathforTest ="configTest/";
        this.droolsInstance.getDroolsEnvironment().init(droolsParams, pathforTest, true);
        this.droolsInstance.getDroolsEnvironment().createKieContainer(sessionId, numberOfSessions, this.droolsParams);
        this.droolsInstance.getDroolsEnvironment().populateDroolsParameters(this.droolsParams);
    }
    
    @Test
    public void testInit() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testInit_completePath");
        String pathForTest = "config";
        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, true);
    }

}
