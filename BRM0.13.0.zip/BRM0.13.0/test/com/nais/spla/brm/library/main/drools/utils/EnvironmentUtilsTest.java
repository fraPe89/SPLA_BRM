
package com.nais.spla.brm.library.main.drools.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SatelliteProperties;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.exception.ConfigurationException;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.SatelliteState;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.utils.MinTimeRight;

public class EnvironmentUtilsTest
{

    private DroolsOperations droolsInstance = null;
    private EnvironmentUtils envUtils = null;
    private DroolsParameters droolsParams = null;
    private DroolsUtils du = null;
    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private double maxBicForTest = 0;
    private double extraCostLeft = 0;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestMaxNumberPrType";
        this.droolsParams = new DroolsParameters();
        this.envUtils = new EnvironmentUtils();
        this.PDHTMaxMemory = 500000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        this.du = new DroolsUtils();
        this.extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, this.extraCostLeft);
    }

    @Test
    public void testSetAllResources() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        ResourceFunctions resFunc = (ResourceFunctions) kie.getGlobal("resourceFunctions");
        SatelliteProperties satProp1 = this.droolsParams.getSatWithId("1").getSatelliteProperties();
        SatelliteProperties satProp2 = this.droolsParams.getSatWithId("2").getSatelliteProperties();

        this.envUtils.setAllResources(this.droolsParams, resFunc, kie, satProp1, satProp2);

        System.out.println("DWL TREEMAP : " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
    }

    @Test
    public void incorrectMHTest()
    {
        this.du = new DroolsUtils();
        this.sessionId = "EssEnergyManagementTest";
        this.PDHTMaxMemory = 500000L;
        StubResources stub = new StubResources();
        MissionHorizon mh = stub.createMH("10/10/2017 06:21fff0", "10/10/2017 18:21:00");
        System.out.println(mh);
    }

    @Test
    public void incorrectSatState() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.du = new DroolsUtils();
        this.sessionId = "EssEnergyManagementTest";
        this.PDHTMaxMemory = 500000L;
        StubResources stub = new StubResources();
        SatelliteState satState = stub.createSatelliteState("sat_1", "10/10/2017 06:21fff0", "10/10/2017 18:21:00");
        System.out.println(satState);
    }

    @Test
    public void incorrectVisibility() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.du = new DroolsUtils();
        this.sessionId = "EssEnergyManagementTest";
        this.PDHTMaxMemory = 500000L;
        StubResources stub = new StubResources();
        Visibility vis = stub.createVisibility(3l, "satId", "acqStatId", "ownerId", "10/10/2017 06:21fff0", "10/10/2017 18:21:00");
        System.out.println(vis);
    }

    @Test
    public void testComputeOrbitValuesNumberFormatException() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        int minutesForSingleOrbit = 97;
        String[] orbits = new String[2];
        orbits[0] = "21";
        orbits[1] = "formatExcept";
        this.envUtils.computeOrbitValues(minutesForSingleOrbit, orbits);
    }

    @Test
    public void testComputeOrbitValuesNullPointerException() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        int minutesForSingleOrbit = 97;
        String[] orbits = null;
        this.envUtils.computeOrbitValues(minutesForSingleOrbit, orbits);
    }

    @Test
    public void testProcessTypeOfPawExcludedFromStoreAux() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        SatelliteProperties satProp = new SatelliteProperties();
        String allTypeOfPawExcludedFromStoreAux = "STTOCCULTATION, cal";

        assertTrue(satProp.getPawExclusionList().size() == 0);

        this.envUtils.processTypeOfPawExcludedFromStoreAux(allTypeOfPawExcludedFromStoreAux, satProp);

        System.out.println("paw exclusion list : " + satProp.getPawExclusionList());
        assertTrue(satProp.getPawExclusionList().size() == 2);

    }

    @Test(expected = ConfigurationException.class)
    public void testLoadPropertiesFile_useExternal() throws ConfigurationException, Exception
    {
        String pathforTest = "";
        boolean useTestPropertiesFiles = false;
        Properties fakeProp = new Properties();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();
        System.out.println("COMPLETE PATH :" + completePath);
        this.envUtils.loadPropertiesFile("fakeProp.config", fakeProp, pathforTest, completePath, "brm", useTestPropertiesFiles);
    }

    @Test
    public void testLoadPropertiesFile_cannotFindFile() throws ConfigurationException, Exception
    {
        String pathforTest = "";
        boolean useTestPropertiesFiles = false;
        Properties fakeProp = new Properties();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();

        this.envUtils.loadPropertiesFile("sat1.properties", fakeProp, pathforTest, completePath, "brm", useTestPropertiesFiles);
    }

    @Test
    public void testGetPropertiesByName_found() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testInit_completePath");
        String pathForTest = "configTest";
        Properties prop = new Properties();
        String FIRST_SATELLITE_CONFIG_FILENAME = "sat1Test.properties";
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();
        System.out.println("Complete path : " + completePath);
        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, false);
        this.envUtils.loadPropertiesFile(FIRST_SATELLITE_CONFIG_FILENAME, prop, pathForTest, completePath, "brm", true);

        String upperBoundPeakOrbit = this.envUtils.getPropertiesByName("upperBoundPeakOrbit", prop, FIRST_SATELLITE_CONFIG_FILENAME, this.droolsInstance.getDroolsEnvironment().readSplaEnv());
        assertEquals("24", upperBoundPeakOrbit);
        System.out.println("upperBoundPeakOrbit : " + upperBoundPeakOrbit);
    }

    @Test
    public void testGetPropertiesByName_not_found() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testInit_completePath");
        String pathForTest = "configTest";
        Properties satProp1 = new Properties();
        String FIRST_SATELLITE_CONFIG_FILENAME = "sat1Test.properties";

        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, false);
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();
        System.out.println("Complete path : " + completePath);
        this.envUtils.loadPropertiesFile(FIRST_SATELLITE_CONFIG_FILENAME, satProp1, pathForTest, completePath, "brm", true);
        String startTypeOfMan = this.envUtils.getPropertiesByName("startTypeOfMan", satProp1, FIRST_SATELLITE_CONFIG_FILENAME, this.droolsInstance.getDroolsEnvironment().readSplaEnv());
        System.out.println("upperBoundPeakOrbit : " + startTypeOfMan);
    }

    @Test
    public void testLoadPropertiesFile_useLocal() throws ConfigurationException, Exception
    {
        boolean useTestPropertiesFiles = true;
        String pathForTest = "config";
        Properties satProp1 = new Properties();
        String FIRST_SATELLITE_CONFIG_FILENAME = "sat1.properties";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();
        System.out.println("Complete path : " + completePath);
        this.envUtils.loadPropertiesFile(FIRST_SATELLITE_CONFIG_FILENAME, satProp1, pathForTest, completePath, "brm", useTestPropertiesFiles);
    }

    @Test(expected = ConfigurationException.class)
    public void testCheckNullValue_null() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        String value = null;
        this.envUtils.checkNullValue(value, "value not setted");
    }

    @Test
    public void testReadFileOfMaxLeftTime() throws Exception
    {
        String completePath = "src/main/resources/config";
        String MAX_TIME_LEFT_FILENAME = "maxLeft.txt";
        TreeMap<Double, List<MinTimeRight>> maxTimeLeft = new TreeMap<>();
        String propertiesFilePath = EnvironmentUtils.concatenePath(completePath, MAX_TIME_LEFT_FILENAME);

        this.envUtils.readFileOfMaxLeftTime(maxTimeLeft, propertiesFilePath);
    }

    @Test(expected = NullPointerException.class)
    public void testGetPropertiesByName_null() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testInit_completePath");
        String pathForTest = "configTest";
        Properties prop = new Properties();
        String FIRST_SATELLITE_CONFIG_FILENAME = "sat1Test.properties";
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();
        System.out.println("Complete path : " + completePath);
        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, false);
        this.envUtils.loadPropertiesFile(FIRST_SATELLITE_CONFIG_FILENAME, prop, pathForTest, completePath, "brm", true);

        this.envUtils.getPropertiesByName(null, prop, FIRST_SATELLITE_CONFIG_FILENAME, this.droolsInstance.getDroolsEnvironment().readSplaEnv());
    }

    @Test
    public void testComputeOrbitValues_formatException() throws ConfigurationException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("testInit_completePath");
        String pathForTest = "configTest";
        Properties prop = new Properties();
        String FIRST_SATELLITE_CONFIG_FILENAME = "sat1Test.properties";
        String completePath = this.droolsInstance.getDroolsEnvironment().composeCompleteModulePath();
        System.out.println("Complete path : " + completePath);
        this.droolsInstance.getDroolsEnvironment().init(this.droolsParams, pathForTest, false);
        this.envUtils.loadPropertiesFile(FIRST_SATELLITE_CONFIG_FILENAME, prop, pathForTest, completePath, "brm", true);
        int minutesForSingleOrbit = 97;
        String[] orbits = null;
        this.envUtils.computeOrbitValues(minutesForSingleOrbit, orbits);
    }

}
