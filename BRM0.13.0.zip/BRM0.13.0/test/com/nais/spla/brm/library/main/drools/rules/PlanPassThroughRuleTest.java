
package com.nais.spla.brm.library.main.drools.rules;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class PlanPassThroughRuleTest
{

    private StubResources stub = null;
    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestOPlanPassThroughRule";
        this.stub = new StubResources();
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void Test_passthrough_overlap_acq() throws Exception
    {
        System.out.println("Running test : Test_passthrough_overlap_acq \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:13:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // inserting a valid dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:08:30", "10/10/2017 08:11:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto2.setPtAvailable(true);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containExpectedReason = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.passThroughOverlapAcq);
        assertEquals(true, containExpectedReason);
    }

    @Test
    public void Test_passthrough_single_pol_VV_created_and_removed() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:13:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPol(Polarization.VV);
        dto1.setSizeV(1200);
        dto1.setSizeH(0);
        dto1.setPtAvailable(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 AFTER REMOVE " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

    }

    @Test
    public void Test_passthrough_single_pol_HH_created_and_removed() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:13:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1200);
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 AFTER REMOVE " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void Test_passthrough_single_pol_HH_noVisAssociated() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:13:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1200);
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected " + rejected);

    }

    @Test
    public void Test_passthrough_single_pol_HH_and_Download() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:13:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1200);
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:11:30", "10/10/2017 07:13:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(1200);
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto2.setPtAvailable(false);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

        System.out.println("all tasks :" + this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
        // droolsInstance.retractSingleAcq(dto1.getDtoId(), currentKieSession);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 AFTER REMOVE " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

    }

    @Test
    public void Test_passthrough_double_pol_VH_created_and_removed() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:12:00", "right", "SAT_1");
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(100);
        dto1.setSizeV(100);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreemap = resFunc.getDwlFunctionAssociatedToSat("SAT_1");

        System.out.println("DWL treemap after pt : " + dwlTreemap);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 AFTER REMOVE " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void Test_passthrough_double_pol_VH_notEnoughSpaceOnVis() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        this.droolsParams.getAllVisibilities().add(vis2);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:12:00", "right", "SAT_1");
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(400);
        dto1.setSizeV(400);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected " + rejected);
    }

    @Test
    public void Test_passthrough_double_pol_HV_created_and_removed() throws Exception
    {
        System.out.println("Running test : Test_passthrough_created_and_removed \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:12:00", "right", "SAT_1");
        dto1.setPol(Polarization.VH);
        dto1.setSizeH(1000);
        dto1.setSizeV(1000);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("GET ALL DWL FOR SAT 1 " + resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreemap = resFunc.getDwlFunctionAssociatedToSat("SAT_1");

        System.out.println("DWL treemap after pt : " + dwlTreemap);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        /*
         * droolsInstance.retractSingleAcq(dto1.getDtoId(), currentKieSession);
         *
         *
         * resFunc = (ResourceFunctions)
         * droolsInstance.getGlobal(currentKieSession, "resourceFunctions");
         * System.out.println("GET ALL DWL FOR SAT 1 AFTER REMOVE " +
         * resFunc.getDwlFunctionAssociatedToSat("SAT_1"));
         */
    }

    @Test
    public void Test_acq_ovedrlap_passthrough() throws ParseException, Exception
    {
        System.out.println("\n\n Running test : Test_acq_ovedrlap_passthrough \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:12:00", "right", "SAT_1");

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // inserting a valid dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:13:30", "10/10/2017 08:14:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertEquals(false, accepted);

        Map<String, Task> acceptedElements = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : acceptedElements.entrySet())
        {
            System.out.println("accepted : " + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containExpectedReason = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithPassThrough);
        assertEquals(true, containExpectedReason);
    }

    @Test
    public void Test_passthrough_ovedrlap_passthrough() throws ParseException, Exception
    {
        System.out.println("\n\n Running test : Test_acq_ovedrlap_passthrough \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setDtoId("100_PR-ITA-001-HP_AR-001_DTO-1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // inserting a valid dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:13:30", "10/10/2017 08:15:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto2.setPtAvailable(true);
        dto2.setUserInfo(userInfoList);
        dto2.setDtoId("100_PR-ITA-002-HP_AR-002_DTO-2");
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Task> acceptedElements = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : acceptedElements.entrySet())
        {
            System.out.println("accepted : " + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containExpectedReason = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithPassThrough);
        assertEquals(true, containExpectedReason);
    }

    @Test
    public void Test_passthrough_and_passthrough() throws ParseException, Exception
    {
        System.out.println("\n\n Running test : Test_acq_ovedrlap_passthrough \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:30:00");
        this.droolsParams.getAllVisibilities().add(vis2);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:11:30", "10/10/2017 08:12:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPtAvailable(true);
        dto1.setPol(Polarization.HH);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(new ArrayList<>(Arrays.asList("1110", "KIR")), false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(new ArrayList<>(Arrays.asList("1200", "KOR")), false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setDtoId("100_PR-ITA-001-HP_AR-001_DTO-1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // inserting a valid dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:13:30", "10/10/2017 08:15:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto2.setPtAvailable(true);
        dto2.setPol(Polarization.VV);
        dto2.setSizeV(200);
        dto2.setSizeH(0);
        dto2.setUserInfo(userInfoList);
        dto2.setDtoId("100_PR-ITA-002-HP_AR-002_DTO-2");
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Task> acceptedElements = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : acceptedElements.entrySet())
        {
            System.out.println("accepted : " + elements.getValue());
        }

        System.out.println("vis : " + vis2);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
    }

}
