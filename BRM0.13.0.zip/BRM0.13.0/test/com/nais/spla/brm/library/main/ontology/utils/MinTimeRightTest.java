
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MinTimeRightTest
{

    @Test
    public void testMinTimeRight() throws Exception
    {
        double totalEssLR = 300;

        double onlyEssL = 200;

        double timeInRight = 34;

        MinTimeRight minTimeRight1 = new MinTimeRight();
        minTimeRight1.setOnlyEssL(onlyEssL);
        minTimeRight1.setTimeInRight(timeInRight);
        minTimeRight1.setTotalEssLR(totalEssLR);

        MinTimeRight minTimeRight2 = new MinTimeRight(totalEssLR, onlyEssL, timeInRight);
        assertEquals(onlyEssL, minTimeRight2.getOnlyEssL(), 0);
        assertEquals(timeInRight, minTimeRight2.getTimeInRight(), 0);
        assertEquals(totalEssLR, minTimeRight2.getTotalEssLR(), 0);

        assertEquals(minTimeRight1.toString(), minTimeRight2.toString());

    }
}
