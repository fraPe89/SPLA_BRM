
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class DroolsQueriesTest
{

    private DroolsQueries droolsQueries = null;
    private TaskPlanned taskPlanned = null;
    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsOperations = null;
    private DroolsUtils du = null;
    private StubResources stub = null;
    private double maxBicForTest = 0;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "DroolsQueriesTest";
        this.droolsQueries = new DroolsQueries();
        this.droolsParams = new DroolsParameters();
        this.taskPlanned = new TaskPlanned();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        this.stub = new StubResources();
        double extraCostLeft = 10;
        this.droolsOperations = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    @Test
    public void getAllAcquisitionsTester() throws Exception
    {
        System.out.println("\n\n Running test : getAllAcquisitionsTester");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        DTO dto = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "right", satelliteId);
        dto.setPol(Polarization.HH);
        dto.setSizeH(400);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Acquisition> allAcqSat1 = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        System.out.println("all acq from query for sat : " + satelliteId + " : " + allAcqSat1);
        assertEquals(1, allAcqSat1.size());

        List<Acquisition> allAcqSat2 = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_2");

        System.out.println("all acq from query for sat : SAT_2 : " + allAcqSat2);
        assertEquals(0, allAcqSat2.size());
    }

    @Test
    public void testFindPartnerInList_foundPartner() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        System.out.println("all partners ;" + allPartners);
        Partner p1 = allPartners.get(0);
        Partner receivedPartner = this.droolsQueries.findPartnerInList(p1.getPartnerId(), allPartners);
        assertEquals(p1, receivedPartner);
    }

    @Test
    public void testFindPartnerInList_not_found() throws Exception
    {
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        String partnerId = "fakePartnerId";
        Partner returnedPartner = this.droolsQueries.findPartnerInList(partnerId, allPartners);
        assertEquals(null, returnedPartner);
    }

    @Test
    public void getAllManeuversTester() throws Exception
    {
        System.out.println("\n\n Running test : getAllManeuversTester");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:56:00", "10/10/2017 08:57:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:51:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Maneuver> allManSat1 = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);
        System.out.println("all man from query for sat : " + satelliteId + " : " + allManSat1);
        assertTrue(allManSat1.size() > 0);

        List<Maneuver> allManSat2 = this.droolsQueries.getAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_2");
        System.out.println("all man from query for sat SAT_2 : " + allManSat2);
        assertEquals(0, allManSat2.size());
    }

    @Test
    public void getAllRampsTester() throws Exception
    {
        System.out.println("\n\n Running test : getAllRampsTester");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:56:00", "10/10/2017 08:57:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:51:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Maneuver> allManSat1 = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        // List<Maneuver> allManSat1 =
        // droolsQueries.getAllManeuvers(droolsParams,satelliteId);
        System.out.println("all mans from query for sat : " + satelliteId + " : " + allManSat1);
        assertTrue(allManSat1.size() > 0);

        List<RampCMGA> allRampsSat1 = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);
        System.out.println("all ramps from query for sat : " + satelliteId + " : " + allRampsSat1);
        assertEquals(2, allRampsSat1.size());

        List<Maneuver> allManSat2 = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "sat_2");
        System.out.println("all mans from query for sat SAT_2 : " + allManSat2);
        assertEquals(0, allManSat2.size());

        List<RampCMGA> allRampsSat2 = this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "sat_2");
        System.out.println("all ramps from query for sat SAT_2 : " + allRampsSat2);
        assertEquals(0, allRampsSat2.size());
    }

    @Test
    public void testGetAllAcqOnSameFixedOrbit() throws Exception
    {
        System.out.println("\n\n Running test : testGetAllAcqOnSameFixedOrbit");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        int revNumberToSearch = 1;

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq1.setRevolutionNumber(revNumberToSearch);

        Acquisition acq2 = this.du.createParametricAcquisition("dto2", "10/10/2017 12:12:00", "10/10/2017 12:13:00", "left", "SAT_1");
        acq2.setRevolutionNumber(2);

        Acquisition acq3 = this.du.createParametricAcquisition("dto3", "10/10/2017 12:41:00", "10/10/2017 12:42:00", "left", "SAT_1");
        acq3.setRevolutionNumber(revNumberToSearch);
        this.droolsParams.setCurrentSession(this.sessionId);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(acq1);
        kie.insert(acq2);
        kie.insert(acq3);

        List<Acquisition> allAcqOnSameFixedOrbit = this.droolsQueries.getAllAcqOnSameFixedOrbit(this.sessionId, this.currentKieSession, this.droolsParams, revNumberToSearch);
        System.out.println("all acq on same fixed orbit returned from query : " + allAcqOnSameFixedOrbit);
        assertEquals(2, allAcqOnSameFixedOrbit.size());
    }

    @Test
    public void testGetAllPawOverlapInterval() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 12:26:00", "10/10/2017 12:43:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1, paw2, paw3, paw4));

        this.droolsParams.setAllPAWS(allPaws);
        System.out.println("\n\n Running test : testGetAllPawOverlapInterval");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Date startCheck = DroolsUtils.createDate("10/10/2017 12:30:00");
        Date endCheck = DroolsUtils.createDate("10/10/2017 15:41:00");

        String satelliteId = "SAT_1";
        List<PAW> allPAWInOverlap = this.droolsQueries.getAllPawOverlapInterval(this.droolsParams, startCheck, endCheck, satelliteId);

        System.out.println("all paw in overlap : " + allPAWInOverlap);
        assertEquals(2, allPAWInOverlap.size());
    }

    @Test
    public void testGetAllVisOverlapOrAfterDate() throws Exception
    {

        this.droolsParams.getAllVisibilities().clear();

        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KIR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "KIR", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "KIR", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis9 = this.stub.createVisibility(8, "SAT_1", "KIR", "Partner_2", "10/10/2017 18:10:00", "10/10/2017 18:15:00");
        Visibility vis10 = this.stub.createVisibility(9, "SAT_1", "KIR", "Partner_2", "10/10/2017 20:00:00", "10/10/2017 22:50:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = this.stub.createVisibility(5, "SAT_2", "KIR", null, "10/10/2017 08:00:00", "10/10/2017 08:20:00");
        Visibility vis7 = this.stub.createVisibility(6, "SAT_2", "KIR", null, "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        Visibility vis8 = this.stub.createVisibility(7, "SAT_2", "KIR", "Partner_1", "10/10/2017 17:50:00", "10/10/2017 18:21:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7, vis8, vis9, vis10));
        System.out.println("\n\n Running test : testGetAllVisOverlapOrAfterDate");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        Date startCheck = DroolsUtils.createDate("10/10/2017 10:41:00");
        String satelliteId = "SAT_1";
        List<Visibility> allVisibilityAfterDate = this.droolsQueries.getAllVisOverlapOrAfterDate(this.sessionId, this.currentKieSession, this.droolsParams, startCheck, satelliteId);

        for (int i = 0; i < allVisibilityAfterDate.size(); i++)
        {
            System.out.println(allVisibilityAfterDate.get(i));
        }
        assertTrue(allVisibilityAfterDate.size() == 3);
        assertTrue(allVisibilityAfterDate.contains(vis3));
        assertTrue(allVisibilityAfterDate.contains(vis4));
        assertTrue(allVisibilityAfterDate.contains(vis9));
    }

    @Test
    public void testGetAllVisOverlapOrAfterDate_nullCase() throws Exception
    {

        this.droolsParams.getAllVisibilities().clear();

        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KIR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "KIR", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "KIR", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = this.stub.createVisibility(5, "SAT_2", "KIR", null, "10/10/2017 08:00:00", "10/10/2017 08:20:00");
        Visibility vis7 = this.stub.createVisibility(6, "SAT_2", "KIR", null, "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        Visibility vis8 = this.stub.createVisibility(7, "SAT_2", "KIR", "Partner_1", "10/10/2017 17:50:00", "10/10/2017 18:21:00");
        Visibility vis9 = this.stub.createVisibility(8, "SAT_1", "KIR", "Partner_2", "10/10/2017 18:10:00", "10/10/2017 18:15:00");
        Visibility vis10 = this.stub.createVisibility(9, "SAT_1", "KIR", "Partner_2", "10/10/2017 20:00:00", "10/10/2017 22:50:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7, vis8, vis9, vis10));
        System.out.println("\n\n Running test : testGetAllAcqOnSameFixedOrbit");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        Date startCheck = DroolsUtils.createDate("10/10/2017 23:41:00");
        String satelliteId = "SAT_1";
        List<Visibility> allVisibilityAfterDate = this.droolsQueries.getAllVisOverlapOrAfterDate(this.sessionId, this.currentKieSession, this.droolsParams, startCheck, satelliteId);

        assertTrue(allVisibilityAfterDate.size() == 0);
    }

    @Test
    public void testGetRelatedDi2sInfo() throws Exception
    {
        System.out.println("\n\n Running test : testGetAllAcqOnSameFixedOrbit");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        master.setDi2s(true);
        master.setPrMode(PRMode.DI2S);
        master.setRevolutionNumber(1);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(1);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerMaster.getPartnerId());
        userInfoSlave.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(true);
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());
        boolean accepted = this.droolsOperations.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertTrue(accepted);

        Di2sInfo di2sInfoReturned = this.droolsQueries.getRelatedDi2sInfo(this.sessionId, this.currentKieSession, this.droolsParams, master.getDtoId());
        System.out.println("di2s info : " + di2sInfoReturned);
    }

    @Test
    public void testGetRelatedDi2sInfo_not_exists() throws Exception
    {
        System.out.println("\n\n Running test : testGetAllAcqOnSameFixedOrbit");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        String dtoId = "DTO1";

        Di2sInfo di2sInfo = this.droolsQueries.getRelatedDi2sInfo(this.sessionId, this.currentKieSession, this.droolsParams, dtoId);
        System.out.println("di2s info : " + di2sInfo);
    }

    @Test
    public void testGetAllStoragesAndDownloadsAfterDate() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        String satId = "SAT_1";
        Date startCheck = DroolsUtils.createDate("10/10/2017 17:13:00");
        Date endCheck = DroolsUtils.createDate("10/10/2017 18:13:00");

        Storage sto1 = this.du.createStorage("sto1", "10/10/2017 17:13:00", "10/10/2017 17:14:00", satId, 200, 30, Polarization.HV); // included
        Storage sto2 = this.du.createStorage("sto2", "10/10/2017 17:10:00", "10/10/2017 17:12:00", satId, 200, 30, Polarization.HV); // excluded
        Storage sto3 = this.du.createStorage("sto3", "10/10/2017 17:50:00", "10/10/2017 17:56:00", satId, 200, 30, Polarization.HV); // included
        Storage sto4 = this.du.createStorage("sto4", "10/10/2017 12:32:00", "10/10/2017 12:36:00", satId, 200, 30, Polarization.HV); // excluded

        Download dwl1 = this.du.createDownload(satId, "10/10/2017 17:52:00", "10/10/2017 17:55:00", DownlinkStrategy.DELETE, true); // included
        Download dwl2 = this.du.createDownload(satId, "10/10/2017 18:12:00", "10/10/2017 18:16:00", DownlinkStrategy.DELETE, true); // included
        Download dwl3 = this.du.createDownload(satId, "10/10/2017 17:19:00", "10/10/2017 17:21:00", DownlinkStrategy.RETAIN, false); // included
        Download dwl4 = this.du.createDownload(satId, "10/10/2017 13:12:00", "10/10/2017 13:14:00", DownlinkStrategy.DELETE, false); // excluded

        List<Task> allDwlAndSto = new ArrayList<>(Arrays.asList(sto1, sto2, sto3, sto4, dwl1, dwl2, dwl3, dwl4));
        List<Task> allStoragesAndDownloadsAfterDate = this.droolsQueries.getAllStoragesAndDownloadsInInterval(startCheck.getTime(), endCheck.getTime(), allDwlAndSto);

        assertEquals(true, allStoragesAndDownloadsAfterDate.contains(sto1));
        assertEquals(true, allStoragesAndDownloadsAfterDate.contains(sto3));
        assertEquals(true, allStoragesAndDownloadsAfterDate.contains(dwl1));
        assertEquals(true, allStoragesAndDownloadsAfterDate.contains(dwl2));
        assertEquals(true, allStoragesAndDownloadsAfterDate.contains(dwl3));

        assertEquals(false, allStoragesAndDownloadsAfterDate.contains(sto2));
        assertEquals(false, allStoragesAndDownloadsAfterDate.contains(sto4));
        assertEquals(false, allStoragesAndDownloadsAfterDate.contains(dwl4));

        System.out.println(allStoragesAndDownloadsAfterDate);
    }

    @Test
    public void testGetAcqWithId() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto = this.du.createSingleDto("10/10/2017 12:23:00", "10/10/2017 12:23:00", "left", "SAT_1");
        dto.setSensorMode(TypeOfAcquisition.SCANSAR_1);

        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto.getDtoId());
        System.out.println("returned acq : " + returnedAcq);
        assertTrue(returnedAcq != null);
    }

    @Test
    public void testGetAllAcquisitionInInterval() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        this.droolsParams.setCurrentSession(this.sessionId);

        Date startCheck = DroolsUtils.createDate("10/10/2017 12:12:30");
        Date endCheck = DroolsUtils.createDate("10/10/2017 12:32:00");
        String satId = "SAT_1";
        this.droolsParams.setCurrentSession(this.sessionId);
        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "right", "SAT_1");
        Acquisition acq2 = this.du.createParametricAcquisition("dto2", "10/10/2017 12:12:00", "10/10/2017 12:13:00", "right", "SAT_1");
        Acquisition acq3 = this.du.createParametricAcquisition("dto3", "10/10/2017 12:41:00", "10/10/2017 12:42:00", "right", "SAT_1");

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(acq1);
        kie.insert(acq2);
        kie.insert(acq3);

        List<String> acqIdInInterval = this.droolsQueries.getAllAcquisitionInInterval(this.sessionId, this.currentKieSession, this.droolsParams, startCheck, endCheck, satId);
        System.out.println("acq in interval : " + acqIdInInterval);
        assertTrue(acqIdInInterval.size() == 2);
        assertTrue(acqIdInInterval.contains(acq1.getId()));
        assertTrue(acqIdInInterval.contains(acq2.getId()));
        assertFalse(acqIdInInterval.contains(acq3.getId()));
    }

    @Test
    public void testGetAllDwlInInterval() throws Exception
    {
        System.out.println("\n\n Running test : testGetAllDwlInInterval");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Download dwl1 = this.du.createDownload("SAT_1", "10/10/2017 17:50:00", "10/10/2017 17:52:00", DownlinkStrategy.DELETE, true);

        Download dwl2 = this.du.createDownload("SAT_2", "10/10/2017 17:40:00", "10/10/2017 17:41:00", DownlinkStrategy.DELETE, true);

        Download dwl3 = this.du.createDownload("SAT_1", "10/10/2017 18:15:00", "10/10/2017 18:17:00", DownlinkStrategy.DELETE, true);

        Download dwl4 = this.du.createDownload("SAT_1", "10/10/2017 18:47:00", "10/10/2017 18:49:00", DownlinkStrategy.DELETE, true);

        Download dwl5 = this.du.createDownload("SAT_1", "10/10/2017 18:51:00", "10/10/2017 18:52:00", DownlinkStrategy.DELETE, true);
        this.droolsParams.setCurrentSession(this.sessionId);

        PassThrough pt1 = new PassThrough();
        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        kie.insert(dwl1);
        kie.insert(dwl2);
        kie.insert(dwl3);
        kie.insert(dwl4);
        kie.insert(dwl5);
        kie.insert(pt1);

        Date startCheck = DroolsUtils.createDate("10/10/2017 17:51:00");
        Date endCheck = DroolsUtils.createDate("10/10/2017 18:48:00");
        String satToSearch = "SAT_1";

        List<Task> allDownloadsInInterval = this.droolsQueries.getAllDwlAndPtInInterval(this.sessionId, this.currentKieSession, this.droolsParams, startCheck, endCheck, satToSearch);
        System.out.println("all dwl in interval : " + allDownloadsInInterval);

        assertTrue(allDownloadsInInterval.contains(dwl1));
        assertFalse(allDownloadsInInterval.contains(dwl2));
        assertTrue(allDownloadsInInterval.contains(dwl3));
        assertTrue(allDownloadsInInterval.contains(dwl4));
        assertFalse(allDownloadsInInterval.contains(dwl5));

    }

    @Test
    public void testGetAllTaskRelatedToEquivalentDto() throws Exception
    {
        String equivDtoId = "equivDtoId";
        System.out.println("\n\n Running test : testGetAllTaskRelatedToEquivalentDto");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        this.droolsParams.setCurrentSession(this.sessionId);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "right", "SAT_1");
        acq1.setReferredEquivalentDto(equivDtoId);

        Storage sto1 = this.du.createStorage("sto1", "10/10/2017 17:13:00", "10/10/2017 17:14:00", "SAT_1", 200, 30, Polarization.HV);
        sto1.setReferredEquivalentDto(equivDtoId);

        Download dwl1 = this.du.createDownload("SAT_1", "10/10/2017 17:50:00", "10/10/2017 17:52:00", DownlinkStrategy.DELETE, true);
        dwl1.setReferredEquivalentDto(equivDtoId);

        kie.insert(acq1);
        kie.insert(sto1);
        kie.insert(dwl1);

        List<Task> tasksRelatedToEquivDto = this.droolsQueries.getAllTaskRelatedToEquivalentDto(this.sessionId, this.currentKieSession, this.droolsParams, "equivDtoId");
        System.out.println("all tasks related to equiv dto : " + tasksRelatedToEquivDto);
        assertEquals(3, tasksRelatedToEquivDto.size());
    }

    @Test
    public void testGetAllVisOverlapInterval() throws Exception
    {
        this.droolsParams.getAllVisibilities().clear();

        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:10:00", "10/10/2017 07:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KIR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "KIR", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "KIR", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 07:25:00", "10/10/2017 07:40:00");
        Visibility vis6 = this.stub.createVisibility(5, "SAT_2", "KIR", null, "10/10/2017 08:00:00", "10/10/2017 08:20:00");
        Visibility vis7 = this.stub.createVisibility(6, "SAT_2", "KIR", null, "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        Visibility vis8 = this.stub.createVisibility(7, "SAT_2", "KIR", "Partner_1", "10/10/2017 17:50:00", "10/10/2017 18:21:00");
        Visibility vis9 = this.stub.createVisibility(8, "SAT_1", "KIR", "Partner_2", "10/10/2017 18:10:00", "10/10/2017 18:15:00");
        Visibility vis10 = this.stub.createVisibility(9, "SAT_1", "KIR", "Partner_2", "10/10/2017 20:00:00", "10/10/2017 22:50:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7, vis8, vis9, vis10));
        System.out.println("\n\n Running test : testGetAllVisOverlapInterval");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Date startCheck = DroolsUtils.createDate("10/10/2017 07:00:00");
        Date endCheck = DroolsUtils.createDate("10/10/2017 08:00:00");

        String satelliteId = "SAT_1";
        List<Visibility> allVisibilityOverlap = this.droolsQueries.getAllVisOverlapInterval(this.droolsParams, startCheck, endCheck, satelliteId);
        System.out.println(allVisibilityOverlap);
        assertTrue(allVisibilityOverlap.size() == 1);
    }

    @Test
    public void testGetAllAcquisitions() throws Exception
    {
        System.out.println("\n\n Running test : testGetAllAcquisitions");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        this.droolsParams.setCurrentSession(this.sessionId);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "right", "SAT_1");

        Acquisition acq2 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:35:00", "10/10/2017 12:36:00", "right", "SAT_1");

        kie.insert(acq1);
        kie.insert(acq2);

        List<Acquisition> allAcq = this.droolsQueries.getAllAcquisitions(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        assertEquals(2, allAcq.size());
    }

    @Test
    public void testGetAllManeuvers() throws Exception
    {
        System.out.println("\n\n Running test : testGetAllManeuvers");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        Partner partnerForTest = this.droolsParams.getAllPartners().get(1);
        UserInfo userInfo = new UserInfo(this.droolsParams.getAllPartners().get(0).getPartnerId());

        userInfo.setUgsId(partnerForTest.getPartnerId());
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:23:00", "10/10/2017 12:24:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setImageBIC(5);
        dto1.setUserInfo(new ArrayList<>(Arrays.asList(userInfo)));

        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("accepted prev dto :" + accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:35:00", "10/10/2017 12:36:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setImageBIC(5);
        dto2.setUserInfo(new ArrayList<>(Arrays.asList(userInfo)));

        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        System.out.println("REJECTED :" + this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));
        List<Maneuver> allMan = this.droolsQueries.getAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("man :" + allMan);
        assertEquals(2, allMan.size());
    }

    @Test
    public void testGetStoWithGivenid() throws Exception
    {

        System.out.println("\n\n Running test : testGetAllManeuvers");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        Partner partnerForTest = this.droolsParams.getAllPartners().get(1);
        UserInfo userInfo = new UserInfo(this.droolsParams.getAllPartners().get(0).getPartnerId());
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        userInfo.setUgsId(partnerForTest.getPartnerId());
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:23:00", "10/10/2017 12:24:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setImageBIC(5);
        dto1.setUserInfo(new ArrayList<>(Arrays.asList(userInfo)));

        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("accepted prev dto :" + accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:35:00", "10/10/2017 12:36:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setImageBIC(5);
        dto2.setUserInfo(new ArrayList<>(Arrays.asList(userInfo)));

        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        System.out.println("REJECTED :" + this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));
        List<Maneuver> allMan = this.droolsQueries.getAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("man :" + allMan);
        assertEquals(2, allMan.size());

        Storage stoRelatedToDto1 = this.droolsQueries.getStoWithGivenid(resFunc.getStoragesAssociatedToSat("SAT_1"), dto1.getDtoId());
        System.out.println(stoRelatedToDto1);

        Storage stoRelatedToDto2 = this.droolsQueries.getStoWithGivenid(resFunc.getStoragesAssociatedToSat("SAT_1"), dto2.getDtoId());
        System.out.println(stoRelatedToDto2);
    }

	@Test
	public void testGetAcqWithIdFromHashMap() throws Exception {
        System.out.println("\n\n Running test : testGetAllManeuvers");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        Partner partnerForTest = this.droolsParams.getAllPartners().get(1);
        UserInfo userInfo = new UserInfo(this.droolsParams.getAllPartners().get(0).getPartnerId());
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        userInfo.setUgsId(partnerForTest.getPartnerId());
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:23:00", "10/10/2017 12:24:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setImageBIC(5);
        dto1.setUserInfo(new ArrayList<>(Arrays.asList(userInfo)));

        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("accepted prev dto :" + accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:35:00", "10/10/2017 12:36:00", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setImageBIC(5);
        dto2.setUserInfo(new ArrayList<>(Arrays.asList(userInfo)));

        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        System.out.println("REJECTED :" + this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));
        List<Maneuver> allMan = this.droolsQueries.getAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("man :" + allMan);
        assertEquals(2, allMan.size());

        Storage stoRelatedToDto1 = this.droolsQueries.getStoWithGivenid(resFunc.getStoragesAssociatedToSat("SAT_1"), dto1.getDtoId());
        System.out.println(stoRelatedToDto1);
        Map<String, Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession,  droolsParams, "SAT_1");

        Acquisition acq2 = this.droolsQueries.getAcqWithIdFromHashMap((HashMap<String, Acquisition>) allAcq, dto2.getDtoId());
        System.out.println(acq2);	}

}
