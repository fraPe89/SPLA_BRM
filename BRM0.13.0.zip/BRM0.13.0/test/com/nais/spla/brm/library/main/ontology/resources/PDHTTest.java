
package com.nais.spla.brm.library.main.ontology.resources;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class PDHTTest
{

    private PDHT pdht = null;

    @Before
    public void setUp()
    {
        String pdhtId = "pdht1";
        String pdhtName = "pdhtname";
        String satelliteId = "Sat_1";
        long freeMemory = 600;
        List<Long> modulesCapacity = null;
        this.pdht = new PDHT(pdhtId, pdhtName, satelliteId, freeMemory, modulesCapacity);
    }

    @Test
    public void testRestoreAllModules() throws Exception
    {
        this.pdht.restoreAllModules();
    }

    @Test
    public void testSetCapacity() throws Exception
    {
        List<Long> modulesCapacity = new ArrayList<>();
        this.pdht.setCapacity(modulesCapacity);
    }

    @Test
    public void testGetFreeMemory() throws Exception
    {
        this.pdht.getFreeMemory();
    }

}
