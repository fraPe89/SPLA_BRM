
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

public class TaskTest
{

    @Test
    public void testTask() throws Exception
    {
        Task task = new Task();
        ArrayList<String> precId = new ArrayList<>(Arrays.asList("ciao"));
        task.setPrecId(precId);
        assertEquals("ciao", task.getPrecId().get(0));

        Bite bite = new Bite();
        bite.setModuleId("MM2");
        bite.setFillerWord("@");
        task.setAssociatedBite(bite);

        assertEquals(bite, task.getAssociatedBite());
    }

}
