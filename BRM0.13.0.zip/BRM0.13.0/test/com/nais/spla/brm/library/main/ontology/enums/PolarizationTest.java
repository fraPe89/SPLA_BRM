
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * The Class PolarizationTest.
 */
public class PolarizationTest
{

    /**
     * Test enum polarization type.
     */
    @Test
    public void testEnumPolarizationType()
    {
        List<Polarization> allPolarizationForTest = new ArrayList<>(Arrays.asList(Polarization.HH, Polarization.VV, Polarization.VH, Polarization.HV));
        Polarization[] allPolarization = Polarization.values();
        for (int i = 0; i < allPolarization.length; i++)
        {
            for (int j = 0; j < allPolarizationForTest.size(); j++)
            {
                if (allPolarization[i].equals(allPolarizationForTest.get(j)))
                {
                    allPolarizationForTest.remove(j);
                    j--;
                }
            }
        }

        Polarization type;
        type = Polarization.valueOf("HH");
        System.out.println("Selected : " + type);

        assertEquals(0, allPolarizationForTest.size());
    }
}
