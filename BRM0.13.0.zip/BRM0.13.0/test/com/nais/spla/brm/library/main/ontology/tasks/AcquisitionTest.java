
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;

/**
 * The Class AcquisitionTest.
 */
public class AcquisitionTest
{

    /** The du. */
    DroolsUtils du = new DroolsUtils();
    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "Test_Calibration";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /**
     * Test add reason of reject.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testAddReasonOfReject() throws Exception
    {
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, 10);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Acquisition acqForTest = new Acquisition();

        assertEquals(0, acqForTest.getReasonOfReject().size());

        ReasonOfReject reasonForTest = ReasonOfReject.exceededSensorModeMaxDuration;
        double onOrbitForTest = 1;
        int violatedSlidingWindowForTest = 3;
        List<String> elementsInvolved = new ArrayList<>();

        acqForTest.addReasonOfReject(1, reasonForTest, "", onOrbitForTest, violatedSlidingWindowForTest, elementsInvolved);

        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
        assertEquals(1, acqForTest.getReasonOfReject().size());

        System.out.println("REJECT : " + acqForTest.getReasonOfReject());
    }

    @Test
    public void testAddReasonOfReject_moreThanOneReject_firstTimeCurrentReject() throws Exception
    {
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, 10);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Acquisition acqForTest = new Acquisition();

        assertEquals(0, acqForTest.getReasonOfReject().size());

        double onOrbitForTest = 1;
        int violatedSlidingWindowForTest = 3;

        ReasonOfReject firstReasonForTest = ReasonOfReject.acqOverlapWithAcquisition;

        List<String> elementsInvolvedFirstReason = new ArrayList<>();
        elementsInvolvedFirstReason.add("dto2");
        elementsInvolvedFirstReason.add("dto3");

        acqForTest.addReasonOfReject(1, firstReasonForTest, "", onOrbitForTest, violatedSlidingWindowForTest, elementsInvolvedFirstReason);

        ReasonOfReject secondReasonForTest = ReasonOfReject.reachedOrbitThreshold;
        onOrbitForTest = 1;
        violatedSlidingWindowForTest = 3;

        List<String> elementsInvolvedSecondReason = new ArrayList<>();
        elementsInvolvedSecondReason.add("dto1");
        elementsInvolvedSecondReason.add("dto3");

        acqForTest.addReasonOfReject(1, secondReasonForTest, "", onOrbitForTest, violatedSlidingWindowForTest, elementsInvolvedSecondReason);

        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
        assertEquals(2, acqForTest.getReasonOfReject().size());

        System.out.println("REJECT : " + acqForTest.getReasonOfReject());
    }

    @Test
    public void testAddReasonOfReject_moreThanOneReject_NotFirstTimeCurrentReject() throws Exception
    {
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, 10);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Acquisition acqForTest = new Acquisition();

        assertEquals(0, acqForTest.getReasonOfReject().size());

        double onOrbitForTest = 1;
        int violatedSlidingWindowForTest = 2;

        ReasonOfReject firstReasonForTest = ReasonOfReject.reachedOrbitThreshold;

        List<String> elementsInvolvedFirstReason = new ArrayList<>();
        elementsInvolvedFirstReason.add("dto2");
        elementsInvolvedFirstReason.add("dto3");

        acqForTest.addReasonOfReject(1, firstReasonForTest, "", onOrbitForTest, violatedSlidingWindowForTest, elementsInvolvedFirstReason);

        ReasonOfReject secondReasonForTest = ReasonOfReject.reachedOrbitThreshold;
        onOrbitForTest = 3;
        violatedSlidingWindowForTest = 3;

        List<String> elementsInvolvedSecondReason = new ArrayList<>();
        elementsInvolvedSecondReason.add("dto1");
        elementsInvolvedSecondReason.add("dto3");

        acqForTest.addReasonOfReject(1, secondReasonForTest, "", onOrbitForTest, violatedSlidingWindowForTest, elementsInvolvedSecondReason);

        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
        assertEquals(1, acqForTest.getReasonOfReject().size());

        System.out.println("REJECT : " + acqForTest.getReasonOfReject());
    }

    /**
     * Test get partners associated.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testGetPartnersAssociated() throws Exception
    {
        List<UserInfo> userInfoList = new ArrayList<>();

        Partner p1 = new Partner("Partner_1", null, 100, 20);
        Partner p2 = new Partner("Partner_2", null, 100, 20);

        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq = new Acquisition();

        acq.setUserInfo(userInfoList);

        List<String> expectedPartners = acq.getPartnersAssociated();

        System.out.println(expectedPartners);
        assertTrue(expectedPartners.size() == 2);
        assertTrue(expectedPartners.contains(p1.getPartnerId()));
        assertTrue(expectedPartners.contains(p2.getPartnerId()));
    }

    /**
     * Test check if user info contains partner id found.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testCheckIfUserInfoContainsPartnerId_found() throws Exception
    {
        String partnerToSearch = "Partner1";
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 15:55:00", "10/10/2017 15:55:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerToSearch);
        UserInfo userInfo2 = new UserInfo("Partner2");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);
        boolean foundPartner = acq.checkIfUserInfoContainsPartnerId(partnerToSearch);
        assertTrue(foundPartner);
    }

    @Test
    public void testCheckIfUserInfoContainsPartnerId_EmptyList() throws Exception
    {
        String partnerToSearch = "Partner1";
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 15:55:00", "10/10/2017 15:55:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        acq.setUserInfo(userInfoList);
        boolean foundPartner = acq.checkIfUserInfoContainsPartnerId(partnerToSearch);
        assertFalse(foundPartner);
    }

    /**
     * Test check if user info contains partner id not found.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testCheckIfUserInfoContainsPartnerId_not_found() throws Exception
    {
        String partnerToSearch = "Partner4";
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 15:55:00", "10/10/2017 15:55:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo("Partner1");
        UserInfo userInfo2 = new UserInfo("Partner2");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);
        boolean foundPartner = acq.checkIfUserInfoContainsPartnerId(partnerToSearch);
        assertFalse(foundPartner);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testExcludeUnremovableTasks() throws Exception
    {
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, 10);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:20", "right", "SAT_1");
        dto1.setPrType(PRType.VU); // so the related acq will be unremovable

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Acquisition acqVu = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("aacq vu : " + acqVu.isRemovableFlag());
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:50", "10/10/2017 15:56:20", "right", "SAT_1");
        dto1.setPrType(PRType.HP); // so the reated acq will be removable
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:55:10", "10/10/2017 15:55:58", "right", "SAT_1");
        dto3.setPrType(PRType.HP); // so the reated acq will be removable
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        Map<String, Acquisition> allRejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        Acquisition acqRelativeToDto3 = allRejectedElements.get(dto3.getDtoId());

        System.out.println(acqRelativeToDto3);
        assertEquals(1, acqRelativeToDto3.getReasonOfReject().size());

    }

    @Test
    public void testCreateAcqFromDto() throws Exception
    {
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, 10);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        DTO dto = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        dto.setPrType(PRType.HP);
        dto.setDtoId("dtoTest");
        dto.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto.setKey(1);
        dto.setPol(Polarization.H_H);
        dto.setNeoAvailable(true);
        dto.setImageBIC(100);
        dto.setPriority(3);
        dto.setPreferredVis(null);
        dto.setPtAvailable(false);
        dto.setReferredEquivalentDto(null);
        dto.setRevolutionNumber(2);
        dto.setPrMode(PRMode.DI2S);
        dto.setStereopair(true);
        dto.setLinkedDtoId(null);
        dto.setReplacedRequestListId(null);
        dto.setInterleavedChannel(2);
        dto.setPreviousMh(false);

        Acquisition acq = new Acquisition();
        acq.createAcqFromDto(dto, acq);
    }

    @Test
    public void testCreateAcqFromDto_VU_prevProc() throws Exception
    {
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, 10);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        DTO dto = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        dto.setPrType(PRType.VU);
        dto.setDtoId("dtoTest");
        dto.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto.setKey(1);
        dto.setPol(Polarization.H_H);
        dto.setNeoAvailable(true);
        dto.setImageBIC(100);
        dto.setPriority(3);
        dto.setPreferredVis(null);
        dto.setPtAvailable(false);
        dto.setReferredEquivalentDto(null);
        dto.setRevolutionNumber(2);
        dto.setPrMode(PRMode.DI2S);
        dto.setStereopair(true);
        dto.setLinkedDtoId(null);
        dto.setReplacedRequestListId(null);
        dto.setLinkedDtoId("linkedDtoId");
        dto.setInterleavedChannel(2);
        dto.setPreviousMh(true);
        dto.setDi2s(true);
        Acquisition acq = new Acquisition();
        acq.createAcqFromDto(dto, acq);

        assertEquals(2, acq.getInterleavedChannel());
        assertEquals(true, acq.isDi2sAvailable());
        assertEquals("linkedDtoId", acq.getLinkedDtoId());

        System.out.println(acq.getPreferredVis());

        assertEquals(0, acq.getReasonOfReject().size());

        acq.addReasonOfReject(1, ReasonOfReject.acqInconsistentWithPaw, "System Conflict", 0, 0, null);

        assertEquals(1, acq.getReasonOfReject().size());

        acq.removeReasonOfReject(ReasonOfReject.acqOverlapTheatre);
        assertEquals(1, acq.getReasonOfReject().size());

        acq.removeReasonOfReject(ReasonOfReject.acqInconsistentWithPaw);

        assertEquals(0, acq.getReasonOfReject().size());

    }

}
