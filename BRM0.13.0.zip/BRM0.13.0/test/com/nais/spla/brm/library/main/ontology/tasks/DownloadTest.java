
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;

public class DownloadTest
{

    @Test
    public void testDownload() throws Exception
    {

        /** The related task id. */
        String relatedTaskId = "dto1";

        /** The packet store strategy. */
        DownlinkStrategy packetStoreStrategy = DownlinkStrategy.RETAIN;

        /** The link. */
        boolean carrierL2Selection = false;

        /** The downloaded size. */
        int downloadedSize = 300;

        /** The memory modules. */
        Map<MemoryModule, Long> plannedOnMemModule = new HashMap<>();

        /** The pol. */
        Polarization pol = Polarization.H_H;

        /** The initial sector. */
        int initialSector = 0;

        /** The final sector. */
        int finalSector = 30;
        
        int sectorShift = 10;

        /** The for partners. */
        List<String> ugsOwnerList = new ArrayList<>();
        ;

        /** The visibility id. */
        long contactCounter = 9l;

        /** The packet store number. */
        int packetStoreNumber = 2;

        /** The acq stat id. */
        String acqStatId = null;

        String satelliteId = "SAT_1";

        Download dwlForTest = new Download(satelliteId);
        dwlForTest.setRelatedTaskId(relatedTaskId);
        dwlForTest.setPacketStoreStrategy(packetStoreStrategy);
        dwlForTest.setCarrierL2Selection(carrierL2Selection);
        dwlForTest.setDownloadedSize(downloadedSize);
        dwlForTest.setPlannedOnMemModule(plannedOnMemModule);
        dwlForTest.setPol(pol);
        dwlForTest.setInitialSector(initialSector);
        dwlForTest.setFinalSector(finalSector);
        dwlForTest.setUgsOwnerList(ugsOwnerList);
        dwlForTest.setContactCounter(contactCounter);
        dwlForTest.setPacketStoreNumber(packetStoreNumber);
        dwlForTest.setAcqStatId(acqStatId);
        dwlForTest.setTaskMark(TaskMarkType.DELETED);
        dwlForTest.setSectorShift(sectorShift);
        dwlForTest.setInitialSector(initialSector);
        dwlForTest.setFinalSector(finalSector);
        Download dwl2 = dwlForTest;
        assertEquals(relatedTaskId, dwl2.getRelatedTaskId());
        assertEquals(packetStoreStrategy, dwl2.getPacketStoreStrategy());
        assertEquals(carrierL2Selection, dwl2.isCarrierL2Selection());
        assertEquals(downloadedSize, dwl2.getDownloadedSize(), 0);
        assertEquals(plannedOnMemModule, dwl2.getPlannedOnMemModule());
        assertEquals(TaskMarkType.DELETED, dwl2.getTaskMark());
        assertEquals(acqStatId, dwl2.getAcqStatId());
        assertEquals(packetStoreNumber, dwl2.getPacketStoreNumber());
        assertEquals(sectorShift, dwlForTest.getSectorShift());
        assertEquals(initialSector, dwlForTest.getInitialSector());
        assertEquals(finalSector, dwlForTest.getFinalSector());
    }

}
