
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class UserInfoTest
{

    @Test
    public void testUserInfo() throws Exception
    {
        UserInfo userInfoForTest = new UserInfo();

        boolean slave = true;
        boolean subscriber = false;
        String ownerId = "ownerId";
        List<String> acquisitionStationIdList = new ArrayList<>();
        userInfoForTest.setAcquisitionStationIdList(acquisitionStationIdList);
        userInfoForTest.setOwnerId(ownerId);
        userInfoForTest.setSubscriber(subscriber);
        userInfoForTest.setSlave(slave);
        assertTrue(userInfoForTest.isSlave());
    }

}
