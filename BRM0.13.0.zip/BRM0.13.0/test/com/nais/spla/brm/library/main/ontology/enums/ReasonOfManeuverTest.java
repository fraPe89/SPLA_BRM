
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ReasonOfManeuverTest
{

    @Test
    public void testEnumReasonOfManeuver()
    {
        List<ReasonOfManeuver> allReasonOfManeuverForTest = new ArrayList<>(Arrays.asList(ReasonOfManeuver.acqAcq, ReasonOfManeuver.acqHpSeg, ReasonOfManeuver.acqPaw, ReasonOfManeuver.conterMan));
        ReasonOfManeuver[] allReasonOfManeuver = ReasonOfManeuver.values();
        for (int i = 0; i < allReasonOfManeuver.length; i++)
        {
            for (int j = 0; j < allReasonOfManeuverForTest.size(); j++)
            {
                if (allReasonOfManeuver[i].equals(allReasonOfManeuverForTest.get(j)))
                {
                    allReasonOfManeuverForTest.remove(j);
                    j--;
                }
            }
        }

        ReasonOfManeuver reason = null;
        reason = ReasonOfManeuver.valueOf("acqAcq");
        System.out.println("Selected : " + reason);

        assertEquals(0, allReasonOfManeuverForTest.size());
    }
}
