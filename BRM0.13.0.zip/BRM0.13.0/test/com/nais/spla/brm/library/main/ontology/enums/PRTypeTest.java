
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * The Class PRTypeTest.
 */
public class PRTypeTest
{

    /**
     * Test enum PR type.
     */
    @Test
    public void testEnumPRType()
    {
        List<PRType> allPRTypeForTest = new ArrayList<>(Arrays.asList(PRType.CIVILIAN_HP, PRType.CRISIS, PRType.HP, PRType.LMP, PRType.PP, PRType.RANKED_ROUTINE, PRType.UNRANKED_ROUTINE, PRType.VU));
        PRType[] allPRType = PRType.values();
        for (int i = 0; i < allPRType.length; i++)
        {
            for (int j = 0; j < allPRTypeForTest.size(); j++)
            {
                if (allPRType[i].equals(allPRTypeForTest.get(j)))
                {
                    allPRTypeForTest.remove(j);
                    j--;
                }
            }
        }

        PRType type;
        type = PRType.valueOf("CIVILIAN_HP");
        System.out.println("Selected : " + type);

        assertEquals(0, allPRTypeForTest.size());
    }

}
