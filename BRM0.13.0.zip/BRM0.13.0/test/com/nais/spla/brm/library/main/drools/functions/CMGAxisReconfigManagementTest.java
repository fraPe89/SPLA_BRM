
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;

public class CMGAxisReconfigManagementTest
{

    private DroolsUtils du = null;
    private TaskPlanned taskPlanned = null;
    private CMGAxisReconfigManagement cmgAxisReconfMng = new CMGAxisReconfigManagement();
    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private double maxBicForTest = 0;

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestManeuverManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        this.taskPlanned = new TaskPlanned();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCheckIfNeedCmgAxis_RW_CMGA_time_for_axis_roll_roll() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSatellite = resources.getManeuverFunctionAssociatedToSat(satId);
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);
        TreeMap<Long, CMGAxis> allCmgAxisForSatellite = resources.getCmgaAxisAssociatedToSat(satId);

        assertEquals(0, allCmgAxisForSatellite.size());
        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);

        assertEquals(0, allCmgAxis.size());
        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.RollSlew);
        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.RollSlew);

        allManForSatellite.put(firstMan.getStartTime().getTime(), firstMan);
        allManForSatellite.put(secondMan.getStartTime().getTime(), secondMan);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:34:00", false);

        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        List<CMGAxis> returnedCmgAxis = this.cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, this.droolsParams, resources, rejected);

        assertEquals(0, returnedCmgAxis.size());
        assertEquals(0, allCmgAxisForSatellite.size());

    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testCheckIfNeedCmgAxis_RW_CMGA_time_for_axis_roll_pitch() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSatellite = resources.getManeuverFunctionAssociatedToSat(satId);
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);
        TreeMap<Long, CMGAxis> allCmgAxisForSatellite = resources.getCmgaAxisAssociatedToSat(satId);

        assertEquals(0, allCmgAxisForSatellite.size());
        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);

        assertEquals(0, allCmgAxis.size());
        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.RollSlew);
        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.PitchCPS);

        allManForSatellite.put(firstMan.getStartTime().getTime(), firstMan);
        allManForSatellite.put(secondMan.getStartTime().getTime(), secondMan);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:34:00", false);

        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        List<CMGAxis> returnedCmgAxis = this.cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, this.droolsParams, resources, rejected);

        assertEquals(1, returnedCmgAxis.size());
        assertEquals(1, allCmgAxisForSatellite.size());
        
        System.out.println(returnedCmgAxis);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCheckIfNeedCmgAxis_onlyPrev() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSatellite = resources.getManeuverFunctionAssociatedToSat(satId);
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);
        TreeMap<Long, CMGAxis> allCmgAxisForSatellite = resources.getCmgaAxisAssociatedToSat(satId);

        assertEquals(0, allCmgAxisForSatellite.size());
        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);

        assertEquals(0, allCmgAxis.size());
        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.RollSlew);
        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.RollSlew);

        allManForSatellite.put(firstMan.getStartTime().getTime(), firstMan);
        allManForSatellite.put(secondMan.getStartTime().getTime(), secondMan);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:34:00", false);

        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        List<CMGAxis> returnedCmgAxis = this.cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, this.droolsParams, resources, rejected);

        assertEquals(0, returnedCmgAxis.size());
        assertEquals(0, allCmgAxisForSatellite.size());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCheckIfNeedCmgAxis_onlyNext() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSatellite = resources.getManeuverFunctionAssociatedToSat(satId);
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);
        TreeMap<Long, CMGAxis> allCmgAxisForSatellite = resources.getCmgaAxisAssociatedToSat(satId);

        assertEquals(0, allCmgAxisForSatellite.size());
        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);

        assertEquals(0, allCmgAxis.size());
        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.RollSlew);
        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.RollSlew);

        allManForSatellite.put(firstMan.getStartTime().getTime(), firstMan);
        allManForSatellite.put(secondMan.getStartTime().getTime(), secondMan);

        RampCMGA rumpUpCmg1 = this.du.createRamp("17/01/2018 11:27:00", true);
        RampCMGA rumpDownCmg1 = this.du.createRamp("17/01/2018 11:34:00", true);

        RampCMGA rumpUpCmg2 = this.du.createRamp("17/01/2018 12:27:00", true);
        RampCMGA rumpDownCmg2 = this.du.createRamp("17/01/2018 12:34:00", false);

        allRampsForSatellite.put(rumpUpCmg1.getStartTime().getTime(), rumpUpCmg1);
        allRampsForSatellite.put(rumpDownCmg1.getStartTime().getTime(), rumpDownCmg1);
        allRampsForSatellite.put(rumpUpCmg2.getStartTime().getTime(), rumpUpCmg2);
        allRampsForSatellite.put(rumpDownCmg2.getStartTime().getTime(), rumpDownCmg2);
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        List<CMGAxis> returnedCmgAxis = this.cmgAxisReconfMng.checkIfNeedCmgAxis(firstMan, this.droolsParams, resources, rejected);

        assertEquals(0, returnedCmgAxis.size());
        assertEquals(0, allCmgAxisForSatellite.size());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCheckIfNeedCmgAxis_RW_CMGA_time() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_time \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSatellite = resources.getManeuverFunctionAssociatedToSat(satId);
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);
        TreeMap<Long, CMGAxis> allCmgAxisForSatellite = resources.getCmgaAxisAssociatedToSat(satId);

        assertEquals(0, allCmgAxisForSatellite.size());
        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);

        assertEquals(0, allCmgAxis.size());
        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 11:30:00", "17/01/2018 11:34:00", "SAT_1", Actuator.ReactionWheels);
        firstMan.setType(ManeuverType.RollSlew);
        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.PitchCPS);

        allManForSatellite.put(firstMan.getStartTime().getTime(), firstMan);
        allManForSatellite.put(secondMan.getStartTime().getTime(), secondMan);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:27:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:34:00", false);

        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        List<CMGAxis> returnedCmgAxis = this.cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, this.droolsParams, resources, rejected);

        assertEquals(0, returnedCmgAxis.size());
        assertEquals(0, allCmgAxisForSatellite.size());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManForSatellite = resources.getManeuverFunctionAssociatedToSat(satId);
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);
        TreeMap<Long, CMGAxis> allCmgAxisForSatellite = resources.getCmgaAxisAssociatedToSat(satId);

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        assertEquals(0, allCmgAxisForSatellite.size());

        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);

        assertEquals(0, allCmgAxis.size());
        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:20:50", "17/01/2018 12:26:50", "SAT_1", Actuator.ReactionWheels);
        firstMan.setType(ManeuverType.RollSlew);
        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.PitchCPS);

        allManForSatellite.put(firstMan.getStartTime().getTime(), firstMan);
        allManForSatellite.put(secondMan.getStartTime().getTime(), secondMan);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:27:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:34:00", false);

        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);
        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        this.cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, this.droolsParams, resources, rejected);

        allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satId);
        assertEquals(0, allCmgAxis.size());
        assertEquals(0, allCmgAxisForSatellite.size());
    }

    @Test
    public void testCheckAndCreateCmgAxis_CMG_Roll() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.PitchCPS);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:23:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:30:00", false);
        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:30:00", "17/01/2018 12:34:00", "SAT_1", Actuator.ReactionWheels);
        secondMan.setType(ManeuverType.RollSlew);

        // TreeMap<Long, CMGAxis> allCmgAxisForSatellite =
        // resources.getCmgaAxisAssociatedToSat(satId);

        // cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, droolsParams,
        // resources);
        // List<CMGAxis> allCmgAxis =
        // taskPlanned.receiveAllCmgAxisForSat(droolsParams, satId);

        // allCmgAxis = taskPlanned.receiveAllCmgAxisForSat(droolsParams,
        // satId);
        //
        // System.out.println(allCmgAxis);
        // assertEquals(0,allCmgAxis.size());
        // assertEquals(0,allCmgAxisForSatellite.size());

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
    }

    @Test
    public void testCheckIfNeedCmgAxis_noTime() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.PitchCPS);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:23:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:30:00", false);
        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:31:00", "17/01/2018 12:35:00", "SAT_1", Actuator.ReactionWheels);
        secondMan.setType(ManeuverType.RollSlew);

        // TreeMap<Long, CMGAxis> allCmgAxisForSatellite =
        // resources.getCmgaAxisAssociatedToSat(satId);

        // cmgAxisReconfMng.checkIfNeedCmgAxis(secondMan, droolsParams,
        // resources);
        // List<CMGAxis> allCmgAxis =
        // taskPlanned.receiveAllCmgAxisForSat(droolsParams, satId);

        // allCmgAxis = taskPlanned.receiveAllCmgAxisForSat(droolsParams,
        // satId);
        //
        // System.out.println(allCmgAxis);
        // assertEquals(0,allCmgAxis.size());
        // assertEquals(0,allCmgAxisForSatellite.size());

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
    }
    @Test
    public void testCheckAndCreateCmgAxis_bothCMga_pitchRoll() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.RollSlew);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:23:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:30:00", false);
        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:55:00", "17/01/2018 12:59:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.PitchCPS);

        RampCMGA rumpUpCmg2 = this.du.createRamp("17/01/2018 12:52:00", true);
        RampCMGA rumpDownCmg2 = this.du.createRamp("17/01/2018 12:59:00", false);
        allRampsForSatellite.put(rumpUpCmg2.getStartTime().getTime(), rumpUpCmg2);
        allRampsForSatellite.put(rumpDownCmg2.getStartTime().getTime(), rumpDownCmg2);

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
        
        assertTrue(results.containsKey(true));
        CMGAxis cmqReturned = results.get(true);
        assertEquals(true,cmqReturned.isRollToPitch());
    }
    
    @Test
    public void testCheckAndCreateCmgAxis_bothCMga_rollPitch() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.PitchCPS);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:23:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:30:00", false);
        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:55:00", "17/01/2018 12:59:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.RollSlew);

        RampCMGA rumpUpCmg2 = this.du.createRamp("17/01/2018 12:52:00", true);
        RampCMGA rumpDownCmg2 = this.du.createRamp("17/01/2018 12:59:00", false);
        allRampsForSatellite.put(rumpUpCmg2.getStartTime().getTime(), rumpUpCmg2);
        allRampsForSatellite.put(rumpDownCmg2.getStartTime().getTime(), rumpDownCmg2);

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
        
        assertTrue(results.containsKey(true));
        CMGAxis cmqReturned = results.get(true);
        assertEquals(false,cmqReturned.isRollToPitch());
    }

    @Test
    public void testCheckAndCreateCmgAxis_bothCMga_noTime() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);

        Maneuver prevMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:00:00", "17/01/2018 12:04:00", "SAT_1", Actuator.CMGA);
        prevMan.setType(ManeuverType.RollSlew);

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.PitchCPS);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 11:57:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:30:00", false);
        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:55:00", "17/01/2018 12:59:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.RollSlew);

        RampCMGA rumpUpCmg2 = this.du.createRamp("17/01/2018 12:52:00", true);
        RampCMGA rumpDownCmg2 = this.du.createRamp("17/01/2018 12:59:00", false);
        allRampsForSatellite.put(rumpUpCmg2.getStartTime().getTime(), rumpUpCmg2);
        allRampsForSatellite.put(rumpDownCmg2.getStartTime().getTime(), rumpDownCmg2);

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
    }

    @Test
    public void testCheckAndCreateCmgAxis_bothCMga_notEnough() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, RampCMGA> allRampsForSatellite = resources.getRampFunctionAssociatedToSat(satId);

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.CMGA);
        firstMan.setType(ManeuverType.PitchCPS);

        RampCMGA rumpUpCmg = this.du.createRamp("17/01/2018 12:23:00", true);
        RampCMGA rumpDownCmg = this.du.createRamp("17/01/2018 12:30:00", false);
        allRampsForSatellite.put(rumpUpCmg.getStartTime().getTime(), rumpUpCmg);
        allRampsForSatellite.put(rumpDownCmg.getStartTime().getTime(), rumpDownCmg);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:55:00", "17/01/2018 12:59:00", "SAT_1", Actuator.CMGA);
        secondMan.setType(ManeuverType.RollSlew);

        RampCMGA rumpUpCmg2 = this.du.createRamp("17/01/2018 12:52:00", true);
        RampCMGA rumpDownCmg2 = this.du.createRamp("17/01/2018 12:59:00", false);
        allRampsForSatellite.put(rumpUpCmg2.getStartTime().getTime(), rumpUpCmg2);
        allRampsForSatellite.put(rumpDownCmg2.getStartTime().getTime(), rumpDownCmg2);

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
    }

    @Test
    public void testCheckAndCreateCmgAxis_bothRw() throws Exception
    {
        System.out.println("Running test : testCheckIfNeedCmgAxis_RW_CMGA_no_time_for_axis \n\n");
        this.droolsParams.setNumberOfSessions(1);
        String satId = "SAT_1";

        // create a new acquisition
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setId("100_PR-ITA-001-HP_AR-001_DTO-1");

        DroolsParameters.setLastAcq(acq1);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId(satId).getSatelliteProperties().setAxesReconfigurationTime(20);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Maneuver firstMan = this.du.createManeuver("previous", null, "acq_1", "17/01/2018 12:26:00", "17/01/2018 12:30:00", "SAT_1", Actuator.ReactionWheels);
        firstMan.setType(ManeuverType.RollSlew);

        Maneuver secondMan = this.du.createManeuver("next", null, "acq_1", "17/01/2018 12:55:00", "17/01/2018 12:59:00", "SAT_1", Actuator.ReactionWheels);
        secondMan.setType(ManeuverType.RollSlew);

        Map<Boolean, CMGAxis> results = this.cmgAxisReconfMng.checkAndCreateCmgAxis(firstMan, secondMan, this.droolsParams, resources, "prev");
        System.out.println(results);
        
        assertTrue(results.containsKey(true));

        assertTrue(results.get(true)==null);

    }


}
