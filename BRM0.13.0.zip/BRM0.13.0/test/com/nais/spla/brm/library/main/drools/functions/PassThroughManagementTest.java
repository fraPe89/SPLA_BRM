
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class PassThroughManagementTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private PassThroughManagement ptMng = new PassThroughManagement();
    StubResources stub = new StubResources();

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "PassThroughManagementTest";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }


    @Test
    public void testTryPassThough_no_Vis_in_overlap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("all vis : " + this.droolsParams.getAllVisibilities());
        System.out.println("Running Test : testTryPassThough_no_Vis_in_overlap \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:30", "left", satelliteId);
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(2000);
        dto1.setSizeV(2000);
        dto1.setPtAvailable(true);
        System.out.println("I'm inserting dto : " + dto1.toString());

        assertEquals(0, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId).size());
        assertEquals(0, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, satelliteId).size());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Acquisition> rejectedElements =  droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        
        Acquisition rejectedAcq = rejectedElements.get(dto1.getDtoId());
        assertEquals(ReasonOfReject.cannotPerformPassThrough, rejectedAcq.getReasonOfReject().get(0).getReason());
        System.out.println(rejectedAcq);
        System.out.println(resourceFunctions);
    }

    @Test
    public void testTryToPlanPT_HH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");

        this.droolsParams.getAllVisibilities().add(vis4);
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeH(200);
        acq.setPolarization(Polarization.HH);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        DownloadUtils dwlUtils = new DownloadUtils();
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");

        pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
        System.out.println(pt);
        
        assertEquals(200,pt.getPacketStoreSizeH());
        assertEquals(0,pt.getPacketStoreSizeV());

        System.out.println("resFunc : " + resFunc.getDownloadsAssociatedToSat("SAT_1"));

    }
    
    @Test
    public void testTryToPlanPT_VV() throws Exception
    {    
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
    this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

    Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");

    this.droolsParams.getAllVisibilities().add(vis4);
    Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
    acq.setSizeV(200);
    acq.setPolarization(Polarization.VV);
    List<UserInfo> userInfoList = new ArrayList<>();
    UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
    userInfoList.add(userInfo1);
    acq.setUserInfo(userInfoList);

    ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
    DownloadUtils dwlUtils = new DownloadUtils();
    PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
    System.out.println("pt planned : " + pt);
    List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");

    pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
    System.out.println(pt);
    
    assertEquals(0,pt.getPacketStoreSizeH());
    assertEquals(200,pt.getPacketStoreSizeV());

    System.out.println("resFunc : " + resFunc.getDownloadsAssociatedToSat("SAT_1"));

    }

    
    
    @Test
    public void testTryToPlanPT_HV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");

        this.droolsParams.getAllVisibilities().add(vis4);
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.HV);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        DownloadUtils dwlUtils = new DownloadUtils();
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");

        pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
        System.out.println(pt);
        
        assertEquals(200,pt.getPacketStoreSizeH());
        assertEquals(200,pt.getPacketStoreSizeV());

        System.out.println("resFunc : " + resFunc.getDownloadsAssociatedToSat("SAT_1"));

    }
    
    @Test
    public void testTryToPlanPT_VH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");
        Visibility vis2 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 07:32:00", "10/10/2017 07:52:00");
        Visibility vis3 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 08:32:00", "10/10/2017 08:52:00");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 09:32:00", "10/10/2017 09:52:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1,vis2,vis3,vis4));
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.VH);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        DownloadUtils dwlUtils = new DownloadUtils();
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");
        System.out.println("allVisInOverlap : " + allVisInOverlap);

        pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
        System.out.println(pt);
        
        assertEquals(200,pt.getPacketStoreSizeH());
        assertEquals(200,pt.getPacketStoreSizeV());
        System.out.println("resFunc : " + resFunc.getDownloadsAssociatedToSat("SAT_1"));
    }
    
    
    @Test
    public void testTryToPlanPT_VH_HV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");
        Visibility vis2 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 07:32:00", "10/10/2017 07:52:00");
        Visibility vis3 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 08:32:00", "10/10/2017 08:52:00");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 09:32:00", "10/10/2017 09:52:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1,vis2,vis3,vis4));
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.VH_HV);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        DownloadUtils dwlUtils = new DownloadUtils();
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");
        System.out.println("allVisInOverlap : " + allVisInOverlap);

        pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
        System.out.println(pt);
        
        assertEquals(200,pt.getPacketStoreSizeH());
        assertEquals(200,pt.getPacketStoreSizeV());
    }
    
    
    @Test
    public void testTryToPlanPT_V_H() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");
        Visibility vis2 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 07:32:00", "10/10/2017 07:52:00");
        Visibility vis3 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 08:32:00", "10/10/2017 08:52:00");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 09:32:00", "10/10/2017 09:52:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1,vis2,vis3,vis4));
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.V_H);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        DownloadUtils dwlUtils = new DownloadUtils();
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");
        System.out.println("allVisInOverlap : " + allVisInOverlap);
      
        pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
        System.out.println(pt);
        
        assertEquals(200,pt.getPacketStoreSizeH());
        assertEquals(200,pt.getPacketStoreSizeV());
        
        System.out.println("resFunc : " + resFunc.getDownloadsAssociatedToSat("SAT_1"));

    }
    
    
    @Test
    public void testTryToPlanPT_VH_VH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");
        Visibility vis2 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 07:32:00", "10/10/2017 07:52:00");
        Visibility vis3 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 08:32:00", "10/10/2017 08:52:00");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 09:32:00", "10/10/2017 09:52:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1,vis2,vis3,vis4));
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.VH_VH);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        DownloadUtils dwlUtils = new DownloadUtils();
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        List<Visibility> allVisInOverlap = dwlUtils.findAllVisInOverlapWithDate(pt.getStartTime(), pt.getEndTime(), this.droolsParams.getAllVisibilities(), "SAT_1");
        System.out.println("allVisInOverlap : " + allVisInOverlap);
        
        pt = this.ptMng.tryToPlanPT(acq, pt, allVisInOverlap, resFunc);
        System.out.println(pt);
        
        assertEquals(200,pt.getPacketStoreSizeH());
        assertEquals(200,pt.getPacketStoreSizeV());

    }
    
    @Test
    public void testCreatePassThrough_HH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();
        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
        this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
        for (int i = 0; i < pdht.getMMList().size(); i++)
        {
            pdht.getMMList().get(i).setFreeSectors(1000);
        }

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setPtAvailable(true);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
       
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");
        assertEquals(1,downloadTreeMap2.size());
        System.out.println(downloadTreeMap2);
        
        
        Acquisition acqRelatedToPt = null;
        acqRelatedToPt = droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
//        List<UserInfo> userInfoList = new ArrayList<>();
//        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
//        userInfoList.add(userInfo1);
//        acq.setUserInfo(userInfoList);
        PassThrough pt = this.ptMng.createPassThrough(acqRelatedToPt, this.droolsParams, resFunc);
        System.out.println("number of ps for the pt :" + pt.getNumberOfPackets());
        System.out.println("pt created : " + pt);
    }
    
    @Test
    public void testCreatePassThrough_VV() throws Exception
    {
        StubResources stub = new StubResources();
            this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
            this.droolsParams.getAllPAWS().clear();
            Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

            List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
            this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
            
            this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
            ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

            PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
            for (int i = 0; i < pdht.getMMList().size(); i++)
            {
                pdht.getMMList().get(i).setFreeSectors(1000);
            }

            DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
            dto1.setPol(Polarization.VV);
            dto1.setSizeV(400);
            dto1.setSizeH(0);

            dto1.setPtAvailable(true);
            System.out.println("I'm inserting dto : " + dto1.toString());

            boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
            assertTrue(inserted);
           
            TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");
            assertEquals(1,downloadTreeMap2.size());
            System.out.println(downloadTreeMap2);
        }
    
    @Test
    public void testCreatePassThrough_VH() throws Exception
    {
        StubResources stub = new StubResources();
            this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
            this.droolsParams.getAllPAWS().clear();
            Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

            List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
            this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
            
            this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
            ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

            PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
            for (int i = 0; i < pdht.getMMList().size(); i++)
            {
                pdht.getMMList().get(i).setFreeSectors(1000);
            }

            DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
            dto1.setPol(Polarization.VH);
            dto1.setSizeV(400);
            dto1.setSizeH(400);

            dto1.setPtAvailable(true);
            System.out.println("I'm inserting dto : " + dto1.toString());

            boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
            assertTrue(inserted);
           
            TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");
            System.out.println(downloadTreeMap2);
            assertEquals(1,downloadTreeMap2.size());
    
    }
    
    @Test
    public void testCreatePassThrough_VH_impossibleForPtBeforeInOverlap() throws Exception
    {
        StubResources stub = new StubResources();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();
        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
        this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
        
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
        for (int i = 0; i < pdht.getMMList().size(); i++)
        {
            pdht.getMMList().get(i).setFreeSectors(1000);
        }

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
        dto1.setPol(Polarization.VH);
        dto1.setSizeV(400);
        dto1.setSizeH(400);

        dto1.setPtAvailable(true);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
       
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");
        System.out.println(downloadTreeMap2);
        assertEquals(1,downloadTreeMap2.size());
        
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 18:01:00", "10/10/2017 18:01:50", "right", "SAT_1");
        dto2.setPol(Polarization.VH);
        dto2.setSizeV(800);
        dto2.setSizeH(800);

        dto2.setPtAvailable(true);
        System.out.println("I'm inserting dto : " + dto2.toString());

        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(inserted);
}
    
    
    @Test
    public void testCreatePassThrough_VH_impossibleForPtAfterInOverlap() throws Exception
    {
        StubResources stub = new StubResources();
            this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
            this.droolsParams.getAllPAWS().clear();
            Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

            List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
            this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
            
            this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
            ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

            PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
            for (int i = 0; i < pdht.getMMList().size(); i++)
            {
                pdht.getMMList().get(i).setFreeSectors(1000);
            }

            DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
            dto1.setPol(Polarization.VH);
            dto1.setSizeV(400);
            dto1.setSizeH(400);

            dto1.setPtAvailable(true);
            System.out.println("I'm inserting dto : " + dto1.toString());

            boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
            assertTrue(inserted);
           
            TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");
            System.out.println(downloadTreeMap2);
            assertEquals(1,downloadTreeMap2.size());
            
            
            DTO dto2 = this.du.createSingleDto("10/10/2017 18:02:46", "10/10/2017 18:03:30", "right", "SAT_1");
            dto2.setPol(Polarization.VH);
            dto2.setSizeV(400);
            dto2.setSizeH(400);

            dto2.setPtAvailable(true);
            System.out.println("I'm inserting dto : " + dto2.toString());

            inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
            System.out.println(downloadTreeMap2);

            assertFalse(inserted);
            
    
    }
    
    @Test
    public void testCreatePassThrough_noSpace() throws Exception
    {
        this.droolsParams.getAllPDHT().get(0).setFreeMemory(200);;
        StubResources stub = new StubResources();
            this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
            this.droolsParams.getAllPAWS().clear();
            Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

            List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
            this.droolsParams.setAllVisibilities(allVisibilitiesSat1);

            this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
            ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

            PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
            for (int i = 0; i < pdht.getMMList().size(); i++)
            {
                pdht.getMMList().get(i).setFreeSectors(20);
            }

            DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
            dto1.setPol(Polarization.HV);
            dto1.setSizeV(400);
            dto1.setSizeH(400);

            dto1.setPtAvailable(true);
            System.out.println("I'm inserting dto : " + dto1.toString());

            boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
            assertFalse(inserted);
           
    }
    
    
    @Test
    public void testCreatePassThrough_HV() throws Exception
    {
        StubResources stub = new StubResources();
            this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
            this.droolsParams.getAllPAWS().clear();
            Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 18:00:00", "10/10/2017 18:21:00");

            List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis4));
            this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
            
            this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
            ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

            PDHT pdht = resFunc.getPDHTFunctionAssociatedToSat("SAT_1").get(this.droolsParams.getCurrentMH().getStart().getTime()).getPdht();
            for (int i = 0; i < pdht.getMMList().size(); i++)
            {
                pdht.getMMList().get(i).setFreeSectors(1000);
            }

            DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "right", "SAT_1");
            dto1.setPol(Polarization.HV);
            dto1.setSizeV(400);
            dto1.setSizeH(400);

            dto1.setPtAvailable(true);
            System.out.println("I'm inserting dto : " + dto1.toString());

            boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
            assertTrue(inserted);
           
            TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap2 = resFunc.getDownloadsAssociatedToSat("1");
            System.out.println(downloadTreeMap2);
            assertEquals(1,downloadTreeMap2.size());
    
    }

    @Test
    public void testSetAcquisitionStationForPt_NOuGSlIST() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");
        Visibility vis2 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 07:32:00", "10/10/2017 07:52:00");
        Visibility vis3 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 08:32:00", "10/10/2017 08:52:00");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 09:32:00", "10/10/2017 09:52:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1,vis2,vis3,vis4));
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.VH_HV);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        this.ptMng.setAcquisitionStationForPt(acq, pt);
        System.out.println("pt planned : " + pt);
        assertEquals(0,pt.getGroundStationId().size());
    }
    
    @Test
    public void testSetAcquisitionStationForPt_uGSlIST() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 06:32:00", "10/10/2017 06:52:00");
        Visibility vis2 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 07:32:00", "10/10/2017 07:52:00");
        Visibility vis3 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 08:32:00", "10/10/2017 08:52:00");

        Visibility vis4 = stub.createVisibility(4, "SAT_1", "Kir", null, "10/10/2017 09:32:00", "10/10/2017 09:52:00");

        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1,vis2,vis3,vis4));
        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-1", "10/10/2017 06:40:00", "10/10/2017 06:50:00", "left", "SAT_1");
        acq.setSizeV(200);
        acq.setSizeH(200);

        acq.setPolarization(Polarization.VH_HV);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        List<String> acqList = new ArrayList<>(Arrays.asList("pdm","pdm"));
        userInfo1.setAcquisitionStationIdList(acqList);
        userInfoList.add(userInfo1);
        acq.setUserInfo(userInfoList);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        PassThrough pt = this.ptMng.createPassThrough(acq, this.droolsParams, resFunc);
        System.out.println("pt planned : " + pt);
        this.ptMng.setAcquisitionStationForPt(acq, pt);
        System.out.println("pt planned : " + pt);
        assertEquals(1,pt.getGroundStationId().size());
        assertEquals("pdm",pt.getGroundStationId().get(0));
    }

    
}
