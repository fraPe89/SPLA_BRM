/**
 *
 */

package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;

/**
 * @author francesca
 *
 */
public class EquivalentDTOTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;

    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "Test_1000_dto";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;

        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    @Test
    public void testSetStartAndStop_with_man() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partner = this.droolsParams.getAllPartners().get(0);
        EquivalentDTO equivDto = new EquivalentDTO();

        UserInfo userInfoMaster = new UserInfo(this.droolsParams.getAllPartners().get(0).getPartnerId());
        userInfoMaster.setUgsId(partner.getPartnerId());

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:59:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setImageBIC(25);
        dto1.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:54:00", "10/10/2017 16:55:10", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setImageBIC(25);
        dto2.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:51:00", "10/10/2017 16:52:10", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setImageBIC(25);
        dto3.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        Maneuver man = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:43:00", "10/10/2017 17:03:00", "SAT_1", Actuator.CMGA);
        man.setType(ManeuverType.PitchCPS);

        List<DTO> allDtoAssociated = new ArrayList<>(Arrays.asList(dto1, dto2, dto3));
        List<Maneuver> allManAssociated = new ArrayList<>(Arrays.asList(man));
        double extraCostTheatre = 10;

        equivDto.setAllDtoInEquivalentDto(allDtoAssociated);
        equivDto.setManAssociated(allManAssociated);
        equivDto.setExtraCostPitch(extraCostTheatre);
        System.out.println("equivalent dto before set start and stop : " + equivDto);

        equivDto.setStartAndStop();

        System.out.println("equivalent dto after set start and stop : " + equivDto);

        assertEquals(man.getStartTime(), equivDto.getStartTime());
        assertEquals(man.getEndTime(), equivDto.getEndTime());
    }

    @Test
    public void testSetStartAndStop_without_man() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partner = this.droolsParams.getAllPartners().get(0);
        EquivalentDTO equivDto = new EquivalentDTO();

        UserInfo userInfoMaster = new UserInfo(this.droolsParams.getAllPartners().get(0).getPartnerId());
        userInfoMaster.setUgsId(partner.getPartnerId());

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:59:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setImageBIC(25);
        dto1.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:54:00", "10/10/2017 16:55:10", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setImageBIC(25);
        dto2.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:51:00", "10/10/2017 16:52:10", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setImageBIC(25);
        dto3.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        List<DTO> allDtoAssociated = new ArrayList<>(Arrays.asList(dto1, dto2, dto3));

        equivDto.setAllDtoInEquivalentDto(allDtoAssociated);
        System.out.println("equivalent dto before set start and stop : " + equivDto);

        equivDto.setStartAndStop();

        System.out.println("equivalent dto after set start and stop : " + equivDto);

        assertEquals(dto3.getStartTime(), equivDto.getStartTime());
        assertEquals(dto1.getEndTime(), equivDto.getEndTime());
    }

    @Test
    public void testRejectAllDtoInEquivalent() throws Exception
    {
        EquivalentDTO equivDto = new EquivalentDTO();
        Partner partner = this.droolsParams.getAllPartners().get(0);

        UserInfo userInfoMaster = new UserInfo(this.droolsParams.getAllPartners().get(0).getPartnerId());
        userInfoMaster.setUgsId(partner.getPartnerId());

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:59:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setImageBIC(25);
        dto1.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:54:00", "10/10/2017 16:55:10", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setImageBIC(25);
        dto2.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:51:00", "10/10/2017 16:52:10", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        dto3.setImageBIC(25);
        dto3.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        List<DTO> allDtoAssociated = new ArrayList<>(Arrays.asList(dto1, dto2, dto3));

        equivDto.setAllDtoInEquivalentDto(allDtoAssociated);
        System.out.println("equivalent dto before set start and stop : " + equivDto);

        equivDto.setStartAndStop();

        assertTrue(dto1.getReasonOfReject() == null);
        assertTrue(dto2.getReasonOfReject() == null);
        assertTrue(dto3.getReasonOfReject() == null);

        ReasonOfReject reason = ReasonOfReject.theatreOverlapAcquisition;
        equivDto.rejectAllDtoInEquivalent(reason);

        assertTrue(dto1.getReasonOfReject().compareTo(reason) == 0);
        assertTrue(dto2.getReasonOfReject().compareTo(reason) == 0);
        assertTrue(dto3.getReasonOfReject().compareTo(reason) == 0);
    }

}
