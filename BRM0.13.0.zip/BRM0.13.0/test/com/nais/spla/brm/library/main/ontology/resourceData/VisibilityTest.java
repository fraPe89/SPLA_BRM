
package com.nais.spla.brm.library.main.ontology.resourceData;

public class VisibilityTest
{

}
