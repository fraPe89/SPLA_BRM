
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class SessionTypeTest
{

    @Test
    public void testEnumSessionType()
    {
        List<SessionType> allSessionTypeForTest = new ArrayList<>(Arrays.asList(SessionType.premium, SessionType.routine, SessionType.urgent));
        SessionType[] allSessionType = SessionType.values();
        for (int i = 0; i < allSessionType.length; i++)
        {
            for (int j = 0; j < allSessionTypeForTest.size(); j++)
            {
                if (allSessionType[i].equals(allSessionTypeForTest.get(j)))
                {
                    allSessionTypeForTest.remove(j);
                    j--;
                }
            }
        }
        SessionType type;
        type = SessionType.valueOf("premium");
        System.out.println("Selected : " + type);

        assertEquals(0, allSessionTypeForTest.size());
    }
}
