
package com.nais.spla.brm.library.main.drools.rules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ConfigMaps;

public class DtoToAcqRuleTest
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestTheatre";
        this.maxBicForTest = 200;
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_VU_overlap_simple() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // droolsInstance.getAllTasksAcceptedAsMap(droolsParams, currentSession)
        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.VU);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        Acquisition acqRejected = rejected.get(dtoTest.getDtoId());

        System.out.println(acqRejected);
        rejected.clear();

        System.out.println("involved ele" + acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d));
        List<String> elementsInvolvedId = acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d).get(0).getElementsInvolved();

        for (int i = 0; i < elementsInvolvedId.size(); i++)
        {
            String acqToRejectId = elementsInvolvedId.get(i);
            DroolsOperations.retractSingleAcq(this.droolsParams, acqToRejectId, this.sessionId, this.currentKieSession, ReasonOfReject.deletedForLMP);
        }
        System.out.println("all partners before VU : " + this.droolsParams.getAllPartners());

        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.deletedForLMP));

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("all partners after VU : " + this.droolsParams.getAllPartners());
        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_sessionVU_restoreBic() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.urgent, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("all partners before first dto : " + this.droolsParams.getAllPartners());

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("all partners after first dto : " + this.droolsParams.getAllPartners());

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // droolsInstance.getAllTasksAcceptedAsMap(droolsParams, currentSession)
        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.VU);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        Acquisition acqRejected = rejected.get(dtoTest.getDtoId());

        System.out.println(acqRejected);
        rejected.clear();

        System.out.println("involved ele" + acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d));
        List<String> elementsInvolvedId = acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d).get(0).getElementsInvolved();

        for (int i = 0; i < elementsInvolvedId.size(); i++)
        {
            String acqToRejectId = elementsInvolvedId.get(i);
            DroolsOperations.retractSingleAcq(this.droolsParams, acqToRejectId, this.sessionId, this.currentKieSession, ReasonOfReject.deletedForLMP);
        }
        System.out.println("all partners before VU : " + this.droolsParams.getAllPartners());

        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.deletedForLMP));

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("all partners after VU : " + this.droolsParams.getAllPartners());
        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_VU_overlap_VU() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.VU);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.VU);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_VU_overlap_LMP() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.LMP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.VU);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        Acquisition acqRejected = rejected.get(dtoTest.getDtoId());

        System.out.println(acqRejected);
        rejected.clear();

        System.out.println("involved ele" + acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d));
        List<String> elementsInvolvedId = acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d).get(0).getElementsInvolved();

        for (int i = 0; i < elementsInvolvedId.size(); i++)
        {
            String acqToRejectId = elementsInvolvedId.get(i);
            System.out.println("ace to retract : " + acqToRejectId);
            DroolsOperations.retractSingleAcq(this.droolsParams, acqToRejectId, this.sessionId, this.currentKieSession, ReasonOfReject.deletedForLMP);
        }

        System.out.println("rejected : " + rejected);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(3, rejected.size());

        // assertEquals(true,du.checkIfContainsTheExpectedReason(dto1.getDtoId(),
        // rejected, ReasonOfReject.acqOverlapWithAcquisition));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.deletedForLMP));

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_LMP_overlap_with_more_elements_than_replaceable_dto() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_VU() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.VU);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_LMP_overlap_VU() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.VU);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_LMP_overlap_LMP() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.LMP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId(), dto3.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_LMP_overlap_with_all_replaceable_dto() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId(), dto3.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        Acquisition acqRejected = rejected.get(dtoTest.getDtoId());

        System.out.println(acqRejected);

        System.out.println("involved ele" + acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d));
        List<String> elementsInvolvedId = acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d).get(0).getElementsInvolved();
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        for (int i = 0; i < elementsInvolvedId.size(); i++)
        {
            String acqToRejectId = elementsInvolvedId.get(i);
            DroolsOperations.retractSingleAcq(this.droolsParams, acqToRejectId, this.sessionId, this.currentKieSession, ReasonOfReject.deletedForLMP);
        }

        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.deletedForLMP));

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_LMP_overlap_with_less_elements_than_replaceable_dto() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId(), dto3.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        Acquisition acqRejected = rejected.get(dtoTest.getDtoId());

        System.out.println(acqRejected);

        System.out.println("involved ele" + acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d));
        List<String> elementsInvolvedId = acqRejected.getReasonOfReject().get(0).getElementsInvolved().get(-1d).get(0).getElementsInvolved();

        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());

        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        rejected.clear();

        for (int i = 0; i < elementsInvolvedId.size(); i++)
        {
            String acqToRejectId = elementsInvolvedId.get(i);
            System.out.println("ace to retract : " + acqToRejectId);
            DroolsOperations.retractSingleAcq(this.droolsParams, acqToRejectId, this.sessionId, this.currentKieSession, ReasonOfReject.deletedForLMP);
        }

        System.out.println("rejected : " + rejected);
        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(2, rejected.size());

        // assertEquals(true,du.checkIfContainsTheExpectedReason(dto1.getDtoId(),
        // rejected, ReasonOfReject.acqOverlapWithAcquisition));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), rejected, ReasonOfReject.deletedForLMP));
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.deletedForLMP));

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_simple_overlap_simple() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_simple_overlap_VU() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.VU);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_simple_overlap_LMP() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPrType(PRType.LMP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> alltasks : allTasksAccepted.entrySet())
        {
            System.out.println("task : " + alltasks.getValue());
        }
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_invalidSize() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPol(Polarization.HH);
        dtoTest.setSizeV(4000);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.PP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_invalidUserInfo() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.getUserInfo().clear();
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.PP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFromDtoToAcqRule_DI2s() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.PP);
        dtoTest.setDi2s(true);
        dtoTest.setPrMode(PRMode.DI2S);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(0, rejected.size());

        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);
    }

}
