
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;

public class LowerAndUpperBoundPowersTest
{

    @Test
    public void testLowerAndUpperBoundPowers() throws Exception
    {
        TypeOfAcquisition sensorMode = TypeOfAcquisition.PINGPONG;

        boolean lowerBound = true;

        double powerAssociated = 20;

        LowerAndUpperBoundPowers lowerUpper = new LowerAndUpperBoundPowers(sensorMode, lowerBound, powerAssociated);

        assertEquals(powerAssociated, lowerUpper.getPowerAssociated(), 0);
        assertEquals(lowerBound, lowerUpper.isLowerBound());
        assertEquals(sensorMode, lowerUpper.getSensorMode());

    }

}
