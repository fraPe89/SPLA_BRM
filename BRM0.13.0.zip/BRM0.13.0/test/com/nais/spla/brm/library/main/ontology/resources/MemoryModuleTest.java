
package com.nais.spla.brm.library.main.ontology.resources;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MemoryModuleTest
{

    @Test
    public void testMemoryModuleString() throws Exception
    {
        String memId = "mm1";

        long freeSectors = 30;
        boolean inUse = true;

        MemoryModule mem1 = new MemoryModule(memId);
        mem1.setInUse(inUse);
        mem1.setFreeSectors(freeSectors);

        MemoryModule mem2 = new MemoryModule(memId, freeSectors);
        mem2.setInUse(inUse);

        assertEquals(mem1.isInUse(), mem2.isInUse());
        assertEquals(mem1.getId(), mem2.getId());
        assertEquals(mem1.getFreeSectors(), mem2.getFreeSectors(), 0);
        assertEquals(mem1.toString(), mem2.toString());

    }

}
