
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SectorAndVisForPartner;
import com.nais.spla.brm.library.main.ontology.resourceData.SizeOfSectorDwl;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.PsPolarization;

/**
 * The Class PdhtManagementTest.
 */
public class PdhtManagementTest
{

    /** The pdht mng. */
    PdhtManagement pdhtMng = new PdhtManagement();

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /** The PDHT function. */
    private TreeMap<Long, ComplexPdht> PDHTFunction = null;

    /** The stub. */
    private StubResources stub = new StubResources();

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestManeuverManagement";
        this.droolsParams = new DroolsParameters();
        this.PDHTFunction = new TreeMap<>();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Test insert sto in PDHT.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void insertStoInPDHT_no_space_Test() throws Exception
    {
        System.out.println("Running Test : insertStoInPDHT_no_space_Test \n\n");

        // create a mission horizon
        MissionHorizon mh = this.stub.createMH("10/10/2017 10:00:00", "10/10/2017 18:00:00");

        // setUp drools environment
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        TreeMap<Long, ComplexPdht> PDHTFunction = new TreeMap<>();
        long freeMemoryForTest = 600;
        PDHT previousPDHT = new PDHT("pdhtId", "PDHT1", "SAT_1", freeMemoryForTest, null);
        System.out.println("pdht : " + previousPDHT);
        PDHTFunction.put(mh.getStart().getTime(), new ComplexPdht(previousPDHT));
        Acquisition acq = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        double durationInSec = (acq.getEndTime().getTime() - acq.getStartTime().getTime()) / 1000;
        System.out.println("acq duration : " + durationInSec);
        int imgSize = (int) (durationInSec * (this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getWizardLinkDataRate() / 8));
        System.out.println("image size : " + imgSize);
        acq.setSizeH(imgSize);
        acq.setPolarization(Polarization.HH);
        Storage sto = this.pdhtMng.createNewStorage(acq, this.droolsParams);
        System.out.println("storage associated : " + sto);
        boolean insertedInPdht = this.pdhtMng.insertStoInPDHT(PDHTFunction, sto);
        System.out.println("inserted : " + insertedInPdht);
        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }
        assertFalse(insertedInPdht);
    }

    /**
     * Test insert sto in PDHT.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void insertStoInPDHT_no_space_drools_Test() throws Exception
    {
        MissionHorizon mh = this.stub.createMH("10/10/2017 10:00:00", "10/10/2017 18:00:00");
        String satId = "SAT_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : A_TestAcceptAcquisition \n\n");
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        TreeMap<Long, ComplexPdht> PDHTFunction = resFunc.getPDHTFunctionAssociatedToSat(satId);
        long freeMemoryForTest = 600;
        PDHT previousPDHT = new PDHT("pdhtId", "PDHT1", satId, freeMemoryForTest, null);
        System.out.println("pdht : " + previousPDHT);
        PDHTFunction.put(mh.getStart().getTime(), new ComplexPdht(previousPDHT));
        Acquisition acq = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        double durationInSec = (acq.getEndTime().getTime() - acq.getStartTime().getTime()) / 1000;
        System.out.println("acq duration : " + durationInSec);
        int imgSize = (int) (durationInSec * (this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getWizardLinkDataRate() / 8));
        System.out.println("image size : " + imgSize);
        acq.setSizeH(imgSize);
        acq.setPolarization(Polarization.HH);
        Storage sto = this.pdhtMng.createNewStorage(acq, this.droolsParams);
        System.out.println("storage associated : " + sto);
        boolean insertedInPdht = this.pdhtMng.insertStoInPDHT(PDHTFunction, sto);
        System.out.println("inserted : " + insertedInPdht);
        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }
        assertFalse(insertedInPdht);
    }

    /**
     * Test insert storage in PDHT , same examples reported in official
     * documentation.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Test
    public void insertStoInPDHT_as_official_documentation_Test() throws ParseException, Exception
    {
        String sessionId = "testInsertStoInPDHT_as_official_documentation";
        DroolsParameters droolsParams = new DroolsParameters();
        DroolsUtils du = new DroolsUtils();
        Long PDHTMaxMemory = 5000000L;
        int currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        DroolsOperations droolsInstance = du.setUpSessionForTest(sessionId, droolsParams, currentKieSession, PDHTMaxMemory, maxBicForTest, extraCostLeft);
        MissionHorizon mh = this.stub.createMH("10/10/2017 10:00:00", "10/10/2017 19:00:00");
        du.setUpDrools(sessionId, droolsParams, droolsInstance);
        droolsInstance = du.setUpSession(sessionId, SessionType.premium, droolsParams, droolsInstance, currentKieSession, "_");
        System.out.println("Running Test : testInsertStoInPDHT_as_official_documentation \n\n");

        System.out.println("pdht : " + droolsParams.getAllPDHT().get(0));
        droolsParams.getAllPDHT().get(0).setFreeMemory(49146);
        droolsParams.getAllPDHT().get(0).setCapacity(null);
        this.PDHTFunction.put(mh.getStart().getTime(), new ComplexPdht(droolsParams.getAllPDHT().get(0)));

        List<MemoryModule> memModuleList = this.PDHTFunction.get(mh.getStart().getTime()).getPdht().getMMList();

        // assert that, at start, all memory modules have the same free sectors
        for (int i = 0; i < memModuleList.size(); i++)
        {
            assertEquals(8191, memModuleList.get(i).getFreeSectors());
        }

        Storage sto1 = du.createStorage("sto1", "10/10/2017 12:00:00", "10/10/2017 12:05:00", "SAT_1", 10, 20, Polarization.HH);
        sto1.setPacketStoreSizeH(10);
        sto1.setPacketStoreSizeV(0);
        System.out.println("storage1 associated : " + sto1);
        boolean insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto1);
        System.out.println("inserted in pdht : " + insertedInPdht);

        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : this.PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }

        List<Long> decrementedModules = new ArrayList<>(Arrays.asList(8181l, 8191l, 8191l, 8191l, 8191l, 8191l));
        memModuleList = this.PDHTFunction.get(sto1.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        Storage sto2 = du.createStorage("sto2", "10/10/2017 12:06:00", "10/10/2017 12:07:00", "SAT_1", 100, 20, Polarization.HV);
        sto2.setPacketStoreSizeH(100);
        sto2.setPacketStoreSizeV(100);
        System.out.println("storage2 associated : " + sto2);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto2);
        System.out.println("packet stores2 created : " + insertedInPdht);

        decrementedModules = new ArrayList<>(Arrays.asList(8181l, 8091l, 8091l, 8191l, 8191l, 8191l));
        memModuleList = this.PDHTFunction.get(sto2.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        Storage sto3 = du.createStorage("sto3", "10/10/2017 12:09:00", "10/10/2017 12:10:00", "SAT_1", 200, 20, Polarization.HV);
        sto3.setPacketStoreSizeH(200);
        sto3.setPacketStoreSizeV(200);
        System.out.println("storage associated : " + sto3);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto3);
        System.out.println("packet stores created : " + insertedInPdht);

        decrementedModules = new ArrayList<>(Arrays.asList(8181l, 8091l, 8091l, 7991l, 7991l, 8191l));
        memModuleList = this.PDHTFunction.get(sto3.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        Storage sto4 = du.createStorage("sto4", "10/10/2017 12:12:00", "10/10/2017 12:16:00", "SAT_1", 3200, 20, Polarization.HV);
        System.out.println("");
        sto4.setPacketStoreSizeH(3200);
        sto4.setPacketStoreSizeV(3200);
        System.out.println("storage associated : " + sto4);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto4);
        System.out.println("packet stores created : " + insertedInPdht);

        decrementedModules = new ArrayList<>(Arrays.asList(7711l, 5394l, 7588l, 7991l, 7991l, 5461l));
        memModuleList = this.PDHTFunction.get(sto4.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        Storage sto5 = du.createStorage("sto5", "10/10/2017 12:19:00", "10/10/2017 12:20:00", "SAT_1", 4800, 20, Polarization.HV);
        sto5.setPacketStoreSizeH(4800);
        sto5.setPacketStoreSizeV(4800);
        System.out.println("storage associated : " + sto5);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto5);
        System.out.println("packet stores created : " + insertedInPdht);

        decrementedModules = new ArrayList<>(Arrays.asList(5141l, 5394l, 5358l, 5328l, 5854l, 5461l));
        memModuleList = this.PDHTFunction.get(sto5.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : this.PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }

        Storage sto6 = du.createStorage("sto6", "10/10/2017 12:21:00", "10/10/2017 12:22:00", "SAT_1", 5600, 20, Polarization.HV);
        sto6.setPacketStoreSizeH(5600);
        sto6.setPacketStoreSizeV(5600);
        System.out.println("storage associated : " + sto6);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto6);
        System.out.println("packet stores created : " + insertedInPdht);

        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : this.PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }

        decrementedModules = new ArrayList<>(Arrays.asList(5141l, 1798l, 3354l, 5328l, 1952l, 3763l));
        memModuleList = this.PDHTFunction.get(sto6.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        Storage sto7 = du.createStorage("sto7", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "SAT_1", 6400, 20, Polarization.HV);
        sto7.setPacketStoreSizeH(6400);
        sto7.setPacketStoreSizeV(6400);
        System.out.println("storage associated : " + sto7);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto7);
        System.out.println("packet stores created : " + insertedInPdht);

        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : this.PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }

        decrementedModules = new ArrayList<>(Arrays.asList(2293l, 1443l, 1118l, 1776l, 651l, 1255l));
        memModuleList = this.PDHTFunction.get(sto7.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);

        Storage sto8 = du.createStorage("sto8", "10/10/2017 12:29:00", "10/10/2017 12:30:00", "SAT_1", 4200, 20, Polarization.HV);
        sto8.setPacketStoreSizeH(4200);
        sto8.setPacketStoreSizeV(4200);
        System.out.println("storage associated : " + sto8);
        insertedInPdht = this.pdhtMng.insertStoInPDHT(this.PDHTFunction, sto8);
        System.out.println("packet stores created : " + insertedInPdht);
        assertEquals(false, insertedInPdht);
        assertEquals(0, sto8.getPacketsAssociated().size());

        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : this.PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }

        decrementedModules = new ArrayList<>(Arrays.asList(2293l, 1443l, 1118l, 1776l, 651l, 1255l));
        memModuleList = this.PDHTFunction.get(sto7.getStartTime().getTime()).getPdht().getMMList();
        checkCorrectnessPDHT(memModuleList, decrementedModules);
    }

    /**
     * Check correctness PDHT.
     *
     * @param memModuleList
     *            the mem module list
     * @param decrementedModules
     *            the decremented modules
     */
    private void checkCorrectnessPDHT(List<MemoryModule> memModuleList, List<Long> decrementedModules)
    {
        for (int i = 0; i < memModuleList.size(); i++)
        {
            if (memModuleList.get(i).getId().equalsIgnoreCase("MM1"))
            {
                assertEquals(decrementedModules.get(0), memModuleList.get(i).getFreeSectors(), 0);
            }
            else if (memModuleList.get(i).getId().equalsIgnoreCase("MM2"))
            {
                assertEquals(decrementedModules.get(1), memModuleList.get(i).getFreeSectors(), 0);
            }
            else if (memModuleList.get(i).getId().equalsIgnoreCase("MM3"))
            {
                assertEquals(decrementedModules.get(2), memModuleList.get(i).getFreeSectors(), 0);
            }
            else if (memModuleList.get(i).getId().equalsIgnoreCase("MM4"))
            {
                assertEquals(decrementedModules.get(3), memModuleList.get(i).getFreeSectors(), 0);
            }
            else if (memModuleList.get(i).getId().equalsIgnoreCase("MM5"))
            {
                assertEquals(decrementedModules.get(4), memModuleList.get(i).getFreeSectors(), 0);
            }
            else if (memModuleList.get(i).getId().equalsIgnoreCase("MM6"))
            {
                assertEquals(decrementedModules.get(5), memModuleList.get(i).getFreeSectors(), 0);
            }
        }
    }

    /**
     * Test compute decrement on memory modules.
     *
     * @throws Exception
     *             the exception
     */
    /*
     * @Test public void testCheckIfThresholdReached() throws Exception { String
     * sessionId = "TestPDHT"; DroolsParameters droolsParams = new
     * DroolsParameters(); Map<String, Acquisition> rejectedElements = new
     * HashMap<String, Acquisition>(); Long PDHTMaxMemory = 5000000L; int
     * currentKieSession = 1; DroolsUtils du = new DroolsUtils(); double
     * maxBicForTest = 100; double extraCostLeft = 10; double extraCostTheatre =
     * 5; DroolsOperations droolsInstance = du.setUpSessionForTest(sessionId,
     * droolsParams, currentKieSession, PDHTMaxMemory, maxBicForTest,
     * extraCostLeft, extraCostTheatre);
     *
     * MissionHorizon mh = du.createMH("10/10/2017 15:55:00",
     * "10/10/2017 16:00:00"); du.setUpDrools(sessionId, droolsParams,
     * droolsInstance, currentKieSession); droolsInstance =
     * du.setUpSession(sessionId, droolsParams, droolsInstance,
     * currentKieSession, false);
     * System.out.println("Running Test : testCheckIfThresholdReached \n\n");
     *
     * TreeMap<Long, PDHT> pDHTFunction = new TreeMap<Long, PDHT>();
     * Map<MemoryModule, PsPolarization> modulesCapacity = new
     * HashMap<MemoryModule, PsPolarization>(); Storage stoForTest = new
     * Storage("sto_1", 200, 21); pdhtMng.checkIfThresholdReached(pDHTFunction,
     * modulesCapacity, stoForTest, mh.getStop()); }
     */
    @Test
    public void computeDecrementOnMemoryModules_Test() throws Exception
    {

    }

    /**
     * Test create new storage.
     */
    @Test
    public void createNewStorage_single_pol_HH_Test()
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.HH);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        acq.setSizeH(200);
        int expectedNumberOfSectorH = acq.getSizeH();
        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        System.out.println("storage : " + returnedSto);
        assertEquals(acq.getStartTime(), returnedSto.getStartTime());
        assertEquals(acq.getEndTime(), returnedSto.getEndTime());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeH());
        assertEquals(0, returnedSto.getPacketStoreSizeV());
        assertEquals(acq.getIdTask(), returnedSto.getRelatedAcqId());
    }

    /**
     * Test create new storage.
     */
    @Test
    public void createNewStorage_single_pol_VV_Test()
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.VV);
        acq.setSizeV(200);
        acq.setSizeH(0);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        int expectedNumberOfSectorV = acq.getSizeV();

        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        System.out.println("storage : " + returnedSto);
        assertEquals(acq.getStartTime(), returnedSto.getStartTime());
        assertEquals(acq.getEndTime(), returnedSto.getEndTime());
        assertEquals(expectedNumberOfSectorV, returnedSto.getPacketStoreSizeV());
        assertEquals(0, returnedSto.getPacketStoreSizeH());
        assertEquals(acq.getIdTask(), returnedSto.getRelatedAcqId());
    }

    /**
     * Creates the new storage single pol V V error test.
     */
    @Test
    public void createNewStorage_single_pol_VV_error_Test()
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.VV);
        acq.setSizeH(200);
        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        System.out.println("storage : " + returnedSto);
        assertEquals(null, returnedSto);
    }

    /**
     * Check if size is valid pol H V not both size populated test.
     */
    @Test
    public void checkIfSizeIsValid_polHV_notBothSizePopulated_Test()
    {
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.HV);

        // invalid V
        acq.setSizeH(200);
        acq.setSizeV(0);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));

        // invalid H
        acq.setSizeH(0);
        acq.setSizeV(200);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));
    }

    /**
     * Check if size is valid pol V H not both size populated test.
     */
    @Test
    public void checkIfSizeIsValid_polVH_notBothSizePopulated_Test()
    {
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.VH);

        // invalid V
        acq.setSizeH(200);
        acq.setSizeV(0);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));

        // invalid H
        acq.setSizeH(0);
        acq.setSizeV(200);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));
    }

    /**
     * Check if size is valid both pol are zero test.
     */
    @Test
    public void checkIfSizeIsValid_bothPolAreZero_Test()
    {
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.VV);
        // zero as default inside the constructor of acq
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));
    }

    /**
     * Check if size is valid pol H H size H is zero test.
     */
    @Test
    public void checkIfSizeIsValid_PolHH_sizeHIsZero_Test()
    {
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.HH);
        acq.setSizeH(0);
        acq.setSizeV(100);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));

        acq.setSizeH(100);
        acq.setSizeV(100);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));
    }

    /**
     * Check if size is valid pol V V size V not filled test.
     */
    @Test
    public void checkIfSizeIsValid_pol_VV_sizeVNotFilled_Test()
    {
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.VV);
        acq.setSizeH(200);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));
    }

    /**
     * Test create new storage.
     */
    @Test
    public void createNewStorage_double_pol_HV_Test()
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setMinimumTimeBetweenStorageAndAcq(1500);

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setSizeH(200);
        acq.setSizeV(200);
        acq.setPolarization(Polarization.HV);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        int expectedNumberOfSectorH = ((Double) java.lang.Math.ceil(acq.getSizeH())).intValue();
        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        Date stoStartTime= DroolsUtils.createDate("10/10/2017 12:22:58.500");
        System.out.println("storage : " + returnedSto);
        assertEquals(stoStartTime, returnedSto.getStartTime());

        assertEquals(stoStartTime.getTime(), returnedSto.getStartTime().getTime());
        assertEquals(acq.getEndTime(), returnedSto.getEndTime());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeH());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeV());
        assertEquals(acq.getIdTask(), returnedSto.getRelatedAcqId());
    }

    /**
     * Test create new storage.
     */
    @Test
    public void createNewStorage_double_pol_VHVH_Test()
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setSizeH(200);
        acq.setSizeV(200);
        acq.setPolarization(Polarization.VH_VH);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        int expectedNumberOfSectorH = ((Double) java.lang.Math.ceil(acq.getSizeH())).intValue();
        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        System.out.println("storage : " + returnedSto);
        assertEquals(acq.getStartTime(), returnedSto.getStartTime());
        assertEquals(acq.getEndTime(), returnedSto.getEndTime());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeH());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeV());
        assertEquals(acq.getIdTask(), returnedSto.getRelatedAcqId());
    }

    /**
     * Test create new storage.
     */
    @Test
    public void createNewStorage_double_pol_VH_Test()
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setSizeH(200);
        acq.setSizeV(200);
        acq.setPolarization(Polarization.VH);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        int expectedNumberOfSectorH = acq.getSizeH();
        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        System.out.println("storage : " + returnedSto);
        assertEquals(acq.getStartTime(), returnedSto.getStartTime());
        assertEquals(acq.getEndTime(), returnedSto.getEndTime());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeH());
        assertEquals(expectedNumberOfSectorH, returnedSto.getPacketStoreSizeV());
        assertEquals(acq.getIdTask(), returnedSto.getRelatedAcqId());
    }

    /**
     * Test sort memory modules.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void sortMemoryModules_Test() throws Exception
    {

    }

    /**
     * Test complete packet store with others MM.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void completePacketStoreWithOthersMM_Test() throws Exception
    {
        PacketStore ps = new PacketStore("psForTest", Polarization.HH, 200);
        // ps.addMemoryModuleToPS(mem, 100);

        List<MemoryModule> memoryModulesName = new ArrayList<>();
        this.pdhtMng.completePacketStoreWithOthersMM(ps, memoryModulesName);
    }

    /**
     * Test remove storage.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void removeStorage_Test() throws Exception
    {
        // throw new RuntimeException("not yet implemented");
    }

    /**
     * Test restore amount to pdht.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testRestoreAmountToPdht() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : testRestoreAmountToPdht \n\n");

        // setting the pdht function with values taken at mission horizon start
        // time
        this.PDHTFunction.put(this.droolsParams.getCurrentMH().getStart().getTime(), new ComplexPdht(this.droolsParams.getAllPDHT().get(0)));

        // creating an acq for test
        Acquisition acqToCheck = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acqToCheck.setPolarization(Polarization.HH);
        acqToCheck.setSizeH(2000);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acqToCheck.setUserInfo(userInfoList);

        // and it's related storage
        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acqToCheck, this.droolsParams);
        this.pdhtMng.insertStoInPDHT(this.PDHTFunction, stoAssociatedToAcq);

        System.out.println("pdht function :" + this.PDHTFunction);
        System.out.println("created packet store : " + stoAssociatedToAcq.getPacketsAssociated());
        System.out.println("created packet store : " + stoAssociatedToAcq);

        // extract packet store from storage
        Map<MemoryModule, Long> plannedOnMem = stoAssociatedToAcq.getPacketsAssociated().get(0).getPlannedOnMemModule();

        boolean carrierL2Selection = false;
        Download downloadToRestore = this.du.createDownload("SAT_1", "10/10/2017 10:00:00", "10/10/2017 10:00:00", DownlinkStrategy.DELETE, carrierL2Selection);
        downloadToRestore.setPol(acqToCheck.getPolarization());
        this.pdhtMng.restoreAmountToPdht(downloadToRestore, this.PDHTFunction, plannedOnMem);

        System.out.println("pdht function :" + this.PDHTFunction);

    }

    /**
     * Test restore amount to pdht.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testRestoreAmountToPdht_prevProcessed() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : testRestoreAmountToPdht \n\n");

        // setting the pdht function with values taken at mission horizon start
        // time
        this.PDHTFunction.put(this.droolsParams.getCurrentMH().getStart().getTime(), new ComplexPdht(this.droolsParams.getAllPDHT().get(0)));

        // creating an acq for test
        Acquisition acqToCheck = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acqToCheck.setPolarization(Polarization.HH);
        acqToCheck.setSizeH(2000);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acqToCheck.setUserInfo(userInfoList);

        acqToCheck.setPreviousMh(true);

        // and it's related storage
        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acqToCheck, this.droolsParams);
        this.pdhtMng.insertStoInPDHT(this.PDHTFunction, stoAssociatedToAcq);

        System.out.println("pdht function :" + this.PDHTFunction);
        System.out.println("created packet store : " + stoAssociatedToAcq.getPacketsAssociated());
        System.out.println("created packet store : " + stoAssociatedToAcq);

        // extract packet store from storage
        Map<MemoryModule, Long> plannedOnMem = stoAssociatedToAcq.getPacketsAssociated().get(0).getPlannedOnMemModule();

        boolean carrierL2Selection = false;
        Download downloadToRestore = this.du.createDownload("SAT_1", "10/10/2017 10:00:00", "10/10/2017 10:00:00", DownlinkStrategy.DELETE, carrierL2Selection);
        downloadToRestore.setPol(acqToCheck.getPolarization());
        this.pdhtMng.restoreAmountToPdht(downloadToRestore, this.PDHTFunction, plannedOnMem);

        System.out.println("pdht function :" + this.PDHTFunction);

    }

    /**
     * Test populate polarization.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testPopulatePolarization() throws Exception
    {
        Polarization[] returnedPolHH = PdhtManagement.populatePolarization(Polarization.HH);
        assertEquals(1, returnedPolHH.length);
        assertEquals(Polarization.HH, returnedPolHH[0]);

        Polarization[] returnedPolVV = PdhtManagement.populatePolarization(Polarization.VV);
        assertEquals(1, returnedPolVV.length);
        assertEquals(Polarization.VV, returnedPolVV[0]);

        Polarization[] returnedPolHV = PdhtManagement.populatePolarization(Polarization.HV);
        assertEquals(2, returnedPolHV.length);
        assertEquals(Polarization.HH, returnedPolHV[0]);
        assertEquals(Polarization.VV, returnedPolHV[1]);

        Polarization[] returnedPolVH = PdhtManagement.populatePolarization(Polarization.VH);
        assertEquals(2, returnedPolVH.length);
        assertEquals(Polarization.VV, returnedPolVH[0]);
        assertEquals(Polarization.HH, returnedPolVH[1]);

        Polarization[] returnedPolVH_HV = PdhtManagement.populatePolarization(Polarization.VH_HV);
        assertEquals(2, returnedPolVH_HV.length);
        assertEquals(Polarization.VV, returnedPolVH_HV[0]);
        assertEquals(Polarization.HH, returnedPolVH_HV[1]);

        Polarization[] returnedPolVH_VH = PdhtManagement.populatePolarization(Polarization.VH_VH);
        assertEquals(2, returnedPolVH_VH.length);
        assertEquals(Polarization.VV, returnedPolVH_VH[0]);
        assertEquals(Polarization.HH, returnedPolVH_VH[1]);

        Polarization[] returnedPolHV_HV = PdhtManagement.populatePolarization(Polarization.HV_HV);
        assertEquals(2, returnedPolHV_HV.length);
        assertEquals(Polarization.HH, returnedPolHV_HV[0]);
        assertEquals(Polarization.VV, returnedPolHV_HV[1]);

        Polarization[] returnedPolHV_VH = PdhtManagement.populatePolarization(Polarization.HV_VH);
        assertEquals(2, returnedPolHV_VH.length);
        assertEquals(Polarization.HH, returnedPolHV_VH[0]);
        assertEquals(Polarization.VV, returnedPolHV_VH[1]);
        
        Polarization[] returnedPolHH_HH = PdhtManagement.populatePolarization(Polarization.HH_HH);
        assertEquals(2, returnedPolHH_HH.length);
        assertEquals(Polarization.HH, returnedPolHH_HH[0]);
        assertEquals(Polarization.HH, returnedPolHH_HH[1]);
        
        Polarization[] returnedPolVV_VV = PdhtManagement.populatePolarization(Polarization.VV_VV);
        assertEquals(2, returnedPolVV_VV.length);
        assertEquals(Polarization.VV, returnedPolVV_VV[0]);
        assertEquals(Polarization.VV, returnedPolVV_VV[1]);
        
        Polarization[] returnedPolHH_VV = PdhtManagement.populatePolarization(Polarization.HH_VV);
        assertEquals(2, returnedPolHH_VV.length);
        assertEquals(Polarization.HH, returnedPolHH_VV[0]);
        assertEquals(Polarization.VV, returnedPolHH_VV[1]);
    }

    /**
     * Test restore priority queue.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testRestorePriorityQueue() throws Exception
    {
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();

        int totalSizeOfAcquisitions = 200;
        int residualSizeOfAcquisitions = 50;

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq1.setPriority(2);
        Acquisition acq2 = this.du.createParametricAcquisition("acq2", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq2.setPriority(4);

        PriorityQueue firstElementInQueque = new PriorityQueue();
        HashMap<String, SectorAndVisForPartner> partnersForAcq1 = new HashMap<>();
        Partner p1 = this.droolsParams.getAllPartners().get(1);
        SizeOfSectorDwl sizeAssocToPartner1 = new SizeOfSectorDwl(totalSizeOfAcquisitions, residualSizeOfAcquisitions, Polarization.HH);
        List<SizeOfSectorDwl> sectorsForPartner = new ArrayList<>();
        sectorsForPartner.add(sizeAssocToPartner1);
        partnersForAcq1.put(p1.getPartnerId(), new SectorAndVisForPartner(null, sectorsForPartner));
        firstElementInQueque.setRelatedAcq(acq1);
        firstElementInQueque.setSectorsNeededForPartners(partnersForAcq1);

        PriorityQueue secondElementInQueque = new PriorityQueue();
        Partner p2 = this.droolsParams.getAllPartners().get(2);
        SizeOfSectorDwl sizeAssocToPartner2 = new SizeOfSectorDwl(totalSizeOfAcquisitions, residualSizeOfAcquisitions, Polarization.HH);
        TreeMap<Polarization, SizeOfSectorDwl> newSize = new TreeMap<>();
        newSize.put(Polarization.HH, sizeAssocToPartner2);

        sectorsForPartner.add(sizeAssocToPartner1);

        partnersForAcq1.put(p2.getPartnerId(), new SectorAndVisForPartner(null, sectorsForPartner));
        secondElementInQueque.setRelatedAcq(acq2);
        secondElementInQueque.setSectorsNeededForPartners(partnersForAcq1);

        downloadPriority.put(acq1.getIdTask(), firstElementInQueque);
        downloadPriority.put(acq2.getIdTask(), secondElementInQueque);

        this.pdhtMng.restorePriorityQueue(downloadPriority);

        for (Map.Entry<String, PriorityQueue> elementsInQueue : downloadPriority.entrySet())
        {
            for (Map.Entry<String, SectorAndVisForPartner> partnersAssociated : elementsInQueue.getValue().getSectorsNeededForPartners().entrySet())
            {
                for (int i = 0; i < partnersAssociated.getValue().getSectorsForPartner().size(); i++)
                {
                    assertEquals(partnersAssociated.getValue().getSectorsForPartner().get(i).getTotalSize(), partnersAssociated.getValue().getSectorsForPartner().get(i).getResidualSize());
                }
            }
        }
    }

    /**
     * Test restore priority queue.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testRestorePriorityQueue_emptyList() throws Exception
    {
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();

        // pdhtMng.restorePriorityQueue(downloadPriority);

        for (Map.Entry<String, PriorityQueue> elementsInQueue : downloadPriority.entrySet())
        {
            for (Map.Entry<String, SectorAndVisForPartner> partnersAssociated : elementsInQueue.getValue().getSectorsNeededForPartners().entrySet())
            {
                for (int i = 0; i < partnersAssociated.getValue().getSectorsForPartner().size(); i++)
                {
                    assertEquals(partnersAssociated.getValue().getSectorsForPartner().get(i).getTotalSize(), partnersAssociated.getValue().getSectorsForPartner().get(i).getResidualSize());
                }
            }
        }
    }

    /**
     * Test insert in priority queue pol HH.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testInsertInPriorityQueue_pol_HH() throws Exception
    {
        Logger logger = LoggerFactory.getLogger(DroolsOperations.class);
        DroolsParameters.setLogger(logger);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq1.setSizeH(20);
        acq1.setSizeV(0);

        UserInfo user1 = new UserInfo();
        user1.setAcquisitionStationIdList(null);
        user1.setOwnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        user1.setSubscriber(false);
        user1.setUgsId("ugsId1");

        UserInfo user2 = new UserInfo();
        user2.setAcquisitionStationIdList(null);
        user2.setOwnerId(this.droolsParams.getAllPartners().get(2).getPartnerId());
        user2.setSubscriber(false);
        user2.setUgsId("ugsId2");

        List<UserInfo> userInfoAssoc = new ArrayList<>(Arrays.asList(user1, user2));

        acq1.setUserInfo(userInfoAssoc);
        acq1.setPolarization(Polarization.HH);
        acq1.setPriority(2);
        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acq1, this.droolsParams);
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();
        PriorityQueue priority = this.pdhtMng.insertInPriorityQueue(acq1,  stoAssociatedToAcq, downloadPriority, this.droolsParams);
        System.out.println(priority);
    }

    /**
     * Test insert in priority queue pol VV.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testInsertInPriorityQueue_pol_VV() throws Exception
    {
        Logger logger = LoggerFactory.getLogger(DroolsOperations.class);
        DroolsParameters.setLogger(logger);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq1.setPolarization(Polarization.VV);
        acq1.setSizeV(20);
        acq1.setSizeH(0);
        acq1.setPriority(2);

        UserInfo user1 = new UserInfo();
        user1.setAcquisitionStationIdList(null);
        user1.setOwnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        user1.setSubscriber(false);
        user1.setUgsId("ugsId1");

        UserInfo user2 = new UserInfo();
        user2.setAcquisitionStationIdList(null);
        user2.setOwnerId(this.droolsParams.getAllPartners().get(2).getPartnerId());
        user2.setSubscriber(false);
        user2.setUgsId("ugsId2");

        List<UserInfo> userInfoAssoc = new ArrayList<>(Arrays.asList(user1, user2));

        acq1.setUserInfo(userInfoAssoc);

        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acq1, this.droolsParams);
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();
        PriorityQueue priority = this.pdhtMng.insertInPriorityQueue(acq1,  stoAssociatedToAcq, downloadPriority, this.droolsParams);
        System.out.println(priority);
       }

    /**
     * Test insert in priority queue pol VH.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testInsertInPriorityQueue_pol_VH() throws Exception
    {
        Logger logger = LoggerFactory.getLogger(DroolsOperations.class);
        DroolsParameters.setLogger(logger);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq1.setPolarization(Polarization.VH);
        acq1.setPriority(2);
        acq1.setSizeV(20);
        acq1.setSizeH(20);

        UserInfo user1 = new UserInfo();
        user1.setAcquisitionStationIdList(null);
        user1.setOwnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        user1.setSubscriber(false);
        user1.setUgsId("ugsId1");

        UserInfo user2 = new UserInfo();
        user2.setAcquisitionStationIdList(null);
        user2.setOwnerId(this.droolsParams.getAllPartners().get(2).getPartnerId());
        user2.setSubscriber(false);
        user2.setUgsId("ugsId2");

        List<UserInfo> userInfoAssoc = new ArrayList<>(Arrays.asList(user1, user2));

        acq1.setUserInfo(userInfoAssoc);
        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acq1, this.droolsParams);
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();
        PriorityQueue priority = this.pdhtMng.insertInPriorityQueue(acq1,  stoAssociatedToAcq, downloadPriority, this.droolsParams);
        System.out.println(priority);
    }

    /**
     * Test insert in priority queue pol HV.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testInsertInPriorityQueue_pol_HV() throws Exception
    {
        Logger logger = LoggerFactory.getLogger(DroolsOperations.class);
        DroolsParameters.setLogger(logger);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq1.setPolarization(Polarization.HV);
        acq1.setPriority(2);
        acq1.setSizeV(20);
        acq1.setSizeH(20);

        UserInfo user1 = new UserInfo();
        user1.setAcquisitionStationIdList(null);
        user1.setOwnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        user1.setSubscriber(false);
        user1.setUgsId("ugsId1");

        UserInfo user2 = new UserInfo();
        user2.setAcquisitionStationIdList(null);
        user2.setOwnerId(this.droolsParams.getAllPartners().get(2).getPartnerId());
        user2.setSubscriber(false);
        user2.setUgsId("ugsId2");

        List<UserInfo> userInfoAssoc = new ArrayList<>(Arrays.asList(user1, user2));

        acq1.setUserInfo(userInfoAssoc);

        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acq1, this.droolsParams);
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();
        PriorityQueue priority = this.pdhtMng.insertInPriorityQueue(acq1,  stoAssociatedToAcq, downloadPriority, this.droolsParams);
        System.out.println(priority);
    }

    /**
     * Test order priority queue.
     *
     * @throws Exception
     *             the exception
     */

    /*
     * @Test public void testOrderPriorityQueue_decrescent() throws Exception {
     * Acquisition acq1 = du.createParametricAcquisition("acq1",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq1.setPriority(3);
     *
     * Acquisition acq2 = du.createParametricAcquisition("acq2",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq2.setPriority(1);
     *
     * Acquisition acq3 = du.createParametricAcquisition("acq3",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq3.setPriority(2);
     *
     * PriorityQueue priority1 = new PriorityQueue(3, Polarization.HH, acq1);
     * PriorityQueue priority2 = new PriorityQueue(1, Polarization.HH, acq2);
     * PriorityQueue priority3 = new PriorityQueue(2, Polarization.HH, acq3);
     *
     * TreeMap<String, PriorityQueue> downloadPriorityForTest = new
     * TreeMap<String, PriorityQueue>();
     *
     * downloadPriorityForTest.put(acq1.getIdTask(), priority1);
     * downloadPriorityForTest.put(acq2.getIdTask(), priority2);
     * downloadPriorityForTest.put(acq3.getIdTask(), priority3);
     *
     * System.out.println("inserting element not ordered : " + priority1);
     * System.out.println("inserting element not ordered : " + priority2);
     * System.out.println("inserting element not ordered : " + priority3 +
     * "\n");
     *
     * List<PriorityQueue> elementsOrderedByPriority =
     * pdhtMng.orderPriorityQueue(downloadPriorityForTest);
     *
     * System.out.println(elementsOrderedByPriority); assertEquals(priority2,
     * elementsOrderedByPriority.get(0)); assertEquals(priority3,
     * elementsOrderedByPriority.get(1)); assertEquals(priority1,
     * elementsOrderedByPriority.get(2));
     *
     * for (int i = 0; i < elementsOrderedByPriority.size(); i++) {
     * System.out.println("list ordered by priority : " +
     * elementsOrderedByPriority.get(i)); } }
     *
     * @Test public void testOrderPriorityQueue_differentPRTypes() throws
     * Exception { Acquisition acq1 = du.createParametricAcquisition("acq1",
     * "10/10/2017 14:55:00", "10/10/2017 14:56:00", "left", "SAT_1");
     * acq1.setPrType(PRType.PP); acq1.setPriority(2);
     *
     * Acquisition acq2 = du.createParametricAcquisition("acq2",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq2.setPrType(PRType.LMP); acq2.setPriority(1);
     *
     * Acquisition acq3 = du.createParametricAcquisition("acq3",
     * "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
     * acq3.setPrType(PRType.VU); acq3.setPriority(3);
     *
     * Acquisition acq4 = du.createParametricAcquisition("acq4",
     * "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
     * acq4.setPrType(PRType.VU); acq4.setPriority(2);
     *
     * Acquisition acq5 = du.createParametricAcquisition("acq5",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq5.setPrType(PRType.LMP); acq5.setPriority(8);
     *
     * PriorityQueue priority1 = new PriorityQueue(acq1.getPriority(),
     * Polarization.HH, acq1); PriorityQueue priority2 = new
     * PriorityQueue(acq2.getPriority(), Polarization.HH, acq2); PriorityQueue
     * priority3 = new PriorityQueue(acq3.getPriority(), Polarization.HH, acq3);
     * PriorityQueue priority4 = new PriorityQueue(acq4.getPriority(),
     * Polarization.HH, acq4); PriorityQueue priority5 = new
     * PriorityQueue(acq5.getPriority(), Polarization.HH, acq5);
     *
     * TreeMap<String, PriorityQueue> downloadPriorityForTest = new
     * TreeMap<String, PriorityQueue>();
     *
     * downloadPriorityForTest.put(acq1.getIdTask(), priority1);
     * downloadPriorityForTest.put(acq2.getIdTask(), priority2);
     * downloadPriorityForTest.put(acq3.getIdTask(), priority3);
     * downloadPriorityForTest.put(acq4.getIdTask(), priority4);
     * downloadPriorityForTest.put(acq5.getIdTask(), priority5);
     *
     * System.out.println("inserting element not ordered : " + priority1);
     * System.out.println("inserting element not ordered : " + priority2);
     * System.out.println("inserting element not ordered : " + priority3 +
     * "\n");
     *
     * List<PriorityQueue> elementsOrderedByPriority =
     * pdhtMng.orderPriorityQueue(downloadPriorityForTest);
     *
     * System.out.println(elementsOrderedByPriority);
     *
     * for (int i = 0; i < elementsOrderedByPriority.size(); i++) {
     * System.out.println("list ordered by priority : " +
     * elementsOrderedByPriority.get(i)); }
     *
     * assertEquals(priority4, elementsOrderedByPriority.get(0));
     * assertEquals(priority3, elementsOrderedByPriority.get(1));
     * assertEquals(priority2, elementsOrderedByPriority.get(2));
     * assertEquals(priority5, elementsOrderedByPriority.get(3));
     * assertEquals(priority1, elementsOrderedByPriority.get(4)); }
     *
     *
     * @Test public void testOrderPriorityQueue_differentPRTypes_Unranked()
     * throws Exception { Acquisition acq1 =
     * du.createParametricAcquisition("acq1", "10/10/2017 14:55:00",
     * "10/10/2017 14:56:00", "left", "SAT_1");
     * acq1.setPrType(PRType.UNRANKED_ROUTINE); acq1.setPriority(0);
     *
     * Acquisition acq2 = du.createParametricAcquisition("acq2",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq2.setPrType(PRType.UNRANKED_ROUTINE); acq2.setPriority(0);
     *
     * Acquisition acq3 = du.createParametricAcquisition("acq3",
     * "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
     * acq3.setPrType(PRType.UNRANKED_ROUTINE); acq3.setPriority(0);
     *
     * Acquisition acq4 = du.createParametricAcquisition("acq4",
     * "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
     * acq4.setPrType(PRType.VU); acq4.setPriority(2);
     *
     * Acquisition acq5 = du.createParametricAcquisition("acq5",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq5.setPrType(PRType.LMP); acq5.setPriority(8);
     *
     * PriorityQueue priority1 = new PriorityQueue(acq1.getPriority(),
     * Polarization.HH, acq1); PriorityQueue priority2 = new
     * PriorityQueue(acq2.getPriority(), Polarization.HH, acq2); PriorityQueue
     * priority3 = new PriorityQueue(acq3.getPriority(), Polarization.HH, acq3);
     * PriorityQueue priority4 = new PriorityQueue(acq4.getPriority(),
     * Polarization.HH, acq4); PriorityQueue priority5 = new
     * PriorityQueue(acq5.getPriority(), Polarization.HH, acq5);
     *
     * TreeMap<String, PriorityQueue> downloadPriorityForTest = new
     * TreeMap<String, PriorityQueue>();
     *
     * downloadPriorityForTest.put(acq1.getIdTask(), priority1);
     * downloadPriorityForTest.put(acq2.getIdTask(), priority2);
     * downloadPriorityForTest.put(acq3.getIdTask(), priority3);
     * downloadPriorityForTest.put(acq4.getIdTask(), priority4);
     * downloadPriorityForTest.put(acq5.getIdTask(), priority5);
     *
     * System.out.println("inserting element not ordered : " + priority1);
     * System.out.println("inserting element not ordered : " + priority2);
     * System.out.println("inserting element not ordered : " + priority3 +
     * "\n");
     *
     * List<PriorityQueue> elementsOrderedByPriority =
     * pdhtMng.orderPriorityQueue(downloadPriorityForTest);
     *
     * System.out.println(elementsOrderedByPriority);
     *
     * for (int i = 0; i < elementsOrderedByPriority.size(); i++) {
     * System.out.println("list ordered by priority : " +
     * elementsOrderedByPriority.get(i)+" : "+elementsOrderedByPriority.get(i).
     * getRelatedAcq().getPrType()); }
     *
     * assertEquals(priority4, elementsOrderedByPriority.get(0));
     * assertEquals(priority5, elementsOrderedByPriority.get(1));
     * assertEquals(priority1, elementsOrderedByPriority.get(2));
     * assertEquals(priority2, elementsOrderedByPriority.get(3));
     * assertEquals(priority3, elementsOrderedByPriority.get(4)); }
     *
     *
     * @Test public void testOrderPriorityQueue_differentPRTypes_HPPP() throws
     * Exception { Acquisition acq1 = du.createParametricAcquisition("acq1",
     * "10/10/2017 14:55:00", "10/10/2017 14:56:00", "left", "SAT_1");
     * acq1.setPrType(PRType.PP); acq1.setPriority(2);
     *
     * Acquisition acq2 = du.createParametricAcquisition("acq2",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq2.setPrType(PRType.HP); acq2.setPriority(1);
     *
     * Acquisition acq3 = du.createParametricAcquisition("acq3",
     * "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
     * acq3.setPrType(PRType.VU); acq3.setPriority(3);
     *
     * Acquisition acq4 = du.createParametricAcquisition("acq4",
     * "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
     * acq4.setPrType(PRType.VU); acq4.setPriority(2);
     *
     * Acquisition acq5 = du.createParametricAcquisition("acq5",
     * "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
     * acq5.setPrType(PRType.LMP); acq5.setPriority(8);
     *
     * PriorityQueue priority1 = new PriorityQueue(acq1.getPriority(),
     * Polarization.HH, acq1); PriorityQueue priority2 = new
     * PriorityQueue(acq2.getPriority(), Polarization.HH, acq2); PriorityQueue
     * priority3 = new PriorityQueue(acq3.getPriority(), Polarization.HH, acq3);
     * PriorityQueue priority4 = new PriorityQueue(acq4.getPriority(),
     * Polarization.HH, acq4); PriorityQueue priority5 = new
     * PriorityQueue(acq5.getPriority(), Polarization.HH, acq5);
     *
     * TreeMap<String, PriorityQueue> downloadPriorityForTest = new
     * TreeMap<String, PriorityQueue>();
     *
     * downloadPriorityForTest.put(acq1.getIdTask(), priority1);
     * downloadPriorityForTest.put(acq2.getIdTask(), priority2);
     * downloadPriorityForTest.put(acq3.getIdTask(), priority3);
     * downloadPriorityForTest.put(acq4.getIdTask(), priority4);
     * downloadPriorityForTest.put(acq5.getIdTask(), priority5);
     *
     * System.out.println("inserting element not ordered : " + priority1);
     * System.out.println("inserting element not ordered : " + priority2);
     * System.out.println("inserting element not ordered : " + priority3);
     * System.out.println("inserting element not ordered : " + priority4);
     * System.out.println("inserting element not ordered : " + priority5);
     *
     * List<PriorityQueue> elementsOrderedByPriority =
     * pdhtMng.orderPriorityQueue(downloadPriorityForTest);
     *
     * System.out.println(elementsOrderedByPriority);
     *
     * for (int i = 0; i < elementsOrderedByPriority.size(); i++) {
     * System.out.println("list ordered by priority : " +
     * elementsOrderedByPriority.get(i)); }
     *
     * assertEquals(priority4, elementsOrderedByPriority.get(0));
     * assertEquals(priority3, elementsOrderedByPriority.get(1));
     * assertEquals(priority5, elementsOrderedByPriority.get(2));
     * assertEquals(priority2, elementsOrderedByPriority.get(3));
     * assertEquals(priority1, elementsOrderedByPriority.get(4)); }
     *
     */

    /**
     * Test create new storage DI 2 s.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testCreateNewStorage_DI2s() throws Exception
    {
        int singleSectorDimensionForTest = 4;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setSingleSectorDimension(singleSectorDimensionForTest);

        // String acquisitionRequestId, String dtoId, String
        // programmingRequestId, String programmingRequestListId, String taskId,
        // String ugsId
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.HH);
        acq.setSizeH(200);
        acq.setDi2sAvailable(true);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        String referredEquivalentDto = "equivDtoForTest";
        Di2sInfo di2sInfoForTest = new Di2sInfo();
        di2sInfoForTest.setRelativeMasterId(acq.getIdTask());
        di2sInfoForTest.setPartnerId("slaveDI2s");

        acq.setReferredEquivalentDto(referredEquivalentDto);
        acq.setDi2sInfo(di2sInfoForTest);

        Storage returnedSto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        assertEquals(di2sInfoForTest, returnedSto.getDi2sInfo());
        assertEquals(referredEquivalentDto, returnedSto.getReferredEquivalentDto());
    }

    /**
     * Test create packet stores and decrement memory modules.
     *
     */
    @Test
    public void createPS_and_decrement_memoryModules_Test_H()
    {
        Polarization pol = Polarization.HH;
        List<MemoryModule> memoryModulesName = this.droolsParams.getAllPDHT().get(0).getMMList();
        MemoryModule memoryModuleAssociatedToSto_1 = this.droolsParams.getAllPDHT().get(0).getMMList().get(0);
        MemoryModule memoryModuleAssociatedToSto_2 = this.droolsParams.getAllPDHT().get(0).getMMList().get(3);

        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_1);
        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_2);

        Storage sto = this.du.createStorage("dto1", "10/10/2017 10:00:00", "10/10/2017 10:01:00", "SAT_1", 200, 20, pol);
        sto.setPacketStoreSizeH(200);

        Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<>();
        modulesCapacity.put(memoryModuleAssociatedToSto_1, new PsPolarization(100, pol));
        modulesCapacity.put(memoryModuleAssociatedToSto_2, new PsPolarization(100, pol));

        List<PacketStore> returnedPs = this.pdhtMng.createPS_and_decrement_memoryModules(sto, modulesCapacity, memoryModulesName);
        System.out.println("returned ps : " + returnedPs);
    }

    /**
     * Test create packet stores and decrement memory modules.
     *
     */
    @Test
    public void createPS_and_decrement_memoryModules_Test_HV()
    {
        Polarization pol = Polarization.HV;
        List<MemoryModule> memoryModulesName = this.droolsParams.getAllPDHT().get(0).getMMList();
        MemoryModule memoryModuleAssociatedToSto_1 = this.droolsParams.getAllPDHT().get(0).getMMList().get(0);
        MemoryModule memoryModuleAssociatedToSto_2 = this.droolsParams.getAllPDHT().get(0).getMMList().get(3);

        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_1);
        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_2);

        Storage sto = this.du.createStorage("dto1", "10/10/2017 10:00:00", "10/10/2017 10:01:00", "SAT_1", 200, 20, pol);
        sto.setPacketStoreSizeH(200);
        sto.setPacketStoreSizeV(200);

        Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<>();
        modulesCapacity.put(memoryModuleAssociatedToSto_1, new PsPolarization(100, pol));
        modulesCapacity.put(memoryModuleAssociatedToSto_2, new PsPolarization(100, pol));

        List<PacketStore> returnedPs = this.pdhtMng.createPS_and_decrement_memoryModules(sto, modulesCapacity, memoryModulesName);
        System.out.println("returned ps : " + returnedPs);
    }

    /**
     * Test create packet stores and decrement memory modules.
     *
     */
    @Test
    public void createPS_and_decrement_memoryModules_Test_VH()
    {
        Polarization pol = Polarization.VH;
        List<MemoryModule> memoryModulesName = this.droolsParams.getAllPDHT().get(0).getMMList();
        MemoryModule memoryModuleAssociatedToSto_1 = this.droolsParams.getAllPDHT().get(0).getMMList().get(0);
        MemoryModule memoryModuleAssociatedToSto_2 = this.droolsParams.getAllPDHT().get(0).getMMList().get(3);

        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_1);
        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_2);

        Storage sto = this.du.createStorage("dto1", "10/10/2017 10:00:00", "10/10/2017 10:01:00", "SAT_1", 200, 20, pol);
        sto.setPacketStoreSizeH(200);
        sto.setPacketStoreSizeV(200);

        Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<>();
        modulesCapacity.put(memoryModuleAssociatedToSto_1, new PsPolarization(100, pol));
        modulesCapacity.put(memoryModuleAssociatedToSto_2, new PsPolarization(100, pol));

        List<PacketStore> returnedPs = this.pdhtMng.createPS_and_decrement_memoryModules(sto, modulesCapacity, memoryModulesName);
        System.out.println("returned ps : " + returnedPs);
    }

    /**
     * Test create packet stores and decrement memory modules.
     *
     */
    @Test
    public void createPS_and_decrement_memoryModules_Test_V()
    {
        Polarization pol = Polarization.VV;
        List<MemoryModule> memoryModulesName = this.droolsParams.getAllPDHT().get(0).getMMList();
        MemoryModule memoryModuleAssociatedToSto_1 = this.droolsParams.getAllPDHT().get(0).getMMList().get(0);
        MemoryModule memoryModuleAssociatedToSto_2 = this.droolsParams.getAllPDHT().get(0).getMMList().get(3);

        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_1);
        System.out.println("mem modules chosen : " + memoryModuleAssociatedToSto_2);

        Storage sto = this.du.createStorage("dto1", "10/10/2017 10:00:00", "10/10/2017 10:01:00", "SAT_1", 200, 20, pol);
        sto.setPacketStoreSizeV(200);

        Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<>();
        modulesCapacity.put(memoryModuleAssociatedToSto_1, new PsPolarization(100, pol));
        modulesCapacity.put(memoryModuleAssociatedToSto_2, new PsPolarization(100, pol));

        List<PacketStore> returnedPs = this.pdhtMng.createPS_and_decrement_memoryModules(sto, modulesCapacity, memoryModulesName);
        System.out.println("returned ps : " + returnedPs);
    }

    /**
     * Check if size is valid pol V V size V not filled test.
     */
    @Test
    public void checkIfSizeIsValid_pol_V_H_sizeVNotFilled_Test()
    {
        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq.setPolarization(Polarization.H_V);
        acq.setSizeH(200);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq));

        Acquisition acq2 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq2.setPolarization(Polarization.V_H);
        acq2.setSizeV(200);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq2));

        Acquisition acq3 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:23:00", "10/10/2017 12:24:00", "left", "SAT_1");
        acq3.setPolarization(Polarization.H_H);
        acq3.setSizeV(200);
        assertEquals(false, this.pdhtMng.checkIfSizeIsValid(acq3));
    }

    /**
     * Test insert in priority queue pol HH.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testInsertInPriorityQueue_previouMh_di2s_withSlave() throws Exception
    {
        Date mhStart = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date mhStop = DroolsUtils.createDate("10/10/2017 18:21:00");

        MissionHorizon mh = new MissionHorizon(mhStart, mhStop);
        this.droolsParams.setCurrentMH(mh);
        Logger logger = LoggerFactory.getLogger(DroolsOperations.class);
        DroolsParameters.setLogger(logger);
        DTO slaveDto = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        slaveDto.setSizeH(20);
        slaveDto.setSizeV(0);

        System.out.println(this.droolsParams.getAllPartners());
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        Di2sInfo di2sInfo = new Di2sInfo("slaveid", "masterId", "ugsId");
        di2sInfo.setSlaveDto(slaveDto);
        acq1.setDi2sInfo(di2sInfo);
        acq1.setSizeH(20);
        acq1.setSizeV(0);

        UserInfo user1 = new UserInfo();
        user1.setAcquisitionStationIdList(null);
        user1.setOwnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        user1.setSubscriber(false);
        user1.setUgsId("ugsId1");

        UserInfo user2 = new UserInfo();
        user2.setAcquisitionStationIdList(null);
        user2.setOwnerId(this.droolsParams.getAllPartners().get(2).getPartnerId());
        user2.setSubscriber(false);
        user2.setUgsId("ugsId2");

        List<UserInfo> userInfoAssoc = new ArrayList<>(Arrays.asList(user1, user2));

        acq1.setUserInfo(userInfoAssoc);
        acq1.setPolarization(Polarization.HH);
        acq1.setPriority(2);
        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acq1, this.droolsParams);
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();
        PriorityQueue priority = this.pdhtMng.insertInPriorityQueue(acq1,  stoAssociatedToAcq, downloadPriority, this.droolsParams);
        System.out.println(priority); }

    /**
     * Test insert in priority queue pol HH.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testInsertInPriorityQueue_previouMh_di2s_withoutSlave() throws Exception
    {
        Date mhStart = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date mhStop = DroolsUtils.createDate("10/10/2017 18:21:00");

        MissionHorizon mh = new MissionHorizon(mhStart, mhStop);
        this.droolsParams.setCurrentMH(mh);

        Logger logger = LoggerFactory.getLogger(DroolsOperations.class);
        DroolsParameters.setLogger(logger);
        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        Di2sInfo di2sInfo = new Di2sInfo("slaveid", "masterId", "ugsId");
        di2sInfo.setPartnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        di2sInfo.setSlaveDto(null);
        acq1.setDi2sInfo(di2sInfo);
        acq1.setSizeH(20);
        acq1.setSizeV(0);

        UserInfo user1 = new UserInfo();
        user1.setAcquisitionStationIdList(null);
        user1.setOwnerId(this.droolsParams.getAllPartners().get(1).getPartnerId());
        user1.setSubscriber(false);
        user1.setUgsId("ugsId1");

        UserInfo user2 = new UserInfo();
        user2.setAcquisitionStationIdList(null);
        user2.setOwnerId(this.droolsParams.getAllPartners().get(2).getPartnerId());
        user2.setSubscriber(false);
        user2.setUgsId("ugsId2");

        List<UserInfo> userInfoAssoc = new ArrayList<>(Arrays.asList(user1, user2));

        acq1.setUserInfo(userInfoAssoc);
        acq1.setPolarization(Polarization.HH);
        acq1.setPriority(2);
        Storage stoAssociatedToAcq = this.pdhtMng.createNewStorage(acq1, this.droolsParams);
        TreeMap<String, PriorityQueue> downloadPriority = new TreeMap<>();
        PriorityQueue priority = this.pdhtMng.insertInPriorityQueue(acq1,  stoAssociatedToAcq, downloadPriority, this.droolsParams);
        System.out.println(priority);  }

    @Test
    public void testCheckPdhtOverload() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto1.setPol(Polarization.VH);
        dto1.setSizeH(2000);
        dto1.setSizeV(2000);
        assertTrue(this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession));
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        System.out.println(allTasks);

        TreeMap<String, Storage> allSto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println(allSto);

        List<Download> allDwl = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println(allDwl);

        List<Task> allStoAndDwl = new ArrayList<>();
        for (Map.Entry<String, Storage> allStoMap : allSto.entrySet())
        {
            allStoAndDwl.add(allStoMap.getValue());
        }
        allStoAndDwl.addAll(allDwl);

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, ComplexPdht> pdhtFunction = resourceFunctions.getPDHTFunctionAssociatedToSat("SAT_1");
        TreeMap<String, Storage> allProcessedSto = resourceFunctions.getStoragesAssociatedToSat("SAT_1");

        long timeOfOverheadPdht = this.pdhtMng.checkPdhtOverload(allStoAndDwl, pdhtFunction, this.droolsParams, allProcessedSto);
        assertEquals(-1, timeOfOverheadPdht);

    }

    @Test
    public void testCheckPdhtOverload_overload() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto1.setPol(Polarization.VH);
        dto1.setSizeH(2000);
        dto1.setSizeV(2000);
        assertTrue(this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession));
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        System.out.println(allTasks);

        TreeMap<String, Storage> allSto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println(allSto);

        List<Download> allDwl = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println(allDwl);

        List<Task> allStoAndDwl = new ArrayList<>();
        for (Map.Entry<String, Storage> allStoMap : allSto.entrySet())
        {
            allStoAndDwl.add(allStoMap.getValue());
        }
        allStoAndDwl.addAll(allDwl);

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, ComplexPdht> pdhtFunction = resourceFunctions.getPDHTFunctionAssociatedToSat("SAT_1");
        pdhtFunction.clear();

        PDHT pdhtForTest = new PDHT("pdhtId", "pdhName", "SAT_1", 0, null);
        pdhtForTest.setFreeMemory(0);
        pdhtForTest.setCapacity(null);
        TreeMap<String, Storage> allProcessedSto = resourceFunctions.getStoragesAssociatedToSat("SAT_1");

        ComplexPdht complexPdtForTest = new ComplexPdht(pdhtForTest);
        pdhtFunction.put(this.droolsParams.getCurrentMH().getStart().getTime(), complexPdtForTest);
        long timeOfOverheadPdht = this.pdhtMng.checkPdhtOverload(allStoAndDwl, pdhtFunction, this.droolsParams, allProcessedSto);

        System.out.println(timeOfOverheadPdht);

       Storage sto = allProcessedSto.get(dto1.getDtoId());
        assertEquals(sto.getStartTime().getTime(), timeOfOverheadPdht);

    }

    @Test
    public void testCheckPdhtOverload_prevProc() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(2000);
        dto1.setSizeV(0);
        dto1.setPreviousMh(false);
        assertTrue(this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession));
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        System.out.println(allTasks);

        TreeMap<String, Storage> allSto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println(allSto);

        List<Download> allDwl = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println(allDwl);

        List<Task> allStoAndDwl = new ArrayList<>();
        for (Map.Entry<String, Storage> allStoMap : allSto.entrySet())
        {
            allStoAndDwl.add(allStoMap.getValue());
        }
        allStoAndDwl.addAll(allDwl);

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, ComplexPdht> pdhtFunction = resourceFunctions.getPDHTFunctionAssociatedToSat("SAT_1");
        TreeMap<String, Storage> allProcessedSto = resourceFunctions.getStoragesAssociatedToSat("SAT_1");

        long timeOfOverheadPdht = this.pdhtMng.checkPdhtOverload(allStoAndDwl, pdhtFunction, this.droolsParams, allProcessedSto);
        assertEquals(-1, timeOfOverheadPdht);
        timeOfOverheadPdht = this.pdhtMng.checkPdhtOverload(allStoAndDwl, pdhtFunction, this.droolsParams, allProcessedSto);

    }

    /**
     * Test insert sto in PDHT.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void insertStoInPDHT_VH() throws Exception
    {
        System.out.println("Running Test : insertStoInPDHT_no_space_Test \n\n");

        // create a mission horizon
        MissionHorizon mh = this.stub.createMH("10/10/2017 10:00:00", "10/10/2017 18:00:00");

        // setUp drools environment
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        TreeMap<Long, ComplexPdht> PDHTFunction = new TreeMap<>();
        long freeMemoryForTest = 600;
        PDHT previousPDHT = new PDHT("pdhtId", "PDHT1", "SAT_1", freeMemoryForTest, null);
        System.out.println("pdht : " + previousPDHT);
        PDHTFunction.put(mh.getStart().getTime(), new ComplexPdht(previousPDHT));
        Acquisition acq = this.du.createParametricAcquisition("acq1", "10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        acq.setPolarization(Polarization.V_H);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        acq.setUserInfo(userInfoList);

        double durationInSec = (acq.getEndTime().getTime() - acq.getStartTime().getTime()) / 1000;
        System.out.println("acq duration : " + durationInSec);
        int imgSize = (int) (durationInSec * (this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getWizardLinkDataRate() / 8));
        System.out.println("image size : " + imgSize);
        acq.setSizeH(imgSize);
        acq.setSizeV(imgSize);

        acq.setPolarization(Polarization.V_H);
        Storage sto = this.pdhtMng.createNewStorage(acq, this.droolsParams);

        System.out.println("storage associated : " + sto);
        boolean insertedInPdht = this.pdhtMng.insertStoInPDHT(PDHTFunction, sto);
        System.out.println("inserted : " + insertedInPdht);
        System.out.println("PDHT function ");
        for (Map.Entry<Long, ComplexPdht> elementsInMap : PDHTFunction.entrySet())
        {
            System.out.println("date : " + new Date(elementsInMap.getKey()));
            System.out.println(" value PDHT : " + elementsInMap.getValue());
        }
        assertFalse(insertedInPdht);
    }

    @Test
    public void testRemoveAcqNoSpacePdht() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(1, acqFunction.size());

        // pdhtMng.removeAcqNoSpacePdht(currentAcq, droolsParams,
        // currentSession, currentInstance, rejectedElements, hashMapEss);
    }

    @Test
    public void testCreateNewPriorityQueueElement_HH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(100);
        dto1.setSizeV(0);

        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);    
        
        Acquisition relatedAcq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),this.sessionId, this.currentKieSession);
        DroolsQueries dq = new DroolsQueries();
        TreeMap<String, Storage>  allStorages = resourceFunctions.getStoragesAssociatedToSat(dto1.getSatelliteId());
        Storage relatedSto = dq.getStoWithGivenid(allStorages, dto1.getDtoId());
        
        PdhtManagement dwlMng = new PdhtManagement();
        PriorityQueue  newElement = dwlMng.createNewPriorityQueueElement(relatedAcq, droolsParams, relatedSto);
        
        System.out.println("relatedAcq "+relatedAcq);
        System.out.println("relatedSto "+relatedSto);

        System.out.println("PriorityQueue "+newElement);
        System.out.println(newElement.getSectorsNeededForPartners().get("Partner_1"));
        assertEquals(1,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().size());
        assertEquals(Polarization.HH,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getPol());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getEffectiveSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getResidualSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getTotalSize());

    }

    @Test
    public void testCreateNewPriorityQueueElement_HH_HH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPol(Polarization.HH_HH);
        dto1.setSizeH(100);
        dto1.setSizeV(0);

        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);    
        
        Acquisition relatedAcq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),this.sessionId, this.currentKieSession);
        DroolsQueries dq = new DroolsQueries();
        TreeMap<String, Storage>  allStorages = resourceFunctions.getStoragesAssociatedToSat(dto1.getSatelliteId());
        Storage relatedSto = dq.getStoWithGivenid(allStorages, dto1.getDtoId());
        
        PdhtManagement dwlMng = new PdhtManagement();
        PriorityQueue  newElement = dwlMng.createNewPriorityQueueElement(relatedAcq, droolsParams, relatedSto);
        
        System.out.println("relatedAcq "+relatedAcq);
        System.out.println("relatedSto "+relatedSto);

        System.out.println("PriorityQueue "+newElement);
        System.out.println(newElement.getSectorsNeededForPartners().get("Partner_1"));
        assertEquals(1,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().size());
        assertEquals(Polarization.HH,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getPol());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getEffectiveSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getResidualSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getTotalSize());



    }
    
    @Test
    public void testCreateNewPriorityQueueElement_HH_VV_1() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPol(Polarization.HH_VV);
        dto1.setSizeH(100);
        dto1.setSizeV(50);

        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);    
        
        Acquisition relatedAcq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),this.sessionId, this.currentKieSession);
        DroolsQueries dq = new DroolsQueries();
        TreeMap<String, Storage>  allStorages = resourceFunctions.getStoragesAssociatedToSat(dto1.getSatelliteId());
        Storage relatedSto = dq.getStoWithGivenid(allStorages, dto1.getDtoId());
        
        PdhtManagement dwlMng = new PdhtManagement();
        PriorityQueue  newElement = dwlMng.createNewPriorityQueueElement(relatedAcq, droolsParams, relatedSto);
        
        System.out.println("relatedAcq "+relatedAcq);
        System.out.println("relatedSto "+relatedSto);

        System.out.println("PriorityQueue "+newElement);
        System.out.println(newElement.getSectorsNeededForPartners().get("Partner_1"));
        assertEquals(2,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().size());
        assertEquals(Polarization.HH,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getPol());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getEffectiveSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getResidualSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getTotalSize());

        assertEquals(Polarization.VV,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getPol());
        assertEquals(50,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getEffectiveSize());
        assertEquals(50,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getResidualSize());
        assertEquals(50,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getTotalSize());



    }
    
    @Test
    public void testCreateNewPriorityQueueElement_HH_VV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPol(Polarization.HV_VH);
        dto1.setSizeH(100);
        dto1.setSizeV(50);

        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);    
        
        Acquisition relatedAcq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(),this.sessionId, this.currentKieSession);
        DroolsQueries dq = new DroolsQueries();
        TreeMap<String, Storage>  allStorages = resourceFunctions.getStoragesAssociatedToSat(dto1.getSatelliteId());
        Storage relatedSto = dq.getStoWithGivenid(allStorages, dto1.getDtoId());
        
        PdhtManagement dwlMng = new PdhtManagement();
        PriorityQueue  newElement = dwlMng.createNewPriorityQueueElement(relatedAcq, droolsParams, relatedSto);
        
        System.out.println("relatedAcq "+relatedAcq);
        System.out.println("relatedSto "+relatedSto);

        System.out.println("PriorityQueue "+newElement);
        System.out.println(newElement.getSectorsNeededForPartners().get("Partner_1"));
        assertEquals(2,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().size());
        assertEquals(Polarization.HH,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getPol());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getEffectiveSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getResidualSize());
        assertEquals(100,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(0).getTotalSize());

        assertEquals(Polarization.VV,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getPol());
        assertEquals(50,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getEffectiveSize());
        assertEquals(50,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getResidualSize());
        assertEquals(50,newElement.getSectorsNeededForPartners().get("Partner_1").getSectorsForPartner().get(1).getTotalSize());



    }
}
