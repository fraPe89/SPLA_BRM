
package com.nais.spla.brm.library.main.drools.utils;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;

public class TaskPlannedTest
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    private StubResources stub = new StubResources();

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    private TaskPlanned taskPlanned = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestTaskPlannedTEst";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.taskPlanned = new TaskPlanned();
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testReceiveAllDownloads() throws Exception
    {
        String satId = "SAT_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, satId);

    }

    @Test
    public void testReceiveAllStoreAux() throws Exception
    {
        String satId = "Sat_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.taskPlanned.receiveAllStoreAux(this.sessionId, this.currentKieSession, this.droolsParams, satId);
    }

    @Test
    public void testReceiveAllManeuvers() throws Exception
    {
        String satId = "Sat_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, satId);
    }

    @Test
    public void testReceiveAllRamps() throws Exception
    {
        String satId = "Sat_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, satId);
    }

    @Test
    public void testGetAllPawOverlapInterval() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 12:26:00", "10/10/2017 12:43:00", PAWType.GENERIC);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.GENERIC);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1, paw2, paw3, paw4));

        this.droolsParams.setAllPAWS(allPaws);
        System.out.println("\n\n Running test : testGetAllPawOverlapInterval");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Date startCheck = DroolsUtils.createDate("10/10/2017 12:30:00");
        Date endCheck = DroolsUtils.createDate("10/10/2017 15:41:00");

        String satelliteId = "SAT_1";
        List<PAW> allPAWInOverlap = this.taskPlanned.getAllPawOverlapInterval(this.droolsParams, startCheck, endCheck, satelliteId);

        System.out.println("all paw in overlap : " + allPAWInOverlap);
        assertEquals(2, allPAWInOverlap.size());
    }

    @Test
    public void testGetAllVisOverlapInterval() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.setNumberOfSessions(2);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Visibility vis = this.stub.createVisibility(2, satelliteId, satelliteId, satelliteId, "10/10/2017 08:55:00", "10/10/2017 09:15:00");
        vis.setSatelliteId(satelliteId);
        this.droolsParams.getAllVisibilities().add(vis);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(vis);

        List<Visibility> allVis = this.taskPlanned.getAllVisOverlapInterval(this.droolsParams, this.droolsParams.getCurrentMH().getStart(), this.droolsParams.getCurrentMH().getStop(), satelliteId);
        assertEquals(1, allVis.size());
        assertEquals(vis, allVis.get(0));
    }

    @Test
    public void testReceiveAllSilent() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Silent sil = this.du.createSilent("10/10/2017 08:55:00", "10/10/2017 08:55:05", "acq1", 2);
        sil.setSatelliteId(satelliteId);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(sil);

        List<Silent> allSilents = this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);
        assertEquals(1, allSilents.size());
        assertEquals(sil, allSilents.get(0));
    }

    @Test
    public void testReceiveAllAcquisitionsAsMap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        String satelliteId = "SAT_1";

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 08:55:00", "10/10/2017 08:55:00", "right", satelliteId);
        acq.setSatelliteId(satelliteId);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(acq);

        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);
        assertEquals(1, allAcq.size());
        assertEquals(acq, allAcq.get(acq.getIdTask()));
    }

    @Test
    public void testReceiveAllCmgAxisForSat() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        String satelliteId = "SAT_1";

        Acquisition acq = this.du.createParametricAcquisition("dto1", "10/10/2017 08:55:00", "10/10/2017 08:55:00", "right", satelliteId);
        acq.setSatelliteId(satelliteId);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        Date startTime = DroolsUtils.createDate("10/10/2017 18:00:00");
        Date endTime = DroolsUtils.createDate("10/10/2017 18:00:00");
        boolean rollToPitch = false;

        CMGAxis cmgAxis = new CMGAxis(startTime, endTime);
        cmgAxis.setRollToPitch(rollToPitch);
        cmgAxis.setSatelliteId(satelliteId);

        kie.insert(cmgAxis);

        List<CMGAxis> allCmgAxis = this.taskPlanned.receiveAllCmgAxisForSat(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);
        assertEquals(1, allCmgAxis.size());
    }

}
