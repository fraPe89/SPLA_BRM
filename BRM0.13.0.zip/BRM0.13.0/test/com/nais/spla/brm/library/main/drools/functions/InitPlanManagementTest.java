
package com.nais.spla.brm.library.main.drools.functions;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class InitPlanManagementTest
{

    @Before
    public void setUp() throws Exception
    {
    }

    @After
    public void tearDown() throws Exception
    {
    }

    @Test
    public void testRemovingAcquisitions() throws Exception
    {

    }

}
