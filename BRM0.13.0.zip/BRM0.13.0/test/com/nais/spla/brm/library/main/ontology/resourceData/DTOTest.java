
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;

public class DTOTest
{

    DroolsUtils du = new DroolsUtils();

    @Test
    public void testDTO() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 11:00:00");
        Date endTime = DroolsUtils.createDate("10/10/2017 11:05:00");

        DTO dto1 = new DTO("100_PR-ITA-001-HP_AR-001_DTO-2", startTime, endTime, "left", "SAT_1", TypeOfAcquisition.PINGPONG, Polarization.HH);
        dto1.setTaskMark(TaskMarkType.CONFIRMED);
        dto1.setSatelliteId("SAT_2");
        dto1.setRejected(true);
        dto1.setPreviousMh(true);
        assertTrue(dto1.isRejected());
        assertTrue(dto1.isPreviousMh());
        assertEquals(TaskMarkType.CONFIRMED, dto1.getTaskMark());
        assertEquals(startTime, dto1.getStartTime());

        dto1.setInterleavedChannel(1);
        dto1.setArID("arIdTest");
        assertTrue(dto1.getArID().compareTo("arIdTest") == 0);
        dto1.setReasonOfReject(ReasonOfReject.bicNotAvailable);
        assertTrue(dto1.getReasonOfReject().compareTo(ReasonOfReject.bicNotAvailable) == 0);

        List<String> preferredVis = new ArrayList<>(Arrays.asList("vis1", "vis2"));
        dto1.setPreferredVis(preferredVis);
        dto1.setLookSide("left");

        DTO dto2 = new DTO();
        dto2 = dto1;
        dto2.setStartTime(startTime);
        assertEquals(dto1.toString(), dto2.toString());
        assertEquals(preferredVis, dto1.getPreferredVis());
    }

}
