
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BicHpPeakOrbitTest
{

    @Test
    public void testPeakOrbit() throws Exception
    {
        String type = "typeTest";
        double bicHp = 5;
        String acqId = "testId";
        BicHpPeakOrbit bicPeak = new BicHpPeakOrbit(type, bicHp, acqId);
        assertEquals(type, bicPeak.getType());
        assertEquals(bicHp, bicPeak.getBicHp(), 0);
        assertEquals(acqId, bicPeak.getAcqId());

    }

}
