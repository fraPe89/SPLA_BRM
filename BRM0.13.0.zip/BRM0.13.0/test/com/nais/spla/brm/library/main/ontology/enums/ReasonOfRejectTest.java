
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * The Class ReasonOfRejectTest.
 */
public class ReasonOfRejectTest
{

    /**
     * Test enum reason of reject.
     */
    @Test
    public void testEnumReasonOfReject()
    {
        List<ReasonOfReject> allReasonOfRejectForTest = new ArrayList<>();
        ReasonOfReject[] allManeuverType = ReasonOfReject.values();
        for (int i = 0; i < allManeuverType.length; i++)
        {
            allReasonOfRejectForTest.add(allManeuverType[i]);
        }

        ReasonOfReject type;
        type = ReasonOfReject.valueOf("CMGFormulaViolation");
        System.out.println("Selected : " + type);

        assertEquals(ReasonOfReject.values().length, allReasonOfRejectForTest.size());
    }

}
