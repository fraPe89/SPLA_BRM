
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.rules.DtoToAcqRule;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ConfigMaps;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class DroolsOperationsTest.
 */
public class DroolsOperationsTest
{

    /** The session id. */
    private String sessionId = null;

    /** The rejected elements. */
    private Map<String, Acquisition> rejectedElements = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools operations. */
    private DroolsOperations droolsOperations = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    private TaskPlanned taskPlanned = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestDroolsOperations";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        this.taskPlanned = new TaskPlanned();
        double extraCostLeft = 10;
        this.droolsOperations = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Test insert dto.
     */
    @Test
    public void testInsertDto() throws Exception
    {
        System.out.println("\n\n Running test : testInsertDto");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        DTO dto = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("inserted a new DTO : " + dto);
        List<Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        assertEquals(dto.getDtoId(), allAcq.get(0).getId());
    }

    /**
     * Test insert dto incorrect session.
     */
    @Test(expected = java.lang.AssertionError.class)
    public void testInsertDtoIncorrectSession() throws Exception
    {
        System.out.println("\n\n Running test : testInsertDtoIncorrectSession");
        int fakeKieSession = 65;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        DTO dto = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto, this.sessionId, fakeKieSession);
        assertFalse(accepted);
    }

    /**
     * Test set get cont dto.
     */
    @Test
    public void testSetGetContDto()
    {
        int cont = 2;
        DroolsOperations.setContDto(cont);
        assertEquals(cont, DroolsOperations.getContDto());
    }

    /**
     * Test close session.
     */
    @Test
    public void testCloseSession() throws Exception
    {
        System.out.println("\n\n Running test : testCloseSession");
        /*
         * create a new instance for two different session, and after then close
         * both
         */
        int sessionToClose = 1;
        int fakeSessionToClose = 13;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // there isn't an opened session with this identifier
        System.out.println("trying to close a session that not exist");
        this.droolsOperations.closeSession(this.sessionId, fakeSessionToClose);

        // the session will be correctly close
        System.out.println("trying to close an existing session");
        this.droolsOperations.closeSession(this.sessionId, sessionToClose);
    }

    /**
     * Clear session test.
     *
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void clearSessionTest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test O_initialAndFinalMan");
        System.out.println(" mission horizon : " + this.droolsParams.getCurrentMH());

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/09/2017 09:42:00", "10/09/2017 09:43:00", "left", "SAT_1");
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejectedElement BEFORE " + this.rejectedElements);
        assertEquals(1, this.rejectedElements.size());

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("resource function : " + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        System.out.println("resource function : " + resFunc.getAllManeuversSat1());
        System.out.println("resource function : " + resFunc.getPDHTFunctionAssociatedToSat("SAT_1"));
        Map<String, Task> taskMap = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elementsInMap : taskMap.entrySet())
        {
            System.out.println(elementsInMap.getKey());
            System.out.println(elementsInMap.getValue());
        }

        // clear the session
        boolean clearAlsoTheRejectedElemenets = true;
        this.droolsOperations.clearSessionInstance(this.sessionId, this.currentKieSession, this.droolsParams, clearAlsoTheRejectedElemenets);

        // get all elements after the clear of the session
        resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("resource function : " + resFunc.toString());
        System.out.println("resource function : " + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        System.out.println("resource function : " + resFunc.getAllManeuversSat1());
        System.out.println("resource function : " + resFunc.getPDHTFunctionAssociatedToSat("SAT_1"));

        taskMap = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        boolean containsTasks = this.du.containsValidTasks(taskMap);
        assertEquals(false, containsTasks);

        System.out.println("all tasks after clear");
        for (Map.Entry<String, Task> elementsInMap : taskMap.entrySet())
        {
            System.out.println(elementsInMap.getKey());
            System.out.println(elementsInMap.getValue());
        }

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejectedElement " + rejectedElements);

        assertEquals(1, rejectedElements.size());
        System.out.println("done");
    }

    /**
     * Clear session test wihout clear rejected elements.
     *
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void clearSessionTest_wihout_clear_rejected_elements() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test O_initialAndFinalMan");
        System.out.println(" mission horizon : " + this.droolsParams.getCurrentMH());

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/09/2017 09:42:00", "10/09/2017 09:43:00", "left", "SAT_1");
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejectedElement BEFORE " + this.rejectedElements);
        assertEquals(1, this.rejectedElements.size());
        boolean containsExpectedReason = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.outsideMHDTO);
        assertEquals(true, containsExpectedReason);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("resource function : " + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        System.out.println("resource function : " + resFunc.getAllManeuversSat1());
        System.out.println("resource function : " + resFunc.getPDHTFunctionAssociatedToSat("SAT_1"));
        Map<String, Task> taskMap = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elementsInMap : taskMap.entrySet())
        {
            System.out.println(elementsInMap.getKey());
            System.out.println(elementsInMap.getValue());
        }

        // clear the session
        boolean clearAlsoTheRejectedElemenets = false;
        this.droolsOperations.clearSessionInstance(this.sessionId, this.currentKieSession, this.droolsParams, clearAlsoTheRejectedElemenets);

        // get all elements after the clear of the session
        resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("resource function : " + resFunc.toString());
        System.out.println("resource function : " + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        System.out.println("resource function : " + resFunc.getAllManeuversSat1());
        System.out.println("resource function : " + resFunc.getPDHTFunctionAssociatedToSat("SAT_1"));

        taskMap = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("task map :" + taskMap);
        boolean containsTasks = this.du.containsValidTasks(taskMap);
        assertEquals(false, containsTasks);

        System.out.println("all tasks after clear");
        for (Map.Entry<String, Task> elementsInMap : taskMap.entrySet())
        {
            System.out.println(elementsInMap.getKey());
            System.out.println(elementsInMap.getValue());
        }

        assertEquals(2, this.rejectedElements.size());
        System.out.println("done");

    }

    /**
     * Test get global.
     */
    @Test
    public void testGetGlobal() throws Exception
    {
        System.out.println("\n\n Running test : testGetGlobal");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        MissionHorizon mh = (MissionHorizon) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "currentMH");
        assertTrue(mh != null);
        System.out.println("receiving global variable -> mission horizon : " + mh);
    }

    @Test(expected = NullPointerException.class)
    public void testGetGlobal_invalidSession() throws Exception
    {
        System.out.println("\n\n Running test : testGetGlobal_invalidSession");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        int fakeSession = 25;

        MissionHorizon mh = null;
        mh = (MissionHorizon) this.droolsOperations.getGlobal(this.sessionId, fakeSession, "currentMH");
        assertTrue(mh == null);
        System.out.println("receiving global variable -> mission horizon : " + mh);
    }

    /**
     * Test get PDHT status.
     */
    @Test
    public void testGetPDHTStatus() throws Exception
    {
        System.out.println("\n\n Running test : testGetPDHTStatus");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // receiving initial state of pdht related of satellites
        PDHT pdhtSat1AtStart = this.droolsParams.getAllPDHT().get(0);
        PDHT pdhtSat2AtStart = this.droolsParams.getAllPDHT().get(1);

        /*
         * the pdht are ordered temporally and stored into a treeMap, one for
         * each satellite. When Drools is started, at mission horizon start
         * time, into the treeMap is stored the initial pdht.
         */

        MissionHorizon mh = (MissionHorizon) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "currentMH");

        PDHT pdhtFromDroolsForSat1 = this.droolsOperations.getPDHTStatus(mh.getStart(), pdhtSat1AtStart.getSatelliteId(), this.sessionId, this.currentKieSession);
        PDHT pdhtFromDroolsForSat2 = this.droolsOperations.getPDHTStatus(mh.getStart(), pdhtSat2AtStart.getSatelliteId(), this.sessionId, this.currentKieSession);
        System.out.println("eceived pdht for sat 1 :" + pdhtFromDroolsForSat1);
        System.out.println("eceived pdht for sat 2 :" + pdhtFromDroolsForSat2);
        assertEquals(pdhtSat1AtStart, pdhtFromDroolsForSat1);
        assertEquals(pdhtSat2AtStart, pdhtFromDroolsForSat2);

        Date startTimeBeforeMh = DroolsUtils.createDate("10/10/2017 06:20:00");
        PDHT invalidPdhtStatus = this.droolsOperations.getPDHTStatus(startTimeBeforeMh, pdhtSat1AtStart.getSatelliteId(), this.sessionId, this.currentKieSession);
        assertEquals(null, invalidPdhtStatus);
    }

    /**
     * Test receive dto accepted.
     */
    @Test
    public void testReceiveDtoAccepted() throws Exception
    {
        System.out.println("\n\n Running test : testReceiveDtoAccepted");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // create a dto and insert it into Drools
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto1);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> acceptedElements = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("all accepted elements : " + acceptedElements);
        assertTrue(acceptedElements.size() > 0);

        Map<String, Acquisition> rejected = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("all rejected elements : " + rejected);
        assertTrue(rejected.size() == 0);
    }

    /**
     * Test init plan.
     */
    @Test
    public void testInitPlan() throws Exception
    {
        System.out.println("\n\n Running test : testInitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // create a dto and insert it into Drools
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto1);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // create another one dto and insert it into Drools
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto2);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        System.out.println(this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));
        assertTrue(accepted);

        List<Task> allTaskAcceptedBeforeInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("ALL TASKS BEFORE INIT PREVIOUS PLAN");
        for (int i = 0; i < allTaskAcceptedBeforeInitPlan.size(); i++)
        {
            System.out.println("task : " + allTaskAcceptedBeforeInitPlan.get(i));
        }
        int sizeBefore = allTaskAcceptedBeforeInitPlan.size();
        System.out.println("before " + sizeBefore);
        this.droolsOperations.initPlan(this.droolsParams, allTaskAcceptedBeforeInitPlan, null, this.sessionId, this.currentKieSession, true);
        List<Task> allTaskAcceptedAfterInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        int sizeAfter = allTaskAcceptedAfterInitPlan.size();
        System.out.println("after" + sizeAfter);
        System.out.println("\n\n ALL TASKS AFTER INIT PREVIOUS PLAN");
        for (int i = 0; i < allTaskAcceptedAfterInitPlan.size(); i++)
        {
            System.out.println("task : " + allTaskAcceptedAfterInitPlan.get(i));
        }

        assertEquals(sizeAfter, sizeBefore);
    }
    
    /**
     * Test init plan.
     */
    @Test
    public void testInitPlanEquivalentDTO() throws Exception
    {
        System.out.println("\n\n Running test : testInitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_2");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", "SAT_2");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", "SAT_2");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", "SAT_2", Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        // create another one dto and insert it into Drools
        DTO dto4 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto4);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        System.out.println(this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));
        assertTrue(accepted);

        List<Task> allTaskAcceptedBeforeInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("ALL TASKS BEFORE INIT PREVIOUS PLAN");
        for (int i = 0; i < allTaskAcceptedBeforeInitPlan.size(); i++)
        {
            System.out.println("task : " + allTaskAcceptedBeforeInitPlan.get(i));
        }
        int sizeBefore = allTaskAcceptedBeforeInitPlan.size();
        System.out.println("before " + sizeBefore);
        this.droolsOperations.initPlan(this.droolsParams, allTaskAcceptedBeforeInitPlan, new ArrayList<EquivalentDTO>(Arrays.asList(equivDto)), this.sessionId, this.currentKieSession, true);
        List<Task> allTaskAcceptedAfterInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        int sizeAfter = allTaskAcceptedAfterInitPlan.size();
        System.out.println("after" + sizeAfter);
        System.out.println("\n\n ALL TASKS AFTER INIT PREVIOUS PLAN");
        for (int i = 0; i < allTaskAcceptedAfterInitPlan.size(); i++)
        {
            System.out.println("task : " + allTaskAcceptedAfterInitPlan.get(i));
        }

        assertEquals(sizeAfter, sizeBefore);
    }
    
    @Test(expected= java.lang.NullPointerException.class)
    public void testInitPlanWrongSession() throws Exception
    {
        System.out.println("\n\n Running test : testInitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", "SAT_2");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", "SAT_2");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", "SAT_2");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", "SAT_2", Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        // create another one dto and insert it into Drools
        DTO dto4 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto4);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        System.out.println(this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));
        assertTrue(accepted);

        List<Task> allTaskAcceptedBeforeInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("ALL TASKS BEFORE INIT PREVIOUS PLAN");
        for (int i = 0; i < allTaskAcceptedBeforeInitPlan.size(); i++)
        {
            System.out.println("task : " + allTaskAcceptedBeforeInitPlan.get(i));
        }
        int sizeBefore = allTaskAcceptedBeforeInitPlan.size();
        System.out.println("before " + sizeBefore);
        
        DroolsQueries dq = new DroolsQueries();
        Map<String, Acquisition> allAcq = dq.getAllAcceptedAcq(this.sessionId, this.currentKieSession);
        this.sessionId = "error";
        this.droolsOperations.initPlan(this.droolsParams, allTaskAcceptedBeforeInitPlan, new ArrayList<EquivalentDTO>(Arrays.asList(equivDto)), this.sessionId, this.currentKieSession, true);
        List<Task> allTaskAcceptedAfterInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        int sizeAfter = allTaskAcceptedAfterInitPlan.size();
        System.out.println("after" + sizeAfter);
        System.out.println("\n\n ALL TASKS AFTER INIT PREVIOUS PLAN");
        for (int i = 0; i < allTaskAcceptedAfterInitPlan.size(); i++)
        {
            System.out.println("task : " + allTaskAcceptedAfterInitPlan.get(i));
        }

        assertEquals(sizeAfter, sizeBefore);
    }
    
    
	@Test
	public void testPriority() {
		TreeMap<String, Integer> priority = new TreeMap<>();
		String p1 = "0_2_0000000015_61";
		String p2 = "-1_2_0000000015_61";
		String p3 = "0_2_0000000011_61";
		String p4 = "3_2_0000000015_61";
		String p5 = "2_2_0000000015_62";
		priority.put(p1, 0);
		priority.put(p2, 1);
		priority.put(p3, 2);
		priority.put(p1, 3);
		priority.put(p4, 4);
		priority.put(p5, 5);

		System.out.println(priority);

	}

	@Test
	public void processDownloadsFromPrevSession() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
		StubResources stub = new StubResources();
		Partner p1 = this.droolsParams.getAllPartners().get(0);
		Partner p2 = this.droolsParams.getAllPartners().get(1);

		this.droolsParams.getAllVisibilities().clear();
		Visibility vis1 = stub.createVisibility(0, "SAT_2", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00",
				"10/10/2017 11:16:00");
		Visibility vis2 = stub.createVisibility(1, "SAT_2", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00",
				"10/10/2017 18:32:00");
		Visibility vis3 = stub.createVisibility(2, "SAT_2", "MAT", null, "10/10/2017 18:00:00",
				"10/10/2017 18:50:00");
		List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
		List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

		this.droolsParams.setAllVisibilities(allVis);
		this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
		this.droolsParams.getHpExclusionList().clear();

		this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsOperations, this.currentKieSession, "_");

		this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
		this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

		this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

		this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsOperations, this.currentKieSession, "_");
		System.out.println("\n\n I'm running test downloadTest");

		DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_2");
		dto1.setPol(Polarization.HH);
		dto1.setSizeH(1000);
		dto1.setSizeV(0);

		dto1.setPreferredVis(allVisId);
		List<UserInfo> userInfoList = new ArrayList<>();
		UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
		// UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
		// p2.getUgsId());
		userInfoList.add(userInfo1);
		// userInfoList.add(userInfo2);
		dto1.setUserInfo(userInfoList);

		boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId,
				this.currentKieSession);
		assertTrue(accepted);
		List<Download> allDwlForAcq = this.droolsOperations.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(),
				this.sessionId, this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_2");
		dto2.setPol(Polarization.V_H);
		dto2.setSizeH(4000);
		dto2.setSizeV(1900);

		dto2.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto2.setUserInfo(userInfoList);

		accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
		assertTrue(accepted);

		Map<String, Task> allTasks = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		allTasks = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsOperations.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(2, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.RETAIN, allDwlForAcq.get(0).getPacketStoreStrategy());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(1).getPacketStoreStrategy());
		ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");

		PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
		PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
		System.out.println(pdhtSat1);
		System.out.println(pdhtSat2);

		System.out.println(allDwlForAcq);
		List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
		this.sessionId = "sessionIdInitPlan";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
		this.droolsParams.getAllPDHT().clear();

		this.droolsParams.getAllPDHT().add(pdhtSat1);
		this.droolsParams.getAllPDHT().add(pdhtSat2);

		this.droolsParams.getAllVisibilities().add(vis2);
		this.droolsParams.getAllVisibilities().add(vis3);

		this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
		this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

		this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsOperations, this.currentKieSession, "_");

		this.droolsOperations.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession,
				true);

		this.droolsOperations.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
		allTasks = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);

		for (Map.Entry<String, Task> elements : allTasks.entrySet()) {
			System.out.println("task : " + elements.getValue());
		}

		allDwlForAcq = this.droolsOperations.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());
		assertEquals(DownlinkStrategy.DELETE, allDwlForAcq.get(0).getPacketStoreStrategy());

		DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_2");
		dto3.setPol(Polarization.H_V);
		dto3.setSizeH(4000);
		dto3.setSizeV(1900);

		dto3.setPreferredVis(allVisId);
		userInfoList.add(userInfo1);
		dto3.setUserInfo(userInfoList);

		accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
		//assertTrue(accepted);

		allDwlForAcq = this.droolsOperations.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,
				this.currentKieSession, this.droolsParams);

		for (int i = 0; i < allDwlForAcq.size(); i++) {
			System.out.println(allDwlForAcq.get(i));

		}
		assertEquals(1, allDwlForAcq.size());

		this.droolsOperations.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
	}

    /**
     * Test init plan incorrect session.
     */
    @Test(expected = NullPointerException.class)
    public void testInitPlanIncorrectSession() throws Exception
    {
        System.out.println("\n\n Running test : testInitPlanIncorrectSession");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        int fakeSession = 19;
        // create a dto and insert it into Drools
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(2800);
        System.out.println("inserted a new DTO : " + dto1);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> allTaskAcceptedBeforeInitPlan = this.droolsOperations.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        // try to invoke initPlan with a session never configured
        this.droolsOperations.initPlan(this.droolsParams, allTaskAcceptedBeforeInitPlan, null, this.sessionId, fakeSession, true);
    }

    /**
     * Test insert list dto.
     */
    @Test
    public void testInsertListDto() throws Exception
    {
        System.out.println("\n\n Running test : testInsertListDto");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        List<DTO> dtoList = new ArrayList<>();

        // create a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto1);
        dtoList.add(dto1);

        // create another one dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        dto2.setPtAvailable(true);
        System.out.println("inserted a new DTO : " + dto2);
        dtoList.add(dto2);

        // create another one dto
        DTO dto3 = this.du.createSingleDto("10/10/2017 16:12:00", "10/10/2017 16:13:00", "right", "SAT_1");
        System.out.println("inserted a new DTO : " + dto3);
        dtoList.add(dto3);

        // create another one dto
        DTO dto4 = this.du.createSingleDto("10/10/2017 16:40:00", "10/10/2017 16:41:00", "right", "SAT_1");
        System.out.println("inserted a new DTO : " + dto4);
        dtoList.add(dto4);
        this.droolsOperations.insertListDto(dtoList, this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allAcceptedTasks = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("All Accepted tasks : ");
        for (Map.Entry<String, Task> allElementsInMap : allAcceptedTasks.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        Map<String, Acquisition> allrejectedAcq = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("All allrejectedAcq tasks : ");
        for (Map.Entry<String, Acquisition> allRejectedMap : allrejectedAcq.entrySet())
        {
            System.out.println("Task ID : " + allRejectedMap.getKey());
            System.out.println("Task  : " + allRejectedMap.getValue());
        }

    }

    /**
     * Test insert list dto invalid session.
     */
    @Test(expected = NullPointerException.class)
    public void testInsertListDtoInvalidSession() throws Exception
    {
        System.out.println("\n\n Running test : testInsertListDto");
        int fakeSession = 80;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        List<DTO> dtoList = new ArrayList<>();

        // create a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto1);
        dtoList.add(dto1);

        // create another one dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto2);
        dtoList.add(dto2);

        // try to invoke method under test with an invalid session identifier
        this.droolsOperations.insertListDto(dtoList, this.sessionId, fakeSession, this.droolsParams);

    }

    /**
     * Test get PDHT status null case.
     */
    @Test
    public void testGetPDHTStatusNullCase() throws Exception
    {
        System.out.println("\n\n Running test : testGetPDHTStatusNullCase");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // receiving initial state of pdht related of satellites
        PDHT pdhtSat1AtStart = this.droolsParams.getAllPDHT().get(0);
        PDHT pdhtSat2AtStart = this.droolsParams.getAllPDHT().get(1);

        /*
         * the pdht are ordered temporally and stored into a treeMap, one for
         * each satellite. When Drools is started, at mission horizon start
         * time, into the treeMap is stored the initial pdht.
         */
        MissionHorizon mh = (MissionHorizon) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "currentMH");

        /*
         * before the start of mission horizon there aren't pdht status stored.
         */
        Calendar cal = Calendar.getInstance();
        cal.setTime(mh.getStart()); // convert your date to Calendar object
        int hoursToDecrement = -1;
        cal.add(Calendar.HOUR, hoursToDecrement);
        Date beforeMh = cal.getTime(); // again get back your date object

        System.out.println("an hour before mh : " + beforeMh);

        PDHT pdhtFromDroolsForSat1 = this.droolsOperations.getPDHTStatus(beforeMh, pdhtSat1AtStart.getSatelliteId(), this.sessionId, this.currentKieSession);
        PDHT pdhtFromDroolsForSat2 = this.droolsOperations.getPDHTStatus(beforeMh, pdhtSat2AtStart.getSatelliteId(), this.sessionId, this.currentKieSession);
        System.out.println("eceived pdht for sat 1 :" + pdhtFromDroolsForSat1);
        System.out.println("eceived pdht for sat 2 :" + pdhtFromDroolsForSat2);
        assertEquals(null, pdhtFromDroolsForSat1);
        assertEquals(null, pdhtFromDroolsForSat2);
    }

    /**
     * Test receive PDHT function.
     */
    @Test
    public void testReceivePDHTFunction() throws Exception
    {
        System.out.println("\n\n Running test : testReceivePDHTFunction");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // receiving initial state of pdht related of satellites
        PDHT pdhtSat1AtStart = this.droolsParams.getAllPDHT().get(0);
        PDHT pdhtSat2AtStart = this.droolsParams.getAllPDHT().get(1);

        /*
         * the pdht are ordered temporally and stored into a treeMap, one for
         * each satellite. When Drools is started, at mission horizon start
         * time, into the treeMap is stored the initial pdht.
         */
        TreeMap<Long, ComplexPdht> allPdhtStatusForSat1 = this.droolsOperations.receivePDHTFunction(this.sessionId, this.currentKieSession, pdhtSat1AtStart.getSatelliteId());
        assertEquals(1, allPdhtStatusForSat1.size());
        TreeMap<Long, ComplexPdht> allPdhtStatusForSat2 = this.droolsOperations.receivePDHTFunction(this.sessionId, this.currentKieSession, pdhtSat2AtStart.getSatelliteId());
        assertEquals(1, allPdhtStatusForSat2.size());
    }

    /**
     * Test receive acquisition with id.
     */
    @Test
    public void testreceiveAcceptedAcquisitionWithId() throws Exception
    {
        System.out.println("\n\n Running test : testreceiveAcceptedAcquisitionWithId");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // create a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto1);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Acquisition acqRelatedToDto = this.droolsOperations.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("acq related to the inserted dto : " + acqRelatedToDto);

        assertTrue(acqRelatedToDto != null);
        assertEquals(dto1.getDtoId(), acqRelatedToDto.getId());

        List<Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "Sat_1");
        Map<String, Acquisition> allAcqAsMap = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println("all Acq as map : " + allAcqAsMap);
        assertEquals(1, allAcq.size());
        assertEquals(1, allAcqAsMap.size());
        assertEquals(acqRelatedToDto, allAcq.get(0));
        assertEquals(acqRelatedToDto, allAcqAsMap.get(dto1.getDtoId()));
    }

    /**
     * Test receive all download associated to dto.
     */
    @Test
    public void testReceiveAllDownloadAssociatedToDto() throws Exception
    {
        System.out.println("\n\n Running test : testReceiveAllDownloadAssociatedToDto");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        List<String> partnerAssociated = new ArrayList<>();
        partnerAssociated.add(this.droolsParams.getAllPartners().get(0).getPartnerId());
        partnerAssociated.add(this.droolsParams.getAllPartners().get(1).getPartnerId());

        // create a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        System.out.println("inserted a new DTO : " + dto1);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Download> allDownloadsAssociatedToDto = this.droolsOperations.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("all downloads associated : " + allDownloadsAssociatedToDto);

        PDHT updatedPdht = this.droolsOperations.getPDHTStatus(dto1.getStartTime(), dto1.getSatelliteId(), this.sessionId, this.currentKieSession);
        System.out.println(updatedPdht);

        List<Download> allDownloads = this.taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, dto1.getSatelliteId());
        assertTrue(allDownloads.size() > 0);
        assertEquals(1, allDownloadsAssociatedToDto.size());
    }

    /**
     * Test insert partner.
     */
    @Test
    public void testInsertPartner() throws Exception
    {
        System.out.println("\n\n Running test : testInsertPartner");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllPartners().clear();
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        String partnerIdForTest = "PartnerTest";
        List<String> arIdForPartnerForTest = new ArrayList<>(Arrays.asList("ar1", "ar2"));
        double maxBicAvailableForTest = 10;
        double maxPercLoanAvailable = 10;
        Partner partner = new Partner(partnerIdForTest, arIdForPartnerForTest, maxBicAvailableForTest, maxPercLoanAvailable);

        List<Partner> allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        assertEquals(0, allPartners.size());

        this.droolsOperations.insertPartner(partner, this.sessionId, this.currentKieSession);

        allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        Partner returnedPartner = this.droolsOperations.receivePartnerWithId(partnerIdForTest, this.sessionId, this.currentKieSession);
        assertEquals(1, allPartners.size());
        System.out.println("partner returned by Drools : " + returnedPartner);
        assertEquals(returnedPartner, allPartners.get(0));
    }

    /**
     * Test insert partner.
     */
    @Test
    public void testInsertPartnerWithLoanAndBorrowedBic() throws Exception
    {
        System.out.println("\n\n Running test : testInsertPartner");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllPartners().clear();
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        String partnerIdForTest = "PartnerTest";
        List<String> arIdForPartnerForTest = new ArrayList<>(Arrays.asList("ar1", "ar2"));
        double maxBicAvailableForTest = 10;
        double maxPercLoanAvailable = 10;
        Partner partner = new Partner(partnerIdForTest, arIdForPartnerForTest, maxBicAvailableForTest, maxPercLoanAvailable);

        DebitCard debit = new DebitCard(partnerIdForTest, maxPercLoanAvailable, partnerIdForTest);
        partner.getLoanList().add(debit);

        CreditCard credit = new CreditCard(partnerIdForTest, maxPercLoanAvailable, partnerIdForTest);
        partner.getGivenLoan().add(credit);

        List<Partner> allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        assertEquals(0, allPartners.size());

        this.droolsOperations.insertPartner(partner, this.sessionId, this.currentKieSession);

        allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        Partner returnedPartner = this.droolsOperations.receivePartnerWithId(partnerIdForTest, this.sessionId, this.currentKieSession);
        assertEquals(1, allPartners.size());
        System.out.println("partner returned by Drools : " + returnedPartner);
        assertEquals(returnedPartner, allPartners.get(0));
    }

    /**
     * Test insert partner.
     */
    @Test
    public void testInsertPartner_Exception() throws Exception
    {
        System.out.println("\n\n Running test : testInsertPartner");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllPartners().clear();
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        String partnerIdForTest = "PartnerTest";
        List<String> arIdForPartnerForTest = new ArrayList<>(Arrays.asList("ar1", "ar2"));
        double maxBicAvailableForTest = 10;
        double maxPercLoanAvailable = 10;
        Partner partner = new Partner(partnerIdForTest, arIdForPartnerForTest, maxBicAvailableForTest, maxPercLoanAvailable);

        List<Partner> allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        assertEquals(0, allPartners.size());

        this.droolsOperations.insertPartner(partner, this.sessionId, this.currentKieSession);

        allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        Partner returnedPartner = this.droolsOperations.receivePartnerWithId(partnerIdForTest, this.sessionId, this.currentKieSession);
        assertEquals(1, allPartners.size());
        System.out.println("partner returned by Drools : " + returnedPartner);
        assertEquals(returnedPartner, allPartners.get(0));
    }

    /**
     * Test receive all maneuvers.
     */
    @Test
    public void testReceiveAllManeuvers() throws Exception
    {
        System.out.println("\n\n Running test : testReceiveAllManeuvers");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // create a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:57:00", "left", "SAT_1");
        System.out.println("inserted a new DTO : " + dto1);
        this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // create another one dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "right", "SAT_1");
        System.out.println("inserted a new DTO : " + dto2);
        this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
    }

    /**
     * Receive rejected acquisitions for sat.
     */
    @Test
    public void receiveRejectedAcquisitions() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<String> partnersAssociated = new ArrayList<>();
        partnersAssociated.add("Partner_1");
        DTO dto1 = this.du.createSingleDto("10/10/2017 11:20:00", "10/10/2017 11:22:00", "left", satelliteId);
        dto1.setPol(Polarization.VV);
        dto1.setSizeV(200);
        dto1.setSizeH(0);
        dto1.setImageBIC(10);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:18:00", "10/10/2017 11:19:00", "right", satelliteId);
        dto2.setPol(Polarization.VV);
        dto2.setSizeV(200);
        dto2.setSizeH(0);
        dto2.setImageBIC(10);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        Map<String, Acquisition> allRejectedAcq = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(1, allRejectedAcq.size());

    }

    /**
     * Inits the plan test.
     */
    @Test
    public void initPlanTest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:55:00", "10/10/2017 11:57:00", "left", satelliteId);
        dto1.setImageBIC(10);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean inserted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Map<String, Task> allPlannedTasks = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allPlannedTasks.entrySet())
        {
            allPlannedTasksAsList.add(allTasks.getValue());
        }

        List<EquivalentDTO> previousTheatres = new ArrayList<>();

        this.droolsOperations.initPlan(this.droolsParams, allPlannedTasksAsList, previousTheatres, this.sessionId, this.currentKieSession, true);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:50:00", "10/10/2017 11:52:00", "left", satelliteId);
        dto2.setPol(Polarization.VV);
        dto2.setSizeV(200);
        dto2.setSizeH(0);
        dto2.setImageBIC(10);
        System.out.println("I'm inserting dto : " + dto2.toString());
        inserted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        Map<String, Acquisition> allRejectedAcq = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, allRejectedAcq.size());

        allPlannedTasks = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allPlannedTasks.entrySet())
        {
            allPlannedTasksAsList.add(allTasks.getValue());
        }

        List<Task> alltasksRejected = this.droolsOperations.receiveDeletedTasks(this.sessionId, this.currentKieSession);
        System.out.println("rejected tasks :" + alltasksRejected.size());
        for (int i = 0; i < alltasksRejected.size(); i++)
        {
            System.out.println(alltasksRejected.get(i));
        }

        this.droolsOperations.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId, this.currentKieSession, true);
    }

    /**
     * Write to file.
     *
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Test
    public void writeToFile() throws IOException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        ResourceFunctions resources = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, ComplexPdht> pdhtFunction = resources.getPDHTFunctionAssociatedToSat("SAT_1");
        System.out.println("pdht status : " + pdhtFunction);

        System.out.println("result will be saved as file in : " + this.droolsParams.getResponceFile());
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());
        this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("06/10/2017 15:55:00", "06/10/2017 15:57:00", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto2.toString());
        this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
    }

    /**
     * Test check if theatre is valid invalid for overlap.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testCheckIfTheatreIsValid_invalidForOverlap() throws Exception
    {
        int currentKieSession = 1;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, currentKieSession, "_");
        EquivalentDTO equivDto = new EquivalentDTO();

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:56:00", "right", "SAT_1");
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 17:00:00", "right", "SAT_1");
        DTO dto3 = this.du.createSingleDto("10/10/2017 17:36:00", "10/10/2017 17:37:00", "right", "SAT_1");

        List<DTO> allDto = new ArrayList<>();
        allDto.add(dto1);
        allDto.add(dto2);
        allDto.add(dto3);

        List<Maneuver> allmanInsideTheatre = new ArrayList<>();
        Maneuver man = this.du.createManeuver("cmga01", "dto1", "dto2", "10/10/2017 17:36:00", "10/10/2017 17:37:00", "Sat_1", Actuator.CMGA);
        allmanInsideTheatre.add(man);

        equivDto.setAllDtoInEquivalentDto(allDto);
        equivDto.setManAssociated(allmanInsideTheatre);
        equivDto.setStartAndStop();
        boolean theatreIsValid = this.droolsOperations.checkIfTheatreIsValid(equivDto, this.sessionId, currentKieSession, this.droolsParams);
        assertFalse(theatreIsValid);
    }

    /**
     * Test check if theatre is valid with man.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testCheckIfTheatreIsValid_WithMan() throws Exception
    {
        int currentKieSession = 1;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, currentKieSession, "_");
        EquivalentDTO equivDto = new EquivalentDTO();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:55:00", "10/10/2017 13:56:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 17:00:00", "left", "SAT_1");
        dto2.setDtoId("dto2");
        DTO dto3 = this.du.createSingleDto("10/10/2017 17:36:00", "10/10/2017 17:37:00", "right", "SAT_1");
        dto3.setDtoId("dto3");

        List<DTO> allDto = new ArrayList<>();
        allDto.add(dto1);
        allDto.add(dto2);
        allDto.add(dto3);

        equivDto.setAllDtoInEquivalentDto(allDto);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        List<Maneuver> allmanInsideTheatre = new ArrayList<>();
        Maneuver man = this.du.createManeuver("cmga01", "dto1", "dto2", "10/10/2017 17:36:00", "10/10/2017 17:37:00", "Sat_1", Actuator.CMGA);
        allmanInsideTheatre.add(man);

        equivDto.setManAssociated(allmanInsideTheatre);
        boolean theatreIsValid = this.droolsOperations.checkIfTheatreIsValid(equivDto, this.sessionId, this.currentKieSession, this.droolsParams);
        assertTrue(theatreIsValid);
    }

    /**
     * Test receive dto rejected.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceiveDtoRejected() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/11/2017 08:45:00", "10/11/2017 08:48:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPol(Polarization.HV);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean inserted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(inserted);

        this.rejectedElements = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

    }

    /**
     * Test receiv all partners.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceivAllPartners() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        List<Partner> allPartners = this.droolsOperations.receiveAllPartners(this.sessionId, this.currentKieSession);
        System.out.println("all partners : " + allPartners);
        assertEquals(this.droolsParams.getAllPartners().size(), allPartners.size());
    }

    /**
     * Test receive prev and next man exist man.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceivePrevAndNextMan_exist_man() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(3000);
        dto1.setSizeV(3000);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        List<Maneuver> prevAndNextMan = this.droolsOperations.receivePrevAndNextMan(allAcq.get(0), this.sessionId, this.currentKieSession);

        assertEquals(2, prevAndNextMan.size());
        System.out.println("prev and next man : " + prevAndNextMan);
        List<Maneuver> allMan = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println("all man : " + allMan);
    }

    /**
     * Test receive prev and next man not exist man.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceivePrevAndNextMan_not_exist_man() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(300);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        List<Maneuver> prevAndNextMan = this.droolsOperations.receivePrevAndNextMan(allAcq.get(0), this.sessionId, this.currentKieSession);

        assertEquals(0, prevAndNextMan.size());
        System.out.println("prev and next man : " + prevAndNextMan);
        List<Maneuver> allMan = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("all man : " + allMan);
    }

    /**
     * Test receive prev and next man only prev man.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceivePrevAndNextMan_only_prev_man() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(200);
        dto1.setSizeV(200);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        List<Maneuver> prevAndNextMan = this.droolsOperations.receivePrevAndNextMan(allAcq.get(0), this.sessionId, this.currentKieSession);

        assertEquals(1, prevAndNextMan.size());
        System.out.println("prev and next man : " + prevAndNextMan);
        List<Maneuver> allMan = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("all man : " + allMan);
    }

    /**
     * Test receive all acquisitions as map.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceiveAllAcquisitionsAsMap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        Map<String, Acquisition> allAcq2 = this.droolsOperations.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println("allAcq : " + allAcq);
        assertEquals(1, allAcq.size());
        assertEquals(allAcq.size(), allAcq2.size());

    }

    /**
     * Test receive all acquisitions as map.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testReceiveAllAcquisitionsAsMap_NoKIeSession() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        SessionHandler.getKieSessionsMap().clear();
        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        Map<String, Acquisition> allAcq2 = this.droolsOperations.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println("allAcq : " + allAcq);
        System.out.println("allAcq2 : " + allAcq2);

    }

    @Test
    public void testReceiveAllAcquisitionsAsMapOtherId() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getAllSat().get(0).setInitialLookSide("left");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "AT_1");
        Map<String, Acquisition> allAcq2 = this.droolsOperations.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println("allAcq : " + allAcq);
        assertEquals(1, allAcq.size());
        assertEquals(allAcq.size(), allAcq2.size());

    }

    /**
     * Restore extra cost left acq test.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void restoreExtraCostLeftAcqTest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Partner partnerUnderTest = this.droolsParams.getAllPartners().get(0);
        List<String> partnerAssociatedId = new ArrayList<>();
        partnerAssociatedId.add(partnerUnderTest.getPartnerId());

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setImageBIC(3);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:11:00", "10/10/2017 13:12:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto2.setImageBIC(5);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:02:00", "10/10/2017 14:03:00", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto4 = this.du.createSingleDto("10/10/2017 13:50:00", "10/10/2017 13:51:00", "left", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto4.setImageBIC(2);
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("rejected : " + this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession));

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> essFuncSat1 = resFunc.getEssFunctionSat1();
        TreeMap<Long, Maneuver> manFuncSat1 = resFunc.getAllManeuversSat1();
        System.out.println("ess function sat1: " + essFuncSat1);
        System.out.println("man function sat1: " + manFuncSat1);

        System.out.println("ess function sat2: " + resFunc.getEssFunctionSat2());
        System.out.println("man function sat2: " + resFunc.getAllManeuversSat2());

        this.droolsOperations.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * Test clear session.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testClearSession() throws Exception
    {
        DroolsQueries queries = new DroolsQueries();

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:45:00", "10/10/2017 12:46:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setImageBIC(20);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("PARTNER ASSOC : " + this.droolsParams.getAllPartners().get(2));
        System.out.println("PARTNER ASSOC : " + this.droolsParams.getAllPartners().get(0));

        System.out.println("before " + queries.getAllAcceptedTasks(this.sessionId, this.currentKieSession, this.droolsParams));

        this.droolsOperations.clearSessionInstance(this.sessionId, this.currentKieSession, this.droolsParams, true);

        System.out.println("PARTNER ASSOC : " + this.droolsParams.getAllPartners().get(2));
        System.out.println("PARTNER ASSOC : " + this.droolsParams.getAllPartners().get(0));
        System.out.println("after " + queries.getAllAcceptedTasks(this.sessionId, this.currentKieSession, this.droolsParams));
    }

    /**
     * Update pdht till end test not overhead list.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void updatePdhtTillEnd_Test_not_Overhead_List() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);
        System.out.println("I'm inserting dto : " + dto1.toString());

        this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        Acquisition acqRelatedToDto = this.droolsOperations.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        System.out.println("returned acq : " + acqRelatedToDto);

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 16:04:00", "10/10/2017 16:08:00", "left", "SAT_1");
        acq1.setSizeH(200);
        acq1.setPolarization(Polarization.HH);

        Acquisition acq2 = this.du.createParametricAcquisition("acq2", "10/10/2017 06:50:00", "10/10/2017 06:52:00", "right", "SAT_1");
        acq2.setSizeH(200);
        acq2.setPolarization(Polarization.HH);

        Acquisition acq3 = this.du.createParametricAcquisition("acq3", "10/10/2017 07:30:00", "10/10/2017 07:32:00", "left", "SAT_1");
        acq3.setSizeH(200);
        acq3.setPolarization(Polarization.HH);

        Acquisition acq4 = this.du.createParametricAcquisition("acq4", "10/10/2017 09:12:00", "10/10/2017 09:14:00", "left", "SAT_1");
        acq4.setSizeH(200);
        acq4.setPolarization(Polarization.HH);
    }

    /**
     * Test update pdht till end no space pdht.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testUpdatePdhtTillEnd_no_space_pdht() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        KieSession kieSession = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
        TreeMap<Long, ComplexPdht> localPdhtFunction = resFunc.getPDHTFunctionAssociatedToSat("SAT_1");
        localPdhtFunction.clear();

        PDHT pdhtForTest = this.droolsParams.getAllPDHT().get(0);
        List<Long> capacityMemoryModulesForTest = new ArrayList<>(Arrays.asList(20l, 20l, 20l, 20l, 20l, 20l));
        pdhtForTest.setCapacity(capacityMemoryModulesForTest);

        System.out.println("created pdht : " + pdhtForTest);

        localPdhtFunction.put(this.droolsParams.getCurrentMH().getStart().getTime(), new ComplexPdht(pdhtForTest));
        resFunc.setPDHTTemporalFunctionSat1(localPdhtFunction);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);
        System.out.println("I'm inserting dto : " + dto1.toString());

        this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        Map<String, Acquisition> rejected = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containReason = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected, ReasonOfReject.noSpaceInPdht);

        assertEquals(true, containReason);

        this.droolsOperations.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testReceiveAcquisitionWithArId() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);

        this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        Acquisition returnedAcq1 = this.droolsOperations.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("1 " + returnedAcq1);

        Acquisition returnedAcq = this.droolsOperations.receiveAcquisitionWithArId(DroolsParameters.getLogger(), "001-HP_AR-001", this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println(returnedAcq);

        assertEquals(returnedAcq1, returnedAcq);
    }

    @Test
    public void testCheckSession_not_exist() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        int sessionForTest = -1;
        boolean existSession = DroolsOperations.checkSession(this.sessionId, sessionForTest);

        assertEquals(false, existSession);
    }

    @Test
    public void testCheckIfDi2sIsFeaasible_slave_Possible() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner slave = this.droolsParams.getAllPartners().get(0);
        slave.setMaxBICAvailable(30);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);

        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave.getPartnerId());

        boolean isSlave = true;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeaasible_slave_possible_with_loan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        Partner slave = this.droolsParams.getAllPartners().get(0);
        slave.setMaxBICAvailable(10);

        Partner potentialCreditor = this.droolsParams.getAllPartners().get(1);
        potentialCreditor.setFinished(true);
        potentialCreditor.getBorrowingBic().add(slave.getPartnerId());
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);

        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave.getPartnerId());

        boolean isSlave = true;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeaasible_slave_notPossible() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Partner slave = this.droolsParams.getAllPartners().get(0);
        slave.setMaxBICAvailable(10);
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);

        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave.getPartnerId());

        boolean isSlave = true;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertFalse(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeaasible_master() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner master = this.droolsParams.getAllPartners().get(0);
        master.setMaxBICAvailable(10);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, master.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        List<String> masterPartnersId = new ArrayList<>();
        masterPartnersId.add(master.getPartnerId());
        boolean isSlave = false;
        this.droolsOperations.checkIfDi2sIsFeasible(dto1, masterPartnersId, isSlave, this.droolsParams);
    }

    @Test
    public void testInsertPreviousEquivalentDto_ok() throws Exception
    {
        System.out.println("\n\n Running test : testInsertPreviousEquivalentDto_ok");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Date start = DroolsUtils.createDate("10/10/2017 15:55:00");
        Date end = DroolsUtils.createDate("10/10/2017 16:00:00");
        EquivalentDTO equivDto = new EquivalentDTO("equivDto", start, end, 0);

        boolean inserted = this.droolsOperations.insertPreviousEquivalentDto(equivDto, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
    }

    @Test
    public void testInsertPreviousEquivalentDto_still_present_in_drools() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        Date start = DroolsUtils.createDate("10/10/2017 15:55:00");
        Date end = DroolsUtils.createDate("10/10/2017 16:00:00");
        EquivalentDTO equivDto = new EquivalentDTO("equivDto", start, end, 2);

        boolean inserted = this.droolsOperations.insertPreviousEquivalentDto(equivDto, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        inserted = this.droolsOperations.insertPreviousEquivalentDto(equivDto, this.sessionId, this.currentKieSession);
        assertFalse(inserted);
    }

    @Test
    public void testPurgeSensorModeForMissionHorizon() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        assertEquals(0, this.droolsParams.getPurgeSensorMode().size());

        List<TypeOfAcquisition> sensorModeToPurge = new ArrayList<>();
        sensorModeToPurge.add(TypeOfAcquisition.PINGPONG);
        this.droolsOperations.purgeSensorModeForMissionHorizon(sensorModeToPurge, this.droolsParams);
        assertEquals(1, this.droolsParams.getPurgeSensorMode().size());

    }

    @Test
    public void testCheckIfDi2sAreConsistentInDistance_valid() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        TypeOfAcquisition firstAcq = TypeOfAcquisition.SPOTLIGHT_1A;
        TypeOfAcquisition secondAcq = TypeOfAcquisition.STRIPMAP;

        Date start = DroolsUtils.createDate("10/10/2017 15:55:00");
        Date end = DroolsUtils.createDate("10/10/2017 15:55:02");

        long gap = end.getTime() - start.getTime(); // 2 sec
        boolean valid = this.droolsOperations.checkIfDi2sAreConsistentInDistance(firstAcq, secondAcq, gap, this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("is valid ? " + valid);

        assertTrue(valid);
    }

    @Test
    public void testCheckIfDi2sAreConsistentInDistance_invalid() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        TypeOfAcquisition firstAcq = TypeOfAcquisition.SPOTLIGHT_1A;
        TypeOfAcquisition secondAcq = TypeOfAcquisition.STRIPMAP;

        Date start = DroolsUtils.createDate("10/10/2017 15:55:00");
        Date end = DroolsUtils.createDate("10/10/2017 15:55:04");

        long gap = end.getTime() - start.getTime(); // 4 sec
        boolean valid = this.droolsOperations.checkIfDi2sAreConsistentInDistance(firstAcq, secondAcq, gap, this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("is valid ? " + valid);

        assertFalse(valid);
    }

    @Test
    public void testFilterRejectForSatellite() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        String startTime = "10/10/2017 15:55:00";
        String stopTime = "10/10/2017 16:55:20";
        String lookSide = "left";
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto(startTime, stopTime, lookSide, satelliteId);
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(4000);
        dto1.setSizeV(4000);

        System.out.println("I'm inserting dto : " + dto1.toString());

        this.rejectedElements = this.droolsOperations.receiveDtoRejected(this.sessionId, this.currentKieSession);

        List<Task> onlyRejectedForSat1 = this.droolsOperations.receiveDtoRejectedForSatellite("1", this.sessionId, this.currentKieSession);
        assertEquals(0, onlyRejectedForSat1.size());
        List<Task> onlyRejectedForSat2 = this.droolsOperations.receiveDtoRejectedForSatellite("2", this.sessionId, this.currentKieSession);
        assertEquals(0, onlyRejectedForSat2.size());

        boolean inserted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println("inserted ? " + inserted);

        onlyRejectedForSat1 = this.droolsOperations.receiveDtoRejectedForSatellite("1", this.sessionId, this.currentKieSession);
        onlyRejectedForSat2 = this.droolsOperations.receiveDtoRejectedForSatellite("2", this.sessionId, this.currentKieSession);

        assertEquals(1, onlyRejectedForSat1.size());
        assertEquals(0, onlyRejectedForSat2.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testRestoreExtraCostTheatre_noValidTheatre() throws Exception
    {
        System.out.println("\n\n\n\n running test : test thirdScenarioDeltaFat");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Date startMH = DroolsUtils.createDate("14/09/2016 06:21:00");
        Date endMH = DroolsUtils.createDate("14/09/2016 18:21:00");
        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTheatreOnADay(1);

        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        String satelliteId = "SAT_1";

        /*
         * PR1
         */

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO PR1_AR1_DTO1 = this.du.createSingleDto("14/09/2016 09:03:00", "14/09/2016 09:03:20", "right", satelliteId);
        PR1_AR1_DTO1.setPol(Polarization.HH);
        PR1_AR1_DTO1.setSizeH(4000);
        PR1_AR1_DTO1.setDtoId("PR1_AR1_DTO1");

        DTO PR1_AR2_DTO1 = this.du.createSingleDto("14/09/2016 09:03:10", "14/09/2016 09:03:30", "right", satelliteId);
        PR1_AR2_DTO1.setPol(Polarization.HH);
        PR1_AR2_DTO1.setSizeH(4000);
        PR1_AR2_DTO1.setDtoId("PR1_AR2_DTO1");

        DTO PR1_AR3_DTO1 = this.du.createSingleDto("14/09/2016 09:04:30", "14/09/2016 09:04:50", "right", satelliteId);
        PR1_AR3_DTO1.setPol(Polarization.HH);
        PR1_AR3_DTO1.setSizeH(4000);
        PR1_AR3_DTO1.setDtoId("PR1_AR3_DTO1");

        allDtosIncludedInTheatre.add(PR1_AR1_DTO1);
        allDtosIncludedInTheatre.add(PR1_AR2_DTO1);
        allDtosIncludedInTheatre.add(PR1_AR3_DTO1);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "14/09/2016 09:04:30", "14/09/2016 09:14:30", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(PR1_AR1_DTO1.getStartTime());
        equivDto.setEndTime(PR1_AR3_DTO1.getEndTime());

        boolean validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);
        List<Acquisition> allAcceptedAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }
        boolean expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR1_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreInternallyInconsistent);
        assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR1_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR2_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreInternallyInconsistent);
        // assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR2_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        // assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR3_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreInternallyInconsistent);
        assertTrue(expectedReason);
        /*
         * PR2
         */

        DTO PR2_AR1_DTO1 = this.du.createSingleDto("14/09/2016 11:00:00", "14/09/2016 11:00:20", "right", satelliteId);
        PR2_AR1_DTO1.setPol(Polarization.HH);
        PR2_AR1_DTO1.setSizeH(4000);
        PR2_AR1_DTO1.setDtoId("PR2_AR1_DTO1");

        boolean insert = this.droolsOperations.insertDto(this.droolsParams, PR2_AR1_DTO1, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        assertTrue(insert);

        DTO PR2_AR2_DTO1 = this.du.createSingleDto("14/09/2016 11:15:00", "14/09/2016 11:15:20", "right", satelliteId);
        PR2_AR2_DTO1.setPol(Polarization.HH);
        PR2_AR2_DTO1.setSizeH(4000);
        PR2_AR2_DTO1.setDtoId("PR2_AR2_DTO1");

        insert = this.droolsOperations.insertDto(this.droolsParams, PR2_AR2_DTO1, this.sessionId, this.currentKieSession);
        assertTrue(insert);

        DTO PR2_AR3_DTO1 = this.du.createSingleDto("14/09/2016 10:52:00", "14/09/2016 10:52:20", "right", satelliteId);
        PR2_AR3_DTO1.setPol(Polarization.HH);
        PR2_AR3_DTO1.setSizeH(4000);
        PR2_AR3_DTO1.setDtoId("PR2_AR3_DTO1");

        insert = this.droolsOperations.insertDto(this.droolsParams, PR2_AR3_DTO1, this.sessionId, this.currentKieSession);
        assertTrue(insert);

        allAcceptedAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        /*
         * PR3
         */

        List<DTO> allDtosIncludedInTheatre2 = new ArrayList<>();

        DTO PR3_AR1_DTO1 = this.du.createSingleDto("14/09/2016 10:52:10", "14/09/2016 10:52:30", "right", satelliteId);
        PR3_AR1_DTO1.setPol(Polarization.HH);
        PR3_AR1_DTO1.setSizeH(4000);
        PR3_AR1_DTO1.setDtoId("PR3_AR1_DTO1");

        DTO PR3_AR2_DTO1 = this.du.createSingleDto("14/09/2016 10:53:00", "14/09/2016 10:53:20", "right", satelliteId);
        PR3_AR2_DTO1.setPol(Polarization.HH);
        PR3_AR2_DTO1.setSizeH(4000);
        PR3_AR2_DTO1.setDtoId("PR3_AR2_DTO1");

        DTO PR3_AR3_DTO1 = this.du.createSingleDto("14/09/2016 10:51:00", "14/09/2016 10:51:20", "right", satelliteId);
        PR3_AR3_DTO1.setPol(Polarization.HH);
        PR3_AR3_DTO1.setSizeH(4000);
        PR3_AR3_DTO1.setDtoId("PR3_AR3_DTO1");

        allDtosIncludedInTheatre2.add(PR3_AR1_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR2_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR3_DTO1);

        EquivalentDTO equivDto2 = new EquivalentDTO();
        equivDto2.setEquivalentDtoId("equivDto2");
        equivDto2.setAllDtoInEquivalentDto(allDtosIncludedInTheatre2);
        equivDto2.setManAssociated(maneuvers);
        equivDto2.setEquivType(PRMode.Theatre);
        equivDto2.setStartTime(PR3_AR3_DTO1.getStartTime());
        equivDto2.setEndTime(PR3_AR2_DTO1.getEndTime());

        validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto2, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        allAcceptedAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        List<String> partnersAssociatedWithTheatre = new ArrayList<>();
        for (int i = 0; i < PR3_AR3_DTO1.getUserInfo().size(); i++)
        {
            String partnerId = PR3_AR3_DTO1.getUserInfo().get(i).getOwnerId();
            partnersAssociatedWithTheatre.add(partnerId);
        }

        Partner p1 = this.droolsOperations.receivePartnerWithId(partnersAssociatedWithTheatre.get(0), this.sessionId, this.currentKieSession);
        Partner p2 = this.droolsOperations.receivePartnerWithId(partnersAssociatedWithTheatre.get(1), this.sessionId, this.currentKieSession);

        System.out.println(partnersAssociatedWithTheatre);

        double bicBeforeRestoreP1 = p1.getUsedBIC();
        double bicBeforeRestoreP2 = p2.getUsedBIC();
        System.out.println("used bic p1 :" + bicBeforeRestoreP1);
        System.out.println("used bic p2 :" + bicBeforeRestoreP2);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.droolsOperations.restoreExtraCostTheatre(this.sessionId, this.currentKieSession, this.droolsParams);

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        bicBeforeRestoreP1 = p1.getUsedBIC();
        bicBeforeRestoreP2 = p2.getUsedBIC();
        System.out.println("used bic p1 :" + bicBeforeRestoreP1);
        System.out.println("used bic p2 :" + bicBeforeRestoreP2);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testRestoreExtraCostTheatre() throws Exception
    {
        System.out.println("\n\n\n\n running test : test thirdScenarioDeltaFat");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Date startMH = DroolsUtils.createDate("14/09/2016 06:21:00");
        Date endMH = DroolsUtils.createDate("14/09/2016 18:21:00");
        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTheatreOnADay(1);

        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        String satelliteId = "SAT_1";

        /*
         * PR1
         */

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO PR1_AR1_DTO1 = this.du.createSingleDto("14/09/2016 09:03:00", "14/09/2016 09:03:20", "right", satelliteId);
        PR1_AR1_DTO1.setPol(Polarization.HH);
        PR1_AR1_DTO1.setSizeH(4000);
        PR1_AR1_DTO1.setImageBIC(4);
        PR1_AR1_DTO1.setDtoId("PR1_AR1_DTO1");

        DTO PR1_AR2_DTO1 = this.du.createSingleDto("14/09/2016 09:03:40", "14/09/2016 09:03:50", "right", satelliteId);
        PR1_AR2_DTO1.setPol(Polarization.HH);
        PR1_AR2_DTO1.setSizeH(4000);
        PR1_AR2_DTO1.setImageBIC(4);
        PR1_AR2_DTO1.setDtoId("PR1_AR2_DTO1");

        DTO PR1_AR3_DTO1 = this.du.createSingleDto("14/09/2016 09:04:30", "14/09/2016 09:04:50", "right", satelliteId);
        PR1_AR3_DTO1.setPol(Polarization.HH);
        PR1_AR3_DTO1.setSizeH(4000);
        PR1_AR3_DTO1.setImageBIC(4);
        PR1_AR3_DTO1.setDtoId("PR1_AR3_DTO1");

        allDtosIncludedInTheatre.add(PR1_AR1_DTO1);
        allDtosIncludedInTheatre.add(PR1_AR2_DTO1);
        allDtosIncludedInTheatre.add(PR1_AR3_DTO1);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setExtraCostPitch(2);
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "14/09/2016 09:03:00", "14/09/2016 09:05:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);
        equivDto.setManAssociated(maneuvers);

        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(PR1_AR1_DTO1.getStartTime());
        equivDto.setEndTime(PR1_AR3_DTO1.getEndTime());

        boolean validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);
        List<Acquisition> allAcceptedAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        List<String> partnersAssociatedWithTheatre = new ArrayList<>();
        for (int i = 0; i < PR1_AR2_DTO1.getUserInfo().size(); i++)
        {
            String partnerId = PR1_AR2_DTO1.getUserInfo().get(i).getOwnerId();
            partnersAssociatedWithTheatre.add(partnerId);
        }

        Partner p1 = this.droolsOperations.receivePartnerWithId(partnersAssociatedWithTheatre.get(0), this.sessionId, this.currentKieSession);
        Partner p2 = this.droolsOperations.receivePartnerWithId(partnersAssociatedWithTheatre.get(1), this.sessionId, this.currentKieSession);

        System.out.println(partnersAssociatedWithTheatre);

        double bicBeforeRestoreP1 = p1.getUsedBIC();
        double bicBeforeRestoreP2 = p2.getUsedBIC();
        System.out.println("used bic p1 :" + bicBeforeRestoreP1);
        System.out.println("used bic p2 :" + bicBeforeRestoreP2);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.droolsOperations.restoreExtraCostTheatre(this.sessionId, this.currentKieSession, this.droolsParams);

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        bicBeforeRestoreP1 = p1.getUsedBIC();
        bicBeforeRestoreP2 = p2.getUsedBIC();
        System.out.println("used bic p1 :" + bicBeforeRestoreP1);
        System.out.println("used bic p2 :" + bicBeforeRestoreP2);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testRestoreExtraCostTheatre_prevProc() throws Exception
    {
        System.out.println("\n\n\n\n running test : test thirdScenarioDeltaFat");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Date startMH = DroolsUtils.createDate("14/09/2016 06:21:00");
        Date endMH = DroolsUtils.createDate("14/09/2016 18:21:00");
        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTheatreOnADay(1);

        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre2 = new ArrayList<>();

        DTO PR3_AR1_DTO1 = this.du.createSingleDto("14/09/2016 10:52:10", "14/09/2016 10:52:30", "right", satelliteId);
        PR3_AR1_DTO1.setPol(Polarization.HH);
        PR3_AR1_DTO1.setSizeH(4000);
        PR3_AR1_DTO1.setDtoId("PR3_AR1_DTO1");

        DTO PR3_AR2_DTO1 = this.du.createSingleDto("14/09/2016 10:53:00", "14/09/2016 10:53:20", "right", satelliteId);
        PR3_AR2_DTO1.setPol(Polarization.HH);
        PR3_AR2_DTO1.setSizeH(4000);
        PR3_AR2_DTO1.setDtoId("PR3_AR2_DTO1");

        DTO PR3_AR3_DTO1 = this.du.createSingleDto("14/09/2016 10:51:00", "14/09/2016 10:51:20", "right", satelliteId);
        PR3_AR3_DTO1.setPol(Polarization.HH);
        PR3_AR3_DTO1.setSizeH(4000);
        PR3_AR3_DTO1.setDtoId("PR3_AR3_DTO1");

        allDtosIncludedInTheatre2.add(PR3_AR1_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR2_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR3_DTO1);

        EquivalentDTO equivDto2 = new EquivalentDTO();
        equivDto2.setEquivalentDtoId("equivDto2");
        equivDto2.setAllDtoInEquivalentDto(allDtosIncludedInTheatre2);
        equivDto2.setManAssociated(null);
        equivDto2.setEquivType(PRMode.Theatre);
        equivDto2.setStartTime(PR3_AR3_DTO1.getStartTime());
        equivDto2.setEndTime(PR3_AR2_DTO1.getEndTime());
        List<Maneuver> maneuvers = new ArrayList<>();

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);
        equivDto2.setManAssociated(maneuvers);

        boolean validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto2, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        List<String> partnersAssociatedWithTheatre = new ArrayList<>();
        for (int i = 0; i < PR3_AR3_DTO1.getUserInfo().size(); i++)
        {
            String partnerId = PR3_AR3_DTO1.getUserInfo().get(i).getOwnerId();
            partnersAssociatedWithTheatre.add(partnerId);
        }

        Partner p1 = this.droolsOperations.receivePartnerWithId(partnersAssociatedWithTheatre.get(0), this.sessionId, this.currentKieSession);
        Partner p2 = this.droolsOperations.receivePartnerWithId(partnersAssociatedWithTheatre.get(1), this.sessionId, this.currentKieSession);

        System.out.println(partnersAssociatedWithTheatre);

        double bicBeforeRestoreP1 = p1.getUsedBIC();
        double bicBeforeRestoreP2 = p2.getUsedBIC();
        System.out.println("used bic p1 :" + bicBeforeRestoreP1);
        System.out.println("used bic p2 :" + bicBeforeRestoreP2);

        this.droolsOperations.restoreExtraCostTheatre(this.sessionId, this.currentKieSession, this.droolsParams);

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        bicBeforeRestoreP1 = p1.getUsedBIC();
        bicBeforeRestoreP2 = p2.getUsedBIC();
        System.out.println("used bic p1 :" + bicBeforeRestoreP1);
        System.out.println("used bic p2 :" + bicBeforeRestoreP2);
    }

    @Test
    public void testPrintElements() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\opt\\spla\\BRM\\testReports\\testWriteToFile.txt"));
        List<Task> factsSat1 = new ArrayList<>();

        Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 06:00:00", "10/10/2017 06:10:00", "left", "SAT_1");
        factsSat1.add(acq);
        factsSat1.add(acq);

        List<Task> rejected = new ArrayList<>();
        this.droolsOperations.printElements(this.droolsParams, "SAT_1", factsSat1, rejected, resourceFunctions, bw);
    }

    @Test
    public void testRestoreExtraCostLeftAcq() throws Exception
    {
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetCorrectConflictRank_invalidDtoId() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        String invalidDtoId = "test";
        String conflictRank = this.droolsOperations.getCorrectConflictRank(invalidDtoId, this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapWithAcquisition);

        assertEquals(null, conflictRank);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetCorrectConflictRank_highest() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        String conflictRank = this.droolsOperations.getCorrectConflictRank(dtoTest.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapWithAcquisition);

        assertEquals(dto1.getDtoId(), conflictRank);

        System.out.println("conflictRank : " + conflictRank);
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetCorrectConflictRank_highest_noElementSamePartner() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner p1 = allPartners.get(0);
        Partner p2 = allPartners.get(1);
        Partner p3 = allPartners.get(2);

        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        UserInfo userInfo3 = new UserInfo(null, false, p3.getPartnerId(), p3.getUgsId());

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList1 = new ArrayList<>();
        userInfoList1.add(userInfo1);
        userInfoList1.add(userInfo2);
        dto1.setUserInfo(userInfoList1);

        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);

        List<UserInfo> userInfoList2 = new ArrayList<>();
        userInfoList2.add(userInfo1);
        userInfoList2.add(userInfo2);
        dto2.setUserInfo(userInfoList2);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);

        List<UserInfo> userInfoList3 = new ArrayList<>();
        userInfoList3.add(userInfo1);
        userInfoList3.add(userInfo2);
        dto3.setUserInfo(userInfoList3);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        List<UserInfo> userInfoListTest = new ArrayList<>();
        userInfoListTest.add(userInfo3);
        dtoTest.setUserInfo(userInfoListTest);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        String conflictRank = this.droolsOperations.getCorrectConflictRank(dtoTest.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqOverlapWithAcquisition);
        assertEquals(null, conflictRank);

        System.out.println("conflictRank : " + conflictRank);
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetCorrectConflictRank_lowest() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(3);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(1);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        String conflictRank = this.droolsOperations.getCorrectConflictRank(dtoTest.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.noSpaceInPdht);

        System.out.println("conflictRank : " + conflictRank);
        System.out.println("rejected : " + rejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetCorrectConflictRank_noConflictRank() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMaps = (ConfigMaps) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Map<String, Acquisition> rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        accepted = this.droolsOperations.insertDto(this.droolsParams, dtoTest, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        rejected = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        assertEquals(1, rejected.size());

        DtoToAcqRule dtoToAcq = new DtoToAcqRule();
        List<String> report = new ArrayList<>();
        dtoToAcq.fromDtoToAcqRule(dtoTest, null, this.droolsParams, report, resourceFunctions, configMaps, rejected, allAccepted);

        System.out.println("rejected : " + rejected);
        assertEquals(1, rejected.size());
        assertEquals(true, this.du.checkIfContainsTheExpectedReason(dtoTest.getDtoId(), rejected, ReasonOfReject.acqOverlapWithAcquisition));

        String conflictRank = this.droolsOperations.getCorrectConflictRank(dtoTest.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.HpFixedOrbitLimitReached);

        System.out.println("conflictRank : " + conflictRank);
        System.out.println("rejected : " + rejected);

    }

    @Test
    public void testCheckIfLMPIsValid_valid() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId(), dto3.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        Map<Boolean, List<String>> impactedElements = this.droolsOperations.checkIfLMP_VU_IsValidForOverlap(this.droolsParams, this.sessionId, this.currentKieSession, dtoTest);
        System.out.println("impactedElemets : " + impactedElements);
        assertTrue(impactedElements.get(true) != null);
    }

    @Test
    public void testCheckIfLMPIsValid_overlapWithMoreElements() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId()));

        dtoTest.setReplacedRequestListId(replacedRequestListId);

        Map<Boolean, List<String>> impactedElements = this.droolsOperations.checkIfLMP_VU_IsValidForOverlap(this.droolsParams, this.sessionId, this.currentKieSession, dtoTest);
        System.out.println("impactedElemets : " + impactedElements);

        assertTrue(impactedElements.get(false) != null);

    }

    @Test
    public void testCheckIfLMPIsValid_invalid_higherPriority() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.PP);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.LMP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.LMP);

        // is in overlap also with dto3 that isn't inside the list of
        // repleaceable dto
        List<String> replacedRequestListId = new ArrayList<>(Arrays.asList(dto1.getDtoId(), dto2.getDtoId(), dto3.getDtoId()));
        dtoTest.setReplacedRequestListId(replacedRequestListId);

        Map<Boolean, List<String>> impactedElements = this.droolsOperations.checkIfLMP_VU_IsValidForOverlap(this.droolsParams, this.sessionId, this.currentKieSession, dtoTest);
        System.out.println("impactedElemets : " + impactedElements);

        assertTrue(impactedElements.get(false) != null);

    }

    @Test
    public void testCheckIfVUIsValid_invalid_higherPriority() throws Exception
    {

        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("\n\n\n\n running test : testFromDtoToAcqRule");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(1);
        dto1.setSizeH(4000);
        dto1.setPriority(1);
        dto1.setPrType(PRType.VU);
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:57:00", "10/10/2017 16:57:20", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setImageBIC(1);
        dto2.setSizeH(4000);
        dto2.setPriority(2);
        dto2.setPrType(PRType.LMP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:58:20", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setImageBIC(1);
        dto3.setSizeH(4000);
        dto3.setPriority(3);
        dto3.setPrType(PRType.PP);
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dtoTest = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:59:20", "right", "SAT_1");
        dtoTest.setPol(Polarization.HH);
        dtoTest.setImageBIC(1);
        dtoTest.setPriority(4);
        dtoTest.setSizeH(4000);
        dtoTest.setPrType(PRType.VU);

        Map<Boolean, List<String>> impactedElements = this.droolsOperations.checkIfLMP_VU_IsValidForOverlap(this.droolsParams, this.sessionId, this.currentKieSession, dtoTest);
        System.out.println("impactedElemets : " + impactedElements);

        assertTrue(impactedElements.get(false) != null);

    }

    /**
     * Test close all.
     */
    @Test
    public void testCloseAll() throws Exception
    {
        System.out.println("\n\n Running test : testCloseAll");
        /*
         * create a new instance for two different session, and after then close
         * both
         */
        int session1ToClose = 1;
        int session2ToClose = 3;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        // Drools is setted up, but there aren't opened session
        this.droolsOperations.closeAllInstancesForSession(this.sessionId);
        int cont = 0;
        // setup the session for session1ToClose
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, session1ToClose, "_");
        cont++;
        // setup a parallel session for session2ToClose
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, session2ToClose, "_");
        cont++;
        // assert that the number of opened session are two
        System.out.println("number of opened sessions before close : " + SessionHandler.getKieSessionsMap().size());
        assertEquals(cont, SessionHandler.getKieSessionsMap().size());

        // close all the opened sessions
        this.droolsOperations.closeAllInstancesForSession(this.sessionId);

        // assert that, after the close, athere aren't opened sessions
        System.out.println("number of opened sessions after close : " + SessionHandler.getKieSessionsMap().size());
        assertEquals(0, SessionHandler.getKieSessionsMap().size());
    }

    @Test
    public void testCheckIfTheatreIsValid() throws Exception
    {
        int currentKieSession = 1;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, currentKieSession, "_");
        EquivalentDTO equivDto = new EquivalentDTO();

        DTO dto1 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:00", "right", "SAT_1");
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 17:00:00", "left", "SAT_1");
        DTO dto3 = this.du.createSingleDto("10/10/2017 17:36:00", "10/10/2017 17:47:00", "right", "SAT_1");

        List<DTO> allDto = new ArrayList<>();
        allDto.add(dto1);
        allDto.add(dto2);
        allDto.add(dto3);

        List<Maneuver> allmanInsideTheatre = new ArrayList<>();
        Maneuver man = this.du.createManeuver("cmga01", "dto1", "dto2", "10/10/2017 17:36:00", "10/10/2017 17:37:00", "Sat_1", Actuator.CMGA);
        allmanInsideTheatre.add(man);

        equivDto.setAllDtoInEquivalentDto(allDto);
        equivDto.setManAssociated(allmanInsideTheatre);
        equivDto.setStartAndStop();

        boolean theatreIsValid = this.droolsOperations.checkIfTheatreIsValid(equivDto, this.sessionId, currentKieSession, this.droolsParams);
        assertFalse(theatreIsValid);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetAllTasksAcceptedAsMap_noKIeSession() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test O_initialAndFinalMan");
        System.out.println(" mission horizon : " + this.droolsParams.getCurrentMH());

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/09/2017 09:42:00", "10/09/2017 09:43:00", "left", "SAT_1");
        accepted = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        this.rejectedElements = (Map<String, Acquisition>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejectedElement BEFORE " + this.rejectedElements);
        assertEquals(1, this.rejectedElements.size());

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("resource function : " + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        System.out.println("resource function : " + resFunc.getAllManeuversSat1());
        System.out.println("resource function : " + resFunc.getPDHTFunctionAssociatedToSat("SAT_1"));
        SessionHandler.getKieSessionsMap().clear();

        Map<String, Task> taskMap = this.droolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println(taskMap);
    }

    @Test
    public void testSetUpEnvironmenException() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String localRepo = "C:/fakePath";
        boolean pathForTest = true;
        this.droolsOperations.setUpEnvironment(this.sessionId, this.droolsParams, localRepo, pathForTest);
    }

    
    @Test
    public void testSetUpEnvironment() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String localRepo = "configTest/";
        boolean pathForTest = true;
        this.droolsOperations.setUpEnvironment(this.sessionId, this.droolsParams, localRepo, pathForTest);
        this.droolsOperations.getDroolsEnvironment().populateDroolsParameters(this.droolsParams);
    }
    
    @Test
    public void testSetUpEnvironmentException() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        String localRepo = "configTest/";
        boolean pathForTest = true;
        this.droolsOperations.setUpEnvironment(this.sessionId, this.droolsParams, localRepo, pathForTest);
        this.droolsOperations.getDroolsEnvironment().populateDroolsParameters(this.droolsParams);
    }
    
    
    public void testCheckIfDi2sIsFeasible_cannotfoundPartner() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, "fakePartnerId", "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);

        boolean isSlave = true;
        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add("fakePartnerId");
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertFalse(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeasible_sensorModeSpot2MSOS_slave() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner slave = this.droolsParams.getAllPartners().get(0);
        slave.setMaxBICAvailable(30);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave.getPartnerId());
        boolean isSlave = true;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeasible_sensorModeSpot2MSOS_master() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner slave = this.droolsParams.getAllPartners().get(0);
        slave.setMaxBICAvailable(30);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);
        dto1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave.getPartnerId());
        boolean isSlave = false;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeasible_partnerNotFound() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner slave = this.droolsParams.getAllPartners().get(0);
        slave.setMaxBICAvailable(30);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);
        dto1.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add("partnerNotFound");

        boolean isSlave = false;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test(expected = java.lang.NullPointerException.class)
    public void testInsert_Theatre_invalidSession() throws Exception
    {
        System.out.println("\n\n\n\n running test : test testInsert_Theatre_invalidSession");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Date startMH = DroolsUtils.createDate("14/09/2016 06:21:00");
        Date endMH = DroolsUtils.createDate("14/09/2016 18:21:00");
        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTheatreOnADay(1);

        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre2 = new ArrayList<>();

        DTO PR3_AR1_DTO1 = this.du.createSingleDto("14/09/2016 10:52:10", "14/09/2016 10:52:30", "right", satelliteId);
        PR3_AR1_DTO1.setPol(Polarization.HH);
        PR3_AR1_DTO1.setSizeH(4000);
        PR3_AR1_DTO1.setDtoId("PR3_AR1_DTO1");

        DTO PR3_AR2_DTO1 = this.du.createSingleDto("14/09/2016 10:53:00", "14/09/2016 10:53:20", "right", satelliteId);
        PR3_AR2_DTO1.setPol(Polarization.HH);
        PR3_AR2_DTO1.setSizeH(4000);
        PR3_AR2_DTO1.setDtoId("PR3_AR2_DTO1");

        DTO PR3_AR3_DTO1 = this.du.createSingleDto("14/09/2016 10:51:00", "14/09/2016 10:51:20", "right", satelliteId);
        PR3_AR3_DTO1.setPol(Polarization.HH);
        PR3_AR3_DTO1.setSizeH(4000);
        PR3_AR3_DTO1.setDtoId("PR3_AR3_DTO1");

        allDtosIncludedInTheatre2.add(PR3_AR1_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR2_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR3_DTO1);

        EquivalentDTO equivDto2 = new EquivalentDTO();
        equivDto2.setEquivalentDtoId("equivDto2");
        equivDto2.setAllDtoInEquivalentDto(allDtosIncludedInTheatre2);
        equivDto2.setManAssociated(null);
        equivDto2.setEquivType(PRMode.Theatre);
        equivDto2.setStartTime(PR3_AR3_DTO1.getStartTime());
        equivDto2.setEndTime(PR3_AR2_DTO1.getEndTime());

        this.sessionId = "invalidSession";
        boolean validTheatre = this.droolsOperations.insert_Theatre(this.droolsParams, equivDto2, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);
    }

    @Test
    public void testCheckIfDi2sIsFeaasible_slave_SubScribed() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner slave1 = this.droolsParams.getAllPartners().get(0);
        slave1.setMaxBICAvailable(30);

        Partner slave2 = this.droolsParams.getAllPartners().get(1);
        slave2.setMaxBICAvailable(20);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, slave2.getPartnerId(), "ugsId");

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave1.getPartnerId());
        slavePartnersId.add(slave2.getPartnerId());

        boolean isSlave = true;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test
    public void testCheckIfDi2sIsFeaasible_master_SubScribed_MSOS() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Partner slave1 = this.droolsParams.getAllPartners().get(0);
        slave1.setMaxBICAvailable(30);

        Partner slave2 = this.droolsParams.getAllPartners().get(1);
        slave2.setMaxBICAvailable(20);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setDi2s(true);
        dto1.setImageBIC(20);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, slave1.getPartnerId(), "ugsId");
        UserInfo userInfo2 = new UserInfo(null, false, slave2.getPartnerId(), "ugsId");

        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        List<String> slavePartnersId = new ArrayList<>();
        slavePartnersId.add(slave1.getPartnerId());
        slavePartnersId.add(slave2.getPartnerId());

        boolean isSlave = false;
        boolean possible = this.droolsOperations.checkIfDi2sIsFeasible(dto1, slavePartnersId, isSlave, this.droolsParams);
        assertTrue(possible);
    }

    @Test
    public void testCloseAllInstancesForSession() throws Exception
    {
        System.out.println("\n\n Running test : testCloseSession");
        /*
         * create a new instance for two different session, and after then close
         * both
         */
        int fakeSessionToClose = 13;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        // there isn't an opened session with this identifier
        System.out.println("trying to close a session that not exist");
        this.droolsOperations.closeSession(this.sessionId, fakeSessionToClose);

        // the session will be correctly close
        System.out.println("trying to close an existing session");
        this.droolsOperations.closeAllInstancesForSession(this.sessionId);
    }

	@Test
	public void testFilterTasksForMh() throws Exception {
        System.out.println("\n\n\n\n running test : test testInsert_Theatre_invalidSession");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);

        Date startMH = DroolsUtils.createDate("14/09/2016 06:21:00");
        Date endMH = DroolsUtils.createDate("14/09/2016 18:21:00");
        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTheatreOnADay(1);

        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        String satelliteId = "SAT_1";

        DTO PR3_AR1_DTO1 = this.du.createSingleDto("14/09/2016 10:52:10", "14/09/2016 10:52:30", "right", satelliteId);
        PR3_AR1_DTO1.setPol(Polarization.HH);
        PR3_AR1_DTO1.setSizeH(4000);
        PR3_AR1_DTO1.setDtoId("PR3_AR1_DTO1");
        
        boolean accepted = this.droolsOperations.insertDto(this.droolsParams,  PR3_AR1_DTO1, this.sessionId, this.currentKieSession);
        
        
	}


}
