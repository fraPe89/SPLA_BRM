
package com.nais.spla.brm.library.main.drools;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexReason;
import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;
import com.nais.spla.brm.library.main.ontology.resources.CMGA;
import com.nais.spla.brm.library.main.ontology.resources.Partner;

public class DroolsParametersTest
{

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.droolsParams = new DroolsParameters();
    }

    @Test
    public void testSetAllCMGA() throws Exception
    {
        List<CMGA> allCMGA = new ArrayList<>();
        this.droolsParams.setAllCMGA(allCMGA);

        allCMGA = null;
        this.droolsParams.setAllCMGA(allCMGA);
    }

    @Test
    public void testSetAllPartners() throws Exception
    {
        List<Partner> allPartners = new ArrayList<>();
        Partner p1 = new Partner("p1", null, 100, 20);
        Partner p2 = new Partner("p2", null, 100, 20);
        double BICBorrowed = 2.5;
        DebitCard debit = new DebitCard(p2.getPartnerId(), BICBorrowed, "testAcq");
        debit.setPrevious(false);
        p1.getLoanList().add(debit);

        CreditCard credit = new CreditCard(p1.getPartnerId(), BICBorrowed, "testAcq");
        credit.setPrevious(false);
        p2.getGivenLoan().add(credit);
        allPartners = new ArrayList<>(Arrays.asList(p1, p2));
        this.droolsParams.setAllPartners(allPartners);
        assertTrue(p1.getLoanList().get(0).isPrevious());
        assertTrue(p2.getGivenLoan().get(0).isPrevious());
    }

    @Test
    public void testGetMaxTaccForSat() throws Exception
    {
        String satId = "SAT_1";
        this.droolsParams.getMaxTaccForSat(satId);

        satId = "SAT_2";
        this.droolsParams.getMaxTaccForSat(satId);

    }

    @Test
    public void testGetAllCMGAForSat() throws Exception
    {
        String satId = "SAT_1";
        this.droolsParams.getAllCMGAForSat(satId);
        String sessionConcatenated = DroolsParameters.concatenateSession("session", 1);
        assertEquals("session_1", sessionConcatenated);
        
        this.droolsParams.setPreviousMh(true);
        assertEquals(true, this.droolsParams.isPreviousMh());
        
        this.droolsParams.setLastPositionGpsExt(6);
        assertEquals(6, this.droolsParams.getLastPositionGpsExt());

        this.droolsParams.setLastPositionGpsPdm(5);
        assertEquals(5, this.droolsParams.getLastPositionGpsPdm());

        this.droolsParams.setCurrentSession("sessionTest");
        assertEquals("sessionTest", this.droolsParams.getCurrentSession());

        this.droolsParams.setNumberOfSatellites(2);
        assertEquals(2, this.droolsParams.getNumberOfSatellites());

        TreeMap<String, Partner> allPartnersAsMap = new TreeMap<String, Partner> ();
        this.droolsParams.setAllPartnersAsMap(allPartnersAsMap);
        assertEquals(allPartnersAsMap, this.droolsParams.getAllPartnersAsMap());

        this.droolsParams.setDownloadTriggeredFromCSPS(true);
        assertEquals(true, this.droolsParams.isDownloadTriggeredFromCSPS());

        Map<ReasonOfReject, ComplexReason> reasonOfRejectMap=  new HashMap<ReasonOfReject, ComplexReason>();
        DroolsParameters.setReasonOfRejectMap(reasonOfRejectMap);
        assertEquals(reasonOfRejectMap, DroolsParameters.getReasonOfRejectMap());

    }

	@Test
	public void testSetDisableCheckLeftAttitude() throws Exception {
		this.droolsParams.setDisableCheckLeftAttitude("1");
		boolean disableCheck = this.droolsParams.isDisableCheckLeftAttitude();
		assertTrue(disableCheck);
		
		
		this.droolsParams.setDisableCheckLeftAttitude("0");
		disableCheck = this.droolsParams.isDisableCheckLeftAttitude();
		assertFalse(disableCheck);
	}


}
