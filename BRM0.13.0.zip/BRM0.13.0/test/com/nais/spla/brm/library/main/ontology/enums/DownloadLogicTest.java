
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * The Class DownloadLogicTest.
 */
public class DownloadLogicTest
{

    /**
     * Test enum download logic.
     */
    @Test
    public void testEnumDownloadLogic()
    {
        List<DownloadLogic> allDownloadLogicForTest = new ArrayList<>(Arrays.asList(DownloadLogic.DWL, DownloadLogic.GPS, DownloadLogic.PAW, DownloadLogic.PT));
        DownloadLogic[] allDownloadLogic = DownloadLogic.values();
        for (int i = 0; i < allDownloadLogic.length; i++)
        {
            for (int j = 0; j < allDownloadLogicForTest.size(); j++)
            {
                if (allDownloadLogic[i].equals(allDownloadLogicForTest.get(j)))
                {
                    allDownloadLogicForTest.remove(j);
                    j--;
                }
            }
        }

        DownloadLogic type;
        type = DownloadLogic.valueOf("GPS");
        System.out.println("Selected : " + type);

        assertEquals(0, allDownloadLogicForTest.size());
    }

}
