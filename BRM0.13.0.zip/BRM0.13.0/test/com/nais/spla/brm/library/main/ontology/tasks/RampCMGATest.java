
package com.nais.spla.brm.library.main.ontology.tasks;

import org.junit.Test;

public class RampCMGATest
{

    @Test
    public void testRampCMGAStringDateBoolean() throws Exception
    {

    }

}
