
package com.nais.spla.brm.library.main.ontology.enums;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * The Class TypeOfActionTest.
 */
public class TypeOfActionTest
{

    /**
     * Test enum type of acquisition.
     */
    @Test
    public void testEnumTypeOfAcquisition()
    {
        List<TypeOfAcquisition> TypeOfAcquisitiononForTest = new ArrayList<>();
        TypeOfAcquisition[] allTypeOfAcquisition = TypeOfAcquisition.values();
        for (int i = 0; i < allTypeOfAcquisition.length; i++)
        {
            TypeOfAcquisitiononForTest.add(allTypeOfAcquisition[i]);
        }

        TypeOfAcquisition type;
        type = TypeOfAcquisition.valueOf("PINGPONG");
        System.out.println("Selected : " + type);
    }
}
