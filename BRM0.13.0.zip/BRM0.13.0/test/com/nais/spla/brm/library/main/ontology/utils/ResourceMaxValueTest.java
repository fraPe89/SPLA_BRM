
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ResourceMaxValueTest
{

    @Test
    public void testResourceMaxValue() throws Exception
    {
        double minutesForOrbit = 97;
        double maxSilent = 300;
        double maxThreshold = 5000;
        int maxManeuvers = 6;
        int maxManeuversRW = 4;
        int maxManeuversCMGA = 3;
        int maxTheatreinADay = 5;
        double minTimeInEclipse = 20;

        ResourceMaxValue resMaxValue1 = new ResourceMaxValue();
        resMaxValue1.setMaxTheatre(maxTheatreinADay);
        resMaxValue1.setMaxThreshold(maxThreshold);
        resMaxValue1.setMinutesForOrbit(minutesForOrbit);
        resMaxValue1.setMaxManeuvers(maxManeuvers);
        resMaxValue1.setMaxManeuversRW(maxManeuversRW);
        resMaxValue1.setMaxManeuversCMGA(maxManeuversCMGA);
        resMaxValue1.setMaxSilent(maxSilent);
        resMaxValue1.setMinTimeInEclipse(minTimeInEclipse);

        ResourceMaxValue resMaxValue2 = new ResourceMaxValue(minutesForOrbit, maxSilent, maxThreshold, maxManeuvers, maxManeuversRW, maxManeuversCMGA, minTimeInEclipse);
        resMaxValue2.setMaxTheatre(maxTheatreinADay);

        assertEquals(resMaxValue1.toString(), resMaxValue2.toString());

        assertEquals(minTimeInEclipse, resMaxValue2.getMinTimeInEclipse(), 0);
        assertEquals(minutesForOrbit, resMaxValue2.getMinutesForOrbit(), 0);
        assertEquals(maxSilent, resMaxValue2.getMaxSilent(), 0);
        assertEquals(maxThreshold, resMaxValue2.getMaxThreshold(), 0);

        assertEquals(maxManeuvers, resMaxValue2.getMaxManeuvers());
        assertEquals(maxManeuversRW, resMaxValue2.getMaxManeuversRW());
        assertEquals(maxManeuversCMGA, resMaxValue2.getMaxManeuversCMGA());
        assertEquals(maxTheatreinADay, resMaxValue2.getMaxTheatre());

    }
}
