
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.utils.ConfigMaps;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

public class SilentManagementTest
{

    SilentManagement silMng = new SilentManagement();
    TaskPlanned taskPlanned = null;
    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "SilentManagementTest";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.taskPlanned = new TaskPlanned();
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testCreateSilent() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");
        Acquisition current = this.du.createParametricAcquisition("dto1", "10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
        Acquisition previous = this.du.createParametricAcquisition("dto2", "10/10/2017 16:51:00", "10/10/2017 16:52:10", "right", "SAT_1");
        Silent sil = this.silMng.createSilent(current, previous, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        System.out.println(" sil : " + sil);
    }

    @Test
    public void testCreateSilent_based_on_standard() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_standard");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");
        Acquisition current = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:50", "10/10/2017 16:53:00", "right", "SAT_1");
        Acquisition previous = this.du.createParametricAcquisition("dto2", "10/10/2017 16:51:00", "10/10/2017 16:52:10", "right", "SAT_1");
        Silent sil = this.silMng.createSilent(current, previous, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        System.out.println(" sil : " + sil);
    }

    @Test
    public void testCreateSilent_based_on_standard_drools() throws Exception
    {

        // setUp environment
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_standard");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // get the object that contains all the thresholds, standards and
        // minDistances maps
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        // insert first dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 16:52:50", "10/10/2017 16:56:00", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // all silent after the first insert
        List<Silent> allSilents = this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        Silent silAssoc = allSilents.get(0);

        resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("print resource function silents : " + resourceFunctions.getSilentFunctionAssociatedToSat(dto1.getSatelliteId()));
        assertEquals(1, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());

        // dto1 has no previous dto, so it's silent will be based on tStandard
        double tStandard_dto1 = configMap.gettStandardmap().get(TypeOfAcquisition.PINGPONG).get(TypeOfAcquisition.PINGPONG);
        System.out.println("standard time for dto1 : " + tStandard_dto1);

        Date expectedStartTimeSilent = new Date((long) (silAssoc.getEndTime().getTime() - (tStandard_dto1 * 1000)));
        assertEquals(dto1.getStartTime(), silAssoc.getEndTime());
        assertEquals(expectedStartTimeSilent, silAssoc.getStartTime());

        // insert prev dto
        DTO dto2 = this.du.createSingleDto("10/10/2017 16:51:00", "10/10/2017 16:52:45", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        allSilents = this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("all silents : " + allSilents);
        assertEquals(2, allSilents.size());
    }

    @Test
    public void testCreateSilent_based_on_gap() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_gap");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Acquisition current = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        current.setSensorMode(TypeOfAcquisition.PINGPONG);

        Acquisition previous = this.du.createParametricAcquisition("dto2", "10/10/2017 16:51:00", "10/10/2017 16:52:10", "right", "SAT_1");
        previous.setSensorMode(TypeOfAcquisition.QUADPOL);

        double thresholdTime = configMap.gettThresholdMap().get(previous.getSensorMode()).get(current.getSensorMode());

        System.out.println("threshold time in seconds : " + thresholdTime);
        Silent sil = this.silMng.createSilent(current, previous, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        System.out.println(" sil : " + sil);
        resourceFunctions.getEssFunctionAssociatedToSat(current.getSatelliteId()).put(current.getStartTime().getTime(), new EnergyAssociatedToTask(current, 20));
        this.silMng.computeSilentEnergy(sil, current, this.droolsParams, this.droolsParams.getSatWithId(current.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
        System.out.println("updated sil : " + sil);
    }

    @Test
    public void testComputeSilentEnergy() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_gap");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");
        Silent sil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        this.silMng.computeSilentEnergy(sil, acqAssociated, this.droolsParams, this.droolsParams.getSatWithId(acqAssociated.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
    }

    @Test
    public void testComputeSilentEnergy_cannotPerformLoan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_gap");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double maxEssThreshold = 0;
        ResourceMaxValue resMaxValue = this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0);
        resMaxValue.setMaxThreshold(maxEssThreshold);
        resMaxValue.setMaxSilent(maxEssThreshold);

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setSensorMode(TypeOfAcquisition.PINGPONG);

        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");
        Silent sil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        boolean silentPerformed = this.silMng.computeSilentEnergy(sil, acqAssociated, this.droolsParams, this.droolsParams.getSatWithId(acqAssociated.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
        System.out.println("silent performed ? " + silentPerformed);

        assertEquals(false, silentPerformed);
    }

    @Test
    public void testComputeSilentEnergy_AcqInEclipse() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_gap");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setInEclipse(true);

        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Silent sil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        this.silMng.computeSilentEnergy(sil, acqAssociated, this.droolsParams, this.droolsParams.getSatWithId(acqAssociated.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
    }

    @Test
    public void testComputeSilentEnergy_AcqInEclipse_loan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCreateSilent_based_on_gap");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        Map<Double, ResourceMaxValue> checkOnOrbitFortest = new HashMap<>();
        double orbitToCheckForTest = 1;
        double minutesForOrbit = 97;
        double maxSilent = 0;
        double maxThreshold = 300;
        int maxManTot = 4;
        int maxManRW = 3;
        int maxManCMGA = 3;
        double minTimeEclipse = 20;

        ResourceMaxValue resMaxVal = new ResourceMaxValue(minutesForOrbit, maxSilent, maxThreshold, maxManTot, maxManRW, maxManCMGA, minTimeEclipse);
        checkOnOrbitFortest.put(orbitToCheckForTest, resMaxVal);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnOrbitFortest);

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setInEclipse(true);

        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Silent sil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        this.silMng.computeSilentEnergy(sil, acqAssociated, this.droolsParams, this.droolsParams.getSatWithId(acqAssociated.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
    }

    @Test
    public void testComputeSilentEnergy_AcqInEclipse_loan_cannot_give() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testComputeSilentEnergy_AcqInEclipse_loan_cannot_give");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        Map<Double, ResourceMaxValue> checkOnOrbitFortest = new HashMap<>();
        double orbitToCheckForTest = 1;
        double minutesForOrbit = 97;
        double maxSilent = 0;
        double maxThreshold = 300;
        int maxManTot = 4;
        int maxManRW = 3;
        int maxManCMGA = 3;
        double minTimeEclipse = 20;

        ResourceMaxValue resMaxVal = new ResourceMaxValue(minutesForOrbit, maxSilent, maxThreshold, maxManTot, maxManRW, maxManCMGA, minTimeEclipse);
        checkOnOrbitFortest.put(orbitToCheckForTest, resMaxVal);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnOrbitFortest);

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setEss(300);
        acqAssociated.setInEclipse(true);

        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Silent sil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());
        this.silMng.computeSilentEnergy(sil, acqAssociated, this.droolsParams, this.droolsParams.getSatWithId(acqAssociated.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
    }

    @Test
    public void testCheckIfLoanIsSatisfiable() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCheckIfLoanIsSatisfiable");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        TreeMap<Long, EnergyAssociatedToTask> hashMapEss = resourceFunctions.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());

        hashMapEss.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, 100));
        double threshold = 200;
        double requestedAmount = 110;

        boolean available = this.silMng.checkIfLoanIsSatisfiable(this.droolsParams, requestedAmount, 1.0, hashMapEss, acqAssociated, threshold, 97, ReasonOfReject.noEnergyForSilent);
        System.out.println("available : " + available);
        assertTrue(available);
        System.out.println("print acq : " + acqAssociated);

        boolean containReasonOfReject = this.du.checkIfContainsTheReasonOfReject(acqAssociated, ReasonOfReject.noEnergyForSilent);
        assertFalse(containReasonOfReject);
    }

    @Test
    public void testCheckIfLoanIsSatisfiable_notSatisfable() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCheckIfLoanIsSatisfiable");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        TreeMap<Long, EnergyAssociatedToTask> hashMapEss = resourceFunctions.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());
        double requestedAmount = 110;

        hashMapEss.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, requestedAmount));
        double threshold = 100;

        boolean available = this.silMng.checkIfLoanIsSatisfiable(this.droolsParams, requestedAmount, 1.0, hashMapEss, acqAssociated, threshold, 97, ReasonOfReject.noEnergyForSilent);
        System.out.println("available : " + available);
        assertFalse(available);
        System.out.println("print acq : " + acqAssociated);

        boolean containReasonOfReject = this.du.checkIfContainsTheReasonOfReject(acqAssociated, ReasonOfReject.noEnergyForSilent);
        assertTrue(containReasonOfReject);
    }

    @Test
    public void testCheckIfLoanIsSatisfiable_notSatisfable_eclipse() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCheckIfLoanIsSatisfiable");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        TreeMap<Long, EnergyAssociatedToTask> hashMapEss = resourceFunctions.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());
        double requestedAmount = 110;

        hashMapEss.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, requestedAmount));
        double threshold = 100;

        boolean available = this.silMng.checkIfLoanIsSatisfiable(this.droolsParams, requestedAmount, 1.0, hashMapEss, acqAssociated, threshold, 97, ReasonOfReject.noEnergyForSilentInEclipse);
        System.out.println("available : " + available);
        assertFalse(available);
        System.out.println("print acq : " + acqAssociated);

        boolean containReasonOfReject = this.du.checkIfContainsTheReasonOfReject(acqAssociated, ReasonOfReject.noEnergyForSilentInEclipse);
        assertTrue(containReasonOfReject);
    }

    @Test
    public void testRemoveSilent_noLoan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testRemoveSilent");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setEss(500);

        double energyForSilent = 30;
        Silent relatedSil = this.du.createSilent("10/10/2017 16:52:08", "10/10/2017 16:52:13", acqAssociated.getId(), energyForSilent);

        TreeMap<Long, EnergyAssociatedToTask> essFunction = new TreeMap<>();
        TreeMap<Long, EnergyAssociatedToTask> silentFunction = new TreeMap<>();

        essFunction.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, acqAssociated.getEss()));
        silentFunction.put(relatedSil.getStartTime().getTime(), new EnergyAssociatedToTask(relatedSil, relatedSil.getEnergy()));

        assertEquals(1, silentFunction.size());
        assertEquals(1, essFunction.size());
        assertEquals(acqAssociated.getEss(), essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);

        this.silMng.removeSilent(relatedSil, acqAssociated, silentFunction, essFunction);

        assertEquals(0, silentFunction.size());
        assertEquals(1, essFunction.size());
        assertEquals(acqAssociated.getEss(), essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);
    }

    @Test
    public void testRemoveSilent_withLoan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testRemoveSilent_withLoan");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setEss(500);

        double energyForSilent = 30;
        double loanFromEss = 20;
        Silent relatedSil = this.du.createSilent("10/10/2017 16:52:08", "10/10/2017 16:52:13", acqAssociated.getId(), energyForSilent);
        relatedSil.setLoanFromEss(loanFromEss);

        TreeMap<Long, EnergyAssociatedToTask> essFunction = new TreeMap<>();
        TreeMap<Long, EnergyAssociatedToTask> silentFunction = new TreeMap<>();

        essFunction.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, acqAssociated.getEss() + loanFromEss));
        silentFunction.put(relatedSil.getStartTime().getTime(), new EnergyAssociatedToTask(relatedSil, relatedSil.getEnergy() - loanFromEss));

        assertEquals(1, silentFunction.size());
        assertEquals(1, essFunction.size());
        assertEquals(acqAssociated.getEss() + loanFromEss, essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);

        this.silMng.removeSilent(relatedSil, acqAssociated, silentFunction, essFunction);

        assertEquals(0, silentFunction.size());
        assertEquals(1, essFunction.size());
        assertEquals(acqAssociated.getEss(), essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);

    }

    @Test
    public void testRemoveSilentWithLoan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testRemoveSilentWithLoan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        Map<Double, ResourceMaxValue> checkOnOrbitFortest = new HashMap<>();
        double orbitToCheckForTest = 1;
        double minutesForOrbit = 97;
        double maxSilent = 0;
        double maxThreshold = 500;
        int maxManTot = 4;
        int maxManRW = 3;
        int maxManCMGA = 3;
        double minTimeEclipse = 20;

        ResourceMaxValue resMaxVal = new ResourceMaxValue(minutesForOrbit, maxSilent, maxThreshold, maxManTot, maxManRW, maxManCMGA, minTimeEclipse);
        checkOnOrbitFortest.put(orbitToCheckForTest, resMaxVal);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnOrbitFortest);
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        acqAssociated.setEss(200);
        Silent relatedSil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        TreeMap<Long, EnergyAssociatedToTask> essFunction = resourceFunctions.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());
        TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions.getSilentFunctionAssociatedToSat(acqAssociated.getSatelliteId());

        essFunction.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, acqAssociated.getEss()));
        silentFunction.put(relatedSil.getStartTime().getTime(), new EnergyAssociatedToTask(relatedSil, relatedSil.getEnergy()));

        assertEquals(acqAssociated.getEss(), essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);
        this.silMng.computeSilentEnergy(relatedSil, acqAssociated, this.droolsParams, this.droolsParams.getSatWithId(acqAssociated.getSatelliteId()).getSatelliteProperties(), resourceFunctions);
        System.out.println("ess function : " + essFunction);
        assertEquals(acqAssociated.getEss() + relatedSil.getEnergy(), essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);

        assertEquals(relatedSil.getEnergy(), relatedSil.getLoanFromEss(), 0);
        this.silMng.removeSilent(relatedSil, acqAssociated, silentFunction, essFunction);
        assertEquals(acqAssociated.getEss(), essFunction.get(acqAssociated.getStartTime().getTime()).getEssValue(), 0);

    }

    @Test
    public void testCalculateMaxSilentInInterval_exceedMoreThanSilent() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCheckIfLoanIsSatisfiable");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        Map<Double, ResourceMaxValue> checkOnOrbitFortest = new HashMap<>();
        double orbitToCheckForTest = 1;
        double minutesForOrbit = 97;
        double maxSilent = 0;
        double maxThreshold = 500;
        int maxManTot = 4;
        int maxManRW = 3;
        int maxManCMGA = 3;
        double minTimeEclipse = 20;

        ResourceMaxValue resMaxVal = new ResourceMaxValue(minutesForOrbit, maxSilent, maxThreshold, maxManTot, maxManRW, maxManCMGA, minTimeEclipse);
        checkOnOrbitFortest.put(orbitToCheckForTest, resMaxVal);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(checkOnOrbitFortest);
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        Silent relatedSil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        Acquisition acq2 = this.du.createParametricAcquisition("dto1", "10/10/2017 16:59:13", "10/10/2017 17:02:00", "right", "SAT_1");
        acq2.setEss(500);
        Silent silRelatedToAcq2 = this.silMng.createSilent(acq2, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        TreeMap<Long, EnergyAssociatedToTask> essFunction = resourceFunctions.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());
        TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions.getSilentFunctionAssociatedToSat(acqAssociated.getSatelliteId());

        essFunction.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, acqAssociated.getEss()));
        silentFunction.put(relatedSil.getStartTime().getTime(), new EnergyAssociatedToTask(relatedSil, relatedSil.getEnergy()));

        essFunction.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, acq2.getEss()));
        silentFunction.put(silRelatedToAcq2.getStartTime().getTime(), new EnergyAssociatedToTask(silRelatedToAcq2, silRelatedToAcq2.getEnergy()));

        double maxSilentForTest = 0;
        double orbitToCheck = 1;
        long slidingWindow = 97 * 60000;
        this.silMng.calculateMaxSilentInInterval(ReasonOfReject.noEnergyForSilent, orbitToCheck, DroolsParameters.getLogger(), acqAssociated, relatedSil, maxSilentForTest, slidingWindow, silentFunction, resourceFunctions);
    }

    @Test
    public void testCalculateMaxSilentInInterval() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCheckIfLoanIsSatisfiable");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        Silent relatedSil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        Acquisition acq2 = this.du.createParametricAcquisition("dto1", "10/10/2017 16:59:13", "10/10/2017 17:02:00", "right", "SAT_1");
        acq2.setEss(500);
        Silent silRelatedToAcq2 = this.silMng.createSilent(acq2, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        TreeMap<Long, EnergyAssociatedToTask> essFunction = resourceFunctions.getEssFunctionAssociatedToSat(acqAssociated.getSatelliteId());
        TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions.getSilentFunctionAssociatedToSat(acqAssociated.getSatelliteId());

        essFunction.put(acqAssociated.getStartTime().getTime(), new EnergyAssociatedToTask(acqAssociated, acqAssociated.getEss()));
        silentFunction.put(relatedSil.getStartTime().getTime(), new EnergyAssociatedToTask(relatedSil, relatedSil.getEnergy()));

        essFunction.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, acq2.getEss()));
        silentFunction.put(silRelatedToAcq2.getStartTime().getTime(), new EnergyAssociatedToTask(silRelatedToAcq2, silRelatedToAcq2.getEnergy()));

        double maxSilentForTest = 1;
        double orbitToCheck = 1;
        long slidingWindow = 97 * 60000;
        this.silMng.calculateMaxSilentInInterval(ReasonOfReject.noEnergyForSilent, orbitToCheck, DroolsParameters.getLogger(), acqAssociated, relatedSil, maxSilentForTest, slidingWindow, silentFunction, resourceFunctions);
    }

    @Test
    public void testCalculateMaxSilentInInterval_functionIsEmpty() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testCheckIfLoanIsSatisfiable");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        ConfigMaps configMap = (ConfigMaps) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "configMaps");

        Acquisition acqAssociated = this.du.createParametricAcquisition("dto1", "10/10/2017 16:52:13", "10/10/2017 16:56:00", "right", "SAT_1");
        Silent relatedSil = this.silMng.createSilent(acqAssociated, null, this.droolsParams, configMap.getPowerSensorMode(), configMap.gettStandardmap(), configMap.gettThresholdMap());

        Acquisition acq2 = this.du.createParametricAcquisition("dto1", "10/10/2017 16:59:13", "10/10/2017 17:02:00", "right", "SAT_1");
        acq2.setEss(500);
        TreeMap<Long, EnergyAssociatedToTask> silentFunction = resourceFunctions.getSilentFunctionAssociatedToSat(acqAssociated.getSatelliteId());

        double maxSilentForTest = 1;
        double orbitToCheck = 1;
        long slidingWindow = 97 * 60000;
        this.silMng.calculateMaxSilentInInterval(ReasonOfReject.noEnergyForSilent, orbitToCheck, DroolsParameters.getLogger(), acqAssociated, relatedSil, maxSilentForTest, slidingWindow, silentFunction, resourceFunctions);
    }

    @Test
    public void testGetMaximumValueOfLoanForSilent_loan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testGetMaximumValueOfLoanForSilent_loan");
        List<Double> maxValuesSW = new ArrayList<>();
        maxValuesSW.add(23.0);
        maxValuesSW.add(2.0);
        maxValuesSW.add(37.0);
        maxValuesSW.add(21.0);

        double returnedMaxValue = this.silMng.getMaximumValueOfLoanForSilent(maxValuesSW);
        assertEquals(37.0, returnedMaxValue, 0);
    }

    @Test
    public void testGetMaximumValueOfLoanForSilent_noLoan() throws Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : testGetMaximumValueOfLoanForSilent_noLoan");
        List<Double> maxValuesSW = new ArrayList<>();

        double returnedMaxValue = this.silMng.getMaximumValueOfLoanForSilent(maxValuesSW);
        assertEquals(0.0, returnedMaxValue, 0);
    }

}
