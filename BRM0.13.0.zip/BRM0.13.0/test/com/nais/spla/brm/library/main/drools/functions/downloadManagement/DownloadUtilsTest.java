
package com.nais.spla.brm.library.main.drools.functions.downloadManagement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.SectorAndVisForPartner;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class DownloadUtilsTest.
 */
public class DownloadUtilsTest
{

    private StubResources stub = new StubResources();

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The dwl utils. */
    private DownloadUtils dwlUtils = new DownloadUtils();

    DownloadManagement dwlMng = new DownloadManagement();

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestDownloadUtilsRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    public Visibility createParametricVisibility(long contactCounter, String satelliteId, String acqStatId, String ownerId, String start, String end)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        // initialize start and stop
        Date startTime = null;
        Date endTime = null;
        try
        {
            // parse the date for the start
            startTime = formatter.parse(start);
            // parse the date for the end
            endTime = formatter.parse(end);
        }
        catch (ParseException e)
        {
            // catch the exception
            e.printStackTrace();
        }
        // create a new visibility with the parsed data
        Visibility vis = new Visibility(contactCounter, satelliteId, acqStatId, ownerId, startTime, endTime);
        return vis;
    }

    /**
     * Test sort visibility list.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void sortVisibilityList() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : SortVisibilityList \n\n");

        List<Visibility> visibilitiesInOverlap = new ArrayList<>();
        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Kir", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "Kir", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "Kir", null, "10/10/2017 07:00:00", "10/10/2017 08:01:00");
        visibilitiesInOverlap.add(vis1);
        visibilitiesInOverlap.add(vis2);
        visibilitiesInOverlap.add(vis3);

        assertEquals(vis1, visibilitiesInOverlap.get(0));
        assertEquals(vis2, visibilitiesInOverlap.get(1));
        assertEquals(vis3, visibilitiesInOverlap.get(2));

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 12:00:00", "10/10/2017 12:00:00", "left", "sat1");
        this.dwlUtils.sortVisibilityList(visibilitiesInOverlap, acq1);

        assertEquals(1, visibilitiesInOverlap.size());
        assertEquals(vis1, visibilitiesInOverlap.get(0));

    }

    /**
     * Test extract all partners relative to acq.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testExtractAllPartnersRelativeToAcq() throws Exception
    {
        System.out.println("Running Test : testExtractAllPartnersRelativeToAcq \n\n");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partner1 = this.droolsParams.getAllPartners().get(1);
        Partner partner2 = this.droolsParams.getAllPartners().get(2);

        List<UserInfo> userInfoToSearch = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, true, partner1.getPartnerId(), "KIR");
        UserInfo userInfo2 = new UserInfo(null, true, partner2.getPartnerId(), "KIR");
        userInfoToSearch.add(userInfo1);
        userInfoToSearch.add(userInfo2);

        List<Partner> returnedPartners = this.dwlUtils.extractAllPartnersRelativeToAcq(userInfoToSearch, this.droolsParams);
        assertEquals(2, returnedPartners.size());
        assertEquals(true, returnedPartners.contains(partner1));
        assertEquals(true, returnedPartners.contains(partner2));

    }

    /**
     * Test check if contains delete dwl related to ps contained.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void checkIfContainsDeleteDwlRelatedToPs_contained_Test() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        PacketStore packet = new PacketStore("relatedToStoId");
        packet.setPolarization(Polarization.HH);

        List<Download> onlyDeleteDwlForSto = new ArrayList<>();
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl1.setPol(Polarization.VV);
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl2.setPol(Polarization.HH);
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.DELETE, false);
        dwl3.setPol(Polarization.HH);
        Download dwl4 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.DELETE, false);
        dwl4.setPol(Polarization.VV);

        onlyDeleteDwlForSto.add(dwl1);
        onlyDeleteDwlForSto.add(dwl2);
        onlyDeleteDwlForSto.add(dwl3);
        onlyDeleteDwlForSto.add(dwl4);

        Download returnedDwl = this.dwlUtils.checkIfContainsDeleteDwlRelatedToPs(onlyDeleteDwlForSto, packet);
        assertEquals(dwl3, returnedDwl);
    }

    /**
     * Test check if contains delete dwl related to ps not contained.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void checkIfContainsDeleteDwlRelatedToPs_not_contained_Test() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        PacketStore packet = new PacketStore("relatedToStoId");
        List<Download> onlyDeleteDwlForSto = new ArrayList<>();

        Download returnedDwl = this.dwlUtils.checkIfContainsDeleteDwlRelatedToPs(onlyDeleteDwlForSto, packet);
        assertEquals(null, returnedDwl);
    }

    /**
     * Test sort tasks by start time.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testSortTasksByStartTime() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<Task> allDownloadsToSort = new ArrayList<>();

        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 09:00:00", "17/01/2018 09:10:00", DownlinkStrategy.RETAIN, false);
        dwl1.setInitialSector(0);

        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 08:55:00", "17/01/2018 08:59:00", DownlinkStrategy.RETAIN, false);
        dwl2.setInitialSector(30);

        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 07:37:37", "17/01/2018 07:50:00", DownlinkStrategy.DELETE, true);
        dwl3.setInitialSector(15);

        allDownloadsToSort.add(dwl1);
        allDownloadsToSort.add(dwl2);
        allDownloadsToSort.add(dwl3);

        assertEquals(dwl1, allDownloadsToSort.get(0));
        assertEquals(dwl2, allDownloadsToSort.get(1));
        assertEquals(dwl3, allDownloadsToSort.get(2));

        DownloadUtils.sortTasksByStartTime(allDownloadsToSort);

        assertEquals(dwl3, allDownloadsToSort.get(0));
        assertEquals(dwl2, allDownloadsToSort.get(1));
        assertEquals(dwl1, allDownloadsToSort.get(2));
    }

    /**
     * Test find all vis in overlap with date.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testFindAllVisInOverlapWithDate() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 10:55:00", "17/01/2018 11:06:00");
        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "Kir", null, "17/01/2018 11:12:00", "17/01/2018 11:18:00");
        Visibility vis3 = this.stub.createVisibility(3, "SAT_2", "Kir", null, "17/01/2018 11:00:00", "17/01/2018 11:20:00");
        Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", "Partner_2", "17/01/2018 11:40:00", "17/01/2018 12:01:00");
        Visibility vis5 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 11:17:00", "17/01/2018 11:27:00");

        List<Visibility> allVisibilities = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        Date startCheck = DroolsUtils.createDate("17/01/2018 11:04:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 11:20:00");

        List<Visibility> allVisInOVerlap = this.dwlUtils.findAllVisInOverlapWithDate(startCheck, endCheck, allVisibilities, "SAT_1");
        assertEquals(3, allVisInOVerlap.size());
        assertEquals(true, allVisInOVerlap.contains(vis1)); // borderline case
                                                            // start
        assertEquals(true, allVisInOVerlap.contains(vis2)); // overlap
        assertEquals(false, allVisInOVerlap.contains(vis3)); // different
                                                             // satellite
        assertEquals(false, allVisInOVerlap.contains(vis4)); // not in overlap
        assertEquals(true, allVisInOVerlap.contains(vis5)); // borderline case
                                                            // end

    }

    /**
     * Test find all vis in overlap with date null case.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testFindAllVisInOverlapWithDate_Null_Case() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 10:55:00", "17/01/2018 11:06:00");
        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "Kir", null, "17/01/2018 11:12:00", "17/01/2018 11:18:00");
        Visibility vis3 = this.stub.createVisibility(3, "SAT_2", "Kir", null, "17/01/2018 10:00:00", "17/01/2018 10:20:00");
        Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", "Partner_2", "17/01/2018 11:40:00", "17/01/2018 12:01:00");
        Visibility vis5 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 11:17:00", "17/01/2018 11:27:00");

        List<Visibility> allVisibilities = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        Date startCheck = DroolsUtils.createDate("17/01/2018 10:00:00");
        Date endCheck = DroolsUtils.createDate("17/01/2018 10:20:00");

        List<Visibility> allVisInOVerlap = this.dwlUtils.findAllVisInOverlapWithDate(startCheck, endCheck, allVisibilities, "SAT_1");
        assertEquals(0, allVisInOVerlap.size());
        assertEquals(false, allVisInOVerlap.contains(vis1)); // not in overlap
        assertEquals(false, allVisInOVerlap.contains(vis2)); // not in overlap
        assertEquals(false, allVisInOVerlap.contains(vis3)); // different
                                                             // satellite
        assertEquals(false, allVisInOVerlap.contains(vis4)); // not in overlap
        assertEquals(false, allVisInOVerlap.contains(vis5)); // not in overlap

    }

    /**
     * Test get only dwl for pol.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testGetOnlyDwlForPol() throws Exception
    {
        /*
         * create dummies tasks
         */
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 10:00:00", "17/01/2018 10:00:00", DownlinkStrategy.DELETE, true);
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 12:00:00", "17/01/2018 12:00:00", DownlinkStrategy.DELETE, true);
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 11:00:00", "17/01/2018 11:00:00", DownlinkStrategy.DELETE, true);

        /*
         * assign a polarization to the created tasks
         */
        dwl1.setPol(Polarization.VH);
        dwl2.setPol(Polarization.HH);
        dwl3.setPol(Polarization.VV);

        List<Task> allTasksToProcess = new ArrayList<Task>(Arrays.asList(dwl1, dwl2, dwl3));

        List<Task> onlyTaskWithPolHH = this.dwlUtils.getOnlyDwlForPol(allTasksToProcess, Polarization.HH);

        assertEquals(1, onlyTaskWithPolHH.size());
        assertEquals(dwl2, onlyTaskWithPolHH.get(0));
    }

    /**
     * Test get only dwl for pol not found.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testGetOnlyDwlForPol_not_found() throws Exception
    {
        /*
         * create dummies tasks
         */
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 10:00:00", "17/01/2018 10:00:00", DownlinkStrategy.DELETE, true);
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 12:00:00", "17/01/2018 12:00:00", DownlinkStrategy.DELETE, true);
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 11:00:00", "17/01/2018 11:00:00", DownlinkStrategy.DELETE, true);

        /*
         * assign a polarization to the created tasks
         */
        dwl1.setPol(Polarization.VH);
        dwl2.setPol(Polarization.HV);
        dwl3.setPol(Polarization.VV);

        List<Task> allTasksToProcess = new ArrayList<Task>(Arrays.asList(dwl1, dwl2, dwl3));

        List<Task> onlyTaskWithPolHH = this.dwlUtils.getOnlyDwlForPol(allTasksToProcess, Polarization.HH);

        assertEquals(0, onlyTaskWithPolHH.size());
    }

    /**
     * Test get only delete dwl.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testGetOnlyDeleteDwl() throws Exception
    {
        /*
         * create dummies tasks
         */
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 10:00:00", "17/01/2018 10:00:00", DownlinkStrategy.DELETE, true);
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 12:00:00", "17/01/2018 12:00:00", DownlinkStrategy.RETAIN, true);
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 11:00:00", "17/01/2018 11:00:00", DownlinkStrategy.DELETE, true);

        List<Download> allTasksToProcess = new ArrayList<>(Arrays.asList(dwl1, dwl2, dwl3));

        List<Download> onlyTaskMarkedAsDeleted = this.dwlUtils.getOnlyDeleteDwl(allTasksToProcess);

        assertEquals(2, onlyTaskMarkedAsDeleted.size());
        assertEquals(dwl1, onlyTaskMarkedAsDeleted.get(0));
        assertEquals(dwl3, onlyTaskMarkedAsDeleted.get(1));
    }

    /**
     * Test get only delete dwl not found.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void testGetOnlyDeleteDwl_not_found() throws Exception
    {
        /*
         * create dummies tasks
         */
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 10:00:00", "17/01/2018 10:00:00", DownlinkStrategy.RETAIN, true);
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 12:00:00", "17/01/2018 12:00:00", DownlinkStrategy.RETAIN, true);
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 11:00:00", "17/01/2018 11:00:00", DownlinkStrategy.RETAIN, true);

        List<Download> allTasksToProcess = new ArrayList<>(Arrays.asList(dwl1, dwl2, dwl3));

        List<Download> onlyTaskMarkedAsDeleted = this.dwlUtils.getOnlyDeleteDwl(allTasksToProcess);

        assertEquals(0, onlyTaskMarkedAsDeleted.size());
    }

    @Test
    public void testFindNextPtOnSameVisAndSameLink_EmptyVis() throws Exception
    {
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

        Visibility vis = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 07:00:00");

        List<Date> returnedDate = this.dwlUtils.findNextPtOnSameVisAndSameLink(acq1.getStartTime(), acq1.getSatelliteId(), vis, vis.getLinkMoreEmpty(), downloadTreeMap);
        assertEquals(vis.getEndTime(), returnedDate.get(0));
        assertEquals(vis.getEndTime(), returnedDate.get(1));

    }

    @Test
    public void testFindNextPtOnSameVisAndSameLink_EmptyCase() throws Exception
    {
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();

        Visibility vis = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 07:00:00");

        List<Date> returnedDate = this.dwlUtils.findNextPtOnSameVisAndSameLink(acq1.getStartTime(), acq1.getSatelliteId(), vis, vis.getLinkMoreEmpty(), downloadTreeMap);
        assertEquals(vis.getEndTime(), returnedDate.get(0));
        assertEquals(vis.getEndTime(), returnedDate.get(1));
    }

//    @Test
//    public void testGetAllDownloadPlannedOnVisOnLinkExceptPt() throws Exception
//    {
//        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> downloadTreeMap = new TreeMap<>();
//
//        Visibility vis = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 07:00:00");
//        Date startTimeDwl = DroolsUtils.createDate("10/10/2017 06:00:00");
//        Date endTimeDwl = DroolsUtils.createDate("10/10/2017 06:05:00");
//
//        TreeMap<String, TreeMap<Long, IDownload>> subMap = new TreeMap<>();
//        TreeMap<Long, IDownload> elementsOnLink = new TreeMap<>();
//
//        elementsOnLink.put(new Date().getTime(), new IDownload("referredAcqID", DownloadLogic.DWL, true, startTimeDwl, endTimeDwl, null));
//
//        subMap.put("1", elementsOnLink);
//        String contactCounterForVis = DownloadManagement.concatVisId(vis.getSatelliteId(), vis);
//
//        downloadTreeMap.put(contactCounterForVis, subMap);
//
//        this.dwlUtils.getAllDownloadPlannedOnVisOnLinkExceptPt(downloadTreeMap, vis, vis.getLinkMoreEmpty());
//    }

    @Test
    public void testFindIfThereArePartOfDownloadOnExternalStation_true() throws Exception
    {
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setPolarization(Polarization.HH);

        Visibility vis1 = this.createParametricVisibility(0, "SAT_1", "KIR", "p1", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        vis1.setExternal(true);
        Visibility vis2 = this.createParametricVisibility(1, "SAT_1", "KIR", "p2", "10/10/2017 07:00:00", "10/10/2017 07:30:00");
        vis2.setExternal(false);
        Visibility vis3 = this.createParametricVisibility(1, "SAT_1", "K0R", "p3", "10/10/2017 05:40:00", "10/10/2017 05:50:00");
        vis3.setExternal(true);

        List<Visibility> visAssociatedToDto = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));

        List<Task> localDownloads = new ArrayList<>();

        // same acq, same partner, external vis, different pol
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl1.getUgsOwnerList().add("p1");
        dwl1.setAcqStatId(vis1.getAcqStatId());
        dwl1.setContactCounter(vis1.getContactCounter());
        dwl1.setRelatedTaskId(acq1.getIdTask());
        dwl1.setPol(Polarization.VV);

        // same acq, different partner, external vis, same pol
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl2.getUgsOwnerList().add("p3");
        dwl2.setAcqStatId(vis1.getAcqStatId());
        dwl2.setRelatedTaskId(acq1.getIdTask());
        dwl2.setContactCounter(vis1.getContactCounter());
        dwl2.setPol(Polarization.HH);

        // different acq, same partner, external vis, same pol
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.DELETE, false);
        dwl3.getUgsOwnerList().add("p1");
        dwl3.setAcqStatId(vis3.getAcqStatId());
        dwl3.setRelatedTaskId("anotherAcq");
        dwl3.setContactCounter(vis3.getContactCounter());
        dwl3.setPol(Polarization.HH);

        // same acq, same partner, not external vis, same pol
        Download dwl4 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.DELETE, false);
        dwl4.getUgsOwnerList().add("p1");
        dwl4.setAcqStatId(vis2.getAcqStatId());
        dwl4.setRelatedTaskId(acq1.getIdTask());
        dwl4.setContactCounter(vis2.getContactCounter());
        dwl4.setPol(Polarization.VV);

        // same acq, same partner, external vis, same pol
        Download dwl5 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl5.getUgsOwnerList().add("p1");
        dwl5.setAcqStatId(vis1.getAcqStatId());
        dwl5.setContactCounter(vis1.getContactCounter());
        dwl5.setRelatedTaskId(acq1.getIdTask());
        dwl5.setPol(Polarization.HH);

        localDownloads.add(dwl1);
        localDownloads.add(dwl2);
        localDownloads.add(dwl3);
        localDownloads.add(dwl4);
        localDownloads.add(dwl5);

        boolean othersDwlOnExternalVis = this.dwlUtils.findIfThereArePartOfDownloadOnExternalStation(acq1.getIdTask(), Polarization.HH, "p1", visAssociatedToDto, localDownloads);
        assertTrue(othersDwlOnExternalVis);
    }

    @Test
    public void testFindIfThereArePartOfDownloadOnExternalStation_false() throws Exception
    {
        Acquisition acq1 = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO-", "17/01/2018 11:10:03", "17/01/2018 11:12:00", "left", "SAT_1");
        acq1.setPolarization(Polarization.HH);

        Visibility vis1 = this.createParametricVisibility(0, "SAT_1", "KIR", "p1", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        vis1.setExternal(true);
        Visibility vis2 = this.createParametricVisibility(1, "SAT_1", "KIR", "p2", "10/10/2017 07:00:00", "10/10/2017 07:30:00");
        vis2.setExternal(false);
        Visibility vis3 = this.createParametricVisibility(1, "SAT_1", "K0R", "p3", "10/10/2017 05:40:00", "10/10/2017 05:50:00");
        vis3.setExternal(true);

        List<Visibility> visAssociatedToDto = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));

        List<Task> localDownloads = new ArrayList<>();

        // same acq, same partner, external vis, different pol
        Download dwl1 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl1.getUgsOwnerList().add("p1");
        dwl1.setAcqStatId(vis1.getAcqStatId());
        dwl1.setContactCounter(vis1.getContactCounter());
        dwl1.setRelatedTaskId(acq1.getIdTask());
        dwl1.setPol(Polarization.VV);

        // same acq, different partner, external vis, same pol
        Download dwl2 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.RETAIN, false);
        dwl2.getUgsOwnerList().add("p3");
        dwl2.setAcqStatId(vis1.getAcqStatId());
        dwl2.setRelatedTaskId(acq1.getIdTask());
        dwl2.setContactCounter(vis1.getContactCounter());
        dwl2.setPol(Polarization.HH);

        // different acq, same partner, external vis, same pol
        Download dwl3 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.DELETE, false);
        dwl3.getUgsOwnerList().add("p1");
        dwl3.setAcqStatId(vis3.getAcqStatId());
        dwl3.setRelatedTaskId("anotherAcq");
        dwl3.setContactCounter(vis3.getContactCounter());
        dwl3.setPol(Polarization.HH);

        // same acq, same partner, not external vis, same pol
        Download dwl4 = this.du.createDownload("SAT_1", "17/01/2018 06:00:00", "17/01/2018 06:00:00", DownlinkStrategy.DELETE, false);
        dwl4.getUgsOwnerList().add("p1");
        dwl4.setAcqStatId(vis2.getAcqStatId());
        dwl4.setRelatedTaskId(acq1.getIdTask());
        dwl4.setContactCounter(vis2.getContactCounter());
        dwl4.setPol(Polarization.VV);

        localDownloads.add(dwl1);
        localDownloads.add(dwl2);
        localDownloads.add(dwl3);
        localDownloads.add(dwl4);
        boolean othersDwlOnExternalVis = this.dwlUtils.findIfThereArePartOfDownloadOnExternalStation(acq1.getIdTask(), Polarization.HH, "p1", visAssociatedToDto, localDownloads);
        assertFalse(othersDwlOnExternalVis);
    }

    @Test
    public void testFilterVisForMh() throws Exception
    {
        Visibility vis1 = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 07:00:00", "10/10/2017 07:30:00");
        Visibility vis3 = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 05:40:00", "10/10/2017 05:50:00");

        List<Visibility> visAssociatedToDto = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        Date startTimeDwl = DroolsUtils.createDate("10/10/2017 06:20:00");
        Date endTimeDwl = DroolsUtils.createDate("10/10/2017 07:02:00");

        MissionHorizon currentMH = new MissionHorizon();
        currentMH.setStart(startTimeDwl);
        currentMH.setStop(endTimeDwl);

        assertEquals(3, visAssociatedToDto.size());

        List<Visibility> filteredVis = this.dwlUtils.filterVisForMh(visAssociatedToDto, currentMH);

        assertEquals(2, filteredVis.size());
        assertTrue(filteredVis.contains(vis1));
        assertTrue(filteredVis.contains(vis2));
        assertFalse(filteredVis.contains(vis3));

    }

    @Test
    public void testFilterVisForMh_noVis() throws Exception
    {
        Visibility vis1 = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 07:00:00", "10/10/2017 07:30:00");
        Visibility vis3 = this.createParametricVisibility(1l, "SAT_1", "KIR", null, "10/10/2017 07:20:00", "10/10/2017 07:50:00");

        List<Visibility> visAssociatedToDto = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        Date startTimeDwl = DroolsUtils.createDate("10/10/2017 08:20:00");
        Date endTimeDwl = DroolsUtils.createDate("10/10/2017 08:50:00");

        MissionHorizon currentMH = new MissionHorizon();
        currentMH.setStart(startTimeDwl);
        currentMH.setStop(endTimeDwl);

        assertEquals(3, visAssociatedToDto.size());

        List<Visibility> filteredVis = this.dwlUtils.filterVisForMh(visAssociatedToDto, currentMH);

        assertEquals(0, filteredVis.size());
        assertFalse(filteredVis.contains(vis1));
        assertFalse(filteredVis.contains(vis2));
        assertFalse(filteredVis.contains(vis3));

    }

    @Test
    public void testGetAllPt() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();

        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = stubRes.createVisibility(3, "SAT_1", "KIR", null, "10/10/2017 17:59:00", "10/10/2017 18:02:00");
        vis4.setExternal(true);
        Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7));

        this.droolsParams.setAllVisibilities(allVisForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        // primo pt
        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
        dto1.setSizeH(330);

        dto1.setImageBIC(3);
        dto1.setPtAvailable(true);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // standard acq

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:57:00", "10/10/2017 17:57:10", "right", "SAT_1");
        dto2.setSizeH(400);

        dto2.setImageBIC(3);
        dto2.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // second pt

        DTO dto3 = this.du.createSingleDto("10/10/2017 17:59:00", "10/10/2017 17:59:50", "right", "SAT_1");
        dto3.setSizeH(400);
        dto3.setImageBIC(3);
        dto3.setPtAvailable(true);
        dto3.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        boolean validCheck = false;
        List<PassThrough> allPt = new ArrayList<>();
        allPt = this.dwlUtils.getAllPt(this.sessionId + "_" + this.currentKieSession, "SAT_1");

        // allPt = DownloadUtils.getAllPt(this.sessionId,
        // this.currentKieSession, "SAT_1");
        System.out.println("allPt :" + allPt);
        assertEquals(allPt.size(), 2);
        if ((allPt.get(0).getIdTask().equalsIgnoreCase(dto3.getDtoId()) || allPt.get(0).getIdTask().equalsIgnoreCase(dto1.getDtoId())) && (allPt.get(1).getIdTask().equalsIgnoreCase(dto3.getDtoId()) || allPt.get(1).getIdTask().equalsIgnoreCase(dto1.getDtoId())))
        {
            validCheck = true;
        }
        assertTrue(validCheck);

    }

    @Test
    public void testGetAllVisFromADate_usePartnerVis() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 06:10:00", "10/10/2017 06:40:00");

        this.droolsParams.getAllVisibilities().add(vis1);
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 07:52:00", "10/10/2017 07:53:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        List<String> allVisForTest = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));

        Partner partnerRelatedToVis = this.droolsParams.getAllPartners().get(0);
        acq1.setPreferredVis(allVisForTest);
        partnerRelatedToVis.setAllVisForPartner(allVisForTest);
        
        UserInfo userInfo = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), "KIR");
        userInfoList.add(userInfo);
        acq1.setUserInfo(userInfoList);
        TreeMap<String, Visibility> allReturnedVis = this.dwlUtils.getAllVisFromADate(null, acq1, this.droolsParams.getAllPartners().get(0), this.droolsParams);
        assertEquals(2, allReturnedVis.size());
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis1)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis2)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis3)) == null);
        assertEquals(2, allReturnedVis.size());

    }

    @Test
    public void testGetAllVisFromADate_visAssociated() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 06:10:00", "10/10/2017 06:40:00");

        this.droolsParams.getAllVisibilities().add(vis1);
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 07:52:00", "10/10/2017 07:53:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), "KIR");
        userInfoList.add(userInfo);
        acq1.setUserInfo(userInfoList);
        TreeMap<String, Visibility> allReturnedVis = this.dwlUtils.getAllVisFromADate(null, acq1, this.droolsParams.getAllPartners().get(0), this.droolsParams);
        assertEquals(2, allReturnedVis.size());
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis1)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis2)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis3)) == null);
        assertEquals(2, allReturnedVis.size());

    }

    @Test
    public void testGetAllVisFromADate_visAssociated_BackUp() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 22:10:00", "10/10/2017 22:40:00");

        this.droolsParams.getAllVisibilities().add(vis1);
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 07:52:00", "10/10/2017 07:53:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), "KIR");
        userInfoList.add(userInfo);
        acq1.setUserInfo(userInfoList);
        TreeMap<String, Visibility> allReturnedVis = this.dwlUtils.getAllVisFromADate(null, acq1, this.droolsParams.getAllPartners().get(0), this.droolsParams);
        assertEquals(2, allReturnedVis.size());
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis1)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis2)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis3)) == null);
        assertEquals(2, allReturnedVis.size());

    }

    @Test
    public void testGetAllVisFromADate_backUp() throws Exception
    {

        this.sessionId = "testGetAllVisFromADate_backUp";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        Partner p3 = this.droolsParams.getAllPartners().get(2);

        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 06:10:00", "10/10/2017 06:40:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "COR", p2.getPartnerId(), "10/10/2017 16:10:00", "10/10/2017 16:40:00");
        Visibility vis5 = this.stub.createVisibility(3, "SAT_1", "KIR", p3.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:40:00");

        this.droolsParams.getAllVisibilities().add(vis1);
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);
        this.droolsParams.getAllVisibilities().add(vis4);
        this.droolsParams.getAllVisibilities().add(vis5);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:52:00", "10/10/2017 08:53:00", "left", "SAT_1");
        dto1.setBackupVis(new ArrayList<>(Arrays.asList(vis4.getAcqStatId(), vis5.getAcqStatId())));

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo = new UserInfo(null, false, p1.getPartnerId(), "KIR");
        userInfoList.add(userInfo);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Download> allDwlAssoc = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println(allDwlAssoc);
        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println(allTasks);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 08:52:00", "10/10/2017 08:53:00", "left", "SAT_1");
        acq1.setBackupVis(new ArrayList<>(Arrays.asList(vis4.getAcqStatId(), vis5.getAcqStatId())));
        acq1.setUserInfo(userInfoList);

        TreeMap<String, Visibility> allReturnedVis = this.dwlUtils.getAllVisFromADate(null, acq1, p1, this.droolsParams);
        assertEquals(2, allReturnedVis.size());
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis1)) == null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis2)) == null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis3)) == null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis4)) != null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis5)) != null);
        assertEquals(2, allReturnedVis.size());

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testGetAllVisFromADate_noVis() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 06:10:00", "10/10/2017 06:40:00");

        this.droolsParams.getAllVisibilities().add(vis1);
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        Acquisition acq1 = this.du.createParametricAcquisition("dto1", "10/10/2017 08:52:00", "10/10/2017 08:53:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        UserInfo userInfo = new UserInfo(null, false, p1.getPartnerId(), "KIR");
        userInfoList.add(userInfo);
        acq1.setUserInfo(userInfoList);
        TreeMap<String, Visibility> allReturnedVis = this.dwlUtils.getAllVisFromADate(null, acq1, p1, this.droolsParams);
        assertEquals(0, allReturnedVis.size());
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis1)) == null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis2)) == null);
        assertTrue(allReturnedVis.get(this.dwlUtils.visKey(vis3)) == null);

    }

    @Test
    public void testGetAllDownloadPlannedOnVis() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> dwlTreeMap = resFunc.getDwlFunctionAssociatedToSat(vis1.getSatelliteId());

        List<IDownload> allDwlOnVis0 = this.dwlUtils.getAllDownloadPlannedOnVis(dwlTreeMap, vis0);
        List<IDownload> allDwlOnVis1 = this.dwlUtils.getAllDownloadPlannedOnVis(dwlTreeMap, vis1);
        List<IDownload> allDwlOnVis2 = this.dwlUtils.getAllDownloadPlannedOnVis(dwlTreeMap, vis2);
        List<IDownload> allDwlOnVis3 = this.dwlUtils.getAllDownloadPlannedOnVis(dwlTreeMap, vis3);

        for (int i = 0; i < allDwlOnVis0.size(); i++)
        {
            System.out.println("DWL ON VIS :" + allDwlOnVis0.get(i));
        }

        assertEquals(1, allDwlOnVis0.size());
        assertEquals(0, allDwlOnVis1.size());
        assertEquals(0, allDwlOnVis2.size());
        assertEquals(1, allDwlOnVis3.size());

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:42:00", "10/10/2017 06:43:10", "right", "SAT_1");
        dto2.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList2 = new ArrayList<>();
        userInfoList2.add(userInfo1);
        userInfoList2.add(userInfo2);
        dto2.setUserInfo(userInfoList2);
        dto2.setPriority(4);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

    }

    @Test
    public void testRestorePriorityQueueOfRelatedAmount_increment() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();
        Acquisition acquisition = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        List<Download> allDwl = resFunc.getDownloadAssociatedToSat("SAT_1");

        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("DWL :" + allDwl.get(i));
        }

        Download currentDwl = allDwl.get(0);
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        PriorityQueue partner1Before = priorityQueue.get(this.dwlMng.getPriorityKey(acquisition));

        SectorAndVisForPartner sectorsForP1B = partner1Before.getSectorsNeededForPartners().get("Partner_1");
        assertEquals(0, sectorsForP1B.getSectorsForPartner().get(0).getResidualSize());

        SectorAndVisForPartner sectorsForP2B = partner1Before.getSectorsNeededForPartners().get("Partner_2");
        assertEquals(0, sectorsForP2B.getSectorsForPartner().get(0).getResidualSize());
        HashMap<String, Acquisition> allAcceptedAcq = new HashMap<>();

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        allAcceptedAcq.put(acq.getIdTask(), acq);
        //
        // partner1Before =
        // this.dwlUtils.restorePriorityQueueOfRelatedAmount(resFunc.getDownloadPriorityQueueForSat("SAT_1"),
        // currentDwl, allAcceptedAcq, 1);
        //
        // PriorityQueue partner1after =
        // priorityQueue.put(dwlMng.getPriorityKey(acquisition),
        // partner1Before);
        //
        // SectorAndVisForPartner sectorsForP1 =
        // partner1after.getSectorsNeededForPartners().get("Partner_1");
        // assertEquals(0,
        // sectorsForP1.getSectorsForPartner().get(0).getResidualSize());
        //
        // SectorAndVisForPartner sectorsForP2 =
        // partner1after.getSectorsNeededForPartners().get("Partner_2");
        // assertEquals(0,
        // sectorsForP2.getSectorsForPartner().get(0).getResidualSize());

    }

    @Test
    public void testRestorePriorityQueueOfRelatedAmount_decrement() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition acquisition = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        List<Download> allDwl = resFunc.getDownloadAssociatedToSat("SAT_1");

        Download currentDwl = allDwl.get(0);
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        PriorityQueue partner1Before = priorityQueue.get(this.dwlMng.getPriorityKey(acquisition));

        SectorAndVisForPartner sectorsForP1B = partner1Before.getSectorsNeededForPartners().get("Partner_1");
        assertEquals(0, sectorsForP1B.getSectorsForPartner().get(0).getResidualSize());

        SectorAndVisForPartner sectorsForP2B = partner1Before.getSectorsNeededForPartners().get("Partner_2");
        assertEquals(0, sectorsForP2B.getSectorsForPartner().get(0).getResidualSize());
        HashMap<String, Acquisition> allAcceptedAcq = new HashMap<>();

        Acquisition acq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        allAcceptedAcq.put(acq.getIdTask(), acq);
        // this.dwlUtils.restorePriorityQueueOfRelatedAmount(resFunc.getDownloadPriorityQueueForSat("SAT_1"),
        // currentDwl, allAcceptedAcq, 0);
        //
        // PriorityQueue partner1after =
        // priorityQueue.get(dwlMng.getPriorityKey(acquisition));
        //
        // SectorAndVisForPartner sectorsForP1 =
        // partner1after.getSectorsNeededForPartners().get("Partner_1");
        // assertEquals(0,
        // sectorsForP1.getSectorsForPartner().get(0).getResidualSize());
        //
        // SectorAndVisForPartner sectorsForP2 =
        // partner1after.getSectorsNeededForPartners().get("Partner_2");
        // assertEquals(0,
        // sectorsForP2.getSectorsForPartner().get(0).getResidualSize());

    }

    @Test
    public void addAllExternalTest() throws Exception
    {
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        vis0.setExternal(true);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", "Partner1", "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        vis1.setExternal(false);
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", "Partner2", "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        vis2.setExternal(false);
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        vis3.setExternal(true);
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));
        List<Visibility> visAssociatedToDto = new ArrayList<>(Arrays.asList(vis0, vis1));

        this.dwlUtils.addAllExternal(visAssociatedToDto, allVis);
    }

    /*
     * @Test public void restoreVisTest() throws Exception { Visibility vis1 =
     * this.stub.createVisibility(0, "SAT_1", "KIR","Partner1",
     * "10/10/2017 07:10:00", "10/10/2017 07:12:00");vis1.setExternal(false);
     * vis1.setAvailableStartTimeL1(du.createDate("10/10/2017 07:11:00"));
     * vis1.setAvailableStartTimeL2(du.createDate("10/10/2017 07:11:30"));
     *
     * dwlUtils.restoreVis(vis1);
     * assertEquals(vis1.getStartTime(),vis1.getAvailableStartTimeL1());
     * assertEquals(vis1.getStartTime(),vis1.getAvailableStartTimeL2()); }
     */
    @Test
    public void visKeyTest() throws Exception
    {
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", "Partner1", "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        vis1.setExternal(false);
        String visKey = "1507612200000_0_KIR_SAT_1";
        String returnedString = this.dwlUtils.visKey(vis1);
        assertEquals(visKey, returnedString);
    }

    @Test
    public void testFilterVisGetOnlyValid() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition acquisition = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());

        TreeMap<String, Visibility> allValidVis = this.dwlUtils.filterVisGetOnlyValid(allVis, acquisition, p1);
        System.out.println(allValidVis);
    }

    @Test
    public void testAddAllExternal() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition acquisition = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());

        TreeMap<String, Visibility> allValidVis = this.dwlUtils.filterVisGetOnlyValid(allVis, acquisition, p1);
        System.out.println(allValidVis);
        
    }
    

    @Test
    public void testAddAllExternal_noVisssociatedToDto() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> visAssociatedToDto = new ArrayList<>();
        List<Visibility> allExternal = new ArrayList<>(Arrays.asList(vis0,vis3));
        List<Visibility> mixedVis = new ArrayList<>(Arrays.asList(vis0, vis3));

        List<Visibility> allVisReturned = new ArrayList<>();
        allVisReturned = dwlUtils.addAllExternal(visAssociatedToDto, allExternal);
        assertEquals(mixedVis.size(),allVisReturned.size());
        
    }
    

    @Test
    public void testAddAllExternal_visssociatedToDto() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> visAssociatedToDto = new ArrayList<>(Arrays.asList( vis1, vis2));
        List<Visibility> allExternal = new ArrayList<>(Arrays.asList(vis0, vis3));
        List<Visibility> mixedVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<Visibility> allVisReturned = new ArrayList<>();
        allVisReturned = dwlUtils.addAllExternal(visAssociatedToDto, allExternal);
        assertEquals(mixedVis.size(),allVisReturned.size());
        
    }

    @Test
    public void testGetAllVisFromADate() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);
        dto1.setPriority(5);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition acquisition = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());

        TreeMap<String, Visibility> allValidVis = this.dwlUtils.filterVisGetOnlyValid(allVis, acquisition, p1);
        System.out.println(allValidVis);
        
    }

}
