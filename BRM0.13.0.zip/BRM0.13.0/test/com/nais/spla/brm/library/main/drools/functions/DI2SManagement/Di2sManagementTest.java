
package com.nais.spla.brm.library.main.drools.functions.DI2SManagement;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;

public class Di2sManagementTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private double maxBicForTest = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private StubResources stub = new StubResources();
    private Di2sManagement di2sMng = new Di2sManagement();

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "di2s";
        this.maxBicForTest = 200;
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;

        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testAcceptDi2s_invalidSession() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, "fakeSession", this.currentKieSession);
        System.out.println(inserted);
        assertFalse(inserted);
    }

    @Test
    public void testAcceptDi2s_invalidInstance() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;
        this.currentKieSession = 1;
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);
        this.currentKieSession = 10;
        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
        assertFalse(inserted);
    }

    @Test
    public void testAcceptDi2s_MasterWasAccepted() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
    }

    @Test
    public void testAcceptDi2s_SubScribed() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
    }

    @Test
    public void testAcceptDi2s__noBicForMAsterAndSlave() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        partnerMaster.setMaxBICAvailable(1);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);
        partnerSlave.setMaxBICAvailable(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        assertFalse(inserted);
        System.out.println(inserted);
    }

    @Test
    public void testAcceptDi2s_SubScribed_noBicFor1Slave() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
    }

    @Test
    public void testAcceptDi2s_equivIsDI2S() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
    }

    @Test
    public void testAcceptDi2s_Di2S_inTrainLeft() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
    }

    @Test
    public void testAcceptDi2s_sameMasterAndSlave() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:56:20", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerMaster.getPartnerId());
        userInfoSlave.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
        assertEquals(true, inserted);

        assertEquals(totalBicForEquivDto, this.droolsParams.getAllPartners().get(0).getUsedBIC(), 0);
        List<Download> allDwlForDto = this.droolsInstance.receiveAllDownloadAssociatedToDto(master.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);

        System.out.println(allDwlForDto);
    }

    @Test
    public void testAcceptDi2s_notBicMaster() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        partnerMaster.setMaxBICAvailable(0);

        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
        assertFalse(inserted);
    }

    @Test
    public void testAcceptDi2s_notBicSlave() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);
        partnerSlave.setMaxBICAvailable(10);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
        assertFalse(inserted);
    }

    @Test
    public void testAcceptDi2s_equivIsDI2S_noSlaveAssoc() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
        assertFalse(inserted);
    }

    @Test
    public void testAcceptDi2s_equivIsNOTDI2S() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        // equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.Exp);
        equivDto.setDi2sInfo(di2sInfo);

        boolean inserted = this.di2sMng.insertDi2s(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println(inserted);
        assertFalse(inserted);
    }

    @Test
    public void testInsertDi2s() throws Exception
    {

    }

    @Test
    public void testRetractMaster() throws Exception
    {

    }

    @Test
    public void testRemoveDi2s() throws Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        // equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        // boolean inserted = di2sMng.removeDi2s(currentKieSession, rejected,
        // equivalentDto);
        // System.out.println(inserted);
    }


}
