
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;

public class PacketStoreTest
{

    @Test
    public void testPacketStore() throws Exception
    {
        Polarization polarization = Polarization.H_H;

        String associatedStoId = "stoForTest";

        int usedSectors = 0;

        int residualSectors = 0;

        int size = 0;

        MemoryModule mem1 = new MemoryModule("mem0", 20);
        MemoryModule mem2 = new MemoryModule("mem1", 20);

        Map<MemoryModule, Long> plannedOnMemModule = new HashMap<>();
        plannedOnMemModule.put(mem1, 5l);
        plannedOnMemModule.put(mem2, 5l);

        PacketStore packet1 = new PacketStore(associatedStoId);
        packet1.setSize(size);
        packet1.setPolarization(polarization);
        packet1.setUsedSectors(usedSectors);
        packet1.setResidualSectors(residualSectors);
        packet1.setPlannedOnMemModule(plannedOnMemModule);

        PacketStore packet2 = new PacketStore(associatedStoId, polarization);
        packet2.setSize(size);
        packet2.setUsedSectors(usedSectors);
        packet2.setResidualSectors(residualSectors);
        packet2.setPlannedOnMemModule(plannedOnMemModule);

        PacketStore packet3 = new PacketStore(associatedStoId, polarization, size);
        packet3.setUsedSectors(usedSectors);
        packet3.setResidualSectors(residualSectors);
        packet3.setPlannedOnMemModule(plannedOnMemModule);
        packet3.setAssociatedStoId(associatedStoId);
        System.out.println(packet3.getResidualSectors());

        assertEquals(packet1.toString(), packet2.toString());
        assertEquals(packet1.getAssociatedStoId(), packet3.getAssociatedStoId());
        assertTrue(packet3.getPlannedOnMemModule().size() == 2);
        assertEquals(10, packet3.getSize());
    }

}
