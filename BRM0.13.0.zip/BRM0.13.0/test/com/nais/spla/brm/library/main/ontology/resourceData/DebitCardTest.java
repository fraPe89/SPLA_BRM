
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class DebitCardTest

{

    @Test
    public void createDebitCard()
    {

        String creditorId = "debitorTest";

        double BICBorrowed = 20;

        String forAcq = "acqId";

        boolean donation = false;

        boolean isPrevious = false;

        DebitCard debit = new DebitCard(creditorId, BICBorrowed, forAcq);
        debit.setDonation(donation);
        debit.setPrevious(isPrevious);
        debit.setBICBorrowed(BICBorrowed);
        assertEquals(BICBorrowed, debit.getBICBorrowed(), 0);
        assertEquals(creditorId, debit.getCreditor());
        assertEquals(forAcq, debit.getForAcq());
        assertEquals(isPrevious, debit.isPrevious());
        assertEquals(donation, debit.isDonation());
        System.out.println(debit.toString());
    }
}
