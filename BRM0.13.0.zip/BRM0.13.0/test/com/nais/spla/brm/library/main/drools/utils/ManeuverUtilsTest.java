
package com.nais.spla.brm.library.main.drools.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.ManeuverResources;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PlanningResources;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;

public class ManeuverUtilsTest
{

    DroolsUtils du = new DroolsUtils();
    StubResources stubRes = new StubResources();
    ManeuverUtils manUtils = new ManeuverUtils();

    @Test
    public void testAllManInInterval_borderlineCase() throws Exception
    {
        Date fromAsDate = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date toAsDate = DroolsUtils.createDate("10/10/2017 08:40:00");
        long from = fromAsDate.getTime();
        long to = toAsDate.getTime();
        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();

        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "10/10/2017 06:06:00", "10/10/2017 06:09:00", "SAT_1", Actuator.CMGA);
        Maneuver secondMan = this.du.createManeuver("man2", "null", "acq1", "10/10/2017 06:39:00", "10/10/2017 06:43:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver thirdMan = this.du.createManeuver("man3", "null", "acq1", "10/10/2017 07:36:00", "10/10/2017 07:40:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver fourthMan = this.du.createManeuver("man4", "null", "acq1", "10/10/2017 08:40:01", "10/10/2017 08:44:01", "SAT_1", Actuator.CMGA);

        allManRelatedToSat.put(firstMan.getStartTime().getTime(), firstMan);
        allManRelatedToSat.put(secondMan.getStartTime().getTime(), secondMan);
        allManRelatedToSat.put(thirdMan.getStartTime().getTime(), thirdMan);
        allManRelatedToSat.put(fourthMan.getStartTime().getTime(), fourthMan);

        List<Maneuver> returnedManFromMethod = new ArrayList<>();

        returnedManFromMethod = this.manUtils.allManInInterval(from, to, allManRelatedToSat);

        assertEquals(2, returnedManFromMethod.size());

        assertEquals(false, returnedManFromMethod.contains(firstMan));
        assertEquals(true, returnedManFromMethod.contains(secondMan));
        assertEquals(true, returnedManFromMethod.contains(thirdMan));
        assertEquals(false, returnedManFromMethod.contains(fourthMan));
    }

    @Test
    public void testAllManInInterval() throws Exception
    {
        Date fromAsDate = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date toAsDate = DroolsUtils.createDate("10/10/2017 08:40:00");
        long from = fromAsDate.getTime();
        long to = toAsDate.getTime();
        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();

        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "10/10/2017 06:06:00", "10/10/2017 06:09:00", "SAT_1", Actuator.CMGA);
        Maneuver secondMan = this.du.createManeuver("man2", "null", "acq1", "10/10/2017 07:06:00", "10/10/2017 07:09:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver thirdMan = this.du.createManeuver("man3", "null", "acq1", "10/10/2017 07:36:00", "10/10/2017 07:40:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver fourthMan = this.du.createManeuver("man4", "null", "acq1", "10/10/2017 08:40:00", "10/10/2017 08:44:00", "SAT_1", Actuator.CMGA);

        allManRelatedToSat.put(firstMan.getStartTime().getTime(), firstMan);
        allManRelatedToSat.put(secondMan.getStartTime().getTime(), secondMan);
        allManRelatedToSat.put(thirdMan.getStartTime().getTime(), thirdMan);
        allManRelatedToSat.put(fourthMan.getStartTime().getTime(), fourthMan);

        List<Maneuver> returnedManFromMethod = new ArrayList<>();

        returnedManFromMethod = this.manUtils.allManInInterval(from, to, allManRelatedToSat);

        assertEquals(3, returnedManFromMethod.size());

        assertEquals(false, returnedManFromMethod.contains(firstMan));
        assertEquals(true, returnedManFromMethod.contains(secondMan));
        assertEquals(true, returnedManFromMethod.contains(thirdMan));
        assertEquals(true, returnedManFromMethod.contains(thirdMan));
    }

    @Test
    public void testAllManInInterval_nullCase() throws Exception
    {
        Date fromAsDate = DroolsUtils.createDate("10/10/2017 16:40:00");
        Date toAsDate = DroolsUtils.createDate("10/10/2017 18:40:00");
        long from = fromAsDate.getTime();
        long to = toAsDate.getTime();
        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();

        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "10/10/2017 06:06:00", "10/10/2017 06:09:00", "SAT_1", Actuator.CMGA);
        Maneuver secondMan = this.du.createManeuver("man2", "null", "acq1", "10/10/2017 06:39:00", "10/10/2017 06:43:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver thirdMan = this.du.createManeuver("man3", "null", "acq1", "10/10/2017 07:36:00", "10/10/2017 07:40:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver fourthMan = this.du.createManeuver("man4", "null", "acq1", "10/10/2017 08:40:01", "10/10/2017 08:44:01", "SAT_1", Actuator.CMGA);

        allManRelatedToSat.put(firstMan.getStartTime().getTime(), firstMan);
        allManRelatedToSat.put(secondMan.getStartTime().getTime(), secondMan);
        allManRelatedToSat.put(thirdMan.getStartTime().getTime(), thirdMan);
        allManRelatedToSat.put(fourthMan.getStartTime().getTime(), fourthMan);

        List<Maneuver> returnedManFromMethod = new ArrayList<>();

        returnedManFromMethod = this.manUtils.allManInInterval(from, to, allManRelatedToSat);

        assertEquals(0, returnedManFromMethod.size());

        assertEquals(false, returnedManFromMethod.contains(firstMan));
        assertEquals(false, returnedManFromMethod.contains(secondMan));
        assertEquals(false, returnedManFromMethod.contains(thirdMan));
        assertEquals(false, returnedManFromMethod.contains(thirdMan));
    }

    @Test
    public void testGetSatId() throws Exception
    {
        String satelliteId = "SAT_1";

        // curr is null
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", satelliteId);
        String expectedSatId = null;
        expectedSatId = this.manUtils.getSatId(prev, null);
        assertEquals("SAT_1", expectedSatId);

        // prev is null
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "right", satelliteId);
        expectedSatId = null;
        expectedSatId = this.manUtils.getSatId(null, curr);
        assertEquals("SAT_1", expectedSatId);
    }

    @Test
    public void testCheckBorderlineCase_Man_Counted_Start() throws Exception
    {
        boolean insertable = false;
        MissionHorizon mh = this.stubRes.createMH("17/01/2018 11:07:00", "17/01/2018 14:05:00");
        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:06:00", "17/01/2018 11:09:00", "SAT_1", Actuator.CMGA);
        insertable = this.manUtils.checkBorderlineCaseStart(firstMan, mh.getStart().getTime(), true);
        assertTrue(insertable);
    }

    @Test
    public void testCheckBorderlineCase_Man_Not_Counted_Start() throws Exception
    {
        boolean insertable = false;
        MissionHorizon mh = this.stubRes.createMH("17/01/2018 11:07:00", "17/01/2018 14:05:00");
        Maneuver firstMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:04:00", "17/01/2018 11:06:00", "SAT_1", Actuator.CMGA);
        insertable = this.manUtils.checkBorderlineCaseStart(firstMan, mh.getStart().getTime(), true);
        assertFalse(insertable);
    }

    @Test
    public void testReceiveManeuverType_CMGA() throws Exception
    {
        Actuator manType = this.manUtils.receiveActuatorType("cmga");
        assertEquals(Actuator.CMGA, manType);
    }

    @Test
    public void testReceiveManeuverType_RW() throws Exception
    {
        Actuator manType = this.manUtils.receiveActuatorType("rw");
        assertEquals(Actuator.ReactionWheels, manType);
    }

    @Test
    public void testReceiveManeuverType_total() throws Exception
    {
        Actuator manType = this.manUtils.receiveActuatorType("total");
        assertEquals(Actuator.total, manType);
    }

    @Test
    public void testAddReasonOfReject_remove_Prev_exist_current() throws Exception
    {
        ReasonOfReject potentialReason = ReasonOfReject.maxNumberOfCMGAManeuverReached;
        Acquisition prev = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        Acquisition curr = this.du.createParametricAcquisition("Dto2", "10/10/2017 06:49:00", "10/10/2017 06:52:00", "left", "SAT_1");
        assertTrue(curr.getReasonOfReject().isEmpty());
        curr.addReasonOfReject(1, potentialReason, "descr", 0, 0, null);

        assertEquals(0, prev.getReasonOfReject().size());
    }

    @Test
    public void testMergeListOverlappedElements() throws Exception
    {

        PAW paw1 = this.stubRes.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        PAW paw2 = this.stubRes.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stubRes.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.GENERIC);
        PAW paw4 = this.stubRes.createPaw(2, "SAT_2", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.GENERIC);
        List<PAW> allPawInTest = new ArrayList<>(Arrays.asList(paw1, paw2, paw3, paw4));

        Visibility vis1 = this.stubRes.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = this.stubRes.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stubRes.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stubRes.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");

        List<Visibility> allVisInTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));

        List<PlanningResources> mergedPawAndVis = this.manUtils.mergeListOverlappedElements(allVisInTest, allPawInTest);
        assertEquals(8, mergedPawAndVis.size());
    }

    @Test
    public void testMergeListOverlappedElements_emptyCase() throws Exception
    {
        List<PAW> allPawInTest = new ArrayList<>();
        List<Visibility> allVisInTest = new ArrayList<>();
        List<PlanningResources> mergedPawAndVis = this.manUtils.mergeListOverlappedElements(allVisInTest, allPawInTest);
        assertEquals(0, mergedPawAndVis.size());
    }

    @Test
    public void testClearManRes() throws Exception
    {
        ManeuverResources manRes = new ManeuverResources();
        List<Maneuver> oldMans = new ArrayList<>();
        List<Maneuver> newMans = new ArrayList<>();
        List<RampCMGA> oldRumps = new ArrayList<>();
        List<RampCMGA> newRumps = new ArrayList<>();

        RampCMGA oldRump = this.du.createRamp("10/10/2017 06:40:00", true);
        oldRumps.add(oldRump);
        manRes.setOldRumps(oldRumps);

        RampCMGA newRamp = this.du.createRamp("10/10/2017 06:30:00", true);
        newRumps.add(newRamp);
        manRes.setNewRumps(newRumps);

        Maneuver oldMan = this.du.createManeuver("man001", "acq1", "acq2", "10/10/2017 06:30:00", "10/10/2017 06:34:00", "SAT_1", Actuator.CMGA);
        oldMans.add(oldMan);
        manRes.setOldMans(oldMans);

        Maneuver newMan = this.du.createManeuver("man002", "acq1", "acq2", "10/10/2017 06:32:00", "10/10/2017 06:36:00", "SAT_1", Actuator.CMGA);
        newMans.add(newMan);
        manRes.setNewMans(newMans);

        assertEquals(1, manRes.getNewMans().size());
        assertEquals(1, manRes.getNewRumps().size());
        assertEquals(1, manRes.getOldMans().size());
        assertEquals(1, manRes.getOldRumps().size());

        this.manUtils.clearManRes(manRes);

        assertEquals(0, manRes.getNewMans().size());
        assertEquals(0, manRes.getNewRumps().size());
        assertEquals(0, manRes.getOldMans().size());
        assertEquals(0, manRes.getOldRumps().size());

    }

    @Test
    public void testAddGapToListIfIsValid_valid() throws Exception
    {
        long timeForCmga = 4 * 60;
        TreeMap<Date, Date> startAndStop = new TreeMap<>();
        Date from = DroolsUtils.createDate("10/10/2017 06:40:00");
        long gap = 5 * 60;

        assertEquals(0, startAndStop.size());

        this.manUtils.addGapToListIfIsValid(timeForCmga, startAndStop, from, gap);

        assertEquals(1, startAndStop.size());
        Date to = new Date(from.getTime() + (gap * 1000));
        assertEquals(to, startAndStop.get(from));

    }

    @Test
    public void testAddGapToListIfIsValid_invalid() throws Exception
    {
        long timeForCmga = 4 * 60;
        TreeMap<Date, Date> startAndStop = new TreeMap<>();
        Date from = DroolsUtils.createDate("10/10/2017 06:40:00");
        long gap = 2 * 60;

        assertEquals(0, startAndStop.size());
        this.manUtils.addGapToListIfIsValid(timeForCmga, startAndStop, from, gap);
        assertEquals(0, startAndStop.size());
    }

    @Test
    public void testSortOverlappedElementList() throws Exception
    {
        Visibility vis1 = this.stubRes.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        PAW paw1 = this.stubRes.createPaw(1, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw2 = this.stubRes.createPaw(2, "SAT_1", "10/10/2017 06:21:00", "10/10/2017 06:45:00", PAWType.GENERIC);

        List<PlanningResources> elementsInOVerlap = new ArrayList<>();
        elementsInOVerlap.add(vis1);
        elementsInOVerlap.add(paw1);
        elementsInOVerlap.add(paw2);

        this.manUtils.sortOverlappedElementList(elementsInOVerlap);
        assertEquals(paw2, elementsInOVerlap.get(0));
        assertEquals(vis1, elementsInOVerlap.get(1));
        assertEquals(paw1, elementsInOVerlap.get(2));

    }

    @Test
    public void testInsertNeManInmanRes_found() throws Exception
    {
        Maneuver newMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:06:00", "17/01/2018 11:09:00", "SAT_1", Actuator.CMGA);
        ManeuverResources manRes = new ManeuverResources();

        manRes.getNewMans().add(newMan);
        assertEquals(1, manRes.getNewMans().size());

        this.manUtils.insertNeManInmanRes(newMan, manRes);
        assertEquals(1, manRes.getNewMans().size());
    }

    @Test
    public void testInsertNeManInmanRes_notFound() throws Exception
    {
        Maneuver newMan = this.du.createManeuver("man1", "null", "acq1", "17/01/2018 11:06:00", "17/01/2018 11:09:00", "SAT_1", Actuator.CMGA);
        ManeuverResources manRes = new ManeuverResources();

        assertEquals(0, manRes.getNewMans().size());

        this.manUtils.insertNeManInmanRes(newMan, manRes);
        assertEquals(1, manRes.getNewMans().size());
    }

    @Test
    public void testFindElement_starts_with_rw_asc() throws Exception
    {
        DateResource dateRes = new DateResource();
        TreeMap<Date, Date> startAndStop = new TreeMap<>();

        Date interval1_1 = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date interval1_2 = DroolsUtils.createDate("10/10/2017 06:42:00");

        Date interval2_1 = DroolsUtils.createDate("10/10/2017 06:20:00");
        Date interval2_2 = DroolsUtils.createDate("10/10/2017 06:22:00");

        Date interval3_1 = DroolsUtils.createDate("10/10/2017 06:50:00");
        Date interval3_2 = DroolsUtils.createDate("10/10/2017 06:59:00");

        startAndStop.put(interval1_1, interval1_2);
        startAndStop.put(interval2_1, interval2_2);
        startAndStop.put(interval3_1, interval3_2);

        boolean startWithRw = true;
        long timeForRw = 6 * 60;
        long timeForCMGA = 4 * 60;
        boolean ascending = true;
        dateRes = this.manUtils.findElement(dateRes, startAndStop, startWithRw, timeForRw, timeForCMGA, ascending);
    }

    @Test
    public void testFindElement_starts_with_rw_asc_try_With_cmga() throws Exception
    {
        DateResource dateRes = new DateResource();
        TreeMap<Date, Date> startAndStop = new TreeMap<>();

        Date interval1_1 = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date interval1_2 = DroolsUtils.createDate("10/10/2017 06:42:00");

        Date interval2_1 = DroolsUtils.createDate("10/10/2017 06:20:00");
        Date interval2_2 = DroolsUtils.createDate("10/10/2017 06:25:00");

        Date interval3_1 = DroolsUtils.createDate("10/10/2017 06:50:00");
        Date interval3_2 = DroolsUtils.createDate("10/10/2017 06:55:00");

        startAndStop.put(interval1_1, interval1_2);
        startAndStop.put(interval2_1, interval2_2);
        startAndStop.put(interval3_1, interval3_2);

        boolean startWithRw = true;
        long timeForRw = 6 * 60;
        long timeForCMGA = 4 * 60;
        boolean ascending = true;
        dateRes = this.manUtils.findElement(dateRes, startAndStop, startWithRw, timeForRw, timeForCMGA, ascending);
    }

    @Test
    public void testFindElement_starts_with_rw_desc() throws Exception
    {
        DateResource dateRes = new DateResource();
        TreeMap<Date, Date> startAndStop = new TreeMap<>();

        Date interval1_1 = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date interval1_2 = DroolsUtils.createDate("10/10/2017 06:42:00");

        Date interval2_1 = DroolsUtils.createDate("10/10/2017 06:20:00");
        Date interval2_2 = DroolsUtils.createDate("10/10/2017 06:22:00");

        Date interval3_1 = DroolsUtils.createDate("10/10/2017 06:50:00");
        Date interval3_2 = DroolsUtils.createDate("10/10/2017 06:59:00");

        startAndStop.put(interval1_1, interval1_2);
        startAndStop.put(interval2_1, interval2_2);
        startAndStop.put(interval3_1, interval3_2);

        boolean startWithRw = true;
        long timeForRw = 6 * 60;
        long timeForCMGA = 4 * 60;
        boolean ascending = false;
        dateRes = this.manUtils.findElement(dateRes, startAndStop, startWithRw, timeForRw, timeForCMGA, ascending);
    }

    @Test
    public void testFindElement_starts_with_cmga_asc() throws Exception
    {
        DateResource dateRes = new DateResource();
        TreeMap<Date, Date> startAndStop = new TreeMap<>();

        Date interval1_1 = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date interval1_2 = DroolsUtils.createDate("10/10/2017 06:42:00");

        Date interval2_1 = DroolsUtils.createDate("10/10/2017 06:20:00");
        Date interval2_2 = DroolsUtils.createDate("10/10/2017 06:22:00");

        Date interval3_1 = DroolsUtils.createDate("10/10/2017 06:50:00");
        Date interval3_2 = DroolsUtils.createDate("10/10/2017 06:59:00");

        startAndStop.put(interval1_1, interval1_2);
        startAndStop.put(interval2_1, interval2_2);
        startAndStop.put(interval3_1, interval3_2);

        boolean startWithRw = false;
        long timeForRw = 6 * 60;
        long timeForCMGA = 4 * 60;
        boolean ascending = true;
        dateRes = this.manUtils.findElement(dateRes, startAndStop, startWithRw, timeForRw, timeForCMGA, ascending);
    }

    @Test
    public void testFindElement_starts_with_cmga_desc() throws Exception
    {
        DateResource dateRes = new DateResource();
        TreeMap<Date, Date> startAndStop = new TreeMap<>();

        Date interval1_1 = DroolsUtils.createDate("10/10/2017 06:40:00");
        Date interval1_2 = DroolsUtils.createDate("10/10/2017 06:42:00");

        Date interval2_1 = DroolsUtils.createDate("10/10/2017 06:20:00");
        Date interval2_2 = DroolsUtils.createDate("10/10/2017 06:22:00");

        Date interval3_1 = DroolsUtils.createDate("10/10/2017 06:50:00");
        Date interval3_2 = DroolsUtils.createDate("10/10/2017 06:59:00");

        startAndStop.put(interval1_1, interval1_2);
        startAndStop.put(interval2_1, interval2_2);
        startAndStop.put(interval3_1, interval3_2);

        boolean startWithRw = false;
        long timeForRw = 6 * 60;
        long timeForCMGA = 4 * 60;
        boolean ascending = false;

        dateRes = this.manUtils.findElement(dateRes, startAndStop, startWithRw, timeForRw, timeForCMGA, ascending);
    }

    @Test
    public void testComputeAscendingOrDiscending_otherAcq_before_current() throws Exception
    {
        Acquisition current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition otherAcq = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:20:00", "10/10/2017 06:21:00", "left", "SAT_1");
        Date toDate = null;
        boolean ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(false, ascending);

        current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(true, ascending);
    }

    @Test
    public void testComputeAscendingOrDiscending_otherAcq_after_current() throws Exception
    {
        Acquisition current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition otherAcq = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:55:00", "10/10/2017 06:56:00", "left", "SAT_1");
        Date toDate = null;
        boolean ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(true, ascending);

        current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(false, ascending);
    }

    @Test
    public void testComputeAscendingOrDiscending_otherAcq_is_null_date_after_current() throws Exception
    {
        Acquisition current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition otherAcq = null;
        Date toDate = DroolsUtils.createDate("10/10/2017 06:55:00");
        boolean ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(true, ascending);

        current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(false, ascending);
    }

    @Test
    public void testComputeAscendingOrDiscending_otherAcq_is_null_date_before_current() throws Exception
    {
        Acquisition current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "left", "SAT_1");
        Acquisition otherAcq = null;
        Date toDate = DroolsUtils.createDate("10/10/2017 06:20:00");
        boolean ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(false, ascending);

        current = this.du.createParametricAcquisition("Dto1", "10/10/2017 06:40:00", "10/10/2017 06:42:00", "right", "SAT_1");
        ascending = this.manUtils.computeAscendingOrDiscending(current, otherAcq, toDate);
        assertEquals(true, ascending);
    }

}
