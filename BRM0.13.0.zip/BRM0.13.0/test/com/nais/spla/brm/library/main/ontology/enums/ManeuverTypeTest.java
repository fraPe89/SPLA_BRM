
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * The Class ManeuverTypeTest.
 */
public class ManeuverTypeTest
{

    /**
     * Test enum maneuver type.
     */
    @Test
    public void testEnumManeuverType()
    {
        List<ManeuverType> allManeuverTypeForTest = new ArrayList<>(Arrays.asList(ManeuverType.PitchCPS, ManeuverType.PitchSlew, ManeuverType.RollSlew));
        ManeuverType[] allManeuverType = ManeuverType.values();
        for (int i = 0; i < allManeuverType.length; i++)
        {
            for (int j = 0; j < allManeuverTypeForTest.size(); j++)
            {
                if (allManeuverType[i].equals(allManeuverTypeForTest.get(j)))
                {
                    allManeuverTypeForTest.remove(j);
                    j--;
                }
            }
        }

        ManeuverType type = null;
        type = ManeuverType.valueOf("RollSlew");
        System.out.println("Selected : " + type);

        assertEquals(0, allManeuverTypeForTest.size());
    }

}
