
package com.nais.spla.brm.library.main.ontology.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nais.spla.brm.library.main.ontology.enums.Polarization;

public class PsPolarizationTest
{

    @Test
    public void testPsPolarizationLongInt() throws Exception
    {
        long sectorsUsedForPs = 20;
        PsPolarization psPol1 = new PsPolarization();
        psPol1.setPol(Polarization.HH);
        psPol1.setSectorUsedForPs(sectorsUsedForPs);

        PsPolarization psPol2 = new PsPolarization(sectorsUsedForPs, Polarization.HH);
        assertEquals(Polarization.HH, psPol2.getPol());
        assertEquals(sectorsUsedForPs, psPol2.getSectorUsedForPs());

    }

}
