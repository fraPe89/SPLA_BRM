
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Di2sInfoTest
{

    @Test
    public void createDi2sInfo()
    {

        String ugsId = "ugsId";

        String relativeSlaveId = "relativeSlaveId";

        String relativeMasterId = "relativeMasterId";

        String partnerId = "partnerId";

        DTO slaveDto = null;

        boolean rejected = false;

        Di2sInfo di2s = new Di2sInfo();
        di2s.setPartnerId(partnerId);
        di2s.setRejected(rejected);
        di2s.setRelativeMasterId(relativeMasterId);
        di2s.setRelativeSlaveId(relativeSlaveId);
        di2s.setSlaveDto(slaveDto);
        di2s.setUgsId(ugsId);

        Di2sInfo di2s2 = new Di2sInfo();
        di2s2 = di2s;

        assertEquals(partnerId, di2s2.getPartnerId());
        assertEquals(rejected, di2s2.isRejected());
        assertEquals(relativeMasterId, di2s2.getRelativeMasterId());
        assertEquals(relativeSlaveId, di2s2.getRelativeSlaveId());
        assertEquals(slaveDto, di2s2.getSlaveDto());
        assertEquals(ugsId, di2s2.getUgsId());
    }

}
