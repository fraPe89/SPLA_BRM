
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.DateResource;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.OrbitResources;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.MinTimeRight;

public class LeftAttitudeProfileManagementTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private LeftAttitudeProfileManagement leftAttitude = new LeftAttitudeProfileManagement();
    private StubResources stub = new StubResources();

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "PassThroughManagementTest";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_ok() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 15:00:00", "10/10/2017 15:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 14:59:50", "10/10/2017 15:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", acqForTest.getId(), next_right.getId(), "10/10/2017 14:19:00", "10/10/2017 14:25:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(false);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        boolean accepted = this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");
        assertTrue(accepted);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_error() throws Exception
    {
        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 15:00:00", "10/10/2017 15:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 14:59:50", "10/10/2017 15:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", acqForTest.getId(), next_right.getId(), "10/10/2017 14:19:00", "10/10/2017 14:25:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(false);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        boolean accepted = this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");
        assertFalse(accepted);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_disabled() throws Exception
    {
        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");
        this.droolsParams.setDisableCheckLeftAttitude(true);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 15:00:00", "10/10/2017 15:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 14:59:50", "10/10/2017 15:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", acqForTest.getId(), next_right.getId(), "10/10/2017 14:19:00", "10/10/2017 14:25:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(false);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        boolean accepted = this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");
        assertTrue(accepted);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_2_checks_on_left() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 17:00:00", "10/10/2017 17:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 16:16:00", "10/10/2017 16:17:00", "left", "SAT_1");
        acqForTest.setEss(40);
        Acquisition nextLeft = this.du.createParametricAcquisition("acqForTest", "10/10/2017 17:16:00", "10/10/2017 17:17:00", "left", "SAT_1");
        nextLeft.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        acqTreemap.put(nextLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLeft, nextLeft.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 16:15:00", "10/10/2017 16:16:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 12:59:00", "10/10/2017 13:00:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 16:59:00", "10/10/2017 17:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", acqForTest.getId(), next_right.getId(), "10/10/2017 16:17:00", "10/10/2017 16:23:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);

        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver conterMan = this.du.createManeuver("man3", next_right.getId(), nextLeft.getId(), "10/10/2017 17:12:00", "10/10/2017 17:13:00", "SAT_1", Actuator.ReactionWheels);
        conterMan.setRightToLeftFlag(true);
        manTreemap.put(conterMan.getStartTime().getTime(), conterMan);

        boolean performed = this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");
        assertFalse(performed);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_reject_for_more_than_2_orbit_in_left() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 17:00:00", "10/10/2017 17:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 16:16:00", "10/10/2017 16:17:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 16:15:00", "10/10/2017 16:16:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 12:59:00", "10/10/2017 13:00:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 16:59:00", "10/10/2017 17:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 16:17:00", "10/10/2017 16:23:00", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        boolean performed = this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");
        assertFalse(performed);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_reject_for_more_than_two_energy_barrel_used_for_left_period() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(500);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 17:00:00", "10/10/2017 17:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 15:16:00", "10/10/2017 15:17:00", "left", "SAT_1");
        acqForTest.setEss(410);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 15:15:00", "10/10/2017 15:16:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 12:59:00", "10/10/2017 13:00:00", anotherLeftInLeftPeriod.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", previousRight.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 16:59:00", "10/10/2017 17:00:00", next_right.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 15:17:00", "10/10/2017 15:23:00", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        System.out.println("max ess in left perio d: " + this.droolsParams.getSatWithId(acqForTest.getSatelliteId()).getSatelliteProperties().getMaxEssInLeftPeriod());
        boolean performed = this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");
        assertFalse(performed);
    }

    @Test
    public void testComputeMaxTimeLeftAlgo_only_a_right() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : testComputeMaxTimeLeftAlgo \n\n");

        Acquisition rightAcq = this.du.createParametricAcquisition("right01", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        rightAcq.setEss(20);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(rightAcq.getStartTime().getTime(), new EnergyAssociatedToTask(rightAcq, rightAcq.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silrightAcq = this.du.createSilent("10/10/2017 12:39:00", "10/10/2017 12:40:00", rightAcq.getIdTask(), 2.0);

        silTreemap.put(silrightAcq.getStartTime().getTime(), new EnergyAssociatedToTask(silrightAcq, silrightAcq.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver initialMan = this.du.createManeuver("man3", null, rightAcq.getId(), "10/10/2017 12:00:00", "10/10/2017 12:06:00", "SAT_1", Actuator.ReactionWheels);
        initialMan.setRightToLeftFlag(true);
        manTreemap.put(initialMan.getStartTime().getTime(), initialMan);

        this.leftAttitude.computeMaxTimeLeftAlgo(rightAcq, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");

    }

    @Test
    public void testComputeMaxTimeLeftAlgo_only_a_left() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : testComputeMaxTimeLeftAlgo_only_a_left \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        MissionHorizon mh = this.stub.createMH("10/10/2017 12:00:00", "10/10/2017 18:00:00");
        this.droolsParams.setCurrentMH(mh);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        Silent sil = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 2.0);
        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(sil.getStartTime().getTime(), new EnergyAssociatedToTask(sil, sil.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        this.leftAttitude.computeMaxTimeLeftAlgo(acqForTest, this.droolsParams, manTreemap, acqTreemap, silTreemap, "test");

    }

    @Test
    public void testComputeEssValuesInInterval_prevOrbit_BorderLine_Case_R() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit_BorderLine_Case ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 12:59:00", "10/10/2017 13:00:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 13:59:50", "10/10/2017 14:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = acqForTest.getEndTime().getTime();
        startSearch = endSearch - (98 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check : " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + new Date(endSearch));

        expectedEssRight = next_right.getEss() + previousRight.getEss() + silNext_right.getEnergy() + silPreviousRight.getEnergy();
        expectedTimeRight = ((lastMan.getStartTime().getTime() - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch) + (previousRight.getEndTime().getTime() - previousRight.getStartTime().getTime())) / 60000;
        expectedTimeLeft = (((manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) + endSearch) - lastMan.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + acqForTest.getEss() + silAnotherLeftInLeftPeriod.getEnergy() + silAcqForTest.getEnergy();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean includeSilent = true;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(includeSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        // assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);
        // assertEquals(expectedTimeRight, previousProfile.getTimeInRight(), 0);
        // assertEquals(expectedTimeLeft, previousProfile.getTimeInLeft(), 0);
        // assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
    }

    @Test
    public void testComputeEssValuesInInterval_LeftPeriod() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_LeftPeriod ");
        DateResource returnedValues = new DateResource();

        this.droolsParams.getSatWithId("1").getSatelliteProperties().setPercentManLeftC2(0);
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;

        MissionHorizon mh = this.stub.createMH("10/10/2017 12:00:00", "10/10/2017 18:00:00");
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 13:20:00", "10/10/2017 13:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:19:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:57:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), acqForTest.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:22:03", "10/10/2017 13:26:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        expectedEssLeft = acqForTest.getEss() + anotherLeftInLeftPeriod.getEss();
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);
        Logger logger = LoggerFactory.getLogger(LeftAttitudeProfileManagementTest.class);

        returnedValues = this.leftAttitude.detectActualLeftPeriod(logger, acqForTest, manTreemap, mh, 0);
        System.out.println("start and stop time left period : " + returnedValues);

        boolean involveSilent = true;
        OrbitResources leftProfileWithSilent = this.leftAttitude.computeEssValuesInInterval(involveSilent, 50.0, returnedValues.getStart().getTime(), returnedValues.getStop().getTime(), acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + leftProfileWithSilent);
        assertEquals(0, leftProfileWithSilent.getEssRight(), 0);
        assertEquals(expectedEssLeft * 2, leftProfileWithSilent.getEssLeft(), 0);
        assertEquals(expectedTimeLeft, leftProfileWithSilent.getTimeInLeft(), 0);

        involveSilent = false;
        OrbitResources leftProfileWithoutSilent = this.leftAttitude.computeEssValuesInInterval(involveSilent, 50.0, returnedValues.getStart().getTime(), returnedValues.getStop().getTime(), acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + leftProfileWithoutSilent);
        assertEquals(0, leftProfileWithoutSilent.getEssRight(), 0);
        assertEquals(expectedEssLeft, leftProfileWithoutSilent.getEssLeft(), 0);
        assertEquals(expectedTimeLeft, leftProfileWithoutSilent.getTimeInLeft(), 0);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeEssValuesInInterval_LeftPeriod_fromDrools() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_LeftPeriod ");
        DateResource returnedValues = new DateResource();

        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:14:00", "10/10/2017 13:15:00", "left", "SAT_1");
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 11:58:00", "10/10/2017 11:58:10", "right", "SAT_1");
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto4 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        HashMap<String, Acquisition> allAccepted = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "allAccepted");

        Acquisition acq1 = allAccepted.get(dto1.getDtoId());
        Acquisition acq2 = allAccepted.get(dto2.getDtoId());

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        TreeMap<Long, Maneuver> manTreemap = resFunc.getAllManeuversSat1();
        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = resFunc.getEssFunctionSat1();
        TreeMap<Long, EnergyAssociatedToTask> silTreemap = resFunc.getSilentFunctionSat1();

        expectedEssLeft = acq1.getEss() + acq2.getEss();
        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);
        Logger logger = LoggerFactory.getLogger(LeftAttitudeProfileManagementTest.class);

        returnedValues = this.leftAttitude.detectActualLeftPeriod(logger, acq1, manTreemap, this.droolsParams.getCurrentMH(), 0);
        System.out.println("start and stop time left period : " + returnedValues);

        boolean involveSilent = true;
        OrbitResources leftProfileWithSilent = this.leftAttitude.computeEssValuesInInterval(involveSilent, 50.0, returnedValues.getStart().getTime(), returnedValues.getStop().getTime(), acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + leftProfileWithSilent);
        assertEquals(0, leftProfileWithSilent.getEssRight(), 0);
        // assertEquals(expectedEssLeft * 2 - 20,
        // leftProfileWithSilent.getEssLeft(), 0);
        // assertEquals(expectedTimeLeft, leftProfileWithSilent.getTimeInLeft(),
        // 0);

        involveSilent = false;
        OrbitResources leftProfileWithoutSilent = this.leftAttitude.computeEssValuesInInterval(involveSilent, 50.0, returnedValues.getStart().getTime(), returnedValues.getStop().getTime(), acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + leftProfileWithoutSilent);
        // assertEquals(0, leftProfileWithoutSilent.getEssRight(), 0);
        // assertEquals(expectedEssLeft, leftProfileWithoutSilent.getEssLeft(),
        // 0);
        // assertEquals(expectedTimeLeft,
        // leftProfileWithoutSilent.getTimeInLeft(), 0);

    }

    @Test
    public void testComputeEssValuesInInterval_prevOrbit() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);

        Acquisition anotherLeftInLeftPeriod2 = this.du.createParametricAcquisition("anotherLeftInLeftPeriod2", "10/10/2017 13:17:00", "10/10/2017 13:18:00", "left", "SAT_1");
        anotherLeftInLeftPeriod2.setEss(30);

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 14:19:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:58:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:16:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:00", "10/10/2017 12:59:00", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod2.getId(), next_right.getId(), "10/10/2017 13:21:00", "10/10/2017 13:25:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), acqForTest.getId(), "10/10/2017 14:15:00", "10/10/2017 14:19:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = lastMan.getStartTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        expectedEssRight = next_right.getEss();
        expectedTimeRight = ((endSearch - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch)) / 60000;
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + anotherLeftInLeftPeriod2.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);

        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);

        useSilent = true;
        previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssLeft * 2, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight * 2, previousProfile.getEssRight(), 0);
    }

    @Test
    public void testComputeEssValuesInInterval_prevOrbit_contermaneuver() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        long startSearch = 0;
        long endSearch = 0;

        Acquisition left1 = this.du.createParametricAcquisition("left1", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "left", "SAT_1");
        left1.setEss(15);

        Acquisition left2 = this.du.createParametricAcquisition("left2", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        left2.setEss(30);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(left1.getStartTime().getTime(), new EnergyAssociatedToTask(left1, left1.getEss()));
        acqTreemap.put(left2.getStartTime().getTime(), new EnergyAssociatedToTask(left2, left2.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(left1.getStartTime().getTime(), new EnergyAssociatedToTask(left1, left1.getEss()));
        silTreemap.put(left2.getStartTime().getTime(), new EnergyAssociatedToTask(left2, left2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manL2R = this.du.createManeuver("manL2R", left2.getId(), left1.getId(), "10/10/2017 13:15:00", "10/10/2017 13:21:00", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manL2R.getStartTime().getTime(), manL2R);

        Maneuver manR2L = this.du.createManeuver("manR2L", left1.getId(), null, "10/10/2017 13:53:57", "10/10/2017 13:59:57", "SAT_1", Actuator.ReactionWheels);
        manR2L.setRightToLeftFlag(true);
        manTreemap.put(manR2L.getStartTime().getTime(), manR2L);

        Maneuver manL2R2 = this.du.createManeuver("manL2R2", left1.getId(), null, "10/10/2017 14:03:03", "10/10/2017 14:09:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manL2R2.getStartTime().getTime(), manL2R2);

        endSearch = left1.getEndTime().getTime();
        startSearch = endSearch - (97 * 60000);

        boolean useSilent = false; // TODO : rimetterlo a true e modificare test

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + left2 + " ,\n" + left1);
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
    }

    @Test
    public void testComputeEssValuesInInterval_prevOrbit_only_right() throws Exception
    {
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double expectedEssRight = 75;
        double expectedTimeRight = 97;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition right1 = this.du.createParametricAcquisition("right1", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        right1.setEss(20);
        Acquisition right2 = this.du.createParametricAcquisition("right2", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        right2.setEss(15);
        Acquisition right3 = this.du.createParametricAcquisition("right3", "10/10/2017 14:20:00", "10/10/2017 14:22:00", "right", "SAT_1");
        right3.setEss(40);
        Acquisition right4 = this.du.createParametricAcquisition("right4", "10/10/2017 13:17:00", "10/10/2017 13:21:00", "right", "SAT_1");
        right4.setEss(30);
        Acquisition right5 = this.du.createParametricAcquisition("right5", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "right", "SAT_1");
        right5.setEss(30);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(right1.getStartTime().getTime(), new EnergyAssociatedToTask(right1, right1.getEss()));
        acqTreemap.put(right2.getStartTime().getTime(), new EnergyAssociatedToTask(right2, right2.getEss()));
        acqTreemap.put(right3.getStartTime().getTime(), new EnergyAssociatedToTask(right3, right3.getEss()));
        acqTreemap.put(right4.getStartTime().getTime(), new EnergyAssociatedToTask(right4, right4.getEss()));
        acqTreemap.put(right5.getStartTime().getTime(), new EnergyAssociatedToTask(right5, right5.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(right1.getStartTime().getTime(), new EnergyAssociatedToTask(right1, right1.getEss()));
        silTreemap.put(right2.getStartTime().getTime(), new EnergyAssociatedToTask(right2, right2.getEss()));
        silTreemap.put(right3.getStartTime().getTime(), new EnergyAssociatedToTask(right3, right3.getEss()));
        silTreemap.put(right4.getStartTime().getTime(), new EnergyAssociatedToTask(right4, right4.getEss()));
        silTreemap.put(right5.getStartTime().getTime(), new EnergyAssociatedToTask(right5, right5.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        endSearch = right2.getEndTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + right1 + " ,\n" + right5 + " ,\n" + right4 + ",\n" + right2 + ", \n" + right3);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);
        assertEquals(expectedTimeRight, previousProfile.getTimeInRight(), 0);
        assertEquals(expectedTimeLeft, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
    }

    @Test(expected = Exception.class)
    public void testComputeEssValuesInInterval_startBeforeStop() throws Exception
    {
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();

        Silent silAcqForTest = this.du.createSilent("10/10/2017 14:11:00", "10/10/2017 14:12:00", acqForTest.getIdTask(), 2.0);
        Silent silAnotherLeftInLeftPeriod = this.du.createSilent("10/10/2017 12:59:00", "10/10/2017 13:00:00", acqForTest.getIdTask(), 3.0);
        Silent silPreviousRight = this.du.createSilent("10/10/2017 12:39:50", "10/10/2017 12:40:00", acqForTest.getIdTask(), 4.0);
        Silent silNext_right = this.du.createSilent("10/10/2017 13:59:50", "10/10/2017 14:00:00", acqForTest.getIdTask(), 5.0);

        silTreemap.put(silAcqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(silAcqForTest, silAcqForTest.getEnergy()));
        silTreemap.put(silAnotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(silAnotherLeftInLeftPeriod, silAnotherLeftInLeftPeriod.getEnergy()));
        silTreemap.put(silPreviousRight.getStartTime().getTime(), new EnergyAssociatedToTask(silPreviousRight, silPreviousRight.getEnergy()));
        silTreemap.put(silNext_right.getStartTime().getTime(), new EnergyAssociatedToTask(silNext_right, silNext_right.getEnergy()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = acqForTest.getEndTime().getTime();
        startSearch = endSearch + (98 * 60000);

        boolean includeSilent = true;
        this.leftAttitude.computeEssValuesInInterval(includeSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);

    }

    @Test
    public void testComputeEssValuesInInterval_prevOrbit_BorderLine_Case_L() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit_BorderLine_Case ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousLeft = this.du.createParametricAcquisition("prev_left", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "left", "SAT_1");
        previousLeft.setEss(20);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:49:00", "10/10/2017 12:51:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = acqForTest.getEndTime().getTime();
        startSearch = endSearch - (98 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check : " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + new Date(endSearch));

        expectedEssRight = next_right.getEss() + previousRight.getEss();
        expectedTimeRight = ((lastMan.getStartTime().getTime() - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch) + (previousRight.getEndTime().getTime() - previousRight.getStartTime().getTime())) / 60000;
        expectedTimeLeft = (((manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) + endSearch) - lastMan.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + acqForTest.getEss() + previousLeft.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

    }

    @Test
    public void testComputeEssValuesInInterval_nextOrbit_manBeforeMAxTime() throws Exception
    {
        System.out.println("running test : testComputeEssValuesInInterval_LeftPeriod ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        long startSearch = 0;
        long maxEndSearch = 0;

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 14:20:00", "10/10/2017 14:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), acqForTest.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", acqForTest.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:15:57", "10/10/2017 14:19:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        startSearch = manNext.getEndTime().getTime();
        maxEndSearch = DroolsUtils.createDate("10/10/2017 14:56:03").getTime();

        System.out.println("acq in order are : \n" + previousRight + " ,\n" + acqForTest + " ,\n" + next_right + ",\n" + anotherLeftInLeftPeriod);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        long returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        System.out.println("end of right period : " + new Date(returnedEndOfNextOrbit));
        assertEquals(lastMan.getStartTime().getTime(), returnedEndOfNextOrbit);
    }

    @Test
    public void testComputeEssValuesInInterval_nextOrbit_manAfterMAxTime() throws Exception
    {
        System.out.println("running test : testComputeEssValuesInInterval_LeftPeriod ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        long startSearch = 0;
        long maxEndSearch = 0;

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 14:20:00", "10/10/2017 14:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), acqForTest.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", acqForTest.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 16:15:57", "10/10/2017 16:19:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        startSearch = manNext.getEndTime().getTime();
        maxEndSearch = DroolsUtils.createDate("10/10/2017 14:56:03").getTime();

        System.out.println("acq in order are : \n" + previousRight + " ,\n" + acqForTest + " ,\n" + next_right + ",\n" + anotherLeftInLeftPeriod);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        long returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        System.out.println("end of right period : " + new Date(returnedEndOfNextOrbit));
        assertEquals(maxEndSearch, returnedEndOfNextOrbit);
    }

    @Test
    public void testComputeEssValuesInInterval_nextOrbit_infinity() throws Exception
    {
        System.out.println("running test : testComputeEssValuesInInterval_LeftPeriod ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        long startSearch = 0;
        long maxEndSearch = 0;

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:57:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), acqForTest.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", acqForTest.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        startSearch = manNext.getEndTime().getTime();
        maxEndSearch = startSearch + (this.droolsParams.getMinutesForOrbit() * 60000);

        System.out.println("acq in order are : \n" + previousRight + " ,\n" + acqForTest + " ,\n" + next_right + ",\n");
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + new Date(maxEndSearch));

        long returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        System.out.println("end of right period : " + new Date(returnedEndOfNextOrbit));

        expectedEssRight = next_right.getEss();
        expectedTimeRight = (returnedEndOfNextOrbit - startSearch) / 60000;
        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);
        boolean useSilent = false;
        OrbitResources leftProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, returnedEndOfNextOrbit, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + leftProfile);

        assertEquals(0, leftProfile.getEssLeft(), 0);
        assertEquals(0, leftProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight, leftProfile.getEssRight(), 0);
        assertEquals(expectedTimeRight, leftProfile.getTimeInRight(), 0);
    }

    @Test
    public void testComputeEssValuesInInterval_nextOrbit() throws Exception
    {
        System.out.println("running test : testComputeEssValuesInInterval_LeftPeriod ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        long startSearch = 0;
        long maxEndSearch = 0;

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 14:20:00", "10/10/2017 14:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), acqForTest.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", acqForTest.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:15:57", "10/10/2017 14:19:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        startSearch = manNext.getEndTime().getTime();
        maxEndSearch = anotherLeftInLeftPeriod.getEndTime().getTime();

        System.out.println("acq in order are : \n" + previousRight + " ,\n" + acqForTest + " ,\n" + next_right + ",\n" + anotherLeftInLeftPeriod);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        long returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        System.out.println("end of right period : " + new Date(returnedEndOfNextOrbit));

        expectedEssRight = next_right.getEss();
        expectedTimeRight = (returnedEndOfNextOrbit - startSearch) / 60000;
        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);
        boolean useSilent = false;
        OrbitResources leftProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, returnedEndOfNextOrbit, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + leftProfile);

        assertEquals(0, leftProfile.getEssLeft(), 0);
        assertEquals(0, leftProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight, leftProfile.getEssRight(), 0);
        assertEquals(expectedTimeRight, leftProfile.getTimeInRight(), 0);
    }

    @Test
    public void testDetectActualLeftPeriod_between_2_man() throws Exception
    {
        System.out.println("running test : testDetectActualLeftPeriod_between_2_man ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DateResource returnedValues = new DateResource();

        MissionHorizon mh = this.stub.createMH("10/10/2017 12:00:00", "10/10/2017 18:00:00");
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 13:20:00", "10/10/2017 13:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), acqForTest.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:22:03", "10/10/2017 13:26:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);
        Logger logger = LoggerFactory.getLogger(LeftAttitudeProfileManagementTest.class);
        returnedValues = this.leftAttitude.detectActualLeftPeriod(logger, acqForTest, manTreemap, mh, 0);
        assertEquals(manPrev.getEndTime().getTime(), returnedValues.getStart().getTime());
        assertEquals(manNext.getStartTime().getTime(), returnedValues.getStop().getTime());
    }

    @Test
    public void testDetectActualLeftPeriod_only_next_man() throws Exception
    {
        System.out.println("running test : testDetectActualLeftPeriod_only_next_man ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DateResource returnedValues = new DateResource();

        MissionHorizon mh = this.stub.createMH("10/10/2017 12:00:00", "10/10/2017 18:00:00");
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 13:20:00", "10/10/2017 13:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:22:03", "10/10/2017 13:26:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Logger logger = LoggerFactory.getLogger(LeftAttitudeProfileManagementTest.class);

        returnedValues = this.leftAttitude.detectActualLeftPeriod(logger, acqForTest, manTreemap, mh, 0);
        assertEquals(mh.getStart(), returnedValues.getStart());
        assertEquals(manNext.getStartTime().getTime(), returnedValues.getStop().getTime());
    }

    @Test
    public void testDetectActualLeftPeriod_no_man() throws Exception
    {
        System.out.println("running test : testDetectActualLeftPeriod_no_man ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DateResource returnedValues = new DateResource();

        MissionHorizon mh = this.stub.createMH("10/10/2017 12:00:00", "10/10/2017 18:00:00");
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setEss(30);
        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("another_left", "10/10/2017 13:20:00", "10/10/2017 13:22:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Logger logger = LoggerFactory.getLogger(LeftAttitudeProfileManagementTest.class);

        returnedValues = this.leftAttitude.detectActualLeftPeriod(logger, acqForTest, manTreemap, mh, 0);
        System.out.println("returned values : " + returnedValues);
    }

    @Test
    public void testFindEndOfNextOrbit_no_left_till_end_of_orbit() throws Exception
    {
        System.out.println("running test : testFindEndOfNextOrbit_no_left_till_end_of_orbit ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        long returnedEndOfNextOrbit = 0;
        long startSearch = 0;
        long maxEndSearch = 0;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition nextAcqRight = this.du.createParametricAcquisition("nextRight", "10/10/2017 16:00:00", "10/10/2017 16:15:00", "right", "SAT_1");
        double essForNextRight = 20;
        nextAcqRight.setEss(essForNextRight);

        Acquisition anotherAcqRight = this.du.createParametricAcquisition("nextNextRight", "10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", "SAT_1");
        double essForNextNextRight = 10;
        anotherAcqRight.setEss(essForNextNextRight);

        Acquisition anotherAcqRight2 = this.du.createParametricAcquisition("anotherAcqRight2", "10/10/2017 17:59:00", "10/10/2017 18:00:00", "right", "SAT_1");
        double essForNextRight2 = 10;
        anotherAcqRight2.setEss(essForNextRight2);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(nextAcqRight.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcqRight, nextAcqRight.getEss()));
        acqTreemap.put(anotherAcqRight2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherAcqRight2, anotherAcqRight2.getEss()));
        acqTreemap.put(anotherAcqRight.getStartTime().getTime(), new EnergyAssociatedToTask(anotherAcqRight, anotherAcqRight.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        startSearch = acqForTest.getEndTime().getTime();
        maxEndSearch = acqForTest.getEndTime().getTime() + (97 * 60000);

        System.out.println("start search = ");
        System.out.println("acq in order are : \n" + acqForTest + " ,\n" + nextAcqRight + " ,\n" + anotherAcqRight + ",\n" + anotherAcqRight2);
        System.out.println("start of right period = " + new Date(startSearch));
        System.out.println("the end of right period is :" + new Date(maxEndSearch));

        returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        assertEquals(maxEndSearch, returnedEndOfNextOrbit);
    }

    @Test
    public void testFindEndOfNextOrbit_left_before_end_of_orbit() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testFindEndOfNextOrbit_left_before_end_of_orbit ");
        long returnedEndOfNextOrbit = 0;
        long startSearch = 0;
        long maxEndSearch = 0;
        long expectedEnd = 0;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition nextAcqRight = this.du.createParametricAcquisition("nextRight", "10/10/2017 16:00:00", "10/10/2017 16:15:00", "right", "SAT_1");
        double essForNextRight = 20;
        nextAcqRight.setEss(essForNextRight);

        Acquisition nextAcqLeft = this.du.createParametricAcquisition("nextLeft", "10/10/2017 17:00:00", "10/10/2017 17:15:00", "left", "SAT_1");
        double essForNextLeft = 10;
        nextAcqLeft.setEss(essForNextLeft);

        Acquisition anotherAcqLeft = this.du.createParametricAcquisition("nextNextLeft", "10/10/2017 17:22:00", "10/10/2017 17:23:00", "left", "SAT_1");
        double essForNextNextLeft = 10;
        anotherAcqLeft.setEss(essForNextNextLeft);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(nextAcqRight.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcqRight, nextAcqRight.getEss()));
        acqTreemap.put(nextAcqLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcqLeft, nextAcqLeft.getEss()));
        acqTreemap.put(anotherAcqLeft.getStartTime().getTime(), new EnergyAssociatedToTask(anotherAcqLeft, anotherAcqLeft.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        startSearch = acqForTest.getEndTime().getTime();
        maxEndSearch = anotherAcqLeft.getEndTime().getTime();

        System.out.println("acq in order are : \n" + acqForTest + " ,\n" + nextAcqRight + " ,\n" + nextAcqLeft + ",\n" + anotherAcqLeft);
        System.out.println("we are checking interval from :" + acqForTest.getEndTime() + "\nto : " + anotherAcqLeft.getEndTime());
        System.out.println("start of right period = " + new Date(startSearch));
        System.out.println("the end of right period is :" + new Date(expectedEnd) + ", so before the max orbit time");

        Maneuver man = this.du.createManeuver("manForTest", nextAcqRight.getId(), nextAcqLeft.getId(), "10/10/2017 16:55:57", "10/10/2017 16:59:57", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(man.getStartTime().getTime(), man);
        returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        expectedEnd = man.getStartTime().getTime();

        assertEquals(expectedEnd, returnedEndOfNextOrbit);
    }

    @Test
    public void testGetLastLeftAcq_next_right_not_exists_another_left() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("running test : testGetLastLeftAcq_null_case");
        Acquisition returnedAcq = null;
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition nextAcqRight = this.du.createParametricAcquisition("next", "10/10/2017 16:00:00", "10/10/2017 16:15:00", "right", "SAT_1");
        nextAcqRight.setEss(5);

        Acquisition nextNextAcqRight = this.du.createParametricAcquisition("next", "10/10/2017 16:20:00", "10/10/2017 16:22:00", "right", "SAT_1");
        nextNextAcqRight.setEss(10);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(nextAcqRight.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcqRight, nextAcqRight.getEss()));
        acqTreemap.put(nextNextAcqRight.getStartTime().getTime(), new EnergyAssociatedToTask(nextNextAcqRight, nextNextAcqRight.getEss()));

        returnedAcq = this.leftAttitude.getPrevLeftPeriod(acqForTest, acqTreemap, false);

        System.out.println("acq in order are : \n" + acqForTest + " ,\n" + nextAcqRight + "" + nextNextAcqRight + " ,\n" + acqForTest);
        System.out.println("we are checking :" + acqForTest.getIdTask());
        System.out.println("last left acq inserted is :" + returnedAcq);

        assertEquals(null, returnedAcq);
    }

    @Test
    public void testGetLastLeftAcq_next_right_exists_another_left() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("running test : testGetLastLeftAcq_null_case");
        Acquisition returnedAcq = null;
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition nextAcqRight = this.du.createParametricAcquisition("next", "10/10/2017 16:00:00", "10/10/2017 16:15:00", "right", "SAT_1");
        nextAcqRight.setEss(5);

        Acquisition nextAcqLeft = this.du.createParametricAcquisition("next", "10/10/2017 16:20:00", "10/10/2017 16:22:00", "left", "SAT_1");
        nextAcqLeft.setEss(10);

        Acquisition nextNextAcqLeft = this.du.createParametricAcquisition("next", "10/10/2017 16:30:00", "10/10/2017 16:32:00", "left", "SAT_1");
        nextNextAcqLeft.setEss(10);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(nextAcqRight.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcqRight, nextAcqRight.getEss()));
        acqTreemap.put(nextAcqLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcqLeft, nextAcqLeft.getEss()));
        acqTreemap.put(nextNextAcqLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextNextAcqLeft, nextNextAcqLeft.getEss()));

        returnedAcq = this.leftAttitude.getPrevLeftPeriod(acqForTest, acqTreemap, false);

        System.out.println("acq in order are : \n" + acqForTest + " ,\n" + nextAcqRight + "" + nextAcqLeft + " ,\n" + acqForTest);
        System.out.println("we are checking :" + acqForTest.getIdTask());
        System.out.println("last left acq inserted is :" + returnedAcq);

        assertEquals(nextAcqLeft, returnedAcq);
    }

    @Test
    public void testGetLastLeftAcq_null_case() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("running test : testGetLastLeftAcq_null_case");
        Acquisition returnedAcq = null;
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition nextAcq = this.du.createParametricAcquisition("next", "10/10/2017 16:00:00", "10/10/2017 16:15:00", "left", "SAT_1");
        double essForNext = 20;
        nextAcq.setEss(essForNext);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(nextAcq.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcq, nextAcq.getEss()));

        returnedAcq = this.leftAttitude.getPrevLeftPeriod(acqForTest, acqTreemap, true);

        System.out.println("acq in order are : \n" + acqForTest + " ,\n" + nextAcq + " ,\n" + acqForTest);
        System.out.println("we are checking :" + acqForTest.getIdTask());
        System.out.println("last left acq inserted is :" + returnedAcq);

        assertEquals(null, returnedAcq);
    }

    @Test
    public void testGetLastLeftAcq_previous_is_left() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testGetLastLeftAcq_previous_is_left");
        Acquisition returnedAcq = null;
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "right", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition previousAcq = this.du.createParametricAcquisition("prev", "10/10/2017 10:00:00", "10/10/2017 10:15:00", "left", "SAT_1");
        double essForPrev = 20;
        previousAcq.setEss(essForPrev);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(previousAcq.getStartTime().getTime(), new EnergyAssociatedToTask(previousAcq, previousAcq.getEss()));

        returnedAcq = this.leftAttitude.getPrevLeftPeriod(acqForTest, acqTreemap, true);

        System.out.println("acq in order are : \n" + previousAcq + " ,\n" + acqForTest);
        System.out.println("we are checking :" + acqForTest.getIdTask());
        System.out.println("last left acq inserted is :" + returnedAcq.getIdTask());

        assertEquals(previousAcq, returnedAcq);
    }

    @Test
    public void testGetLastLeftAcq_previous_is_right() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testGetLastLeftAcq_previous_is_right ");
        Acquisition returnedPrevAcq = null;
        Acquisition returnedNextAcq = null;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        Acquisition previousAcq = this.du.createParametricAcquisition("prev", "10/10/2017 12:00:00", "10/10/2017 12:15:00", "right", "SAT_1");
        double essForPrev = 20;
        previousAcq.setEss(essForPrev);

        Acquisition previousPreviousAcq = this.du.createParametricAcquisition("prevprev", "10/10/2017 10:00:00", "10/10/2017 10:15:00", "left", "SAT_1");
        double essForPrevPrev = 20;
        previousPreviousAcq.setEss(essForPrevPrev);

        Acquisition nextAcq = this.du.createParametricAcquisition("next", "10/10/2017 14:00:00", "10/10/2017 14:15:00", "left", "SAT_1");
        double essFornextAcq = 20;
        previousPreviousAcq.setEss(essFornextAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(previousAcq.getStartTime().getTime(), new EnergyAssociatedToTask(previousAcq, previousAcq.getEss()));
        acqTreemap.put(previousPreviousAcq.getStartTime().getTime(), new EnergyAssociatedToTask(previousPreviousAcq, previousPreviousAcq.getEss()));
        acqTreemap.put(nextAcq.getStartTime().getTime(), new EnergyAssociatedToTask(nextAcq, nextAcq.getEss()));

        returnedPrevAcq = this.leftAttitude.getPrevLeftPeriod(acqForTest, acqTreemap, true);
        returnedNextAcq = this.leftAttitude.getPrevLeftPeriod(acqForTest, acqTreemap, false);

        System.out.println("acq in order are :\n " + previousPreviousAcq + " ,\n" + previousAcq + " ,\n" + acqForTest);
        System.out.println("we are checking :" + acqForTest.getIdTask());
        System.out.println("last left acq inserted is :" + returnedPrevAcq.getIdTask());

        assertEquals(previousPreviousAcq, returnedPrevAcq);
        assertEquals(nextAcq, returnedNextAcq);

    }

    @Test
    public void testFindMinimumValueInTable() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double returnedRightTimeFromTable = 0;
        double expectedRightTimeFromTable = 41;

        double totalEssRight = 12, totalEssLeft = 2, totalTimeInLeft = 18, totalTimeInRight = 49;
        double time1 = 20;
        double time2 = 32;

        List<MinTimeRight> allValuesUnderTestTime1 = new ArrayList<>();
        allValuesUnderTestTime1.add(new MinTimeRight(60, 20, 122));
        allValuesUnderTestTime1.add(new MinTimeRight(15, 33, 41));
        allValuesUnderTestTime1.add(new MinTimeRight(15, 56, 30));

        List<MinTimeRight> allValuesUnderTestTime2 = new ArrayList<>();
        allValuesUnderTestTime2.add(new MinTimeRight(60, 7, 33));
        allValuesUnderTestTime2.add(new MinTimeRight(60, 5, 12));
        allValuesUnderTestTime2.add(new MinTimeRight(26, 9, 37));

        TreeMap<Double, List<MinTimeRight>> mapForTest = new TreeMap<>();
        mapForTest.put(time1, allValuesUnderTestTime1);
        mapForTest.put(time2, allValuesUnderTestTime2);
        this.droolsParams.setMinTimeRight(mapForTest);
        Logger logger = LoggerFactory.getLogger(LeftAttitudeProfileManagementTest.class);
        DroolsParameters.setLogger(logger);
        returnedRightTimeFromTable = this.leftAttitude.findMinimumValueInTable(this.droolsParams, totalEssRight, totalEssLeft, totalTimeInLeft, totalTimeInRight, this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties());
        assertEquals(expectedRightTimeFromTable, returnedRightTimeFromTable, 0);
    }

    @Test
    public void testFindMinimumValueInTable_no_value_found() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double returnedRightTimeFromTable = 0;
        double expectedRightTimeFromTable = -1;

        double totalEssRight = 12, totalEssLeft = 320, totalTimeInLeft = 18, totalTimeInRight = 49;
        double time1 = 15;
        double time2 = 12;

        List<MinTimeRight> allValuesUnderTestTime1 = new ArrayList<>();
        allValuesUnderTestTime1.add(new MinTimeRight(60, 20, 122));
        allValuesUnderTestTime1.add(new MinTimeRight(15, 33, 41));
        allValuesUnderTestTime1.add(new MinTimeRight(15, 56, 30));

        List<MinTimeRight> allValuesUnderTestTime2 = new ArrayList<>();
        allValuesUnderTestTime2.add(new MinTimeRight(60, 7, 33));
        allValuesUnderTestTime2.add(new MinTimeRight(60, 5, 12));
        allValuesUnderTestTime2.add(new MinTimeRight(26, 9, 37));

        TreeMap<Double, List<MinTimeRight>> mapForTest = new TreeMap<>();
        mapForTest.put(time1, allValuesUnderTestTime1);
        mapForTest.put(time2, allValuesUnderTestTime2);

        this.droolsParams.setMinTimeRight(mapForTest);
        returnedRightTimeFromTable = this.leftAttitude.findMinimumValueInTable(this.droolsParams, totalEssRight, totalEssLeft, totalTimeInLeft, totalTimeInRight, this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties());
        assertEquals(expectedRightTimeFromTable, returnedRightTimeFromTable, 0);
    }

    @Test
    public void testFindMinimumValueInTable_getMaxDefault() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double totalEssRight = 12, totalEssLeft = 132, totalTimeInLeft = 18, totalTimeInRight = 49;
        double time1 = 20;
        double time2 = 32;

        List<MinTimeRight> allValuesUnderTestTime1 = new ArrayList<>();
        allValuesUnderTestTime1.add(new MinTimeRight(60, 20, 122));
        allValuesUnderTestTime1.add(new MinTimeRight(15, 33, 41));
        allValuesUnderTestTime1.add(new MinTimeRight(15, 56, 30));

        List<MinTimeRight> allValuesUnderTestTime2 = new ArrayList<>();
        allValuesUnderTestTime2.add(new MinTimeRight(60, 7, 33));
        allValuesUnderTestTime2.add(new MinTimeRight(60, 5, 12));
        allValuesUnderTestTime2.add(new MinTimeRight(26, 9, 37));

        TreeMap<Double, List<MinTimeRight>> mapForTest = new TreeMap<>();
        mapForTest.put(time1, allValuesUnderTestTime1);
        mapForTest.put(time2, allValuesUnderTestTime2);
        this.droolsParams.setMinTimeRight(mapForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setDefaultMinTimeRight(582);

        double returnedRightTimeFromTable = 0;
        double expectedRightTimeFromTable = this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getDefaultMinTimeRight() * 60; // expressed
        // in
        // seconds

        returnedRightTimeFromTable = this.leftAttitude.findMinimumValueInTable(this.droolsParams, totalEssRight, totalEssLeft, totalTimeInLeft, totalTimeInRight, this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties());
        assertEquals(expectedRightTimeFromTable, returnedRightTimeFromTable, 0);
    }

    @Test
    public void testFindPossibleRows() throws Exception
    {
        List<MinTimeRight> possibleRows = new ArrayList<>();
        double valueToCheck = 20;
        List<MinTimeRight> allValuesUnderTest = new ArrayList<>();
        allValuesUnderTest.add(new MinTimeRight(60, 20, 122));
        allValuesUnderTest.add(new MinTimeRight(10, 33, 41));
        allValuesUnderTest.add(new MinTimeRight(15, 56, 30));
        allValuesUnderTest.add(new MinTimeRight(60, 7, 33));
        allValuesUnderTest.add(new MinTimeRight(60, 5, 12));
        possibleRows = LeftAttitudeProfileManagement.findPossibleRows(allValuesUnderTest, valueToCheck);
        System.out.println("possible rows : " + possibleRows);
        assertTrue(possibleRows.size() == 3);

        valueToCheck = 70;
        possibleRows = LeftAttitudeProfileManagement.findPossibleRows(allValuesUnderTest, valueToCheck);
        System.out.println("possible rows : " + possibleRows);
        assertTrue(possibleRows.size() == 0);

        valueToCheck = 7;
        possibleRows = LeftAttitudeProfileManagement.findPossibleRows(allValuesUnderTest, valueToCheck);
        System.out.println("possible rows : " + possibleRows);
        assertTrue(possibleRows.size() == 1);
    }

    @Test
    public void testGetNearestLeftTime() throws Exception
    {
        MinTimeRight chosenRow = null;
        double totalEssLeft = 20;
        List<MinTimeRight> allValuesUnderTest = new ArrayList<>();
        allValuesUnderTest.add(new MinTimeRight(60, 20, 122));
        allValuesUnderTest.add(new MinTimeRight(10, 33, 41));
        allValuesUnderTest.add(new MinTimeRight(15, 56, 30));
        allValuesUnderTest.add(new MinTimeRight(60, 7, 33));
        allValuesUnderTest.add(new MinTimeRight(60, 5, 12));

        chosenRow = LeftAttitudeProfileManagement.getNearestLeftTime(allValuesUnderTest, totalEssLeft);

        System.out.println("pchosenRow : " + chosenRow);
        assertTrue(chosenRow != null);

        totalEssLeft = 90;
        chosenRow = LeftAttitudeProfileManagement.getNearestLeftTime(allValuesUnderTest, totalEssLeft);
        System.out.println("pchosenRow : " + chosenRow);
        assertTrue(chosenRow == null);
    }

    @Test
    public void testFindEndOfNextOrbit() throws Exception
    {
        System.out.println("running test : testFindEndOfNextOrbit_left_before_end_of_orbit ");
        long returnedEndOfNextOrbit = 0;
        long startSearch = 0;
        long maxEndSearch = 0;
        long expectedEnd = 0;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        startSearch = acqForTest.getEndTime().getTime();
        Date endCheck = DroolsUtils.createDate("10/10/2017 15:00:00");
        maxEndSearch = endCheck.getTime();

        System.out.println("we are checking interval from :" + acqForTest.getEndTime() + "\nto : " + endCheck);
        System.out.println("start of right period = " + new Date(startSearch));
        System.out.println("the end of right period is :" + new Date(expectedEnd) + ", so before the max orbit time");

        Maneuver man = this.du.createManeuver("", "manForTest", acqForTest.getId(), "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver conterMan = this.du.createManeuver("manForTest", "", acqForTest.getId(), "10/10/2017 13:02:00", "10/10/2017 13:06:00", "SAT_1", Actuator.ReactionWheels);

        manTreemap.put(man.getStartTime().getTime(), man);
        manTreemap.put(conterMan.getStartTime().getTime(), conterMan);

        returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        expectedEnd = endCheck.getTime();
        System.out.println("returned end : " + new Date(returnedEndOfNextOrbit));
        System.out.println("expectend end : " + new Date(expectedEnd));

        assertEquals(expectedEnd, returnedEndOfNextOrbit);
    }

    @Test
    public void testFindEndOfNextOrbit_manAfterMaxTime() throws Exception
    {
        System.out.println("running test : testFindEndOfNextOrbit_left_before_end_of_orbit ");
        long returnedEndOfNextOrbit = 0;
        long startSearch = 0;
        long maxEndSearch = 0;
        long expectedEnd = 0;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        startSearch = acqForTest.getEndTime().getTime();
        Date endCheck = DroolsUtils.createDate("10/10/2017 15:00:00");
        maxEndSearch = endCheck.getTime();

        System.out.println("we are checking interval from :" + acqForTest.getEndTime() + "\nto : " + endCheck);
        System.out.println("start of right period = " + new Date(startSearch));
        System.out.println("the end of right period is :" + new Date(expectedEnd) + ", so before the max orbit time");

        Maneuver man = this.du.createManeuver("", "manForTest", acqForTest.getId(), "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        Maneuver conterMan = this.du.createManeuver("manForTest", "", acqForTest.getId(), "10/10/2017 13:02:00", "10/10/2017 13:06:00", "SAT_1", Actuator.ReactionWheels);

        manTreemap.put(man.getStartTime().getTime(), man);
        manTreemap.put(conterMan.getStartTime().getTime(), conterMan);

        returnedEndOfNextOrbit = this.leftAttitude.findEndOfNextOrbit(startSearch, maxEndSearch, acqTreemap, manTreemap);
        expectedEnd = endCheck.getTime();
        System.out.println("returned end : " + new Date(returnedEndOfNextOrbit));
        System.out.println("expectend end : " + new Date(expectedEnd));

        assertEquals(expectedEnd, returnedEndOfNextOrbit);
    }

    @Test
    public void testGetPreviousMan_exists_man() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:59:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextMan(manTreemap, startSearch.getTime(), true);
        assertEquals(man2.getStartTime().getTime(), returnedKey);
    }

    @Test
    public void testGetPreviousMan_exists_man_CMGA() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.CMGA);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:59:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextManOfRelatedType(manTreemap, startSearch.getTime(), true, Actuator.CMGA);
        assertEquals(man2.getStartTime().getTime(), returnedKey);
    }

    @Test
    public void testGetPreviousMan_not_exists_man_CMGA() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:59:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextManOfRelatedType(manTreemap, startSearch.getTime(), true, Actuator.CMGA);
        assertEquals(null, returnedKey);
    }

    @Test
    public void testGetPreviousMan_exists_man_RW() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:59:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextManOfRelatedType(manTreemap, startSearch.getTime(), true, Actuator.ReactionWheels);
        assertEquals(man1.getStartTime().getTime(), returnedKey);
    }

    @Test
    public void testGetPreviousMan_not_exists_man_only_pitch() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:59:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextMan(manTreemap, startSearch.getTime(), true);
        System.out.println("returned key : " + returnedKey);
        assertEquals(null, returnedKey);
    }

    @Test
    public void testGetNextMan_exists_man() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchSlew);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.RollSlew);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:00:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextMan(manTreemap, startSearch.getTime(), false);
        assertEquals(man3.getStartTime().getTime(), returnedKey);
    }

    @Test
    public void testGetNextMan_not_exists_man_only_pitch() throws Exception
    {
        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);

        Date startSearch = DroolsUtils.createDate("10/10/2017 12:00:00");
        Object returnedKey = this.leftAttitude.getPrevOrNextMan(manTreemap, startSearch.getTime(), false);
        System.out.println("returned key : " + returnedKey);
        assertEquals(null, returnedKey);
    }

    @Test
    public void AAAtestDetectActualLeftPeriodFromMan_noPrevleftperiod() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId("1").setInitialLookSide("left");

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> acceptedElements : alltasksAccepted.entrySet())
        {
            System.out.println("accepted : " + acceptedElements.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        // leftAttitude.detectActualLeftPeriodFromMan(manLeft, manTreemap, mh,
        // leftPeriod, existsPrevious);

    }

    @Test
    public void testAddPercentLeftMan_50() throws Exception
    {
        Maneuver manLeft = this.du.createManeuver("manLeft", "x", "dto1", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        manLeft.setRightToLeftFlag(true);

        double percManLeft = 50;

        long timeInLeft = this.leftAttitude.addPercentLeftMan(manLeft, percManLeft);
        System.out.println("computed time in left : " + timeInLeft);

        Date expectedDate = DroolsUtils.createDate("10/10/2017 12:52:00");
        Date updatedStartTimeLeft = new Date(manLeft.getEndTime().getTime() - timeInLeft);
        System.out.println("updated startTime : " + updatedStartTimeLeft);
        assertEquals(expectedDate.getTime(), updatedStartTimeLeft.getTime());
    }

    @Test
    public void testAddPercentLeftMan_100() throws Exception
    {
        Maneuver manLeft = this.du.createManeuver("manLeft", "x", "dto1", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        manLeft.setRightToLeftFlag(true);

        double percManLeft = 100;

        long timeInLeft = this.leftAttitude.addPercentLeftMan(manLeft, percManLeft);
        System.out.println("computed time in left : " + timeInLeft);

        Date expectedDate = DroolsUtils.createDate("10/10/2017 12:50:00");
        Date updatedStartTimeLeft = new Date(manLeft.getEndTime().getTime() - timeInLeft);
        System.out.println("updated startTime : " + updatedStartTimeLeft);
        assertEquals(expectedDate.getTime(), updatedStartTimeLeft.getTime());
    }

    @Test
    public void testAddPercentLeftMan_0() throws Exception
    {
        Maneuver manLeft = this.du.createManeuver("manLeft", "x", "dto1", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        manLeft.setRightToLeftFlag(true);

        double percManLeft = 0;

        long timeInLeft = this.leftAttitude.addPercentLeftMan(manLeft, percManLeft);
        System.out.println("computed time in left : " + timeInLeft);

        Date expectedDate = DroolsUtils.createDate("10/10/2017 12:54:00");
        Date updatedStartTimeLeft = new Date(manLeft.getEndTime().getTime() - timeInLeft);
        System.out.println("updated startTime : " + updatedStartTimeLeft);
        assertEquals(expectedDate.getTime(), updatedStartTimeLeft.getTime());
    }

    @Test
    public void testAddEnergy_totalIncluded() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        acq.setEss(20);

        Date startTimeAsDate = DroolsUtils.createDate("10/10/2017 11:00:00");
        Date endTimeAsDate = DroolsUtils.createDate("10/10/2017 12:00:00");
        double computedEnergy = this.leftAttitude.addEnergy(0, acq, false, null, startTimeAsDate.getTime(), endTimeAsDate.getTime());
        assertEquals(20, computedEnergy, 0);

    }

    @Test
    public void testAddEnergy_borderlineStart() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        acq.setEss(20);

        Date startTimeAsDate = DroolsUtils.createDate("10/10/2017 11:58:30");
        Date endTimeAsDate = DroolsUtils.createDate("10/10/2017 13:00:00");
        double computedEnergy = this.leftAttitude.addEnergy(0, acq, false, null, startTimeAsDate.getTime(), endTimeAsDate.getTime());
        assertEquals(10, computedEnergy, 0);

    }

    @Test
    public void testAddEnergy_borderlineEnd() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        acq.setEss(60);

        Date startTimeAsDate = DroolsUtils.createDate("10/10/2017 11:00:00");
        Date endTimeAsDate = DroolsUtils.createDate("10/10/2017 11:58:20");
        double computedEnergy = this.leftAttitude.addEnergy(0, acq, false, null, startTimeAsDate.getTime(), endTimeAsDate.getTime());
        assertEquals(20, computedEnergy, 0);

    }

    @Test
    public void testGetNextLeftPeriod_LeftToLeft() throws Exception
    {
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 14:36:00", "10/10/2017 14:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 13:50:00", "10/10/2017 13:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        Acquisition nextLeft = this.leftAttitude.getNextLeftPeriod(acqForTest, manTreemap, acqTreemap);
        System.out.println(nextLeft);
    }

    @Test
    public void testGetNextLeftPeriod_Left_noConterman() throws Exception
    {
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        Acquisition nextLeft = this.leftAttitude.getNextLeftPeriod(acqForTest, manTreemap, acqTreemap);
        assertEquals(null, nextLeft);
    }

    @Test
    public void testGetNextLeftPeriod_LeftNotExistsLeft() throws Exception
    {
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "left", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        Acquisition nextLeftAcq = this.leftAttitude.getNextLeftPeriod(acqForTest, manTreemap, acqTreemap);
        assertEquals(null, nextLeftAcq);
    }

    @Test
    public void testGetNextLeftPeriod_RightNotExistsLeft() throws Exception
    {
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "right", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        Acquisition nextLeftAcq = this.leftAttitude.getNextLeftPeriod(acqForTest, manTreemap, acqTreemap);
        assertEquals(null, nextLeftAcq);
    }

    @Test
    public void testGetNextLeftPeriod_RightExistsLeft() throws Exception
    {
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:02:00", "right", "SAT_1");
        double essForAcq = 40;
        acqForTest.setEss(essForAcq);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        Acquisition nextLeft = this.du.createParametricAcquisition("acq_test", "10/10/2017 14:02:00", "10/10/2017 14:03:00", "left", "SAT_1");
        nextLeft.setEss(20);

        Acquisition nextLNexteft = this.du.createParametricAcquisition("acq_test", "10/10/2017 15:02:00", "10/10/2017 15:03:00", "left", "SAT_1");
        nextLNexteft.setEss(20);

        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(nextLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLeft, nextLeft.getEss()));
        acqTreemap.put(nextLNexteft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLNexteft, nextLNexteft.getEss()));

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.RollSlew);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);
        Acquisition nextLeftAcq = this.leftAttitude.getNextLeftPeriod(acqForTest, manTreemap, acqTreemap);
        assertEquals(nextLeft, nextLeftAcq);
    }

    @Test
    public void testCompareEssL() throws Exception
    {
        MinTimeRight minT1 = new MinTimeRight();
        minT1.setOnlyEssL(5);
        MinTimeRight minT2 = new MinTimeRight();
        minT2.setOnlyEssL(5);
        int returnedInt = LeftAttitudeProfileManagement.compareEssL.compare(minT1, minT2);

        assertEquals(0, returnedInt);

        minT1.setOnlyEssL(5);
        minT2.setOnlyEssL(3);
        returnedInt = LeftAttitudeProfileManagement.compareEssL.compare(minT1, minT2);
        System.out.println(returnedInt);
        assertTrue(returnedInt > 0);

        minT1.setOnlyEssL(5);
        minT2.setOnlyEssL(9);
        returnedInt = LeftAttitudeProfileManagement.compareEssL.compare(minT1, minT2);
        System.out.println(returnedInt);

        assertTrue(returnedInt < 0);
    }

    @Test
    public void testGetNextMan_exist() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 12:30:10");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);

        Object nextManKey = this.leftAttitude.getNextMan(manTreemap, startTime);
        assertEquals(man1.getStartTime().getTime(), nextManKey);
    }

    @Test
    public void testGetNextMan_afterPitch() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 12:30:10");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);

        Object nextManKey = this.leftAttitude.getNextMan(manTreemap, startTime);
        assertEquals(man4.getStartTime().getTime(), nextManKey);
    }

    @Test
    public void testGetNextMan_onlyPitch() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 12:30:10");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.PitchCPS);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);

        Object nextManKey = this.leftAttitude.getNextMan(manTreemap, startTime);
        assertEquals(null, nextManKey);
    }

    @Test
    public void testGetPrevMan_onlyPitch() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 15:50:10");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.PitchCPS);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.PitchCPS);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);

        Object nextManKey = this.leftAttitude.getPrevMan(manTreemap, startTime);
        assertEquals(null, nextManKey);
    }

    @Test
    public void testGetPrevMan_PitchbeforeSlew() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 15:50:10");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.PitchCPS);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);

        Object nextManKey = this.leftAttitude.getPrevMan(manTreemap, startTime);
        assertEquals(man1.getStartTime().getTime(), nextManKey);
    }

    @Test
    public void testGetPrevMan_Slew() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 15:50:10");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:36:00", "10/10/2017 12:40:00", "SAT_1", Actuator.ReactionWheels);
        man1.setType(ManeuverType.RollSlew);

        Maneuver man2 = this.du.createManeuver("", "", "", "10/10/2017 12:56:00", "10/10/2017 13:00:00", "SAT_1", Actuator.ReactionWheels);
        man2.setType(ManeuverType.PitchCPS);

        Maneuver man3 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);
        man3.setType(ManeuverType.PitchCPS);

        Maneuver man4 = this.du.createManeuver("", "", "", "10/10/2017 13:56:00", "10/10/2017 14:00:00", "SAT_1", Actuator.CMGA);
        man4.setType(ManeuverType.RollSlew);
        man4.setRightToLeftFlag(true);

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        manTreemap.put(man1.getStartTime().getTime(), man1);
        manTreemap.put(man2.getStartTime().getTime(), man2);
        manTreemap.put(man3.getStartTime().getTime(), man3);
        manTreemap.put(man4.getStartTime().getTime(), man4);

        Object nextManKey = this.leftAttitude.getPrevMan(manTreemap, startTime);
        assertEquals(man4.getStartTime().getTime(), nextManKey);
    }

    @Test
    public void testGetNextMan_noMan() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 15:50:10");

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Object nextManKey = this.leftAttitude.getNextMan(manTreemap, startTime);
        assertEquals(null, nextManKey);

        manTreemap = null;
        nextManKey = this.leftAttitude.getNextMan(manTreemap, startTime);
        assertEquals(null, nextManKey);
    }

    @Test
    public void testGetPrevMan_noMan() throws Exception
    {
        Date startTime = DroolsUtils.createDate("10/10/2017 15:50:10");

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Object nextManKey = this.leftAttitude.getPrevMan(manTreemap, startTime);
        assertEquals(null, nextManKey);

        manTreemap = null;
        nextManKey = this.leftAttitude.getPrevMan(manTreemap, startTime);
        assertEquals(null, nextManKey);
    }

    @Test
    public void testFindNextLeft_noMan() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 14:40:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("man1", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:57", "10/10/2017 12:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.ReactionWheels);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        Acquisition acq = this.leftAttitude.findNextLeft(firstCheck, manTreemap, acqTreemap);
        System.out.println("acq: " + acq);
        assertEquals(null, acq);

    }

    @Test
    public void testFindNextLeft_man_R2L() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition nextLeft = this.du.createParametricAcquisition("prev_right", "10/10/2017 15:40:00", "10/10/2017 15:42:00", "left", "SAT_1");
        nextLeft.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "right", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(nextLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLeft, nextLeft.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.CMGA);
        manNext.setType(ManeuverType.PitchCPS);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(false);
        lastMan.setType(ManeuverType.RollSlew);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        Maneuver manPrev = this.du.createManeuver("man1", nextLeft.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:55:57", "10/10/2017 14:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Acquisition acq = this.leftAttitude.findNextLeft(firstCheck, manTreemap, acqTreemap);
        System.out.println("acq: " + acq);
        assertEquals(nextLeft, acq);
    }

    @Test
    public void testFindNextLeft_man_R2L_NoNextMan() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition nextLeft = this.du.createParametricAcquisition("prev_right", "10/10/2017 12:40:00", "10/10/2017 12:42:00", "left", "SAT_1");
        nextLeft.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "right", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(nextLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLeft, nextLeft.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.CMGA);
        manNext.setType(ManeuverType.PitchCPS);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(false);
        lastMan.setType(ManeuverType.RollSlew);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        Maneuver manPrev = this.du.createManeuver("man1", nextLeft.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:55:57", "10/10/2017 14:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Acquisition acq = this.leftAttitude.findNextLeft(firstCheck, manTreemap, acqTreemap);
        System.out.println("acq: " + acq);
        assertEquals(null, acq);
    }

    @Test
    public void testFindNextLeft_noNextAcq() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:12:00", "10/10/2017 14:19:00", "right", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.CMGA);
        manNext.setType(ManeuverType.PitchCPS);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(false);
        lastMan.setType(ManeuverType.RollSlew);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        Maneuver manPrev = this.du.createManeuver("man1", acqForTest.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:55:57", "10/10/2017 14:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Acquisition acq = this.leftAttitude.findNextLeft(firstCheck, manTreemap, acqTreemap);
        System.out.println("acq: " + acq);
        assertEquals(null, acq);
    }

    @Test
    public void testFindNextLeft_man_L2R() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition nextLeft = this.du.createParametricAcquisition("prev_right", "10/10/2017 15:40:00", "10/10/2017 15:42:00", "left", "SAT_1");
        nextLeft.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:14:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(nextLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLeft, nextLeft.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.CMGA);
        manNext.setType(ManeuverType.PitchCPS);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("man3", next_right.getId(), acqForTest.getId(), "10/10/2017 14:08:57", "10/10/2017 14:12:57", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        lastMan.setType(ManeuverType.RollSlew);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        Maneuver manPrev = this.du.createManeuver("man1", nextLeft.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:55:57", "10/10/2017 14:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(false);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Acquisition acq = this.leftAttitude.findNextLeft(firstCheck, manTreemap, acqTreemap);
        System.out.println("acq: " + acq);
        assertEquals(acqForTest, acq);

    }

    @Test
    public void testFindNextLeft_man_L2R_not_exists_man() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);
        Acquisition nextLeft = this.du.createParametricAcquisition("prev_right", "10/10/2017 15:40:00", "10/10/2017 15:42:00", "left", "SAT_1");
        nextLeft.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:03:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:14:00", "10/10/2017 14:19:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(nextLeft.getStartTime().getTime(), new EnergyAssociatedToTask(nextLeft, nextLeft.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();

        Maneuver manNext = this.du.createManeuver("man2", anotherLeftInLeftPeriod.getId(), next_right.getId(), "10/10/2017 13:15:03", "10/10/2017 13:19:03", "SAT_1", Actuator.CMGA);
        manNext.setType(ManeuverType.PitchCPS);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver manPrev = this.du.createManeuver("man1", nextLeft.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 14:55:57", "10/10/2017 14:59:57", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(false);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Acquisition acq = this.leftAttitude.findNextLeft(firstCheck, manTreemap, acqTreemap);
        System.out.println("acq: " + acq);
        assertEquals(null, acq);

    }

    @Test
    public void testProcessResources_right_prevLEft_nextLeft() throws Exception
    {
        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        List<DateResource> startAndStopLeftPeriod = new ArrayList<>();
        startAndStopLeftPeriod.add(firstCheck);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);

        Acquisition anotherLeftInLeftPeriod2 = this.du.createParametricAcquisition("anotherLeftInLeftPeriod2", "10/10/2017 13:17:00", "10/10/2017 13:18:00", "left", "SAT_1");
        anotherLeftInLeftPeriod2.setEss(30);

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 14:19:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:58:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:16:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:00", "10/10/2017 12:59:00", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod2.getId(), next_right.getId(), "10/10/2017 13:21:00", "10/10/2017 13:25:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), acqForTest.getId(), "10/10/2017 14:15:00", "10/10/2017 14:19:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = lastMan.getStartTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        expectedEssRight = next_right.getEss();
        expectedTimeRight = ((endSearch - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch)) / 60000;
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + anotherLeftInLeftPeriod2.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);

        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);

        useSilent = true;
        previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssLeft * 2, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight * 2, previousProfile.getEssRight(), 0);

        this.leftAttitude.processResources(startAndStopLeftPeriod, next_right, this.droolsParams, acqTreemap, silTreemap, manTreemap, 30.0);
    }

    @Test
    public void testProcessResources_right_noValidPeriod() throws Exception
    {

        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        List<DateResource> startAndStopLeftPeriod = new ArrayList<>();
        startAndStopLeftPeriod.add(firstCheck);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);

        Acquisition anotherLeftInLeftPeriod2 = this.du.createParametricAcquisition("anotherLeftInLeftPeriod2", "10/10/2017 13:17:00", "10/10/2017 13:18:00", "left", "SAT_1");
        anotherLeftInLeftPeriod2.setEss(30);

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 14:19:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:58:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:16:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:00", "10/10/2017 12:59:00", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod2.getId(), next_right.getId(), "10/10/2017 13:21:00", "10/10/2017 13:25:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), acqForTest.getId(), "10/10/2017 14:15:00", "10/10/2017 14:19:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = lastMan.getStartTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        expectedEssRight = next_right.getEss();
        expectedTimeRight = ((endSearch - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch)) / 60000;
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + anotherLeftInLeftPeriod2.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);

        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);

        useSilent = true;
        previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssLeft * 2, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight * 2, previousProfile.getEssRight(), 0);

        this.leftAttitude.processResources(startAndStopLeftPeriod, next_right, this.droolsParams, acqTreemap, silTreemap, manTreemap, 30.0);
    }

    @Test
    public void testProcessResources_right_onlyPrev() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);

        Acquisition anotherLeftInLeftPeriod2 = this.du.createParametricAcquisition("anotherLeftInLeftPeriod2", "10/10/2017 13:17:00", "10/10/2017 13:18:00", "left", "SAT_1");
        anotherLeftInLeftPeriod2.setEss(30);

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 14:19:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:58:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:16:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:00", "10/10/2017 12:59:00", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod2.getId(), next_right.getId(), "10/10/2017 13:21:00", "10/10/2017 13:25:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), acqForTest.getId(), "10/10/2017 14:15:00", "10/10/2017 14:19:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = lastMan.getStartTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        expectedEssRight = next_right.getEss();
        expectedTimeRight = ((endSearch - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch)) / 60000;
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + anotherLeftInLeftPeriod2.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);

        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);

        useSilent = true;
        previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssLeft * 2, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight * 2, previousProfile.getEssRight(), 0);

        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:57:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:23:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        List<DateResource> startAndStopLeftPeriod = new ArrayList<>();
        startAndStopLeftPeriod.add(firstCheck);

        this.leftAttitude.processResources(startAndStopLeftPeriod, next_right, this.droolsParams, acqTreemap, silTreemap, manTreemap, 30.0);
    }

    @Test
    public void testProcessResources_right_onlyPrev_percentMan0() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        double percentManLeft = 0.0;

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        this.droolsParams.getSatWithId("1").getSatelliteProperties().setPercentManLeftC2(percentManLeft);
        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);

        Acquisition anotherLeftInLeftPeriod2 = this.du.createParametricAcquisition("anotherLeftInLeftPeriod2", "10/10/2017 13:17:00", "10/10/2017 13:18:00", "left", "SAT_1");
        anotherLeftInLeftPeriod2.setEss(30);

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 14:19:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:57:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:16:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:00", "10/10/2017 12:59:00", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod2.getId(), next_right.getId(), "10/10/2017 13:21:00", "10/10/2017 13:25:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), acqForTest.getId(), "10/10/2017 14:15:00", "10/10/2017 14:19:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = lastMan.getStartTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        expectedEssRight = next_right.getEss();
        expectedTimeRight = ((endSearch - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch)) / 60000;
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + anotherLeftInLeftPeriod2.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);

        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);

        useSilent = true;
        previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssLeft * 2, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight * 2, previousProfile.getEssRight(), 0);

        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:59:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:21:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        List<DateResource> startAndStopLeftPeriod = new ArrayList<>();
        startAndStopLeftPeriod.add(firstCheck);

        // TODO : completare con assert
        this.leftAttitude.processResources(startAndStopLeftPeriod, next_right, this.droolsParams, acqTreemap, silTreemap, manTreemap, percentManLeft);
    }

    @Test
    public void testProcessResources_right_dateStartAfterDateEnd() throws Exception
    {

        DateResource firstCheck = new DateResource();
        Date start = DroolsUtils.createDate("10/10/2017 12:40:00");
        Date stop = DroolsUtils.createDate("10/10/2017 13:00:00");
        firstCheck.setStart(start);
        firstCheck.setStop(stop);

        List<DateResource> startAndStopLeftPeriod = new ArrayList<>();
        startAndStopLeftPeriod.add(firstCheck);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("running test : testComputeEssValuesInInterval_prevOrbit ");

        double expectedEssRight = 0;
        double expectedTimeRight = 0;
        double expectedEssLeft = 0;
        double expectedTimeLeft = 0;
        long startSearch = 0;
        long endSearch = 0;

        Acquisition anotherLeftInLeftPeriod = this.du.createParametricAcquisition("anotherLeftInLeftPeriod", "10/10/2017 13:00:00", "10/10/2017 13:01:00", "left", "SAT_1");
        anotherLeftInLeftPeriod.setEss(30);

        Acquisition anotherLeftInLeftPeriod2 = this.du.createParametricAcquisition("anotherLeftInLeftPeriod2", "10/10/2017 13:17:00", "10/10/2017 13:18:00", "left", "SAT_1");
        anotherLeftInLeftPeriod2.setEss(30);

        Acquisition previousRight = this.du.createParametricAcquisition("prev_right", "10/10/2017 11:58:00", "10/10/2017 11:59:00", "right", "SAT_1");
        previousRight.setEss(20);
        Acquisition next_right = this.du.createParametricAcquisition("next_right", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "right", "SAT_1");
        next_right.setEss(15);
        Acquisition acqForTest = this.du.createParametricAcquisition("acqForTest", "10/10/2017 14:20:00", "10/10/2017 14:21:00", "left", "SAT_1");
        acqForTest.setEss(40);

        TreeMap<Long, EnergyAssociatedToTask> acqTreemap = new TreeMap<>();
        acqTreemap.put(acqForTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod2.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));
        acqTreemap.put(anotherLeftInLeftPeriod.getStartTime().getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        acqTreemap.put(previousRight.getStartTime().getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        acqTreemap.put(next_right.getStartTime().getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));

        TreeMap<Long, EnergyAssociatedToTask> silTreemap = new TreeMap<>();
        silTreemap.put(DroolsUtils.createDate("10/10/2017 14:19:00").getTime(), new EnergyAssociatedToTask(acqForTest, acqForTest.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 12:59:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod, anotherLeftInLeftPeriod.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 11:58:00").getTime(), new EnergyAssociatedToTask(previousRight, previousRight.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:59:00").getTime(), new EnergyAssociatedToTask(next_right, next_right.getEss()));
        silTreemap.put(DroolsUtils.createDate("10/10/2017 13:16:00").getTime(), new EnergyAssociatedToTask(anotherLeftInLeftPeriod2, anotherLeftInLeftPeriod2.getEss()));

        TreeMap<Long, Maneuver> manTreemap = new TreeMap<>();
        Maneuver manPrev = this.du.createManeuver("manPrev", previousRight.getId(), anotherLeftInLeftPeriod.getId(), "10/10/2017 12:55:00", "10/10/2017 12:59:00", "SAT_1", Actuator.ReactionWheels);
        manPrev.setRightToLeftFlag(true);
        manTreemap.put(manPrev.getStartTime().getTime(), manPrev);

        Maneuver manNext = this.du.createManeuver("manNext", anotherLeftInLeftPeriod2.getId(), next_right.getId(), "10/10/2017 13:21:00", "10/10/2017 13:25:00", "SAT_1", Actuator.ReactionWheels);
        manNext.setRightToLeftFlag(false);
        manTreemap.put(manNext.getStartTime().getTime(), manNext);

        Maneuver lastMan = this.du.createManeuver("lastMan", next_right.getId(), acqForTest.getId(), "10/10/2017 14:15:00", "10/10/2017 14:19:00", "SAT_1", Actuator.ReactionWheels);
        lastMan.setRightToLeftFlag(true);
        manTreemap.put(lastMan.getStartTime().getTime(), lastMan);

        endSearch = lastMan.getStartTime().getTime();
        startSearch = endSearch - (97 * 60000);

        System.out.println("start of check = " + new Date(startSearch));
        System.out.println("end of check = " + new Date(endSearch));
        System.out.println("acq in order are : \n" + previousRight + " ,\n" + anotherLeftInLeftPeriod + " ,\n" + next_right + ",\n" + acqForTest);
        System.out.println("we are checking interval from :" + new Date(startSearch) + "\nto : " + anotherLeftInLeftPeriod.getEndTime());

        expectedEssRight = next_right.getEss();
        expectedTimeRight = ((endSearch - manNext.getEndTime().getTime()) + (manPrev.getStartTime().getTime() - startSearch)) / 60000;
        expectedTimeLeft = (manNext.getStartTime().getTime() - manPrev.getEndTime().getTime()) / 60000;
        expectedEssLeft = anotherLeftInLeftPeriod.getEss() + anotherLeftInLeftPeriod2.getEss();

        System.out.println("expected ess spent in right : " + expectedEssRight);
        System.out.println("expected time spent in right : " + expectedTimeRight);

        System.out.println("expected ess spent in left : " + expectedEssLeft);
        System.out.println("expected time spent in left : " + expectedTimeLeft);

        boolean useSilent = false;
        OrbitResources previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());
        assertEquals(expectedEssRight, previousProfile.getEssRight(), 0);

        assertEquals(expectedEssLeft, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);

        useSilent = true;
        previousProfile = this.leftAttitude.computeEssValuesInInterval(useSilent, 50.0, startSearch, endSearch, acqTreemap, silTreemap, manTreemap);
        System.out.println("left profile : " + previousProfile);

        System.out.println("time in right : " + previousProfile.getTimeInRight());

        assertEquals(expectedEssLeft * 2, previousProfile.getEssLeft(), 0);
        assertEquals(71, previousProfile.getTimeInRight(), 0);
        assertEquals(26, previousProfile.getTimeInLeft(), 0);
        assertEquals(expectedEssRight * 2, previousProfile.getEssRight(), 0);

        this.leftAttitude.processResources(startAndStopLeftPeriod, next_right, this.droolsParams, acqTreemap, silTreemap, manTreemap, 30.0);
    }
}
