
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TaskType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class StorageTest
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "initPlan";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void createStorage_HV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        dto1.setPol(Polarization.HV);

        /** The packet store size H. */
        int packetStoreSizeH = 20;

        /** The packet store size V. */
        int packetStoreSizeV = 30;

        dto1.setSizeH(packetStoreSizeH);
        dto1.setSizeV(packetStoreSizeV);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Storage sto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());
        System.out.println(sto.getPacketsStore(Polarization.HH).getUsedSectors());
        System.out.println(sto.getNumberOfSectors(Polarization.HH));

        assertEquals(packetStoreSizeV, sto.getNumberOfSectors(Polarization.VV));
        assertEquals(packetStoreSizeH, sto.getNumberOfSectors(Polarization.HH));

        assertEquals(sto.getNumberOfSectors(Polarization.HH), sto.getPacketsStore(Polarization.HH).getUsedSectors());
        assertEquals(sto.getNumberOfSectors(Polarization.VV), sto.getPacketsStore(Polarization.VV).getUsedSectors());

        System.out.println("ps v " + sto.getPacketsStore(Polarization.VV));
        System.out.println("number of sectors v : " + sto.getNumberOfSectors(Polarization.VV));
        System.out.println("used sectors : " + sto.getPacketsStore(Polarization.VV).getUsedSectors());

        assertEquals(sto.getNumberOfSectors(Polarization.VV), sto.getPacketsStore(Polarization.VV).getUsedSectors());

        System.out.println("ps hv " + sto.getPacketsStore(Polarization.VV).getUsedSectors() + sto.getPacketsStore(Polarization.HH).getUsedSectors());
        System.out.println("number of sectors hv : " + (sto.getNumberOfSectors(Polarization.VV) + sto.getNumberOfSectors(Polarization.HH)));
        System.out.println("used sectors hv : " + sto.getPacketsStore(Polarization.VV).getUsedSectors() + sto.getPacketsStore(Polarization.HH).getUsedSectors());
        assertEquals(sto.getNumberOfSectors(Polarization.VV) + sto.getNumberOfSectors(Polarization.HH), (sto.getPacketsStore(Polarization.VV).getUsedSectors() + sto.getPacketsStore(Polarization.HH).getUsedSectors()));

        /** The ugs id. */
        String ugsId = null;

        /** The pol. */
        Polarization pol = Polarization.HV;

        sto.setUgsId(ugsId);
        sto.setTaskMark(TaskMarkType.DELETED);
        sto.setTaskType(TaskType.STORE);

        assertEquals(dto1.getDtoId(), sto.getRelatedAcqId());
        assertEquals(ugsId, sto.getUgsId());
        assertEquals(TaskMarkType.DELETED, sto.getTaskMark());

        System.out.println(sto.getNumberOfSectors(pol));
    }

    @Test
    public void createStorage_HH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        dto1.setPol(Polarization.HH);

        /** The packet store size H. */
        int packetStoreSizeH = 20;

        /** The packet store size V. */
        int packetStoreSizeV = 0;

        dto1.setSizeH(packetStoreSizeH);
        dto1.setSizeV(packetStoreSizeV);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Storage sto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());
        System.out.println("pol H " + sto.getPacketsStore(Polarization.HH).getUsedSectors());
        System.out.println("pol H " + sto.getNumberOfSectors(Polarization.HH));

        System.out.println("pol v " + sto.getPacketsStore(Polarization.VV));
        System.out.println("pol v " + sto.getNumberOfSectors(Polarization.VV));

        assertEquals(sto.getNumberOfSectors(Polarization.HH), sto.getPacketsStore(Polarization.HH).getUsedSectors());
        System.out.println("pol v " + sto.getPacketsStore(Polarization.VV));

        System.out.println("ps v " + sto.getPacketsStore(Polarization.VV));
        System.out.println("number of sectors v : " + sto.getNumberOfSectors(Polarization.VV));

        assertEquals(packetStoreSizeV, sto.getNumberOfSectors(Polarization.VV));
        assertEquals(packetStoreSizeH, sto.getNumberOfSectors(Polarization.HH));

        /** The ugs id. */
        String ugsId = null;

        /** The pol. */
        Polarization pol = Polarization.HH;

        sto.setUgsId(ugsId);
        sto.setTaskMark(TaskMarkType.DELETED);
        sto.setTaskType(TaskType.STORE);

        assertEquals(dto1.getDtoId(), sto.getRelatedAcqId());
        assertEquals(ugsId, sto.getUgsId());
        assertEquals(TaskMarkType.DELETED, sto.getTaskMark());

        System.out.println(sto.getNumberOfSectors(pol));
    }

    @Test
    public void createStorage_VV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : createStorage_VV \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        dto1.setPol(Polarization.VV);

        /** The packet store size H. */
        int packetStoreSizeH = 0;

        /** The packet store size V. */
        int packetStoreSizeV = 30;

        dto1.setSizeH(packetStoreSizeH);
        dto1.setSizeV(packetStoreSizeV);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Storage sto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());

        assertEquals(packetStoreSizeV, sto.getNumberOfSectors(Polarization.VV));
        assertEquals(packetStoreSizeH, sto.getNumberOfSectors(Polarization.HH));

        System.out.println("ps v " + sto.getPacketsStore(Polarization.VV));
        System.out.println("number of sectors v : " + sto.getNumberOfSectors(Polarization.VV));
        System.out.println("used sectors : " + sto.getPacketsStore(Polarization.VV).getUsedSectors());

        System.out.println("ps v " + sto.getPacketsStore(Polarization.HH));
        System.out.println("number of sectors v : " + sto.getNumberOfSectors(Polarization.HH));

        assertEquals(sto.getNumberOfSectors(Polarization.VV), sto.getPacketsStore(Polarization.VV).getUsedSectors());

        /** The ugs id. */
        String ugsId = null;

        /** The pol. */
        Polarization pol = Polarization.VV;

        sto.setUgsId(ugsId);
        sto.setTaskMark(TaskMarkType.DELETED);
        sto.setTaskType(TaskType.STORE);

        assertEquals(dto1.getDtoId(), sto.getRelatedAcqId());
        assertEquals(ugsId, sto.getUgsId());
        assertEquals(TaskMarkType.DELETED, sto.getTaskMark());

        System.out.println(sto.getNumberOfSectors(pol));
    }

    @Test
    public void createStorage_VH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        dto1.setPol(Polarization.VH);

        /** The packet store size H. */
        int packetStoreSizeH = 20;

        /** The packet store size V. */
        int packetStoreSizeV = 30;

        dto1.setSizeH(packetStoreSizeH);
        dto1.setSizeV(packetStoreSizeV);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Storage sto = this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, dto1.getSatelliteId()).get(dto1.getDtoId());
        System.out.println(sto.getPacketsStore(Polarization.HH).getUsedSectors());
        System.out.println(sto.getNumberOfSectors(Polarization.HH));

        System.out.println(sto.getPacketsStore(Polarization.VV).getUsedSectors());
        System.out.println(sto.getNumberOfSectors(Polarization.VV));

        assertEquals(packetStoreSizeV, sto.getNumberOfSectors(Polarization.VV));
        assertEquals(packetStoreSizeH, sto.getNumberOfSectors(Polarization.HH));
        System.out.println("ps v " + sto.getPacketsStore(Polarization.VV));
        System.out.println("number of sectors v : " + sto.getNumberOfSectors(Polarization.VV));
        System.out.println("used sectors : " + sto.getPacketsStore(Polarization.VV).getUsedSectors());

        assertEquals(sto.getNumberOfSectors(Polarization.VV), sto.getPacketsStore(Polarization.VV).getUsedSectors());

        System.out.println("ps hv " + sto.getPacketsStore(Polarization.VV).getUsedSectors() + sto.getPacketsStore(Polarization.HH).getUsedSectors());
        System.out.println("number of sectors hv : " + (sto.getNumberOfSectors(Polarization.VV) + sto.getNumberOfSectors(Polarization.HH)));
        System.out.println("used sectors hv : " + sto.getPacketsStore(Polarization.VV).getUsedSectors() + sto.getPacketsStore(Polarization.HH).getUsedSectors());
        assertEquals(sto.getNumberOfSectors(Polarization.VV) + sto.getNumberOfSectors(Polarization.HH), (sto.getPacketsStore(Polarization.VV).getUsedSectors() + sto.getPacketsStore(Polarization.HH).getUsedSectors()));

        /** The ugs id. */
        String ugsId = null;

        /** The pol. */
        Polarization pol = Polarization.VH;

        sto.setUgsId(ugsId);
        sto.setTaskMark(TaskMarkType.DELETED);
        sto.setTaskType(TaskType.STORE);

        assertEquals(dto1.getDtoId(), sto.getRelatedAcqId());
        assertEquals(ugsId, sto.getUgsId());
        assertEquals(TaskMarkType.DELETED, sto.getTaskMark());

        System.out.println(sto.getNumberOfSectors(pol));
    }

}
