
package com.nais.spla.brm.library.main.ontology.enums;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class PAWTypeTest
{

    @Test
    public void testEnumPAWType()
    {
        List<PAWType> allPAWTypeForTest = new ArrayList<>(Arrays.asList(PAWType.CAL, PAWType.CMS, PAWType.GENERIC, PAWType.KCR, PAWType.KCR, PAWType.STTOCCULTATION, PAWType.SWM, PAWType.MAN));
        PAWType[] allPAWType = PAWType.values();
        for (int i = 0; i < allPAWType.length; i++)
        {
            for (int j = 0; j < allPAWTypeForTest.size(); j++)
            {
                if (allPAWType[i].equals(allPAWTypeForTest.get(j)))
                {
                    allPAWTypeForTest.remove(j);
                    j--;
                }
            }
        }

        PAWType type = null;
        type = PAWType.valueOf("GENERIC");
        System.out.println("Selected : " + type);

        assertEquals(0, allPAWTypeForTest.size());
    }
}
