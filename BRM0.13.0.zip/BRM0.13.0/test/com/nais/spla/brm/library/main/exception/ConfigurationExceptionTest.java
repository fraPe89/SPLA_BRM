
package com.nais.spla.brm.library.main.exception;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ConfigurationExceptionTest
{

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testConfigurationException() throws Exception
    {
        ConfigurationException configExcept = null;

        System.out.println("expetion : +" + configExcept);

        String message = "testConfigException";
        configExcept = new ConfigurationException(message);

        System.out.println("expetion : +" + configExcept);
    }

}
