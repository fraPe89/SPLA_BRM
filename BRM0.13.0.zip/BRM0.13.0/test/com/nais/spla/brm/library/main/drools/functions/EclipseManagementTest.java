
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.resources.Eclipse;

public class EclipseManagementTest
{

    private EclipseManagement eclipseMng = new EclipseManagement();
    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private StubResources stub = new StubResources();
    private DroolsParameters droolsParams = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestEclipseRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void testCheckInInterval_minEclipsePeriodNotReached() throws Exception
    {

        Date start = DroolsUtils.createDate("17/01/2018 11:08:00");
        Date end = DroolsUtils.createDate("17/01/2018 11:12:00");

        Eclipse e1 = this.stub.createEclipse("17/01/2018 11:10:00", "17/01/2018 11:15:00", "SAT_1");
        Eclipse e2 = this.stub.createEclipse("17/01/2018 13:10:00", "17/01/2018 13:15:00", "SAT_1");
        Eclipse e3 = this.stub.createEclipse("17/01/2018 15:10:00", "17/01/2018 15:15:00", "SAT_1");

        List<Eclipse> allEclipsesForTest = new ArrayList<>(Arrays.asList(e1, e2, e3));

        double minTempEclipseForTest = 2000;

        boolean inEclipse = this.eclipseMng.checkInInterval(start, end, allEclipsesForTest, minTempEclipseForTest);
        assertEquals(false, inEclipse);
    }

    @Test
    public void testCheckInInterval_minEclipsePeriodReached() throws Exception
    {

        Date start = DroolsUtils.createDate("17/01/2018 11:10:00");
        Date end = DroolsUtils.createDate("17/01/2018 11:20:00");

        Eclipse e1 = this.stub.createEclipse("17/01/2018 11:10:00", "17/01/2018 11:15:00", "SAT_1");
        Eclipse e2 = this.stub.createEclipse("17/01/2018 13:10:00", "17/01/2018 13:15:00", "SAT_1");
        Eclipse e3 = this.stub.createEclipse("17/01/2018 15:10:00", "17/01/2018 15:15:00", "SAT_1");

        List<Eclipse> allEclipsesForTest = new ArrayList<>(Arrays.asList(e1, e2, e3));

        double minTempEclipseForTest = 20;

        boolean inEclipse = this.eclipseMng.checkInInterval(start, end, allEclipsesForTest, minTempEclipseForTest);
        assertEquals(true, inEclipse);
    }

    @Test
    public void testCalculateAmountOfEclipse_no_eclipse() throws Exception
    {
        Date start = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date end = DroolsUtils.createDate("17/01/2018 13:00:00");
        Eclipse e1 = this.stub.createEclipse("17/01/2018 08:00:00", "17/01/2018 08:06:00", "SAT_1");
        long returnedPeriodEclipse = this.eclipseMng.calculateAmountOfEclipse(start, end, e1);
        long expectedPeriodEclipse = 0;
        assertEquals(expectedPeriodEclipse, returnedPeriodEclipse);
    }

    @Test
    public void testCalculateAmountOfEclipse_eclipseTotallyIncludedInPeriod() throws Exception
    {
        Date start = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date end = DroolsUtils.createDate("17/01/2018 13:00:00");
        Eclipse e1 = this.stub.createEclipse("17/01/2018 11:05:00", "17/01/2018 11:10:00", "SAT_1");
        long returnedPeriodEclipse = this.eclipseMng.calculateAmountOfEclipse(start, end, e1);
        long expectedPeriodEclipse = e1.getEndTime().getTime() - e1.getStartTime().getTime();
        assertEquals(expectedPeriodEclipse, returnedPeriodEclipse);
    }

    @Test
    public void testCalculateAmountOfEclipse_periodTotallyIncluded() throws Exception
    {
        Date start = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date end = DroolsUtils.createDate("17/01/2018 13:00:00");
        Eclipse e1 = this.stub.createEclipse("17/01/2018 10:55:00", "17/01/2018 13:05:00", "SAT_1");
        long returnedPeriodEclipse = this.eclipseMng.calculateAmountOfEclipse(start, end, e1);
        long expectedPeriodEclipse = end.getTime() - start.getTime();
        assertEquals(expectedPeriodEclipse, returnedPeriodEclipse);
    }

    @Test
    public void testCalculateAmountOfEclipse_exceedInStart() throws Exception
    {
        Date start = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date end = DroolsUtils.createDate("17/01/2018 13:00:00");
        Eclipse e1 = this.stub.createEclipse("17/01/2018 10:48:00", "17/01/2018 11:06:00", "SAT_1");
        long returnedPeriodEclipse = this.eclipseMng.calculateAmountOfEclipse(start, end, e1);
        long expectedPeriodEclipse = e1.getEndTime().getTime() - start.getTime();
        assertEquals(expectedPeriodEclipse, returnedPeriodEclipse);
    }

    @Test
    public void testCalculateAmountOfEclipse_exceedInEnd() throws Exception
    {
        Date start = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date end = DroolsUtils.createDate("17/01/2018 13:00:00");
        Eclipse e1 = this.stub.createEclipse("17/01/2018 12:42:00", "17/01/2018 13:06:00", "SAT_1");
        long returnedPeriodEclipse = this.eclipseMng.calculateAmountOfEclipse(start, end, e1);
        long expectedPeriodEclipse = end.getTime() - e1.getStartTime().getTime();
        assertEquals(expectedPeriodEclipse, returnedPeriodEclipse);
    }

    @Test
    public void testCheckTimeEclipse_eclipseInFirstCheck() throws Exception
    {
        Eclipse e1 = this.stub.createEclipse("17/01/2018 11:10:00", "17/01/2018 11:15:00", "SAT_1");
        Eclipse e2 = this.stub.createEclipse("17/01/2018 13:10:00", "17/01/2018 13:15:00", "SAT_1");
        Eclipse e3 = this.stub.createEclipse("17/01/2018 15:10:00", "17/01/2018 15:15:00", "SAT_1");

        List<Eclipse> allEclipsesForTest = new ArrayList<>(Arrays.asList(e1, e2, e3));

        Date startCheck1 = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck1 = DroolsUtils.createDate("17/01/2018 12:00:00");

        Date startCheck2 = DroolsUtils.createDate("17/01/2018 12:00:00");
        Date endCheck2 = DroolsUtils.createDate("17/01/2018 13:00:00");

        double minTempEclipseForTest = 20;

        this.eclipseMng.checkTimeEclipse(startCheck1, endCheck1, startCheck2, endCheck2, allEclipsesForTest, minTempEclipseForTest);
    }

    @Test
    public void testCheckTimeEclipse_eclipseInSecondCheck() throws Exception
    {
        Eclipse e1 = this.stub.createEclipse("17/01/2018 11:10:00", "17/01/2018 11:15:00", "SAT_1");
        Eclipse e2 = this.stub.createEclipse("17/01/2018 13:10:00", "17/01/2018 13:15:00", "SAT_1");
        Eclipse e3 = this.stub.createEclipse("17/01/2018 15:10:00", "17/01/2018 15:15:00", "SAT_1");

        List<Eclipse> allEclipsesForTest = new ArrayList<>(Arrays.asList(e1, e2, e3));

        Date startCheck1 = DroolsUtils.createDate("17/01/2018 10:00:00");
        Date endCheck1 = DroolsUtils.createDate("17/01/2018 11:00:00");

        Date startCheck2 = DroolsUtils.createDate("17/01/2018 11:00:00");
        Date endCheck2 = DroolsUtils.createDate("17/01/2018 12:00:00");

        double minTempEclipseForTest = 20;

        this.eclipseMng.checkTimeEclipse(startCheck1, endCheck1, startCheck2, endCheck2, allEclipsesForTest, minTempEclipseForTest);
    }

}
