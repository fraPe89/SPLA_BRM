
package com.nais.spla.brm.library.main.ontology.resourceData;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CreditCardTest
{

    @Test
    public void createCreditCard()
    {

        String debitorId = "debitorTest";

        double BICLent = 20;

        String forAcq = "acqId";

        boolean donation = false;

        boolean isPrevious = false;

        CreditCard credit = new CreditCard(debitorId, BICLent, forAcq);
        credit.setDonation(donation);
        credit.setPrevious(isPrevious);
        credit.setBICLent(BICLent);
        assertEquals(BICLent, credit.getBICLent(), 0);
        assertEquals(debitorId, credit.getDebitor());
        assertEquals(forAcq, credit.getForAcq());
        assertEquals(isPrevious, credit.isPrevious());
        assertEquals(donation, credit.isDonation());
        System.out.println(credit.toString());
    }

}
