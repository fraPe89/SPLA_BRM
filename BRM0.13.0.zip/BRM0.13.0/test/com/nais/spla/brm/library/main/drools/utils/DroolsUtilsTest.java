
package com.nais.spla.brm.library.main.drools.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfManeuver;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.CMGAxis;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.PassThrough;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.InitPlanTasks;

public class DroolsUtilsTest
{

    DroolsUtils du = new DroolsUtils();
    StubResources stub = new StubResources();
    DroolsParameters droolsParams = new DroolsParameters();

    @Test(expected = java.text.ParseException.class)
    public void testCreateSilent() throws Exception
    {
        String startTime = "10/10/2017 17:00:00";
        String endTime = "10/10/2017 17:03:00";
        String associatedAcq = "acq1";
        double energy = 25;
        Silent returnedSilent = this.du.createSilent(startTime, endTime, associatedAcq, energy);
        assertTrue(returnedSilent != null);

        String startTime2 = "10/10/2017 17:00:00";
        String endTime2 = "10/10/2017 17:03000";
        String associatedAcq2 = "acq2";
        double energy2 = 25;

        Silent returnedSilent2 = this.du.createSilent(startTime2, endTime2, associatedAcq2, energy2);
        System.out.println(returnedSilent2);
        assertTrue(returnedSilent2 == null);

    }

    @Test
    public void testCreateSingleDto() throws Exception
    {
        String startTime = "10/10/2017 17:00:00";
        String endTime = "10/10/2017 17:03:00";
        String lookSide = "left";
        String satelliteID = "SSAR1";
        DTO dto = null;
        dto = this.du.createSingleDto(startTime, endTime, lookSide, satelliteID);
        assertTrue(dto != null);
    }

    @Test
    public void testCreateSingleDto_ParseException() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String lookSide = "left";
        String satelliteID = "SSAR1";
        DTO dto = null;
        dto = this.du.createSingleDto(startTime, endTime, lookSide, satelliteID);
        assertTrue(dto == null);
    }

    @Test
    public void testCreatePaw() throws Exception
    {
        String startTime = "10/10/2017 11:00:00";
        String endTime = "10/10/2017 17:03:00";
        int idPaw = 1;
        String satelliteID = "SSAR1";
        PAW paw = null;
        paw = this.stub.createPaw(idPaw, satelliteID, startTime, endTime, PAWType.GENERIC);
        assertEquals(idPaw, paw.getActivityId());
        assertEquals(satelliteID, paw.getSatelliteId());
    }

    @Test
    public void testCreatePaw_ParseException() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        int idPaw = 1;
        String satelliteID = "SSAR1";
        this.stub.createPaw(idPaw, satelliteID, startTime, endTime, PAWType.GENERIC);
    }

    @Test
    public void testCreateHpExclusionSegment_ParseException() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String idSegment = "1";
        String satelliteID = "SSAR1";
        this.stub.createHPExclusion(idSegment, startTime, "right", endTime, "left", satelliteID, true, false);
    }

    @Test(expected = java.text.ParseException.class)
    public void testCreateEclipse() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String satelliteID = "SSAR1";
        this.stub.createEclipse(startTime, endTime, satelliteID);
    }

    @Test
    public void testCreateDownload_exception() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String satelliteID = "SSAR1";
        this.du.createDownload(satelliteID, startTime, endTime, DownlinkStrategy.DELETE, true);
    }

    @Test
    public void testCreateManeuver() throws Exception
    {
        TaskMarkType taskMark = TaskMarkType.CONFIRMED;
        boolean forHpSeg = false;
        String startTime = "10/10/2017 11:00:00";
        String endTime = "10/10/2017 11:03:00";
        String satelliteID = "SSAR1";
        Maneuver man = this.du.createManeuver("manID", "x", "dto1", startTime, endTime, satelliteID, Actuator.CMGA);
        man.setTaskMark(taskMark);
        assertEquals(taskMark, man.getTaskMark());

        man.setForHpSegm(forHpSeg);
        assertEquals(forHpSeg, man.isForHpSegm());

        ReasonOfManeuver reason = ReasonOfManeuver.acqHpSeg;
        man.setReasonOfMan(reason);
        assertEquals(reason, man.getReasonOfMan());

    }

    @Test
    public void testCreateManeuver_exception() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String satelliteID = "SSAR1";
        this.du.createManeuver("manID", "x", "dto1", startTime, endTime, satelliteID, Actuator.CMGA);
    }

    @Test
    public void testCreatePt_exception() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String satelliteID = "SSAR1";
        this.du.createDownload(satelliteID, startTime, endTime, DownlinkStrategy.DELETE, true);
    }

    @Test
    public void testCreateGenericTask_exception() throws Exception
    {
        String startTime = "10/10/2017 117:00:00";
        String endTime = "10/10/2017 17:0300";
        String satelliteID = "SSAR1";
        this.du.createGenericTask(satelliteID, startTime, endTime);
    }

    @Test
    public void testCreateStorage_exception() throws Exception
    {
        String startTime = "test7 117:@0:00";
        String endTime = "10/10/2017 17:0300";
        String satelliteID = "SSAR1";
        this.du.createStorage("Dtoid", startTime, endTime, satelliteID, 20, 20, Polarization.HH);
    }

    @Test
    public void testCreateRamp() throws Exception
    {
        String startTime = "10/10/2017 11:00:00";
        String satId = "SatId";
        String idTask = "idTask";
        TaskMarkType taskMark = TaskMarkType.CONFIRMED;
        RampCMGA newRamp = this.du.createRamp(startTime, true);
        newRamp.setTaskMark(taskMark);
        assertEquals(taskMark, newRamp.getTaskMark());
        newRamp.setSatelliteId(satId);
        newRamp.setIdTask(idTask);
    }

    @Test
    public void testCreateRampException() throws Exception
    {
        String startTime = "10/10/2017 1aaa:00:00";
        RampCMGA newRamp = this.du.createRamp(startTime, true);
        System.out.println(newRamp);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDeepClone() throws Exception
    {
        List<Partner> allPartners1 = new ArrayList<>();
        double maxBicForTest = 100;
        Partner p1 = new Partner("Partner_1", null, maxBicForTest, 20);
        Partner p2 = new Partner("Partner_2", null, maxBicForTest, 30);
        Partner p3 = new Partner("Partner_3", null, maxBicForTest, 40);
        Partner p4 = new Partner("Partner_4", null, maxBicForTest, 50);
        allPartners1.add(p1);
        allPartners1.add(p2);
        allPartners1.add(p3);
        allPartners1.add(p4);

        // copy the first object in the second
        List<Partner> allPartners2 = allPartners1;

        // copy the first object in the third using a deepClone
        List<Partner> allPartners3 = (List<Partner>) DroolsUtils.deepClone(allPartners1);

        assertTrue(allPartners1.size() == allPartners2.size());
        assertTrue(allPartners1.size() == allPartners2.size());

        // modify the first object
        allPartners1.remove(p3);

        assertTrue(allPartners1.size() == allPartners2.size());
        assertFalse(allPartners1.size() == allPartners3.size());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDeepClone_Exception() throws Exception
    {

        List<Partner> allPartners3 = (List<Partner>) DroolsUtils.deepClone(null);
        System.out.println(allPartners3);
    }

    @Test
    public void testCheckIfContainsTheReasonOfReject_contained() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");
        boolean existExpectedReason = false;
        ReasonOfReject expectedReason = ReasonOfReject.minDistanceViolation;
        acq.addReasonOfReject(2, expectedReason, "minimum distance violation", 1, 1, null);
        existExpectedReason = this.du.checkIfContainsTheReasonOfReject(acq, expectedReason);
        assertEquals(true, existExpectedReason);
    }

    @Test
    public void testcreateParametricAcquisitionException() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12dddd:12:00", "left", "SAT_1");
        boolean existExpectedReason = false;
        ReasonOfReject expectedReason = ReasonOfReject.minDistanceViolation;
        acq.addReasonOfReject(2, expectedReason, "minimum distance violation", 1, 1, null);
        existExpectedReason = this.du.checkIfContainsTheReasonOfReject(acq, expectedReason);
        assertEquals(true, existExpectedReason);
    }
    
    @Test
    public void testCheckIfContainsTheReasonOfReject_not_contained() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");
        boolean existExpectedReason = false;
        ReasonOfReject expectedReason = ReasonOfReject.minDistanceViolation;
        acq.addReasonOfReject(2, expectedReason, "minimum distance violtion", 1, 1, null);
        existExpectedReason = this.du.checkIfContainsTheReasonOfReject(acq, ReasonOfReject.cannotPerformBite);
        assertEquals(false, existExpectedReason);
    }

    @Test
    public void testGetAllElementsInvolvedWithManInInterval_CMGA() throws Exception
    {
        /*
         * acq1 left acq2 right acq3 left acq4 left acq5 right acq6 right acq7
         * left
         */
        ManeuverUtils manUtils = new ManeuverUtils();

        Maneuver rightToLeft1 = this.du.createManeuver("RL1", "x", "acq1", "17/01/2018 12:00:03", "17/01/2018 12:06:03", "sat_1", Actuator.ReactionWheels);
        rightToLeft1.setRightToLeftFlag(true);

        Maneuver conterMan1 = this.du.createManeuver("conterman1", "acq1", "x", "17/01/2018 12:08:03", "17/01/2018 12:14:03", "sat_1", Actuator.ReactionWheels);
        conterMan1.setRightToLeftFlag(false);

        Maneuver rightToLeft2 = this.du.createManeuver("RL2", "acq2", "acq3", "17/01/2018 13:08:03", "17/01/2018 13:14:03", "sat_1", Actuator.ReactionWheels);
        rightToLeft2.setRightToLeftFlag(true);

        Maneuver leftToRight1 = this.du.createManeuver("conterman1", "acq4", "acq5", "17/01/2018 13:50:03", "17/01/2018 13:54:03", "sat_1", Actuator.CMGA);
        leftToRight1.setRightToLeftFlag(false);

        Maneuver rightToLeft3 = this.du.createManeuver("RL3", "acq6", "acq7", "17/01/2018 14:08:03", "17/01/2018 14:12:03", "sat_1", Actuator.CMGA);
        rightToLeft3.setRightToLeftFlag(true);

        Maneuver conterMan2 = this.du.createManeuver("conterman1", "acq7", "x", "17/01/2018 14:13:03", "17/01/2018 14:19:03", "sat_1", Actuator.ReactionWheels);
        conterMan2.setRightToLeftFlag(false);

        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();
        allManRelatedToSat.put(rightToLeft1.getStartTime().getTime(), rightToLeft1);
        allManRelatedToSat.put(conterMan1.getStartTime().getTime(), conterMan1);
        allManRelatedToSat.put(rightToLeft2.getStartTime().getTime(), rightToLeft2);
        allManRelatedToSat.put(leftToRight1.getStartTime().getTime(), rightToLeft1);
        allManRelatedToSat.put(rightToLeft3.getStartTime().getTime(), leftToRight1);
        allManRelatedToSat.put(conterMan2.getStartTime().getTime(), conterMan2);

        Date from = DroolsUtils.createDate("17/01/2018 10:13:03");
        Date to = DroolsUtils.createDate("17/01/2018 15:13:03");
        List<Maneuver> allManInInterval = manUtils.allManInInterval(from.getTime(), to.getTime(), allManRelatedToSat);
        List<String> acqInvolved = this.du.getAllElementsInvolvedWithManInInterval(allManInInterval, Actuator.CMGA);
        assertTrue(acqInvolved.contains("acq4"));
        assertTrue(acqInvolved.size() == 1);
    }

    @Test
    public void testGetAllElementsInvolvedWithManInInterval_RW() throws Exception
    {
        /*
         * acq1 left acq2 right acq3 left acq4 left acq5 right acq6 right acq7
         * left
         */
        ManeuverUtils manUtils = new ManeuverUtils();

        Maneuver rightToLeft1 = this.du.createManeuver("RL1", "x", "acq1", "17/01/2018 12:00:03", "17/01/2018 12:06:03", "sat_1", Actuator.ReactionWheels);
        rightToLeft1.setRightToLeftFlag(true);

        Maneuver conterMan1 = this.du.createManeuver("conterman1", "acq1", "x", "17/01/2018 12:08:03", "17/01/2018 12:14:03", "sat_1", Actuator.ReactionWheels);
        conterMan1.setRightToLeftFlag(false);

        Maneuver rightToLeft2 = this.du.createManeuver("RL2", "acq2", "acq3", "17/01/2018 13:08:03", "17/01/2018 13:14:03", "sat_1", Actuator.ReactionWheels);
        rightToLeft2.setRightToLeftFlag(true);

        Maneuver leftToRight1 = this.du.createManeuver("conterman1", "acq4", "acq5", "17/01/2018 13:50:03", "17/01/2018 13:54:03", "sat_1", Actuator.CMGA);
        leftToRight1.setRightToLeftFlag(false);

        Maneuver rightToLeft3 = this.du.createManeuver("RL3", "acq6", "acq7", "17/01/2018 14:08:03", "17/01/2018 14:12:03", "sat_1", Actuator.CMGA);
        rightToLeft3.setRightToLeftFlag(true);

        Maneuver conterMan2 = this.du.createManeuver("conterman1", "acq7", "x", "17/01/2018 14:13:03", "17/01/2018 14:19:03", "sat_1", Actuator.ReactionWheels);
        conterMan2.setRightToLeftFlag(false);

        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();
        allManRelatedToSat.put(rightToLeft1.getStartTime().getTime(), rightToLeft1);
        allManRelatedToSat.put(conterMan1.getStartTime().getTime(), conterMan1);
        allManRelatedToSat.put(rightToLeft2.getStartTime().getTime(), rightToLeft2);
        allManRelatedToSat.put(leftToRight1.getStartTime().getTime(), rightToLeft1);
        allManRelatedToSat.put(rightToLeft3.getStartTime().getTime(), leftToRight1);
        allManRelatedToSat.put(conterMan2.getStartTime().getTime(), conterMan2);

        Date from = DroolsUtils.createDate("17/01/2018 10:13:03");
        Date to = DroolsUtils.createDate("17/01/2018 15:13:03");
        List<Maneuver> allManInInterval = manUtils.allManInInterval(from.getTime(), to.getTime(), allManRelatedToSat);
        List<String> acqInvolved = this.du.getAllElementsInvolvedWithManInInterval(allManInInterval, Actuator.ReactionWheels);
        assertTrue(acqInvolved.contains("acq1"));
        assertTrue(acqInvolved.contains("acq3"));
        assertTrue(acqInvolved.contains("acq7"));
        assertTrue(acqInvolved.size() == 3);
    }

    @Test
    public void testGetAllElementsInvolvedWithManInInterval_Total() throws Exception
    {
        /*
         * acq1 left acq2 right acq3 left acq4 left acq5 right acq6 right acq7
         * left
         */
        ManeuverUtils manUtils = new ManeuverUtils();

        Maneuver rightToLeft1 = this.du.createManeuver("RL1", "x", "acq1", "17/01/2018 12:00:03", "17/01/2018 12:06:03", "sat_1", Actuator.ReactionWheels);
        rightToLeft1.setRightToLeftFlag(true);

        Maneuver conterMan1 = this.du.createManeuver("conterman1", "acq1", "x", "17/01/2018 12:08:03", "17/01/2018 12:14:03", "sat_1", Actuator.ReactionWheels);
        conterMan1.setRightToLeftFlag(false);

        Maneuver rightToLeft2 = this.du.createManeuver("RL2", "acq2", "acq3", "17/01/2018 13:08:03", "17/01/2018 13:14:03", "sat_1", Actuator.ReactionWheels);
        rightToLeft2.setRightToLeftFlag(true);

        Maneuver leftToRight1 = this.du.createManeuver("conterman1", "acq4", "acq5", "17/01/2018 13:50:03", "17/01/2018 13:54:03", "sat_1", Actuator.CMGA);
        leftToRight1.setRightToLeftFlag(false);

        Maneuver rightToLeft3 = this.du.createManeuver("RL3", "acq6", "acq7", "17/01/2018 14:08:03", "17/01/2018 14:12:03", "sat_1", Actuator.CMGA);
        rightToLeft3.setRightToLeftFlag(true);

        Maneuver conterMan2 = this.du.createManeuver("conterman1", "acq7", "x", "17/01/2018 14:13:03", "17/01/2018 14:19:03", "sat_1", Actuator.ReactionWheels);
        conterMan2.setRightToLeftFlag(false);

        TreeMap<Long, Maneuver> allManRelatedToSat = new TreeMap<>();
        allManRelatedToSat.put(rightToLeft1.getStartTime().getTime(), rightToLeft1);
        allManRelatedToSat.put(conterMan1.getStartTime().getTime(), conterMan1);
        allManRelatedToSat.put(rightToLeft2.getStartTime().getTime(), rightToLeft2);
        allManRelatedToSat.put(leftToRight1.getStartTime().getTime(), rightToLeft1);
        allManRelatedToSat.put(rightToLeft3.getStartTime().getTime(), leftToRight1);
        allManRelatedToSat.put(conterMan2.getStartTime().getTime(), conterMan2);

        Date from = DroolsUtils.createDate("17/01/2018 10:13:03");
        Date to = DroolsUtils.createDate("17/01/2018 15:13:03");
        List<Maneuver> allManInInterval = manUtils.allManInInterval(from.getTime(), to.getTime(), allManRelatedToSat);
        List<String> acqInvolved = this.du.getAllElementsInvolvedWithManInInterval(allManInInterval, Actuator.total);
        assertTrue(acqInvolved.contains("acq1"));
        assertTrue(acqInvolved.contains("acq3"));
        assertTrue(acqInvolved.contains("acq4"));
        assertTrue(acqInvolved.contains("acq7"));
        assertTrue(acqInvolved.size() == 4);
    }

    @Test
    public void testAddNumberOfDto() throws Exception
    {
        long numbDto = 5;
        DroolsUtils.setNumberOfDto(numbDto);
        DroolsUtils.addNumberOfDto();
        long numbDtoAfterIncrement = DroolsUtils.getNumberOfDto();
        assertEquals(numbDto + 1, numbDtoAfterIncrement);
    }

    @Test
    public void testSplitTasksByCategory() throws Exception
    {
        Acquisition acq = new Acquisition();
        Storage sto = new Storage();
        CMGAxis cmgAxis = new CMGAxis();
        Silent silent = new Silent();
        Maneuver man = new Maneuver();
        Download dwl = new Download();
        PassThrough pt = new PassThrough();
        RampCMGA ramp = new RampCMGA();
        Bite bite = new Bite();
        StoreAUX storeAux = new StoreAUX();
        EquivalentDTO equivDto = new EquivalentDTO();

        List<Task> allPreviousTasks = new ArrayList<>(Arrays.asList(acq, sto, man, cmgAxis, silent, dwl, pt, ramp, bite, storeAux, equivDto));
        InitPlanTasks initPlanTask = this.du.splitTasksByCategory(allPreviousTasks);

        assertEquals(1, initPlanTask.getAllInitAcq().size());
        assertEquals(1, initPlanTask.getAllInitBite().size());
        assertEquals(1, initPlanTask.getAllInitCmgAxis().size());
        assertEquals(1, initPlanTask.getAllInitDwl().size());
        assertEquals(1, initPlanTask.getAllInitMan().size());
        assertEquals(1, initPlanTask.getAllInitPt().size());
        assertEquals(1, initPlanTask.getAllInitRamp().size());
        assertEquals(1, initPlanTask.getAllInitSil().size());
        assertEquals(1, initPlanTask.getAllInitSto().size());
        assertEquals(1, initPlanTask.getAllInitStoreAux().size());
        assertEquals(1, initPlanTask.getAllInitEquivDTO().size());


    }

    @Test
    public void testCreatePassThrough() throws Exception
    {
        BigDecimal deliberateDelay = new BigDecimal(0);
        int packetStoreSize = 30;
        String idTask = "idTask";
        String prReqId = "prReqId";
        String arReqId = "arReqId";
        String satId = "Sat_1";
        String start = "17/01/2018 10:13:03";
        String end = "17/01/2018 10:13:03";
        PassThrough pt = this.du.createPassThrough(satId, start, end);
        pt.setDeliberateDelay(deliberateDelay);
        pt.setIdTask(idTask);
        pt.setPacketStoreSizeH(packetStoreSize);
        pt.setPacketStoreSizeV(packetStoreSize);

        pt.setAcquisitionRequestId(arReqId);
        pt.setProgrammingRequestId(prReqId);
        System.out.println(pt);
    }

    @Test
    public void testCreatePassThroughException() throws Exception
    {
        String satId = "Sat_1";
        String start = "17/01/2018 10aaa:13:03";
        String end = "17/01/2018 10:13:03";
        PassThrough pt = this.du.createPassThrough(satId, start, end);
        System.out.println(pt);
    }

    @Test
    public void testCreateParametricAcquisitionException() throws Exception
    {
        String dtoId = "dtotest";
        String start = "17/01/2018 10aaa:13:03";
        String end = "17/01/2018 10:13:03";
        String lookSide = "right";
        String satelliteId = "satelliteId";

        this.du.createParametricAcquisition(dtoId, start, end, lookSide, satelliteId);

    }

    @Test
    public void testContainsValidTasks() throws Exception
    {
        Map<String, Task> taskMap = new HashMap<>();

        String startTime = "10/10/2017 11:00:00";
        String endTime = "10/10/2017 11:03:00";
        String satelliteID = "SSAR1";
        Maneuver man = this.du.createManeuver("manID", "x", "dto1", startTime, endTime, satelliteID, Actuator.CMGA);

        Download dwl = this.du.createDownload(satelliteID, startTime, endTime, DownlinkStrategy.DELETE, true);

        taskMap.put(man.getIdTask(), man);
        taskMap.put(dwl.getIdTask(), dwl);

        boolean validTasks = this.du.containsValidTasks(taskMap);
        assertTrue(validTasks);
    }

    @Test
    public void testAvoidCloneVis_notCopiedElements() throws Exception
    {

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 06:00:00", "17/01/2018 06:30:00");
        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "Kir", null, "17/01/2018 08:10:00", "17/01/2018 08:15:00");
        vis2.setExternal(true);
        Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "Kir", null, "17/01/2018 11:00:00", "17/01/2018 12:50:00");
        vis3.setExternal(true);
        Visibility vis4 = this.stub.createVisibility(4, "SAT_1", "Kir", "Partner_2", "17/01/2018 18:00:00", "17/01/2018 18:21:00");

        List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
        List<Visibility> notCopiedVis = this.du.avoidCloneVis(allVisibilitiesSat1);
        assertEquals(4, notCopiedVis.size());
    }

    @Test
    public void testAvoidCloneVis_copiedElements() throws Exception
    {

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Kir", "Partner_3", "17/01/2018 06:00:00", "17/01/2018 06:30:00");
        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "Kir", null, "17/01/2018 08:10:00", "17/01/2018 08:15:00");
        vis2.setExternal(true);
        Visibility vis3 = this.stub.createVisibility(3, "SAT_1", "Kir", null, "17/01/2018 11:00:00", "17/01/2018 12:50:00");
        vis3.setExternal(true);
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "Kir", null, "17/01/2018 11:00:00", "17/01/2018 12:50:00");

        List<Visibility> allVisibilitiesSat1 = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
        List<Visibility> notCopiedVis = this.du.avoidCloneVis(allVisibilitiesSat1);
        assertEquals(3, notCopiedVis.size());
    }

    @Test
    public void testDetectIfAcqIsOutSideMh_Inside() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");

        MissionHorizon mh = new MissionHorizon();
        mh.setStart(DroolsUtils.createDate("17/01/2018 10:08:03"));
        mh.setStop(DroolsUtils.createDate("17/01/2018 16:08:03"));
        boolean insideMh = this.du.detectIfAcqIsOutSideMh(acq, mh);
        assertTrue(insideMh);
    }

    @Test
    public void testDetectIfAcqIsOutSideMh_before() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");

        MissionHorizon mh = new MissionHorizon();
        mh.setStart(DroolsUtils.createDate("17/01/2018 13:08:03"));
        mh.setStop(DroolsUtils.createDate("17/01/2018 15:08:03"));
        boolean insideMh = this.du.detectIfAcqIsOutSideMh(acq, mh);
        assertFalse(insideMh);
    }

    @Test
    public void testDetectIfAcqIsOutSideMh_after() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");

        MissionHorizon mh = new MissionHorizon();
        mh.setStart(DroolsUtils.createDate("17/01/2018 10:08:03"));
        mh.setStop(DroolsUtils.createDate("17/01/2018 12:00:03"));
        boolean insideMh = this.du.detectIfAcqIsOutSideMh(acq, mh);
        assertFalse(insideMh);
    }

    @Test
    public void testDetectIfAcqIsOutSideMh_startInside_endOutside() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");

        MissionHorizon mh = new MissionHorizon();
        mh.setStart(DroolsUtils.createDate("17/01/2018 12:06:03"));
        mh.setStop(DroolsUtils.createDate("17/01/2018 12:10:03"));
        boolean insideMh = this.du.detectIfAcqIsOutSideMh(acq, mh);
        assertTrue(insideMh);
    }

    @Test
    public void testDetectIfAcqIsOutSideMh_StartOutside_endInside() throws Exception
    {
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:00:03", "17/01/2018 12:12:00", "left", "SAT_1");

        MissionHorizon mh = new MissionHorizon();
        mh.setStart(DroolsUtils.createDate("17/01/2018 12:08:03"));
        mh.setStop(DroolsUtils.createDate("17/01/2018 15:08:03"));
        boolean insideMh = this.du.detectIfAcqIsOutSideMh(acq, mh);
        assertFalse(insideMh);
    }

}
