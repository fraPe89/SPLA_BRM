
package com.nais.spla.brm.library.main.ontology.tasks;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BiteTest
{

    @Test
    public void testGetModuleSelectionFlag() throws Exception
    {
        int moduleSelectionFlag = 1;
        String moduleId = "moduleId";
        String fillerWord = "fillerWord";
        String packetStoreId = "psId";

        Bite biteForTest = new Bite();
        biteForTest.setModuleSelectionFlag(moduleSelectionFlag);
        assertEquals(moduleSelectionFlag, biteForTest.getModuleSelectionFlag());

        biteForTest.setModuleId(moduleId);
        assertEquals(moduleId, biteForTest.getModuleId());

        biteForTest.setFillerWord(fillerWord);
        assertEquals(fillerWord, biteForTest.getFillerWord());

        biteForTest.setPacketStoreId(packetStoreId);
        assertEquals(packetStoreId, biteForTest.getPacketStoreId());

        Bite biteForTest2 = new Bite(moduleSelectionFlag, moduleId, fillerWord, packetStoreId);
        assertEquals(biteForTest2.toString(), biteForTest.toString());
    }

}
