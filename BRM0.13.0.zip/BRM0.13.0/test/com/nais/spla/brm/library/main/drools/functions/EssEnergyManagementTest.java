
package com.nais.spla.brm.library.main.drools.functions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;
import org.slf4j.LoggerFactory;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TaskMarkType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

public class EssEnergyManagementTest
{

    private String sessionId = null;
    private DroolsUtils du = null;
    private long PDHTMaxMemory = 0;
    private EssEnergyManagement essMng = null;
    private int currentKieSession = 0;
    private DroolsParameters droolsParams = null;
    private MissionHorizon mh = null;
    private DroolsOperations droolsInstance = null;
    private double maxBicForTest = 0;

    @Before
    public void setUp() throws Exception
    {
        this.du = new DroolsUtils();
        this.sessionId = "EssEnergyManagementTest";
        this.essMng = new EssEnergyManagement();
        this.PDHTMaxMemory = 500000L;
        StubResources stub = new StubResources();
        this.mh = stub.createMH("10/10/2017 06:21:00", "10/10/2017 18:21:00");
        this.droolsParams = new DroolsParameters();
        this.currentKieSession = 1;
        this.droolsParams.setCurrentMH(this.mh);
        this.droolsParams.setMinutesForOrbit(97);
        this.maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    @Test
    public void testUpdateMapAfterRemove() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : testUpdateMapAfterRemove \n\n");
        String satId = "SAT_1";
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:20:00", "10/10/2017 08:20:10", "left", satId);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:54:00", "10/10/2017 07:54:10", "right", satId);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:42:00", "10/10/2017 06:42:10", "left", satId);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("REJECTED _" + this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resFunc.getEssFunctionAssociatedToSat(satId);
        assertTrue(allAcq.size() == 3);
        System.out.println("acq treemap before update map : " + allAcq);
        DroolsQueries dq = new DroolsQueries();
        Acquisition acqForTest = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto2.getDtoId());
        this.essMng.updateMapAfterRemove(acqForTest, allAcq);

        allAcq = resFunc.getEssFunctionAssociatedToSat(satId);
        System.out.println("acq treemap after update map : " + allAcq);
        assertTrue(allAcq.size() == 2);
        assertTrue(allAcq.containsKey(dto1.getStartTime().getTime()));
        assertTrue(allAcq.containsKey(dto3.getStartTime().getTime()));

    }

    @Test
    public void testGetThreshold_Eclipse() throws Exception
    {
        System.out.println("Running test :testGetThreshold_Eclipse ");
        double thresholdForTest = 200;
        double receivedThreshold = 0;
        double percentEnergyLossForEclipse = 20;
        double computedThreshold = (thresholdForTest / 100) * (100 - percentEnergyLossForEclipse);
        boolean lastOrbitSmoothing = false;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setInEclipse(true);

        receivedThreshold = this.essMng.getThreshold(acqForTest, thresholdForTest, percentEnergyLossForEclipse, lastOrbitSmoothing, this.droolsParams);
        System.out.println("threshold received from method " + receivedThreshold);
        assertEquals(computedThreshold, receivedThreshold, 0);
    }

    @Test
    public void testGetThreshold_No_Eclipse() throws Exception
    {
        System.out.println("Running test :testGetThreshold_No_Eclipse ");
        double thresholdForTest = 200;
        double receivedThreshold = 0;
        double percentEnergyLossForEclipse = 20;
        boolean lastOrbitSmoothing = false;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        acqForTest.setInEclipse(false);
        acqForTest.setPrType(PRType.UNRANKED_ROUTINE);

        receivedThreshold = this.essMng.getThreshold(acqForTest, thresholdForTest, percentEnergyLossForEclipse, lastOrbitSmoothing, this.droolsParams);
        System.out.println("threshold received from method " + receivedThreshold);
        assertEquals(thresholdForTest, receivedThreshold, 0);
    }

    @Test
    public void testGetThreshold_ROUTINE5_Last_orbit_No_Eclipse() throws Exception
    {
        System.out.println("Running test :testGetThreshold_ROUTINE5_Last_orbit_No_Eclipse ");
        double thresholdForTest = 200;
        double receivedThreshold = 0;
        double percentEnergyLossForEclipse = 20;
        long totalSecOfAnOrbit = this.droolsParams.getMinutesForOrbit() * 60;
        boolean lastOrbitSmoothing = false;
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setPeriodBeforeEndOfMhForSmoothingUnranked(50);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 18:18:00", "10/10/2017 18:19:00", "left", "SAT_1");
        acqForTest.setInEclipse(false);
        acqForTest.setPrType(PRType.UNRANKED_ROUTINE);

        long diff = (this.droolsParams.getCurrentMH().getStop().getTime() - acqForTest.getEndTime().getTime()) / 1000;
        double percentToReduce = 100 - ((diff * 100) / totalSecOfAnOrbit);
        thresholdForTest = (thresholdForTest / 100) * (100 - percentToReduce);
        receivedThreshold = this.essMng.getThreshold(acqForTest, thresholdForTest, percentEnergyLossForEclipse, lastOrbitSmoothing, this.droolsParams);
        System.out.println("threshold received from method " + receivedThreshold);
        // assertEquals(thresholdForTest, receivedThreshold, 0);
    }

    @Test
    public void testGetThreshold_ROUTINE5_not_Last_orbit() throws Exception
    {
        System.out.println("Running test :testGetThreshold_ROUTINE5_Last_orbit_Eclipse ");
        double thresholdForTest = 200;
        double receivedThreshold = 0;
        double percentEnergyLossForEclipse = 20;
        boolean lastOrbitSmoothing = false;

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 14:00:00", "10/10/2017 14:01:00", "left", "SAT_1");
        acqForTest.setInEclipse(false);
        acqForTest.setPrType(PRType.UNRANKED_ROUTINE);
        receivedThreshold = this.essMng.getThreshold(acqForTest, thresholdForTest, percentEnergyLossForEclipse, lastOrbitSmoothing, this.droolsParams);
        System.out.println("threshold received from method " + receivedThreshold);
        assertEquals(thresholdForTest, receivedThreshold, 0);
    }

    @Test
    public void testGetThreshold_ROUTINE5_Last_orbit_Eclipse() throws Exception
    {
        System.out.println("Running test :testGetThreshold_ROUTINE5_Last_orbit_Eclipse ");
        boolean lastOrbitSmoothing = false;
        double thresholdForTest = 100;
        double receivedThreshold = 0;
        double percentEnergyLossForEclipse = 20;
        double expectedThreshold = 32;
        DroolsParameters.setLogger(LoggerFactory.getLogger(DroolsOperations.class));
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setPeriodBeforeEndOfMhForSmoothingUnranked(97);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 18:00:00", "10/10/2017 18:01:00", "left", "SAT_1");
        acqForTest.setInEclipse(true);
        acqForTest.setPrType(PRType.UNRANKED_ROUTINE);
        receivedThreshold = this.essMng.getThreshold(acqForTest, thresholdForTest, percentEnergyLossForEclipse, lastOrbitSmoothing, this.droolsParams);
        System.out.println("threshold received from method " + receivedThreshold);
        // assertEquals(expectedThreshold, receivedThreshold, 0);
    }

    @Test
    public void testComputeEss() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : testComputeEss_dis2_os_less_than_threshold ");

        System.out.println("Running test : testComputeEss ");
        Map<TypeOfAcquisition, Double> powersSensorMode = new HashMap<>();
        powersSensorMode.put(TypeOfAcquisition.STRIPMAP, 15466.78);
        powersSensorMode.put(TypeOfAcquisition.SPOTLIGHT_2A, 20522.22);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:05:00", "left", "SAT_1");
        acqForTest.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);

        System.out.println("creating acq : " + acqForTest);
        System.out.println("ess formula : ( energy *  duration ) / power ReferenceType ");
        long duration = (acqForTest.getEndTime().getTime() - acqForTest.getStartTime().getTime()) / 1000;
        System.out.println(" duration (5 min = 300s): " + duration);
        double expectedEss = 398.06;
        double computedEss = this.essMng.computeEss(acqForTest, this.droolsParams, powersSensorMode);
        System.out.println("computed ess : " + computedEss);
        assertEquals(expectedEss, computedEss, 0);
    }

    @Test
    public void testComputeEss_dis2_msos_less_than_refd2_di2s() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : testComputeEss_dis2_os_less_than_threshold ");

        System.out.println("Running test : testComputeEss ");
        Map<TypeOfAcquisition, Double> powersSensorMode = new HashMap<>();
        powersSensorMode.put(TypeOfAcquisition.STRIPMAP, 15466.78);
        powersSensorMode.put(TypeOfAcquisition.SPOTLIGHT_2_MSOS, 20522.22);
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:00:02", "left", "SAT_1");
        acqForTest.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);
        acqForTest.setPrMode(PRMode.DI2S);
        System.out.println("creating acq : " + acqForTest);
        System.out.println("ess formula : ( energy *  duration ) / power ReferenceType ");
        long duration = (acqForTest.getEndTime().getTime() - acqForTest.getStartTime().getTime()) / 1000;
        System.out.println(" duration (5 min = 300s): " + duration);
        double expectedEss = 2.41;
        double computedEss = this.essMng.computeEss(acqForTest, this.droolsParams, powersSensorMode);
        System.out.println("computed ess : " + computedEss);
        assertEquals(expectedEss, computedEss, 0);
    }

    @Test
    public void testComputeEss_dis2_msor_less_than_threshold() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : testComputeEss_dis2_os_less_than_threshold ");

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:00:10", "left", "SAT_1");
        acqForTest.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1_MSOR);
        acqForTest.setPrMode(PRMode.DI2S);

        System.out.println("creating acq : " + acqForTest);
        System.out.println("ess formula : ( energy *  duration ) / power ReferenceType ");
        long duration = (acqForTest.getEndTime().getTime() - acqForTest.getStartTime().getTime()) / 1000;
        System.out.println(" duration: " + duration + " vs threshold :" + this.droolsParams.getRefd1_DI2S());
        System.out.println(" duration is less than the threshold -> upper bound power  ");

        double expectedEss = new BigDecimal((18603.59 * duration) / 13548.15).setScale(2, BigDecimal.ROUND_UP).doubleValue();
        double computedEss = this.essMng.computeEss(acqForTest, this.droolsParams, this.droolsParams.getPowersSensorMode());
        System.out.println("computed ess : " + computedEss);
        assertEquals(expectedEss, computedEss, 0);
    }

    @Test
    public void testComputeEss_dis2_msor_more_than_threshold() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : testComputeEss_dis2_os_less_than_threshold ");

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:00:50", "left", "SAT_1");
        acqForTest.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1_MSOR);
        acqForTest.setPrMode(PRMode.DI2S);

        System.out.println("creating acq : " + acqForTest);
        System.out.println("ess formula : ( energy *  duration ) / power ReferenceType ");
        long duration = (acqForTest.getEndTime().getTime() - acqForTest.getStartTime().getTime()) / 1000;
        System.out.println(" duration: " + duration + " vs threshold :" + this.droolsParams.getRefd1_DI2S());
        System.out.println(" duration is more than the threshold -> upper bound power  ");

        double expectedEss = new BigDecimal((23635.73 * duration) / 13548.15).setScale(2, BigDecimal.ROUND_UP).doubleValue();
        double computedEss = this.essMng.computeEss(acqForTest, this.droolsParams, this.droolsParams.getPowersSensorMode());
        System.out.println("computed ess : " + computedEss);
        assertEquals(expectedEss, computedEss, 0);
    }

    @Test
    public void testComputeEss_dis2_msos_less_than_threshold() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : testComputeEss_dis2_msos_less_than_threshold ");

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:00:30", "left", "SAT_1");
        acqForTest.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);
        acqForTest.setPrMode(PRMode.DI2S);

        System.out.println("creating acq : " + acqForTest);
        System.out.println("ess formula : ( energy *  duration ) / power ReferenceType ");
        long duration = (acqForTest.getEndTime().getTime() - acqForTest.getStartTime().getTime()) / 1000;
        System.out.println(" duration: " + duration + " vs threshold :" + this.droolsParams.getRefd1_DI2S());
        System.out.println(" duration is more than the threshold -> upper bound power  ");

        double expectedEss = new BigDecimal((23635.73 * duration) / 13548.15).setScale(2, BigDecimal.ROUND_UP).doubleValue();
        double computedEss = this.essMng.computeEss(acqForTest, this.droolsParams, this.droolsParams.getPowersSensorMode());
        System.out.println("computed ess : " + computedEss);
        assertEquals(expectedEss, computedEss, 0);
    }

    @Test
    public void testComputeEss_dis2_msos_more_than_threshold() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : testComputeEss_dis2_msos_more_than_threshold ");

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:00:50", "left", "SAT_1");
        acqForTest.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2_MSOS);
        acqForTest.setPrMode(PRMode.DI2S);

        System.out.println("creating acq : " + acqForTest);
        System.out.println("ess formula : ( energy *  duration ) / power ReferenceType ");
        long duration = (acqForTest.getEndTime().getTime() - acqForTest.getStartTime().getTime()) / 1000;
        System.out.println(" duration: " + duration + " vs threshold :" + this.droolsParams.getRefd1_DI2S());
        System.out.println(" duration is more than the threshold -> upper bound power  ");

        double expectedEss = new BigDecimal((23635.73 * duration) / 13548.15).setScale(2, BigDecimal.ROUND_UP).doubleValue();
        double computedEss = this.essMng.computeEss(acqForTest, this.droolsParams, this.droolsParams.getPowersSensorMode());
        System.out.println("computed ess : " + computedEss);
        assertEquals(expectedEss, computedEss, 0);
    }

    @Test
    public void testGetPrevious_null()
    {
        System.out.println("Running test : testGetPrevious");
        TreeMap<Long, EnergyAssociatedToTask> allAcquisitions = new TreeMap<>();

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 13:00:00", "10/10/2017 13:05:00", "left", "SAT_1");
        acq1.setSensorMode(TypeOfAcquisition.PINGPONG);

        allAcquisitions.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));

        Acquisition prev = this.essMng.getPrevious(acq1, allAcquisitions);
        assertEquals(prev, null);
    }

    @Test
    public void testGetPrevious()
    {
        System.out.println("Running test : testGetPrevious");
        TreeMap<Long, EnergyAssociatedToTask> allAcquisitions = new TreeMap<>();

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 13:00:00", "10/10/2017 13:05:00", "left", "SAT_1");
        acq1.setSensorMode(TypeOfAcquisition.PINGPONG);

        Acquisition acq2 = this.du.createParametricAcquisition("acq2", "10/10/2017 16:00:00", "10/10/2017 16:05:00", "left", "SAT_1");
        acq2.setSensorMode(TypeOfAcquisition.PINGPONG);

        allAcquisitions.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));
        allAcquisitions.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, acq2.getEss()));

        Acquisition prev = this.essMng.getPrevious(acq2, allAcquisitions);
        assertEquals(prev, acq1);
    }

    // @Test
    // public void testGetAcquisitionsInOverlap_No_Overlap() throws Exception
    // {
    // System.out.println("Running test :
    // testGetAcquisitionsInOverlap_No_Overlap");
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcquisitions = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // double minDistancePingPongQuad = 20;
    // double minDistanceQuadPingPong = 8;
    //
    // Acquisition acq1 = this.du.createParametricAcquisition("acq1",
    // "10/10/2017 13:00:00", "10/10/2017 13:05:00", "left", "SAT_1");
    // acq1.setSensorMode(TypeOfAcquisition.PINGPONG);
    // Acquisition acq2 = this.du.createParametricAcquisition("acq2",
    // "10/10/2017 13:50:00", "10/10/2017 13:52:00", "left", "SAT_1");
    // acq2.setSensorMode(TypeOfAcquisition.PINGPONG);
    // Acquisition acqUnderTest =
    // this.du.createParametricAcquisition("acqUnderTest", "10/10/2017
    // 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acqUnderTest.setSensorMode(TypeOfAcquisition.QUADPOL);
    //
    // allAcquisitions.put(acq1.getStartTime().getTime(), new
    // EnergyAssociatedToTask(acq1, 100));
    // allAcquisitions.put(acq2.getStartTime().getTime(), new
    // EnergyAssociatedToTask(acq2, 100));
    // // allAcquisitions.put(acqUnderTest.getStartTime().getTime(), new
    // // EnergyAssociatedToTask(acqUnderTest, 100));
    //
    // List<String> overlappedElements = new ArrayList<String>();
    // Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap =
    // new HashMap<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>();
    // Map<TypeOfAcquisition, Double> subMapQuad = new
    // HashMap<TypeOfAcquisition, Double>();
    // Map<TypeOfAcquisition, Double> subMapPing = new
    // HashMap<TypeOfAcquisition, Double>();
    //
    // subMapQuad.put(TypeOfAcquisition.QUADPOL, minDistancePingPongQuad);
    // subMapPing.put(TypeOfAcquisition.PINGPONG, minDistanceQuadPingPong);
    // minDistanceMap.put(TypeOfAcquisition.PINGPONG, subMapQuad);
    // minDistanceMap.put(TypeOfAcquisition.QUADPOL, subMapPing);
    //
    // overlappedElements = this.essMng.checkAcqOverlap(droolsParams,
    // acqUnderTest, allAcquisitions, minDistanceMap);
    // assertTrue(overlappedElements.size() == 0);
    // }
    //
    // @Test
    // public void testGetAcquisitionsInOverlap_Overlap() throws Exception
    // {
    // System.out.println("Running test :
    // testGetAcquisitionsInOverlap_Overlap");
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcquisitions = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // double minDistancePingPongQuad = 20;
    // double minDistanceQuadPingPong = 8;
    //
    // Acquisition acq1 = this.du.createParametricAcquisition("acq1",
    // "10/10/2017 13:20:10", "10/10/2017 13:26:00", "left", "SAT_1");
    // acq1.setSensorMode(TypeOfAcquisition.PINGPONG);
    // Acquisition acq2 = this.du.createParametricAcquisition("acq2",
    // "10/10/2017 13:19:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acq2.setSensorMode(TypeOfAcquisition.PINGPONG);
    // Acquisition acqUnderTest =
    // this.du.createParametricAcquisition("acqUnderTest", "10/10/2017
    // 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acqUnderTest.setSensorMode(TypeOfAcquisition.QUADPOL);
    //
    // allAcquisitions.put(acq1.getStartTime().getTime(), new
    // EnergyAssociatedToTask(acq1, 100));
    // allAcquisitions.put(acq2.getStartTime().getTime(), new
    // EnergyAssociatedToTask(acq2, 100));
    //
    // Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap =
    // new HashMap<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>();
    // Map<TypeOfAcquisition, Double> subMapQuad = new
    // HashMap<TypeOfAcquisition, Double>();
    // Map<TypeOfAcquisition, Double> subMapPing = new
    // HashMap<TypeOfAcquisition, Double>();
    //
    // subMapQuad.put(TypeOfAcquisition.QUADPOL, minDistancePingPongQuad);
    // subMapPing.put(TypeOfAcquisition.PINGPONG, minDistanceQuadPingPong);
    // minDistanceMap.put(TypeOfAcquisition.PINGPONG, subMapQuad);
    // minDistanceMap.put(TypeOfAcquisition.QUADPOL, subMapPing);
    //
    // List<String> overlappedElements =
    // this.essMng.checkAcqOverlap(droolsParams, acqUnderTest, allAcquisitions,
    // minDistanceMap);
    // System.out.println("acquisition " + acqUnderTest.getIdTask() + " is in
    // overlap with " + overlappedElements);
    // System.out.println("eason of reject " +
    // acqUnderTest.getReasonOfReject());
    // assertFalse(overlappedElements.isEmpty());
    // assertTrue(acqUnderTest.getReasonOfReject().size() > 0);
    // }
    //
    // @Test
    // public void testGetAcquisitionsInOverlap_MinDistanceTooShort() throws
    // Exception
    // {
    // System.out.println("Running test :
    // testGetAcquisitionsInOverlap_MinDistanceTooShort");
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcquisitions = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // double minDistancePingPongQuad = 20;
    // double minDistanceQuadPingPong = 8;
    //
    // Acquisition acq1 = this.du.createParametricAcquisition("acq1",
    // "10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acq1.setSensorMode(TypeOfAcquisition.PINGPONG);
    // Acquisition acqUnderTest =
    // this.du.createParametricAcquisition("acqUnderTest", "10/10/2017
    // 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acqUnderTest.setSensorMode(TypeOfAcquisition.QUADPOL);
    //
    // allAcquisitions.put(acq1.getStartTime().getTime(), new
    // EnergyAssociatedToTask(acq1, 100));
    //
    // Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap =
    // new HashMap<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>();
    // Map<TypeOfAcquisition, Double> subMapQuad = new
    // HashMap<TypeOfAcquisition, Double>();
    // Map<TypeOfAcquisition, Double> subMapPing = new
    // HashMap<TypeOfAcquisition, Double>();
    //
    // subMapQuad.put(TypeOfAcquisition.QUADPOL, minDistancePingPongQuad);
    // subMapPing.put(TypeOfAcquisition.PINGPONG, minDistanceQuadPingPong);
    // minDistanceMap.put(TypeOfAcquisition.PINGPONG, subMapQuad);
    // minDistanceMap.put(TypeOfAcquisition.QUADPOL, subMapPing);
    //
    // List<String> overlappedElements =
    // this.essMng.checkAcqOverlap(droolsParams, acqUnderTest, allAcquisitions,
    // minDistanceMap);
    // assertFalse(overlappedElements.isEmpty());
    //
    // System.out.println("reason of reject : " +
    // acqUnderTest.getReasonOfReject());
    // assertTrue(acqUnderTest.getReasonOfReject().size() > 0);
    // }
    //
    // @Test
    // public void testGetAcquisitionsInOverlap_SameAcqInsertedTwoTimes() throws
    // Exception
    // {
    // System.out.println("Running test :
    // testGetAcquisitionsInOverlap_SameAcqInsertedTwoTimes");
    //
    // TreeMap<Long, EnergyAssociatedToTask> allAcquisitions = new TreeMap<Long,
    // EnergyAssociatedToTask>();
    // double minDistancePingPongQuad = 20;
    // double minDistanceQuadPingPong = 8;
    //
    // Acquisition acq1 = this.du.createParametricAcquisition("acq1",
    // "10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acq1.setSensorMode(TypeOfAcquisition.PINGPONG);
    // Acquisition acqUnderTest =
    // this.du.createParametricAcquisition("acqUnderTest", "10/10/2017
    // 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
    // acqUnderTest.setSensorMode(TypeOfAcquisition.QUADPOL);
    //
    // allAcquisitions.put(acq1.getStartTime().getTime(), new
    // EnergyAssociatedToTask(acq1, 100));
    //
    // Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap =
    // new HashMap<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>();
    // Map<TypeOfAcquisition, Double> subMapQuad = new
    // HashMap<TypeOfAcquisition, Double>();
    // Map<TypeOfAcquisition, Double> subMapPing = new
    // HashMap<TypeOfAcquisition, Double>();
    //
    // subMapQuad.put(TypeOfAcquisition.QUADPOL, minDistancePingPongQuad);
    // subMapPing.put(TypeOfAcquisition.PINGPONG, minDistanceQuadPingPong);
    // minDistanceMap.put(TypeOfAcquisition.PINGPONG, subMapQuad);
    // minDistanceMap.put(TypeOfAcquisition.QUADPOL, subMapPing);
    //
    // List<String> overlappedElements =
    // this.essMng.checkAcqOverlap(droolsParams, acq1, allAcquisitions,
    // minDistanceMap);
    // assertFalse(overlappedElements.isEmpty());
    // }

    @Test
    public void Test_Reached_Threshold_1_orbit() throws Exception
    {
        DroolsUtils du = new DroolsUtils();
        du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.setCurrentSession(this.sessionId);
        TreeMap<Long, EnergyAssociatedToTask> hashMapEss = new TreeMap<>();

        EssEnergyManagement essMng = new EssEnergyManagement();
        System.out.println("RUNNING TEST : Test_Reached_Threshold_1_orbit");
        Acquisition acq1 = du.createParametricAcquisition("acq1", "10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        acq1.setSensorMode(TypeOfAcquisition.PINGPONG);
        acq1.setEss(20);
        hashMapEss.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, acq1.getEss()));

        Acquisition acq2 = du.createParametricAcquisition("acq2a", "10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        acq2.setSensorMode(TypeOfAcquisition.PINGPONG);
        acq2.setEss(20);
        hashMapEss.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, acq2.getEss()));

        Acquisition acq3 = du.createParametricAcquisition("acq3", "10/10/2017 13:23:00", "10/10/2017 13:24:00", "left", "SAT_1");
        acq3.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        acq3.setEss(20);
        hashMapEss.put(acq3.getStartTime().getTime(), new EnergyAssociatedToTask(acq3, acq3.getEss()));

        Acquisition acq4 = du.createParametricAcquisition("acq4", "10/10/2017 16:21:00", "10/10/2017 16:22:00", "right", "SAT_1");
        acq4.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        acq4.setEss(20);
        hashMapEss.put(acq4.getStartTime().getTime(), new EnergyAssociatedToTask(acq4, acq4.getEss()));

        Acquisition acq5 = du.createParametricAcquisition("acq5", "10/10/2017 15:18:00", "10/10/2017 15:18:30", "right", "SAT_1");
        acq5.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        acq5.setEss(20);
        hashMapEss.put(acq5.getStartTime().getTime(), new EnergyAssociatedToTask(acq5, acq5.getEss()));

        Acquisition acq6 = du.createParametricAcquisition("acq6", "10/10/2017 13:02:00", "10/10/2017 13:03:00", "left", "SAT_1");
        acq6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        acq6.setEss(20);
        hashMapEss.put(acq6.getStartTime().getTime(), new EnergyAssociatedToTask(acq6, acq6.getEss()));

        Acquisition acq7 = du.createParametricAcquisition("acq7", "10/10/2017 13:57:00", "10/10/2017 13:58:00", "right", "SAT_1");
        acq7.setSensorMode(TypeOfAcquisition.PINGPONG);
        acq7.setEss(20);
        hashMapEss.put(acq7.getStartTime().getTime(), new EnergyAssociatedToTask(acq7, acq7.getEss()));

        Acquisition underTest = du.createParametricAcquisition("acq8", "10/10/2017 13:13:00", "10/10/2017 13:16:00", "left", "SAT_1");
        underTest.setSensorMode(TypeOfAcquisition.STRIPMAP);
        underTest.setEss(20);
        hashMapEss.put(underTest.getStartTime().getTime(), new EnergyAssociatedToTask(underTest, underTest.getEss()));
        KieSession kieSession = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resFunc = (ResourceFunctions) kieSession.getGlobal("resourceFunctions");
        resFunc.setEssFunctionSat1(hashMapEss);

        double checkOnOrbit = 1;
        double maxThreshold = 50;
        boolean reachedThreshold = essMng.checkMeasurementFunction(checkOnOrbit, underTest, resFunc, maxThreshold, this.droolsParams, this.droolsParams.getSatWithId(underTest.getSatelliteId()).getSatelliteProperties());
        assertTrue(reachedThreshold);
    }

    @Test
    public void Test_Reached_Threshold_Daily_orbit_eclipse() throws Exception
    {
        DroolsUtils du = new DroolsUtils();
        du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        String satId = "SAT_1";

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resFunc.getEssFunctionAssociatedToSat(satId);

        double orbit = 14;
        double threshold = 800;

        System.out.println("RUNNING TEST : Test_Reached_Threshold_Daily_orbit_eclipse");
        Acquisition acq1 = du.createParametricAcquisition("acq1", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", satId);
        Acquisition acq2 = du.createParametricAcquisition("acq2", "10/10/2017 17:00:00", "10/10/2017 17:15:00", "left", satId);
        Acquisition acq3 = du.createParametricAcquisition("acq3", "10/10/2017 21:00:00", "10/10/2017 21:15:00", "left", satId);
        Acquisition acq4 = du.createParametricAcquisition("acq4", "10/10/2017 17:00:00", "10/10/2017 17:15:00", "left", satId);
        Acquisition acqUnderTest = du.createParametricAcquisition("acq5", "11/10/2017 06:00:00", "11/10/2017 06:15:00", "left", satId);

        allAcq.put(acq1.getStartTime().getTime(), new EnergyAssociatedToTask(acq1, 200));
        allAcq.put(acq2.getStartTime().getTime(), new EnergyAssociatedToTask(acq2, 600));
        allAcq.put(acq3.getStartTime().getTime(), new EnergyAssociatedToTask(acq3, 500));
        allAcq.put(acq4.getStartTime().getTime(), new EnergyAssociatedToTask(acq4, 200));
        allAcq.put(acqUnderTest.getStartTime().getTime(), new EnergyAssociatedToTask(acqUnderTest, 300));

        boolean insertable = this.essMng.checkMeasurementFunction(orbit, acqUnderTest, resFunc, threshold, this.droolsParams, this.droolsParams.getSatWithId(satId).getSatelliteProperties());
        System.out.println("insertable : " + insertable);
    }

    @Test
    public void testInsertRejectedElements_not_contained() throws Exception
    {
        String idTask = "DTO1";

        List<String> overlappedElements = new ArrayList<>();
        assertEquals(0, overlappedElements.size());

        this.essMng.insertRejectedElements(overlappedElements, idTask);
        assertEquals(1, overlappedElements.size());
    }

    @Test
    public void testInsertRejectedElements_contained() throws Exception
    {
        String idTask = "DTO1";

        List<String> overlappedElements = new ArrayList<>();
        overlappedElements.add("DTO2");
        overlappedElements.add(idTask);
        assertEquals(2, overlappedElements.size());

        this.essMng.insertRejectedElements(overlappedElements, idTask);
        assertTrue(overlappedElements.size() == 2);
    }

    @Test
    public void testSetCorrectMarkType_VU() throws Exception
    {
        boolean isLmpOrVuSession = true;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        TaskMarkType markToAssign = TaskMarkType.CONFIRMED;
        acqForTest.setTaskMark(markToAssign);
        List<Task> deletedTasks = new ArrayList<>();
        assertEquals(0, deletedTasks.size());

        boolean deletedByCsps = false;
        this.essMng.setCorrectMarkType(DroolsParameters.getLogger(), acqForTest, isLmpOrVuSession, deletedByCsps, deletedTasks);
        System.out.println("get updated task mark : " + acqForTest.getTaskMark());
        assertEquals(TaskMarkType.CONFIRMED, acqForTest.getTaskMark());
        assertEquals(0, deletedTasks.size());

        deletedByCsps = true;
        this.essMng.setCorrectMarkType(DroolsParameters.getLogger(), acqForTest, isLmpOrVuSession, deletedByCsps, deletedTasks);
        System.out.println("get updated task mark : " + acqForTest.getTaskMark());
        assertEquals(TaskMarkType.DELETED, acqForTest.getTaskMark());
        assertEquals(1, deletedTasks.size());
    }

    @Test
    public void testSetCorrectMarkType_not_VU() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        boolean isLmpOrVuSession = false;
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Acquisition acqForTest = this.du.createParametricAcquisition("acq_test", "10/10/2017 13:00:00", "10/10/2017 13:15:00", "left", "SAT_1");
        TaskMarkType markToAssign = TaskMarkType.CONFIRMED;
        boolean deletedByCsps = true;
        acqForTest.setTaskMark(markToAssign);

        List<Task> deletedTasks = new ArrayList<>();
        this.essMng.setCorrectMarkType(DroolsParameters.getLogger(), acqForTest, isLmpOrVuSession, deletedByCsps, deletedTasks);
        System.out.println("get updated task mark : " + acqForTest.getTaskMark());
        assertEquals(markToAssign, acqForTest.getTaskMark());
        assertEquals(0, deletedTasks.size());

        deletedByCsps = false;
        this.essMng.setCorrectMarkType(DroolsParameters.getLogger(), acqForTest, isLmpOrVuSession, deletedByCsps, deletedTasks);
        System.out.println("get updated task mark : " + acqForTest.getTaskMark());
        assertEquals(markToAssign, acqForTest.getTaskMark());
        assertEquals(0, deletedTasks.size());
    }

    @Test
    public void TestAddReasonOfReject_unranked() throws Exception
    {
        EssEnergyManagement essMng = new EssEnergyManagement();
        System.out.println("RUNNING TEST : TestAddReasonOfReject_unranked");

        Acquisition acq1 = this.du.createParametricAcquisition("acq1", "10/10/2017 13:20:00", "10/10/2017 13:21:00", "left", "SAT_1");
        acq1.setSensorMode(TypeOfAcquisition.PINGPONG);
        acq1.setPrType(PRType.UNRANKED_ROUTINE);
        acq1.setEss(20);

        int orbit = 1;
        int slidingWindow = 1;
        List<String> elementsInvolved = null;

        assertEquals(0, acq1.getReasonOfReject().size());
        essMng.addReasonOfReject(acq1, orbit, ReasonOfReject.reachedOrbitThreshold, true, slidingWindow, elementsInvolved);
        assertEquals(1, acq1.getReasonOfReject().size());
        System.out.println(acq1.getReasonOfReject());
    }

}
