/**
*
* MODULE FILE NAME:	DownloadScenario.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		26 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 26 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package deltaFat;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;

/**
 * @author francesca
 *
 */
public class DownloadScenario
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestManeuverScenario";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void DWlScenarioFede() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stubRes = new StubResources();

        Partner p1 = new Partner("1000", null, 100, 20);

        this.droolsParams.getAllPartners().add(p1);
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = stubRes.createVisibility(111012, "SAT_1", "1110", "1100", "10/10/2017 10:00:00", "10/10/2017 10:10:00");
        Visibility vis2 = stubRes.createVisibility(112011, "SAT_1", "1120", "1200", "10/10/2017 11:00:00", "10/10/2017 11:10:00");
        Visibility vis3 = stubRes.createVisibility(110013, "SAT_1", "1100", "1000", "10/10/2017 12:00:00", "10/10/2017 12:10:00");
        Visibility vis4 = stubRes.createVisibility(110014, "SAT_1", "1100", "1000", "10/10/2017 14:00:00", "10/10/2017 14:10:00");
        Visibility vis5 = stubRes.createVisibility(111011, "SAT_1", "1110", "1100", "10/10/2017 08:00:00", "10/10/2017 08:10:00");
        Visibility vis6 = stubRes.createVisibility(110011, "SAT_1", "1100", "1000", "10/10/2017 08:00:00", "10/10/2017 08:10:00");

        List<Visibility> allVisibilitiesSat1 = new ArrayList<>();
        allVisibilitiesSat1.add(vis1);
        allVisibilitiesSat1.add(vis2);
        allVisibilitiesSat1.add(vis3);
        allVisibilitiesSat1.add(vis4);
        allVisibilitiesSat1.add(vis5);
        allVisibilitiesSat1.add(vis6);

        this.droolsParams.setAllVisibilities(allVisibilitiesSat1);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        List<String> acquisitionStationIdList = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:05:00", "10/10/2017 11:05:10", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setDtoId("100_PR-ITA-151-21-1_AR-001_DTO-001");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1120"));
        populatePartner(dto1, acquisitionStationIdList, "1000", "100");
        dto1.setPreferredVis(new ArrayList<>(Arrays.asList("1120")));
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:04:40", "10/10/2017 11:04:50", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setDtoId("100_PR-ITA-151-21-1_AR-002_DTO-001");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1120"));
        populatePartner(dto1, acquisitionStationIdList, "1000", "100");
        dto1.setPreferredVis(new ArrayList<>(Arrays.asList("1120")));
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 11:09:45", "10/10/2017 11:09:55", "right", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setDtoId("100_PR-ITA-151-21-1_AR-003_DTO-001");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1120"));
        populatePartner(dto1, acquisitionStationIdList, "1000", "100");
        dto1.setPreferredVis(new ArrayList<>(Arrays.asList("1120")));
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 09:52:00", "10/10/2017 09:52:10", "right", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto4.setDtoId("100_PR-ITA-151-21-2_AR-001_DTO-001");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto4, acquisitionStationIdList, "1000", "100");
        dto4.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 09:42:00", "10/10/2017 09:42:10", "right", "SAT_1");
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto5.setDtoId("100_PR-ITA-151-21-2_AR-002_DTO-001_");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto5, acquisitionStationIdList, "1000", "100");
        dto5.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 09:32:00", "10/10/2017 09:32:10", "right", "SAT_1");
        dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto6.setDtoId("100_PR-ITA-151-21-2_AR-003_DTO-001_");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto6, acquisitionStationIdList, "1000", "100");
        dto6.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 09:32:00", "10/10/2017 09:32:10", "right", "SAT_1");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto7.setDtoId("100_PR-ITA-151-21-2_AR-004_DTO-001_");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto7, acquisitionStationIdList, "1000", "100");
        dto7.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 09:22:00", "10/10/2017 09:22:10", "right", "SAT_1");
        dto8.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto8.setDtoId("100_PR-ITA-151-21-2_AR-005_DTO-001_");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto8, acquisitionStationIdList, "1000", "100");
        dto8.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        /*
         *
         */
        DTO dto9 = this.du.createSingleDto("10/10/2017 09:02:00", "10/10/2017 09:02:10", "right", "SAT_1");
        dto9.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto9.setDtoId("100_PR-ITA-151-21-2_AR-006_DTO-001_");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto9, acquisitionStationIdList, "1000", "100");
        dto9.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 10:02:00", "10/10/2017 10:02:10", "right", "SAT_1");
        dto10.setDtoId("100_PR-ITA-151-21-2_AR-007_DTO-001");
        acquisitionStationIdList = new ArrayList<>(Arrays.asList("1100", "1101"));
        populatePartner(dto10, acquisitionStationIdList, "1000", "100");
        dto10.setPreferredVis(new ArrayList<>(Arrays.asList("1100", "1101")));
        dto10.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    public void populatePartner(DTO dto, List<String> acquisitionStationIdList, String ownerId, String ugsId)
    {
        List<UserInfo> userInfoList = dto.getUserInfo();
        UserInfo userInfo1 = new UserInfo(acquisitionStationIdList, false, ownerId, ugsId);
        userInfoList.add(userInfo1);
    }

}
