
package deltaFat;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

public class TestManeuverScenario
{

    private String sessionId = null;
    private TaskPlanned taskPlanned = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestManeuverScenario";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.taskPlanned = new TaskPlanned();
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void deltaFatTestMan_01_06_10_2_scenario_3() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();

        int maxNumRw = 4;
        int maxNumCmga = 3;
        int maxNumTotMan = 6;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test deltaFatTestMan_01_06_10_2");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:25:00", "10/10/2017 10:25:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:20:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:00:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:10:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + acqRejected);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        System.out.println("current session : " + this.currentKieSession);
        System.out.println("--------------------------------------------");
        System.out.println(this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1"));
        // droolsInstance.updatePdhtTillEnd(1,
        // droolsParams.getCurrentMH().getStart(), droolsParams);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void deltaFatTestMan_01_06_10_scenario_3() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();

        int maxNumRw = 1;
        int maxNumCmga = 1;
        int maxNumTotMan = 1;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test deltaFatTestMan_01_06_10_3");

        DTO dto0 = this.du.createSingleDto("10/10/2017 08:20:00", "10/10/2017 08:20:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:10:00", "10/10/2017 08:10:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:50:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 08:40:00", "10/10/2017 08:40:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:55:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        DTO dto11 = this.du.createSingleDto("10/10/2017 10:25:00", "10/10/2017 10:25:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);

        DTO dto12 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId, this.currentKieSession);

        DTO dto13 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + acqRejected);
    }

    @Test
    public void deltaFatTestMan_01_06_08_scenario_1() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test deltaFatTestMan_01_06_10_3");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:20:00", "10/10/2017 08:20:10", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:10:00", "10/10/2017 08:10:10", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
        dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 12:06:00", "10/10/2017 12:06:10", "right", "SAT_1");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 12:00:00", "10/10/2017 12:00:10", "right", "SAT_1");
        dto8.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 12:03:00", "10/10/2017 12:03:10", "left", "SAT_1");
        dto9.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:20:10", "left", "SAT_1");
        dto10.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        DTO dto11 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:00:10", "left", "SAT_1");
        dto11.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);

        DTO dto12 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:10:10", "right", "SAT_1");
        dto12.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId, this.currentKieSession);

        DTO dto13 = this.du.createSingleDto("10/10/2017 16:10:00", "10/10/2017 16:10:10", "left", "SAT_1");
        dto13.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId, this.currentKieSession);

        DTO dto14 = this.du.createSingleDto("10/10/2017 16:00:00", "10/10/2017 16:00:10", "left", "SAT_1");
        dto14.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto14, this.sessionId, this.currentKieSession);

        DTO dto15 = this.du.createSingleDto("10/10/2017 16:05:00", "10/10/2017 16:05:10", "right", "SAT_1");
        dto15.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto15, this.sessionId, this.currentKieSession);

        DTO dto16 = this.du.createSingleDto("10/10/2017 18:06:00", "10/10/2017 18:06:10", "left", "SAT_1");
        dto16.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto16, this.sessionId, this.currentKieSession);

        DTO dto17 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "left", "SAT_1");
        dto17.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto17, this.sessionId, this.currentKieSession);

        DTO dto18 = this.du.createSingleDto("10/10/2017 18:03:00", "10/10/2017 18:03:10", "right", "SAT_1");
        dto18.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto18, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getKey() + " : " + elements.getValue());
        }

        System.out.println(this.taskPlanned.receiveAllRamps(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1"));

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        System.out.println("res func : " + resFunc.getAllRampsSat1());

        Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + acqRejected);
    }

    /*
     * @Test public void deltaFatTestMan_01_06_10_4() throws Exception {
     *
     * this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance); this.droolsInstance =
     * this.du.setUpSession(this.sessionId, SessionType.premium,
     * this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
     *
     * this.droolsParams.getAllPAWS().clear();
     * this.droolsParams.getAllVisibilities().clear();
     * this.droolsParams.getSatelliteState().clear();
     *
     * Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<Double,
     * ResourceMaxValue>();
     *
     * int maxNumRw = 4; int maxNumCmga = 3; int maxNumTotMan = 6;
     *
     * checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000,
     * maxNumTotMan, maxNumRw, maxNumCmga, 20));
     * this.droolsParams.getSatWithId("1").getSatelliteProperties().
     * setAllChecksOnOrbits(checkOnSingleOrbit);
     *
     * this.droolsParams.getAllVisibilities().clear();
     * this.droolsParams.getAllPAWS().clear();
     *
     * this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
     * this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
     *
     * this.droolsParams.getSatWithId("1").getSatelliteProperties().
     * setStartWithRw(true);
     *
     * this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_");
     * System.out.println("\n\n I'm running test deltaFatTestMan_01_06_10_2");
     *
     * DTO dto1 = this.du.createSingleDto("10/10/2017 08:20:00",
     * "10/10/2017 08:20:10", "left", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:00",
     * "10/10/2017 08:00:10", "left", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto3 = this.du.createSingleDto("10/10/2017 08:10:00",
     * "10/10/2017 08:10:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto4 = this.du.createSingleDto("10/10/2017 08:50:00",
     * "10/10/2017 08:50:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto5 = this.du.createSingleDto("10/10/2017 08:30:00",
     * "10/10/2017 08:30:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto6 = this.du.createSingleDto("10/10/2017 08:40:00",
     * "10/10/2017 08:40:10", "left", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto7 = this.du.createSingleDto("10/10/2017 08:55:00",
     * "10/10/2017 08:55:10", "left", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto8 = this.du.createSingleDto("10/10/2017 08:20:00",
     * "10/10/2017 08:20:10", "left", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto9 = this.du.createSingleDto("10/10/2017 08:00:00",
     * "10/10/2017 08:00:10", "left", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto10 = this.du.createSingleDto("10/10/2017 08:10:00",
     * "10/10/2017 08:10:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto11 = this.du.createSingleDto("10/10/2017 08:45:00",
     * "10/10/2017 08:45:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto12 = this.du.createSingleDto("10/10/2017 08:30:00",
     * "10/10/2017 08:30:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto13 = this.du.createSingleDto("10/10/2017 08:40:00",
     * "10/10/2017 08:40:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId,
     * this.currentKieSession);
     *
     * DTO dto14 = this.du.createSingleDto("10/10/2017 08:50:00",
     * "10/10/2017 08:50:10", "right", "SAT_1");
     * this.droolsInstance.insertDto(this.droolsParams, dto14, this.sessionId,
     * this.currentKieSession);
     *
     * ResourceFunctions resFunc = (ResourceFunctions)
     * this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession,
     * "resourceFunctions"); resFunc.getAllManeuversSat1();
     *
     * for (Map.Entry<Long, Maneuver> elementInMap :
     * resFunc.getAllManeuversSat1().entrySet()) {
     * System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue()); }
     *
     * List<Maneuver> allManInDrools =
     * this.taskPlanned.receiveAllManeuvers(sessionId, this.currentKieSession,
     * this.droolsParams, "SAT_1"); for (int i = 0; i < allManInDrools.size();
     * i++) { System.out.println("RETURNED MAN DROOLS:" +
     * allManInDrools.get(i)); }
     *
     * List<RampCMGA> allramps = this.taskPlanned.receiveAllRamps(sessionId,
     * this.currentKieSession, this.droolsParams, "SAT_1");
     * System.out.println("all ramps : " + allramps);
     *
     * Map<String, Task> allTasks =
     * this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
     * this.sessionId, this.currentKieSession);
     * System.out.println("all tasks : ");
     *
     * for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet()) {
     * System.out.println(elementsInmap.getValue()); }
     *
     * Map<String, Acquisition> acqRejected =
     * this.droolsInstance.receiveDtoRejected(this.sessionId,
     * this.currentKieSession); for (Map.Entry<String, Acquisition> elements :
     * acqRejected.entrySet()) { System.out.println("rejected : " +
     * elements.getValue()); } }
     */

}
