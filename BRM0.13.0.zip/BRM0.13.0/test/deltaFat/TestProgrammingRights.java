
package deltaFat;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

public class TestProgrammingRights
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestProgrammingRights";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void deltaFatTestMan_01_06_10_scenario_1() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();

        int maxNumRw = 4;
        int maxNumCmga = 3;
        int maxNumTotMan = 6;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(true);

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner P2000 = allPartners.get(0);
        Partner P2100 = allPartners.get(1);
        Partner P2200 = allPartners.get(2);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(P2000);
        this.droolsParams.getAllPartners().add(P2100);
        this.droolsParams.getAllPartners().add(P2200);

        P2000.setMaxBICAvailable(100);
        P2000.setMaxNEOBicAvailable(100);
        P2000.setMaxPercLoanBic(20);

        P2100.setMaxBICAvailable(50);
        P2100.setMaxNEOBicAvailable(50);
        P2100.setMaxPercLoanBic(20);
        P2100.getBorrowingBic().add(P2000.getPartnerId());
        P2100.getBorrowingBic().add(P2200.getPartnerId());

        P2200.setMaxBICAvailable(25);
        P2200.setMaxNEOBicAvailable(25);
        P2200.setMaxPercLoanBic(20);
        P2200.getBorrowingBic().add(P2000.getPartnerId());
        P2200.getBorrowingBic().add(P2100.getPartnerId());

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test deltaFatTestMan_01_06_10_2");

        List<UserInfo> userInfoListP2000 = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, P2000.getPartnerId(), "ugsId2");
        userInfoListP2000.add(userInfo1);

        List<UserInfo> userInfoListP2100 = new ArrayList<>();
        UserInfo userInfo2 = new UserInfo(null, false, P2100.getPartnerId(), "ugsId2");
        userInfoListP2100.add(userInfo2);

        List<UserInfo> userInfoListP2200 = new ArrayList<>();
        UserInfo userInfo3 = new UserInfo(null, false, P2200.getPartnerId(), "ugsId2");
        userInfoListP2200.add(userInfo3);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto1.setImageBIC(10);
        dto1.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        dto2.setImageBIC(10);
        dto2.setUserInfo(userInfoListP2000);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:00:00", "10/10/2017 16:00:10", "right", "SAT_1");
        dto3.setImageBIC(10);
        dto3.setUserInfo(userInfoListP2000);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:30:00", "10/10/2017 10:30:10", "right", "SAT_1");
        dto4.setImageBIC(10);
        dto4.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        dto5.setImageBIC(10);
        dto5.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 07:00:00", "10/10/2017 07:00:10", "right", "SAT_2");
        dto6.setImageBIC(10);
        dto6.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_2");
        dto7.setImageBIC(10);
        dto7.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:00:10", "right", "SAT_2");
        dto8.setImageBIC(10);
        dto8.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_2");
        dto9.setImageBIC(10);
        dto9.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_2");
        dto10.setImageBIC(10);
        dto10.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        DTO dto11 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_1");
        dto11.setImageBIC(10);
        dto11.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);

        DTO dto12 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_1");
        dto12.setImageBIC(10);
        dto12.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId, this.currentKieSession);

        DTO dto13 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:00:10", "right", "SAT_1");
        dto13.setImageBIC(10);
        dto13.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId, this.currentKieSession);

        DTO dto14 = this.du.createSingleDto("10/10/2017 11:30:00", "10/10/2017 11:30:10", "right", "SAT_1");
        dto14.setImageBIC(10);
        dto14.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto14, this.sessionId, this.currentKieSession);

        DTO dto15 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto15.setImageBIC(10);
        dto15.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto15, this.sessionId, this.currentKieSession);

        DTO dto16 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_2");
        dto16.setImageBIC(10);
        dto16.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto16, this.sessionId, this.currentKieSession);

        DTO dto17 = this.du.createSingleDto("10/10/2017 11:30:00", "10/10/2017 11:30:10", "right", "SAT_2");
        dto17.setImageBIC(10);
        dto17.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto17, this.sessionId, this.currentKieSession);

        DTO dto18 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_2");
        dto18.setImageBIC(10);
        dto18.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto18, this.sessionId, this.currentKieSession);

        DTO dto19 = this.du.createSingleDto("10/10/2017 10:30:00", "10/10/2017 10:30:10", "right", "SAT_2");
        dto19.setImageBIC(10);
        dto19.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto19, this.sessionId, this.currentKieSession);

        DTO dto20 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "right", "SAT_2");
        dto20.setImageBIC(10);
        dto20.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto20, this.sessionId, this.currentKieSession);

        DTO dto21 = this.du.createSingleDto("10/10/2017 07:30:00", "10/10/2017 07:30:10", "right", "SAT_1");
        dto21.setImageBIC(10);
        dto21.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto21, this.sessionId, this.currentKieSession);

        DTO dto22 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_1");
        dto22.setImageBIC(10);
        dto22.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto22, this.sessionId, this.currentKieSession);

        DTO dto23 = this.du.createSingleDto("10/10/2017 12:00:00", "10/10/2017 12:00:10", "right", "SAT_1");
        dto23.setImageBIC(10);
        dto23.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto23, this.sessionId, this.currentKieSession);

        DTO dto24 = this.du.createSingleDto("10/10/2017 10:30:00", "10/10/2017 10:30:10", "right", "SAT_1");
        dto24.setImageBIC(10);
        dto24.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto24, this.sessionId, this.currentKieSession);

        DTO dto25 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "right", "SAT_1");
        dto25.setImageBIC(10);
        dto24.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto25, this.sessionId, this.currentKieSession);

        DTO dto26 = this.du.createSingleDto("10/10/2017 18:30:00", "10/10/2017 18:30:10", "right", "SAT_2");
        dto26.setImageBIC(10);
        dto26.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto26, this.sessionId, this.currentKieSession);

        DTO dto27 = this.du.createSingleDto("10/10/2017 17:30:00", "10/10/2017 17:30:10", "right", "SAT_2");
        dto27.setImageBIC(10);
        dto27.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto27, this.sessionId, this.currentKieSession);

        DTO dto28 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:00:10", "right", "SAT_2");
        dto28.setImageBIC(10);
        dto27.setUserInfo(userInfoListP2100);
        this.droolsInstance.insertDto(this.droolsParams, dto28, this.sessionId, this.currentKieSession);

        DTO dto29 = this.du.createSingleDto("10/10/2017 16:30:00", "10/10/2017 16:30:10", "right", "SAT_2");
        dto29.setImageBIC(10);
        dto29.setUserInfo(userInfoListP2100);
        this.droolsInstance.insertDto(this.droolsParams, dto29, this.sessionId, this.currentKieSession);

        DTO dto30 = this.du.createSingleDto("10/10/2017 08:15:00", "10/10/2017 08:15:10", "right", "SAT_2");
        dto30.setImageBIC(10);
        dto30.setUserInfo(userInfoListP2100);
        this.droolsInstance.insertDto(this.droolsParams, dto30, this.sessionId, this.currentKieSession);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + acqRejected);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void deltaFatTestMan_01_06_10_scenario_2() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<Double, ResourceMaxValue> checkOnSingleOrbit = new HashMap<>();

        int maxNumRw = 4;
        int maxNumCmga = 3;
        int maxNumTotMan = 6;

        checkOnSingleOrbit.put(1.0, new ResourceMaxValue(97, 1000, 2000, maxNumTotMan, maxNumRw, maxNumCmga, 20));
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setAllChecksOnOrbits(checkOnSingleOrbit);
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("1").getSatelliteProperties().setStartWithRw(true);

        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner P1000 = allPartners.get(0);
        Partner P1100 = allPartners.get(1);
        Partner P1200 = allPartners.get(2);

        this.droolsParams.getAllPartners().clear();
        this.droolsParams.getAllPartners().add(P1000);
        this.droolsParams.getAllPartners().add(P1100);
        this.droolsParams.getAllPartners().add(P1200);

        P1000.setMaxBICAvailable(100);
        P1000.setMaxNEOBicAvailable(100);
        P1000.setMaxPercLoanBic(20);

        P1100.setMaxBICAvailable(50);
        P1100.setMaxNEOBicAvailable(50);
        P1100.setMaxPercLoanBic(20);
        P1100.getBorrowingBic().add(P1000.getPartnerId());
        P1100.getBorrowingBic().add(P1200.getPartnerId());

        P1200.setMaxBICAvailable(25);
        P1200.setMaxNEOBicAvailable(25);
        P1200.setMaxPercLoanBic(20);
        P1200.getBorrowingBic().add(P1000.getPartnerId());
        P1200.getBorrowingBic().add(P1100.getPartnerId());

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test deltaFatTestMan_01_06_10_2");

        List<UserInfo> userInfoListP2000 = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, P1000.getPartnerId(), "ugsId2");
        userInfoListP2000.add(userInfo1);

        List<UserInfo> userInfoListP2100 = new ArrayList<>();
        UserInfo userInfo2 = new UserInfo(null, false, P1100.getPartnerId(), "ugsId2");
        userInfoListP2100.add(userInfo2);

        List<UserInfo> userInfoListP2200 = new ArrayList<>();
        UserInfo userInfo3 = new UserInfo(null, false, P1200.getPartnerId(), "ugsId2");
        userInfoListP2200.add(userInfo3);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:10:00", "10/10/2017 08:10:10", "Left", "SAT_1");
        dto1.setImageBIC(10);
        dto1.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto2.setImageBIC(10);
        dto2.setUserInfo(userInfoListP2000);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:10:00", "10/10/2017 16:10:10", "right", "SAT_1");
        dto3.setImageBIC(10);
        dto3.setUserInfo(userInfoListP2000);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:40:00", "10/10/2017 10:40:10", "right", "SAT_1");
        dto4.setImageBIC(10);
        dto4.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto5.setImageBIC(10);
        dto5.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        /*
         *
         */

        DTO dto6 = this.du.createSingleDto("10/10/2017 07:00:00", "10/10/2017 07:00:10", "right", "SAT_2");
        dto6.setImageBIC(10);
        dto6.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_2");
        dto7.setImageBIC(10);
        dto7.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:00:10", "right", "SAT_2");
        dto8.setImageBIC(10);
        dto8.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_2");
        dto9.setImageBIC(10);
        dto9.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_2");
        dto10.setImageBIC(10);
        dto10.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        DTO dto11 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_1");
        dto11.setImageBIC(10);
        dto11.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);

        DTO dto12 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_1");
        dto12.setImageBIC(10);
        dto12.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId, this.currentKieSession);

        DTO dto13 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:00:10", "right", "SAT_1");
        dto13.setImageBIC(10);
        dto13.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId, this.currentKieSession);

        DTO dto14 = this.du.createSingleDto("10/10/2017 11:30:00", "10/10/2017 11:30:10", "right", "SAT_1");
        dto14.setImageBIC(10);
        dto14.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto14, this.sessionId, this.currentKieSession);

        DTO dto15 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto15.setImageBIC(10);
        dto15.setUserInfo(userInfoListP2200);

        this.droolsInstance.insertDto(this.droolsParams, dto15, this.sessionId, this.currentKieSession);

        DTO dto16 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_2");
        dto16.setImageBIC(10);
        dto16.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto16, this.sessionId, this.currentKieSession);

        DTO dto17 = this.du.createSingleDto("10/10/2017 11:30:00", "10/10/2017 11:30:10", "right", "SAT_2");
        dto17.setImageBIC(10);
        dto17.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto17, this.sessionId, this.currentKieSession);

        DTO dto18 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_2");
        dto18.setImageBIC(10);
        dto18.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto18, this.sessionId, this.currentKieSession);

        DTO dto19 = this.du.createSingleDto("10/10/2017 10:30:00", "10/10/2017 10:30:10", "right", "SAT_2");
        dto19.setImageBIC(10);
        dto19.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto19, this.sessionId, this.currentKieSession);

        DTO dto20 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "right", "SAT_2");
        dto20.setImageBIC(10);
        dto20.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto20, this.sessionId, this.currentKieSession);

        DTO dto21 = this.du.createSingleDto("10/10/2017 07:30:00", "10/10/2017 07:30:10", "right", "SAT_1");
        dto21.setImageBIC(10);
        dto21.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto21, this.sessionId, this.currentKieSession);

        DTO dto22 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_1");
        dto22.setImageBIC(10);
        dto22.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto22, this.sessionId, this.currentKieSession);

        DTO dto23 = this.du.createSingleDto("10/10/2017 12:00:00", "10/10/2017 12:00:10", "right", "SAT_1");
        dto23.setImageBIC(10);
        dto23.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto23, this.sessionId, this.currentKieSession);

        DTO dto24 = this.du.createSingleDto("10/10/2017 10:30:00", "10/10/2017 10:30:10", "right", "SAT_1");
        dto24.setImageBIC(10);
        dto24.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto24, this.sessionId, this.currentKieSession);

        DTO dto25 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "right", "SAT_1");
        dto25.setImageBIC(10);
        dto24.setUserInfo(userInfoListP2000);

        this.droolsInstance.insertDto(this.droolsParams, dto25, this.sessionId, this.currentKieSession);

        DTO dto26 = this.du.createSingleDto("10/10/2017 18:30:00", "10/10/2017 18:30:10", "right", "SAT_2");
        dto26.setImageBIC(10);
        dto26.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto26, this.sessionId, this.currentKieSession);

        DTO dto27 = this.du.createSingleDto("10/10/2017 17:30:00", "10/10/2017 17:30:10", "right", "SAT_2");
        dto27.setImageBIC(10);
        dto27.setUserInfo(userInfoListP2100);

        this.droolsInstance.insertDto(this.droolsParams, dto27, this.sessionId, this.currentKieSession);

        DTO dto28 = this.du.createSingleDto("10/10/2017 13:00:00", "10/10/2017 13:00:10", "right", "SAT_2");
        dto28.setImageBIC(10);
        dto27.setUserInfo(userInfoListP2100);
        this.droolsInstance.insertDto(this.droolsParams, dto28, this.sessionId, this.currentKieSession);

        DTO dto29 = this.du.createSingleDto("10/10/2017 16:30:00", "10/10/2017 16:30:10", "right", "SAT_2");
        dto29.setImageBIC(10);
        dto29.setUserInfo(userInfoListP2100);
        this.droolsInstance.insertDto(this.droolsParams, dto29, this.sessionId, this.currentKieSession);

        DTO dto30 = this.du.createSingleDto("10/10/2017 08:15:00", "10/10/2017 08:15:10", "right", "SAT_2");
        dto30.setImageBIC(10);
        dto30.setUserInfo(userInfoListP2100);
        this.droolsInstance.insertDto(this.droolsParams, dto30, this.sessionId, this.currentKieSession);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + acqRejected);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

}
