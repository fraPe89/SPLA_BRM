
package deltaFat;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

public class TestEssScenario
{

    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestEssScenario";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void testEss() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();

        // config for one orbit
        double firstOrbitToCheck = 1;
        double firstMaxThresholdOnOrbit = 600;
        long firstMaxSilent = 600;
        ResourceMaxValue resOnOneOrbit = new ResourceMaxValue(97d, firstMaxSilent, firstMaxThresholdOnOrbit, -1, -1, -1, 20);

        // config for a day orbit
        double dailyOrbitToCheck = 14.85;
        double dailyMaxThresholdOnOrbit = 6000;
        long dailyMaxSilent = 6000;
        ResourceMaxValue resOnDailyOrbit = new ResourceMaxValue(97 * dailyOrbitToCheck, dailyMaxSilent, dailyMaxThresholdOnOrbit, -1, -1, -1, 20);

        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(firstOrbitToCheck, resOnOneOrbit);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(dailyOrbitToCheck, resOnDailyOrbit);

        /*
         *
         * - PR1/AR1/DTO 1: STRIPMAP on 2016-09-14 from 08:00:00 to 08:00:10 -
         * PR1/AR2/DTO 1: SPOTLIGHT_2A on 2016-09-14 from 08:00:20 to 08:00:40 -
         * PR1/AR3/DTO 1: SCANSAR_2 on 2016-09-14 from 08:01:00 to 08:01:35 -
         * PR1/AR3/DTO 1: STRIPMAP on 2016-09-14 from 08:02:00 to 08:02:10 -
         * PR1/AR3/DTO 1: STRIPMAP on 2016-09-14 from 08:02:20 to 08:02:30
         */
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:20", "10/10/2017 08:00:40", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:01:00", "10/10/2017 08:01:35", "right", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 08:02:00", "10/10/2017 08:02:10", "right", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 08:02:20", "10/10/2017 08:02:30", "right", "SAT_1");
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        // PR9
        /*
         * - PR9/AR1/DTO 1: STRIPMAP on 2016-09-14 from 09:36:00 to 09:26:10 -
         * PR9/AR2/DTO 1: SPOTLIGHT_2A on 2016-09-14 from 09:36:20 to 09:36:40 -
         * PR9/AR3/DTO 1: SCANSAR_2 on 2016-09-14 from 09:37:00 to 09:37:35 -
         * PR9/AR3/DTO 1: STRIPMAP on 2016-09-14 from 09:38:00 to 09:38:10 -
         * PR9/AR3/DTO 1: STRIPMAP on 2016-09-14 from 09:38:20 to 09:38:30
         *
         */
        DTO dto6 = this.du.createSingleDto("10/10/2017 09:36:00", "10/10/2017 09:36:10", "right", "SAT_1");
        dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 09:36:20", "10/10/2017 09:36:40", "right", "SAT_1");
        dto7.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 09:37:00", "10/10/2017 09:37:35", "right", "SAT_1");
        dto8.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 09:38:00", "10/10/2017 09:38:10", "right", "SAT_1");
        dto9.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 09:38:20", "10/10/2017 09:38:30", "right", "SAT_1");
        dto10.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);
    }

}
