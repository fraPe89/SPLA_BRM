/**
*
* MODULE FILE NAME:	TestLeftAttitude.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		24 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 24 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package deltaFat;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

/**
 * @author francesca
 *
 */
public class TestLeftAttitude
{

    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestEssScenario";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    @Test
    public void testLeftAttitudeMoreThanEssThreshold() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();

        // config for one orbit
        double firstOrbitToCheck = 1;
        double firstMaxThresholdOnOrbit = 600;
        long firstMaxSilent = 600;
        ResourceMaxValue resOnOneOrbit = new ResourceMaxValue(97d, firstMaxSilent, firstMaxThresholdOnOrbit, -1, -1, -1, 20);

        // config for a day orbit
        double dailyOrbitToCheck = 14.85;
        double dailyMaxThresholdOnOrbit = 6000;
        long dailyMaxSilent = 6000;
        ResourceMaxValue resOnDailyOrbit = new ResourceMaxValue(97 * dailyOrbitToCheck, dailyMaxSilent, dailyMaxThresholdOnOrbit, -1, -1, -1, 20);

        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(firstOrbitToCheck, resOnOneOrbit);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(dailyOrbitToCheck, resOnDailyOrbit);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:20", "10/10/2017 08:00:40", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:01:00", "10/10/2017 08:01:35", "right", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 08:02:00", "10/10/2017 08:02:10", "right", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);
    }

    @Test
    public void testLeftAttitudeMoreThanTimeThreshold() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTimeInAllTheLeftPeriod(10);
        // config for one orbit
        double firstOrbitToCheck = 1;
        double firstMaxThresholdOnOrbit = 600;
        long firstMaxSilent = 600;
        ResourceMaxValue resOnOneOrbit = new ResourceMaxValue(97d, firstMaxSilent, firstMaxThresholdOnOrbit, -1, -1, -1, 20);

        // config for a day orbit
        double dailyOrbitToCheck = 14.85;
        double dailyMaxThresholdOnOrbit = 6000;
        long dailyMaxSilent = 6000;
        ResourceMaxValue resOnDailyOrbit = new ResourceMaxValue(97 * dailyOrbitToCheck, dailyMaxSilent, dailyMaxThresholdOnOrbit, -1, -1, -1, 20);

        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(firstOrbitToCheck, resOnOneOrbit);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(dailyOrbitToCheck, resOnDailyOrbit);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:40", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:10:00", "10/10/2017 08:10:40", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:01:00", "10/10/2017 08:01:40", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testLeftAttitudeMoreThanEssThreshold_Sce1() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();

        // config for one orbit
        double firstOrbitToCheck = 1;
        double firstMaxThresholdOnOrbit = 600;
        long firstMaxSilent = 600;
        ResourceMaxValue resOnOneOrbit = new ResourceMaxValue(97d, firstMaxSilent, firstMaxThresholdOnOrbit, -1, -1, -1, 20);

        // config for a day orbit
        double dailyOrbitToCheck = 14.85;
        double dailyMaxThresholdOnOrbit = 6000;
        long dailyMaxSilent = 6000;
        ResourceMaxValue resOnDailyOrbit = new ResourceMaxValue(97 * dailyOrbitToCheck, dailyMaxSilent, dailyMaxThresholdOnOrbit, -1, -1, -1, 20);

        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(firstOrbitToCheck, resOnOneOrbit);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(dailyOrbitToCheck, resOnDailyOrbit);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:20", "10/10/2017 08:00:40", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:01:00", "10/10/2017 08:01:35", "right", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 08:02:00", "10/10/2017 08:02:10", "right", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);
    }

    @Test
    public void A_testLeftAttitudeMoreThanEssThreshold_Sce2() throws Exception
    {
        this.sessionId = "TEST_SUL_TRENO_LEFT_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();

        // config for one orbit
        double firstOrbitToCheck = 1;
        double firstMaxThresholdOnOrbit = 600;
        long firstMaxSilent = 600;
        ResourceMaxValue resOnOneOrbit = new ResourceMaxValue(97d, firstMaxSilent, firstMaxThresholdOnOrbit, -1, -1, -1, 20);

        // config for a day orbit
        double dailyOrbitToCheck = 14.85;
        double dailyMaxThresholdOnOrbit = 6000;
        long dailyMaxSilent = 6000;
        ResourceMaxValue resOnDailyOrbit = new ResourceMaxValue(97 * dailyOrbitToCheck, dailyMaxSilent, dailyMaxThresholdOnOrbit, -1, -1, -1, 20);

        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(firstOrbitToCheck, resOnOneOrbit);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(dailyOrbitToCheck, resOnDailyOrbit);

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:20", "10/10/2017 08:00:30", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto3 = this.du.createSingleDto("10/10/2017 09:40:00", "10/10/2017 09:40:10", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:30:00", "10/10/2017 11:30:10", "right", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto5 = this.du.createSingleDto("10/10/2017 11:42:00", "10/10/2017 11:42:10", "left", "SAT_1");
        dto5.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto6 = this.du.createSingleDto("10/10/2017 08:10:00", "10/10/2017 08:10:10", "right", "SAT_1");
        dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto7 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "left", "SAT_1");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        DTO dto8 = this.du.createSingleDto("10/10/2017 09:50:00", "10/10/2017 09:50:10", "right", "SAT_1");
        dto8.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);
        System.out.println(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testLeftAttitudeMoreThanEssThreshold_Sce3() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().clear();

        // config for one orbit
        double firstOrbitToCheck = 1;
        double firstMaxThresholdOnOrbit = 600;
        long firstMaxSilent = 600;
        ResourceMaxValue resOnOneOrbit = new ResourceMaxValue(97d, firstMaxSilent, firstMaxThresholdOnOrbit, -1, -1, -1, 20);

        // config for a day orbit
        double dailyOrbitToCheck = 14.85;
        double dailyMaxThresholdOnOrbit = 6000;
        long dailyMaxSilent = 6000;
        ResourceMaxValue resOnDailyOrbit = new ResourceMaxValue(97 * dailyOrbitToCheck, dailyMaxSilent, dailyMaxThresholdOnOrbit, -1, -1, -1, 20);

        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(firstOrbitToCheck, resOnOneOrbit);
        this.droolsParams.getSatWithId("1").getSatelliteProperties().getAllChecksOnOrbits().put(dailyOrbitToCheck, resOnDailyOrbit);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:00:20", "10/10/2017 08:00:40", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:01:00", "10/10/2017 08:01:35", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 08:02:00", "10/10/2017 08:02:10", "left", "SAT_1");
        dto4.setSensorMode(TypeOfAcquisition.STRIPMAP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + this.rejectedElements);
    }

}
