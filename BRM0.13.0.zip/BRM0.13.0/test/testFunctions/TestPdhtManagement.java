/// **
// *
// * MODULE FILE NAME: TestPdhtManagement.java
// *
// * MODULE TYPE: Class definition
// *
// * FUNCTION: <Functional description of the DDC>
// *
// * PURPOSE:
// *
// * CREATION DATE: 26 set 2017
// *
// * AUTHORS: fpedrola
// *
// * DESIGN ISSUE: 1.0
// *
// * INTERFACES:
// *
// * SUBORDINATES:
// *
// * MODIFICATION HISTORY:
// *
// * Date | Name | New ver. | Description
// *
/// -----------------+------------+-------------+-------------------------------
// * 26 set 2017 | fpedrola | 1.0 | first issue
// *
/// -----------------+------------+-------------+-------------------------------
// *
// */
//
// package testFunctions;
//
// import static org.junit.Assert.*;
//
// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Date;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.TreeMap;
//
// import org.junit.Before;
// import org.junit.FixMethodOrder;
// import org.junit.Test;
// import org.junit.runners.MethodSorters;
//
// import com.nais.spla.brm.library.main.drools.DroolsOperations;
// import com.nais.spla.brm.library.main.drools.DroolsParameters;
// import com.nais.spla.brm.library.main.drools.DroolsUtils;
// import com.nais.spla.brm.library.main.drools.ResourceFunctions;
// import com.nais.spla.brm.library.main.drools.functions.DownloadManagement;
// import com.nais.spla.brm.library.main.drools.functions.PdhtManagement;
// import com.nais.spla.brm.library.main.ontology.DTO;
// import com.nais.spla.brm.library.main.ontology.enums.Polarization;
// import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
// import com.nais.spla.brm.library.main.ontology.resourceData.PacketStore;
// import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
// import com.nais.spla.brm.library.main.ontology.resources.MemoryModule;
// import com.nais.spla.brm.library.main.ontology.resources.PDHT;
// import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
// import com.nais.spla.brm.library.main.ontology.tasks.Storage;
// import com.nais.spla.brm.library.main.ontology.utils.PsPolarization;
//
/// **
// * @author fpedrola
// *
// */
// @FixMethodOrder(MethodSorters.NAME_ASCENDING)
// public class TestPdhtManagement
// {
//
// DroolsParameters droolsParams = null;
// DroolsUtils du = null;
// PdhtManagement pdhtMng = null;
// DroolsOperations droolsMng = null;
// DownloadManagement downloadMgn = null;
// List<PDHT> allPDHT = null;
// List<Visibility> allVisibility = null;
// Visibility vis1 = null, vis2 = null, vis3 = null;
//
// @Before
// public void setUp()
// {
// du = new DroolsUtils();
// droolsParams = new DroolsParameters();
//
// droolsParams.setWizardLinkDataRate(1280);
// droolsParams.setSingleSectorDimension(4);
// droolsParams.setAllPDHT(allPDHT);
//
// MissionHorizon mh = du.createMH("10/10/2017 06:21:00", "10/10/2017
/// 18:21:00");
// droolsParams.setCurrentMH(mh);
//
// pdhtMng = new PdhtManagement();
// droolsMng = new DroolsOperations();
// downloadMgn = new DownloadManagement();
// allPDHT = new ArrayList<PDHT>();
// PDHT pdht1 = new PDHT("PDHT_1", "PDHT1_Name", "SAT_1", 100000, null);
// PDHT pdht2 = new PDHT("PDHT_2", "PDHT2_Name", "SAT_2", 100000, null);
// PDHT pdht3 = new PDHT("PDHT_3", "PDHT3_Name", "SAT_3", 1000, null);
// allPDHT.add(pdht1);
// allPDHT.add(pdht2);
// allPDHT.add(pdht3);
// allVisibility = new ArrayList<Visibility>();
// vis1 = du.createParametricVisibility(1l, "SAT_1", "KIR","10/10/2017
// 06:00:00", "10/10/2017 07:00:00", 100.0, 200.0);
// vis2 = du.createParametricVisibility(2l, "SAT_1", "KIR", "10/10/2017
// 16:00:00", "10/10/2017 17:00:00", 1000.0, 2000.0);
// vis3 = du.createParametricVisibility(3l, "SAT_2", "KIR", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00", 800.0, 1200.0);
//
// allVisibility.add(vis1);
// allVisibility.add(vis2);
// allVisibility.add(vis3);
//
// droolsParams.setAllVisibilities(allVisibility);
// }
//
// /*
// @Test
// public void TestFirstVisibility_VisibilityStartsBeforeStorage()
// {
// System.out.println("\n\nRunning test :
// TestFirstVisibility_VisibilityStartsBeforeStorage");
// System.out.println(" case 1 : visibility starts before the storage ");
// double downlinkPerChannel = 260;
// Acquisition acq1 = du.createParametricAcquisition("acq_1", "10/10/2017
// 06:00:00", "10/10/2017 06:05:00", "left", "SAT_1", null);
// System.out.println("created acq : " + acq1);
//
// Storage sto1 = pdhtMng.createNewStorage(acq1,
// droolsParams.getSingleSectorDimension());
// System.out.println("created sto : "+sto1);
//
// List<Visibility> allVisibilityForTest = new ArrayList<Visibility>();
// Visibility vis1 = du.createVisibilityForTest("VIS_1", "SAT_1", "10/10/2017
/// 06:00:00", "10/10/2017 07:00:00",downlinkPerChannel);
// Visibility vis2 = du.createVisibilityForTest("VIS_2", "SAT_1", "10/10/2017
/// 16:00:00", "10/10/2017 17:00:00",downlinkPerChannel);
// Visibility vis3 = du.createVisibilityForTest("VIS_3", "SAT_1", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00",downlinkPerChannel);
// Visibility vis4 = du.createVisibilityForTest("VIS_4", "SAT_2", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00",downlinkPerChannel);
// allVisibilityForTest.add(vis1);
// allVisibilityForTest.add(vis2);
// allVisibilityForTest.add(vis3);
// allVisibilityForTest.add(vis4);
// downloadMgn.sortVisibilityList(allVisibilityForTest);
//
// //receiving only the visibilities that starts after the storage that we are
// planned
// List<Visibility> onlyValidVisibilities =
// downloadMgn.filterVisibilities(allVisibilityForTest,sto1,droolsParams.getMinPercDownloadOnVis());
// assertEquals(3,onlyValidVisibilities.size());
//
// System.out.println("only valid visibilities : ");
// for(int i=0;i<onlyValidVisibilities.size();i++)
// {
// System.out.println(onlyValidVisibilities.get(i));
// }
//
// //the first valid visibility starts at 06:00 and the storage starts at 06:05
/// , the download will plan at the first date available, so 06:05
// Date selectedVis =
// downloadMgn.receiveFirstDateAvailableForDownloadTheStorage(sto1,onlyValidVisibilities,downlinkPerChannel);
// System.out.println("first download date is : "+selectedVis);
// assertEquals(vis1.getVisibilityId(),selectedVis);
// assertEquals(sto1.getEndTime(),vis1.getAvailableStartTimeL1());
// }
//
//
// @Test
// public void TestFirstVisibility_VisibilityStartsAfterStorage()
// {
// System.out.println("\n\nRunning test :
// TestFirstVisibility_VisibilityStartsAfterStorage ");
// double downlinkPerChannel = 260;
//
// System.out.println(" case 2 : visibility starts after the storage ");
//
// Acquisition acq2 = du.createParametricAcquisition("acq_2", "10/10/2017
// 07:08:00", "10/10/2017 07:18:00", "left", "SAT_1", null);
// System.out.println("created acq : " + acq2);
//
// Storage sto2 = pdhtMng.createNewStorage(acq2,
// droolsParams.getSingleSectorDimension());
// System.out.println("created sto : "+sto2);
//
//
//
// List<Visibility> allVisibilityForTest = new ArrayList<Visibility>();
// Visibility vis1 = du.createVisibilityForTest("VIS_1", "SAT_1", "10/10/2017
// 06:00:00", "10/10/2017 07:00:00",downlinkPerChannel);
// Visibility vis2 = du.createVisibilityForTest("VIS_2", "SAT_1", "10/10/2017
// 16:00:00", "10/10/2017 17:00:00",downlinkPerChannel);
// Visibility vis3 = du.createVisibilityForTest("VIS_3", "SAT_1", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00",downlinkPerChannel);
// Visibility vis4 = du.createVisibilityForTest("VIS_4", "SAT_2", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00",downlinkPerChannel);
// allVisibilityForTest.add(vis1);
// allVisibilityForTest.add(vis2);
// allVisibilityForTest.add(vis3);
// allVisibilityForTest.add(vis4);
// downloadMgn.sortVisibilityList(allVisibilityForTest);
// // pdhtMng.insertStoInPDHT(validVisibilities, PDHTFunction, sto, polar,
/// droolsParams, PDHTAssociatedToSat);
// //receiving only the visibilities that starts after the storage that we are
// planned
// List<Visibility> onlyValidVisibilities =
// downloadMgn.filterVisibilities(allVisibilityForTest,sto2,droolsParams.getMinPercDownloadOnVis());
// assertEquals(2,onlyValidVisibilities.size());
//
// Date selectedVis =
// downloadMgn.receiveFirstDateAvailableForDownloadTheStorage(sto2,onlyValidVisibilities,downlinkPerChannel);
// System.out.println("first download date is : "+selectedVis);
// assertEquals(sto2.getAvailableDateForDownload(),selectedVis);
//
// }
//
//
// @Test
// public void TestFirstVisibility_NoValidVisibilitiesAvailable()
// {
// System.out.println("\n\nRunning test :
// TestFirstVisibility_NoValidVisibilitiesAvailable ");
// double downlinkPerChannel = 260;
//
// System.out.println(" case 3 : there aren't available visibilities ");
//
// Acquisition acq3 = du.createParametricAcquisition("acq_3", "10/10/2017
// 17:08:00", "10/10/2017 17:18:00", "left", "SAT_1", null);
// System.out.println("created acq : " + acq3);
//
// Storage sto3 = pdhtMng.createNewStorage(acq3,
// droolsParams.getSingleSectorDimension());
// System.out.println("created sto : "+sto3);
//
// List<Visibility> allVisibilityForTest = new ArrayList<Visibility>();
// Visibility vis1 = du.createVisibilityForTest("VIS_1", "SAT_1", "10/10/2017
// 06:00:00", "10/10/2017 07:00:00",downlinkPerChannel);
// Visibility vis2 = du.createVisibilityForTest("VIS_2", "SAT_1", "10/10/2017
// 16:00:00", "10/10/2017 17:00:00",downlinkPerChannel);
// Visibility vis3 = du.createVisibilityForTest("VIS_3", "SAT_1", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00",downlinkPerChannel);
// Visibility vis4 = du.createVisibilityForTest("VIS_4", "SAT_2", "10/10/2017
// 10:00:00", "10/10/2017 12:00:00",downlinkPerChannel);
// allVisibilityForTest.add(vis1);
// allVisibilityForTest.add(vis2);
// allVisibilityForTest.add(vis3);
// allVisibilityForTest.add(vis4);
// downloadMgn.sortVisibilityList(allVisibilityForTest);
// //receiving only the visibilities that starts after the storage that we are
// planned
// List<Visibility> onlyValidVisibilities =
// downloadMgn.filterVisibilities(allVisibilityForTest,sto3,droolsParams.getMinPercDownloadOnVis());
// assertEquals(0,onlyValidVisibilities.size());
//
// Date selectedVis =
// downloadMgn.receiveFirstDateAvailableForDownloadTheStorage(sto3,onlyValidVisibilities,downlinkPerChannel);
// System.out.println("first download date is : "+selectedVis);
// assertEquals(null,selectedVis);
//
// }
// */
//
// /*
// @Test
// public void A_test_extract_previous_PDHT_state_Empty_PDHTFunction()
// {
// System.out.println("\n\n I'm running test
/// A_test_extract_previous_PDHT_state");
// Acquisition acq1 = du.createParametricAcquisition("acq_1", "29/03/2017
/// 06:00:00", "29/03/2017 06:05:00", "left", "SAT_1", null);
// System.out.println("for acq : " + acq1);
// PDHT initialPDHT = allPDHT.get(0);
// TreeMap<Long, PDHT> pDHTFunction = new TreeMap<Long, PDHT>();
// Storage sto = pdhtMng.createNewStorage(acq1,
/// droolsParams.getSingleSectorDimension());
// PDHT expectedPDHT = pdhtMng.receivePDHTFromFunction(vis1, pDHTFunction, sto,
/// allPDHT.get(0), droolsParams);
// System.out.println("previous PDHT : " + expectedPDHT);
// for (int i = 0; i < initialPDHT.getMMList().size(); i++)
// {
// for (int j = 0; j < expectedPDHT.getMMList().size(); j++)
// {
// if
/// (initialPDHT.getMMList().get(i).getId().equals(expectedPDHT.getMMList().get(j).getId()))
// {
// assertEquals(expectedPDHT.getMMList().get(j).getFreeSectors(),
/// initialPDHT.getMMList().get(i).getFreeSectors());
// }
// }
// }
// }
//
// @Test
// public void
/// B_test_extract_previous_PDHT_state_exists_previous_PDHT_in_PDHTFunction()
// {
// System.out.println("\n\n I'm running test
/// B_test_extract_previous_PDHT_state_exists_previous_PDHT_in_PDHTFunction");
// Acquisition acq1 = du.createParametricAcquisition("acq_1", "29/03/2017
/// 06:00:00", "29/03/2017 06:05:00", "left", "SAT_1", null);
// acq1.setSize(2000);
// TreeMap<Long, PDHT> pDHTFunction = new TreeMap<Long, PDHT>();
// Long previousPdhtFunctionDateInLong = acq1.getStartTime().getTime() - 90000;
// PDHT previousPDHT = new PDHT("PDHT_2", "PDHT2_Name", "SAT_2", 6000, null);
// pDHTFunction.put(previousPdhtFunctionDateInLong, previousPDHT);
// Storage sto = pdhtMng.createNewStorage(acq1,
/// droolsParams.getSingleSectorDimension());
// PDHT expectedPDHT = pdhtMng.receivePDHTFromFunction(vis1, pDHTFunction, sto,
/// allPDHT.get(1), droolsParams);
// for (int i = 0; i < previousPDHT.getMMList().size(); i++)
// {
// for (int j = 0; j < expectedPDHT.getMMList().size(); j++)
// {
// if
/// (previousPDHT.getMMList().get(i).getId().equals(expectedPDHT.getMMList().get(j).getId()))
// {
// assertEquals(expectedPDHT.getMMList().get(j).getFreeSectors(),
/// previousPDHT.getMMList().get(i).getFreeSectors());
// }
// }
// }
// }
//
// @Test
// public void D_check_correct_polarization()
// {
// System.out.println("\n\n I'm running test D_check_correct_polarization");
// Acquisition acq1 = du.createParametricAcquisition("acq_1", "29/03/2017
/// 06:00:00", "29/03/2017 06:05:00", "left", "SAT_1", null);
//
// //test polarization HH
//
// acq1.setPolarization(Polarization.HH);
// System.out.println("check with single polarization : " + Polarization.HH);
// Polarization[] extectedPolarization = new Polarization[1];
// extectedPolarization[0] = Polarization.HH;
// Polarization[] calculatedPolarizationArray =
/// pdhtMng.populatePolarization(acq1.getPolarization());
// int calculatedPolarization = 1;
// if (calculatedPolarizationArray.length == 2)
// {
// calculatedPolarization = 2;
// }
// System.out.println("the polarization expected is 1 :" +
/// calculatedPolarization);
//
// assertEquals(1, calculatedPolarization);
// assertEquals(extectedPolarization[0], calculatedPolarizationArray[0]);
// assertEquals(extectedPolarization.length,
/// calculatedPolarizationArray.length);
// System.out.println("correct with single polarization " + Polarization.HH);
//
// //test polarization VV
//
// acq1.setPolarization(Polarization.VV);
// System.out.println("check with single polarization : " + Polarization.VV);
// extectedPolarization = new Polarization[1];
// extectedPolarization[0] = Polarization.VV;
// calculatedPolarizationArray =
/// pdhtMng.populatePolarization(acq1.getPolarization());
// if (calculatedPolarizationArray.length == 2)
// {
// calculatedPolarization = 2;
// }
// else
// {
// calculatedPolarization = 1;
// }
// System.out.println("the polarization expected is 1 :" +
/// calculatedPolarization);
//
// assertEquals(1, calculatedPolarization);
// assertEquals(extectedPolarization[0], calculatedPolarizationArray[0]);
// assertEquals(extectedPolarization.length,
/// calculatedPolarizationArray.length);
// System.out.println("correct with single polarization " + Polarization.VV);
//
// // test polarization HV
//
// acq1.setPolarization(Polarization.HV);
// System.out.println("check with single polarization : " + Polarization.HV);
// extectedPolarization = new Polarization[2];
// extectedPolarization[0] = Polarization.HH;
// extectedPolarization[1] = Polarization.VV;
// calculatedPolarizationArray =
/// pdhtMng.populatePolarization(acq1.getPolarization());
// if (calculatedPolarizationArray.length == 2)
// {
// calculatedPolarization = 2;
// }
// else
// {
// calculatedPolarization = 1;
// }
// System.out.println("the polarization expected is 2 :" +
/// calculatedPolarization);
//
// assertEquals(2, calculatedPolarization);
// assertEquals(extectedPolarization[0], calculatedPolarizationArray[0]);
// assertEquals(extectedPolarization[1], calculatedPolarizationArray[1]);
// assertEquals(extectedPolarization.length,
/// calculatedPolarizationArray.length);
// System.out.println("correct with double polarization " + Polarization.HV);
//
// //test polarization VH
//
// acq1.setPolarization(Polarization.VH);
// System.out.println("check with single polarization : " + Polarization.VH);
// extectedPolarization = new Polarization[2];
// extectedPolarization[0] = Polarization.VV;
// extectedPolarization[1] = Polarization.HH;
// calculatedPolarizationArray =
/// pdhtMng.populatePolarization(acq1.getPolarization());
// if (calculatedPolarizationArray.length == 2)
// {
// calculatedPolarization = 2;
// }
// else
// {
// calculatedPolarization = 1;
// }
// System.out.println("the polarization expected is 2 :" +
/// calculatedPolarization);
//
// assertEquals(2, calculatedPolarization);
// assertEquals(extectedPolarization[0], calculatedPolarizationArray[0]);
// assertEquals(extectedPolarization[1], calculatedPolarizationArray[1]);
// assertEquals(extectedPolarization.length,
/// calculatedPolarizationArray.length);
// System.out.println("correct with double polarization " + Polarization.VH);
// }
//
// @Test
// public void E_test_storage_enter_totally_in_a_single_memory_modules()
// {
// System.out.println("\n\n I'm running test
/// E_test_storage_enter_totally_in_a_single_memory_modules");
// Acquisition acq1 = du.createParametricAcquisition("acq_1", "08/10/2017
/// 06:00:00", "08/10/2017 06:05:00", "left", "SAT_2", null);
// acq1.setPolarization(Polarization.HH);
// acq1.setSize(2000);
// Storage sto = pdhtMng.createNewStorage(acq1,
/// droolsParams.getSingleSectorDimension());
// System.out.println("storage : " + sto.toString());
// TreeMap<Long, PDHT> PDHTFunction = new TreeMap<Long, PDHT>();
// List<PacketStore> packetsCreated = pdhtMng.insertStoInPDHT(vis2,
/// PDHTFunction, sto, acq1, droolsParams, allPDHT.get(1));
// System.out.println("packets created " + packetsCreated);
// }
// */
// @Test
// public void H_test_createPS_and_decrement_memoryModules_case_single_pol_HH()
// {
// System.out.println("\n\n I'm running test
/// H_test_createPS_and_decrement_memoryModules_case_single_pol_HH");
// Acquisition acq = du.createParametricAcquisition("acq_1", "29/03/2017
/// 06:00:00", "29/03/2017 06:05:00", "left", "SAT_1", null);
// acq.setPolarization(Polarization.HH);
// int storageSectors = 200;
// Storage sto = new Storage("sto_1",
/// storageSectors,acq.getStartTime(),acq.getEndTime(), acq.getPolarization());
// Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<MemoryModule,
/// PsPolarization>();
//
// MemoryModule mem1 = new MemoryModule("MM1", 1000);
// MemoryModule mem2 = new MemoryModule("MM2", 500);
// MemoryModule mem3 = new MemoryModule("MM3", 200);
//
// PsPolarization sectorUsedForStoOnMM1 = new PsPolarization(100, 1);
// PsPolarization sectorUsedForStoOnMM2 = new PsPolarization(60, 1);
// PsPolarization sectorUsedForStoOnMM3 = new PsPolarization(40, 1);
// modulesCapacity.put(mem1, sectorUsedForStoOnMM1);
// modulesCapacity.put(mem2, sectorUsedForStoOnMM2);
// modulesCapacity.put(mem3, sectorUsedForStoOnMM3);
//
// /*List<PacketStore> psCreated =
/// pdhtMng.createPS_and_decrement_memoryModules(sto,modulesCapacity);
// assertEquals(1, psCreated.size());
// System.out.println(psCreated.toString());*/
// }
//
// /*
// @Test
// public void I_test_createPS_and_decrement_memoryModules_case_double_pol_HV()
// {
// System.out.println("\n\n I'm running test
/// I_test_createPS_and_decrement_memoryModules_case_double_pol_HV");
// Acquisition acq = du.createParametricAcquisition("acq_1", "29/03/2017
/// 06:00:00", "29/03/2017 06:05:00", "left", "SAT_1", null);
// acq.setPolarization(Polarization.HV);
// acq.setSize(200);
// System.out.println("creating acquisition :" + acq);
// Storage sto = pdhtMng.createNewStorage(acq, 4);
// System.out.println("creating storage related to acq : " + sto);
// Map<MemoryModule, PsPolarization> modulesCapacity = new HashMap<MemoryModule,
/// PsPolarization>();
//
// MemoryModule mem1 = new MemoryModule("MM1", 1000);
// MemoryModule mem2 = new MemoryModule("MM2", 500);
// MemoryModule mem3 = new MemoryModule("MM3", 300);
// MemoryModule mem4 = new MemoryModule("MM4", 300);
// MemoryModule mem5 = new MemoryModule("MM5", 200);
// MemoryModule mem6 = new MemoryModule("MM6", 100);
//
// PsPolarization sectorUsedForStoOnMM1 = new PsPolarization(100, 1);
// PsPolarization sectorUsedForStoOnMM2 = new PsPolarization(60, 1);
// PsPolarization sectorUsedForStoOnMM3 = new PsPolarization(40, 1);
// PsPolarization sectorUsedForStoOnMM4 = new PsPolarization(100, 2);
// PsPolarization sectorUsedForStoOnMM5 = new PsPolarization(60, 2);
// PsPolarization sectorUsedForStoOnMM6 = new PsPolarization(40, 2);
//
// modulesCapacity.put(mem1, sectorUsedForStoOnMM1);
// modulesCapacity.put(mem2, sectorUsedForStoOnMM2);
// modulesCapacity.put(mem3, sectorUsedForStoOnMM3);
// modulesCapacity.put(mem4, sectorUsedForStoOnMM4);
// modulesCapacity.put(mem5, sectorUsedForStoOnMM5);
// modulesCapacity.put(mem6, sectorUsedForStoOnMM6);
//
// long expectedMM1FreeSectorAfterCreationOfPS = mem1.getFreeSectors() -
/// sectorUsedForStoOnMM1.getSectorUsedForPs();
// long expectedMM2FreeSectorAfterCreationOfPS = mem2.getFreeSectors() -
/// sectorUsedForStoOnMM2.getSectorUsedForPs();
// long expectedMM3FreeSectorAfterCreationOfPS = mem3.getFreeSectors() -
/// sectorUsedForStoOnMM3.getSectorUsedForPs();
// long expectedMM4FreeSectorAfterCreationOfPS = mem4.getFreeSectors() -
/// sectorUsedForStoOnMM4.getSectorUsedForPs();
// long expectedMM5FreeSectorAfterCreationOfPS = mem5.getFreeSectors() -
/// sectorUsedForStoOnMM5.getSectorUsedForPs();
// long expectedMM6FreeSectorAfterCreationOfPS = mem6.getFreeSectors() -
/// sectorUsedForStoOnMM6.getSectorUsedForPs();
// List<PacketStore> psCreated =
/// pdhtMng.createPS_and_decrement_memoryModules(acq.getPolarization(), sto,
/// modulesCapacity);
//
// assertEquals(expectedMM1FreeSectorAfterCreationOfPS, mem1.getFreeSectors());
// assertEquals(expectedMM2FreeSectorAfterCreationOfPS, mem2.getFreeSectors());
// assertEquals(expectedMM3FreeSectorAfterCreationOfPS, mem3.getFreeSectors());
// assertEquals(expectedMM4FreeSectorAfterCreationOfPS, mem4.getFreeSectors());
// assertEquals(expectedMM5FreeSectorAfterCreationOfPS, mem5.getFreeSectors());
// assertEquals(expectedMM6FreeSectorAfterCreationOfPS, mem6.getFreeSectors());
// }
//
//
// @Test
// public void L_test_createPS_and_decrement_memoryModules_case_double_pol_HV()
// {
// System.out.println("\n\n I'm running test
/// E_test_storage_enter_totally_in_a_single_memory_modules");
// TreeMap<Long, PDHT> PDHTFunction = new TreeMap<Long, PDHT>();
// Acquisition acq1 = du.createParametricAcquisition("acq_1", "08/10/2017
/// 06:00:00", "08/10/2017 06:05:00", "left", "SAT_2", null);
// acq1.setPolarization(Polarization.HH);
// acq1.setSize(40);
//
// Storage sto = pdhtMng.createNewStorage(acq1,
/// droolsParams.getSingleSectorDimension());
// System.out.println("storage : " + sto.toString());
//
// List<PacketStore> packetsCreated = pdhtMng.insertStoInPDHT(vis2,
/// PDHTFunction, sto, acq1, droolsParams, allPDHT.get(1));
// }
// */
// }
