/**
*
* MODULE FILE NAME: TestBicManagement.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        20 set 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 20 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testFunctions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.functions.BicManagement;
import com.nais.spla.brm.library.main.drools.utils.BicUtils;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.exception.ConfigurationException;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * The Class TestDroolsBicManagement.
 *
 * @author fpedrola
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestDroolsBicManagement
{

    /** The session id. */
    private String sessionId = null;

    /** The rejected elements. */
    private Map<String, Acquisition> rejectedElements = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The all partners. */
    private List<Partner> allPartners = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    private BicManagement bicMng = null;

    private DroolsQueries queries = null;

    private BicUtils bicUtils = new BicUtils();

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestDroolsBicManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.queries = new DroolsQueries();
        this.maxBicForTest = 100;
        this.allPartners = new ArrayList<>();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.bicMng = new BicManagement();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        BicManagement bicManagement = new BicManagement();
        Logger logger = DroolsParameters.getLogger();
        List<Partner> listOfPartner = this.droolsParams.getAllPartners();

        HashMap<String, Acquisition> rejected = new HashMap<>();
        Acquisition acq = this.du.createParametricAcquisition("acq1", "17/01/2018 12:08:03", "17/01/2018 12:12:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, listOfPartner.get(0).getPartnerId(), listOfPartner.get(0).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, listOfPartner.get(1).getPartnerId(), listOfPartner.get(1).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        acq.setUserInfo(userInfoList);
        acq.setImageBIC(20);
        TreeMap<Long, EnergyAssociatedToTask> allAcq = resourceFunctions.getEssFunctionAssociatedToSat(acq.getSatelliteId());
        TreeMap<Long, Maneuver> allMan = resourceFunctions.getManeuverFunctionAssociatedToSat(acq.getSatelliteId());

        if (acq.getLookSide().equalsIgnoreCase("left")) // use also extra bic
                                                        // for left attitude
        {
            logger.debug("027_DECREMENT_BIC_RULE_");
            acq.setImageBIC(acq.getImageBIC() + this.droolsParams.getExtraCostLeft());
        }
        List<Partner> partnersWithInvalidBic = bicManagement.checkBicAndNeoBicForAcq(this.droolsParams, acq, null, allAcq, allMan);
        if (!partnersWithInvalidBic.isEmpty() && acq.getUserInfo().isEmpty())
        {
            if (acq.getUserInfo().isEmpty())
            {
                logger.debug("DECREMENT_BIC_RULE_ no one  of the partners associated had valid bic, acq rejected");
                List<String> otherAcqOfPartners = this.bicMng.findAllAcqRelatedToRejectedPartners(partnersWithInvalidBic, allAcq);
                acq.addReasonOfReject(1, ReasonOfReject.bicNotAvailable, "", 0, 0, otherAcqOfPartners);
                rejected.put(acq.getId(), acq);
                logger.debug("DECREMENT_BIC_RULE_ acq :" + acq + " cannot be accepted because : bicNotAvailable / noNEOBicAvailable");
                acq.setRejected(true);
            }
        }
        else
        {
            logger.debug("DECREMENT_BIC_RULE_ bic decremented only for : " + acq.getUserInfo());
        }
    }

    /**
     * B test BI C 2 BI C used for acquisition.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void B_Test_BIC_2_BIC_Used_for_acquisition() throws ConfigurationException, Exception
    {
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : B_Test_BIC_2_BIC_Used_for_acquisition \n\n");
        double maxBicForTest = 100;
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }
        Partner partnerForTest = allPartners.get(1);
        allPartners.get(0).getBorrowingBic().add(partnerForTest.getPartnerId());

        System.out.println("partner choosen for test : " + partnerForTest);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "right", "SAT_1");
        dto1.setPrType(PRType.PP);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, partnerForTest.getPartnerId(), partnerForTest.getUgsId());
        userInfoList.add(userInfo1);

        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(120);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println("accepted ? " + accepted);

        System.out.println("for partner :" + partnerForTest);
        assertFalse(partnerForTest.getLoanList().isEmpty());
        assertTrue(partnerForTest.getGivenLoan().isEmpty());

        double loan = partnerForTest.getLoanList().get(0).getBICBorrowed();
        String creditorId = partnerForTest.getLoanList().get(0).getCreditor();
        Partner creditor = this.bicUtils.findPartnerInList(creditorId, this.droolsParams.getAllPartners());

        assertEquals(dto1.getImageBIC() - loan, partnerForTest.getUsedBIC(), 0);
        for (int i = 0; i < allPartners.size(); i++)
        {
            System.out.println("extracted partner : " + allPartners.get(i));
            if (allPartners.get(i).getPartnerId().equalsIgnoreCase(partnerForTest.getPartnerId()))
            {
                assertEquals(dto1.getImageBIC() - loan, partnerForTest.getUsedBIC(), 0);
            }
            else if (allPartners.get(i).getPartnerId().equalsIgnoreCase(creditor.getPartnerId()))
            {
                assertEquals(loan, allPartners.get(i).getUsedBIC(), 0);
            }
            else
            {
                assertEquals(maxBicForTest, allPartners.get(i).getMaxBICAvailable(), 0);
                assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            }
        }
    }

    /**
     * Need loan but no partners available.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void NeedLoanButNoPartnersAvailable() throws ConfigurationException, Exception
    {
        System.out.println("Running test : NeedLoanButNoPartnersAvailable \n\n");
        double maxBicForTest = 100;
        double maxPercLoanBic = 20;
        // create new partners
        List<String> arAssociatedToPartner = Arrays.asList("fakeAr", "arTest");
        this.allPartners = new ArrayList<>();
        Partner p1 = new Partner("Partner_1", arAssociatedToPartner, maxBicForTest, maxPercLoanBic);
        Partner p2 = new Partner("Partner_2", arAssociatedToPartner, maxBicForTest, maxPercLoanBic);
        Partner p3 = new Partner("Partner_3", arAssociatedToPartner, maxBicForTest, maxPercLoanBic);
        Partner p4 = new Partner("Partner_4", arAssociatedToPartner, maxBicForTest, maxPercLoanBic);
        this.allPartners.add(p1);
        this.allPartners.add(p2);
        this.allPartners.add(p3);
        this.allPartners.add(p4);

        this.droolsParams.setAllPartners(this.allPartners);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(120);
        dto1.setPrType(PRType.PP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        assertEquals(0, p1.getUsedBIC(), 0);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("Rejected because : " + ReasonOfReject.bicNotAvailable);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.bicNotAvailable);
        assertTrue(found);

        System.out.println("partner owner of acq : " + p1);
    }

    /**
     * D test BI C 3 no neo.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void D_Test_BIC_3_No_Neo() throws ConfigurationException, Exception
    {
        System.out.println("Running test : D_Test_BIC_3_No_Neo \n\n");
        double maxBicForTest = 100;
        double maxPerLoanAvailable = 20;
        // create new partners
        List<String> arAssociatedToPartner = Arrays.asList("fakeAr", "arTest");
        this.allPartners = new ArrayList<>();
        Partner p1 = new Partner("Partner_1", arAssociatedToPartner, maxBicForTest, maxPerLoanAvailable);
        p1.setMaxNEOBicAvailable(100);

        Partner p2 = new Partner("Partner_2", arAssociatedToPartner, maxBicForTest, maxPerLoanAvailable);
        p2.getBorrowingBic().add("Partner_1");
        p2.setFinished(true);

        Partner p3 = new Partner("Partner_3", arAssociatedToPartner, maxBicForTest, maxPerLoanAvailable);
        Partner p4 = new Partner("Partner_4", arAssociatedToPartner, maxBicForTest, maxPerLoanAvailable);
        this.allPartners.add(p1);
        this.allPartners.add(p2);
        this.allPartners.add(p3);
        this.allPartners.add(p4);

        this.droolsParams.setAllPartners(this.allPartners);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        dto1.setNeoAvailable(true);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        dto1.setSizeH(20);
        dto1.setImageBIC(120);
        dto1.setPrType(PRType.PP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);

        Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("acquisition : " + acq);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("Rejected because : " + ReasonOfReject.bicNotAvailable);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.neoBicNotAvailable);
        assertTrue(found);
    }

    /**
     * O test BI C 4 loan partner available.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void O_Test_BIC_4_loan_partner_available() throws ConfigurationException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : O_Test_BIC_4_loan_partner_available \n\n");
        double maxBicForTest = 100;
        double maxPercLoanAvailable = 30;
        double imageBicFortest = 120;
        String arIdForTest = "AR-001";

        Partner debitor = this.droolsParams.getAllPartners().get(0);
        debitor.setArIdForPartner(new ArrayList<>(Arrays.asList(arIdForTest)));
        debitor.setMaxBICAvailable(maxBicForTest);
        debitor.setMaxPercLoanBic(maxPercLoanAvailable);

        Partner creditor = this.droolsParams.getAllPartners().get(1);
        creditor.setMaxBICAvailable(200);
        creditor.setMaxPercLoanBic(60);
        creditor.setBorrowingBic(new ArrayList<>(Arrays.asList(debitor.getPartnerId())));
        creditor.setFinished(true);

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:56:00", "left", "SAT_1");
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, debitor.getPartnerId(), debitor.getUgsId());
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(imageBicFortest);
        dto1.setPrType(PRType.PP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        List<Task> allTasks = this.queries.getAllAcceptedTasks(this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println("all tasks : " + allTasks);
        System.out.println("debitor: " + debitor.getUsedBIC());
        System.out.println("debitor loan list: " + debitor.getLoanList());
        System.out.println("creditor given loan: " + creditor.getGivenLoan());

        System.out.println("debitor : " + debitor);
        System.out.println("creditor : " + creditor);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        System.out.println("debitor : " + debitor);
        System.out.println("creditor : " + creditor);

    }

    /**
     * E test multiple bic 1 partner.
     */
    @Test
    public void E_test_multipleBic1Partner() throws Exception
    {
        System.out.println("\n\n\n\n running test : E_test_multipleBic1Partner");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partner = this.droolsParams.getAllPartners().get(0);
        List<String> arAssociated = Arrays.asList("AR_01", "AR_02", "AR_03");
        partner.setArIdForPartner(arAssociated);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:52:00", "10/10/2017 15:53:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, partner.getPartnerId(), partner.getUgsId());
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);

        dto1.setArID("AR_01");
        dto1.setImageBIC(1);

        // droolsInstance.insertPartner(partner, currentKieSession);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println("1) partner residual BIC " + partner.getUsedBIC());

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:56:00", "left", "SAT_1");
        dto2.setArID("AR_01");
        dto2.setImageBIC(1);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        // droolsInstance.insertPartner(partner, currentKieSession);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        System.out.println("2) partner residual BIC " + partner.getUsedBIC());

        System.out.println("p 10 : " + partner.getUsedBIC());
        System.out.println("p 10 loan list: " + partner.getLoanList());

        TaskPlanned taskPlanned = new TaskPlanned();
        System.out.println("before clear");
        System.out.println(taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1"));
        System.out.println("after clear");
        System.out.println(taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1"));

    }

    /**
     * Q exclude only one partner for no neo bic available.
     */
    @Test
    public void Q_excludeOnlyOnePartnerForNoNeoBicAvailable() throws Exception
    {
        System.out.println("\n\n\n\n running test : Q_excludeOnlyOnePartnerForNoNeoBicAvailable()");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxDailyBicForPartner = 200;
        double maxNeoP1 = 70;
        double maxNeoP2 = 200;
        double maxNeoP3 = 20;
        double imageBicForTest = 150;
        boolean accepted = true;
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        p1.setMaxBICAvailable(maxDailyBicForPartner);
        p1.setMaxNEOBicAvailable(maxNeoP1);

        Partner p2 = this.droolsParams.getAllPartners().get(1);
        p2.setMaxBICAvailable(maxDailyBicForPartner);
        p2.setMaxNEOBicAvailable(maxNeoP2);

        Partner p3 = this.droolsParams.getAllPartners().get(2);
        p3.setMaxBICAvailable(maxDailyBicForPartner);
        p3.setMaxNEOBicAvailable(maxNeoP3);

        System.out.println("inserted a Partner p1 with " + maxNeoP1 + " as NeoBic");
        System.out.println("inserted a Partner p2 with " + maxNeoP2 + " as NeoBic");
        System.out.println("inserted a Partner p3 with " + maxNeoP3 + " as NeoBic");

        ArrayList<String> partnersAssociatedId = new ArrayList<>();
        partnersAssociatedId.add(p1.getPartnerId());
        partnersAssociatedId.add(p2.getPartnerId());

        // Acquisition acq = du.createParametricAcquisition("acq_1", "08/10/2017
        // 03:00:00", "08/10/2017 03:05:00", "left", "SAT_2", null);
        DTO dto = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:01:00", "right", "SAT_2");
        dto.setSizeH(200);
        dto.setPol(Polarization.HH);
        dto.setNeoAvailable(true);
        dto.setImageBIC(imageBicForTest);
        dto.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto.setUserInfo(userInfoList);

        System.out.println("new dto " + dto.getDtoId() + " involved only two of the partners : " + partnersAssociatedId);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("p1 :" + p1);
        System.out.println("p2 :" + p2);
        assertFalse(p1.getAcqPerformed().contains(dto.getDtoId()));

        Acquisition acqReturnedByDrools = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("print p1 : " + p2);
        System.out.println("print p2 : " + p2);
        System.out.println("acq : " + acqReturnedByDrools);
        assertTrue(p2.getAcqPerformed().contains(dto.getDtoId()));

        System.out.println(p1.getPartnerId() + " is removed from " + dto.getDtoId() + " because it has not enough bic of type neo");

        System.out.println(p2.getPartnerId() + " has enough neo bic and the amount of neo bic is correctly decremented of the image bic size");
        System.out.println(p3.getPartnerId() + " is invariated because it is not linked with the current acquisition");
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(imageBicForTest, p2.getUsedNeoBic(), 0);
        assertEquals(imageBicForTest, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedNeoBic(), 0);
    }

    @Test
    public void P_excludeOnlyOnePartnerForBicNotAvailable() throws Exception
    {
        System.out.println("\n\n\n\n running test : P_excludeOnlyOnePartnerForBicNotAvailable()");

        /*
         * setUp drools session
         */
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        /*
         * create an arIdList to associate to partner
         */
        List<String> arIdFortest = new ArrayList<>();
        arIdFortest.add("AR-001");

        /*
         * declare partners max bic and neo bic
         */
        double maxNeoP1 = 200;
        double maxBicP1 = 60;

        double maxNeoP2 = 200;
        double maxBicP2 = 200;

        double maxNeoP3 = 20;
        double maxBicP3 = 50;

        double imageBicForTest = 150;
        boolean accepted = true;

        /*
         * first partner associated to acq
         */
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        p1.setArIdForPartner(arIdFortest);
        p1.setMaxBICAvailable(maxBicP1);
        p1.setMaxNEOBicAvailable(maxNeoP1);

        /*
         * second partner associated to acq
         */
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        p2.setArIdForPartner(arIdFortest);
        p2.setMaxBICAvailable(maxBicP2);
        p2.setMaxNEOBicAvailable(maxNeoP2);

        /*
         * another partner not involved in acquisitions
         */
        Partner p3 = this.droolsParams.getAllPartners().get(2);
        p3.setMaxBICAvailable(maxBicP3);
        p3.setMaxNEOBicAvailable(maxNeoP3);

        /*
         * creting an user info list for the dto under test
         */
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(p1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(p2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        /*
         * creating a dto
         */
        DTO dto = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:01:00", "right", "SAT_2");
        dto.setNeoAvailable(true);
        dto.setImageBIC(imageBicForTest);
        dto.setUserInfo(userInfoList);
        dto.setPrType(PRType.PP);

        /*
         * insert the dto into Drools and verity that it will be accepted.
         */
        System.out.println("new dto " + dto.getDtoId() + " involved only two of the partners : " + dto.getUserInfo());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("p1 :" + p1);
        System.out.println("p2 :" + p2);
        assertFalse(p1.getAcqPerformed().contains(dto.getDtoId()));

        Acquisition acqReturnedByDrools = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("print p1 : " + p2);
        System.out.println("print p2 : " + p2);
        System.out.println("acq : " + acqReturnedByDrools);
        assertTrue(p2.getAcqPerformed().contains(dto.getDtoId()));

        System.out.println(p1.getPartnerId() + " is removed from " + dto.getDtoId() + " because it has not enough bic of type neo");

        System.out.println(p2.getPartnerId() + " has enough neo bic and the amount of neo bic is correctly decremented of the image bic size");
        System.out.println(p3.getPartnerId() + " is invariated because it is not linked with the current acquisition");
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(imageBicForTest, p2.getUsedNeoBic(), 0);
        assertEquals(imageBicForTest, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedNeoBic(), 0);
    }

    /**
     * Retract neo acq.
     */
    @Test
    public void retractNeoAcq() throws Exception
    {
        System.out.println("\n\n\n\n running test : retractNeoAcq");
        double imageBicForTest = 1;
        double maxNeo = 11;
        double maxBic = 100;
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        // set to all partners max bic and max neo declared above
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            Partner p = allPartners.get(i);
            p.setMaxNEOBicAvailable(maxNeo);
            p.setMaxBICAvailable(maxBic);
            System.out.println("partner in for : " + p);
        }

        Partner partnerAssociatedToAcq = this.droolsInstance.receivePartnerWithId("partner_2", this.sessionId, this.currentKieSession);
        System.out.println("partner : " + partnerAssociatedToAcq);
        ArrayList<String> partnersAssociatedId = new ArrayList<>();
        partnersAssociatedId.add(partnerAssociatedToAcq.getPartnerId());

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerAssociatedToAcq.getPartnerId());
        userInfoList.add(userInfo1);

        DTO dto1 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:01:00", "left", "SAT_1");
        dto1.setImageBIC(imageBicForTest);
        dto1.setNeoAvailable(true);
        dto1.setUserInfo(userInfoList);

        double updatedNeoBic = partnerAssociatedToAcq.getUsedNeoBic() + (imageBicForTest);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        assertEquals(updatedNeoBic, partnerAssociatedToAcq.getUsedNeoBic(), 0);
        assertEquals(updatedNeoBic, partnerAssociatedToAcq.getUsedNeoBic(), 0);

        System.out.println("used neo updated : " + partnerAssociatedToAcq.getUsedNeoBic());
        System.out.println("used bic updated : " + partnerAssociatedToAcq.getUsedBIC());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        System.out.println("max bic updated after  retract dto2:" + partnerAssociatedToAcq.getUsedNeoBic());
        System.out.println("max bic updated after  retract dto2: " + partnerAssociatedToAcq.getUsedBIC());
        assertEquals(0, partnerAssociatedToAcq.getUsedBIC(), 0);
        assertEquals(0, partnerAssociatedToAcq.getUsedNeoBic(), 0);

    }

    /**
     * S test insert equivalent dto LMP.
     *
     * @throws Exception
     *             the exception
     */
    /*
     * @Test public void R_testInsertEquivalentDto_Di2s() throws Exception {
     * System.out.
     * println("\n\n\n\n running test : R_testInsertEquivalentDto_Di2s");
     * boolean isVuOrLmp = false; du.setUpDrools(sessionId, droolsParams,
     * droolsInstance, currentKieSession); droolsInstance =
     * du.setUpSession(sessionId, droolsParams, droolsInstance,
     * currentKieSession, isVuOrLmp);
     *
     * DTO dtoMaster = du.createSingleDto("17/01/2018 15:55:00",
     * "17/01/2018 16:00:00", "left", "SAT_1"); DTO dtoSlave =
     * du.createSingleDto("10/10/2017 16:02:00", "10/10/2017 16:03:00", "left",
     * "SAT_1"); List<DTO> dtoInEquivDto = new ArrayList<DTO>();
     * dtoInEquivDto.add(dtoMaster); dtoInEquivDto.add(dtoSlave);
     *
     * EquivalentDTO equivDto = new EquivalentDTO("equivDto",
     * dtoMaster.getStartTime(), dtoSlave.getEndTime());
     * equivDto.setAllDtoInEquivalentDto(dtoInEquivDto);
     * System.out.println("inserting an equivalent dto "); boolean insertOk =
     * droolsInstance.insertEquivalentDto(equivDto, currentKieSession);
     * rejectedElements = droolsInstance.receiveDtoRejected(sessionId,
     * currentKieSession); assertFalse(insertOk); assertEquals(2,
     * rejectedElements.size()); System.out.println("rejected elements : " +
     * rejectedElements); }
     *
     */
    @Test
    public void S_testInsertEquivalentDto_LMP() throws Exception
    {
        System.out.println("\n\n\n\n running test : S_testInsertEquivalentDto_LMP");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        long extraCostTheatre = 3;
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allPartners.get(0).getPartnerId());
        UserInfo userInfo2 = new UserInfo(allPartners.get(1).getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        System.out.println("all partners : " + allPartners);
        DTO dtoMaster = this.du.createSingleDto("17/01/2018 15:55:00", "17/01/2018 16:00:00", "left", "SAT_1");
        dtoMaster.setImageBIC(20);
        dtoMaster.setUserInfo(userInfoList);

        DTO dtoSlave = this.du.createSingleDto("10/10/2017 16:02:00", "10/10/2017 16:03:00", "left", "SAT_1");
        dtoSlave.setImageBIC(30);
        dtoSlave.setUserInfo(userInfoList);

        List<DTO> dtoInEquivDto = new ArrayList<>();
        dtoInEquivDto.add(dtoMaster);
        dtoInEquivDto.add(dtoSlave);

        EquivalentDTO equivDto = new EquivalentDTO("equivDto", dtoMaster.getStartTime(), dtoSlave.getEndTime(), extraCostTheatre);
        equivDto.setAllDtoInEquivalentDto(dtoInEquivDto);
        System.out.println("inserting an equivalent dto ");
    }

    /**
     * Neo bic not available for all partners.
     */
    @Test
    public void NeoBicNotAvailableForAllPartners() throws Exception
    {
        System.out.println("\n\n\n\n running test : NeoBicNotAvailableForAllPartners");
        double imageBicForTest = 160;
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        List<String> arIdForPartner = new ArrayList<>();
        arIdForPartner.add("AR-001");
        Map<String, Partner> allPartners = this.droolsInstance.receiveAllPartnersAsMap(this.sessionId, this.currentKieSession);
        double maxBicP1 = 100;
        double maxNeoP1 = 10;
        Partner p1 = allPartners.get("Partner_1");
        p1.setMaxBICAvailable(maxBicP1);
        p1.setMaxNEOBicAvailable(maxNeoP1);
        System.out.println("GET MAX NEO P1 : " + p1.getMaxNEOBicAvailable());
        p1.setArIdForPartner(arIdForPartner);

        double maxBicP2 = 180;
        double maxNeoP2 = 30;
        Partner p2 = allPartners.get("Partner_2");
        p2.setMaxBICAvailable(maxBicP2);
        p2.setMaxNEOBicAvailable(maxNeoP2);
        System.out.println("GET MAX NEO P2 : " + p2.getMaxNEOBicAvailable());
        p2.setArIdForPartner(arIdForPartner);

        double maxBicP3 = 180;
        double maxNeoP3 = 20;
        Partner p3 = allPartners.get("Partner_3");
        p3.setMaxBICAvailable(maxBicP3);
        p3.setMaxNEOBicAvailable(maxNeoP3);
        System.out.println("GET MAX NEO P3 : " + p3.getMaxNEOBicAvailable());
        p3.setArIdForPartner(arIdForPartner);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(p1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(p2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        DTO dto = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:01:00", "right", "SAT_1");
        dto.setImageBIC(imageBicForTest);
        dto.setNeoAvailable(true);
        dto.setUserInfo(userInfoList);
        dto.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("REJECTED : " + this.rejectedElements);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), this.rejectedElements, ReasonOfReject.bicNotAvailable);
        assertTrue(found);

        System.out.println("GET MAX NEO P1 : " + p1.getMaxNEOBicAvailable());
        System.out.println("GET MAX NEO P2 : " + p2.getMaxNEOBicAvailable());
        System.out.println("GET MAX NEO P3 : " + p3.getMaxNEOBicAvailable());

        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);
        assertEquals(0, p3.getUsedNeoBic(), 0);
    }

    /**
     * Retract acq before bic rule.
     */
    @Test
    public void retractAcqBeforeBicRule() throws Exception
    {
        System.out.println("\n\n\n\n running test : retractAcqBeforeBicRule");
        double imageBicForTest = 160;
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        List<String> arIdForPartner = new ArrayList<>();
        arIdForPartner.add("AR-001");
        Map<String, Partner> allPartners = this.droolsInstance.receiveAllPartnersAsMap(this.sessionId, this.currentKieSession);
        double maxBicP1 = 100;
        double maxNeoP1 = 10;
        Partner p1 = allPartners.get("Partner_1");
        p1.setMaxBICAvailable(maxBicP1);
        p1.setMaxNEOBicAvailable(maxNeoP1);
        System.out.println("GET MAX NEO P1 : " + p1.getMaxNEOBicAvailable());
        p1.setArIdForPartner(arIdForPartner);

        double maxBicP2 = 180;
        double maxNeoP2 = 30;
        Partner p2 = allPartners.get("Partner_2");
        p2.setMaxBICAvailable(maxBicP2);
        p2.setMaxNEOBicAvailable(maxNeoP2);
        System.out.println("GET MAX NEO P2 : " + p2.getMaxNEOBicAvailable());
        p2.setArIdForPartner(arIdForPartner);

        double maxBicP3 = 180;
        double maxNeoP3 = 20;
        Partner p3 = allPartners.get("Partner_3");
        p3.setMaxBICAvailable(maxBicP3);
        p3.setMaxNEOBicAvailable(maxNeoP3);
        System.out.println("GET MAX NEO P3 : " + p3.getMaxNEOBicAvailable());
        p3.setArIdForPartner(arIdForPartner);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(p1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(p2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        DTO dto = this.du.createSingleDto("11/10/2017 09:00:00", "11/10/2017 09:05:00", "left", "SAT_1");
        dto.setImageBIC(imageBicForTest);
        dto.setNeoAvailable(true);
        dto.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("REJECTED : " + this.rejectedElements);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), this.rejectedElements, ReasonOfReject.outsideMHDTO);
        assertTrue(found);

        System.out.println("GET MAX NEO P1 : " + p1.getMaxNEOBicAvailable());
        System.out.println("GET MAX NEO P2 : " + p2.getMaxNEOBicAvailable());
        System.out.println("GET MAX NEO P3 : " + p3.getMaxNEOBicAvailable());

        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p2.getUsedNeoBic(), 0);
        assertEquals(0, p3.getUsedNeoBic(), 0);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedBIC(), 0);
        assertEquals(0, p3.getUsedBIC(), 0);
    }

    /**
     * L test decrement ar I D associated to partner.
     */
    @Test
    public void L_test_decrement_arID_associated_to_Partner() throws Exception
    {
        System.out.println("\n\n\n\n running test : L_test_decrement_arID_associated_to_Partner");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxDailyBicForPartner = 200;
        double maxPercLoanAvailable = 30;
        List<String> arIdForPartner1 = new ArrayList<>();
        arIdForPartner1.add("100_PR-ITA-001-HP_AR-001_");

        List<String> arIdForPartner2 = new ArrayList<>();
        arIdForPartner2.add("100_PR-ITA-001-HP_AR-001_");
        arIdForPartner2.add("100_PR-ITA-001-HP_AR-002_");

        List<String> arIdForPartner3 = new ArrayList<>();
        arIdForPartner3.add("100_PR-ITA-001-HP_AR-003_");

        Partner p1 = new Partner("partner_1", null, maxDailyBicForPartner, maxPercLoanAvailable);
        p1.setArIdForPartner(arIdForPartner1);
        Partner p2 = new Partner("partner_2", null, maxDailyBicForPartner, maxPercLoanAvailable);
        p2.setArIdForPartner(arIdForPartner2);
        Partner p3 = new Partner("partner_3", null, maxDailyBicForPartner, maxPercLoanAvailable);
        p3.setArIdForPartner(arIdForPartner3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(p1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(p2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        Acquisition acq = this.du.createParametricAcquisition("100_PR-ITA-001-HP_AR-001_DTO1", "08/10/2017 03:00:00", "08/10/2017 03:05:00", "left", "SAT_2");
        acq.setImageBIC(100);
        acq.setNeo(true);
        acq.setUserInfo(userInfoList);
        this.bicUtils.checkIfContainsArId(acq, p1, DroolsParameters.getSplitChar());
        this.bicUtils.checkIfContainsArId(acq, p2, DroolsParameters.getSplitChar());
        this.bicUtils.checkIfContainsArId(acq, p3, DroolsParameters.getSplitChar());
        assertEquals(0, p1.getArIdForPartner().size());
        assertEquals(1, p2.getArIdForPartner().size());
        assertEquals(1, p3.getArIdForPartner().size());
    }

    /**
     * G test bic loan and retract both partner with valid bic neo.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void G_Test_Bic_Loan_And_Retract_both_partner_with_valid_bic_neo() throws ConfigurationException, Exception
    {
        System.out.println("Running test : G_Test_Bic_Loan_And_Retract_both_partner_with_valid_bic \n\n");

        // initialize drools session
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxBicForTest = 50;

        // receive all partners and set the max bic available
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest1 = allPartners.get(1);
        partnerForTest1.setMaxBICAvailable(40);
        partnerForTest1.setMaxNEOBicAvailable(60);

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest2 = allPartners.get(2);
        partnerForTest2.setMaxBICAvailable(32);
        partnerForTest2.setMaxNEOBicAvailable(60);

        System.out.println("partner1 choosen for test : " + partnerForTest1);
        System.out.println("partner2 choosen for test : " + partnerForTest2);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerForTest1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(partnerForTest2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        // creating a dto related to the two partners
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "right", "SAT_1");
        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(60);
        dto1.setNeoAvailable(true);
        dto1.setPrType(PRType.PP);

        // inserting the dto into the Drools session
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("for partner1 :" + partnerForTest1);
        System.out.println("for partner1 :" + partnerForTest2);

        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println("acq inserted in drools : " + allAcq);
        assertTrue(partnerForTest1.getLoanList().isEmpty());
        assertTrue(partnerForTest1.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(partnerForTest2.getLoanList().isEmpty());
        assertTrue(partnerForTest2.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(allAcq.get(0).getUserInfo().size() == 2);
        assertEquals(dto1.getImageBIC() / allAcq.get(0).getUserInfo().size(), partnerForTest1.getUsedBIC(), 0);
        assertEquals(dto1.getImageBIC() / allAcq.get(0).getUserInfo().size(), partnerForTest2.getUsedBIC(), 0);

        assertEquals(dto1.getImageBIC() / allAcq.get(0).getUserInfo().size(), partnerForTest1.getUsedNeoBic(), 0);
        assertEquals(dto1.getImageBIC() / allAcq.get(0).getUserInfo().size(), partnerForTest2.getUsedNeoBic(), 0);

        // retract dto with loan

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        for (int i = 0; i < allPartners.size(); i++)
        {
            System.out.println("extracted partner : " + allPartners.get(i));
            if (i == 1)
            {
                assertEquals(40, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            else if (i == 2)
            {
                assertEquals(32, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            System.out.println("partner : " + allPartners.get(i));
            System.out.println("index :" + i);
            assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            assertEquals(0, allPartners.get(i).getUsedNeoBic(), 0);
            assertEquals(0, allPartners.get(i).getLoanList().size());
            assertEquals(0, allPartners.get(i).getGivenLoan().size());
        }

    }

    /**
     * G test bic loan and retract both partner with valid bic.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void G_Test_Bic_Loan_And_Retract_both_partner_with_valid_bic() throws ConfigurationException, Exception
    {
        System.out.println("Running test : G_Test_Bic_Loan_And_Retract_both_partner_with_valid_bic \n\n");

        // initialize drools session
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxBicForTest = 50;

        // receive all partners and set the max bic available
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest1 = allPartners.get(1);
        partnerForTest1.setMaxBICAvailable(40);
        partnerForTest1.setMaxNEOBicAvailable(20);

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest2 = allPartners.get(2);
        partnerForTest2.setMaxBICAvailable(32);
        partnerForTest2.setMaxNEOBicAvailable(60);

        allPartners.get(0).getBorrowingBic().add(partnerForTest1.getPartnerId());
        allPartners.get(0).getBorrowingBic().add(partnerForTest2.getPartnerId());

        System.out.println("partner1 choosen for test : " + partnerForTest1);
        System.out.println("partner2 choosen for test : " + partnerForTest2);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerForTest1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(partnerForTest2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        // creating a dto related to the two partners
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "right", "SAT_1");
        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(60);
        dto1.setPrType(PRType.PP);
        // inserting the dto into the Drools session
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("for partner1 :" + partnerForTest1);
        System.out.println("for partner1 :" + partnerForTest2);

        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println("acq inserted in drools : " + allAcq);
        assertTrue(partnerForTest1.getLoanList().isEmpty());
        assertTrue(partnerForTest1.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(partnerForTest2.getLoanList().isEmpty());
        assertTrue(partnerForTest2.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(allAcq.get(0).getUserInfo().size() == 2);
        assertEquals(dto1.getImageBIC() / allAcq.get(0).getUserInfo().size(), partnerForTest1.getUsedBIC(), 0);
        assertEquals(dto1.getImageBIC() / allAcq.get(0).getUserInfo().size(), partnerForTest2.getUsedBIC(), 0);

        // retract dto with loan

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        for (int i = 0; i < allPartners.size(); i++)
        {
            System.out.println("extracted partner : " + allPartners.get(i));
            if (i == 1)
            {
                assertEquals(40, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            else if (i == 2)
            {
                assertEquals(32, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            System.out.println("partner : " + allPartners.get(i));
            System.out.println("index :" + i);
            assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            assertEquals(0, allPartners.get(i).getLoanList().size());
            assertEquals(0, allPartners.get(i).getGivenLoan().size());
        }

    }

    /**
     * G test bic loan and retract only a partner with valid bic.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void G_Test_Bic_Loan_And_Retract_only_a_partner_with_valid_bic() throws ConfigurationException, Exception
    {
        System.out.println("Running test : G_Test_Bic_Loan_And_Retract_only_a_partner_with_valid_bic \n\n");

        // initialize drools session
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxBicForTest = 50;

        // receive all partners and set the max bic available
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }

        allPartners.get(0).getBorrowingBic().add(allPartners.get(1).getPartnerId());
        allPartners.get(3).getBorrowingBic().add(allPartners.get(1).getPartnerId());

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest1 = allPartners.get(1);
        partnerForTest1.setMaxBICAvailable(40);
        partnerForTest1.setMaxNEOBicAvailable(20);

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest2 = allPartners.get(2);
        partnerForTest2.setMaxBICAvailable(20);
        partnerForTest2.setMaxNEOBicAvailable(60);

        System.out.println("partner 2 :" + partnerForTest2);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerForTest1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(partnerForTest2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        // creating a dto related to the two partners
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");
        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(60);
        dto1.setPrType(PRType.PP);

        // inserting the dto into the Drools session
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("for partner1 :" + partnerForTest1);
        System.out.println("for partner2 :" + partnerForTest2);

        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println("acq inserted in drools : " + allAcq);

        assertEquals(1, allAcq.get(0).getUserInfo().size());

        System.out.println("partner 1 : " + partnerForTest1);
        System.out.println("partner 2 : " + partnerForTest2);

        assertFalse(partnerForTest1.getLoanList().isEmpty());
        assertTrue(partnerForTest1.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(partnerForTest2.getLoanList().isEmpty());
        assertFalse(partnerForTest2.getAcqPerformed().contains(dto1.getDtoId()));

        assertEquals(((dto1.getImageBIC()) - partnerForTest1.getTotalLoan()), partnerForTest1.getUsedBIC(), 0);
        assertEquals(0, partnerForTest2.getUsedBIC(), 0);

        // retract dto with loan

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        for (int i = 0; i < allPartners.size(); i++)
        {
            System.out.println("extracted partner : " + allPartners.get(i));
            if (i == 1)
            {
                assertEquals(40, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            else if (i == 2)
            {
                assertEquals(20, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            System.out.println("partner : " + allPartners.get(i));
            System.out.println("index :" + i);
            assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            assertEquals(0, allPartners.get(i).getLoanList().size());
            assertEquals(0, allPartners.get(i).getGivenLoan().size());
        }

    }

    /**
     * G test bic before rule bic.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void G_Test_Bic_before_rule_bic() throws ConfigurationException, Exception
    {
        System.out.println("Running test : G_Test_Bic_before_rule_bic \n\n");
        List<String> arListId = new ArrayList<>();
        arListId.add("arIdForTest");

        // initialize drools session
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxBicForTest = 50;

        // receive all partners and set the max bic available
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest1 = allPartners.get(1);
        partnerForTest1.setMaxBICAvailable(40);
        partnerForTest1.setMaxNEOBicAvailable(20);
        partnerForTest1.setArIdForPartner(arListId);

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest2 = allPartners.get(2);
        partnerForTest2.setMaxBICAvailable(40);
        partnerForTest2.setMaxNEOBicAvailable(60);
        partnerForTest2.setArIdForPartner(arListId);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerForTest1.getPartnerId());
        UserInfo userInfo2 = new UserInfo(partnerForTest2.getPartnerId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        System.out.println("partner1 choosen for test : " + partnerForTest1);
        System.out.println("partner2 choosen for test : " + partnerForTest2);

        // creating a dto related to the two partners
        DTO dto1 = this.du.createSingleDto("10/1/2017 15:55:00", "10/11/2017 15:56:00", "left", "SAT_1");
        dto1.setUserInfo(userInfoList);
        dto1.setArID("arIdForTest");
        dto1.setImageBIC(60);
        dto1.setNeoAvailable(true);
        // inserting the dto into the Drools session
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        System.out.println("for partner1 :" + partnerForTest1);
        System.out.println("for partner1 :" + partnerForTest2);

        Map<String, Acquisition> allAcq = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("acq inserted in drools : " + allAcq);

        assertTrue(allAcq.get(dto1.getDtoId()).getUserInfo().size() == 2);

        assertTrue(partnerForTest1.getLoanList().isEmpty());
        assertFalse(partnerForTest1.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(partnerForTest2.getLoanList().isEmpty());
        assertFalse(partnerForTest2.getAcqPerformed().contains(dto1.getDtoId()));

        assertEquals(0, partnerForTest1.getUsedBIC(), 0);
        assertEquals(0, partnerForTest2.getUsedBIC(), 0);

        // retract dto with loan

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        for (int i = 0; i < allPartners.size(); i++)
        {
            assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            assertEquals(0, allPartners.get(i).getLoanList().size());
            assertEquals(0, allPartners.get(i).getGivenLoan().size());
        }

    }

    /**
     * G test bic loan and retract only a partner with valid bic neo.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void G_Test_Bic_Loan_And_Retract_only_a_partner_with_valid_bic_neo() throws ConfigurationException, Exception
    {
        System.out.println("Running test : G_Test_Bic_Loan_And_Retract_only_a_partner_with_valid_bic_neo \n\n");
        List<String> arListId = new ArrayList<>();
        arListId.add("arIdForTest");

        // initialize drools session
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        double maxBicForTest = 50;

        // receive all partners and set the max bic available
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest1 = allPartners.get(1);
        partnerForTest1.setMaxBICAvailable(40);
        partnerForTest1.setMaxNEOBicAvailable(20);
        partnerForTest1.setArIdForPartner(arListId);

        // set max neo and max bic to the first chosen partner
        Partner partnerForTest2 = allPartners.get(2);
        partnerForTest2.setMaxBICAvailable(80);
        partnerForTest2.setMaxNEOBicAvailable(80);
        partnerForTest2.setArIdForPartner(arListId);

        // creating an array with the two partners involved
        List<String> partnersAssociated = new ArrayList<>();
        partnersAssociated.add(partnerForTest1.getPartnerId());
        partnersAssociated.add(partnerForTest2.getPartnerId());

        System.out.println("partner1 choosen for test : " + partnerForTest1);
        System.out.println("partner2 choosen for test : " + partnerForTest2);

        // creating a dto related to the two partners
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", "SAT_1");

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, partnerForTest1.getPartnerId(), "ugsId2");
        UserInfo userInfo2 = new UserInfo(null, false, partnerForTest2.getPartnerId(), "ugsId2");
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        dto1.setArID("arIdForTest");
        dto1.setImageBIC(60);
        dto1.setNeoAvailable(true);
        dto1.setPrType(PRType.PP);

        // inserting the dto into the Drools session
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("for partner1 :" + partnerForTest1);
        System.out.println("for partner1 :" + partnerForTest2);

        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println("acq inserted in drools : " + allAcq);

        assertTrue(allAcq.get(0).getUserInfo().size() == 1);

        assertTrue(partnerForTest1.getLoanList().isEmpty());
        assertFalse(partnerForTest1.getAcqPerformed().contains(dto1.getDtoId()));

        assertTrue(partnerForTest2.getLoanList().isEmpty());
        assertTrue(partnerForTest2.getAcqPerformed().contains(dto1.getDtoId()));

        assertEquals(0, partnerForTest1.getUsedBIC(), 0);
        assertEquals(dto1.getImageBIC(), partnerForTest2.getUsedBIC(), 0);

        // retract dto with loan

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        for (int i = 0; i < allPartners.size(); i++)
        {
            System.out.println("extracted partner : " + allPartners.get(i));
            if (i == 1)
            {
                assertEquals(40, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            else if (i == 2)
            {
                assertEquals(80, allPartners.get(i).getMaxBICAvailable(), 0);
            }
            System.out.println("partner : " + allPartners.get(i));
            System.out.println("index :" + i);
            assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            assertEquals(0, allPartners.get(i).getLoanList().size());
            assertEquals(0, allPartners.get(i).getGivenLoan().size());
        }

    }

    /**
     * G test check bic retract before bic rule.
     *
     * @throws ConfigurationException
     *             the configuration exception
     */
    @Test
    public void G_Test_checkBicRetractBeforeBicRule() throws ConfigurationException, Exception
    {
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running test : G_Test_checkBicRetractBeforeBicRule \n\n");
        double maxBicForTest = 50;
        List<Partner> allPartners = this.droolsInstance.receiveAllPartners(this.sessionId, this.currentKieSession);
        for (int i = 0; i < allPartners.size(); i++)
        {
            allPartners.get(i).setMaxBICAvailable(maxBicForTest);
        }

        Partner partnerForTest = allPartners.get(1);
        System.out.println("partner choosen for test : " + partnerForTest);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(partnerForTest.getPartnerId());
        userInfoList.add(userInfo1);

        DTO dto1 = this.du.createSingleDto("20/10/2017 15:55:00", "20/10/2017 15:56:00", "left", "SAT_1");
        dto1.setUserInfo(userInfoList);
        dto1.setImageBIC(70);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + this.rejectedElements);
        assertFalse(accepted);

        System.out.println("accepted ? " + accepted);

        for (int i = 0; i < allPartners.size(); i++)
        {
            System.out.println("extracted partner : " + allPartners.get(i));
            assertEquals(maxBicForTest, allPartners.get(i).getMaxBICAvailable(), 0);
            System.out.println("partner : " + allPartners.get(i));
            System.out.println("index :" + i);
            assertEquals(0, allPartners.get(i).getUsedBIC(), 0);
            assertEquals(0, allPartners.get(i).getLoanList().size());
            assertEquals(0, allPartners.get(i).getGivenLoan().size());
        }
    }

}
