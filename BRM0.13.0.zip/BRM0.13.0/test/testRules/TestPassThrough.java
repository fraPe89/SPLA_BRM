
/**
*
* MODULE FILE NAME:	TestPassThrough.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		24 nov 2018
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 24 nov 2018          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * @author fpedrola
 *
 */
public class TestPassThrough
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestDroolsBicManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.maxBicForTest = 100;
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_single_Pol_Pt_And_Remove() throws Exception
    {
        this.sessionId = "testBicRule_single_Pol_Pt_And_Remove";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();

        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis5, vis6, vis7));

        this.droolsParams.setAllVisibilities(allVisForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
        dto1.setSizeH(330);

        dto1.setImageBIC(3);
        dto1.setPtAvailable(true);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:58:00", "10/10/2017 17:59:00", "right", "SAT_1");
        dto2.setSizeH(830);

        dto2.setImageBIC(3);
        dto2.setPtAvailable(true);
        dto2.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_double_Pol_Pt_NoSpace() throws Exception
    {   
        long PDHTMaxMemory = 0;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, PDHTMaxMemory, this.maxBicForTest, 5);

        this.sessionId = "testBicRule_single_Pol_Pt_And_Remove";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();

        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis5, vis6, vis7));

        this.droolsParams.setAllVisibilities(allVisForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
        dto1.setSizeH(330);
        dto1.setSizeV(330);
        dto1.setPol(Polarization.HH_VV);
        dto1.setImageBIC(3);
        dto1.setPtAvailable(true);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:58:00", "10/10/2017 17:59:00", "right", "SAT_1");
        dto2.setSizeH(830);

        dto2.setImageBIC(3);
        dto2.setPtAvailable(true);
        dto2.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_double_Pol_Pt_And_Remove() throws Exception
    {
        this.sessionId = "testBicRule_single_Pol_Pt_And_Remove";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", p1.getPartnerId(), "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis5 = stubRes.createVisibility(3, "SAT_1", "KOR", p1.getPartnerId(), "10/10/2017 17:50:00", "10/10/2017 18:01:00");
        Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR2", null, "10/10/2017 17:55:00", "10/10/2017 18:06:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis5, vis6, vis7));

        this.droolsParams.setAllVisibilities(allVisForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);



        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
        dto1.setSizeH(330);
        dto1.setSizeV(330);
        dto1.setPol(Polarization.HH_VV);
        dto1.setImageBIC(3);
        dto1.setPtAvailable(true);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:58:00", "10/10/2017 17:59:00", "right", "SAT_1");
        dto2.setSizeH(830);

        dto2.setImageBIC(3);
        dto2.setPtAvailable(true);
        dto2.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
    
    
    
    
    
    /**
     * Test bic rule.
     */
    @Test
    public void testPtInitPlan() throws Exception
    {
        this.sessionId = "testBicRule_single_Pol_Pt_And_Remove";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();

        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(6, "SAT_1", "MAT", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis7.setExternal(true);

        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis5, vis6, vis7));

        this.droolsParams.setAllVisibilities(allVisForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
        dto1.setSizeH(330);

        dto1.setImageBIC(3);
        dto1.setPtAvailable(true);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:58:00", "10/10/2017 17:59:00", "right", "SAT_1");
        dto2.setSizeH(830);

        dto2.setImageBIC(3);
        dto2.setPtAvailable(true);
        dto2.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 17:59:40", "10/10/2017 17:59:50", "right", "SAT_1");
        dto3.setSizeH(830);

        dto3.setImageBIC(3);
        dto3.setPtAvailable(true);
        dto3.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        this.currentKieSession = 1;
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        dto1.setPreviousSession(true);
        dto2.setPreviousSession(true);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void testBicRule_single_Pol_OverlapWithNextChangeLink() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();

        StubResources stubRes = new StubResources();
        Visibility vis1 = stubRes.createVisibility(0, "SAT_1", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:30:00");
        Visibility vis2 = stubRes.createVisibility(1, "SAT_1", "KOR", "owner1d", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = stubRes.createVisibility(2, "SAT_1", "MAT", "owner1d", "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = stubRes.createVisibility(3, "SAT_1", "KIR", null, "10/10/2017 17:59:00", "10/10/2017 18:02:00");
        vis4.setExternal(true);
        Visibility vis5 = stubRes.createVisibility(4, "SAT_2", "KIR", "owner1d", "10/10/2017 06:00:00", "10/10/2017 06:40:00");
        Visibility vis6 = stubRes.createVisibility(5, "SAT_1", "KOR", null, "10/10/2017 17:55:00", "10/10/2017 18:01:00");
        vis6.setExternal(true);
        Visibility vis7 = stubRes.createVisibility(6, "SAT_2", "MAT", "owner1d", "10/10/2017 16:10:00", "10/10/2017 16:57:00");
        List<Visibility> allVisForTest = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4, vis5, vis6, vis7));

        this.droolsParams.setAllVisibilities(allVisForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:10", "right", "SAT_1");
        dto1.setSizeH(330);

        dto1.setImageBIC(3);
        dto1.setPtAvailable(true);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // standard acq

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:57:00", "10/10/2017 17:57:10", "right", "SAT_1");
        dto2.setSizeH(400);

        dto2.setImageBIC(3);
        dto2.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // second pt

        DTO dto3 = this.du.createSingleDto("10/10/2017 17:59:00", "10/10/2017 17:59:50", "right", "SAT_1");
        dto3.setSizeH(400);

        dto3.setImageBIC(3);
        dto3.setPtAvailable(true);
        dto3.setPrType(PRType.PP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allTasksAsList = DroolsUtils.fromTreemapToList(allTasksAccepted);

        for (int i = 0; i < allTasksAsList.size(); i++)
        {
            System.out.println("PREV ACC :" + allTasksAsList.get(i));
        }

        this.sessionId = "sessionInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, allTasksAsList, null, this.sessionId, this.currentKieSession, true);

        // DTO dto4 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017
        // 17:00:10", "left", "SAT_1");
        // dto4.setSizeH(330);
        // dto4.setImageBIC(3);
        // dto4.setPtAvailable(false);
        // dto4.setPrType(PRType.PP);
        //
        // this.droolsInstance.insertDto(this.droolsParams, dto4,
        // this.sessionId, this.currentKieSession);
        //
        // this.droolsInstance.retractSingleAcq(this.droolsParams,
        // dto2.getDtoId(), this.sessionId, this.currentKieSession,
        // ReasonOfReject.acqInconsistentWithPaw);
    }
}
