/**
*
* MODULE FILE NAME:	DownloadRules.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		01 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 01 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.DroolsQueries;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class DownloadRules.
 *
 * @author francesca
 */
public class TestDownloadRules
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    private StubResources stub = new StubResources();

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "DownloadScenario";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Download test.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void downloadTest_PDHT() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        this.droolsParams.getAllPDHT().get(0).setFreeMemory(50000);
        this.droolsParams.getAllPDHT().get(0).setCapacity(null);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : " + allTasks.size());
        // assertEquals(4, allTasks.size());

    }

    /**
     * Download test.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void downloadTest_PDHT_noSpace() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllPDHT().get(0).setFreeMemory(0);
        this.droolsParams.getAllPDHT().get(0).setCapacity(null);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containReason = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), rejected, ReasonOfReject.noSpaceInPdht);
        assertEquals(true, containReason);
    }

    /**
     * Download test.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void downloadTest_double_pol() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto1.setPol(Polarization.VH);
        dto1.setSizeH(2000);
        dto1.setSizeV(2000);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

    }

    /**
     * Download test.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void downloadTest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:25:00", "10/10/2017 10:25:10", "left", "SAT_2");
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        DroolsOperations.retractSingleAcq(this.droolsParams, dto4.getDtoId(), this.sessionId, this.currentKieSession, null);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        DTO dto6 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 14:20:00", "10/10/2017 14:20:10", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 14:00:00", "10/10/2017 14:00:10", "left", "SAT_2");
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 14:10:00", "10/10/2017 14:10:10", "right", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        Map<String, Acquisition> acqRejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + acqRejected);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        System.out.println("current session : " + this.currentKieSession);
        System.out.println("--------------------------------------------");
        System.out.println(this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1"));

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task SAT : " + elements.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void downloadTest_Partial_initPlan_doublePol() throws Exception
    {
        this.sessionId = "downloadTest_Partial_initPlan_doublePol";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setPol(Polarization.H_V);
        dto1.setSizeV(400);
        dto1.setSizeH(400);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Download> allDwlassoc = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);

        for (int i = 0; i < allDwlassoc.size(); i++)
        {
            System.out.println(allDwlassoc.get(i));
        }
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(400);
        dto2.setSizeH(400);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(400);
        dto3.setSizeH(400);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.filterTasksForMh(allTasks, this.droolsParams);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "downloadTest_Partial_initPlan_doublePol_InitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 19:30:00", "10/10/2017 19:59:00");
        allVis = new ArrayList<>(Arrays.asList(vis2, vis3, vis4));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void downloadTest_Partial_initPlan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void downloadTest_Partial_initPlan_HV_singlePartner() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(4000);
        dto1.setSizeV(4000);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void downloadTest_Partial_initPlan_H_V_singlePartner_totalRetain() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.H_V);
        dto1.setSizeH(4000);
        dto1.setSizeV(4000);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.RETAIN);
        assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.RETAIN);

        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
        assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
    
    @Test
    public void downloadTest_Partial_initPlan_H_V_singlePartner_partialRetainH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00", "10/10/2017 11:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");


        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1000);
        dto1.setSizeV(0);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
        dto2.setPol(Polarization.H_V);
        dto2.setSizeH(4000);
        dto2.setSizeV(1900);

        dto2.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
        assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.RETAIN);

        droolsInstance.writeToFile(this.sessionId, this.currentKieSession, droolsParams);
        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(1,allDwlForAcq.size());
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_1");
        dto3.setPol(Polarization.H_V);
        dto3.setSizeH(4000);
        dto3.setSizeV(1900);

        dto3.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto3.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(1,allDwlForAcq.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    
    @Test
    public void downloadTest_Partial_initPlan_H_V_singlePartner_partialRetainV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00.800", "10/10/2017 07:16:00.800");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:10:00.800", "10/10/2017 07:10:50.800", "right", "SAT_1");
        dto1.setPol(Polarization.H_V);
        dto1.setSizeH(4000);
        dto1.setSizeV(4000);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:50:00.800", "10/10/2017 06:50:50.800", "right", "SAT_1");
        dto2.setPol(Polarization.H_V);
        dto2.setSizeH(4000);
        dto2.setSizeV(4000);

        dto2.setPreferredVis(allVisId);
        
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);


        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
    
    @Test
    public void downloadTest_Partial_initPlan_H_V_singlePartner_prova() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00.800", "10/10/2017 07:16:00.800");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1,vis2,vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:10:00.800", "10/10/2017 07:10:50.800", "right", "SAT_1");
        dto1.setPol(Polarization.H_V);
        dto1.setSizeH(4000);
        dto1.setSizeV(4000);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:50:00.800", "10/10/2017 06:50:50.800", "right", "SAT_1");
        dto2.setPol(Polarization.H_V);
        dto2.setSizeH(4000);
        dto2.setSizeV(4000);

        dto2.setPreferredVis(allVisId);
        
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }
    
    @Test 
    public void testPriority ()
    {
        TreeMap<String, Integer> priority = new TreeMap<String,Integer>();
        String p1 = "0_2_0000000015_61";
        String p2 = "-1_2_0000000015_61";
        String p3 = "0_2_0000000011_61";
        String p4 = "3_2_0000000015_61";
        String p5 = "2_2_0000000015_62";
        priority.put(p1, 0);
        priority.put(p2, 1);
        priority.put(p3, 2);
        priority.put(p1, 3);
        priority.put(p4, 4);
        priority.put(p5, 5);
        
        System.out.println(priority);

    }
    @Test
    public void downloadTest_downloadPriority() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00", "10/10/2017 11:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");


        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1000);
        dto1.setSizeV(0);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
        dto2.setPol(Polarization.V_H);
        dto2.setSizeH(4000);
        dto2.setSizeV(1900);

        dto2.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(DownlinkStrategy.RETAIN,allDwlForAcq.get(0).getPacketStoreStrategy());
        assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(1).getPacketStoreStrategy());
        ResourceFunctions resFunc =  (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
        PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
        System.out.println(pdhtSat1);
        System.out.println(pdhtSat2);

        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPDHT().clear();
        
   
       this.droolsParams.getAllPDHT().add(pdhtSat1);
       this.droolsParams.getAllPDHT().add(pdhtSat2);

       this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
       
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(1,allDwlForAcq.size());
        assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(0).getPacketStoreStrategy());

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_1");
        dto3.setPol(Polarization.H_V);
        dto3.setSizeH(4000);
        dto3.setSizeV(1900);

        dto3.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto3.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(1,allDwlForAcq.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    
    
    @Test
    public void downloadTest_Partial_initPlan_H_V_singlePartner_totalDwl_HV() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00", "10/10/2017 11:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");


        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1000);
        dto1.setSizeV(0);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
        dto2.setPol(Polarization.HV);
        dto2.setSizeH(552);
        dto2.setSizeV(552);

        dto2.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(0).getPacketStoreStrategy());
        assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(1).getPacketStoreStrategy());
        ResourceFunctions resFunc =  (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
        PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
        System.out.println(pdhtSat1);
        System.out.println(pdhtSat2);

        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPDHT().clear();
        
   
       this.droolsParams.getAllPDHT().add(pdhtSat1);
       this.droolsParams.getAllPDHT().add(pdhtSat2);

       this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
       
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(0,allDwlForAcq.size());
       // assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(0).getPacketStoreStrategy());

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:45:00", "10/10/2017 18:45:10", "right", "SAT_1");
        dto3.setPol(Polarization.H_V);
        dto3.setSizeH(4000);
        dto3.setSizeV(1900);

        dto3.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto3.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(0,allDwlForAcq.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
    
    
    @Test
    public void downloadTest_Partial_initPlan_V_H_singlePartner_partialRetain() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00", "10/10/2017 11:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");


        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1000);
        dto1.setSizeV(0);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
        dto2.setPol(Polarization.V_H);
        dto2.setSizeH(4000);
        dto2.setSizeV(1900);

        dto2.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(DownlinkStrategy.RETAIN,allDwlForAcq.get(0).getPacketStoreStrategy());
        assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(1).getPacketStoreStrategy());
        ResourceFunctions resFunc =  (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
        PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
        System.out.println(pdhtSat1);
        System.out.println(pdhtSat2);

        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPDHT().clear();
        
   
       this.droolsParams.getAllPDHT().add(pdhtSat1);
       this.droolsParams.getAllPDHT().add(pdhtSat2);

       this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
       
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(1,allDwlForAcq.size());
        assertEquals(DownlinkStrategy.DELETE,allDwlForAcq.get(0).getPacketStoreStrategy());

        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(1,allDwlForAcq.size());
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    
    
    
    
    @Test
    public void downloadTest_Partial_initPlan_V_H_singlePartner_2() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 11:10:00", "10/10/2017 11:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");


        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1000);
        dto1.setSizeV(0);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 10:45:00", "10/10/2017 10:45:10", "right", "SAT_1");
        dto2.setPol(Polarization.HH_VV);
        dto2.setSizeH(552);
        dto2.setSizeV(552);

        dto2.setPreferredVis(allVisId);
        userInfoList.add(userInfo1);
        dto2.setUserInfo(userInfoList);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        ResourceFunctions resFunc =  (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        
        PDHT pdhtSat1 = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();
        PDHT pdhtSat2 = resFunc.getPDHTTemporalFunctionSat2().lastEntry().getValue().getPdht();
        System.out.println(pdhtSat1);
        System.out.println(pdhtSat2);

        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPDHT().clear();
        
   
       this.droolsParams.getAllPDHT().add(pdhtSat1);
       this.droolsParams.getAllPDHT().add(pdhtSat2);

       this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
       
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }

        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto2.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    
    
    
    @Test
    public void downloadTest_Partial_initPlan_H_V_singlePartner_totalDownloaded() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:32:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 18:00:00", "10/10/2017 18:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.H_V);
        dto1.setSizeH(4000);
        dto1.setSizeV(4000);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
                
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(2,allDwlForAcq.size());
        assertEquals(allDwlForAcq.get(0).getPacketStoreStrategy(), DownlinkStrategy.DELETE);
        assertEquals(allDwlForAcq.get(1).getPacketStoreStrategy(), DownlinkStrategy.DELETE);

        System.out.println(allDwlForAcq);
        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        
        allDwlForAcq = this.droolsInstance.receiveAllDownloadAssociatedToDtoForMh(dto1.getDtoId(), this.sessionId,  this.currentKieSession, droolsParams);
        
        for(int i=0;i<allDwlForAcq.size();i++)
        {
            System.out.println(allDwlForAcq.get(i));

        }
        assertEquals(0,allDwlForAcq.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }


    @Test
    public void downloadTest_Partial_initPlan_HH_singlePartner() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:16:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);
        dto1.setSizeV(0);

        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        // UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(),
        // p2.getUgsId());
        userInfoList.add(userInfo1);
        // userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "sessionIdInitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void downloadTest_Partial_Time_Performance() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void downloadTest_NoSpaceOnVis_Shift_Latest_noSpace() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:15:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:15:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 13:00:00", "10/10/2017 13:15:00");

        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId(), vis4.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        System.out.println("returned acq : " + returnedAcq);
        assertTrue(returnedAcq != null);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(false);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // droolsInstance.retractSingleAcq(droolsParams, dto3.getDtoId(),
        // sessionId, currentKieSession, ReasonOfReject.brmError);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println(priorityQueue);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }
        // droolsInstance.initPlan(droolsParams, allPrevTask, null, sessionId,
        // currentKieSession, false);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println(priorityQueue);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task INITPLAN : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }
    }

    @Test
    public void downloadTest_NoSpaceOnVis_Shift_Latest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:15:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 13:00:00", "10/10/2017 13:15:00");

        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId(), vis4.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        System.out.println("returned acq : " + returnedAcq);
        assertTrue(returnedAcq != null);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(false);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void downloadTest_NoSpaceOnVis_Shift_And_Retract() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:15:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:15:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 13:00:00", "10/10/2017 13:15:00");

        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId(), vis4.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        DroolsQueries dq = new DroolsQueries();

        Acquisition returnedAcq = dq.getAcqWithId(this.sessionId, this.currentKieSession, dto1.getDtoId());
        System.out.println("returned acq : " + returnedAcq);
        assertTrue(returnedAcq != null);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(false);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println(priorityQueue);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }
        // droolsInstance.initPlan(droolsParams, allPrevTask, null, sessionId,
        // currentKieSession, false);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println(priorityQueue);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task INITPLAN : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }
    }

    @Test
    public void downloadTest_useBackUpStation() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p2.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00", "10/10/2017 07:20:00");

        Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(0, "SAT_1", "MAT", p2.getPartnerId(), "10/10/2017 12:00:00", "10/10/2017 12:50:00");

        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.getHpExclusionList().clear();
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3, vis4));
        this.droolsParams.setAllVisibilities(allVis);
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        userInfoList.add(userInfo1);
        dto1.setUserInfo(userInfoList);
        dto1.setBackupVis(allVisId);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setBackupVis(allVisId);

        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setBackupVis(allVisId);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setPriority(-20);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DTO dto4 = this.du.createSingleDto("10/10/2017 07:10:00", "10/10/2017 07:10:10", "right", "SAT_1");
        dto4.setTimePerformance(false);
        dto4.setPreferredVis(allVisId);
        dto4.setUserInfo(userInfoList);
        dto4.setBackupVis(allVisId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeV(0);
        dto4.setPriority(0);
        dto4.setSizeH(100);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println(priorityQueue);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }

        List<Task> fromTreemapToList = DroolsUtils.fromTreemapToList(allTasks);
        Date startMh = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date stopMh = DroolsUtils.createDate("11/10/2017 06:21:00");

        this.droolsParams.getCurrentMH().setStart(startMh);
        this.droolsParams.getCurrentMH().setStop(stopMh);
        Visibility vis5 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 19:10:00", "10/10/2017 19:12:00");
        Visibility vis6 = this.stub.createVisibility(0, "SAT_1", "MAT", null, "10/10/2017 20:00:00", "10/10/2017 20:50:00");
        this.droolsParams.getAllVisibilities().add(vis5);
        this.droolsParams.getAllVisibilities().add(vis6);

        this.droolsInstance.initPlan(this.droolsParams, fromTreemapToList, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void downloadTest_NoSpaceOnVis_Shift_Previous_on_next_vis_1() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00", "10/10/2017 07:20:00");

        Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(0, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis4, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
  
        userInfoList.add(userInfo2);
        dto1.setPrType(PRType.LMP);        //1111507610700000
                                           //1321507610100000
                                           //1031507609320000
                                           //1041507612200000
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        //this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(false);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPrType(PRType.RANKED_ROUTINE);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);   //151507610100000

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setPrType(PRType.VU);  //1_1_3_1507609320000

        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DTO dto4 = this.du.createSingleDto("10/10/2017 07:10:00", "10/10/2017 07:10:10", "right", "SAT_1");
        dto4.setTimePerformance(false);
        dto4.setPreferredVis(allVisId);
        dto4.setUserInfo(userInfoList);
        dto4.setPol(Polarization.HH);
        dto4.setSizeV(0);
        dto4.setPrType(PRType.VU);    //1_1_0_1507612200000

       // dto4.setPriority(0);
        dto4.setSizeH(100);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println("PRIORITY :"+priorityQueue);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }
    }

    @Test
    public void downloadTest_NoSpaceOnVis_Shift_Previous_retainInitPlan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00", "10/10/2017 07:20:00");

        Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis4));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:22:00", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(4000);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DTO dto4 = this.du.createSingleDto("10/10/2017 07:10:00", "10/10/2017 07:10:10", "right", "SAT_1");
        dto4.setTimePerformance(false);
        dto4.setPreferredVis(allVisId);
        dto4.setUserInfo(userInfoList);
        dto4.setPol(Polarization.HH);
        dto4.setSizeV(0);
        dto4.setPriority(0);
        dto4.setSizeH(100);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, PriorityQueue> priorityQueue = resFunc.getDownloadPriorityQueueForSat("SAT_1");
        System.out.println(priorityQueue);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPrevTask = new ArrayList<>();
        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
            allPrevTask.add(elements.getValue());
        }

        List<Task> fromTreemapToList = DroolsUtils.fromTreemapToList(allTasks);
        Date startMh = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date stopMh = DroolsUtils.createDate("11/10/2017 06:21:00");

        System.out.println("DTO 1 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams));

        System.out.println("DTO 2 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto2.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams));

        System.out.println("DTO 3 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto3.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams));

        System.out.println("DTO 4 :" + this.droolsInstance.receiveAllDownloadAssociatedToDto(dto4.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams));

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        // assertEquals(3,
        // this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(),
        // this.sessionId, this.currentKieSession, this.droolsParams).size());
        // assertEquals(5,
        // this.droolsInstance.receiveAllDownloadAssociatedToDto(dto2.getDtoId(),
        // this.sessionId, this.currentKieSession, this.droolsParams).size());
        // assertEquals(4,
        // this.droolsInstance.receiveAllDownloadAssociatedToDto(dto3.getDtoId(),
        // this.sessionId, this.currentKieSession, this.droolsParams).size());
        // assertEquals(2,
        // this.droolsInstance.receiveAllDownloadAssociatedToDto(dto4.getDtoId(),
        // this.sessionId, this.currentKieSession, this.droolsParams).size());
      
        //PDHT lastPDHT = resFunc.getPDHTTemporalFunctionSat1().lastEntry().getValue().getPdht();

        this.droolsParams.getCurrentMH().setStart(startMh);
        this.droolsParams.getCurrentMH().setStop(stopMh);
        Visibility vis5 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 19:10:00", "10/10/2017 19:12:00");
        Visibility vis6 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 20:00:00", "10/10/2017 20:50:00");
        this.droolsParams.getAllVisibilities().add(vis5);
        this.droolsParams.getAllVisibilities().add(vis6);
        this.sessionId = "newSession";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);
        
        this.droolsInstance.initPlan(this.droolsParams, fromTreemapToList, null, this.sessionId, this.currentKieSession, true);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 19:10:00", "10/10/2017 19:10:10", "right", "SAT_1");
        dto5.setTimePerformance(false);
        dto5.setPreferredVis(allVisId);
        dto5.setUserInfo(userInfoList);
        dto5.setPol(Polarization.HH);
        dto5.setSizeV(0);
        dto5.setPriority(0);
        dto5.setSizeH(100);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void downloadTest_NoSpaceOnVis_Shift_Previous_on_next_vis_2() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis4 = this.stub.createVisibility(0, "SAT_1", "KOR2", p2.getPartnerId(), "10/10/2017 07:15:00", "10/10/2017 07:20:00");

        Visibility vis2 = this.stub.createVisibility(0, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(0, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis4, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void downloadTest_NoSpaceOnVis_Plan_partially() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(4000);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void downloadTest_Partial_start_on_own_vis_ends_in_external() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();
        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
    }

    @Test
    public void downloadTest_Partial_start_on_external_ends_in_external() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:50:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        // assertEquals(5, allDwl.size());

        assertEquals(DownlinkStrategy.RETAIN, allDwl.get(0).getPacketStoreStrategy());
        assertEquals(DownlinkStrategy.DELETE, allDwl.get(1).getPacketStoreStrategy());

        assertEquals(true, allDwl.get(0).getUgsOwnerList().contains(p1.getPartnerId()));
        assertEquals(true, allDwl.get(0).getUgsOwnerList().contains(p2.getPartnerId()));

        assertEquals(true, allDwl.get(1).getUgsOwnerList().contains(p2.getPartnerId()));
        assertEquals(true, allDwl.get(1).getUgsOwnerList().contains(p1.getPartnerId()));
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @Test
    public void downloadTest_RankedAfterAnHp() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis0 = this.stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 06:40:00", "10/10/2017 06:51:00");
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:13:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis0, vis1, vis2, vis3));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis0.getAcqStatId(), vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        List<String> allVisAsString = new ArrayList<>(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        dto1.setPrType(PRType.HP);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAsString, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAsString, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        // assertEquals(5, allDwl.size());

        // assertEquals(DownlinkStrategy.RETAIN,
        // allDwl.get(0).getPacketStoreStrategy());
        // assertEquals(DownlinkStrategy.DELETE,
        // allDwl.get(1).getPacketStoreStrategy());
        //
        // assertEquals(true,
        // allDwl.get(0).getUgsOwnerList().contains(p1.getPartnerId()));
        // assertEquals(true,
        // allDwl.get(0).getUgsOwnerList().contains(p2.getPartnerId()));
        //
        // assertEquals(true,
        // allDwl.get(1).getUgsOwnerList().contains(p1.getPartnerId()));
        // assertEquals(true,
        // allDwl.get(1).getUgsOwnerList().contains(p2.getPartnerId()));
        //
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:30:00", "10/10/2017 06:31:10", "right", "SAT_1");
        dto2.setPreferredVis(allVisAdId);
        dto2.setUserInfo(userInfoList);
        dto2.setPrType(PRType.RANKED_ROUTINE);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 06:21:10", "10/10/2017 06:22:10", "right", "SAT_1");
        dto3.setPreferredVis(allVisAdId);
        dto3.setUserInfo(userInfoList);
        dto3.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        // assertEquals(5, allDwl.size());
        //
        // assertEquals(DownlinkStrategy.RETAIN,
        // allDwl.get(0).getPacketStoreStrategy());
        // assertEquals(DownlinkStrategy.DELETE,
        // allDwl.get(1).getPacketStoreStrategy());
        //
        // assertEquals(true,
        // allDwl.get(0).getUgsOwnerList().contains(p1.getPartnerId()));
        // assertEquals(true,
        // allDwl.get(0).getUgsOwnerList().contains(p2.getPartnerId()));
        //
        // assertEquals(true,
        // allDwl.get(1).getUgsOwnerList().contains(p1.getPartnerId()));
        // assertEquals(true,
        // allDwl.get(1).getUgsOwnerList().contains(p2.getPartnerId()));
        //
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @Test
    public void downloadTest_download_not_overlap_paw_retain_sameMh() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:05:00", "10/10/2017 08:13:00");

        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:08:00", PAWType.GENERIC);
        List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.setAllPAWS(allPaws);

        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        dto1.setPol(Polarization.HV);
        dto1.setSizeH(200);
        dto1.setSizeV(200);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAdId, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAdId, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        assertEquals(3, allDwl.size());

        assertEquals(DownlinkStrategy.DELETE, allDwl.get(0).getPacketStoreStrategy());

        Map<String, Task> previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> previousTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> prevElements : previousTasks.entrySet())
        {
            previousTasksAsList.add(prevElements.getValue());
        }
        this.currentKieSession = 4;

        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 12:05:00", "10/10/2017 12:13:00");
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        assertEquals(4, allDwl.size());
        System.out.println(previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @Test
    public void downloadTest_download_not_overlap_paw_retain_newMh() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();
        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:05:00", "10/10/2017 08:13:00");

        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:08:00", PAWType.GENERIC);
        List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.setAllPAWS(allPaws);

        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        PDHT startPdht = this.droolsParams.getAllPDHT().get(0);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAdId, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAdId, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        assertEquals(2, allDwl.size());

        assertEquals(DownlinkStrategy.RETAIN, allDwl.get(0).getPacketStoreStrategy());

        Map<String, Task> previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> previousTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> prevElements : previousTasks.entrySet())
        {
            previousTasksAsList.add(prevElements.getValue());
        }
        PDHT lastPdht = this.droolsInstance.getPDHTStatus(this.droolsParams.getCurrentMH().getStop(), "SAT_1", this.sessionId, this.currentKieSession);
        System.out.println("last pdht was : " + lastPdht);
        this.currentKieSession = 4;

        Visibility vis2 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 19:05:00", "10/10/2017 19:13:00");
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllPDHT().clear();
        this.droolsParams.getAllPDHT().add(lastPdht);
        this.droolsParams.getAllPDHT().add(startPdht);
        Date mhNewStart = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date mhNewEnd = DroolsUtils.createDate("11/10/2017 06:21:00");
        MissionHorizon newMh = new MissionHorizon(mhNewStart, mhNewEnd);
        this.droolsParams.setCurrentMH(newMh);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, previousTasksAsList, null, this.sessionId, this.currentKieSession, true);
        allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        System.out.println(previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    @Test
    public void downloadTest_download_not_overlap_GPS() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis1 = this.stub.createVisibility(1, "SAT_1", "Pdr", "1100", "10/10/2017 08:05:00", "10/10/2017 08:13:00");

        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1));

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:08:00", PAWType.GENERIC);
        List<PAW> allPaws = new ArrayList<>(Arrays.asList(paw1));

        List<String> allVisAdId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.setAllPAWS(allPaws);

        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisAdId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisAdId, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisAdId, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        List<Download> allDwl = taskPlanned.receiveAllDownloads(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allDwl.size(); i++)
        {
            System.out.println("allDwl : " + allDwl.get(i));
        }

        // assertEquals(1, allDwl.size());

        // assertEquals(DownlinkStrategy.RETAIN,
        // allDwl.get(0).getPacketStoreStrategy());

        Map<String, Task> previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        List<Task> previousTasksAsList = new ArrayList<>();
        for (Map.Entry<String, Task> elements : previousTasks.entrySet())
        {
            previousTasksAsList.add(elements.getValue());
        }

        this.currentKieSession = 4;
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Visibility vis4 = this.stub.createVisibility(2, "SAT_1", "KOR", null, "10/10/2017 12:05:00", "10/10/2017 12:13:00");
        this.droolsParams.getAllVisibilities().add(vis4);

        this.droolsInstance.initPlan(this.droolsParams, previousTasksAsList, null, this.sessionId, this.currentKieSession, false);

        System.out.println(previousTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    /*
     * @Test public void parseTaskReportDifferentFormat() throws ParseException,
     * Exception { sessionId = "parseTaskReportDifferentFormat";
     * this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     *
     * MissionHorizon currentMH = new MissionHorizon();
     * currentMH.setStart(du.createDate("16/09/2016 06:21:00"));
     * currentMH.setStop(du.createDate("16/09/2016 18:21:00"));
     * droolsParams.setCurrentMH(currentMH);
     *
     * droolsParams.getAllPAWS().clear(); this.droolsInstance =
     * this.du.setUpSession(this.sessionId, SessionType.premium,
     * this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
     *
     * double extraCostLeft = 2; droolsParams.setExtraCostLeft(extraCostLeft);
     *
     * String fileString =
     * "� 200_702_1_1_, startTime :2016-09-16 11:42:43.86, endTime :2016-09-16 11:42:51.083, lookSide :Right, sensorMode :STRIPMAP , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
     * +
     * "	 � 100_3258_1_1_, startTime :2016-09-16 17:21:57.374, endTime :2016-09-16 17:22:04.65, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3249_1_1_, startTime :2016-09-16 17:24:51.879, endTime :2016-09-16 17:25:00.138, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3247_1_1_, startTime :2016-09-16 18:08:47.967, endTime :2016-09-16 18:08:55.059, lookSide :Right, sensorMode :QUADPOL , prType : PP, sat :SSAR2 added\n"
     * +
     * "	 � 100_3229_1_1_, startTime :2016-09-16 18:18:50.975, endTime :2016-09-16 18:19:42.008, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3230_1_1_, startTime :2016-09-16 07:13:11.463, endTime :2016-09-16 07:13:27.535, lookSide :Left, sensorMode :SCANSAR_1 , prType : PP, sat :SSAR2 added\n"
     * +
     * "	 � 100_3252_1_1_, startTime :2016-09-16 11:56:33.898, endTime :2016-09-16 11:56:41.108, lookSide :Right, sensorMode :QUADPOL , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3246_1_1_, startTime :2016-09-16 11:50:12.498, endTime :2016-09-16 11:50:43.485, lookSide :Right, sensorMode :SCANSAR_2 , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3244_1_1_, startTime :2016-09-16 11:34:57.855, endTime :2016-09-16 11:35:06.13, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3232_1_1_, startTime :2016-09-16 11:37:59.614, endTime :2016-09-16 11:38:10.319, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3228_1_1_, startTime :2016-09-16 11:53:29.208, endTime :2016-09-16 11:53:36.789, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3256_1_2_, startTime :2016-09-16 11:47:14.494, endTime :2016-09-16 11:47:30.464, lookSide :Right, sensorMode :SCANSAR_1 , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3251_1_1_, startTime :2016-09-16 11:41:08.255, endTime :2016-09-16 11:41:13.669, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3233_1_3_, startTime :2016-09-16 11:44:13.319, endTime :2016-09-16 11:44:20.616, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3224_1_2_, startTime :2016-09-16 13:40:52.081, endTime :2016-09-16 13:41:01.92, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3222_1_1_, startTime :2016-09-16 08:52:26.951, endTime :2016-09-16 08:52:35.046, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3227_1_2_, startTime :2016-09-16 13:42:25.0, endTime :2016-09-16 13:42:31.0, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3226_1_1_, startTime :2016-09-16 07:13:10.876, endTime :2016-09-16 07:13:19.123, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3223_1_2_, startTime :2016-09-16 07:12:25.461, endTime :2016-09-16 07:12:35.539, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3225_4_1_, startTime :2016-09-16 12:04:15.441, endTime :2016-09-16 12:04:24.559, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3225_3_1_, startTime :2016-09-16 08:50:38.601, endTime :2016-09-16 08:50:47.397, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3225_2_1_, startTime :2016-09-16 13:41:09.918, endTime :2016-09-16 13:41:21.084, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3225_1_1_, startTime :2016-09-16 07:13:50.481, endTime :2016-09-16 07:13:59.517, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat :SSAR1 added\n"
     * +
     * "	 � 200_704_1_1_, startTime :2016-09-16 17:20:24.63, endTime :2016-09-16 17:20:40.391, lookSide :Right, sensorMode :SCANSAR_1 , prType : HP, sat :SSAR1 added\n"
     * +
     * "	 � 200_703_1_1_, startTime :2016-09-16 11:45:41.497, endTime :2016-09-16 11:45:57.454, lookSide :Right, sensorMode :SCANSAR_1 , prType : HP, sat :SSAR1 added\n"
     * +
     * "	 � 200_701_1_1_, startTime :2016-09-16 09:39:06.429, endTime :2016-09-16 09:39:11.57, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : HP, sat :SSAR2 added\n"
     * +
     * "	 � 200_697_1_1_, startTime :2016-09-16 13:07:35.891, endTime :2016-09-16 13:07:43.093, lookSide :Left, sensorMode :STRIPMAP , prType : HP, sat :SSAR2 added\n"
     * +
     * "	 � 200_696_1_1_, startTime :2016-09-16 15:25:08.407, endTime :2016-09-16 15:25:15.584, lookSide :Right, sensorMode :STRIPMAP , prType : HP, sat :SSAR1 added\n"
     * +
     * "	 � 200_693_1_2_, startTime :2016-09-16 11:01:59.716, endTime :2016-09-16 11:02:30.296, lookSide :Left, sensorMode :SCANSAR_2 , prType : HP, sat :SSAR2 added\n"
     * +
     * "	 � 200_708_1_3_, startTime :2016-09-16 11:55:05.286, endTime :2016-09-16 11:55:12.717, lookSide :Right, sensorMode :PINGPONG , prType : HP, sat :SSAR1 added\n"
     * +
     * "	 � 200_707_1_2_, startTime :2016-09-16 10:22:02.906, endTime :2016-09-16 10:22:10.085, lookSide :Left, sensorMode :QUADPOL , prType : HP, sat :SSAR1 added\n"
     * +
     * "	 � 100_3243_1_1_, startTime :Fri Sep 16 11:39:48 GMT 2016, endTime :Fri Sep 16 11:39:57 GMT 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
     * +
     * "	 � 100_3240_1_1_, startTime :Fri Sep 16 11:36:30 GMT 2016, endTime :Fri Sep 16 11:36:37 GMT 2016, lookSide :Right, sensorMode :STRIPMAP , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
     * +
     * "	 � 100_3238_1_1_, startTime :Fri Sep 16 11:39:48 GMT 2016, endTime :Fri Sep 16 11:39:57 GMT 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : RANKED_ROUTINE, sat :SSAR1 added\n"
     * +
     * "	 � 100_3237_1_1_, startTime :Fri Sep 16 12:30:33 GMT 2016, endTime :Fri Sep 16 12:31:04 GMT 2016, lookSide :Left, sensorMode :SCANSAR_2 , prType : RANKED_ROUTINE, sat :SSAR1 added"
     * ; FunctionUtils fu = new FunctionUtils(); List<DTO> dtoList =
     * fu.parseDtoFromFile(fileString); System.out.println(dtoList);
     *
     * for (int i = 0; i < dtoList.size(); i++) {
     *
     * this.droolsInstance.insertDto(this.droolsParams, dtoList.get(i),
     * sessionId, this.currentKieSession); }
     *
     * droolsInstance.writeToFile(sessionId, currentKieSession, droolsParams); }
     */
    @Test
    public void A_Test_Dwl_Init_plan() throws Exception
    {
        System.out.println("running test : A_Test_Dwl_Init_plan");
        this.droolsParams.getAllVisibilities().clear();
        TaskPlanned taskPlanned = new TaskPlanned();

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // to be sure that other maneuvers will not be planned outside the ones
        // expected for the test, I will set the initial lookside for both
        // satellites to right, as the first acquisition that I put into the
        // rule engine
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        assertEquals(0, taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        assertEquals(0, taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:12", "right", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> alltasksOfPreviousSession = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, dto1.getSatelliteId());
        System.out.println("all tasks : " + alltasksOfPreviousSession);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        List<Maneuver> numberOfManeuvers = taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        System.out.println("number of maneuvers : " + numberOfManeuvers);

        this.currentKieSession = 2;

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        // this.droolsInstance.initPreviousPlan(alltasksOfPreviousSession,
        // this.currentKieSession);

    }
}
