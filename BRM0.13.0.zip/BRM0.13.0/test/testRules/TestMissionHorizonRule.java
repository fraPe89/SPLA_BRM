/**
*
* MODULE FILE NAME:	TestMissionHorizonRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		22 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 22 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * @author fpedrola
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestMissionHorizonRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;

    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException, Exception
    {
        this.sessionId = "TestMissionHorizonRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void A_Test_Acq_Totally_Inside_CurrentMH() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestMissionHorizonRule.class.getSimpleName() + " : A_Test_Acq_Totally_Inside_CurrentMH --\n\n");

        System.out.println("-- The mission horizon under test is : " + this.droolsParams.getCurrentMH());
        System.out.println("-- I'm inserting a dto with start and stop time into this mission horizon");
        DTO dto = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:00:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.outsideMHDTO);
        assertFalse(found);
        System.out.println("-- The dto is accepted.");
    }

    @Test
    public void B_Test_Acq_Start_Outside_CurrentMH() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestMissionHorizonRule.class.getSimpleName() + " : B_Test_Acq_Start_Outside_CurrentMH --\n\n");

        System.out.println("-- The mission horizon under test is : " + this.droolsParams.getCurrentMH());
        System.out.println("-- I'm inserting a dto that starts before this mission horizon");
        DTO dto = this.du.createSingleDto("10/10/2017 06:15:00", "10/10/2017 06:25:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.outsideMHDTO);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

    @Test
    public void C_Test_Acq_Ends_Outside_CurrentMH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestMissionHorizonRule.class.getSimpleName() + " : C_Test_Acq_Ends_Outside_CurrentMH --\n\n");

        System.out.println("-- The mission horizon under test is : " + this.droolsParams.getCurrentMH());
        System.out.println("-- I'm inserting a dto that starts before this mission horizon");
        DTO dto = this.du.createSingleDto("10/10/2017 18:19:00", "10/10/2017 18:25:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
    }

    @Test
    public void D_Test_Acq_Totally_Outside_CurrentMH() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestMissionHorizonRule.class.getSimpleName() + " : D_Test_Acq_Totally_Outside_CurrentMH --\n\n");

        System.out.println("-- The mission horizon under test is : " + this.droolsParams.getCurrentMH());
        System.out.println("-- I'm inserting a dto that starts before this mission horizon");
        DTO dto = this.du.createSingleDto("10/10/2017 18:21:05", "10/10/2017 18:28:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.outsideMHDTO);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

}
