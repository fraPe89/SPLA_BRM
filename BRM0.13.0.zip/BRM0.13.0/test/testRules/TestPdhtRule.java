
package testRules;

import java.text.ParseException;

import org.junit.After;
import org.junit.Before;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;

public class TestPdhtRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;

    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "pdhtRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /*
     *
     * @Test public void TestCreateNewStorage() throws IOException, Exception {
     * TaskPlanned taskPlanned = new TaskPlanned(); double sizeOfTheImage = 200;
     * boolean accepted = false; DTO dto1 = null;
     *
     * this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     *
     * this.droolsParams.setResponceFile(
     * "C:/opt/SPLA/BRM/testReports/test_0_.txt");
     *
     * this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_");
     * System.out.println("\n\n Running test : TestCreateNewStorage \n\n");
     *
     * // create a dto with the partner just created as subscriber dto1 =
     * this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00",
     * "left", "SAT_1"); dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
     * dto1.setSizeH(sizeOfTheImage);
     * System.out.println("I'm inserting a new dto with sensorMode " +
     * TypeOfAcquisition.STRIPMAP + " : " + dto1); accepted =
     * this.droolsInstance.insertDto(this.droolsParams, dto1, sessionId,
     * this.currentKieSession); assertTrue(accepted);
     * System.out.println("The dto is accepted.");
     *
     * Acquisition acq = taskPlanned.receiveAllAcquisitionsAsMap(sessionId,
     * this.currentKieSession, this.droolsParams, "SAT_1").get(dto1.getDtoId());
     * // Storage sto = //
     * droolsInstance.receiveAllStorages(currentKieSession,"SAT_1").get(0);
     * assertEquals(1,
     * this.droolsInstance.receiveAllAcquisitions(this.sessionId,
     * this.currentKieSession, "SAT_1").size()); //
     * assertEquals(0,droolsInstance.receiveAllStorages(currentKieSession,
     * "SAT_1").size());
     *
     * System.out.println("generated acq associated to dto : " + acq); //
     * System.out.println("generated sto associated to acq : "+sto); //
     * assertEquals(dto1.getDtoId(),sto.getRelatedAcqId());
     *
     * // create a dto with the partner just created as subscriber DTO dto2 =
     * this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:57:00",
     * "left", "SAT_1"); dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
     * dto2.setSizeH(sizeOfTheImage); dto2.setPol(Polarization.HH);
     * System.out.println("I'm inserting a new dto with sensorMode " +
     * TypeOfAcquisition.STRIPMAP + " : " + dto1); accepted =
     * this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId,
     * this.currentKieSession); assertTrue(accepted);
     * System.out.println("The dto is accepted.");
     *
     * this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession,
     * this.droolsParams);
     *
     * ResourceFunctions resources = (ResourceFunctions)
     * this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession,
     * "resourceFunctions"); TreeMap<Long, ComplexPdht> pdhtFunctionSat1 =
     * resources.getPDHTTemporalFunctionSat1();
     * System.out.println("PRINT pdht : "); for (Map.Entry<Long, ComplexPdht>
     * historyOfPdht : pdhtFunctionSat1.entrySet()) { Date associatedDate = new
     * Date(historyOfPdht.getKey()); System.out.println(" at time : " +
     * associatedDate); System.out.println(historyOfPdht.getValue()); }
     *
     * }
     *
     */
}
