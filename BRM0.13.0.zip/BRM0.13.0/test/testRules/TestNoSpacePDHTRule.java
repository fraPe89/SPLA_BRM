/**
*
* MODULE FILE NAME:	TestNoSpacePDHT.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		30 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 30 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Storage;

/**
 * @author fpedrola
 *
 */
public class TestNoSpacePDHTRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsOperations = null;
    private DroolsUtils du = null;
    private double maxBicForTest = 0;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestDroolsOperations";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsOperations = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsOperations.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void A_TestStorageFail() throws Exception
    {
        System.out.println("Running test : TestStorageFail ");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_0_.txt");
        List<Acquisition> allAcq = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        assertEquals(0, allAcq.size());
        System.out.println("# list acq is null when test is starting...");

        TreeMap<Long, PDHT> pdhtFunction = (TreeMap<Long, PDHT>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "PDHTFunction");
        System.out.println("pdht function before insert the acq under test: " + pdhtFunction);

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:40:00", "10/10/2017 07:46:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(1011);
        System.out.println("# I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);
        System.out.println("# the dto is accepted : " + accepted);

        List<Acquisition> allAcqAfterAcceptedDto = this.droolsOperations.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        assertEquals(allAcq.size(), allAcqAfterAcceptedDto.size());
        assertEquals(0, allAcqAfterAcceptedDto.size());

        System.out.println("# a storage cannot be created, There isn't enought space on PDHT.");
        System.out.println("# acq deleted ");

        TreeMap<String, Storage> allStorages = this.droolsOperations.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1");
        assertEquals(0, allStorages.size());

        pdhtFunction = (TreeMap<Long, PDHT>) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "PDHTFunction");
        System.out.println("pdht function after the insert of the acq: " + pdhtFunction);

    }

    /**
     * Test insert sto in PDHT.
     *
     * @throws Exception
     *             the exception
     */
    @Test
    public void insertStoInPDHT_no_space_drools_Second_Step_Test() throws Exception
    {
        String satId = "SAT_1";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsOperations);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsOperations = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsOperations, this.currentKieSession, "_");
        System.out.println("Running Test : A_TestAcceptAcquisition \n\n");
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsOperations.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        TreeMap<Long, ComplexPdht> PDHTFunction = resFunc.getPDHTFunctionAssociatedToSat(satId);
        long freeMemoryForTest = 600;
        PDHT previousPDHT = new PDHT("pdhtId", "PDHT1", satId, freeMemoryForTest, null);
        System.out.println("pdht : " + previousPDHT);
        PDHTFunction.put(this.droolsParams.getCurrentMH().getStart().getTime(), new ComplexPdht(previousPDHT));

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:40:00", "10/10/2017 07:41:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        System.out.println("# I'm inserting dto : " + dto1.toString());

        boolean insertedInPdht = this.droolsOperations.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        PDHTFunction = resFunc.getPDHTFunctionAssociatedToSat(satId);

        for (Map.Entry<Long, ComplexPdht> eleentPdht : PDHTFunction.entrySet())
        {
            System.out.println("PDHT function AT TIME: " + new Date(eleentPdht.getKey()));

            System.out.println(" " + eleentPdht.getValue());

        }
        // assertEquals(false, insertedInPdht);
        System.out.println("# the dto is accepted : " + insertedInPdht);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:40:00", "10/10/2017 06:41:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(300);
        System.out.println("# I'm inserting dto : " + dto2.toString());

        insertedInPdht = this.droolsOperations.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        PDHTFunction = resFunc.getPDHTFunctionAssociatedToSat(satId);
        System.out.println("PDHT function : " + PDHTFunction);
        assertFalse(insertedInPdht);

        PDHTFunction = resFunc.getPDHTFunctionAssociatedToSat(satId);

        for (Map.Entry<Long, ComplexPdht> eleentPdht : PDHTFunction.entrySet())
        {
            System.out.println("PDHT function AT TIME: " + new Date(eleentPdht.getKey()));

            System.out.println(" " + eleentPdht.getValue());

        }

        this.droolsOperations.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

}
