/**
*
* MODULE FILE NAME:	TestBicRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		06 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 06 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.LoggerFactory;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.functions.BicManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.CreditCard;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.DebitCard;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author fpedrola
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestBicRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private double maxBicForPartner;

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestBicRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.maxBicForPartner = 200;
        DroolsParameters.setLogger(LoggerFactory.getLogger(TestBicRule.class));
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void A_test_Assign_BIC_when_start_new_MH()
    {
        System.out.println("\n\n\n\n running test : A_test_Assign_BIC_when_start_new_MH");
        BicManagement bicMng = new BicManagement();
        double maxPercLoanAvailable = 30;
        Partner p1 = new Partner("partner_1", null, this.maxBicForPartner, maxPercLoanAvailable);
        Partner p2 = new Partner("partner_2", null, this.maxBicForPartner, maxPercLoanAvailable);
        p2.setPayOffs(2);
        p2.setUgsId("ugsId");
        p1.setNewBicSetup(true);
        p2.setNewBicSetup(true);
        bicMng.initializeBIC(p1);
        bicMng.initializeBIC(p2);
        assertEquals(this.maxBicForPartner, p1.getMaxBICAvailable(), 0);
        assertEquals(this.maxBicForPartner, p2.getMaxBICAvailable(), 0);
        assertFalse(p1.isNewBicSetup());
        assertFalse(p2.isNewBicSetup());
    }

    @Test
    public void B_test_accept_BIC_Loan_in_next_mh_no_BlackList()
    {
        System.out.println("\n\n\n\n running test : B_test_accept_BIC_Loan_in_next_mh_no_BlackList");
        BicManagement bicMng = new BicManagement();
        List<String> arList = new ArrayList<>(Arrays.asList("firstAr", "secondAr"));
        double loan = 20;
        Partner p1 = new Partner("partner_1", arList, this.maxBicForPartner, loan);
        Partner p2 = new Partner("partner_2", arList, this.maxBicForPartner, loan);
        p1.setNewBicSetup(true);
        p2.setNewBicSetup(true);
        p2.setFinished(true);

        System.out.println("p1 residual amount before returning the credit to p2 :" + p1.getMaxBICAvailable());
        System.out.println("p2 residual amount before receiving the debt from p1:" + p2.getMaxBICAvailable());

        // p1 will have p2 on the list of partners from which it received BIC
        // (creditors)
        List<DebitCard> creditors = new ArrayList<>();
        DebitCard debit = new DebitCard(p2.getPartnerId(), loan, "acq1");
        creditors.add(debit);
        p1.setLoanList(creditors);

        // p2 adds p1 to the list of partners to which he has lent BICs
        // (debtors)
        List<CreditCard> debitors = new ArrayList<>();
        CreditCard credit = new CreditCard(p1.getPartnerId(), loan, "acq1");
        debitors.add(credit);
        p2.setGivenLoan(debitors);

        System.out.println("p1 has a creditor, p2 :" + credit.toString());
        System.out.println("p2 has a debitor, p1 :" + debit);

        p1.setNewBicSetup(true);
        p2.setNewBicSetup(true);
        bicMng.initializeBIC(p1);
        bicMng.initializeBIC(p2);

        System.out.println("p1 residual amount after returning the credit to p2 :" + p1.getMaxBICAvailable());
        System.out.println("p2 residual amount after receiving the debt from p1:" + p2.getMaxBICAvailable());

        System.out.println("list of creditors of p1 is now empty : " + p1.getLoanList());
        System.out.println("list of debitors of p2 is now empty : " + p2.getGivenLoan());
        assertEquals(0, p1.getLoanList().size());
        assertEquals(0, p2.getGivenLoan().size());

    }

    @Test
    public void C_test_accept_BIC_loan_with_donation()
    {
        System.out.println("\n\n\n\n running test : C_test_accept_BIC_loan_with_donation");
        BicManagement bicMng = new BicManagement();

        int maxDailyBicForPartner = 200;
        Partner p1 = new Partner("partner_1", null, maxDailyBicForPartner, 20);
        Partner p2 = new Partner("partner_2", null, maxDailyBicForPartner, 20);
        Partner p3 = new Partner("partner_3", null, maxDailyBicForPartner, 20);
        Partner p4 = new Partner("partner_4", null, maxDailyBicForPartner, 20);

        List<String> partnersToDonate = new ArrayList<>();
        partnersToDonate.add(p1.getPartnerId());
        p2.setDonation(partnersToDonate);

        List<String> borrowingBic = new ArrayList<>();
        borrowingBic.add(p2.getPartnerId());
        p3.setBorrowingBic(borrowingBic);

        bicMng.initializeBIC(p1);
        bicMng.initializeBIC(p2);
        bicMng.initializeBIC(p3);
        bicMng.initializeBIC(p4);

        assertEquals(maxDailyBicForPartner, p1.getMaxBICAvailable(), 0);
        assertEquals(maxDailyBicForPartner, p2.getMaxBICAvailable(), 0);
        assertEquals(maxDailyBicForPartner, p3.getMaxBICAvailable(), 0);
        assertEquals(maxDailyBicForPartner, p4.getMaxBICAvailable(), 0);
    }

    @Test
    public void E_reject_Acq_Because_BlackList_Partner() throws Exception
    {
        BicManagement bicMng = new BicManagement();
        DroolsUtils du = new DroolsUtils();
        List<Acquisition> allAcq = new ArrayList<>();

        System.out.println("\n\n\n\n running test : E_reject_Acq_Because_BlackList_Partner");
        Partner p1 = new Partner("partner_1", null, this.maxBicForPartner, 20);
        Partner p2 = new Partner("partner_2", null, this.maxBicForPartner, 20);
        Partner p3 = new Partner("partner_3", null, this.maxBicForPartner, 20);

        List<String> borrowingBic = new ArrayList<>();
        borrowingBic.add(p3.getPartnerId());
        p2.setBorrowingBic(borrowingBic);

        bicMng.initializeBIC(p1);
        bicMng.initializeBIC(p2);
        bicMng.initializeBIC(p3);
        p2.setFinished(true);
        p3.setFinished(true);

        p2.setUsedBIC(60);
        p3.setUsedBIC(180);

        List<Partner> allPartners = new ArrayList<>();
        allPartners.add(p1);
        allPartners.add(p2);
        allPartners.add(p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);

        Acquisition acq_p1 = du.createParametricAcquisition("dto1", "10/10/2017 19:41:00", "10/10/2017 19:41:00", "left", "SAT_1");

        acq_p1.setImageBIC(250); // ->loan = 50
        acq_p1.setUserInfo(userInfoList);
        allAcq.add(acq_p1);
        TreeMap<Long, EnergyAssociatedToTask> allAcqAssToSat = new TreeMap<>();

        List<Partner> invalidPartner = bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq_p1, null, allAcqAssToSat, null);
        assertTrue(invalidPartner.size() > 0);
    }

    @Test
    public void F_test_reject_Acq_Because_BIC_unavailables() throws Exception
    {
        System.out.println("\n\n\n\n running test : F_test_reject_Acq_Because_BIC_unavailables");
        BicManagement bicMng = new BicManagement();
        DroolsUtils du = new DroolsUtils();
        List<Acquisition> allAcq = new ArrayList<>();
        Partner p1 = new Partner("partner_1", null, this.maxBicForPartner, 20);
        Partner p2 = new Partner("partner_2", null, this.maxBicForPartner, 20);
        Partner p3 = new Partner("partner_3", null, this.maxBicForPartner, 20);
        p2.setFinished(true);
        p3.setFinished(true);

        p2.setUsedBIC(190);
        p3.setUsedBIC(200);

        List<Partner> allPartners = new ArrayList<>();
        allPartners.add(p1);
        allPartners.add(p2);
        allPartners.add(p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);

        Acquisition acq_p1 = du.createParametricAcquisition("dto1", "10/10/2017 19:41:00", "10/10/2017 19:41:00", "left", "SAT_1");
        acq_p1.setImageBIC(250);
        acq_p1.setUserInfo(userInfoList);

        allAcq.add(acq_p1);
        TreeMap<Long, EnergyAssociatedToTask> allAcqAssToSat = new TreeMap<>();

        List<Partner> invalidPartner = bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq_p1, null, allAcqAssToSat, null);
        assertTrue(invalidPartner.size() > 0);
    }

    @Test
    public void G_test_reject_Acq_Because_all_others_partners_haven_t_done_their_schedules() throws Exception
    {
        System.out.println("\n\n\n\n running test : G_test_reject_Acq_Because_all_others_partners_haven_t_done_their_schedules");
        BicManagement bicMng = new BicManagement();
        DroolsUtils du = new DroolsUtils();
        List<Acquisition> allAcq = new ArrayList<>();

        Partner p1 = new Partner("partner_1", null, this.maxBicForPartner, 20);
        Partner p2 = new Partner("partner_2", null, this.maxBicForPartner, 20);
        Partner p3 = new Partner("partner_3", null, this.maxBicForPartner, 20);

        bicMng.initializeBIC(p1);
        bicMng.initializeBIC(p2);
        bicMng.initializeBIC(p3);
        p2.setFinished(false);
        p3.setFinished(false);
        p2.setUsedBIC(60);
        p3.setUsedBIC(80);

        List<Partner> allPartners = new ArrayList<>();
        allPartners.add(p1);
        allPartners.add(p2);
        allPartners.add(p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);

        Acquisition acq_p1 = du.createParametricAcquisition("dto1", "10/10/2017 19:41:00", "10/10/2017 19:41:00", "left", "SAT_1");
        acq_p1.setImageBIC(250);
        acq_p1.setUserInfo(userInfoList);

        allAcq.add(acq_p1);
        TreeMap<Long, EnergyAssociatedToTask> allAcqAssToSat = new TreeMap<>();

        List<Partner> invalidPartner = bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq_p1, null, allAcqAssToSat, null);
        assertEquals(1, invalidPartner.size());
    }

    @Test
    public void I_test_accept_acq_without_using_extraBIC() throws Exception
    {
        System.out.println("\n\n\n\n running test : I_test_accept_acq_without_using_extraBIC");
        BicManagement bicMng = new BicManagement();
        DroolsUtils du = new DroolsUtils();
        List<Acquisition> allAcq = new ArrayList<>();

        Partner p1 = new Partner("partner_1", null, this.maxBicForPartner, 20);
        Partner p2 = new Partner("partner_2", null, this.maxBicForPartner, 20);
        Partner p3 = new Partner("partner_3", null, this.maxBicForPartner, 20);

        List<String> donateList = new ArrayList<>();
        donateList.add(p1.getPartnerId());
        p3.setDonation(donateList);

        bicMng.initializeBIC(p1);
        bicMng.initializeBIC(p2);
        bicMng.initializeBIC(p3);
        p2.setFinished(true);
        p3.setFinished(true);

        int usedBicP3 = 80;
        int usedBicP2 = 70;

        p2.setUsedBIC(usedBicP2);
        p3.setUsedBIC(usedBicP3);

        List<Partner> allPartners = new ArrayList<>();
        allPartners.add(p1);
        allPartners.add(p2);
        allPartners.add(p3);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), "ugsId");
        userInfoList.add(userInfo1);

        Acquisition acq_p1 = du.createParametricAcquisition("dto1", "10/10/2017 19:41:00", "10/10/2017 19:41:00", "left", "SAT_1");
        acq_p1.setImageBIC(30);
        acq_p1.setUserInfo(userInfoList);
        allAcq.add(acq_p1);

        TreeMap<Long, EnergyAssociatedToTask> allAcqAssToSat = new TreeMap<>();

        List<Partner> invalidPartner = bicMng.checkBicAndNeoBicForAcq(this.droolsParams, acq_p1, null, allAcqAssToSat, new TreeMap<Long, Maneuver>());
        assertEquals(0, invalidPartner.size());
    }

    @Test
    public void notDecrementBicTest() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : L_Test_Dont_Decrement_previous_accepted \n\n");

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        double imgBic = 3;

        // create a dto with the partner just created as subscriber
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");

        UserInfo userInfo = new UserInfo(null, true, p1.getPartnerId(), "KIR");
        List<UserInfo> userInfoAssociatedToDto = new ArrayList<>(Arrays.asList(userInfo));
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setUserInfo(userInfoAssociatedToDto);
        dto1.setPrType(PRType.RANKED_ROUTINE);
        dto1.setImageBIC(imgBic);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p1.getAcqPerformed().size());

        System.out.println("I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(1, p1.getAcqPerformed().size());
    }

    @Test
    public void decrementBicTest() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.routine, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : L_Test_Dont_Decrement_previous_accepted \n\n");

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        double imgBic = 3;

        // create a dto with the partner just created as subscriber
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");

        UserInfo userInfo = new UserInfo(null, true, p1.getPartnerId(), "KIR");
        List<UserInfo> userInfoAssociatedToDto = new ArrayList<>(Arrays.asList(userInfo));
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setUserInfo(userInfoAssociatedToDto);
        dto1.setPrType(PRType.RANKED_ROUTINE);
        dto1.setImageBIC(imgBic);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(0, p1.getAcqPerformed().size());

        System.out.println("I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        assertEquals(imgBic, p1.getUsedBIC(), 0);
        assertEquals(0, p1.getUsedNeoBic(), 0);
        assertEquals(1, p1.getAcqPerformed().size());
    }

    /**
     * Test decrement ar id case last one ar.
     *
     * @throws ParseException
     *             the parse exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void L_Test_Dont_Decrement_previous_accepted() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : L_Test_Dont_Decrement_previous_accepted \n\n");

        // creating a partner with a list of AR associated
        List<String> arAssociatedToPartner = new ArrayList<>();
        arAssociatedToPartner.add("AR-001");

        double maxBicAvailableForTest = 100;
        Partner partnerForTest = new Partner("partnerTest", arAssociatedToPartner, maxBicAvailableForTest, 20);
        List<String> partnersAssociated = new ArrayList<>();
        partnersAssociated.add(partnerForTest.getPartnerId());

        this.droolsParams.getAllPartners().add(partnerForTest);
        // insert the partner into Drools
        this.droolsInstance.insertPartner(partnerForTest, this.sessionId, this.currentKieSession);

        System.out.println("partner for test before insert of dto: " + partnerForTest);

        // create a dto with the partner just created as subscriber
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");

        UserInfo userInfo = new UserInfo(null, true, partnerForTest.getPartnerId(), "KIR");
        List<UserInfo> userInfoAssociatedToDto = new ArrayList<>(Arrays.asList(userInfo));
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setUserInfo(userInfoAssociatedToDto);
        dto1.setArID("AR-001");

        System.out.println("I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("partner for test after insert of dto: " + partnerForTest);
        System.out.println("The dto is accepted.");
        System.out.println("ar id : " + partnerForTest.getArIdForPartner());

        assertTrue(partnerForTest.isFinished());
        List<String> acceptedElements = (List<String>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "accepted");
        System.out.println("list of accepted elements : " + acceptedElements);

        System.out.println("creating another session : " + this.sessionId);
        partnerForTest.getAcqPerformed().clear();
        partnerForTest.setFinished(false);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        acceptedElements = (List<String>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "accepted");
        System.out.println("list of accepted elements : " + acceptedElements);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("partner for test after insert of dto: " + partnerForTest);
        System.out.println("The dto is accepted.");
        System.out.println("ar id : " + partnerForTest.getArIdForPartner());
    }

}
