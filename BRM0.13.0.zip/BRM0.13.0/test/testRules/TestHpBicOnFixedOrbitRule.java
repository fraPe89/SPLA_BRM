/**
*
* MODULE FILE NAME:	TestHpBicOnFixedOrbit.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		14 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 14 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * @author fpedrola
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestHpBicOnFixedOrbitRule
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    Map<String, Acquisition> rejectedElements = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "DownloadScenario";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.PDHTMaxMemory = 500000L;
        this.rejectedElements = new HashMap<>();
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testExceedBicOnFixedOrbit() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        int fixedOrbitForTest = 2;
        double maxNumberOfBicForFixedOrbit = 25;
        double totalBicOnFixedOrbit = 0;

        System.out.println("on fixed orbit : " + fixedOrbitForTest);
        System.out.println("that has max number of Bic for Hp acquisition of : " + maxNumberOfBicForFixedOrbit);

        Map<String, Map<Integer, Double>> maxHpBic = this.droolsParams.getMaxHpBicFixedOrbit();
        Map<Integer, Double> fixedHpForSat = new HashMap<>();
        fixedHpForSat.put(1, 25.0);
        fixedHpForSat.put(2, 25.0);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        maxHpBic.put("SAT_1", fixedHpForSat);
        this.droolsParams.setMaxHpBicFixedOrbit(maxHpBic);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:01:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(200);
        dto1.setRevolutionNumber(fixedOrbitForTest);
        dto1.setImageBIC(15);
        dto1.setPrType(PRType.HP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        totalBicOnFixedOrbit = totalBicOnFixedOrbit + dto1.getImageBIC();
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:55:01", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(200);
        dto2.setRevolutionNumber(fixedOrbitForTest);
        dto2.setImageBIC(5);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        totalBicOnFixedOrbit = totalBicOnFixedOrbit + dto2.getImageBIC();
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 09:55:00", "10/10/2017 09:57:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(200);
        dto3.setRevolutionNumber(fixedOrbitForTest);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(15);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        totalBicOnFixedOrbit = totalBicOnFixedOrbit + dto3.getImageBIC();
        assertFalse(accepted);
        assertTrue(totalBicOnFixedOrbit > maxNumberOfBicForFixedOrbit);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), this.rejectedElements, ReasonOfReject.HpFixedOrbitLimitReached);
        assertTrue(found);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void Test_exceed_there_isnt_sat() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_exceed_there_isnt_sat ");
        int fixedOrbitForTest = 2;
        double maxNumberOfBicForFixedOrbit = 25;
        double totalBicOnFixedOrbit = 0;

        System.out.println("on fixed orbit : " + fixedOrbitForTest);
        System.out.println("that has max number of Bic for Hp acquisition of : " + maxNumberOfBicForFixedOrbit);

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_.txt");
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Map<Integer, Double>> maxHpBic = this.droolsParams.getMaxHpBicFixedOrbit();
        Map<Integer, Double> fixedHpForSat = new HashMap<>();
        fixedHpForSat.put(1, 25.0);
        fixedHpForSat.put(2, 25.0);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        maxHpBic.put("SAT_1", fixedHpForSat);

        this.droolsParams.setMaxHpBicFixedOrbit(maxHpBic);

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:01:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(200);
        dto1.setRevolutionNumber(fixedOrbitForTest);
        dto1.setImageBIC(15);
        dto1.setPrType(PRType.HP);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        totalBicOnFixedOrbit = totalBicOnFixedOrbit + dto1.getImageBIC();
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:55:00", "10/10/2017 08:55:01", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(200);
        dto2.setRevolutionNumber(fixedOrbitForTest);
        dto2.setImageBIC(5);
        dto2.setPrType(PRType.HP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        totalBicOnFixedOrbit = totalBicOnFixedOrbit + dto2.getImageBIC();
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 09:55:00", "10/10/2017 09:57:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(200);
        dto3.setRevolutionNumber(fixedOrbitForTest);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(15);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        totalBicOnFixedOrbit = totalBicOnFixedOrbit + dto3.getImageBIC();
        assertFalse(accepted);
        assertTrue(totalBicOnFixedOrbit > maxNumberOfBicForFixedOrbit);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        assertEquals(1, this.rejectedElements.size());
    }

}
