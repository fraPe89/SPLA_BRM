/**
*
* MODULE FILE NAME:	TestPurgeSensorMode.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		01 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 01 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resources.ReasonOfRejectElement;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author francesca
 *
 */
public class TestPurgeSensorMode
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestMissionHorizonRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void purgeSensorModeTest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        List<TypeOfAcquisition> typeOfNotAllowedSensorMode = new ArrayList<>();
        typeOfNotAllowedSensorMode.add(TypeOfAcquisition.PINGPONG);
        typeOfNotAllowedSensorMode.add(TypeOfAcquisition.SCANSAR_1);
        this.droolsParams.setPurgeSensorMode(typeOfNotAllowedSensorMode);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : purgeSensorModeTest \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", satelliteId);
        dto1.setSizeH(2000);
        dto1.setDtoId("dtoId");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(inserted);

        Map<String, Acquisition> rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + rejectedElements);

        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", satelliteId);
        dto2.setDtoId("dto2Id");
        dto2.setSizeH(2000);
        dto2.setPol(Polarization.HH);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);

        System.out.println("I'm inserting dto : " + dto2.toString());
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected elements : " + rejectedElements);

        Acquisition acqRelatedToRejectedDto = rejectedElements.get(dto1.getDtoId());
        ReasonOfRejectElement reasonOfReject = acqRelatedToRejectedDto.findReasonOfReject(ReasonOfReject.sensorModeNotAllowed);
        assertTrue(reasonOfReject != null);
    }
}
