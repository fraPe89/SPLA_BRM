/**
*
* MODULE FILE NAME:	TestEssManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		20 set 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 20 set 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

/**
 * @author fpedrola
 *
 */
public class TestOrbitThresholdRule
{

    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException, Exception
    {
        this.sessionId = "TestOrbitThresholdRule";
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test : A_Test_Sort_Acq_Related_To_Sat
     *
     */
    @Test
    public void A_Test_Sort_Acq_Related_To_Sat() throws Exception
    {
        TreeMap<Long, EnergyAssociatedToTask> orderedSat1 = null, orderedSat2 = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test A_Test_Sort_Acq_Related_To_Sat");

        System.out.println("-- I'm inserting a dto related to sat1");
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        orderedSat1 = resourceFunctions.getEssFunctionSat1();
        orderedSat2 = resourceFunctions.getEssFunctionSat2();
        assertTrue(orderedSat1.isEmpty());
        assertTrue(orderedSat2.isEmpty());

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:00:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        assertEquals(dto1.getDtoId(), orderedSat1.get(dto1.getStartTime().getTime()).getTask().getIdTask());
        assertEquals(1, orderedSat1.size());
        assertTrue(orderedSat2.isEmpty());

        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:00:00", "left", "SAT_2");
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        assertEquals(dto1.getDtoId(), orderedSat1.get(dto1.getStartTime().getTime()).getTask().getIdTask());
        assertEquals(dto2.getDtoId(), orderedSat2.get(dto2.getStartTime().getTime()).getTask().getIdTask());
        assertEquals(1, orderedSat1.size());
        assertEquals(1, orderedSat2.size());
    }

    /*
     * Scenario : there is another acq (dto1) in the same orbit of the one that
     * we are testing (dto2): dto2 is under eclipse so the total threshold for
     * the ess is decremented : 100% -20% of decrement = 80% remaining -> 80% of
     * 500 (500 = thresholdFortest) = 400 on the same orbit there are dto1 and
     * dto2 -> 300 + 480 ess -> dto2 exceed the energy threshold -> dto2 is
     * rejected
     */
    @SuppressWarnings("unchecked")
    @Test
    public void Test_Reached_Threshold_On_One_Orbit_Eclipse() throws Exception
    {
        System.out.println("\n\n Test_Reached_Threshold_On_One_Orbit_Eclipse");
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        double minTimeEclipseForTest = 300;

        double orbitToTest_1_Orb = 1;
        double thresholdForTest_1_Orb = 500;
        long maxSilentForTest_1_Orb = 1000;
        double minutesForOrbit_1_Orb = orbitToTest_1_Orb * this.droolsParams.getMinutesForOrbit();

        double orbitToTest_3_Orb = 3;
        double thresholdForTest_3_Orb = 500;
        long maxSilentForTest_3_Orb = 300;
        double minutesForOrbit_3_Orb = orbitToTest_3_Orb * this.droolsParams.getMinutesForOrbit();

        Map<Double, ResourceMaxValue> allCheckOnOrbitTest = new HashMap<>();
        ResourceMaxValue resourcesForTest_1_Orb = new ResourceMaxValue(minutesForOrbit_1_Orb, maxSilentForTest_1_Orb, thresholdForTest_1_Orb, -1, -1, -1, minTimeEclipseForTest);
        ResourceMaxValue resourcesForTest_3_Orb = new ResourceMaxValue(minutesForOrbit_3_Orb, maxSilentForTest_3_Orb, thresholdForTest_3_Orb, -1, -1, -1, minTimeEclipseForTest);

        allCheckOnOrbitTest.put(orbitToTest_1_Orb, resourcesForTest_1_Orb);
        allCheckOnOrbitTest.put(orbitToTest_3_Orb, resourcesForTest_3_Orb);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).getSatelliteProperties().setAllChecksOnOrbits(allCheckOnOrbitTest);

        Map<TypeOfAcquisition, Double> powersMap = (Map<TypeOfAcquisition, Double>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "powersSensorMode");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:04:00", "10/10/2017 07:07:00", "left", "SAT_1"); // 300
        // ess
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setDtoId("dto1");
        double powerPingpong = powersMap.get(TypeOfAcquisition.PINGPONG);
        double referencePower = powersMap.get(TypeOfAcquisition.STRIPMAP);
        double gap = (dto1.getEndTime().getTime() - dto1.getStartTime().getTime()) / 1000;

        double expectedEss = (powerPingpong * gap) / referencePower;
        System.out.println("expected ess : " + expectedEss); // = 300 ess

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 11:42:00", "10/10/2017 11:45:00", "left", "SAT_1");
        dto3.setDtoId("dto3");// 180 ess
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:42:00", "10/10/2017 08:45:00", "left", "SAT_1"); // 180
        // ess
        dto2.setDtoId("dto2");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        System.out.println("accepted ? " + accepted);
        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println("allAcq : " + allAcq);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("REJECTED : " + this.rejectedElements);

        Acquisition acq = this.rejectedElements.get(dto2.getDtoId());
        System.out.println(" acq REASON OF REJECT : " + acq.getReasonOfReject());

        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.reachedOrbitThresholdInEclipse);
        assertTrue(found);
    }

    /*
     * Scenario : there is another acq (dto1) in the same orbit of the one that
     * we are testing (dto2): dto2 is under eclipse so the total threshold for
     * the ess is decremented : 100% -20% of decrement = 80% remaining -> 80% of
     * 500 (500 = thresholdFortest) = 400 on the same orbit there are dto1 and
     * dto2 -> 300 + 480 ess -> dto2 exceed the energy threshold -> dto2 is
     * rejected
     */
    @SuppressWarnings("unchecked")
    @Test
    public void Test_Reached_Threshold_On_One_Orbit_No_Eclipse() throws Exception
    {
        System.out.println("\n\n Test_Reached_Threshold_On_One_Orbit_No_Eclipse");
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllEclipses().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        double orbitToTest = 1;
        double thresholdForTest = 500;
        long maxSilentForTest = 1000;
        double minutesForOrbit = orbitToTest * this.droolsParams.getMinutesForOrbit();
        double minTimeEclipseForTest = 300;
        Map<Double, ResourceMaxValue> allCheckOnOrbitTest = new HashMap<>();
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, thresholdForTest, -1, -1, -1, minTimeEclipseForTest);
        allCheckOnOrbitTest.put(orbitToTest, resourcesForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allCheckOnOrbitTest);

        Map<TypeOfAcquisition, Double> powersMap = (Map<TypeOfAcquisition, Double>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "powersSensorMode");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:47:00", "left", "SAT_1"); // 300
        // ess
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);

        double powerPingpong = powersMap.get(TypeOfAcquisition.PINGPONG);
        double referencePower = powersMap.get(TypeOfAcquisition.STRIPMAP);
        double gap = (dto1.getEndTime().getTime() - dto1.getStartTime().getTime()) / 1000;

        double expectedEss = (powerPingpong * gap) / referencePower;
        System.out.println("expected ess : " + expectedEss); // = 300 ess

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:52:00", "10/10/2017 06:57:00", "left", "SAT_1"); // 180
        // ess
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        System.out.println("accepted ? " + accepted);
        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        System.out.println("allAcq : " + allAcq);
        assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        Acquisition acq = this.rejectedElements.get(dto2.getDtoId());
        System.out.println(" acq rejected : " + acq);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.reachedOrbitThreshold);
        assertTrue(found);
    }

    @Test
    public void Test_Threshold_Is_Ok_Because_More_distance_Than_One_Orbit() throws Exception
    {
        System.out.println("\n\n Test_Threshold_Is_Ok_Because_More_distance_Than_One_Orbit");
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        double orbitToTest = 1;
        double minutesForOrbit = orbitToTest * this.droolsParams.getMinutesForOrbit();
        double thresholdForTest = 500;
        long maxSilentForTest = 1000;
        double minTimeEclipseForTest = 300;
        Map<Double, ResourceMaxValue> allCheckOnOrbitTest = new HashMap<>();
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, thresholdForTest, -1, -1, -1, minTimeEclipseForTest);
        allCheckOnOrbitTest.put(orbitToTest, resourcesForTest);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allCheckOnOrbitTest);

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:47:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 09:42:00", "10/10/2017 09:45:00", "right", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        // assertEquals(0, rejectedElements.size());
        System.out.println("dto2 isn't rejected because is not on the same period to check of dto1 (more than 97 minutes)");
    }

    @SuppressWarnings("unchecked")
    @Test
    public void Test_Reached_Threshold_On_Three_Orbit() throws Exception
    {
        System.out.println("\n\n Test_Reached_Threshold_On_Three_Orbit");
        boolean accepted = false;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        double orbitToTest = 3;
        double minutesForOrbit = orbitToTest * this.droolsParams.getMinutesForOrbit();
        double thresholdForTest = 400;
        long maxSilentForTest = 1000;
        double minTimeEclipseForTest = 300;
        Map<Double, ResourceMaxValue> allCheckOnOrbitTest = new HashMap<>();
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(minutesForOrbit, maxSilentForTest, thresholdForTest, -1, -1, -1, minTimeEclipseForTest);
        allCheckOnOrbitTest.put(orbitToTest, resourcesForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allCheckOnOrbitTest);

        Map<TypeOfAcquisition, Double> powersMap = (Map<TypeOfAcquisition, Double>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "powersSensorMode");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:42:30", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);

        double powerPingpong = powersMap.get(TypeOfAcquisition.PINGPONG);
        double referencePower = powersMap.get(TypeOfAcquisition.STRIPMAP);
        double gap = (dto1.getEndTime().getTime() - dto1.getStartTime().getTime()) / 1000;

        double expectedEss = (powerPingpong * gap) / referencePower;
        System.out.println("expected ess : " + expectedEss); // = 300 ess

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:01:00", "10/10/2017 10:02:00", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:48:00", "10/10/2017 08:53:00", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        // assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), this.rejectedElements, ReasonOfReject.reachedOrbitThresholdInEclipse);
        assertTrue(found);

    }

}
