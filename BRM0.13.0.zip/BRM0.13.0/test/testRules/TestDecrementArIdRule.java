/**
*
* MODULE FILE NAME:	TestDecrementArIdRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		01 dic 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 01 dic 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;

/**
 * The Class TestDecrementArIdRule.
 *
 * @author fpedrola
 */
public class TestDecrementArIdRule
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestDecrementArIdRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down. After each test, all the sessions of Drools will be closed.
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test decrement ar : if the partner that we are processed has more than
     * one ar associated.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Test
    public void TestDecrementArId_Case_MoreThanOneAr() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestDecrementArId_Case_MoreThanOneAr \n\n");

        // creating a partner with a list of AR associated
        List<String> arAssociatedToPartner = new ArrayList<>();
        arAssociatedToPartner.add("arTest");
        arAssociatedToPartner.add("AR-001");

        double maxBicAvailableForTest = 100;
        Partner partnerForTest = new Partner("partnerTest", arAssociatedToPartner, maxBicAvailableForTest, 30);
        this.droolsParams.getAllPartners().add(partnerForTest);
        List<String> partnersAssociated = new ArrayList<>();
        partnersAssociated.add(partnerForTest.getPartnerId());

        // insert the partner into Drools
        this.droolsInstance.insertPartner(partnerForTest, this.sessionId, this.currentKieSession);

        // create a dto with the partner just created as subscriber
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setArID("AR-001");

        System.out.println("I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("The dto is accepted.");
        System.out.println("ar id : " + partnerForTest.getArIdForPartner());

        // since there is another ar stored into the partner, the status of the
        // partner is not yet on finished
        assertFalse(partnerForTest.isFinished());
    }

    /**
     * Test decrement ar id case last one ar.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Test
    public void TestDecrementArId_Case_LastOneAr() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestDecrementArId_Case_LastOneAr \n\n");

        // creating a partner with a list of AR associated
        List<String> arAssociatedToPartner = new ArrayList<>();
        arAssociatedToPartner.add("AR-001");

        double maxBicAvailableForTest = 100;
        Partner partnerForTest = new Partner("partnerTest", arAssociatedToPartner, maxBicAvailableForTest, 20);
        List<String> partnersAssociated = new ArrayList<>();
        partnersAssociated.add(partnerForTest.getPartnerId());

        this.droolsParams.getAllPartners().add(partnerForTest);
        // insert the partner into Drools
        this.droolsInstance.insertPartner(partnerForTest, this.sessionId, this.currentKieSession);

        // create a dto with the partner just created as subscriber
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");

        UserInfo userInfo = new UserInfo(null, true, partnerForTest.getPartnerId(), "KIR");
        List<UserInfo> userInfoAssociatedToDto = new ArrayList<>(Arrays.asList(userInfo));
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setUserInfo(userInfoAssociatedToDto);
        dto1.setArID("AR-001");

        System.out.println("I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("The dto is accepted.");
        System.out.println("ar id : " + partnerForTest.getArIdForPartner());

        assertTrue(partnerForTest.isFinished());
    }

    /**
     * Test decrement ar id case last one ar.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Test
    public void TestDecrementArId_Case_RetractAcq() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestDecrementArId_Case_LastOneAr \n\n");

        // creating a partner with a list of AR associated
        List<String> arAssociatedToPartner = new ArrayList<>();
        arAssociatedToPartner.add("AR-001");

        double maxBicAvailableForTest = 100;
        Partner partnerForTest = new Partner("partnerTest", arAssociatedToPartner, maxBicAvailableForTest, 30);
        List<String> partnersAssociated = new ArrayList<>();
        partnersAssociated.add(partnerForTest.getPartnerId());

        this.droolsParams.getAllPartners().add(partnerForTest);

        // insert the partner into Drools
        this.droolsInstance.insertPartner(partnerForTest, this.sessionId, this.currentKieSession);

        // create a dto with the partner just created as subscriber
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        UserInfo userInfo = new UserInfo(null, true, partnerForTest.getPartnerId(), "KIR");
        List<UserInfo> userInfoAssociatedToDto = new ArrayList<>(Arrays.asList(userInfo));
        dto1.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto1.setUserInfo(userInfoAssociatedToDto);
        dto1.setArID("AR-001");

        System.out.println("I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        System.out.println("The dto is accepted.");
        System.out.println("ar id : " + partnerForTest.getArIdForPartner());

        assertTrue(partnerForTest.isFinished());
    }

}
