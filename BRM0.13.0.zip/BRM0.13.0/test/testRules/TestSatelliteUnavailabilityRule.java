
package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

public class TestSatelliteUnavailabilityRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestSatelliteUnavailabilityRule";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    // SatelliteState satStat2 = createSatelliteState("SAT_1", "10/10/2017
    // 15:10:00", "10/10/2017 15:13:00");

    @Test
    public void C_Test_Acq_overlap_unavailability_window_overlapAtStart() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : C_Test_Acq_overlap_unavailability_window_overlapAtStart");

        System.out.println("-- I'm inserting a dto that sarts inside and ends after this unavailability window");
        DTO dto = this.du.createSingleDto("10/10/2017 15:09:00", "10/10/2017 15:11:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.satelliteUnavailability);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

    @Test
    public void B_Test_Acq_overlap_unavailability_window_overlapAtEnd() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : B_Test_Acq_overlap_unavailability_window_overlapAtEnd");

        System.out.println("-- I'm inserting a dto that sarts inside and ends after this unavailability window");
        DTO dto = this.du.createSingleDto("10/10/2017 15:12:00", "10/10/2017 15:16:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.satelliteUnavailability);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

    @Test
    public void C_Test_Acq_overlap_unavailability_window_dtoTotallyIncludedInWindow() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : C_Test_Acq_overlap_unavailability_window_dtoTotallyIncludedInWindow");

        System.out.println("-- I'm inserting a dto that sarts inside and ends after this unavailability window");
        DTO dto = this.du.createSingleDto("10/10/2017 15:12:00", "10/10/2017 15:16:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.satelliteUnavailability);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

    @Test
    public void C_Test_Acq_overlap_unavailability_window_WindowTotallyIncludedInDto() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : C_Test_Acq_overlap_unavailability_window_WindowTotallyIncludedInDto");

        System.out.println("-- I'm inserting a dto that sarts inside and ends after this unavailability window");
        DTO dto = this.du.createSingleDto("10/10/2017 15:09:00", "10/10/2017 15:13:10", "right", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.satelliteUnavailability);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

    @Test
    public void D_Test_Acq_Totally_Outside_CurrentMH() throws Exception
    {
        Map<String, Acquisition> rejected = null;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("-- The mission horizon under test is : " + this.droolsParams.getCurrentMH());
        System.out.println("-- I'm inserting a dto that starts before this mission horizon");
        DTO dto = this.du.createSingleDto("10/10/2017 18:23:00", "10/10/2017 18:24:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), rejected, ReasonOfReject.outsideMHDTO);
        assertTrue(found);
        System.out.println("-- The dto is rejected because : " + rejected.get(dto.getDtoId()).getReasonOfReject());
    }

}
