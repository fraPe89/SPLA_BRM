/**
*
* MODULE FILE NAME:	TestMaxNumberPrType.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		17 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 17 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * @author fpedrola
 *
 */
public class TestMaxPrTypeRule
{

    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private double maxBicForTest = 0;

    @Before
    public void setUp() throws ParseException, Exception
    {
        this.sessionId = "TestMaxNumberPrType";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void test_max_Number_Pr_type_Hp() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_max_Number_Pr_type_Hp");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:55:00", "10/10/2017 07:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.PP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto3 = 9;
        DTO dto3 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 17:00:00", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto3.setImageBIC(imageBicDto3);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + rejected);
      //  boolean existReason = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.maxNumberPrType);
      //  assertEquals(true, existReason);
    }

    @Test
    public void test_max_Number_Pr_type_Different_From_HP() throws IOException, Exception
    {
        System.out.println("RUNNING TEST : test_max_Number_Pr_type_Different_From_HP");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllPAWS().clear();
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        System.out.println("\n\n\n\n max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        dto1.setPrType(PRType.CIVILIAN_HP);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 06:55:00", "10/10/2017 07:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.CIVILIAN_HP);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:56:00", "right", "SAT_1");
        dto3.setPrType(PRType.CIVILIAN_HP);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
}
