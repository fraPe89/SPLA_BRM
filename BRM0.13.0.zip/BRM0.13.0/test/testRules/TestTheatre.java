
package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * The Class TestTheatre.
 */
public class TestTheatre
{

    /** The session id. */
    private String sessionId = null;

    /** The rejected elements. */
    private Map<String, Acquisition> rejectedElements = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestTheatre";
        this.maxBicForTest = 200;
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_dtos_too_close() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();
        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:58:00", "10/10/2017 13:58:30", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 13:58:31", "10/10/2017 13:58:45", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        for (Map.Entry<String, Acquisition> allAcceptEl : allAcqRejected.entrySet())
        {
            System.out.println("REJECTED EL " + allAcceptEl.getValue());
        }

    }

    /**
     * Test insert theatre invalid for overlap acq.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_invalid_for_overlap_acq() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO previousDto = this.du.createSingleDto("10/10/2017 15:58:00", "10/10/2017 16:01:00", "left", satelliteId);
        previousDto.setPol(Polarization.HH);
        previousDto.setSizeH(4000);
        boolean insert = this.droolsInstance.insertDto(this.droolsParams, previousDto, this.sessionId, this.currentKieSession);
        assertTrue(insert);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:59:00", "10/10/2017 16:00:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);
        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */

    // TODO : ripristinare test cmgFormula dopo aver ripristinato relativo
    // algoritmo
    /*
     * @SuppressWarnings("unchecked")
     *
     * @Test public void testInsert_theatre_with_pitch_invalid_for_cmga() throws
     * Exception {
     *
     * System.out.
     * println("\n\n\n\n running test : testInsert_theatre_with_pitch_invalid_for_cmga"
     * ); this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance); this.droolsInstance =
     * this.du.setUpSession(this.sessionId, SessionType.premium,
     * this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
     * String satelliteId = "SAT_1"; Map<Double, Double> allPowersForOrbit = new
     * HashMap<Double, Double>(); allPowersForOrbit.put(1.0, 18.0);
     * allPowersForOrbit.put(3.0, 38.0); allPowersForOrbit.put(14.8125, 42.0);
     *
     * for (int i = 0; i < droolsParams.getAllCMGAForSat(satelliteId).size();
     * i++) {
     * droolsParams.getAllCMGAForSat(satelliteId).get(i).setAllPowersForOrbit(
     * allPowersForOrbit); } List<DTO> allDtosIncludedInTheatre = new
     * ArrayList<DTO>(); List<Maneuver> maneuvers = new ArrayList<Maneuver>();
     *
     * DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00",
     * "10/10/2017 14:00:00", "right", satelliteId);
     * dto1.setPol(Polarization.HH); dto1.setSizeH(4000);
     *
     * DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00",
     * "10/10/2017 14:02:00", "right", satelliteId);
     * dto2.setPol(Polarization.HH); dto2.setSizeH(4000);
     *
     * DTO dto3 = this.du.createSingleDto("10/10/2017 15:03:00",
     * "10/10/2017 15:04:00", "right", satelliteId);
     * dto3.setPol(Polarization.HH); dto3.setSizeH(4000);
     *
     * allDtosIncludedInTheatre.add(dto1); allDtosIncludedInTheatre.add(dto2);
     * allDtosIncludedInTheatre.add(dto3);
     *
     * Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1",
     * "dto2", "10/10/2017 13:59:00", "10/10/2017 15:04:00", satelliteId,
     * Actuator.CMGA); manInsideTheatre.setType(ManeuverType.PitchCPS);
     * maneuvers.add(manInsideTheatre);
     *
     * EquivalentDTO equivDto = new EquivalentDTO();
     * equivDto.setEquivalentDtoId("equivDto");
     * equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
     * equivDto.setManAssociated(maneuvers);
     * equivDto.setEquivType(PRMode.Theatre);
     * equivDto.setStartTime(dto1.getStartTime());
     * equivDto.setEndTime(dto3.getEndTime());
     *
     * boolean validTheatre =
     * this.droolsInstance.insert_Theatre(this.droolsParams, equivDto,
     * this.sessionId, this.currentKieSession); assertFalse(validTheatre);
     *
     * Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>)
     * droolsInstance.getGlobal(this.sessionId, this.currentKieSession,
     * "rejected"); List<Task> allTasks =
     * this.droolsInstance.receiveDtoAccepted(this.sessionId,
     * this.currentKieSession, this.droolsParams, satelliteId);
     *
     * System.out.println("all tasks planned :\n "); for (int i = 0; i <
     * allTasks.size(); i++) { System.out.println(allTasks.get(i)); }
     *
     * Map<String, Task> allAcceptedTasks =
     * droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
     * this.sessionId, this.currentKieSession); for (Map.Entry<String, Task>
     * allAcceptEl : allAcceptedTasks.entrySet()) {
     * System.out.println("ACCEPTED EL " + allAcceptEl.getValue()); }
     *
     * for (Map.Entry<String, Acquisition> allAcceptEl :
     * allAcqRejected.entrySet()) { System.out.println("REJECTED EL " +
     * allAcceptEl.getValue()); }
     *
     * for (int i = 0; i < this.droolsParams.getAllPartners().size(); i++) {
     * System.out.println("partner : " +
     * this.droolsParams.getAllPartners().get(i)); }
     *
     * this.droolsInstance.writeToFile(sessionId, this.currentKieSession,
     * this.droolsParams); }
     */

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_cmgAxis() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto4 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:56:00", "left", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);
        boolean insertDto = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(insertDto);

        DTO dto5 = this.du.createSingleDto("10/10/2017 14:55:00", "10/10/2017 14:56:00", "right", satelliteId);
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(4000);
        insertDto = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(insertDto);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_recoverTheatre_right() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_with_pitch_valid_recoverTheatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.setExtraCostLeft(2);

        double extraCostTheatre = 3;

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);
        dto1.setImageBIC(7);
        dto1.setUserInfo(userInfoList);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);
        dto2.setImageBIC(8);
        dto2.setUserInfo(userInfoList);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);
        dto3.setImageBIC(9);
        dto3.setUserInfo(userInfoList);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setExtraCostPitch(extraCostTheatre);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        p1 = this.droolsParams.getAllPartners().get(0);
        p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 after theatre : " + p1);
        assertEquals(9, p1.getUsedBIC(), 0);
        assertEquals(9, p2.getUsedBIC(), 0);

        System.out.println("p2 after theatre: " + p2);

        this.droolsInstance.restoreExtraCostTheatre(this.sessionId, this.currentKieSession, this.droolsParams);

        p1 = this.droolsParams.getAllPartners().get(0);
        p2 = this.droolsParams.getAllPartners().get(1);

        assertEquals(7.5, p1.getUsedBIC(), 0);
        assertEquals(7.5, p2.getUsedBIC(), 0);

        System.out.println("p1 after recover : " + p1);
        System.out.println("p2 after recover: " + p2);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, null);
        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        p1 = this.droolsParams.getAllPartners().get(0);
        p2 = this.droolsParams.getAllPartners().get(1);

        // assertEquals(0, p1.getUsedBIC(), 0);
        // assertEquals(0, p2.getUsedBIC(), 0);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */

    /*
     * @SuppressWarnings("unchecked")
     *
     * @Test public void
     * testInsert_theatre_with_pitch_valid_recoverTheatre_Left() throws
     * Exception { System.out.
     * println("\n\n\n\n running test : testInsert_theatre_with_pitch_valid_recoverTheatre"
     * );
     *
     * this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     *
     * this.droolsParams.getHpExclusionList().clear();
     * droolsParams.setExtraCostLeft(3);
     *
     * this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_"); String satelliteId = "SAT_1";
     *
     * List<DTO> allDtosIncludedInTheatre = new ArrayList<DTO>(); List<Maneuver>
     * maneuvers = new ArrayList<Maneuver>();
     *
     * Partner p1 = droolsParams.getAllPartners().get(0); Partner p2 =
     * droolsParams.getAllPartners().get(1);
     *
     * System.out.println("p1 before dto1: " + p1);
     * System.out.println("p2 before dto1: " + p2);
     *
     * List<UserInfo> userInfoList = new ArrayList<UserInfo>(); UserInfo
     * userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
     * UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(),
     * p2.getUgsId()); userInfoList.add(userInfo1); userInfoList.add(userInfo2);
     *
     * DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00",
     * "10/10/2017 14:00:00", "left", satelliteId);
     * dto1.setPol(Polarization.HH); dto1.setSizeH(4000); dto1.setImageBIC(7);
     * dto1.setUserInfo(userInfoList);
     *
     * DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00",
     * "10/10/2017 14:02:00", "left", satelliteId);
     * dto2.setPol(Polarization.HH); dto2.setSizeH(4000); dto2.setImageBIC(8);
     * dto2.setUserInfo(userInfoList);
     *
     * DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00",
     * "10/10/2017 14:04:00", "left", satelliteId);
     * dto3.setPol(Polarization.HH); dto3.setSizeH(4000); dto3.setImageBIC(9);
     * dto3.setUserInfo(userInfoList);
     *
     * allDtosIncludedInTheatre.add(dto1); allDtosIncludedInTheatre.add(dto2);
     * allDtosIncludedInTheatre.add(dto3);
     *
     * Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1",
     * "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId,
     * Actuator.CMGA); manInsideTheatre.setType(ManeuverType.PitchCPS);
     * maneuvers.add(manInsideTheatre);
     *
     * double extraCostPitch = 3;
     *
     * EquivalentDTO equivDto = new EquivalentDTO();
     * equivDto.setEquivalentDtoId("equivDto");
     * equivDto.setExtraCostPitch(extraCostPitch);
     * equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
     * equivDto.setManAssociated(maneuvers);
     * equivDto.setEquivType(PRMode.Theatre);
     * equivDto.setStartTime(dto1.getStartTime());
     * equivDto.setEndTime(dto3.getEndTime());
     *
     * boolean validTheatre =
     * this.droolsInstance.insert_Theatre(this.droolsParams, equivDto,
     * this.sessionId, this.currentKieSession); assertTrue(validTheatre);
     *
     * droolsInstance.writeToFile(sessionId, currentKieSession, droolsParams);
     *
     * Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>)
     * this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession,
     * "rejected"); List<Task> allTasks =
     * this.droolsInstance.receiveDtoAccepted(this.sessionId,
     * this.currentKieSession, this.droolsParams, satelliteId);
     *
     * p1 = droolsParams.getAllPartners().get(0); p2 =
     * droolsParams.getAllPartners().get(1);
     *
     * System.out.println("p1 after theatre : " + p1); assertEquals(5.5,
     * p1.getUsedBIC(), 0); assertEquals(5.5, p2.getUsedBIC(), 0);
     *
     * System.out.println("p2 after theatre: " + p2);
     *
     * droolsInstance.restoreExtraCostTheatre(sessionId, this.currentKieSession,
     * droolsParams);
     *
     * p1 = droolsParams.getAllPartners().get(0); p2 =
     * droolsParams.getAllPartners().get(1);
     *
     * // assertEquals(7.5, p1.getUsedBIC(), 0); // assertEquals(7.5,
     * p2.getUsedBIC(), 0);
     *
     * System.out.println("p1 after recover : " + p1);
     * System.out.println("p2 after recover: " + p2);
     *
     * System.out.println("all tasks planned :\n "); for (int i = 0; i <
     * allTasks.size(); i++) { System.out.println(allTasks.get(i)); }
     * System.out.println("\nrejected : " + allAcqRejected);
     *
     * Map<String, Task> allAcceptedTasks =
     * this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
     * this.sessionId, this.currentKieSession); for (Map.Entry<String, Task>
     * allAcceptEl : allAcceptedTasks.entrySet()) {
     * System.out.println("ACCEPTED EL " + allAcceptEl.getValue()); } }
     */

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto0 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto0.setPol(Polarization.HH);
        dto0.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        List<Maneuver> maneuvers = new ArrayList<>();

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "left", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis_Right_cancel_Both() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_with_pitch_valid_cmgAxis_Right");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        DTO dto4 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);
        allDtosIncludedInTheatre.add(dto4);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:02:40", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto2.getStartTime());
        equivDto.setEndTime(dto4.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "left", satelliteId);
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis_Right_cancel_Next() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_with_pitch_valid_cmgAxis_Right");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        DTO dto4 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);
        allDtosIncludedInTheatre.add(dto4);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:02:40", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto2.getStartTime());
        equivDto.setEndTime(dto4.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "left", satelliteId);
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis_Right_cancel_prev() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_with_pitch_valid_cmgAxis_Right");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        DTO dto4 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);
        allDtosIncludedInTheatre.add(dto4);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:02:40", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto2.getStartTime());
        equivDto.setEndTime(dto4.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "left", satelliteId);
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        DroolsOperations.retractSingleAcq(this.droolsParams, dto5.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis_Right_cancel_prev_insert() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_with_pitch_valid_cmgAxis_Right");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        DTO dto4 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);
        allDtosIncludedInTheatre.add(dto4);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:02:40", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto2.getStartTime());
        equivDto.setEndTime(dto4.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "left", satelliteId);
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        DroolsOperations.retractSingleAcq(this.droolsParams, dto5.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.internallyInconsistent);

        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        List<EquivalentDTO> equivDtoInitPlan = new ArrayList<>();
        equivDtoInitPlan.add(equivDto);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        // droolsInstance.initPlan(droolsParams, allAcceptedTasks,
        // equivDtoInitPlan, sessionId, currentKieSession, true);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis_left() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "left", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        DTO dto4 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "left", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);
        allDtosIncludedInTheatre.add(dto4);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:02:40", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto2.getStartTime());
        equivDto.setEndTime(dto4.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "left", satelliteId);
        dto5.setPol(Polarization.HH);
        dto5.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto6 = this.du.createSingleDto("10/10/2017 10:06:00", "10/10/2017 10:07:00", "right", satelliteId);
        dto6.setPol(Polarization.HH);
        dto6.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // droolsInstance.retractSingleAcq(droolsParams, dto5.getDtoId(),
        // sessionId, currentKieSession, ReasonOfReject.internallyInconsistent);
        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_with_pitch_valid_cmgAxis_fromRollToPitch() throws Exception
    {

        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto0 = this.du.createSingleDto("10/10/2017 15:00:00", "10/10/2017 15:01:00", "left", satelliteId);
        dto0.setPol(Polarization.HH);
        dto0.setSizeH(4000);

        assertTrue(this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession));

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "left", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "left", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:01:00", "right", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(4000);

        assertTrue(this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession));

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_inconsinstent_internal() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();
        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:01:40", "10/10/2017 14:03:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }

        for (Map.Entry<String, Acquisition> allAcceptEl : allAcqRejected.entrySet())
        {
            System.out.println("REJECTED EL " + allAcceptEl.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_inconsinstent_internal_tooClose() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_inconsinstent_internal_tooClose");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00.010", "10/10/2017 14:00:00.010", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00.010", "10/10/2017 14:02:03.010", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:02:06.000", "10/10/2017 14:03:00.010", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);

        List<Maneuver> maneuvers = new ArrayList<>();
        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00.000", "10/10/2017 14:04:00.000", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);
        equivDto.setManAssociated(maneuvers);

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }

        for (Map.Entry<String, Acquisition> allAcceptEl : allAcqRejected.entrySet())
        {
            System.out.println("REJECTED EL " + allAcceptEl.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_theatre_max_num_theatre_reached() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_theatre_max_num_theatre_reached");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        String satelliteId = "SAT_1";
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId(satelliteId).getSatelliteProperties().setMaxTheatreOnADay(1);
        this.droolsParams.getSatWithId("SAT_2").getSatelliteProperties().setMaxTheatreOnADay(1);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setImageBIC(2);
        dto1.setPrMode(PRMode.Theatre);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);
        dto2.setPrMode(PRMode.Theatre);
        dto2.setImageBIC(2);

        allDtosIncludedInTheatre.addAll(Arrays.asList(dto1, dto2));

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(null);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        List<Maneuver> maneuvers = new ArrayList<>();
        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        equivDto.setManAssociated(maneuvers);

        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        EquivalentDTO equivDto2 = new EquivalentDTO();

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:03:00", "10/10/2017 15:04:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setPrMode(PRMode.Theatre);
        dto3.setSizeH(4000);

        DTO dto4 = this.du.createSingleDto("10/10/2017 16:03:00", "10/10/2017 16:04:00", "right", satelliteId);
        dto4.setPol(Polarization.HH);
        dto4.setPrMode(PRMode.Theatre);
        dto4.setSizeH(4000);

        List<DTO> allDtosIncludedInTheatre2 = new ArrayList<>();
        allDtosIncludedInTheatre2.add(dto3);
        allDtosIncludedInTheatre2.add(dto4);

        equivDto2.setEquivalentDtoId("equivDto2");
        equivDto2.setAllDtoInEquivalentDto(allDtosIncludedInTheatre2);
        equivDto2.setEquivType(PRMode.Theatre);
        equivDto2.setStartTime(dto3.getStartTime());
        equivDto2.setEndTime(dto4.getEndTime());
        equivDto2.setExtraCostPitch(extraCostPitch);
        List<Maneuver> maneuvers2 = new ArrayList<>();
        Maneuver manInsideTheatre2 = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:04:00", "10/10/2017 16:14:00", satelliteId, Actuator.CMGA);
        manInsideTheatre2.setType(ManeuverType.PitchCPS);
        maneuvers2.add(manInsideTheatre2);
        equivDto2.setManAssociated(maneuvers2);

        validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto2, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");

        /*
         * allTasks =
         * this.droolsInstance.receiveDtoAccepted(this.currentKieSession,
         * this.droolsParams, satelliteId);
         *
         * System.out.println("all tasks planned :\n "); for (int i = 0; i <
         * allTasks.size(); i++) { System.out.println(allTasks.get(i)); }
         */
        System.out.println("\nrejected : " + allAcqRejected);

    }

    /**
     * Test insert remove acq overlap theatre.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testInsert_remove_Acq_overlap_theatre() throws Exception
    {
        System.out.println("\n\n\n\n running test : testInsert_remove_Acq_overlap_theatre");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:59:00", "10/10/2017 16:00:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());
        double extraCostPitch = 3;
        equivDto.setExtraCostPitch(extraCostPitch);
        Maneuver man = this.du.createManeuver("x", "x", dto1.getDtoId(), "10/10/2017 14:00:00", "10/10/2017 17:23:00", satelliteId, Actuator.CMGA);
        man.setType(ManeuverType.PitchCPS);
        equivDto.setManAssociated(new ArrayList<>(Arrays.asList(man)));
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        DTO nextDto = this.du.createSingleDto("10/10/2017 15:40:00", "10/10/2017 15:41:00", "left", satelliteId);
        nextDto.setPol(Polarization.HH);
        nextDto.setSizeH(4000);
        boolean insert = this.droolsInstance.insertDto(this.droolsParams, nextDto, this.sessionId, this.currentKieSession);
        assertFalse(insert);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testThirdScenarioDeltaFat() throws Exception
    {
        System.out.println("\n\n\n\n running test : test thirdScenarioDeltaFat");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Date startMH = DroolsUtils.createDate("14/09/2016 06:21:00");
        Date endMH = DroolsUtils.createDate("14/09/2016 18:21:00");
        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatWithId("1").getSatelliteProperties().setMaxTheatreOnADay(2);

        this.droolsParams.getCurrentMH().setStart(startMH);
        this.droolsParams.getCurrentMH().setStop(endMH);

        String satelliteId = "SAT_1";

        /*
         * PR1
         */

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO PR1_AR1_DTO1 = this.du.createSingleDto("14/09/2016 09:03:00", "14/09/2016 09:03:20", "right", satelliteId);
        PR1_AR1_DTO1.setPol(Polarization.HH);
        PR1_AR1_DTO1.setSizeH(4000);
        PR1_AR1_DTO1.setDtoId("PR1_AR1_DTO1");

        DTO PR1_AR2_DTO1 = this.du.createSingleDto("14/09/2016 09:03:10", "14/09/2016 09:03:30", "right", satelliteId);
        PR1_AR2_DTO1.setPol(Polarization.HH);
        PR1_AR2_DTO1.setSizeH(4000);
        PR1_AR2_DTO1.setDtoId("PR1_AR2_DTO1");

        DTO PR1_AR3_DTO1 = this.du.createSingleDto("14/09/2016 09:04:30", "14/09/2016 09:04:50", "right", satelliteId);
        PR1_AR3_DTO1.setPol(Polarization.HH);
        PR1_AR3_DTO1.setSizeH(4000);
        PR1_AR3_DTO1.setDtoId("PR1_AR3_DTO1");

        allDtosIncludedInTheatre.add(PR1_AR1_DTO1);
        allDtosIncludedInTheatre.add(PR1_AR2_DTO1);
        allDtosIncludedInTheatre.add(PR1_AR3_DTO1);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(PR1_AR1_DTO1.getStartTime());
        equivDto.setEndTime(PR1_AR3_DTO1.getEndTime());
        double extraCostPitch = 3;

        equivDto.setExtraCostPitch(extraCostPitch);
        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);
        List<Acquisition> allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }
        boolean expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR1_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreInternallyInconsistent);
        assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR1_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR2_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreInternallyInconsistent);
        // assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR2_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR1_AR3_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreInternallyInconsistent);
        assertTrue(expectedReason);
        /*
         * PR2
         */

        DTO PR2_AR1_DTO1 = this.du.createSingleDto("14/09/2016 11:00:00", "14/09/2016 11:00:20", "right", satelliteId);
        PR2_AR1_DTO1.setPol(Polarization.HH);
        PR2_AR1_DTO1.setSizeH(4000);
        PR2_AR1_DTO1.setDtoId("PR2_AR1_DTO1");

        boolean insert = this.droolsInstance.insertDto(this.droolsParams, PR2_AR1_DTO1, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        assertTrue(insert);

        DTO PR2_AR2_DTO1 = this.du.createSingleDto("14/09/2016 11:15:00", "14/09/2016 11:15:20", "right", satelliteId);
        PR2_AR2_DTO1.setPol(Polarization.HV);
        PR2_AR2_DTO1.setSizeH(4000);
        PR2_AR2_DTO1.setSizeV(4000);
        PR2_AR2_DTO1.setDtoId("PR2_AR2_DTO1");

        insert = this.droolsInstance.insertDto(this.droolsParams, PR2_AR2_DTO1, this.sessionId, this.currentKieSession);
        assertTrue(insert);

        DTO PR2_AR3_DTO1 = this.du.createSingleDto("14/09/2016 10:52:00", "14/09/2016 10:52:20", "right", satelliteId);
        PR2_AR3_DTO1.setPol(Polarization.HH);
        PR2_AR3_DTO1.setSizeH(4000);
        PR2_AR3_DTO1.setDtoId("PR2_AR3_DTO1");

        insert = this.droolsInstance.insertDto(this.droolsParams, PR2_AR3_DTO1, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        assertTrue(insert);

        /*
         * PR3
         */

        List<DTO> allDtosIncludedInTheatre2 = new ArrayList<>();

        DTO PR3_AR1_DTO1 = this.du.createSingleDto("14/09/2016 10:52:10", "14/09/2016 10:52:30", "right", satelliteId);
        PR3_AR1_DTO1.setPol(Polarization.HH);
        PR3_AR1_DTO1.setSizeH(4000);
        PR3_AR1_DTO1.setDtoId("PR3_AR1_DTO1");

        DTO PR3_AR2_DTO1 = this.du.createSingleDto("14/09/2016 10:53:00", "14/09/2016 10:53:20", "right", satelliteId);
        PR3_AR2_DTO1.setPol(Polarization.HH);
        PR3_AR2_DTO1.setSizeH(4000);
        PR3_AR2_DTO1.setDtoId("PR3_AR2_DTO1");

        DTO PR3_AR3_DTO1 = this.du.createSingleDto("14/09/2016 10:51:00", "14/09/2016 10:51:20", "right", satelliteId);
        PR3_AR3_DTO1.setPol(Polarization.HH);
        PR3_AR3_DTO1.setSizeH(4000);
        PR3_AR3_DTO1.setDtoId("PR3_AR3_DTO1");

        allDtosIncludedInTheatre2.add(PR3_AR1_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR2_DTO1);
        allDtosIncludedInTheatre2.add(PR3_AR3_DTO1);

        EquivalentDTO equivDto2 = new EquivalentDTO();
        equivDto2.setEquivalentDtoId("equivDto2");
        equivDto2.setAllDtoInEquivalentDto(allDtosIncludedInTheatre2);
        equivDto2.setManAssociated(null);
        equivDto2.setEquivType(PRMode.Theatre);
        equivDto2.setStartTime(PR3_AR3_DTO1.getStartTime());
        equivDto2.setManAssociated(maneuvers);
        equivDto2.setEndTime(PR3_AR2_DTO1.getEndTime());
        extraCostPitch = 3;
        equivDto2.setExtraCostPitch(extraCostPitch);
        validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto2, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        assertFalse(validTheatre);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR3_AR2_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreOverlapAcquisition);
        assertTrue(expectedReason);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR3_AR3_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.theatreOverlapAcquisition);
        assertTrue(expectedReason);

        /*
         * PR4
         */

        List<DTO> allDtosIncludedInTheatre3 = new ArrayList<>();

        DTO PR4_AR1_DTO1 = this.du.createSingleDto("14/09/2016 09:03:00", "14/09/2016 09:03:20", "right", satelliteId);
        PR4_AR1_DTO1.setPol(Polarization.HH);
        PR4_AR1_DTO1.setSizeH(4000);
        PR4_AR1_DTO1.setDtoId("PR4_AR1_DTO1");

        DTO PR4_AR2_DTO1 = this.du.createSingleDto("14/09/2016 09:03:50", "14/09/2016 09:04:10", "right", satelliteId);
        PR4_AR2_DTO1.setPol(Polarization.HH);
        PR4_AR2_DTO1.setSizeH(4000);
        PR4_AR2_DTO1.setDtoId("PR4_AR2_DTO1");

        DTO PR4_AR3_DTO1 = this.du.createSingleDto("14/09/2016 09:04:30", "14/09/2016 09:04:50", "right", satelliteId);
        PR4_AR3_DTO1.setPol(Polarization.HH);
        PR4_AR3_DTO1.setSizeH(4000);
        PR4_AR3_DTO1.setDtoId("PR4_AR3_DTO1");

        allDtosIncludedInTheatre3.add(PR4_AR1_DTO1);
        allDtosIncludedInTheatre3.add(PR4_AR2_DTO1);
        allDtosIncludedInTheatre3.add(PR4_AR3_DTO1);

        EquivalentDTO equivDto3 = new EquivalentDTO();
        equivDto3.setEquivalentDtoId("equivDto3");
        equivDto3.setAllDtoInEquivalentDto(allDtosIncludedInTheatre3);
        equivDto3.setManAssociated(maneuvers);
        equivDto3.setEquivType(PRMode.Theatre);
        equivDto3.setStartTime(PR4_AR1_DTO1.getStartTime());
        equivDto3.setEndTime(PR4_AR3_DTO1.getEndTime());
        extraCostPitch = 3;
        equivDto3.setExtraCostPitch(extraCostPitch);
        validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto3, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        assertTrue(validTheatre);

        /*
         * PR5
         */

        DTO PR5_AR1_DTO1 = this.du.createSingleDto("14/09/2016 12:00:00", "14/09/2016 12:00:20", "right", satelliteId);
        PR5_AR1_DTO1.setPol(Polarization.HH);
        PR5_AR1_DTO1.setSizeH(4000);
        PR5_AR1_DTO1.setDtoId("PR5_AR1_DTO1");

        insert = this.droolsInstance.insertDto(this.droolsParams, PR5_AR1_DTO1, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

       // assertTrue(insert);

        DTO PR5_AR2_DTO1 = this.du.createSingleDto("14/09/2016 11:55:00", "14/09/2016 11:55:20", "right", satelliteId);
        PR5_AR2_DTO1.setPol(Polarization.HH);
        PR5_AR2_DTO1.setSizeH(4000);
        PR5_AR2_DTO1.setDtoId("PR5_AR2_DTO1");

        insert = this.droolsInstance.insertDto(this.droolsParams, PR5_AR2_DTO1, this.sessionId, this.currentKieSession);
        //assertTrue(insert);

        DTO PR5_AR3_DTO1 = this.du.createSingleDto("14/09/2016 09:03:25", "14/09/2016 09:03:40", "right", satelliteId);
        PR5_AR3_DTO1.setPol(Polarization.HH);
        PR5_AR3_DTO1.setSizeH(4000);
        PR5_AR3_DTO1.setDtoId("PR5_AR3_DTO1");

        insert = this.droolsInstance.insertDto(this.droolsParams, PR5_AR3_DTO1, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

        assertFalse(insert);

        expectedReason = this.du.checkIfContainsTheExpectedReason(PR5_AR3_DTO1.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapTheatre);
        assertTrue(expectedReason);

        System.out.println("max number of theatre in a day : " + this.droolsParams.getSatWithId("1").getSatelliteProperties().getMaxTheatreOnADay());

        /*
         * PR6
         */

        List<DTO> allDtosIncludedInTheatre4 = new ArrayList<>();

        DTO PR6_AR1_DTO1 = this.du.createSingleDto("14/09/2016 13:00:00", "14/09/2016 13:00:20", "right", satelliteId);
        PR6_AR1_DTO1.setPol(Polarization.HH);
        PR6_AR1_DTO1.setSizeH(4000);
        PR6_AR1_DTO1.setDtoId("PR6_AR1_DTO1");

        DTO PR6_AR2_DTO1 = this.du.createSingleDto("14/09/2016 13:01:00", "14/09/2016 13:01:20", "right", satelliteId);
        PR6_AR2_DTO1.setPol(Polarization.HH);
        PR6_AR2_DTO1.setSizeH(4000);
        PR6_AR2_DTO1.setDtoId("PR6_AR2_DTO1");

        DTO PR6_AR3_DTO1 = this.du.createSingleDto("14/09/2016 12:59:30", "14/09/2016 12:59:50", "right", satelliteId);
        PR6_AR3_DTO1.setPol(Polarization.HH);
        PR6_AR3_DTO1.setSizeH(4000);
        PR6_AR3_DTO1.setDtoId("PR6_AR3_DTO1");

        allDtosIncludedInTheatre4.add(PR6_AR1_DTO1);
        allDtosIncludedInTheatre4.add(PR6_AR2_DTO1);
        allDtosIncludedInTheatre4.add(PR6_AR3_DTO1);

        EquivalentDTO equivDto4 = new EquivalentDTO();
        equivDto4.setEquivalentDtoId("equivDto4");
        equivDto4.setAllDtoInEquivalentDto(allDtosIncludedInTheatre4);
        equivDto4.setManAssociated(maneuvers);
        equivDto4.setEquivType(PRMode.Theatre);
        equivDto4.setStartTime(PR6_AR3_DTO1.getStartTime());
        equivDto4.setEndTime(PR6_AR2_DTO1.getEndTime());
        extraCostPitch = 3;
        equivDto4.setExtraCostPitch(extraCostPitch);
        validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto4, this.sessionId, this.currentKieSession);

        allAcceptedAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, satelliteId);

        for (int i = 0; i < allAcceptedAcq.size(); i++)
        {
            System.out.println("accepted : " + allAcceptedAcq.get(i));
        }

        this.rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        for (Map.Entry<String, Acquisition> rejected : this.rejectedElements.entrySet())
        {
            System.out.println("rejected : " + rejected.getValue());
        }

       // assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        for (Map.Entry<String, Acquisition> allRejected : allAcqRejected.entrySet())
        {
            System.out.println("\nrejected : " + allRejected.getValue());

        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
}
