/**
*
* MODULE FILE NAME:	TestRetractAcq.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		17 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 17 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * The Class TestRetractAcqRule.
 *
 * @author fpedrola
 */
public class TestRetractAcqRule
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "retractAcq";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test retract acq.
     *
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Test
    public void test_retractAcq() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : retractAcq");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        int maxNumberPrTypeForTest = 2;
        String satForTest = "SAT_1";

        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", satForTest);
        double imageBicDto1 = 3;
        dto1.setPol(Polarization.HH);
        dto1.setRevolutionNumber(4);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        assertEquals(0, rejected.size());

        System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        assertEquals(2, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(1, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(1, resources.getSilentFunctionAssociatedToSat(satForTest).size());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());
        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }
    
    
    /**
     * Test retract acq.
     *
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Test
    public void test_retractAcqVU() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_retractAcqVU");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        int maxNumberPrTypeForTest = 2;
        String satForTest = "SAT_1";

        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);

        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", satForTest);
        double imageBicDto1 = 3;
        dto1.setPol(Polarization.HH);
        dto1.setRevolutionNumber(4);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.LMP);
        dto1.setImageBIC(imageBicDto1);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:20:00", "10/10/2017 17:40:00", "right", satForTest);
        double imageBicDto2 = 3;
        dto2.setPol(Polarization.HH);
        dto2.setRevolutionNumber(4);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.VU);
        dto2.setImageBIC(imageBicDto2);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto1.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        assertEquals(1, rejected.size());

        System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        assertEquals(2, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(1, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(1, resources.getSilentFunctionAssociatedToSat(satForTest).size());

//        this.droolsInstance.clearSessionInstance(this.sessionId, this.currentKieSession, droolsParams, true);
//
//        System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
//        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
//        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
//        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
//        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());
//        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
//        
//        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, droolsParams);
    }

    /**
     * Test retract acq.
     *
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Test
    public void test_retractAcqNoBic() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_retractAcqNoBic");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        int maxNumberPrTypeForTest = 2;
        String satForTest = "SAT_1";

        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());
        this.droolsParams.getAllPartners().get(0).setMaxBICAvailable(2);
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", satForTest);
        double imageBicDto1 = 3;
        dto1.setPol(Polarization.HH);
        dto1.setRevolutionNumber(4);
        UserInfo userInfo = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), null);
        dto1.getUserInfo().clear();
        dto1.getUserInfo().add(userInfo);

        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        assertEquals(1, rejected.size());

        // System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        // assertEquals(1,
        // resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        // assertEquals(1,
        // resources.getEssFunctionAssociatedToSat(satForTest).size());
        // assertEquals(0,
        // resources.getRampFunctionAssociatedToSat(satForTest).size());
        // assertEquals(1,
        // resources.getSilentFunctionAssociatedToSat(satForTest).size());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());
        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
    }

    /**
     * Test retract acq.
     *
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    @Test
    public void test_retractAcqNoNeoBic() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_retractAcqNoBic");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        int maxNumberPrTypeForTest = 2;
        String satForTest = "SAT_1";

        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());
        this.droolsParams.getAllPartners().get(0).setMaxNEOBicAvailable(2);
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", satForTest);
        double imageBicDto1 = 3;
        dto1.setPol(Polarization.HH);
        dto1.setRevolutionNumber(4);
        dto1.setPreviousSession(true);
        dto1.setNeoAvailable(true);
        UserInfo userInfo = new UserInfo(null, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), null);
        dto1.getUserInfo().clear();
        dto1.getUserInfo().add(userInfo);

        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        assertEquals(1, rejected.size());

        // System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        // assertEquals(1,
        // resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        // assertEquals(1,
        // resources.getEssFunctionAssociatedToSat(satForTest).size());
        // assertEquals(0,
        // resources.getRampFunctionAssociatedToSat(satForTest).size());
        // assertEquals(1,
        // resources.getSilentFunctionAssociatedToSat(satForTest).size());

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        System.out.println(resources.getManeuverFunctionAssociatedToSat(satForTest));
        assertEquals(0, resources.getManeuverFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getEssFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getRampFunctionAssociatedToSat(satForTest).size());
        assertEquals(0, resources.getSilentFunctionAssociatedToSat(satForTest).size());
        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

}
