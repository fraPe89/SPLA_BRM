/**
*
* MODULE FILE NAME:	TestSilentRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		31 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 31 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resources.Satellite;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Silent;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;
import com.nais.spla.brm.library.main.ontology.utils.ResourceMaxValue;

/**
 * @author fpedrola
 *
 */
/**
 * @author fpedrola
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestSilentRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private TreeMap<Long, EnergyAssociatedToTask> silentFunction = null;
    private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tStandardMap = null;
    private Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> tThresholdMap = null;
    private TaskPlanned taskPlanned = null;
    Map<TypeOfAcquisition, Double> powersSensorMode = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "0010";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.silentFunction = new TreeMap<>();
        this.taskPlanned = new TaskPlanned();
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void A_Test_Plan_Silent_If_There_Isn_t_Previous() throws Exception
    {
        System.out.println("Running test : A_Test_Plan_Silent_If_There_Isn_t_Previous \n\n");

        // initialize the values to compute silents time, from acq STRIPMAP to
        // PINGPONG
        double tStandardForTest = 5;
        double tThresholdForTest = 4;
        double tReconfForTest = 2;
        double powerPingpongFortest = 13548.15;
        double powerStripmapFortest = 13548.15;
        long maxSilentForTest = 1000;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        setupCheckOnOrbitForSilentTest(maxSilentForTest);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        setupEnvironmentForSilentTests(this.sessionId, this.currentKieSession, tStandardForTest, tThresholdForTest, tReconfForTest, powerPingpongFortest, powerStripmapFortest);
        Satellite satForTest = this.droolsParams.getSatWithId("SAT_1");
        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // since the acquisition is accepted, it has his silent associated
        assertEquals(1, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        Acquisition acq1 = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").get(dto1.getDtoId());
        Silent sil1 = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1").get(dto1.getDtoId());

        long expectedStartTimeSilentAsLong = (long) (acq1.getStartTime().getTime() - (tReconfForTest * 1000));
        Date expectedStartTime = new Date(expectedStartTimeSilentAsLong);

        double expectedEnergySilent = ((powerPingpongFortest / powerStripmapFortest) * tReconfForTest * satForTest.getSatelliteProperties().getSilentFactor());
        System.out.println("expected silent energy :" + expectedEnergySilent);
        assertEquals(acq1.getStartTime(), sil1.getEndTime());
        assertEquals(expectedStartTime, sil1.getStartTime());
        assertEquals(expectedEnergySilent, sil1.getEnergy(), 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void B_Test_Plan_Silent_Based_On_Tstandard() throws Exception
    {
        System.out.println("Running test : B_Test_Plan_Silent_Based_On_Tstandard \n\n");

        // initialize the values for compute silents time, from acq STRIPMAP to
        // PINGPONG
        double tStandardForTest = 4;
        double tThresholdForTest = 5;
        double tReconfForTest = 3;
        double powerPingpongFortest = 13548.15;
        double powerStripmapFortest = 13548.15;
        Map<TypeOfAcquisition, Double> nestedStandardMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> nestedThresholdMap = new HashMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 1000;
        double maxThresholdForTest = 2000;
        int maxManForTest = 2;
        int maxManRWForTest = 4;
        int maxManCMGAForTest = 1;
        double minTimeEclipse = 700;

        Satellite satForTest = this.droolsParams.getSatWithId("SAT_1");

        ResourceMaxValue resourcesForTest = new ResourceMaxValue(97, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        satForTest.getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<TypeOfAcquisition, Double> powerSensorMode = (Map<TypeOfAcquisition, Double>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "powersSensorMode");
        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);
        // receiving correct values of silents time from the configuration files
        this.tStandardMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tStandardMap");
        this.tThresholdMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tThresholdMap");

        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);

        // populate the variables with the values taken from the configuration
        // files
        nestedStandardMap.put(TypeOfAcquisition.STRIPMAP, tStandardForTest);
        nestedStandardMap.put(TypeOfAcquisition.PINGPONG, tReconfForTest);
        this.tStandardMap.put(TypeOfAcquisition.PINGPONG, nestedStandardMap);

        nestedThresholdMap.put(TypeOfAcquisition.STRIPMAP, tThresholdForTest);
        this.tThresholdMap.put(TypeOfAcquisition.PINGPONG, nestedThresholdMap);

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:43:09", "10/10/2017 07:43:20", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // since the acquisition is accepted, it has his silent associated
        assertEquals(2, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        Acquisition acq2 = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").get(dto2.getDtoId());
        Silent sil2 = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1").get(dto2.getDtoId());

        long expectedStartTimeSilentAsLong = (long) (acq2.getStartTime().getTime() - (tStandardForTest * 1000));
        Date expectedStartTime = new Date(expectedStartTimeSilentAsLong);
        double expectedEnergySilent = ((powerPingpongFortest / powerStripmapFortest) * tStandardForTest * satForTest.getSatelliteProperties().getSilentFactor());

        assertEquals(acq2.getStartTime(), sil2.getEndTime());
        assertEquals(expectedStartTime, sil2.getStartTime());
        assertEquals(expectedEnergySilent, sil2.getEnergy(), 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void C_Test_Remove_Silent_If_Related_Acq_Is_Rejected_Without_Loan_Ess() throws Exception
    {
        System.out.println("Running test : C_Test_Remove_Silent_If_Related_Acq_Is_Rejected_Without_Loan_Ess \n\n");

        // initialize the values for compute silents time, from acq STRIPMAP to
        // PINGPONG
        double tStandardForTest = 4, tThresholdForTest = 5, tReconfForTest = 3;
        double powerPingpongFortest = 13548.15;
        double powerStripmapFortest = 13548.15;
        Map<TypeOfAcquisition, Double> nestedStandardMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> nestedThresholdMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> powerSensorMode = new HashMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 1000;
        double maxThresholdForTest = 2000;
        int maxManForTest = 2;
        int maxManRWForTest = 4;
        int maxManCMGAForTest = 1;
        double minTimeEclipse = 700;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(97, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // receiving correct values of silents time from the configuration files
        this.tStandardMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tStandardMap");
        this.tThresholdMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tThresholdMap");

        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);
        // populate the variables with the values taken from the configuration
        // files
        nestedStandardMap.put(TypeOfAcquisition.STRIPMAP, tStandardForTest);
        nestedStandardMap.put(TypeOfAcquisition.PINGPONG, tReconfForTest);
        this.tStandardMap.put(TypeOfAcquisition.PINGPONG, nestedStandardMap);

        nestedThresholdMap.put(TypeOfAcquisition.STRIPMAP, tThresholdForTest);
        this.tThresholdMap.put(TypeOfAcquisition.PINGPONG, nestedThresholdMap);

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // since the acquisition is accepted, it has his silent associated
        assertEquals(1, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        Acquisition acq1 = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").get(dto1.getDtoId());
        Silent sil1 = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1").get(dto1.getDtoId());

        long expectedStartTimeSilentAsLong = (long) (acq1.getStartTime().getTime() - (tReconfForTest * 1000));
        Date expectedStartTime = new Date(expectedStartTimeSilentAsLong);

        double expectedEnergySilent = ((powerPingpongFortest / powerStripmapFortest) * tReconfForTest * this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getSilentFactor());
        System.out.println("expectedEnergySilent : " + expectedEnergySilent);
        assertEquals(acq1.getStartTime(), sil1.getEndTime());
        assertEquals(expectedStartTime, sil1.getStartTime());
        assertEquals(expectedEnergySilent, sil1.getEnergy(), 0);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        this.silentFunction = resources.getSilentFunctionAssociatedToSat(dto1.getSatelliteId());
        Silent extractedSilent = (Silent) this.silentFunction.get(sil1.getStartTime().getTime()).getTask();
        assertEquals(sil1, extractedSilent);
        assertEquals(1, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void D_Test_Remove_Silent_If_Related_Acq_Is_Rejected_Loan_Ess() throws Exception
    {
        System.out.println("Running test : D_Test_Remove_Silent_If_Related_Acq_Is_Rejected_Loan_Ess \n\n");

        // initialize the values for compute silents time, from acq STRIPMAP to
        // PINGPONG
        double tStandardForTest = 4, tThresholdForTest = 5, tReconfForTest = 3;
        double powerPingpongFortest = 13548.15;
        double powerStripmapFortest = 13548.15;
        Map<TypeOfAcquisition, Double> nestedStandardMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> nestedThresholdMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> powerSensorMode = new HashMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 0;
        double maxThresholdForTest = 2000;
        int maxManForTest = 2;
        int maxManRWForTest = 4;
        int maxManCMGAForTest = 1;
        double minTimeEclipse = 700;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(97, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // receiving correct values of silents time from the configuration files
        this.tStandardMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tStandardMap");
        this.tThresholdMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tThresholdMap");

        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);
        // populate the variables with the values taken from the configuration
        // files
        nestedStandardMap.put(TypeOfAcquisition.STRIPMAP, tStandardForTest);
        nestedStandardMap.put(TypeOfAcquisition.PINGPONG, tReconfForTest);
        this.tStandardMap.put(TypeOfAcquisition.PINGPONG, nestedStandardMap);

        nestedThresholdMap.put(TypeOfAcquisition.STRIPMAP, tThresholdForTest);
        this.tThresholdMap.put(TypeOfAcquisition.PINGPONG, nestedThresholdMap);

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // since the acquisition is accepted, it has his silent associated
        assertEquals(1, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        Acquisition acq1 = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").get(dto1.getDtoId());
        Silent sil1 = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1").get(dto1.getDtoId());

        long expectedStartTimeSilentAsLong = (long) (acq1.getStartTime().getTime() - (tReconfForTest * 1000));
        Date expectedStartTime = new Date(expectedStartTimeSilentAsLong);

        double expectedEnergySilent = ((powerPingpongFortest / powerStripmapFortest) * tReconfForTest * this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getSilentFactor());
        System.out.println("expectedEnergySilent : " + expectedEnergySilent);
        assertEquals(acq1.getStartTime(), sil1.getEndTime());
        assertEquals(expectedStartTime, sil1.getStartTime());
        assertEquals(expectedEnergySilent, sil1.getEnergy(), 0);

        ResourceFunctions resources = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        this.silentFunction = resources.getSilentFunctionAssociatedToSat(dto1.getSatelliteId());
        Silent extractedSilent = (Silent) this.silentFunction.get(sil1.getStartTime().getTime()).getTask();
        assertEquals(sil1, extractedSilent);
        assertEquals(1, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, this.taskPlanned.receiveAllSilent(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1").size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void E_Test_Silent_Receive_A_Loan_Of_Ess() throws Exception
    {
        System.out.println("Running test : E_Test_Silent_Receive_A_Loan_Of_Ess \n\n");
        Map<String, Silent> allSilents = null;
        double contSilentEnergy = 0;
        // initialize the values for compute silents time, from acq STRIPMAP to
        // PINGPONG
        double tStandardForTest = 34;
        double tThresholdForTest = 200;
        double tReconfForTest = 23;
        double powerPingpongFortest = 2200;
        double powerStripmapFortest = 2500;
        Map<TypeOfAcquisition, Double> nestedStandardMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> nestedThresholdMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> powerSensorMode = new HashMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 1;
        double maxThresholdForTest = 2000;
        int maxManForTest = 2;
        int maxManRWForTest = 4;
        int maxManCMGAForTest = 1;
        double minTimeEclipse = 700;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(97, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // receiving correct values of silents time from the configuration files
        this.tStandardMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tStandardMap");
        this.tThresholdMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tThresholdMap");

        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);

        // populate the variables with the values taken from the configuration
        // files
        nestedStandardMap.put(TypeOfAcquisition.STRIPMAP, tStandardForTest);
        nestedStandardMap.put(TypeOfAcquisition.PINGPONG, tReconfForTest);
        this.tStandardMap.put(TypeOfAcquisition.PINGPONG, nestedStandardMap);

        nestedThresholdMap.put(TypeOfAcquisition.STRIPMAP, tThresholdForTest);
        nestedThresholdMap.put(TypeOfAcquisition.PINGPONG, tThresholdForTest);

        this.tThresholdMap.put(TypeOfAcquisition.PINGPONG, nestedThresholdMap);

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        allSilents = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1");
        Silent sil1 = allSilents.get(dto1.getDtoId());
        System.out.println("silent associated to acq 1 :" + sil1);
        contSilentEnergy = contSilentEnergy + sil1.getEnergy();

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:46:00", "10/10/2017 07:47:00", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        assertTrue(accepted);

        allSilents = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1");
        Silent sil2 = allSilents.get(dto2.getDtoId());
        System.out.println("silent associated to acq 2 :" + sil2);
        contSilentEnergy = contSilentEnergy + sil2.getEnergy();
        

        assertTrue(contSilentEnergy > maxSilentForTest);
        // assertTrue(sil2.getLoanFromEss() > 0);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("ESS FUNCTION :" + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }

        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");

        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void F_Test_Silent_Receive_A_Loan_Of_Ess_no_Energy() throws Exception
    {
        System.out.println("Running test : F_Test_Silent_Receive_A_Loan_Of_Ess_no_Energy \n\n");
        Map<String, Silent> allSilents = null;
        double contSilentEnergy = 0;
        this.sessionId = "loanForSilent";
        // initialize the values for compute silents time, from acq STRIPMAP to
        // PINGPONG
        double tStandardForTest = 34;
        double tThresholdForTest = 200;
        double tReconfForTest = 23;
        double powerPingpongFortest = 2200;
        double powerStripmapFortest = 2500;
        Map<TypeOfAcquisition, Double> nestedStandardMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> nestedThresholdMap = new HashMap<>();
        Map<TypeOfAcquisition, Double> powerSensorMode = new HashMap<>();
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        long maxSilentForTest = 1;
        double maxThresholdForTest = 65;
        int maxManForTest = 2;
        int maxManRWForTest = 4;
        int maxManCMGAForTest = 1;
        double minTimeEclipse = 700;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(97, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        // this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);
        this.droolsParams.getAllSat().get(1).getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);

        // receiving correct values of silents time from the configuration files
        System.out.println("all check on orbit : " + this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits());
        System.out.println("all check on orbit : " + this.droolsParams.getAllSat().get(0).getSatelliteProperties().getAllChecksOnOrbits());

        System.out.println("all check on orbit : " + this.droolsParams.getAllSat().get(1).getSatelliteProperties().getAllChecksOnOrbits());

        // System.out.println("max silent : "+);
        this.tStandardMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tStandardMap");
        this.tThresholdMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "tThresholdMap");

        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);

        // populate the variables with the values taken from the configuration
        // files
        nestedStandardMap.put(TypeOfAcquisition.STRIPMAP, tStandardForTest);
        nestedStandardMap.put(TypeOfAcquisition.PINGPONG, tReconfForTest);
        this.tStandardMap.put(TypeOfAcquisition.PINGPONG, nestedStandardMap);

        nestedThresholdMap.put(TypeOfAcquisition.STRIPMAP, tThresholdForTest);
        nestedThresholdMap.put(TypeOfAcquisition.PINGPONG, tThresholdForTest);

        this.tThresholdMap.put(TypeOfAcquisition.PINGPONG, nestedThresholdMap);

        // inserting a valid dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:42:00", "10/10/2017 07:43:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        allSilents = this.droolsInstance.receiveAllSilentAsMap(this.sessionId, this.currentKieSession, "SAT_1");
        Silent sil1 = allSilents.get(dto1.getDtoId());
        System.out.println("silent associated to acq 1 :" + sil1);
        contSilentEnergy = contSilentEnergy + sil1.getEnergy();

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:46:00", "10/10/2017 07:47:00", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        // assertFalse(accepted);
        contSilentEnergy = contSilentEnergy + sil1.getEnergy();

        System.out.println("cont silent energy : " + contSilentEnergy);

        assertTrue(contSilentEnergy > maxSilentForTest);
        // assertTrue(sil2.getLoanFromEss() > 0);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        System.out.println("ESS FUNCTION :" + resFunc.getEssFunctionAssociatedToSat("SAT_1"));
        for (Map.Entry<Long, Maneuver> elementInMap : resFunc.getAllManeuversSat1().entrySet())
        {
            System.out.println("RETURNED MAN FUNCTION:" + elementInMap.getValue());
        }

        List<Maneuver> allManInDrools = this.taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allManInDrools.size(); i++)
        {
            System.out.println("RETURNED MAN DROOLS:" + allManInDrools.get(i));
        }

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks : ");

        for (Map.Entry<String, Task> elementsInmap : allTasks.entrySet())
        {
            System.out.println(elementsInmap.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * @param tStandardForTest
     * @param tThresholdForTest
     * @param tReconfForTest
     * @param powerPingpongFortest
     * @param powerStripmapFortest
     */
    @SuppressWarnings("unchecked")
    private void setupEnvironmentForSilentTests(String droolsSession, int activeInstance, double tStandardForTest, double tThresholdForTest, double tReconfForTest, double powerPingpongFortest, double powerStripmapFortest)
    {
        this.tStandardMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(droolsSession, activeInstance, "tStandardMap");
        Map<TypeOfAcquisition, Double> nestedStandardMap = new HashMap<>();
        // populate the variables with the values taken from the configuration
        // files
        nestedStandardMap.put(TypeOfAcquisition.STRIPMAP, tStandardForTest);
        nestedStandardMap.put(TypeOfAcquisition.PINGPONG, tReconfForTest);
        this.tStandardMap.put(TypeOfAcquisition.PINGPONG, nestedStandardMap);

        // receiving correct values of silents time from the configuration files
        this.tThresholdMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(droolsSession, activeInstance, "tThresholdMap");
        Map<TypeOfAcquisition, Double> nestedThresholdMap = new HashMap<>();
        nestedThresholdMap.put(TypeOfAcquisition.STRIPMAP, tThresholdForTest);
        this.tThresholdMap.put(TypeOfAcquisition.PINGPONG, nestedThresholdMap);

        Map<TypeOfAcquisition, Double> powerSensorMode = (Map<TypeOfAcquisition, Double>) this.droolsInstance.getGlobal(droolsSession, activeInstance, "powersSensorMode");
        powerSensorMode.put(TypeOfAcquisition.PINGPONG, powerPingpongFortest);
        powerSensorMode.put(TypeOfAcquisition.STRIPMAP, powerStripmapFortest);
    }

    /**
     * check on orbit for silent test.
     *
     * @param maxSilentForTest
     *            the new up check on orbit for silent test
     */
    private void setupCheckOnOrbitForSilentTest(long maxSilentForTest)
    {
        Map<Double, ResourceMaxValue> allChecksOnOrbitsForTest = new HashMap<>();
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().clear();
        double maxThresholdForTest = 2000;
        int maxManForTest = -1;
        int maxManRWForTest = -1;
        int maxManCMGAForTest = -1;
        double minTimeEclipse = 700;
        ResourceMaxValue resourcesForTest = new ResourceMaxValue(97, maxSilentForTest, maxThresholdForTest, maxManForTest, maxManRWForTest, maxManCMGAForTest, minTimeEclipse);
        allChecksOnOrbitsForTest.put(1.0, resourcesForTest);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setAllChecksOnOrbits(allChecksOnOrbitsForTest);
    }

}
