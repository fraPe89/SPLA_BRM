/**
*
* MODULE FILE NAME:	TestSensorModeRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		27 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 27 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * @author fpedrola
 *
 */
public class TestSensorModeRule
{

    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;

    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestSensorModeRule";
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void A_Test_Acq_Duration_Exceeds_SensorMode_Max_Time() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test :  A_Test_Acq_Duration_Exceeds_SensorMode_Max_Time \n\n");
        Map<TypeOfAcquisition, Double> maxTimeSensorMode = (Map<TypeOfAcquisition, Double>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "maxDurationSensorMode");
        double maxTimeRelatedOfThisDto = maxTimeSensorMode.get(TypeOfAcquisition.PINGPONG);
        int durationOfDto = (int) (maxTimeRelatedOfThisDto + 8);
        System.out.println("max time : " + maxTimeRelatedOfThisDto);
        System.out.println("duration of dto : " + durationOfDto);
        DTO dto = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:40:00", "left", "SAT_1");
        dto.setArID("ar001");
        dto.setPol(Polarization.HH);

        System.out.println("created acq : " + dto);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(1, this.rejectedElements.size());

        boolean found = this.du.checkIfContainsTheExpectedReason(dto.getDtoId(), this.rejectedElements, ReasonOfReject.exceededSensorModeMaxDuration);
        assertTrue(found);

    }
}
