
package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.HPExclusion;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class TestHpSegmentExclusion
{

    /** The session id. */
    private String sessionId = null;

    /** The rejected elements. */
    private Map<String, Acquisition> rejectedElements = null;

    private StubResources stub = new StubResources();
    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "HPsegmentRule";
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down. After each test, all the sessions of Drools will be closed.
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    // TODO: decommentare test quando torner� effettiva la regola delle
    // hpExclusion

    /**
     * Test decrement ar : if the partner that we are processed has more than
     * one ar associated
     */
    @Test
    public void TestRejectHpOverlapSegment_total_overlap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        // create a dummy hp segment
        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:58:00", "10/10/2017 15:00:00", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * Test decrement ar : if the partner that we are processed has more than
     * one ar associated
     */
    @Test
    public void TestRejectHpOverlapSegment_total_overlap_VU() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        // create a dummy hp segment
        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);
        DTO dto2 = this.du.createSingleDto("10/10/2017 14:58:00", "10/10/2017 15:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.VU);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * Test decrement ar : if the partner that we are processed has more than
     * one ar associated
     */
    @Test
    public void TestRejectHpOverlapSegment_total_overlap_rankedRoutine() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        // create a dummy hp segment
        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:58:00", "10/10/2017 15:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.LMP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void TestRejectHpOverlapSegment_partial_overlap_at_start() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        // create a dummy hp segment
        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);

        kie.insert(hpSeg);
        DTO dto2 = this.du.createSingleDto("10/10/2017 07:58:00", "10/10/2017 08:01:00", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

    @Test
    public void TestRejectHpOverlapSegment_partial_overlap_at_end() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getHpExclusionList().clear();
        // create a dummy hp segment
        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);
        this.droolsParams.getHpExclusionList().add(hpSeg);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:14:00", "10/10/2017 08:16:00", "left", "SAT_1");
        dto2.setPrType(PRType.HP);
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(inserted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

    @Test
    public void TestRejectHpOverlapSegment_no_overlap_need_a_man_end() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment_need_a_man_end \n\n");

        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:58:00", "10/10/2017 15:00:00", "left", "SAT_1");
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

    @Test
    public void TestRejectHpOverlapSegment_need_a_man_start_updateAcq() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:00:00", "10/10/2017 07:05:00", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:30:00", "10/10/2017 07:31:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

    /*
     * @Test public void TestRejectHpOverlapSegment_need_a_man_noTime() throws
     * Exception { this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     * DroolsOperations.getDroolsEnvironment().setUpFixedOrbitHpMap(this.
     * droolsParams); this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_");
     * System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n"
     * );
     *
     * HPExclusion hpSeg = this.stub.createHPExclusion("1",
     * "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1",
     * true, true);
     *
     * KieSession kie = SessionHandler.getKieSessionsMap().get(sessionId + "_" +
     * currentKieSession); kie.insert(hpSeg);
     *
     * DTO dto1 = this.du.createSingleDto("10/10/2017 07:55:00",
     * "10/10/2017 07:56:00", "right", "SAT_1"); dto1.setPrType(PRType.HP);
     *
     * boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * Map<String, Task> alltasksAccepted =
     * droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
     * this.sessionId, this.currentKieSession); for (Map.Entry<String, Task>
     * elements : alltasksAccepted.entrySet()) {
     * System.out.println("element accepted :" + elements.getValue()); }
     *
     * this.rejectedElements =
     * this.droolsInstance.receiveDtoRejected(this.sessionId,
     * this.currentKieSession); for (Map.Entry<String, Acquisition> elements :
     * this.rejectedElements.entrySet()) {
     * System.out.println("element rejected :" + elements.getValue()); } }
     */
    @Test
    public void TestRejectHpOverlapSegment_need_a_man_start() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);
        this.droolsParams.getHpExclusionList().add(hpSeg);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:00:00", "10/10/2017 07:05:00", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:31:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

    /*
     * @Test public void TestHpSegment_deltaFatScenario() throws Exception {
     * this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     * DroolsOperations.getDroolsEnvironment().setUpFixedOrbitHpMap(this.
     * droolsParams);
     *
     * this.droolsParams.getSatelliteState().clear();
     * this.droolsParams.getAllPAWS().clear();
     * this.droolsParams.getHpExclusionList().clear();
     *
     * Date startMh = this.du.createDate("15/09/2016 06:21:00"); Date stopMh =
     * this.du.createDate("15/09/2016 18:21:00");
     *
     * this.droolsParams.getCurrentMH().setStart(startMh);
     * this.droolsParams.getCurrentMH().setStop(stopMh);
     *
     * HPExclusion hpSeg1 = this.stub.createHPExclusion("1",
     * "15/09/2016 08:00:00", "right", "15/09/2016 08:10:00", "right", "SAT_1",
     * true, true); this.droolsParams.getHpExclusionList().add(hpSeg1);
     *
     * HPExclusion hpSeg2 = this.stub.createHPExclusion("1",
     * "30/08/2016 11:00:00", "right", "30/08/2016 11:10:00", "right", "SAT_1",
     * true, true); this.droolsParams.getHpExclusionList().add(hpSeg2);
     *
     * this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_");
     * System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n"
     * );
     *
     * DTO dto1 = this.du.createSingleDto("15/09/2016 07:59:00",
     * "15/09/2016 08:00:05", "right", "SAT_1"); dto1.setPrType(PRType.HP);
     * boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto2 = this.du.createSingleDto("15/09/2016 08:09:55",
     * "15/09/2016 08:10:05", "right", "SAT_1"); dto2.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto2,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto3 = this.du.createSingleDto("15/09/2016 08:05:00",
     * "15/09/2016 08:05:10", "right", "SAT_1"); dto3.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto3,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto4 = this.du.createSingleDto("15/09/2016 09:30:00",
     * "15/09/2016 09:30:10", "right", "SAT_1"); dto4.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto4,
     * this.sessionId, this.currentKieSession); assertTrue(accepted);
     *
     * DTO dto5 = this.du.createSingleDto("15/09/2016 09:10:00",
     * "15/09/2016 09:10:10", "right", "SAT_1"); dto5.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto5,
     * this.sessionId, this.currentKieSession); assertTrue(accepted);
     *
     * DTO dto6 = this.du.createSingleDto("15/09/2016 11:05:00",
     * "15/09/2016 11:05:10", "left", "SAT_1"); dto6.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto6,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto7 = this.du.createSingleDto("15/09/2016 12:00:00",
     * "15/09/2016 12:00:10", "left", "SAT_1"); dto7.setPrType(PRType.HP);
     * dto7.setRevolutionNumber(6); accepted =
     * this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId,
     * this.currentKieSession); assertTrue(accepted);
     *
     * Map<String, Task> alltasksAccepted =
     * droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
     * this.sessionId, this.currentKieSession); for (Map.Entry<String, Task>
     * elements : alltasksAccepted.entrySet()) {
     * System.out.println("element accepted :" + elements.getValue()); }
     *
     * this.rejectedElements =
     * this.droolsInstance.receiveDtoRejected(this.sessionId,
     * this.currentKieSession); for (Map.Entry<String, Acquisition> elements :
     * this.rejectedElements.entrySet()) {
     * System.out.println("element rejected :" + elements.getValue()); }
     *
     * this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession,
     * this.droolsParams); }
     *
     *
     * @Test public void TestHpSegment_deltaFatScenario_Extended() throws
     * Exception { this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     * DroolsOperations.getDroolsEnvironment().setUpFixedOrbitHpMap(this.
     * droolsParams);
     *
     * this.droolsParams.getSatelliteState().clear();
     * this.droolsParams.getAllPAWS().clear();
     * this.droolsParams.getHpExclusionList().clear();
     *
     * Date startMh = this.du.createDate("15/09/2016 06:21:00"); Date stopMh =
     * this.du.createDate("15/09/2016 18:21:00");
     *
     * this.droolsParams.getCurrentMH().setStart(startMh);
     * this.droolsParams.getCurrentMH().setStop(stopMh);
     *
     * HPExclusion hpSeg1 = this.stub.createHPExclusion("1",
     * "15/09/2016 08:00:00", "right", "15/09/2016 08:10:00", "right", "SAT_1",
     * true, true); this.droolsParams.getHpExclusionList().add(hpSeg1);
     *
     * HPExclusion hpSeg2 = this.stub.createHPExclusion("1",
     * "30/08/2016 11:00:00", "left", "30/08/2016 11:10:00", "left", "SAT_1",
     * true, true); this.droolsParams.getHpExclusionList().add(hpSeg2);
     *
     * this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_");
     * System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n"
     * );
     *
     * DTO dto1 = this.du.createSingleDto("15/09/2016 07:59:00",
     * "15/09/2016 08:00:05", "right", "SAT_1"); dto1.setPrType(PRType.HP);
     * boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto2 = this.du.createSingleDto("15/09/2016 08:09:55",
     * "15/09/2016 08:10:05", "right", "SAT_1"); dto2.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto2,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto3 = this.du.createSingleDto("15/09/2016 08:05:00",
     * "15/09/2016 08:05:10", "right", "SAT_1"); dto3.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto3,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto4 = this.du.createSingleDto("15/09/2016 09:30:00",
     * "15/09/2016 09:30:10", "right", "SAT_1"); dto4.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto4,
     * this.sessionId, this.currentKieSession); assertTrue(accepted);
     *
     * DTO dto5 = this.du.createSingleDto("15/09/2016 09:10:00",
     * "15/09/2016 09:10:10", "right", "SAT_1"); dto5.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto5,
     * this.sessionId, this.currentKieSession); assertTrue(accepted);
     *
     * DTO dto6 = this.du.createSingleDto("15/09/2016 11:05:00",
     * "15/09/2016 11:05:10", "right", "SAT_1"); dto6.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto6,
     * this.sessionId, this.currentKieSession); assertFalse(accepted);
     *
     * DTO dto7 = this.du.createSingleDto("15/09/2016 12:00:00",
     * "15/09/2016 12:00:10", "right", "SAT_1"); dto7.setPrType(PRType.HP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto7,
     * this.sessionId, this.currentKieSession); assertTrue(accepted);
     *
     * DTO dto8 = this.du.createSingleDto("15/09/2016 08:08:55",
     * "15/09/2016 08:09:05", "right", "SAT_1"); dto8.setPrType(PRType.PP);
     * accepted = this.droolsInstance.insertDto(this.droolsParams, dto8,
     * this.sessionId, this.currentKieSession); assertTrue(accepted);
     *
     * Map<String, Task> alltasksAccepted =
     * droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
     * this.sessionId, this.currentKieSession); for (Map.Entry<String, Task>
     * elements : alltasksAccepted.entrySet()) {
     * System.out.println("element accepted :" + elements.getValue()); }
     *
     * this.rejectedElements =
     * this.droolsInstance.receiveDtoRejected(this.sessionId,
     * this.currentKieSession); for (Map.Entry<String, Acquisition> elements :
     * this.rejectedElements.entrySet()) {
     * System.out.println("element rejected :" + elements.getValue()); } }
     */
    @Test
    public void TestRejectHpOverlapSegment_need_a_man_start_notimeforRw_useCmga() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        HPExclusion hpSeg = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "left", "10/10/2017 08:15:00", "left", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg);

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:00:00", "10/10/2017 07:05:00", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:30:00", "10/10/2017 07:31:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

    @Test
    public void TestRejectHpOverlapSegment_need_a_man_end_notimeforRw_useCmga() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance.getDroolsEnvironment().setUpFixedOrbitHpMap(this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n Running test : TestRejectHpOverlapSegment \n\n");

        HPExclusion hpSeg1 = this.stub.createHPExclusion("1", "10/10/2017 08:00:00", "right", "10/10/2017 08:10:00", "right", "SAT_1", true, true);
        HPExclusion hpSeg2 = this.stub.createHPExclusion("1", "10/10/2017 11:00:00", "right", "10/10/2017 11:10:00", "right", "SAT_1", true, true);

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        kie.insert(hpSeg1);
        kie.insert(hpSeg2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 09:10:00", "10/10/2017 09:10:10", "right", "SAT_1");
        dto2.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 11:05:00", "10/10/2017 11:05:10", "right", "SAT_1");
        dto3.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:15:00", "10/10/2017 11:16:10", "left", "SAT_1");
        dto4.setPrType(PRType.HP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> elements : alltasksAccepted.entrySet())
        {
            System.out.println("element accepted :" + elements.getValue());
        }
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Acquisition> elements : this.rejectedElements.entrySet())
        {
            System.out.println("element rejected :" + elements.getValue());
        }
    }

}
