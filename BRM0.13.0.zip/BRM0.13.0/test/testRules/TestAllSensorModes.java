/**
*
* MODULE FILE NAME:	TestAllSensorModes.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		02 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 02 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.PriorityQueue;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author francesca
 *
 */
public class TestAllSensorModes
{

    private StubResources stub = new StubResources();
    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestAllSensorModes";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    public List<DTO> createDtoForGivenSensorMode(TypeOfAcquisition[] types, Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap, DTO dtoAccepted, DroolsParameters droolsParams, DroolsOperations droolsInstance, boolean detract)
    {
        List<DTO> dtos = new ArrayList<>();
        double minDist = 0.0;
        double addOrDecrement = +1.0;
        if (!detract)
        {
            addOrDecrement = -1.0;
        }
        for (int i = 0; i < types.length; i++)
        {
            if (types[i].compareTo(TypeOfAcquisition.BITE) != 0)
            {
                DTO dto = new DTO();
                minDist = minDistanceMap.get(dtoAccepted.getSensorMode()).get(types[i]);
                long startTime = (long) (dtoAccepted.getEndTime().getTime() + ((minDist + addOrDecrement) * 1000));
                Date startTimeAsDate = new Date(startTime);
                System.out.println("start time other acq : " + startTimeAsDate);
                long endTime = startTimeAsDate.getTime() + ((5) * 1000);
                Date endTimeAsDate = new Date(endTime);
                System.out.println("end time other acq : " + endTimeAsDate);

                dto = this.du.createSingleDto("10/10/2017 07:00:00.250", "10/10/2017 07:00:00.250", "right", dtoAccepted.getSatelliteId());
                dto.setSensorMode(types[i]);
                System.out.println("set sensor mode : " + dto.getSensorMode());
                System.out.println("I'm inserting dto : " + dto.toString());

                dto.setStartTime(startTimeAsDate);
                dto.setEndTime(endTimeAsDate);

                dtos.add(dto);
            }
        }
        return dtos;
    }

    @SuppressWarnings("unchecked")
    @Test
    public void A_TestAllSensorModeNegativeCase() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : A_TestAllSensorModeNegativeCase \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        TypeOfAcquisition[] types = TypeOfAcquisition.values();
        Date startTime = DroolsUtils.createDate("10/10/2017 07:00:00.250");
        Date endTime = new Date(startTime.getTime() + 5000);

        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "minDistanceMap");
        System.out.println("min distance : " + minDistanceMap);

        System.out.println("computed startTime :" + startTime);
        System.out.println("computed endTime :" + endTime);

        for (int i = 0; i < types.length; i++)
        {
            if ((types[i].compareTo(TypeOfAcquisition.BITE) != 0) && (types[i].compareTo(TypeOfAcquisition.TRCAL) != 0) && (types[i].compareTo(TypeOfAcquisition.POC2048) != 0))
            {
                DTO dtoAccepted_PINGPONG = this.du.createSingleDto("10/10/2017 07:00:00.250", "10/10/2017 07:00:00.250", "right", satelliteId);
                dtoAccepted_PINGPONG.setStartTime(startTime);
                dtoAccepted_PINGPONG.setEndTime(endTime);
                dtoAccepted_PINGPONG.setSensorMode(types[i]);
                System.out.println("I'm inserting dto : " + dtoAccepted_PINGPONG.toString());

                boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dtoAccepted_PINGPONG, this.sessionId, this.currentKieSession);
                assertEquals(true, accepted);

                List<DTO> dtos = createDtoForGivenSensorMode(types, minDistanceMap, dtoAccepted_PINGPONG, this.droolsParams, this.droolsInstance, false);
                accepted = this.droolsInstance.insertListDto(dtos, this.sessionId, this.currentKieSession, this.droolsParams);
                System.out.println("ACCEPTED ??? " + accepted);
            }

            startTime = new Date(startTime.getTime() + (1800 * 1000));
            endTime = new Date(startTime.getTime() + 5000);
        }

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAccedpted : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED : " + allAccedpted.getValue());
        }
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        // List<Acquisition> allAcceptedAcq =
        // droolsInstance.receiveAllAcquisitions(sessionId,currentKieSession,
        // "SAT_1");
        // assertEquals(TypeOfAcquisition.values().length,
        // allAcceptedAcq.size());
        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            allPlannedTasksAsList.add(allTasks.getValue());
            System.out.println("ACCEPTED : " + allTasks.getValue());

        }

        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println(rejected);
        for (Map.Entry<String, Acquisition> allRejec : rejected.entrySet())
        {
            System.out.println("REJECTED : " + allRejec.getValue());
        }

        TreeMap<String, PriorityQueue> downloadPriority = resourceFunctions.getDownloadPriorityQueueForSat(satelliteId);
        System.out.println("DOWNLOAD PRIORITY : " + downloadPriority);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        // currentKieSession = 4;
        Visibility newVis = this.stub.createVisibility(10, "SAT_1", "KIR", null, "10/10/2017 17:50:00", "10/10/2017 18:21:00");

        this.droolsParams.getAllVisibilities().add(newVis);
        SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession).insert(newVis);
        // droolsInstance.initPlan(droolsParams, allPlannedTasksAsList, null,
        // sessionId, true , currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    // TODO restore next test
    /*
     * @SuppressWarnings("unchecked")
     *
     * @Test public void A_TestAllSensorModePositiveCase() throws Exception {
     * this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     *
     * droolsParams.getHpExclusionList().clear();
     * droolsParams.getSatelliteState().clear();
     * droolsParams.getAllPAWS().clear();
     *
     * this.droolsInstance = this.du.setUpSession(this.sessionId,
     * SessionType.premium, this.droolsParams, this.droolsInstance,
     * this.currentKieSession, "_");
     * System.out.println("Running Test : A_TestAllSensorModePositiveCase \n\n"
     * ); String satelliteId = "SAT_1"; ResourceFunctions resourceFunctions =
     * (ResourceFunctions) DroolsOperations.getGlobal(sessionId,
     * this.currentKieSession, "resourceFunctions"); TreeMap<Long,
     * EnergyAssociatedToTask> acqFunction =
     * resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
     * assertEquals(0, acqFunction.size());
     *
     * TypeOfAcquisition[] types = TypeOfAcquisition.values(); Date startTime =
     * du.createDate("10/10/2017 07:00:00"); Date endTime = new
     * Date(startTime.getTime() + 5000);
     *
     * Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistanceMap =
     * (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>)
     * DroolsOperations.getGlobal(sessionId, this.currentKieSession,
     * "minDistanceMap"); System.out.println("min distance : " +
     * minDistanceMap);
     *
     * System.out.println("computed startTime :" + startTime);
     * System.out.println("computed endTime :" + endTime);
     *
     * for (int i = 0; i < types.length; i++) { if
     * (types[i].compareTo(TypeOfAcquisition.BITE) != 0 &&
     * types[i].compareTo(TypeOfAcquisition.TRCAL) != 0 &&
     * types[i].compareTo(TypeOfAcquisition.POC2048) != 0) { DTO
     * dtoAccepted_PINGPONG = this.du.createSingleDto(null, null, "right",
     * satelliteId); dtoAccepted_PINGPONG.setStartTime(startTime);
     * dtoAccepted_PINGPONG.setEndTime(endTime);
     * dtoAccepted_PINGPONG.setSensorMode(types[i]);
     * System.out.println("I'm inserting dto : " +
     * dtoAccepted_PINGPONG.toString());
     *
     * boolean accepted = this.droolsInstance.insertDto(this.droolsParams,
     * dtoAccepted_PINGPONG, sessionId, this.currentKieSession);
     * assertEquals(true, accepted);
     *
     * List<DTO> dtos = createDtoForGivenSensorMode(types, minDistanceMap,
     * dtoAccepted_PINGPONG, droolsParams, this.droolsInstance, false); accepted
     * = droolsInstance.insertListDto(dtos, sessionId, currentKieSession,
     * droolsParams); System.out.println("ACCEPTED ??? " + accepted); }
     *
     * startTime = new Date(startTime.getTime() + 1800 * 1000); endTime = new
     * Date(startTime.getTime() + 5000); }
     *
     * Map<String, Task> allAcceptedTasks =
     * DroolsOperations.getAllTasksAcceptedAsMap(this.droolsParams, sessionId,
     * this.currentKieSession); for (Map.Entry<String, Task> allAccedpted :
     * allAcceptedTasks.entrySet()) { System.out.println("ACCEPTED : " +
     * allAccedpted.getValue()); }
     *
     * Map<String, Acquisition> rejected =
     * this.droolsInstance.receiveDtoRejected(sessionId,
     * this.currentKieSession);
     *
     * for (Map.Entry<String, Acquisition> allRejec : rejected.entrySet()) {
     * System.out.println("REJECTED : " + allRejec.getValue()); }
     *
     * this.droolsInstance.writeToFile(sessionId, this.currentKieSession,
     * this.droolsParams);
     *
     * StubResources stub = new StubResources(); // currentKieSession = 4;
     * Visibility newVis = stub.createVisibility(10, "SAT_1", "KIR", null,
     * "10/10/2017 17:50:00", "10/10/2017 18:21:00");
     *
     * droolsParams.getAllVisibilities().add(newVis);
     * SessionHandler.getKieSessionsMap().get(sessionId + "_" +
     * currentKieSession).insert(newVis);
     *
     * // droolsInstance.initPlan(droolsParams, allAcceptedTasks, null, //
     * sessionId, true , currentKieSession);
     * this.droolsInstance.writeToFile(sessionId, this.currentKieSession,
     * this.droolsParams);
     *
     * }
     */
}
