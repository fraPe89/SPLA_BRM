
package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class TestDi2s
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private double maxBicForTest = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private StubResources stub = new StubResources();

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "di2s";
        this.maxBicForTest = 200;
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;

        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void test_DI2S_Accepted_same_dwl() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        master.setDi2s(true);
        master.setPrMode(PRMode.DI2S);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerMaster.getPartnerId());
        userInfoSlave.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        // assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_rejectMaster_insertDi2s_rejected() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 16:09:00", "right", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        master.getUserInfo().clear();
        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        slave.getUserInfo().clear();
        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        master.setEndTime(slave.getEndTime());
        equivDto.getAllDtoInEquivalentDto().add(master);
        // equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_rejectMaster_insertDi2s_ok() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        // equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_uncorrect_di2ssMode() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.Standard);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_bic_Not_Available_master() throws IOException, Exception
    {
        // TODO : chiedere a Fede, in caso in cui si rigetta il DI2S x colpa
        // dello slave
        // o del master ripristinare il DTO master o ci pensi te?
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        partnerMaster.setMaxBICAvailable(2);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(2);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().clear();
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().clear();
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.setDi2sInfo(di2sInfo);
        equivDto.setSatelliteId(master.getSatelliteId());
        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_bic_Not_Available_slave() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        partnerMaster.setMaxBICAvailable(100);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);
        partnerSlave.setMaxBICAvailable(2);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(2);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().clear();
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().clear();
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.setDi2sInfo(di2sInfo);
        equivDto.setSatelliteId(master.getSatelliteId());

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_bic_Not_Available_master_and_slave() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2SOR_Accepted");
        int fixedOrbitForTest = 2;

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        partnerMaster.setMaxBICAvailable(10);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);
        partnerSlave.setMaxBICAvailable(10);
        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        // insert single DTO
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, master, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_no_space_pdht() throws IOException, Exception
    {
        System.out.println("\n\n\n\n running test : Test_DI2S_no_space_pdht");
        int fixedOrbitForTest = 2;
        this.droolsParams.getAllPDHT().get(0).setFreeMemory(100);
        this.droolsParams.getAllPDHT().get(0).setCapacity(null);
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:57:00", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        master.setDi2s(true);
        master.setRevolutionNumber(fixedOrbitForTest);
        master.setImageBIC(15);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 15:56:00", "10/10/2017 15:58:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setRevolutionNumber(fixedOrbitForTest);
        slave.setImageBIC(15);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        master.setUserInfo(Arrays.asList(userInfoMaster));

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));
        slave.setUserInfo(Arrays.asList(userInfoSlave));

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());

        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 20;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        // assertTrue(accepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);
    }

    @Test
    public void test_DI2S_not_enough_bic() throws Exception
    {
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        partnerSlave.setMaxBICAvailable(10);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setEquivalentDtoId("100_PR-ITA-001-HP_AR-001_DTOEquiv");

        DTO master = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:00", "right", satelliteId);
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        master.setImageBIC(25);
        master.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO slave = this.du.createSingleDto("10/10/2017 16:59:00", "10/10/2017 16:59:20", "right", satelliteId);
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setImageBIC(20);
        slave.setUserInfo(new ArrayList<>(Arrays.asList(userInfoSlave)));

        equivDto.setStartTime(master.getStartTime());
        equivDto.setEndTime(slave.getEndTime());
        List<DTO> allDtoInsideTheEquivalentDto = new ArrayList<>();
        allDtoInsideTheEquivalentDto.add(master);

        equivDto.setAllDtoInEquivalentDto(allDtoInsideTheEquivalentDto);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());

        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        equivDto.setDi2sInfo(di2sInfo);
        System.out.println("DI2SInfo : " + di2sInfo);

        double totalBicForTest = 30;
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForTest, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);
        System.out.println("equivalent dto :" + equivDto);
        assertEquals(ReasonOfReject.bicNotAvailable, equivDto.getReasonOfReject().get(0).getReason());

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        @SuppressWarnings("unchecked")
        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_fail_for_overlap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());

        DTO previousDto = this.du.createSingleDto("10/10/2017 16:58:00", "10/10/2017 16:59:10", "right", satelliteId);
        previousDto.setPol(Polarization.HH);
        previousDto.setSizeH(400);
        previousDto.setImageBIC(5);
        previousDto.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        boolean acceptedPrevDto = this.droolsInstance.insertDto(this.droolsParams, previousDto, this.sessionId, this.currentKieSession);
        assertTrue(acceptedPrevDto);
        System.out.println("accepted prev dto :" + acceptedPrevDto);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivType(PRMode.DI2S);

        DTO master = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:56:00", "right", satelliteId);
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        master.setImageBIC(5);
        master.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO slave = this.du.createSingleDto("10/10/2017 16:59:00", "10/10/2017 16:59:20", "right", satelliteId);
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setImageBIC(2);
        slave.setUserInfo(new ArrayList<>(Arrays.asList(userInfoSlave)));

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());

        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());
        equivDto.setDi2sInfo(di2sInfo);

        equivDto.setStartTime(master.getStartTime());
        equivDto.setEndTime(slave.getEndTime());
        List<DTO> allDtoInsideTheEquivalentDto = new ArrayList<>();
        master.setEndTime(slave.getEndTime());
        allDtoInsideTheEquivalentDto.add(master);
        // allDtoInsideTheEquivalentDto.add(slave);

        equivDto.setAllDtoInEquivalentDto(allDtoInsideTheEquivalentDto);

        double totalBicForTest = 10;
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForTest, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);
        HashMap<String, Acquisition> rejected = (HashMap<String, Acquisition>) this.droolsInstance.getGlobal( this.sessionId, this.currentKieSession, "rejected");
        
        System.out.println(rejected);
        assertEquals(ReasonOfReject.acqOverlapWithAcquisition, rejected.get(equivDto.getAllDtoInEquivalentDto().get(0).getDtoId()).getReasonOfReject().get(0).getReason());
        System.out.println(equivDto);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void test_DI2S_different_dwl() throws Exception
    {
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", null, "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "KIR", null, "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis4.getAcqStatId(), vis5.getAcqStatId()));

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setEquivalentDtoId("100_PR-ITA-001-HP_AR-001_DTOEquiv");
        DTO master = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:20", "right", satelliteId);
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        master.setImageBIC(25);
        master.setDi2s(true);
        master.setPrMode(PRMode.DI2S);
        master.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));

        DTO slave = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", satelliteId);
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setImageBIC(20);
        slave.setUserInfo(new ArrayList<>(Arrays.asList(userInfoSlave)));

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());

        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        equivDto.setDi2sInfo(di2sInfo);
        equivDto.setStartTime(master.getStartTime());
        equivDto.setEndTime(slave.getEndTime());
        List<DTO> allDtoInsideTheEquivalentDto = new ArrayList<>();
        allDtoInsideTheEquivalentDto.add(master);

        equivDto.setAllDtoInEquivalentDto(allDtoInsideTheEquivalentDto);

        double totalBicForTest = 30;
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForTest, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        // assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Acquisition> rejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        System.out.println("rejected elements : " + rejectedElements);
    }

    /**
     * Test insert storage in PDHT , same examples reported in official
     * documentation.
     *
     * @throws ParseException
     */
    @Test
    public void createNewStorage_Di2s_Test() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : createNewStorageWithDi2s \n\n");

        DTO dtoMaster = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:03:00", "left", "SAT_1");
        dtoMaster.setPol(Polarization.HH);
        dtoMaster.setSizeH(4000);
        dtoMaster.setDi2s(true);

        DTO dtoSlave = this.du.createSingleDto("10/10/2017 10:01:00", "10/10/2017 10:05:00", "left", "SAT_1");
        dtoSlave.setPol(Polarization.HH);
        dtoSlave.setSizeH(4000);
        dtoSlave.setDi2s(true);

        List<DTO> allDtoInEquivDto = new ArrayList<>(Arrays.asList(dtoMaster, dtoSlave));
        double extraCostTheatre = 10;
        EquivalentDTO equivalentDto = new EquivalentDTO("equivDtoId", dtoMaster.getStartTime(), dtoSlave.getEndTime(), extraCostTheatre);
        dtoMaster.setReferredEquivalentDto(equivalentDto.getEquivalentDtoId());
        dtoSlave.setReferredEquivalentDto(equivalentDto.getEquivalentDtoId());

        equivalentDto.setAllDtoInEquivalentDto(allDtoInEquivDto);
        equivalentDto.setEquivType(PRMode.DI2S);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(dtoMaster.getDtoId());
        di2sInfo.setRelativeSlaveId(dtoSlave.getDtoId());

        // di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(dtoSlave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(dtoSlave.getUserInfo().get(0).getUgsId());

        equivalentDto.setDi2sInfo(di2sInfo);
        this.droolsInstance.insert_DI2S(this.droolsParams, equivalentDto, 100, this.sessionId, this.currentKieSession);
    }

    @Test
    public void test_DI2S_different_dwl_no_Dto_slave() throws Exception
    {
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", "Partner_1", "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", "Partner_2", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "1110", "Partner_2", "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis4.getAcqStatId(), vis5.getAcqStatId()));

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setEquivalentDtoId("100_PR-ITA-001-HP_AR-001_DTOEquiv");
        DTO master = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:20", "right", satelliteId);
        master.setPol(Polarization.HV_VH);
        master.setSizeH(400);
        master.setSizeV(400);
        master.setImageBIC(25);
        master.setDi2s(true);
        master.setPrMode(PRMode.DI2S);
        master.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));
        master.setDi2s(true);

        DTO slave = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", satelliteId);
        slave.setPol(Polarization.HV_VH);
        slave.setSizeH(400);
        slave.setImageBIC(20);
        slave.setDi2s(true);
        slave.setUserInfo(new ArrayList<>(Arrays.asList(userInfoSlave)));

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());

        // di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        equivDto.setDi2sInfo(di2sInfo);
        equivDto.setStartTime(master.getStartTime());
        equivDto.setEndTime(slave.getEndTime());
        List<DTO> allDtoInsideTheEquivalentDto = new ArrayList<>();
        allDtoInsideTheEquivalentDto.add(master);
        // allDtoInsideTheEquivalentDto.add(slave);

        equivDto.setAllDtoInEquivalentDto(allDtoInsideTheEquivalentDto);

        double totalBicForTest = 30;
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForTest, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertFalse(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void test_DI2S_different_dwl_masterAndSlave() throws Exception
    {
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", "Partner_1", "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", "Partner_2", "10/10/2017 08:10:00", "10/10/2017 08:15:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        Visibility vis4 = this.stub.createVisibility(3, "SAT_1", "MAT", "Partner_2", "10/10/2017 18:00:00", "10/10/2017 18:21:00");
        Visibility vis5 = this.stub.createVisibility(4, "SAT_2", "1110", "Partner_2", "10/10/2017 19:00:00", "10/10/2017 19:40:00");
        this.droolsParams.getAllVisibilities().addAll(Arrays.asList(vis1, vis2, vis3, vis4, vis5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setAcquisitionStationIdList(Arrays.asList(vis1.getAcqStatId(), vis2.getAcqStatId(), vis3.getAcqStatId()));

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoSlave.setAcquisitionStationIdList(Arrays.asList(vis4.getAcqStatId(), vis5.getAcqStatId()));

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setEquivalentDtoId("100_PR-ITA-001-HP_AR-001_DTOEquiv");
        DTO master = this.du.createSingleDto("10/10/2017 16:55:00", "10/10/2017 16:55:20", "right", satelliteId);
        master.setPol(Polarization.HV_VH);
        master.setSizeH(400);
        master.setSizeV(400);
        master.setImageBIC(25);
        master.setDi2s(true);
        master.setPrMode(PRMode.DI2S);
        master.setUserInfo(new ArrayList<>(Arrays.asList(userInfoMaster)));
        master.setDi2s(true);

        DTO slave = this.du.createSingleDto("10/10/2017 16:56:00", "10/10/2017 16:56:20", "right", satelliteId);
        slave.setPol(Polarization.HV_VH);
        slave.setSizeH(400);
        slave.setSizeV(400);

        slave.setImageBIC(20);
        slave.setDi2s(true);
        slave.setUserInfo(new ArrayList<>(Arrays.asList(userInfoSlave)));

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());

        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        equivDto.setDi2sInfo(di2sInfo);
        equivDto.setStartTime(master.getStartTime());
        equivDto.setEndTime(slave.getEndTime());
        List<DTO> allDtoInsideTheEquivalentDto = new ArrayList<>();
        allDtoInsideTheEquivalentDto.add(master);

        equivDto.setAllDtoInEquivalentDto(allDtoInsideTheEquivalentDto);

        double totalBicForTest = 30;
        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForTest, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertTrue(accepted);

        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
}
