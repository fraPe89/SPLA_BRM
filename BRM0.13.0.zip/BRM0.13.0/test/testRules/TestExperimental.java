/**
*
* MODULE FILE NAME:	TestExperimental.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		06 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 06 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * @author francesca
 *
 */
public class TestExperimental
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "insert_Experimental";
        this.maxBicForTest = 200;
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /**
     * Tear down.
     */
    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void insert_Experimental() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : insert_Experimental");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto0 = this.du.createSingleDto("10/10/2017 08:59:00", "10/10/2017 08:59:20", "right", satelliteId);
        dto0.setPol(Polarization.HH);
        dto0.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:59:00", "10/10/2017 16:00:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchSlew);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Exp);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Experimental(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void insert_Experimental_invalid() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : insert_Experimental_invalid");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto0 = this.du.createSingleDto("10/10/2017 15:59:20", "10/10/2017 15:59:40", "right", satelliteId);
        dto0.setPol(Polarization.HH);
        dto0.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:59:00", "10/10/2017 16:00:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchSlew);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Exp);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Experimental(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void insert_Experimental_invalid_prMode() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : insert_Experimental_invalid");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto0 = this.du.createSingleDto("10/10/2017 15:59:20", "10/10/2017 15:59:40", "right", satelliteId);
        dto0.setPol(Polarization.HH);
        dto0.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:59:00", "10/10/2017 16:00:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchSlew);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Experimental(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }

    /**
     * Test insert theatre valid.
     *
     * @throws Exception
     *             the exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void insert_Experimental_invalid_Man() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : insert_Experimental_invalid");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        this.droolsParams.getSatWithId(satelliteId).getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(0);
        this.droolsParams.getSatWithId(satelliteId).getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuvers(0);
        this.droolsParams.getSatWithId(satelliteId).getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(0);

        DTO dto0 = this.du.createSingleDto("10/10/2017 15:59:20", "10/10/2017 15:59:40", "right", satelliteId);
        dto0.setPol(Polarization.HH);
        dto0.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:22:00", "10/10/2017 17:23:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:59:00", "10/10/2017 16:00:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 16:55:00", "10/10/2017 16:59:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchSlew);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Exp);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto2.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Experimental(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void insert_Experimental_left() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : insert_Experimental_invalid");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        DTO dto0 = this.du.createSingleDto("10/10/2017 15:59:20", "10/10/2017 15:59:40", "right", satelliteId);
        dto0.setPol(Polarization.VV);
        dto0.setSizeV(4000);
        dto0.setSizeH(0);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "left", satelliteId);
        dto1.setPol(Polarization.VV);
        dto1.setSizeV(4000);
        dto1.setSizeH(0);

        allDtosIncludedInTheatre.add(dto1);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:00:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchSlew);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto1.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Experimental(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertFalse(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);
    }
}
