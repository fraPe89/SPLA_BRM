/**
*
* MODULE FILE NAME:	PeakRule.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		02 mag 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 02 mag 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * @author francesca
 *
 */
public class TestPeakRule
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private Long PDHTMaxMemory = 0l;

    private StubResources stub = null;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /**
     * Sets the up.
     *
     * @throws ParseException
     *             the parse exception
     */
    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "testPeakOrbits";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.stub = new StubResources();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void peak_rule() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:11:10", "left", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");
        dto5.setPrType(PRType.PP);
        dto5.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
        dto6.setPrType(PRType.HP);
        dto6.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 11:20:00", "10/10/2017 11:20:10", "right", "SAT_1");
        dto7.setPrType(PRType.HP);
        dto7.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_1");
        dto8.setPrType(PRType.HP);
        dto8.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 11:10:00", "10/10/2017 11:10:10", "right", "SAT_1");
        dto9.setPrType(PRType.HP);
        dto9.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
    }

    @Test
    public void peak_duration_is_more_than_two_barrells() throws Exception
    {

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        // this.droolsParams.getAllVisibilities().clear();
        // this.droolsParams.getSatelliteState().clear();
        // this.droolsParams.getAllPAWS().clear();

        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setLowerBoundPeakOrbit(6);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setUpperBoundPeakOrbit(20);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:00:10", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "left", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 09:10:00", "10/10/2017 09:10:10", "left", "SAT_1");
        dto5.setPrType(PRType.HP);
        dto5.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 08:22:00", "10/10/2017 08:22:10", "right", "SAT_1");
        dto6.setPrType(PRType.HP);
        dto6.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 08:45:00", "10/10/2017 08:45:10", "right", "SAT_1");
        dto7.setPrType(PRType.HP);
        dto7.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 09:12:00", "10/10/2017 09:12:10", "right", "SAT_1");
        dto8.setPrType(PRType.HP);
        dto8.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 09:37:00", "10/10/2017 09:37:10", "right", "SAT_1");
        dto9.setPrType(PRType.HP);
        dto9.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto10.setPrType(PRType.HP);
        dto10.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        DTO dto11 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
        dto11.setPrType(PRType.HP);
        dto11.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);

        DTO dto12 = this.du.createSingleDto("10/10/2017 10:40:00", "10/10/2017 10:40:10", "right", "SAT_1");
        dto12.setPrType(PRType.HP);
        dto12.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId, this.currentKieSession);

        DTO dto13 = this.du.createSingleDto("10/10/2017 14:30:00", "10/10/2017 14:30:10", "right", "SAT_1");
        dto13.setPrType(PRType.HP);
        dto13.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId, this.currentKieSession);

        DTO dto14 = this.du.createSingleDto("10/10/2017 15:30:00", "10/10/2017 15:30:10", "right", "SAT_1");
        dto14.setPrType(PRType.HP);
        dto14.setImageBIC(2);
        this.droolsInstance.insertDto(this.droolsParams, dto14, this.sessionId, this.currentKieSession);

        DTO dto15 = this.du.createSingleDto("10/10/2017 16:10:00", "10/10/2017 16:10:10", "right", "SAT_1");
        dto15.setPrType(PRType.HP);
        dto15.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto15, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> allAcc = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        for (int i = 0; i < allAcc.size(); i++)
        {
            System.out.println("task FROM FUNCTION : " + allAcc.get(i));

        }

        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void peak_rule_peak_more_than_upperbound() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(0).getSatelliteProperties().setLowerBoundPeakOrbit(6);
        this.droolsParams.getAllSat().get(0).getSatelliteProperties().setUpperBoundPeakOrbit(10);

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:50:10", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(5);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(6);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(10);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containsExpectedReason = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), rejected, ReasonOfReject.moreThanUpperBoundPeaksBic);
        assertTrue(containsExpectedReason);

        containsExpectedReason = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), rejected, ReasonOfReject.moreThanUpperBoundPeaksBic);
        assertTrue(containsExpectedReason);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
    }

    @Test
    public void deltaFatScenario2() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setMaxNumberDailyPeak(1);

        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setMaxNumberDailyPeak(1);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setMaxNumberDailyPeak(1);

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:50:10", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 09:00:00", "10/10/2017 09:00:10", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:30:00", "10/10/2017 08:30:10", "right", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 09:30:00", "10/10/2017 09:30:10", "right", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 09:10:00", "10/10/2017 09:10:10", "right", "SAT_1");
        dto5.setPrType(PRType.HP);
        dto5.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 09:13:00", "10/10/2017 09:13:10", "right", "SAT_1");
        dto6.setPrType(PRType.HP);
        dto6.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 09:27:00", "10/10/2017 09:27:10", "right", "SAT_1");
        dto7.setPrType(PRType.HP);
        dto7.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 09:32:00", "10/10/2017 09:32:10", "right", "SAT_1");
        dto8.setPrType(PRType.HP);
        dto8.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 09:02:00", "10/10/2017 09:02:10", "right", "SAT_1");
        dto9.setPrType(PRType.HP);
        dto9.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        DTO dto10 = this.du.createSingleDto("10/10/2017 09:03:00", "10/10/2017 09:03:10", "right", "SAT_1");
        dto10.setPrType(PRType.HP);
        dto10.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto10, this.sessionId, this.currentKieSession);

        DTO dto11 = this.du.createSingleDto("10/10/2017 09:06:00", "10/10/2017 09:06:10", "right", "SAT_1");
        dto11.setPrType(PRType.HP);
        dto11.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);

        DTO dto12 = this.du.createSingleDto("10/10/2017 08:43:00", "10/10/2017 08:43:10", "right", "SAT_1");
        dto12.setPrType(PRType.HP);
        dto12.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto12, this.sessionId, this.currentKieSession);

        DTO dto13 = this.du.createSingleDto("10/10/2017 14:30:00", "10/10/2017 14:30:10", "right", "SAT_1");
        dto13.setPrType(PRType.HP);
        dto13.setImageBIC(14);
        this.droolsInstance.insertDto(this.droolsParams, dto13, this.sessionId, this.currentKieSession);

        DTO dto14 = this.du.createSingleDto("10/10/2017 15:30:00", "10/10/2017 15:30:10", "right", "SAT_1");
        dto14.setPrType(PRType.HP);
        dto14.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto14, this.sessionId, this.currentKieSession);

        DTO dto15 = this.du.createSingleDto("10/10/2017 16:10:00", "10/10/2017 16:10:10", "right", "SAT_1");
        dto15.setPrType(PRType.HP);
        dto15.setImageBIC(4);
        this.droolsInstance.insertDto(this.droolsParams, dto15, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void peak_rule_max_number_daily_peaks() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:12:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 08:10:00", "10/10/2017 08:12:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 12:00:00", "10/10/2017 12:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:10:00", "10/10/2017 10:10:10", "right", "SAT_1");
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:00:00", "10/10/2017 10:00:10", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:05:00", "10/10/2017 10:05:10", "left", "SAT_1");
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 10:25:00", "10/10/2017 10:25:10", "left", "SAT_1");
        dto4.setPrType(PRType.HP);
        dto4.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 10:15:00", "10/10/2017 10:15:10", "left", "SAT_1");
        dto5.setPrType(PRType.HP);
        dto5.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 10:20:00", "10/10/2017 10:20:10", "right", "SAT_1");
        dto6.setPrType(PRType.HP);
        dto6.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 11:20:00", "10/10/2017 11:20:10", "right", "SAT_1");
        dto7.setPrType(PRType.HP);
        dto7.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:00:10", "right", "SAT_1");
        dto8.setPrType(PRType.HP);
        dto8.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);

        DTO dto9 = this.du.createSingleDto("10/10/2017 11:10:00", "10/10/2017 11:10:10", "right", "SAT_1");
        dto9.setPrType(PRType.HP);
        dto9.setImageBIC(3);
        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        System.out.println(this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));
    }

}
