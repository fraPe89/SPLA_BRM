/**
*
* MODULE FILE NAME:	DynamicBic.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		09 ago 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 09 ago 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.ManeuverType;
import com.nais.spla.brm.library.main.ontology.enums.PRMode;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Di2sInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.EquivalentDTO;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * @author francesca
 *
 */
public class DynamicBic
{

	//TODO : TEST_DA DECOMMENTARE
	//testPlanGpsSectorsForCurrentVis_GPS
	//A_Acq_on_DLO_inconsistent_with_paw
	//A_Paw_overlap_Vis
	//A_dwl_Before_paw_partial_dwl
	//A_dwl_and_paw
	//downloadTest_Partial_initPlan_V_H_singlePartner_2
	//testBicRule_train_Left_And_Remove_DI2S_BEfore
	//testBicRule_train_Left_And_Remove_DI2S
	//testThirdScenarioDeltaFat
	
    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestDroolsBicManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.maxBicForTest = 100;
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_single_Left_And_Remove() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Acquisition relatedAcq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        assertEquals(extraCostLeft, relatedAcq.getExtraLeft(), 0);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

        assertEquals(relatedAcq.getImageBIC() / 2, p1.getUsedBIC(), 0);
        assertEquals(relatedAcq.getImageBIC() / 2, p2.getUsedBIC(), 0);

        System.out.println("retract sing acq");

        DroolsOperations.retractSingleAcq(this.droolsParams, relatedAcq.getIdTask(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, p1.getUsedBIC(), 0);
        assertEquals(0, p2.getUsedBIC(), 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testBicRule_single_Theatre_R_And_Remove() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:59:00", "10/10/2017 14:00:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:01:00", "10/10/2017 14:02:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:03:00", "10/10/2017 14:04:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 13:59:00", "10/10/2017 14:04:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedForVU);

        allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testBicRule_single_Theatre_Between2MH() throws Exception
    {
        this.droolsParams.setDrlRulesFile("src/main/resources/drl/droolsRules.drl");
        System.out.println("\n\n\n\n running test : testInsert_theatre");

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";

        List<DTO> allDtosIncludedInTheatre = new ArrayList<>();
        List<Maneuver> maneuvers = new ArrayList<>();

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:17:00", "10/10/2017 18:18:00", "right", satelliteId);
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(4000);

        DTO dto2 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:21:00", "right", satelliteId);
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(4000);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:23:00", "10/10/2017 18:24:00", "right", satelliteId);
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(4000);

        allDtosIncludedInTheatre.add(dto1);
        allDtosIncludedInTheatre.add(dto2);
        allDtosIncludedInTheatre.add(dto3);

        Maneuver manInsideTheatre = this.du.createManeuver("man001", "dto1", "dto2", "10/10/2017 18:17:00", "10/10/2017 18:24:00", satelliteId, Actuator.CMGA);
        manInsideTheatre.setType(ManeuverType.PitchCPS);
        maneuvers.add(manInsideTheatre);

        EquivalentDTO equivDto = new EquivalentDTO();
        equivDto.setEquivalentDtoId("equivDto");
        equivDto.setAllDtoInEquivalentDto(allDtosIncludedInTheatre);
        equivDto.setManAssociated(maneuvers);
        equivDto.setEquivType(PRMode.Theatre);
        equivDto.setStartTime(dto1.getStartTime());
        equivDto.setEndTime(dto3.getEndTime());

        boolean validTheatre = this.droolsInstance.insert_Theatre(this.droolsParams, equivDto, this.sessionId, this.currentKieSession);
        assertTrue(validTheatre);

        Map<String, Acquisition> allAcqRejected = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        System.out.println("\nrejected : " + allAcqRejected);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allAcceptEl : allAcceptedTasks.entrySet())
        {
            System.out.println("ACCEPTED EL " + allAcceptEl.getValue());
        }

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.deletedForVU);

        allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, satelliteId);

        System.out.println("all tasks planned :\n ");
        for (int i = 0; i < allTasks.size(); i++)
        {
            System.out.println(allTasks.get(i));
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_single_Theatre_restore_extra_cost() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.setExtraCostLeft(2);
        this.droolsParams.getAllPAWS().clear();

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_train_Left_And_Remove_DI2S_BEfore() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();

        Visibility vis1 = stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 18:10:00", "10/10/2017 18:22:00");

        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllVisibilities().add(vis1);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setImageBIC(1);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 18:02:50", "10/10/2017 18:03:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setImageBIC(3);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(null);
        List<UserInfo> userInfoMasterList = new ArrayList<UserInfo>();
        userInfoMasterList.add(userInfoMaster);
        master.setUserInfo(userInfoMasterList);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(null);
        slave.setUserInfo(Arrays.asList(userInfoSlave));

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 4;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        boolean accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        Acquisition relatedAcq1 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        assertEquals(extraCostLeft/2, relatedAcq1.getExtraLeft(), 0);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

     //   assertEquals(relatedAcq1.getImageBIC() / 2, p2.getUsedBIC(), 0);
        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        assertEquals(true, p2.getAcqPerformed().contains(dto1.getDtoId()));

        Acquisition relatedAcq2 = this.droolsInstance.receiveAcceptedAcquisitionWithId(master.getDtoId(), this.sessionId, this.currentKieSession);

        System.out.println("relatedAcq2 : " + relatedAcq2);
        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

        // droolsInstance.retractSingleAcq(droolsParams,
        // relatedAcq1.getIdTask(), sessionId, this.currentKieSession, null);

//        assertEquals(2.5, p1.getUsedBIC(), 0);
//        assertEquals(2.5, p2.getUsedBIC(), 0);
        assertEquals(1, relatedAcq1.getExtraLeft(), 0);
        assertEquals(1, relatedAcq2.getExtraLeft(), 0);

        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        // assertEquals(true, p2.getAcqPerformed().contains(dto2.getDtoId()));

        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        // assertEquals(true, p2.getAcqPerformed().contains(dto2.getDtoId()));

    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_train_Left_And_Remove_DI2S() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto0 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017 17:00:30", "right", "SAT_1");
        dto0.setImageBIC(3);
        dto0.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto0.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto0.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:16:00", "10/10/2017 18:16:30", "right", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto11 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "left", "SAT_1");
        dto11.setImageBIC(3);
        dto11.setPrType(PRType.PP);

        dto11.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto11.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto11, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Acquisition relatedAcq1 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto11.getDtoId(), this.sessionId, this.currentKieSession);
        assertEquals(extraCostLeft, relatedAcq1.getExtraLeft(), 0);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

        // assertEquals(relatedAcq1.getImageBIC() / 2, p1.getUsedBIC(), 0);
        // assertEquals(relatedAcq1.getImageBIC() / 2, p2.getUsedBIC(), 0);
        // assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        // assertEquals(true, p2.getAcqPerformed().contains(dto1.getDtoId()));

        Partner partnerMaster = this.droolsParams.getAllPartners().get(0);
        Partner partnerSlave = this.droolsParams.getAllPartners().get(1);

        DTO master = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "left", "SAT_1");
        master.setPol(Polarization.HH);
        master.setSizeH(400);
        // master.setDi2s(true);
        master.setPrMode(PRMode.Standard);
        master.setImageBIC(1);
        master.setPrType(PRType.HP);

        DTO slave = this.du.createSingleDto("10/10/2017 18:02:50", "10/10/2017 18:03:00", "left", "SAT_1");
        slave.setPol(Polarization.HH);
        slave.setSizeH(400);
        slave.setDi2s(true);
        slave.setImageBIC(3);
        slave.setPrType(PRType.HP);

        UserInfo userInfoMaster = new UserInfo(partnerMaster.getPartnerId());
        userInfoMaster.setUgsId(partnerMaster.getPartnerId());
        userInfoMaster.setSubscriber(false);
        userInfoMaster.setAcquisitionStationIdList(null);
        master.getUserInfo().add(userInfoMaster);

        UserInfo userInfoSlave = new UserInfo(partnerSlave.getPartnerId());
        userInfoSlave.setUgsId(partnerSlave.getPartnerId());
        userInfoMaster.setSubscriber(true);
        userInfoSlave.setAcquisitionStationIdList(null);
        slave.getUserInfo().add(userInfoSlave);

        // creating the element di2s info linked to all tasks of type
        // di2s
        Di2sInfo di2sInfo = new Di2sInfo();
        di2sInfo.setRelativeMasterId(master.getDtoId());
        di2sInfo.setRelativeSlaveId(slave.getDtoId());
        di2sInfo.setSlaveDto(slave);
        di2sInfo.setPartnerId(slave.getUserInfo().get(0).getOwnerId());
        di2sInfo.setUgsId(slave.getUserInfo().get(0).getUgsId());

        EquivalentDTO equivDto = new EquivalentDTO("100_PR-ITA-001-HP_AR-001_EquivDTO", master.getStartTime(), slave.getEndTime(), PRMode.DI2S);
        equivDto.getAllDtoInEquivalentDto().add(master);
        equivDto.getAllDtoInEquivalentDto().add(slave);
        equivDto.setEquivType(PRMode.DI2S);
        equivDto.setDi2sInfo(di2sInfo);

        double totalBicForEquivDto = 4;
        System.out.println("get all partners : " + this.droolsParams.getAllPartners());

        accepted = this.droolsInstance.insert_DI2S(this.droolsParams, equivDto, totalBicForEquivDto, this.sessionId, this.currentKieSession);
        System.out.println("accepted?" + accepted);
        assertTrue(accepted);

        Acquisition relatedAcq2 = this.droolsInstance.receiveAcceptedAcquisitionWithId(master.getDtoId(), this.sessionId, this.currentKieSession);

        System.out.println("relatedAcq2 : " + relatedAcq2);
        Map<String, Task> allTasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("all tasks accepted :" + allTasksAccepted);

         DroolsOperations.retractSingleAcq(droolsParams,relatedAcq1.getIdTask(), sessionId, this.currentKieSession, null);

//        assertEquals(2.5, p1.getUsedBIC(), 0);
//        assertEquals(2.5, p2.getUsedBIC(), 0);
//        assertEquals(1, relatedAcq1.getExtraLeft(), 0);
//        assertEquals(1, relatedAcq2.getExtraLeft(), 0);
//
//        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
//        // assertEquals(true, p2.getAcqPerformed().contains(dto2.getDtoId()));
//
//        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
//        // assertEquals(true, p2.getAcqPerformed().contains(dto2.getDtoId()));
//
//        System.out.println("retract acq1");
//
//        System.out.println("p1 : " + p1);
//        System.out.println("p2 : " + p2);
//
//        assertEquals(2, p1.getUsedBIC(), 0);
//        assertEquals(2, p2.getUsedBIC(), 0);
        // assertEquals(2,relatedAcq2.getExtraLeft(),0);
        // assertEquals(true, p1.getAcqPerformed().contains(dto2.getDtoId()));

    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_train_Left_And_Remove() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Acquisition relatedAcq1 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        assertEquals(extraCostLeft, relatedAcq1.getExtraLeft(), 0);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

        assertEquals(relatedAcq1.getImageBIC() / 2, p1.getUsedBIC(), 0);
        assertEquals(relatedAcq1.getImageBIC() / 2, p2.getUsedBIC(), 0);
        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        assertEquals(true, p2.getAcqPerformed().contains(dto1.getDtoId()));

        DTO dto2 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:02:30", "left", "SAT_1");
        dto2.setImageBIC(4);
        dto2.setPrType(PRType.PP);

        dto2.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Acquisition relatedAcq2 = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto2.getDtoId(), this.sessionId, this.currentKieSession);

        assertEquals(2.5, p1.getUsedBIC(), 0);
        assertEquals(2.5, p2.getUsedBIC(), 0);
        assertEquals(1, relatedAcq1.getExtraLeft(), 0);
        assertEquals(1, relatedAcq2.getExtraLeft(), 0);

        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        assertEquals(true, p2.getAcqPerformed().contains(dto2.getDtoId()));

        assertEquals(true, p1.getAcqPerformed().contains(dto1.getDtoId()));
        assertEquals(true, p2.getAcqPerformed().contains(dto2.getDtoId()));

        System.out.println("retract acq1");

        DroolsOperations.retractSingleAcq(this.droolsParams, relatedAcq1.getIdTask(), this.sessionId, this.currentKieSession, null);

        System.out.println("p1 : " + p1);
        System.out.println("p2 : " + p2);

        assertEquals(2, p1.getUsedBIC(), 0);
        assertEquals(2, p2.getUsedBIC(), 0);
        assertEquals(2, relatedAcq2.getExtraLeft(), 0);
        assertEquals(true, p1.getAcqPerformed().contains(dto2.getDtoId()));

    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_single_Left_restore_extra_cost() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;

        this.droolsParams.setExtraCostLeft(extraCostLeft);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Acquisition relatedAcq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        assertEquals(extraCostLeft, relatedAcq.getExtraLeft(), 0);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

        assertEquals(relatedAcq.getImageBIC() / 2, p1.getUsedBIC(), 0);
        assertEquals(relatedAcq.getImageBIC() / 2, p2.getUsedBIC(), 0);

        System.out.println("retract sing acq");

        this.droolsInstance.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);

        // both partners spends 1 bic as extra cost (2 values of extra bic
        // splitted for 2 partners)
        // so 3 as total bic splitted for 2 partners : 1.5 each, minus 1 as
        // extra cost = 0.5 residual
        assertEquals(0.5, p1.getUsedBIC(), 0);
        assertEquals(0.5, p2.getUsedBIC(), 0);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_train_Left_restore_extra_cost() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.setExtraCostLeft(2);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);

        System.out.println("p1 before dto1: " + p1);
        System.out.println("p2 before dto1: " + p2);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        System.out.println("p1 after dto1: " + p1);
        System.out.println("p2 after dto1: " + p2);

    }
}
