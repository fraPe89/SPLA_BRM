/**
*
* MODULE FILE NAME:	TestPawManagement.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		04 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 04 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.functions.downloadManagement.DownloadManagement;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.IDownload;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * @author fpedrola
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestPawRule
{

    private String sessionId = null;
    private StubResources stub = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private long PDHTMaxMemory = 0;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private double maxBicForTest = 0;
    DownloadManagement dwlMng = new DownloadManagement();

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestManeuverManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.stub = new StubResources();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        this.maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

//    @Test
//    public void A_Paw_overlap_Vis() throws Exception
//    {
//        System.out.println("Running test : A_Test_Acq_Overlap_Paw_In_Start \n\n");
//        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
//
//        this.droolsParams.getAllVisibilities().clear();
//        this.droolsParams.getAllPAWS().clear();
//
//        String satIdForTest = "SAT_1";
//
//        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
//        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
//        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
//        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 10:10:00", "10/10/2017 10:40:00");
//
//        this.droolsParams.getAllPAWS().add(paw1);
//        this.droolsParams.getAllVisibilities().add(vis1);
//        this.droolsParams.getAllVisibilities().add(vis2);
//        this.droolsParams.getAllVisibilities().add(vis3);
//
//        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
//
//        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
//        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlforSat = resFunc.getDownloadsAssociatedToSat(satIdForTest);
//        System.out.println("all dwl " + allDwlforSat);
//
//        /*
//         * in the treemap of dwl is stored a space for paw, on both links, for
//         * all the visibilitities that overlap a paw.
//         */
//        String vis1UnivocId = DownloadManagement.concatVisId(satIdForTest, vis1);
//        String vis2UnivocId = DownloadManagement.concatVisId(satIdForTest, vis2);
//
//        IDownload pawStoredOnLink1Vis1 = allDwlforSat.get(vis1UnivocId).get("1").get(paw1.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis1 = allDwlforSat.get(vis1UnivocId).get("2").get(paw1.getStartTime().getTime());
//
//        IDownload pawStoredOnLink1Vis2 = allDwlforSat.get(vis2UnivocId).get("1").get(vis2.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis2 = allDwlforSat.get(vis2UnivocId).get("2").get(vis2.getStartTime().getTime());
//
//        assertTrue(pawStoredOnLink1Vis1 != null);
//        assertTrue(pawStoredOnLink2Vis1 != null);
//
//        assertTrue(pawStoredOnLink1Vis2 != null);
//        assertTrue(pawStoredOnLink2Vis2 != null);
//    }

//    @Test
//    public void A_dwl_and_paw() throws Exception
//    {
//        this.sessionId = "GPS_DWL";
//        System.out.println("Running test : A_Test_Acq_Overlap_Paw_In_Start \n\n");
//        this.droolsParams.getAllVisibilities().clear();
//        this.droolsParams.getAllPAWS().clear();
//
//        String satIdForTest = "SAT_1";
//
//        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:25:00", PAWType.GENERIC);
//        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
//        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:20:00");
//        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 10:10:00", "10/10/2017 10:40:00");
//
//        this.droolsParams.getAllPAWS().add(paw1);
//        this.droolsParams.getAllVisibilities().add(vis1);
//        this.droolsParams.getAllVisibilities().add(vis2);
//        this.droolsParams.getAllVisibilities().add(vis3);
//
//        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
//
//        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
//
//        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
//        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlforSat = resFunc.getDownloadsAssociatedToSat(satIdForTest);
//        System.out.println("all dwl " + allDwlforSat);
//
//        /*
//         * in the treemap of dwl is stored a space for paw, on both links, for
//         * all the visibilitities that overlap a paw.
//         */
//
//        String vis1UnivocId = DownloadManagement.concatVisId(satIdForTest, vis1);
//        String vis2UnivocId = DownloadManagement.concatVisId(satIdForTest, vis1);
//
//        IDownload pawStoredOnLink1Vis1 = allDwlforSat.get(vis1UnivocId).get("1").get(paw1.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis1 = allDwlforSat.get(vis1UnivocId).get("2").get(paw1.getStartTime().getTime());
//
//        IDownload pawStoredOnLink1Vis2 = allDwlforSat.get(vis2UnivocId).get("1").get(paw1.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis2 = allDwlforSat.get(vis2UnivocId).get("2").get(paw1.getStartTime().getTime());
//
//        assertTrue(pawStoredOnLink1Vis1 != null);
//        assertTrue(pawStoredOnLink2Vis1 != null);
//
//        assertTrue(pawStoredOnLink1Vis2 != null);
//        assertTrue(pawStoredOnLink2Vis2 != null);
//
//        List<String> acqStatListForPartner1 = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));
//        List<String> acqStatListForPartner2 = new ArrayList<>(Arrays.asList(vis2.getAcqStatId()));
//
//        DTO dto1 = this.du.createSingleDto("10/10/2017 08:16:00", "10/10/2017 08:17:00", "right", satIdForTest);
//
//        List<UserInfo> userInfoList = new ArrayList<>();
//        UserInfo userInfo1 = new UserInfo(acqStatListForPartner1, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
//        UserInfo userInfo2 = new UserInfo(acqStatListForPartner2, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
//        userInfoList.add(userInfo1);
//        userInfoList.add(userInfo2);
//        dto1.setUserInfo(userInfoList);
//
//        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
//        System.out.println("accepted : " + accepted);
//        // assertEquals(false, accepted);
//
//        // droolsInstance.updatePdhtTillEnd(currentKieSession,
//        // droolsParams.getCurrentMH().getStart(), droolsParams, satIdForTest);
//
//        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
//        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
//        allDwlforSat = resFunc.getDownloadsAssociatedToSat("SAT_1");
//        System.out.println("all dwl " + allDwlforSat);
//    }

//    @Test
//    public void A_dwl_Before_paw_partial_dwl() throws Exception
//    {
//        System.out.println("Running test : A_Test_Acq_Overlap_Paw_In_Start \n\n");
//        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
//
//        this.droolsParams.getSatelliteState().clear();
//        this.droolsParams.getAllVisibilities().clear();
//        this.droolsParams.getAllPAWS().clear();
//
//        String satIdForTest = "SAT_1";
//
//        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:11:00", "10/10/2017 08:15:00", PAWType.GENERIC);
//        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
//        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:20:00");
//        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 10:10:00", "10/10/2017 10:40:00");
//
//        this.droolsParams.getAllPAWS().add(paw1);
//        this.droolsParams.getAllVisibilities().add(vis1);
//        this.droolsParams.getAllVisibilities().add(vis2);
//        this.droolsParams.getAllVisibilities().add(vis3);
//
//        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
//
//        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
//        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlforSat = resFunc.getDownloadsAssociatedToSat(satIdForTest);
//        System.out.println("all dwl " + allDwlforSat);
//
//        /*
//         * in the treemap of dwl is stored a space for paw, on both links, for
//         * all the visibilitities that overlap a paw.
//         */
//        String vis1UnivocId = DownloadManagement.concatVisId(satIdForTest, vis1);
//        String vis2UnivocId = DownloadManagement.concatVisId(satIdForTest, vis1);
//
//        IDownload pawStoredOnLink1Vis1 = allDwlforSat.get(vis1UnivocId).get("1").get(paw1.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis1 = allDwlforSat.get(vis1UnivocId).get("2").get(paw1.getStartTime().getTime());
//
//        IDownload pawStoredOnLink1Vis2 = allDwlforSat.get(vis2UnivocId).get("1").get(paw1.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis2 = allDwlforSat.get(vis2UnivocId).get("2").get(paw1.getStartTime().getTime());
//
//        assertTrue(pawStoredOnLink1Vis1 != null);
//        assertTrue(pawStoredOnLink2Vis1 != null);
//
//        assertTrue(pawStoredOnLink1Vis2 != null);
//        assertTrue(pawStoredOnLink2Vis2 != null);
//
//        List<String> acqStatListForPartner1 = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));
//        List<String> acqStatListForPartner2 = new ArrayList<>(Arrays.asList(vis2.getAcqStatId()));
//
//        DTO dto1 = this.du.createSingleDto("10/10/2017 08:03:00", "10/10/2017 08:08:00", "right", satIdForTest);
//
//        List<UserInfo> userInfoList = new ArrayList<>();
//        UserInfo userInfo1 = new UserInfo(acqStatListForPartner1, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
//        UserInfo userInfo2 = new UserInfo(acqStatListForPartner2, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
//        userInfoList.add(userInfo1);
//        userInfoList.add(userInfo2);
//        dto1.setUserInfo(userInfoList);
//
//        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
//        System.out.println("accepted : " + accepted);
//        // assertEquals(false, accepted);
//
//        // droolsInstance.updatePdhtTillEnd(currentKieSession,
//        // droolsParams.getCurrentMH().getStart(), droolsParams, satIdForTest);
//
//        System.out.println(this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession));
//        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
//        allDwlforSat = resFunc.getDownloadsAssociatedToSat("SAT_1");
//        System.out.println("all dwl " + allDwlforSat);
//    }

    @Test
    public void A_Acq_on_DLO_inconsistent_with_paw() throws Exception
    {
        System.out.println("Running test : A_Test_Acq_Overlap_Paw_In_Start \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        String satIdForTest = "SAT_1";

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:15:00", PAWType.GENERIC);
        Visibility vis1 = this.stub.createVisibility(0, "SAT_1", "KIR", null, "10/10/2017 07:55:00", "10/10/2017 08:33:00");
        Visibility vis2 = this.stub.createVisibility(1, "SAT_1", "COR", null, "10/10/2017 08:10:00", "10/10/2017 08:40:00");
        Visibility vis3 = this.stub.createVisibility(2, "SAT_1", "COR", null, "10/10/2017 10:10:00", "10/10/2017 10:40:00");

        this.droolsParams.getAllPAWS().add(paw1);
        this.droolsParams.getAllVisibilities().add(vis1);
        this.droolsParams.getAllVisibilities().add(vis2);
        this.droolsParams.getAllVisibilities().add(vis3);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<String, TreeMap<String, TreeMap<Long, IDownload>>> allDwlforSat = resFunc.getDownloadsAssociatedToSat(satIdForTest);
        System.out.println("all dwl " + allDwlforSat);

        /*
         * in the treemap of dwl is stored a space for paw, on both links, for
         * all the visibilitities that overlap a paw.
         */

        String vis1UnivocId = DownloadManagement.concatVisId(satIdForTest, vis1);
        String vis2UnivocId = DownloadManagement.concatVisId(satIdForTest, vis2);

        
        for(int i=0;i<this.droolsParams.getAllVisibilities().size();i++)
        {
        	System.out.println(this.droolsParams.getAllVisibilities().get(i));
        }
        
        System.out.println(allDwlforSat.get(vis1UnivocId).get("1"));
//        
//        IDownload pawStoredOnLink1Vis1 = allDwlforSat.get(vis1UnivocId).get("1").get(paw1.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis1 = allDwlforSat.get(vis1UnivocId).get("2").get(paw1.getStartTime().getTime());
//
//        IDownload pawStoredOnLink1Vis2 = allDwlforSat.get(vis2UnivocId).get("1").get(vis2.getStartTime().getTime());
//        IDownload pawStoredOnLink2Vis2 = allDwlforSat.get(vis2UnivocId).get("2").get(vis2.getStartTime().getTime());
//
//        assertTrue(pawStoredOnLink1Vis1 != null);
//        assertTrue(pawStoredOnLink2Vis1 != null);
//
//        assertTrue(pawStoredOnLink1Vis2 != null);
//        assertTrue(pawStoredOnLink2Vis2 != null);

        List<String> acqStatListForPartner1 = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));
        List<String> acqStatListForPartner2 = new ArrayList<>(Arrays.asList(vis2.getAcqStatId()));

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:16:00", "10/10/2017 08:17:00", "left", satIdForTest);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(acqStatListForPartner1, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        UserInfo userInfo2 = new UserInfo(acqStatListForPartner2, false, this.droolsParams.getAllPartners().get(0).getPartnerId(), this.droolsParams.getAllPartners().get(0).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println("accepted : " + accepted);
        assertEquals(false, accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqInconsistentWithPaw);
        assertTrue(found);

        // droolsInstance.updatePdhtTillEnd(currentKieSession,
        // droolsParams.getCurrentMH().getStart(), droolsParams, satIdForTest);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        allDwlforSat = resFunc.getDownloadsAssociatedToSat("SAT_1");
        System.out.println("all dwl " + allDwlforSat);
    }

    @Test
    public void A_Test_Acq_Overlap_Paw_In_Start() throws Exception
    {
        System.out.println("Running test : A_Test_Acq_Overlap_Paw_In_Start \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        TaskPlanned taskPlanned = new TaskPlanned();
        // I'm setting initial lookside for both satellites
        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        TreeMap<Long, ComplexPdht> PDHTFunctionSat1BeforeInsert = this.droolsInstance.receivePDHTFunction(this.sessionId, this.currentKieSession, "SAT_1");
        DTO dto1 = this.du.createSingleDto("10/10/2017 14:19:00", "10/10/2017 14:22:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqPartialOverlapPAW);
        assertTrue(found);

        TreeMap<Long, ComplexPdht> PDHTFunctionSat1AfterInsert = this.droolsInstance.receivePDHTFunction(this.sessionId, this.currentKieSession, "SAT_1");
        assertEquals(PDHTFunctionSat1BeforeInsert, PDHTFunctionSat1AfterInsert);
    }

    @Test
    public void B_Test_Acq_Overlap_Paw_In_End() throws Exception
    {
        System.out.println("Running test : B_Test_Acq_Overlap_Paw_In_End \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DTO dto1 = this.du.createSingleDto("10/10/2017 14:44:00", "10/10/2017 14:46:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejected : " + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqPartialOverlapPAW);
        assertTrue(found);
    }

    @Test
    public void C_Test_Acq_Totally_Included_Into_Paw() throws Exception
    {

        System.out.println("Running test : C_Test_Acq_Totally_Included_Into_Paw \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getSatelliteState().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DTO dto1 = this.du.createSingleDto("10/10/2017 18:02:00", "10/10/2017 18:05:00", "left", "SAT_2");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapPAW);
        assertTrue(found);
    }

    @Test
    public void C_Test_Silent_Included_Into_Paw() throws Exception
    {
        /**
         * PAW FOR TEST PAW paw1 = "10/10/2017 08:00:00", "10/10/2017 08:15:00"
         * "SAT_1" PAW paw2 = "10/10/2017 14:21:00", "10/10/2017 14:45:00"
         * "SAT_1" PAW paw3 = "10/10/2017 18:00:00", "10/10/2017 18:07:00"
         * "SAT_2" PAW paw4 = "10/10/2017 08:00:00", "10/10/2017 08:03:00"
         * "SAT_2"
         */

        System.out.println("Running test : C_Test_Silent_Included_Into_Paw \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DTO dto1 = this.du.createSingleDto("10/10/2017 14:45:02", "10/10/2017 14:46:00", "right", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqPartialOverlapPAW);
        assertTrue(found);
    }

    @Test
    public void D_Test_Paw_Totally_Included_Into_Acq() throws Exception
    {
        /**
         * PAW FOR TEST PAW paw1 = "10/10/2017 08:00:00", "10/10/2017 08:15:00"
         * "SAT_1" PAW paw2 = "10/10/2017 14:21:00", "10/10/2017 14:45:00"
         * "SAT_1" PAW paw3 = "10/10/2017 18:00:00", "10/10/2017 18:07:00"
         * "SAT_2" PAW paw4 = "10/10/2017 08:00:00", "10/10/2017 08:03:00"
         * "SAT_2"
         */

        System.out.println("Running test : D_Test_Paw_Totally_Included_Into_Acq \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:03:00", PAWType.GENERIC);
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllPAWS().add(paw1);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:59:59", "10/10/2017 08:04:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 07:59:59", "10/10/2017 08:04:00", "left", "SAT_2");
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqPartialOverlapPAW);
        assertTrue(found);
    }

    @Test
    public void E_Test_Remove_Acq_PawOverlapVis_totallyIncluded() throws Exception
    {
        System.out.println("Running test : E_Test_Remove_Acq_PawOverlapGps \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Visibility vis = this.stub.createVisibility(5, "SAT_1", "1100", null, "10/10/2017 08:00:00", "10/10/2017 08:06:00");
        vis.setExternal(true);
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:03:00", PAWType.GENERIC);
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getAllPAWS().add(paw1);
        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllVisibilities().add(vis);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        //
        // DTO dto1 = this.du.createSingleDto("10/10/2017 07:55:00", "10/10/2017
        // 07:58:00", "left", "SAT_1");
        // boolean accepted = this.droolsInstance.insertDto(this.droolsParams,
        // dto1, this.sessionId, this.currentKieSession);
        // assertFalse(accepted);

        Map<String, Task> allTasksAsMap = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> alltasks : allTasksAsMap.entrySet())
        {
            System.out.println("TASK " + alltasks.getValue());
        }

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        //
        // boolean found =
        // this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(),
        // this.rejectedElements, ReasonOfReject.acqInconsistentWithPaw);
        // assertTrue(found);
    }

    @Test
    public void E_Test_Remove_Acq_If_Not_Overlap_But_Violated_Paw_Asset_Start() throws Exception
    {
        System.out.println("Running test : E_Test_Remove_Acq_If_Not_Overlap_But_Violated_Paw_Asset_Start \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:55:00", "10/10/2017 07:58:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqInconsistentWithPaw);
        assertTrue(found);
    }

    @Test
    public void F_Test_Remove_Acq_If_Not_Overlap_But_Violated_Paw_Asset_End() throws Exception
    {
        System.out.println("Running test : F_Test_Remove_Acq_If_Not_Overlap_But_Violated_Paw_Asset_End \n\n");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:17:00", "10/10/2017 08:19:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.acqInconsistentWithPaw);
        assertTrue(found);
    }
}
