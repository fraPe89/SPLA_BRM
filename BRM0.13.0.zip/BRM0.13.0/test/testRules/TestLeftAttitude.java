/**
*
* MODULE FILE NAME:	TestLeftAttitude.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		31 ago 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 31 ago 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author francesca
 *
 */
public class TestLeftAttitude
{

    /** The session id. */
    private String sessionId = null;

    /** The current kie session. */
    private int currentKieSession = 0;

    /** The PDHT max memory. */
    private long PDHTMaxMemory = 0;

    /** The drools params. */
    private DroolsParameters droolsParams = null;

    /** The drools instance. */
    private DroolsOperations droolsInstance = null;

    /** The du. */
    private DroolsUtils du = null;

    /** The max bic for test. */
    private double maxBicForTest = 0;

    /**
     * Sets the up.
     *
     * @throws Exception
     *             the exception
     */
    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestDroolsBicManagement";
        this.droolsParams = new DroolsParameters();
        this.du = new DroolsUtils();
        this.maxBicForTest = 100;
        this.PDHTMaxMemory = 5000000;
        this.currentKieSession = 1;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, this.maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_single_Left_And_Remove() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:51:30", "left", "SAT_1");
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.PP);

        List<UserInfo> userInfoList2 = new ArrayList<>();
        userInfoList2.add(userInfo1);
        userInfoList2.add(userInfo2);
        dto2.setUserInfo(userInfoList2);

        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        // assertEquals(true, accepted);

    }
    
    /**
     * Test bic rule.
     */
    @Test
    public void testBicRule_SOV() throws Exception
    {
    	this.sessionId = "testBicRule_SOV";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        DTO dto1 = this.du.createSingleDto("10/10/2017 13:10:00", "10/10/2017 13:11:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:55:00", "10/10/2017 10:56:30", "left", "SAT_1");
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.PP);

        List<UserInfo> userInfoList2 = new ArrayList<>();
        userInfoList2.add(userInfo1);
        userInfoList2.add(userInfo2);
        dto2.setUserInfo(userInfoList2);

        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        
        Map<String, Task> alltasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for(Map.Entry<String, Task> alltasksAccepted : alltasks.entrySet())
        {
            System.out.println(alltasksAccepted.getValue());
        }
    
        
        DTO dto3 = this.du.createSingleDto("10/10/2017 11:20:00", "10/10/2017 11:20:30", "left", "SAT_1");
        dto3.setImageBIC(3);
        dto3.setPrType(PRType.PP);
        dto3.setNeoAvailable(false);
        List<UserInfo> userInfoList3 = new ArrayList<>();
        userInfoList3.add(userInfo1);
        userInfoList3.add(userInfo2);
        dto3.setUserInfo(userInfoList3);

        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        
        alltasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for(Map.Entry<String, Task> alltasksAccepted : alltasks.entrySet())
        {
            System.out.println(alltasksAccepted.getValue());
        }
        
        DroolsOperations.retractSingleAcq(this.droolsParams, dto3.getDtoId(), this.sessionId, this.currentKieSession, null);
      
        DTO dto4 = this.du.createSingleDto("10/10/2017 13:40:00", "10/10/2017 13:40:30", "left", "SAT_1");
        dto4.setImageBIC(3);
        dto4.setPrType(PRType.PP);
        dto4.setNeoAvailable(false);
        List<UserInfo> userInfoList4 = new ArrayList<>();
        userInfoList4.add(userInfo1);
        userInfoList4.add(userInfo2);
        dto3.setUserInfo(userInfoList4);

        System.out.println("I'm inserting dto : " + dto4.toString());

        KieSession kie = SessionHandler.getKieSessionsMap().get(this.sessionId + "_" + this.currentKieSession);
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
       
        System.out.println(kie);
        
        TreeMap<Long, Maneuver> allManSat1 = resFunc.getManeuverFunctionAssociatedToSat("SAT_1");
        Maneuver manToRemove1 = allManSat1.get(DroolsUtils.createDate("10/10/2017 13:11:30").getTime());
        System.out.println(manToRemove1);
        
        Maneuver manToRemove2 = allManSat1.get(DroolsUtils.createDate("10/10/2017 10:48:20").getTime());
        System.out.println(manToRemove2);
        
        FactHandle manToRemove1FH = kie.getFactHandle(manToRemove1);
        FactHandle manToRemove2FH = kie.getFactHandle(manToRemove2);

        kie.delete(manToRemove1FH);
        kie.delete(manToRemove2FH);

        allManSat1.remove(DroolsUtils.createDate("10/10/2017 10:48:20").getTime());
        allManSat1.remove(DroolsUtils.createDate("10/10/2017 13:11:30").getTime());

        System.out.println(allManSat1);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        
        alltasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for(Map.Entry<String, Task> alltasksAccepted : alltasks.entrySet())
        {
            System.out.println(alltasksAccepted.getValue());
        }
        
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, droolsParams);
        
    }


    /*
     * @Test public void parseDtoFromFileTest() throws ParseException, Exception
     * { this.du.setUpDrools(this.sessionId, this.droolsParams,
     * this.droolsInstance);
     *
     * MissionHorizon currentMH = new MissionHorizon();
     * currentMH.setStart(du.createDate("16/09/2016 06:21:00"));
     * currentMH.setStop(du.createDate("16/09/2016 18:21:00"));
     * droolsParams.setCurrentMH(currentMH);
     *
     * droolsParams.getAllPAWS().clear(); this.droolsInstance =
     * this.du.setUpSession(this.sessionId, SessionType.premium,
     * this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
     *
     * double extraCostLeft = 2; droolsParams.setExtraCostLeft(extraCostLeft);
     *
     * String fileString =
     * "  � 100_2282_1_1_, startTime :Fri Sep 16 11:23:22 UTC 2016, endTime : Fri Sep 16 11:23:32 UTC 2016, lookSide :Left, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2271_1_1_, startTime :Fri Sep 16 11:42:49 UTC 2016, endTime : Fri Sep 16 11:43:05 UTC 2016, lookSide :Left, sensorMode :SCANSAR_1 , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2289_1_1_, startTime :Fri Sep 16 17:24:53 UTC 2016, endTime : Fri Sep 16 17:25:01 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2288_1_1_, startTime :Fri Sep 16 17:24:50 UTC 2016, endTime : Fri Sep 16 17:24:58 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2516_1_1_, startTime :Fri Sep 16 18:00:30 UTC 2016, endTime : Fri Sep 16 18:00:40 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_2 added\r\n"
     * +
     * "	 � 100_2498_1_1_, startTime :Fri Sep 16 16:00:48 UTC 2016, endTime : Fri Sep 16 16:00:58 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_2 added\r\n"
     * +
     * "	 � 100_2297_1_1_, startTime :Fri Sep 16 18:18:52 UTC 2016, endTime : Fri Sep 16 18:39:43 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_2 added\r\n"
     * +
     * "	 � 100_2294_1_1_, startTime :Fri Sep 16 11:12:36 UTC 2016, endTime : Fri Sep 16 11:12:44 UTC 2016, lookSide :Left, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2296_1_1_, startTime :Fri Sep 16 18:19:30 UTC 2016, endTime : Fri Sep 16 18:19:43 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2294_1_2_, startTime :Fri Sep 16 11:12:37 UTC 2016, endTime : Fri Sep 16 11:12:44 UTC 2016, lookSide :Left, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2281_1_1_, startTime :Fri Sep 16 11:33:15 UTC 2016, endTime : Fri Sep 16 11:33:26 UTC 2016, lookSide :Left, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2499_1_1_, startTime :Fri Sep 16 17:20:19 UTC 2016, endTime : Fri Sep 16 17:20:27 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2188_1_1_, startTime :Fri Sep 16 11:34:59 UTC 2016, endTime : Fri Sep 16 11:35:07 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2184_1_1_, startTime :Fri Sep 16 11:53:30 UTC 2016, endTime : Fri Sep 16 11:53:37 UTC 2016, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2184_1_2_, startTime :Fri Sep 16 11:53:30 UTC 2016, endTime : Fri Sep 16 11:53:37 UTC 2016, lookSide :Right, sensorMode :PINGPONG , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2183_1_1_, startTime :Fri Sep 16 11:50:13 UTC 2016, endTime : Fri Sep 16 11:50:44 UTC 2016, lookSide :Right, sensorMode :SCANSAR_2 , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2179_1_1_, startTime :Fri Sep 16 11:41:09 UTC 2016, endTime : Fri Sep 16 11:41:14 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2178_1_1_, startTime :Fri Sep 16 11:38:01 UTC 2016, endTime : Fri Sep 16 11:38:11 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2181_1_2_, startTime :Fri Sep 16 11:47:15 UTC 2016, endTime : Fri Sep 16 11:47:31 UTC 2016, lookSide :Right, sensorMode :SCANSAR_1 , prType : PP, sat : SAT_1 added\r\n"
     * +
     * "	 � 100_2180_1_3_, startTime :Fri Sep 16 11:44:14 UTC 2016, endTime : Fri Sep 16 11:44:21 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType : PP, sat : SAT_1 added "
     * ; FunctionUtils fu = new FunctionUtils(); List<DTO> dtoList =
     * fu.parseDtoFromFile(fileString); System.out.println(dtoList);
     *
     * for (int i = 0; i < dtoList.size(); i++) {
     *
     * this.droolsInstance.insertDto(this.droolsParams, dtoList.get(i),
     * sessionId, this.currentKieSession); }
     *
     * droolsInstance.writeToFile(sessionId, currentKieSession, droolsParams); }
     */

    @Test
    public void LeftAttitudeTest() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        this.droolsParams.getAllVisibilities().clear();
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:30", "left", satelliteId);
        dto2.setImageBIC(2);
        dto2.setPrType(PRType.CIVILIAN_HP);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);

        // Map<String, Acquisition> rejectedElements =
        // this.droolsInstance.receiveDtoRejected(this.sessionId,
        // this.currentKieSession);
        // boolean containsExpectedReason =
        // this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(),
        // rejectedElements, ReasonOfReject.smoothingEssUnranked);
        // assertEquals(true, containsExpectedReason);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:20:50", "10/10/2017 18:21:20", "left", satelliteId);
        dto3.setImageBIC(4);
        dto3.setSizeH(1500);

        dto3.setPrType(PRType.VU);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);

        DTO dto4 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:50:20", "left", satelliteId);
        dto4.setImageBIC(4);
        dto4.setSizeH(3000);
        dto4.setPrType(PRType.LMP);
        System.out.println("I'm inserting dto : " + dto4.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        assertEquals(false, accepted);

        DTO dto5 = this.du.createSingleDto("10/10/2017 09:20:50", "10/10/2017 09:21:20", "right", satelliteId);
        dto5.setImageBIC(4);
        dto5.setPrType(PRType.PP);
        System.out.println("I'm inserting dto : " + dto5.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);

        DTO dto6 = this.du.createSingleDto("10/10/2017 17:52:20", "10/10/2017 17:52:40", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto6.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        this.currentKieSession = 3;

        Date startTimeNewMh = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date endTimeNewMh = DroolsUtils.createDate("11/10/2017 06:21:00");
        this.droolsParams.getCurrentMH().setStart(startTimeNewMh);
        this.droolsParams.getCurrentMH().setStop(endTimeNewMh);
        this.droolsParams.getSatWithId(satelliteId).setInitialLookSide("left");
        Visibility vis10 = stub.createVisibility(9, "SAT_1", "PDR", null, "10/10/2017 20:00:00", "10/10/2017 22:50:00");

        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getAllVisibilities().add(vis10);
        this.droolsParams.getCurrentMH().setStart(startTimeNewMh);
        this.droolsParams.getCurrentMH().setStop(endTimeNewMh);
        this.droolsInstance.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId, this.currentKieSession, true);

        DTO dto7 = this.du.createSingleDto("10/10/2017 22:54:00", "10/10/2017 22:55:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto7.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted : " + allTasks.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testBicRule_LeftAttitude() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        double extraCostLeft = 2;
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:30", "left", "SAT_1");
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.PP);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(1).getPartnerId(), this.droolsParams.getAllPartners().get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, this.droolsParams.getAllPartners().get(2).getPartnerId(), this.droolsParams.getAllPartners().get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:51:30", "left", "SAT_1");
        dto2.setImageBIC(3);
        dto2.setPrType(PRType.PP);

        List<UserInfo> userInfoList2 = new ArrayList<>();
        userInfoList2.add(userInfo1);
        userInfoList2.add(userInfo2);
        dto2.setUserInfo(userInfoList2);

        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

    }
}
