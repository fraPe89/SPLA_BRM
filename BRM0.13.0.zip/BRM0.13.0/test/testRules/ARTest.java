/**
*
* MODULE FILE NAME:	SmoothingMh.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		23 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 23 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

// TODO: Auto-generated Javadoc
/**
 * The Class ARTest.
 *
 * @author francesca
 */
public class ARTest {
	
	/** The session id. */
	private String sessionId = null;
	
	/** The current kie session. */
	private int currentKieSession = 0;
	
	/** The PDHT max memory. */
	private Long PDHTMaxMemory = 0l;
	
	/** The drools params. */
	private DroolsParameters droolsParams = null;
	
	/** The drools instance. */
	private DroolsOperations droolsInstance = null;
	
	/** The du. */
	private DroolsUtils du = null;

	/**
	 * Sets the up.
	 *
	 * @throws ParseException the parse exception
	 */
	@Before
	public void setUp() throws ParseException {
		this.sessionId = "AR_TEST";
		this.droolsParams = new DroolsParameters();
		this.PDHTMaxMemory = 5000000L;
		this.currentKieSession = 1;
		double maxBicForTest = 100;
		this.du = new DroolsUtils();
		double extraCostLeft = 10;
		this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession,
				this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

	}

	/**
	 * Tear down.
	 */
	/*
	 * after each test, all the sessions of Drools will be closed
	 */
	@After
	public void tearDown() {
		this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
		this.droolsInstance.closeAllInstancesForSession(this.sessionId);
	}

	/**
	 * Test double maneuver.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void TestDoubleManeuver() throws Exception {
		this.sessionId = "A_Test555Left";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		StubResources stub = new StubResources();
		this.droolsParams.getAllPAWS().clear();

		List<DTO> allDto = new ArrayList<>();
		Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00",
				"10/10/2017 18:30:00");
		this.droolsParams.getAllVisibilities().add(vis11);
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("Running Test : A_Test555 \n\n");
		String satelliteId = "SAT_1";
		ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(satelliteId);
		assertEquals(0, acqFunction.size());

		DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", "SAT_2");
		dto1.setSensorMode(TypeOfAcquisition.SCANSAR_2);
		dto1.setImageBIC(3);
		dto1.setPrType(PRType.HP);
		allDto.add(dto1);

		DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", "SAT_1");
		dto2.setSensorMode(TypeOfAcquisition.SCANSAR_1);
		dto2.setImageBIC(2);
		dto2.setPrType(PRType.HP);
		allDto.add(dto2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", "SAT_1");
		dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
		dto2.setImageBIC(2);
		dto3.setPrType(PRType.HP);
		allDto.add(dto3);

		DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", "SAT_1");
		dto4.setSensorMode(TypeOfAcquisition.PINGPONG);
		dto4.setImageBIC(3);
		dto4.setPrType(PRType.HP);
		allDto.add(dto4);

		DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", "SAT_1");
		dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
		dto5.setImageBIC(2);
		dto5.setPrType(PRType.HP);
		allDto.add(dto5);

		DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", "SAT_1");
		dto6.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto6.setImageBIC(2);
		dto6.setPrType(PRType.HP);
		allDto.add(dto6);

		DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", "SAT_1");
		dto7.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
		dto7.setImageBIC(3);
		dto7.setPrType(PRType.HP);
		allDto.add(dto7);

		DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", "SAT_1");
		dto8.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
		dto8.setImageBIC(2);
		dto8.setPrType(PRType.PP);
		allDto.add(dto8);

		DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", "SAT_1");
		dto9.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
		dto9.setImageBIC(2);
		dto9.setPrType(PRType.PP);
		allDto.add(dto9);

		DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", "SAT_1");
		dto10.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
		dto10.setImageBIC(3);
		dto10.setPrType(PRType.PP);
		allDto.add(dto10);

		DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", "SAT_1");
		dto11.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2C);
		dto11.setImageBIC(2);
		dto11.setPrType(PRType.PP);
		allDto.add(dto11);

		DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", "SAT_1");
		dto12.setSensorMode(TypeOfAcquisition.SCANSAR_1);
		dto12.setImageBIC(2);
		dto12.setPrType(PRType.PP);
		allDto.add(dto12);

		DTO dto13 = this.du.createSingleDto("10/10/2017 11:44:14", "10/10/2017 11:44:21", "Right", "SAT_1");
		dto13.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto13.setImageBIC(3);
		dto13.setPrType(PRType.PP);
		allDto.add(dto13);

		DTO dto14 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", "SAT_1");
		dto14.setSensorMode(TypeOfAcquisition.SCANSAR_1);
		dto14.setImageBIC(2);
		dto14.setPrType(PRType.PP);
		allDto.add(dto14);

		DTO dto15 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", "SAT_1");
		dto15.setSensorMode(TypeOfAcquisition.SCANSAR_2);
		dto15.setImageBIC(2);
		dto15.setPrType(PRType.PP);
		allDto.add(dto15);

		DTO dto16 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", "SAT_1");
		dto16.setSensorMode(TypeOfAcquisition.PINGPONG);
		dto16.setImageBIC(3);
		dto16.setPrType(PRType.PP);
		allDto.add(dto16);

		DTO dto17 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", "SAT_1");
		dto17.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
		dto17.setImageBIC(2);
		dto17.setPrType(PRType.PP);
		allDto.add(dto17);

		DTO dto18 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", "SAT_1");
		dto18.setSensorMode(TypeOfAcquisition.SCANSAR_1);
		dto18.setImageBIC(2);
		dto18.setPrType(PRType.PP);
		allDto.add(dto18);

		DTO dto19 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", "SAT_1");
		dto19.setSensorMode(TypeOfAcquisition.SCANSAR_2);
		dto19.setImageBIC(2);
		dto19.setPrType(PRType.PP);
		allDto.add(dto19);

		DTO dto20 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", "SAT_1");
		dto20.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto20.setImageBIC(3);
		dto20.setPrType(PRType.PP);
		allDto.add(dto20);

		DTO dto21 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", "SAT_1");
		dto21.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
		dto21.setImageBIC(2);
		dto21.setPrType(PRType.PP);
		allDto.add(dto21);

		DTO dto22 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", "SAT_1");
		dto22.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
		dto22.setImageBIC(2);
		dto22.setPrType(PRType.HP);
		allDto.add(dto22);
		this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> allPlannedTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet()) {
			System.out.println("accepted ;" + allTasks.getValue());
			allPlannedTasksAsList.add(allTasks.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	/**
	 * Double man 2.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void DoubleMan2() throws Exception {
		this.sessionId = "A_Test557";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		StubResources stub = new StubResources();
		this.droolsParams.getAllPAWS().clear();

		List<DTO> allDto = new ArrayList<>();
		Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00",
				"10/10/2017 18:30:00");
		this.droolsParams.getAllVisibilities().add(vis11);
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("Running Test : A_Test555 \n\n");
		String satelliteId = "SAT_1";
		ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(satelliteId);
		assertEquals(0, acqFunction.size());

		/*
		 * ----------------------------------------------------------
		 *
		 *
		 * acq performed by priority : ? 100_2297_1_1_, startTime :2016-09-16
		 * 18:18:52.392, endTime : 2016-09-16 18:19:43.798, lookSide :Right, sensorMode
		 * :STRIPMAP , prType : PP added ? 100_2188_1_1_, startTime :2016-09-16
		 * 11:34:59.042, endTime : 2016-09-16 11:35:07.317, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2A , prType : PP added ? 100_2288_1_1_, startTime :2016-09-16
		 * 17:24:50.072, endTime : 2016-09-16 17:24:58.856, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2A , prType : PP added ? 100_2178_1_1_, startTime :2016-09-16
		 * 11:38:01.044, endTime : 2016-09-16 11:38:11.775, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2B , prType : PP added ? 100_2179_1_1_, startTime :2016-09-16
		 * 11:41:09.498, endTime : 2016-09-16 11:41:14.919, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2C , prType : PP added ? 200_210_1_1_, startTime :2016-09-16
		 * 11:42:44.358, endTime : 2016-09-16 11:42:51.585, lookSide :Right, sensorMode
		 * :STRIPMAP , prType : RANKED_ROUTINE added ? 200_212_1_4_, startTime
		 * :2016-09-16 11:01:57.32, endTime : 2016-09-16 11:02:28.693, lookSide :Left,
		 * sensorMode :SCANSAR_2 , prType : HP added ? 200_211_1_1_, startTime
		 * :2016-09-16 11:45:42.494, endTime : 2016-09-16 11:45:58.458, lookSide :Right,
		 * sensorMode :SCANSAR_1 , prType : HP added ? 200_214_1_1_, startTime
		 * :2016-09-16 10:22:03.906, endTime : 2016-09-16 10:22:11.084, lookSide :Left,
		 * sensorMode :QUADPOL , prType : HP added ? 200_213_1_2_, startTime :2016-09-16
		 * 11:55:05.743, endTime : 2016-09-16 11:55:13.26, lookSide :Right, sensorMode
		 * :PINGPONG , prType : HP added ? 200_207_1_1_, startTime :2016-09-16
		 * 11:34:01.593, endTime : 2016-09-16 11:34:10.391, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2A , prType : HP added ? 200_209_1_2_, startTime :2016-09-16
		 * 15:25:09.398, endTime : 2016-09-16 15:25:16.593, lookSide :Right, sensorMode
		 * :STRIPMAP , prType : HP added ? 100_2295_1_2_, startTime :2016-09-16
		 * 12:30:34.172, endTime : 2016-09-16 12:31:05.213, lookSide :Left, sensorMode
		 * :SCANSAR_2 , prType : RANKED_ROUTINE added ? 200_208_1_1_, startTime
		 * :2016-09-16 11:36:28.799, endTime : 2016-09-16 11:36:39.159, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2B , prType : HP added ? 100_2265_1_1_, startTime
		 * :2016-09-16 11:39:49.943, endTime : 2016-09-16 11:39:58.892, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2A , prType : RANKED_ROUTINE added ? 100_2180_1_3_,
		 * startTime :2016-09-16 11:44:14.314, endTime : 2016-09-16 11:44:21.617,
		 * lookSide :Right, sensorMode :STRIPMAP , prType : PP added ? 100_2181_1_2_,
		 * startTime :2016-09-16 11:47:15.695, endTime : 2016-09-16 11:47:31.671,
		 * lookSide :Right, sensorMode :SCANSAR_1 , prType : PP added ? 100_2282_1_1_,
		 * startTime :2016-09-16 11:23:22.652, endTime : 2016-09-16 11:23:32.836,
		 * lookSide :Left, sensorMode :SPOTLIGHT_2B , prType : PP added ? 100_2183_1_1_,
		 * startTime :2016-09-16 11:50:13.616, endTime : 2016-09-16 11:50:44.611,
		 * lookSide :Right, sensorMode :SCANSAR_2 , prType : PP added ? 100_2294_1_1_,
		 * startTime :2016-09-16 11:12:36.82, endTime : 2016-09-16 11:12:44.811,
		 * lookSide :Left, sensorMode :PINGPONG , prType : PP added ? 100_2184_1_1_,
		 * startTime :2016-09-16 11:53:30.418, endTime : 2016-09-16 11:53:37.999,
		 * lookSide :Right, sensorMode :PINGPONG , prType : PP added ? 100_2185_1_1_,
		 * startTime :2016-09-16 11:56:35.339, endTime : 2016-09-16 11:56:42.546,
		 * lookSide :Right, sensorMode :QUADPOL , prType : PP added ? 100_2278_1_1_,
		 * startTime :Fri Sep 16 11:52:00 UTC 2016, endTime : Fri Sep 16 11:52:07 UTC
		 * 2016, lookSide :Right, sensorMode :STRIPMAP , prType : UNRANKED_ROUTINE added
		 * ? 100_2277_1_1_, startTime :Fri Sep 16 11:55:29 UTC 2016, endTime : Fri Sep
		 * 16 11:55:34 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType :
		 * UNRANKED_ROUTINE added ? 100_2264_1_1_, startTime :Fri Sep 16 11:45:59 UTC
		 * 2016, endTime : Fri Sep 16 11:46:09 UTC 2016, lookSide :Left, sensorMode
		 * :SPOTLIGHT_2B , prType : UNRANKED_ROUTINE added ? 100_2302_1_1_, startTime
		 * :Fri Sep 16 18:18:07 UTC 2016, endTime : Fri Sep 16 18:18:46 UTC 2016,
		 * lookSide :Right, sensorMode :SCANSAR_1 , prType : UNRANKED_ROUTINE added ?
		 * 200_215_1_1_, startTime :Fri Sep 16 15:25:09 UTC 2016, endTime : Fri Sep 16
		 * 15:25:16 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType :
		 * UNRANKED_ROUTINE added ? 200_215_1_2_, startTime :Fri Sep 16 15:25:09 UTC
		 * 2016, endTime : Fri Sep 16 15:25:16 UTC 2016, lookSide :Right, sensorMode
		 * :STRIPMAP , prType : UNRANKED_ROUTINE added
		 *
		 *
		 *
		 */
		DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", satelliteId);
		dto1.setImageBIC(3);
		dto1.setPrType(PRType.HP);
		allDto.add(dto1);

		DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);

		dto2.setImageBIC(2);
		dto2.setPrType(PRType.HP);
		allDto.add(dto2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
		dto2.setImageBIC(2);
		dto3.setPrType(PRType.HP);
		allDto.add(dto3);

		DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", satelliteId);
		dto4.setImageBIC(2);
		dto4.setPrType(PRType.HP);
		allDto.add(dto4);

		DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", satelliteId);
		dto5.setImageBIC(2);
		dto5.setPrType(PRType.HP);
		allDto.add(dto5);

		DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", satelliteId);
		dto6.setImageBIC(2);
		dto6.setPrType(PRType.HP);
		allDto.add(dto6);

		DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", satelliteId);
		dto7.setImageBIC(2);
		dto7.setPrType(PRType.HP);
		allDto.add(dto7);

		DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
		dto8.setImageBIC(2);
		dto8.setPrType(PRType.HP);
		allDto.add(dto8);

		DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
		dto9.setImageBIC(2);
		dto9.setPrType(PRType.HP);
		allDto.add(dto9);

		DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
		dto10.setImageBIC(2);
		dto10.setPrType(PRType.HP);
		allDto.add(dto10);

		DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
		dto11.setImageBIC(2);
		dto11.setPrType(PRType.HP);
		allDto.add(dto11);

		DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", satelliteId);
		dto12.setImageBIC(2);
		dto12.setPrType(PRType.HP);
		allDto.add(dto12);

		DTO dto13 = this.du.createSingleDto("10/10/2017 11:44:14", "10/10/2017 11:44:21", "Right", satelliteId);
		dto13.setImageBIC(2);
		dto13.setPrType(PRType.PP);
		allDto.add(dto13);

		DTO dto141 = this.du.createSingleDto("10/10/2017 11:23:22.652", "10/10/2017 11:23:32.836", "Left", satelliteId);
		dto141.setImageBIC(2);
		dto141.setPrType(PRType.PP);
		allDto.add(dto141);

		DTO dto14 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
		dto14.setImageBIC(2);
		dto14.setPrType(PRType.PP);
		allDto.add(dto14);

		DTO dto15 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", satelliteId);
		dto15.setImageBIC(2);
		dto15.setPrType(PRType.PP);
		allDto.add(dto15);

		DTO dto16 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
		dto16.setImageBIC(2);
		dto16.setPrType(PRType.PP);
		allDto.add(dto16);

		DTO dto17 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
		dto17.setImageBIC(2);
		dto17.setPrType(PRType.PP);
		allDto.add(dto17);

		DTO dto18 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
		dto18.setImageBIC(2);
		dto18.setPrType(PRType.PP);
		allDto.add(dto18);

		DTO dto19 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
		dto19.setImageBIC(2);
		dto19.setPrType(PRType.PP);
		allDto.add(dto19);

		DTO dto20 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", satelliteId);
		dto20.setImageBIC(2);
		dto20.setPrType(PRType.PP);
		allDto.add(dto20);

		DTO dto21 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
		dto21.setImageBIC(2);
		dto21.setPrType(PRType.PP);
		allDto.add(dto21);

		DTO dto22 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
		dto22.setImageBIC(2);
		dto22.setPrType(PRType.PP);
		allDto.add(dto22);

		this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> allPlannedTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet()) {
			System.out.println("accepted ;" + allTasks.getValue());
			allPlannedTasksAsList.add(allTasks.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		List<Task> prevProcTask = DroolsUtils.fromTreemapToList(allAcceptedTasks);
		this.sessionId = "initSmoothing";
		this.currentKieSession = 4;
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		stub = new StubResources();
		this.droolsParams.getAllPAWS().clear();

		allDto = new ArrayList<>();
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("AKK TASKS ACCEPTED " + allAcceptedTasks.size());
		int allTaskBefore = allAcceptedTasks.size();
		this.droolsInstance.initPlan(this.droolsParams, prevProcTask, null, this.sessionId, this.currentKieSession,
				true);
		allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId,
				this.currentKieSession);
		int allTaskafter = allAcceptedTasks.size();
		assertEquals(allTaskBefore, allTaskafter);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	/**
	 * Ramp after R W and without man.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void rampAfterRW_And_withoutMan() throws Exception {
		this.sessionId = "A_Test555";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		StubResources stub = new StubResources();
		this.droolsParams.getAllPAWS().clear();

		List<DTO> allDto = new ArrayList<>();
		Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00",
				"10/10/2017 18:30:00");
		this.droolsParams.getAllVisibilities().add(vis11);
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("Running Test : A_Test555 \n\n");
		String satelliteId = "SAT_1";
		ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(satelliteId);
		assertEquals(0, acqFunction.size());

		/*
		 * 200_480_1_1_, startTime :2016-09-16 08:27:03.675, endTime :2016-09-16
		 * 08:27:11.311, lookSide :Right, sensorMode :STRIPMAP , prType :
		 * CIVILIAN_HPtimePerformance: false , sat :SSAR2 added 200_534_1_1_, startTime
		 * :2016-09-16 10:22:03.713, endTime :2016-09-16 10:22:11.232, lookSide :Left,
		 * sensorMode :QUADPOL , prType : HPtimePerformance: false , sat :SSAR1 added
		 * 200_542_1_1_, startTime :2016-09-16 15:25:08.678, endTime :2016-09-16
		 * 15:25:16.252, lookSide :Right, sensorMode :STRIPMAP , prType :
		 * HPtimePerformance: false , sat :SSAR1 added 200_544_1_1_, startTime
		 * :2016-09-16 13:12:10.732, endTime :2016-09-16 13:12:20.169, lookSide :Left,
		 * sensorMode :SPOTLIGHT_1A , prType : HPtimePerformance: false , sat :SSAR2
		 * added 200_547_1_1_, startTime :2016-09-16 09:39:04.213, endTime :2016-09-16
		 * 09:39:09.726, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType :
		 * HPtimePerformance: false , sat :SSAR2 added 200_533_1_1_, startTime
		 * :2016-09-16 18:00:04.778, endTime :2016-09-16 18:00:14.189, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2A , prType : HPtimePerformance: false , sat :SSAR2
		 * added 200_535_1_1_, startTime :2016-09-16 11:55:05.392, endTime :2016-09-16
		 * 11:55:13.545, lookSide :Right, sensorMode :PINGPONG , prType :
		 * HPtimePerformance: false , sat :SSAR1 added 200_537_1_1_, startTime
		 * :2016-09-16 13:14:48.035, endTime :2016-09-16 13:15:03.707, lookSide :Left,
		 * sensorMode :SPOTLIGHT_1_MSOR , prType : HPtimePerformance: false , sat :SSAR2
		 * added 200_538_1_1_, startTime :2016-09-16 13:14:00.925, endTime :2016-09-16
		 * 13:14:11.946, lookSide :Left, sensorMode :SPOTLIGHT_1B , prType :
		 * HPtimePerformance: false , sat :SSAR2 added 200_541_1_1_, startTime
		 * :2016-09-16 11:36:28.118, endTime :2016-09-16 11:36:38.788, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2B , prType : HPtimePerformance: false , sat :SSAR1
		 * added 200_543_1_1_, startTime :2016-09-16 13:07:33.147, endTime :2016-09-16
		 * 13:07:40.772, lookSide :Left, sensorMode :STRIPMAP , prType :
		 * HPtimePerformance: false , sat :SSAR2 added 200_549_1_1_, startTime
		 * :2016-09-16 11:45:41.895, endTime :2016-09-16 11:45:58.99, lookSide :Right,
		 * sensorMode :SCANSAR_1 , prType : HPtimePerformance: false , sat :SSAR1 added
		 * 200_550_1_1_, startTime :2016-09-16 17:20:24.011, endTime :2016-09-16
		 * 17:20:40.936, lookSide :Right, sensorMode :SCANSAR_1 , prType :
		 * HPtimePerformance: false , sat :SSAR1 added 200_539_1_2_, startTime
		 * :2016-09-16 11:01:56.679, endTime :2016-09-16 11:02:30.071, lookSide :Left,
		 * sensorMode :SCANSAR_2 , prType : HPtimePerformance: false , sat :SSAR2 added
		 * 200_540_1_1_, startTime :2016-09-16 11:34:01.426, endTime :2016-09-16
		 * 11:34:10.505, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType :
		 * HPtimePerformance: false , sat :SSAR1 added 200_1581_1_1_, startTime
		 * :2016-09-16 08:04:10.171, endTime :2016-09-16 08:04:21.365, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2B , prType : HPtimePerformance: false , sat :SSAR2
		 * added 200_1581_1_2_, startTime :2016-09-16 08:04:24.478, endTime :2016-09-16
		 * 08:04:30.059, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType :
		 * HPtimePerformance: false , sat :SSAR2 added 200_1581_1_3_, startTime
		 * :2016-09-16 08:07:18.192, endTime :2016-09-16 08:07:23.87, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2C , prType : HPtimePerformance: false , sat :SSAR2
		 * added 200_1591_1_1_, startTime :2016-09-16 06:50:24.748, endTime :2016-09-16
		 * 06:50:36.257, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType :
		 * CRISIStimePerformance: false , sat :SSAR2 added 100_2483_1_1_, startTime :Fri
		 * Sep 16 08:27:04 UTC 2016, endTime :Fri Sep 16 08:27:11 UTC 2016, lookSide
		 * :Right, sensorMode :STRIPMAP , prType : PPtimePerformance: false , sat :SSAR2
		 * added 100_2483_1_2_, startTime :Fri Sep 16 08:27:04 UTC 2016, endTime :Fri
		 * Sep 16 08:27:11 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType :
		 * PPtimePerformance: false , sat :SSAR2 added 100_2482_1_1_, startTime :Fri Sep
		 * 16 06:50:21 UTC 2016, endTime :Fri Sep 16 06:50:39 UTC 2016, lookSide :Right,
		 * sensorMode :SCANSAR_1 , prType : CRISIStimePerformance: false , sat :SSAR2
		 * added 100_2715_4_1_, startTime :Fri Sep 16 13:41:10 UTC 2016, endTime :Fri
		 * Sep 16 13:41:22 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType
		 * : PPtimePerformance: false , sat :SSAR1 added 100_6056_1_1_, startTime :Fri
		 * Sep 16 16:42:04 UTC 2016, endTime :Fri Sep 16 16:42:15 UTC 2016, lookSide
		 * :Right, sensorMode :SPOTLIGHT_2B , prType : PP+isTimePerformance :false , sat
		 * :SSAR2 added 100_6056_1_2_, startTime :Fri Sep 16 16:42:18 UTC 2016, endTime
		 * :Fri Sep 16 16:42:24 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2C ,
		 * prType : PP+isTimePerformance :false , sat :SSAR2 added 100_6056_1_3_,
		 * startTime :Fri Sep 16 16:41:49 UTC 2016, endTime :Fri Sep 16 16:42:01 UTC
		 * 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType :
		 * PP+isTimePerformance :false , sat :SSAR2 added 100_6056_1_3_, startTime :Fri
		 * Sep 16 16:41:49 UTC 2016, endTime :Fri Sep 16 16:42:01 UTC 2016, lookSide
		 * :Right, sensorMode :SPOTLIGHT_2A , prType : PPtimePerformance: false , sat
		 * :SSAR2 added 100_6056_1_1_, startTime :Fri Sep 16 16:42:04 UTC 2016, endTime
		 * :Fri Sep 16 16:42:15 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B ,
		 * prType : PPtimePerformance: false , sat :SSAR2 added 100_6056_1_2_, startTime
		 * :Fri Sep 16 16:42:18 UTC 2016, endTime :Fri Sep 16 16:42:24 UTC 2016,
		 * lookSide :Right, sensorMode :SPOTLIGHT_2C , prType : PPtimePerformance: false
		 * , sat :SSAR2 added 100_2720_1_1_, startTime :Fri Sep 16 11:23:21 UTC 2016,
		 * endTime :Fri Sep 16 11:23:32 UTC 2016, lookSide :Left, sensorMode
		 * :SPOTLIGHT_2B , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2728_1_1_, startTime :Fri Sep 16 11:42:47 UTC 2016, endTime :Fri Sep 16
		 * 11:43:05 UTC 2016, lookSide :Left, sensorMode :SCANSAR_1 , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2727_1_1_, startTime :Fri Sep
		 * 16 17:20:19 UTC 2016, endTime :Fri Sep 16 17:20:26 UTC 2016, lookSide :Right,
		 * sensorMode :STRIPMAP , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2716_1_1_, startTime :Fri Sep 16 08:52:27 UTC 2016, endTime :Fri Sep 16
		 * 08:52:35 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2740_1_1_, startTime :Fri Sep
		 * 16 16:00:47 UTC 2016, endTime :Fri Sep 16 16:00:58 UTC 2016, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2B , prType : PPtimePerformance: false , sat :SSAR2
		 * added 100_2722_1_1_, startTime :Fri Sep 16 11:12:36 UTC 2016, endTime :Fri
		 * Sep 16 11:12:44 UTC 2016, lookSide :Left, sensorMode :PINGPONG , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2717_1_2_, startTime :Fri Sep
		 * 16 13:40:52 UTC 2016, endTime :Fri Sep 16 13:41:02 UTC 2016, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2B , prType : PPtimePerformance: false , sat :SSAR1
		 * added 100_2714_1_1_, startTime :Fri Sep 16 15:19:21 UTC 2016, endTime :Fri
		 * Sep 16 15:19:27 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType
		 * : PPtimePerformance: false , sat :SSAR1 added 100_2714_1_2_, startTime :Fri
		 * Sep 16 13:42:25 UTC 2016, endTime :Fri Sep 16 13:42:32 UTC 2016, lookSide
		 * :Right, sensorMode :SPOTLIGHT_2C , prType : PPtimePerformance: false , sat
		 * :SSAR1 added 100_2713_1_4_, startTime :Fri Sep 16 07:12:25 UTC 2016, endTime
		 * :Fri Sep 16 07:12:36 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B ,
		 * prType : PPtimePerformance: false , sat :SSAR1 added 100_2712_1_1_, startTime
		 * :Fri Sep 16 07:13:11 UTC 2016, endTime :Fri Sep 16 07:13:19 UTC 2016,
		 * lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PPtimePerformance: false
		 * , sat :SSAR1 added 100_2715_7_1_, startTime :Fri Sep 16 12:04:15 UTC 2016,
		 * endTime :Fri Sep 16 12:04:25 UTC 2016, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2A , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2715_6_1_, startTime :Fri Sep 16 15:18:15 UTC 2016, endTime :Fri Sep 16
		 * 15:18:28 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2715_5_1_, startTime :Fri Sep
		 * 16 07:13:51 UTC 2016, endTime :Fri Sep 16 07:14:01 UTC 2016, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2A , prType : PPtimePerformance: false , sat :SSAR1
		 * added 100_2715_2_1_, startTime :Fri Sep 16 10:27:25 UTC 2016, endTime :Fri
		 * Sep 16 10:27:35 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A , prType
		 * : PPtimePerformance: false , sat :SSAR1 added 100_2715_1_1_, startTime :Fri
		 * Sep 16 08:50:38 UTC 2016, endTime :Fri Sep 16 08:50:48 UTC 2016, lookSide
		 * :Right, sensorMode :SPOTLIGHT_2A , prType : PPtimePerformance: false , sat
		 * :SSAR1 added 100_2749_1_1_, startTime :Fri Sep 16 17:21:57 UTC 2016, endTime
		 * :Fri Sep 16 17:22:05 UTC 2016, lookSide :Right, sensorMode :PINGPONG , prType
		 * : PPtimePerformance: false , sat :SSAR1 added 100_2748_1_1_, startTime :Fri
		 * Sep 16 18:01:29 UTC 2016, endTime :Fri Sep 16 18:01:39 UTC 2016, lookSide
		 * :Right, sensorMode :SPOTLIGHT_2B , prType : PPtimePerformance: false , sat
		 * :SSAR2 added 100_2744_1_1_, startTime :Fri Sep 16 17:24:52 UTC 2016, endTime
		 * :Fri Sep 16 17:25:00 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2A ,
		 * prType : PPtimePerformance: false , sat :SSAR1 added 100_2743_1_1_, startTime
		 * :Fri Sep 16 17:24:49 UTC 2016, endTime :Fri Sep 16 17:24:58 UTC 2016,
		 * lookSide :Right, sensorMode :SPOTLIGHT_2A , prType : PPtimePerformance: false
		 * , sat :SSAR1 added 100_2726_1_1_, startTime :Fri Sep 16 18:08:44 UTC 2016,
		 * endTime :Fri Sep 16 18:08:51 UTC 2016, lookSide :Right, sensorMode :QUADPOL ,
		 * prType : PPtimePerformance: false , sat :SSAR2 added 100_2724_1_1_, startTime
		 * :Fri Sep 16 18:18:51 UTC 2016, endTime :Fri Sep 16 18:19:43 UTC 2016,
		 * lookSide :Right, sensorMode :STRIPMAP , prType : PPtimePerformance: false ,
		 * sat :SSAR1 added 100_2730_1_1_, startTime :Fri Sep 16 07:13:07 UTC 2016,
		 * endTime :Fri Sep 16 07:13:25 UTC 2016, lookSide :Left, sensorMode :SCANSAR_1
		 * , prType : PPtimePerformance: false , sat :SSAR2 added 100_2729_1_1_,
		 * startTime :Fri Sep 16 11:33:15 UTC 2016, endTime :Fri Sep 16 11:33:25 UTC
		 * 2016, lookSide :Left, sensorMode :SPOTLIGHT_2B , prType : PPtimePerformance:
		 * false , sat :SSAR1 added 100_2721_1_1_, startTime :Fri Sep 16 11:34:58 UTC
		 * 2016, endTime :Fri Sep 16 11:35:06 UTC 2016, lookSide :Right, sensorMode
		 * :SPOTLIGHT_2A , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2742_1_1_, startTime :Fri Sep 16 11:56:34 UTC 2016, endTime :Fri Sep 16
		 * 11:56:42 UTC 2016, lookSide :Right, sensorMode :QUADPOL , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2737_1_1_, startTime :Fri Sep
		 * 16 11:53:29 UTC 2016, endTime :Fri Sep 16 11:53:37 UTC 2016, lookSide :Right,
		 * sensorMode :PINGPONG , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2723_1_1_, startTime :Fri Sep 16 11:37:59 UTC 2016, endTime :Fri Sep 16
		 * 11:38:10 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2B , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2719_1_1_, startTime :Fri Sep
		 * 16 11:50:12 UTC 2016, endTime :Fri Sep 16 11:50:45 UTC 2016, lookSide :Right,
		 * sensorMode :SCANSAR_2 , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2741_1_3_, startTime :Fri Sep 16 11:44:13 UTC 2016, endTime :Fri Sep 16
		 * 11:44:21 UTC 2016, lookSide :Right, sensorMode :STRIPMAP , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2738_1_2_, startTime :Fri Sep
		 * 16 11:47:14 UTC 2016, endTime :Fri Sep 16 11:47:32 UTC 2016, lookSide :Right,
		 * sensorMode :SCANSAR_1 , prType : PPtimePerformance: false , sat :SSAR1 added
		 * 100_2733_1_1_, startTime :Fri Sep 16 11:41:08 UTC 2016, endTime :Fri Sep 16
		 * 11:41:14 UTC 2016, lookSide :Right, sensorMode :SPOTLIGHT_2C , prType :
		 * PPtimePerformance: false , sat :SSAR1 added 100_2744_1_1_, startTime :Fri Sep
		 * 16 17:24:50 UTC 2016, endTime :Fri Sep 16 17:25:02 UTC 2016, lookSide :Right,
		 * sensorMode :SPOTLIGHT_2_MSOS , prType : PPtimePerformance: false , sat :SSAR1
		 * added
		 *
		 *
		 *
		 */
		DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", satelliteId);
		dto1.setImageBIC(3);
		dto1.setPrType(PRType.HP);
		allDto.add(dto1);

		DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);

		dto2.setImageBIC(2);
		dto2.setPrType(PRType.HP);
		allDto.add(dto2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
		dto2.setImageBIC(2);
		dto3.setPrType(PRType.HP);
		allDto.add(dto3);

		DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", satelliteId);
		dto4.setImageBIC(2);
		dto4.setPrType(PRType.HP);
		allDto.add(dto4);

		DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", satelliteId);
		dto5.setImageBIC(2);
		dto5.setPrType(PRType.HP);
		allDto.add(dto5);

		DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", satelliteId);
		dto6.setImageBIC(2);
		dto6.setPrType(PRType.HP);
		allDto.add(dto6);

		DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", satelliteId);
		dto7.setImageBIC(2);
		dto7.setPrType(PRType.HP);
		allDto.add(dto7);

		DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
		dto8.setImageBIC(2);
		dto8.setPrType(PRType.HP);
		allDto.add(dto8);

		DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
		dto9.setImageBIC(2);
		dto9.setPrType(PRType.HP);
		allDto.add(dto9);

		DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
		dto10.setImageBIC(2);
		dto10.setPrType(PRType.HP);
		allDto.add(dto10);

		DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
		dto11.setImageBIC(2);
		dto11.setPrType(PRType.HP);
		allDto.add(dto11);

		DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", satelliteId);
		dto12.setImageBIC(2);
		dto12.setPrType(PRType.HP);
		allDto.add(dto12);

		DTO dto13 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
		dto13.setImageBIC(2);
		dto13.setPrType(PRType.PP);
		allDto.add(dto13);

		DTO dto141 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", satelliteId);
		dto141.setImageBIC(2);
		dto141.setPrType(PRType.PP);
		allDto.add(dto141);

		DTO dto14 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
		dto14.setImageBIC(2);
		dto14.setPrType(PRType.PP);
		allDto.add(dto14);

		DTO dto15 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
		dto15.setImageBIC(2);
		dto15.setPrType(PRType.PP);
		allDto.add(dto15);

		DTO dto16 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
		dto16.setImageBIC(2);
		dto16.setPrType(PRType.PP);
		allDto.add(dto16);

		DTO dto17 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
		dto17.setImageBIC(2);
		dto17.setPrType(PRType.PP);
		allDto.add(dto17);

		DTO dto18 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", satelliteId);
		dto18.setImageBIC(2);
		dto18.setPrType(PRType.PP);
		allDto.add(dto18);

		DTO dto19 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
		dto19.setImageBIC(2);
		dto19.setPrType(PRType.PP);
		allDto.add(dto19);

		DTO dto20 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
		dto20.setImageBIC(2);
		dto20.setPrType(PRType.PP);
		allDto.add(dto20);
		this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> allPlannedTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet()) {
			System.out.println("accepted ;" + allTasks.getValue());
			allPlannedTasksAsList.add(allTasks.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	/**
	 * A test 635.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void A_Test635() throws Exception {
		this.sessionId = "A_Test635";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		StubResources stub = new StubResources();
		this.droolsParams.getAllPAWS().clear();

		List<DTO> allDto = new ArrayList<>();
		Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00",
				"10/10/2017 18:30:00");
		this.droolsParams.getAllVisibilities().add(vis11);
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("Running Test : A_Test555 \n\n");
		String satelliteId = "SAT_1";
		ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(satelliteId);
		assertEquals(0, acqFunction.size());

		DTO dto1 = this.du.createSingleDto("10/10/2017 17:20:24.629", "10/10/2017 17:20:40.393", "Right", satelliteId);
		dto1.setImageBIC(3);
		dto1.setPrType(PRType.HP);
		allDto.add(dto1);

		DTO dto2 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.085", "Left", satelliteId);
		dto2.setImageBIC(2);
		dto2.setPrType(PRType.HP);
		allDto.add(dto2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 15:25:09.4", "10/10/2017 15:25:16.591", "Right", satelliteId);
		dto2.setImageBIC(2);
		dto3.setPrType(PRType.HP);
		allDto.add(dto3);

		DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.746", "10/10/2017 11:55:13.257", "Right", satelliteId);
		dto4.setImageBIC(2);
		dto4.setPrType(PRType.HP);
		allDto.add(dto4);

		DTO dto5 = this.du.createSingleDto("10/10/2017 09:39:04.429", "10/10/2017 09:39:09.57", "Right", "SAT_2");
		dto5.setImageBIC(2);
		dto5.setPrType(PRType.HP);
		allDto.add(dto5);

		DTO dto6 = this.du.createSingleDto("10/10/2017 13:12:10.654", "10/10/2017 13:12:20.302", "Left", "SAT_2");
		dto6.setImageBIC(2);
		dto6.setPrType(PRType.HP);
		allDto.add(dto6);

		DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:33.391", "10/10/2017 13:07:40.593", "Left", "SAT_2");
		dto7.setImageBIC(2);
		dto7.setPrType(PRType.HP);
		allDto.add(dto7);

		DTO dto8 = this.du.createSingleDto("10/10/2017 18:00:04.974", "10/10/2017 18:00:14.045", "Right", "SAT_2");
		dto8.setImageBIC(2);
		dto8.setPrType(PRType.HP);
		allDto.add(dto8);

		DTO dto9 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);
		dto9.setImageBIC(2);
		dto9.setPrType(PRType.HP);
		allDto.add(dto9);

		DTO dto10 = this.du.createSingleDto("10/10/2017 11:36:28.804", "10/10/2017 11:36:39.154", "Right", satelliteId);
		dto10.setImageBIC(2);
		dto10.setPrType(PRType.HP);
		allDto.add(dto10);

		DTO dto11 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
		dto11.setImageBIC(2);
		dto11.setPrType(PRType.PP);
		allDto.add(dto11);

		DTO dto12 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
		dto12.setImageBIC(2);
		dto12.setPrType(PRType.HP);
		allDto.add(dto12);

		DTO dto13 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
		dto13.setImageBIC(2);
		dto13.setPrType(PRType.PP);
		allDto.add(dto13);

		DTO dto1411 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
		dto1411.setImageBIC(2);
		dto1411.setPrType(PRType.PP);
		allDto.add(dto1411);

		DTO dto142 = this.du.createSingleDto("10/10/2017 11:42:48", "10/10/2017 11:43:04", "Left", satelliteId);
		dto142.setImageBIC(2);
		dto142.setPrType(PRType.PP);
		allDto.add(dto142);

		DTO dto143 = this.du.createSingleDto("10/10/2017 11:44:14", "10/10/2017 11:44:21", "Right", satelliteId);
		dto143.setImageBIC(2);
		dto143.setPrType(PRType.PP);
		allDto.add(dto143);

		DTO dto144 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
		dto144.setImageBIC(2);
		dto144.setPrType(PRType.PP);
		allDto.add(dto144);
		DTO dto141 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", satelliteId);
		dto141.setImageBIC(2);
		dto141.setPrType(PRType.PP);
		allDto.add(dto141);

		DTO dto14 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
		dto14.setImageBIC(2);
		dto14.setPrType(PRType.PP);
		allDto.add(dto14);

		DTO dto15 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
		dto15.setImageBIC(2);
		dto15.setPrType(PRType.PP);
		allDto.add(dto15);

		DTO dto16 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
		dto16.setImageBIC(2);
		dto16.setPrType(PRType.PP);
		allDto.add(dto16);

		DTO dto17 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
		dto17.setImageBIC(2);
		dto17.setPrType(PRType.PP);
		allDto.add(dto17);

		DTO dto18 = this.du.createSingleDto("10/10/2017 18:19:30", "10/10/2017 18:19:43", "Right", satelliteId);
		dto18.setImageBIC(2);
		dto18.setPrType(PRType.PP);
		allDto.add(dto18);

		DTO dto19 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
		dto19.setImageBIC(2);
		dto19.setPrType(PRType.PP);
		allDto.add(dto19);

		DTO dto20 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
		dto20.setImageBIC(2);
		dto20.setPrType(PRType.PP);
		allDto.add(dto20);

		DTO dto21 = this.du.createSingleDto("10/10/2017 16:00:48", "10/10/2017 16:00:58", "Right", "SAT_2");
		dto21.setImageBIC(2);
		dto21.setPrType(PRType.PP);
		allDto.add(dto21);

		DTO dto22 = this.du.createSingleDto("10/10/2017 18:08:45", "10/10/2017 18:08:52", "Right", "SAT_2");
		dto22.setImageBIC(2);
		dto22.setPrType(PRType.PP);
		allDto.add(dto22);

		DTO dto23 = this.du.createSingleDto("10/10/2017 18:00:30", "10/10/2017 18:00:40", "Right", "SAT_2");
		dto23.setImageBIC(2);
		dto23.setPrType(PRType.PP);
		allDto.add(dto23);

		DTO dto24 = this.du.createSingleDto("10/10/2017 17:20:19", "10/10/2017 17:20:26", "Right", satelliteId);
		dto24.setImageBIC(2);
		dto24.setPrType(PRType.PP);
		allDto.add(dto24);

		DTO dto25 = this.du.createSingleDto("10/10/2017 07:13:09", "10/10/2017 07:13:25", "Left", "SAT_2");
		dto25.setImageBIC(2);
		dto25.setPrType(PRType.PP);
		allDto.add(dto25);

		DTO dto26 = this.du.createSingleDto("10/10/2017 17:24:48", "10/10/2017 17:25:00", "Right", satelliteId);
		dto26.setImageBIC(2);
		dto26.setPrType(PRType.PP);
		allDto.add(dto26);

		this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> allPlannedTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet()) {
			System.out.println("accepted ;" + allTasks.getValue());
			allPlannedTasksAsList.add(allTasks.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	/**
	 * A test 553.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void A_Test553() throws Exception {
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		StubResources stub = new StubResources();
		this.droolsParams.getAllPAWS().clear();

		List<DTO> allDto = new ArrayList<>();
		Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00",
				"10/10/2017 18:30:00");
		this.droolsParams.getAllVisibilities().add(vis11);
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("Running Test : A_Test553 \n\n");
		String satelliteId = "SAT_1";
		ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(satelliteId);
		assertEquals(0, acqFunction.size());

		DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", satelliteId);
		dto1.setImageBIC(3);
		dto1.setPrType(PRType.HP);
		allDto.add(dto1);

		DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);
		dto2.setImageBIC(2);
		dto2.setPrType(PRType.HP);
		allDto.add(dto2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
		dto2.setImageBIC(2);
		dto3.setPrType(PRType.HP);
		allDto.add(dto3);

		DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", satelliteId);
		dto4.setImageBIC(2);
		dto4.setPrType(PRType.HP);
		allDto.add(dto4);

		DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", satelliteId);
		dto5.setImageBIC(2);
		dto5.setPrType(PRType.HP);
		allDto.add(dto5);

		DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", satelliteId);
		dto6.setImageBIC(2);
		dto6.setPrType(PRType.HP);
		allDto.add(dto6);

		DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", satelliteId);
		dto7.setImageBIC(2);
		dto7.setPrType(PRType.HP);
		allDto.add(dto7);

		DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
		dto8.setImageBIC(2);
		dto8.setPrType(PRType.HP);
		allDto.add(dto8);

		DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
		dto9.setImageBIC(2);
		dto9.setPrType(PRType.HP);
		allDto.add(dto9);

		DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
		dto10.setImageBIC(2);
		dto10.setPrType(PRType.HP);
		allDto.add(dto10);

		DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
		dto11.setImageBIC(2);
		dto11.setPrType(PRType.HP);
		allDto.add(dto11);

		DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", satelliteId);
		dto12.setImageBIC(2);
		dto12.setPrType(PRType.HP);
		allDto.add(dto12);

		DTO dto13 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
		dto13.setImageBIC(2);
		dto13.setPrType(PRType.PP);
		allDto.add(dto13);

		DTO dto14 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
		dto14.setImageBIC(2);
		dto14.setPrType(PRType.PP);
		allDto.add(dto14);

		DTO dto15 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
		dto15.setImageBIC(2);
		dto15.setPrType(PRType.PP);
		allDto.add(dto15);

		DTO dto16 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
		dto16.setImageBIC(2);
		dto16.setPrType(PRType.PP);
		allDto.add(dto16);

		DTO dto17 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
		dto17.setImageBIC(2);
		dto17.setPrType(PRType.PP);
		allDto.add(dto17);

		DTO dto18 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", satelliteId);
		dto18.setImageBIC(2);
		dto18.setPrType(PRType.PP);
		allDto.add(dto18);

		DTO dto19 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
		dto19.setImageBIC(2);
		dto19.setPrType(PRType.PP);
		allDto.add(dto19);

		DTO dto20 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
		dto20.setImageBIC(2);
		dto20.setPrType(PRType.PP);
		allDto.add(dto20);
		this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> allPlannedTasksAsList = new ArrayList<>();

		for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet()) {
			System.out.println("accepted ;" + allTasks.getValue());
			allPlannedTasksAsList.add(allTasks.getValue());
		}
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

	/**
	 * A test 693.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void A_Test693() throws Exception {
		this.sessionId = "A_Test693";
		this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
		StubResources stub = new StubResources();
		this.droolsParams.getHpExclusionList().clear();

		List<DTO> allDto = new ArrayList<>();
		Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00",
				"10/10/2017 18:30:00");
		this.droolsParams.getAllVisibilities().add(vis11);
		this.droolsParams.getHpExclusionList().clear();
		this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams,
				this.droolsInstance, this.currentKieSession, "_");

		System.out.println("Running Test : A_Test553 \n\n");
		String satelliteId = "SAT_1";
		ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId,
				this.currentKieSession, "resourceFunctions");
		TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions
				.getEssFunctionAssociatedToSat(satelliteId);
		assertEquals(0, acqFunction.size());

		DTO dto1 = this.du.createSingleDto("10/10/2017 07:13:11", "10/10/2017 07:13:27", "Left", satelliteId);
		dto1.setImageBIC(3);
		dto1.setDtoId("100_3084_1_1_");
		dto1.setSensorMode(TypeOfAcquisition.SCANSAR_1);
		dto1.setPrType(PRType.PP);
		allDto.add(dto1);

		DTO dto2 = this.du.createSingleDto("10/10/2017 16:00:50", "10/10/2017 16:01:00", "Right", satelliteId);
		dto2.setImageBIC(3);
		dto2.setDtoId("100_3080_1_1_");
		dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
		dto2.setPrType(PRType.PP);
		allDto.add(dto2);

		DTO dto3 = this.du.createSingleDto("10/10/2017 18:08:47", "10/10/2017 18:08:55", "Right", satelliteId);
		dto3.setImageBIC(3);
		dto3.setDtoId("100_3094_1_1_");
		dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
		dto3.setPrType(PRType.PP);
		allDto.add(dto3);

		DTO dto4 = this.du.createSingleDto("10/10/2017 11:01:59", "10/10/2017 11:02:30", "Left", satelliteId);
		dto4.setImageBIC(3);
		dto4.setDtoId("200_630_1_2_");
		dto4.setSensorMode(TypeOfAcquisition.SCANSAR_2);
		dto4.setPrType(PRType.HP);
		allDto.add(dto4);

		DTO dto5 = this.du.createSingleDto("10/10/2017 13:12:13", "10/10/2017 13:12:22", "Left", satelliteId);
		dto5.setImageBIC(3);
		dto5.setDtoId("200_635_1_1_");
		dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
		dto5.setPrType(PRType.HP);
		allDto.add(dto5);

		DTO dto6 = this.du.createSingleDto("10/10/2017 09:39:06", "10/10/2017 09:39:11", "Right", satelliteId);
		dto6.setImageBIC(3);
		dto6.setDtoId("200_639_1_1_");
		dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2C);
		dto6.setPrType(PRType.HP);
		allDto.add(dto6);

		DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:35.891", "10/10/2017 13:07:43.093", "Left", satelliteId);
		dto7.setImageBIC(3);
		dto7.setDtoId("200_634_1_1_");
		dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
		dto7.setPrType(PRType.HP);
		allDto.add(dto7);

		DTO dto8 = this.du.createSingleDto("10/10/2017 13:14:52", "10/10/2017 13:15:03", "Left", satelliteId);
		dto8.setImageBIC(3);
		dto8.setDtoId("200_647_1_2_");
		dto8.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
		dto8.setPrType(PRType.HP);
		allDto.add(dto8);

		this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

		Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams,
				this.sessionId, this.currentKieSession);
		List<Task> allPlannedTasksAsList = new ArrayList<>();

		allPlannedTasksAsList = DroolsUtils.fromTreemapToList(allAcceptedTasks);
		this.droolsInstance.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId,
				this.currentKieSession, false);

		DTO dto9 = this.du.createSingleDto("10/10/2017 17:14:52", "10/10/2017 17:15:03", "Right", satelliteId);
		dto9.setImageBIC(3);
		dto9.setDtoId("200_6499_1_2_");
		dto9.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
		dto9.setPrType(PRType.HP);

		this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);
		this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

	}

}
