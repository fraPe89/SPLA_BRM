/**
*
* MODULE FILE NAME: TestAcqOverlapRule.java
*
* MODULE TYPE:      Class definition
*
* FUNCTION:     <Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:        23 ott 2017
*
* AUTHORS:      fpedrola
*
* DESIGN ISSUE:     1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 23 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.RampCMGA;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author fpedrola
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestAcqOverlapRule
{

    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "TestAcqOverlapRule";
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void A_TestOutsideMH() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 02:55:00", "10/10/2017 02:55:30", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);
    }

    @Test
    public void acq_partialOverlapMH_newAcqOverlap() throws Exception
    {
        this.sessionId = "acq_partialOverlapMH_newAcqOverlap";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        Partner p1 = this.droolsParams.getAllPartners().get(0);
        Partner p2 = this.droolsParams.getAllPartners().get(1);
        StubResources stub = new StubResources();
        this.droolsParams.getAllVisibilities().clear();
        Visibility vis1 = stub.createVisibility(0, "SAT_1", "KIR", p1.getPartnerId(), "10/10/2017 07:10:00", "10/10/2017 07:22:00");
        Visibility vis2 = stub.createVisibility(1, "SAT_1", "KOR", p2.getPartnerId(), "10/10/2017 18:10:00", "10/10/2017 18:12:00");
        Visibility vis3 = stub.createVisibility(2, "SAT_1", "MAT", null, "10/10/2017 19:00:00", "10/10/2017 19:50:00");
        List<Visibility> allVis = new ArrayList<>(Arrays.asList(vis1, vis2, vis3));
        List<String> allVisId = new ArrayList<>(Arrays.asList(vis1.getAcqStatId()));

        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getSatWithId("SAT_1").setVisibilityList(allVis);
        this.droolsParams.getHpExclusionList().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllSat().get(0).setInitialLookSide("right");
        this.droolsParams.getAllSat().get(1).setInitialLookSide("right");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().setStartWithRw(true);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n I'm running test downloadTest");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:45:00", "10/10/2017 06:45:10", "right", "SAT_1");
        dto1.setPreferredVis(allVisId);
        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(allVisId, false, p1.getPartnerId(), p1.getUgsId());
        UserInfo userInfo2 = new UserInfo(allVisId, false, p2.getPartnerId(), p2.getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setPol(Polarization.H_V);
        dto1.setSizeV(400);
        dto1.setSizeH(400);
        dto1.setUserInfo(userInfoList);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Download> allDwlassoc = this.droolsInstance.receiveAllDownloadAssociatedToDto(dto1.getDtoId(), this.sessionId, this.currentKieSession, this.droolsParams);

        for (int i = 0; i < allDwlassoc.size(); i++)
        {
            System.out.println(allDwlassoc.get(i));
        }
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:35:00", "10/10/2017 06:38:10", "right", "SAT_1");
        dto2.setTimePerformance(true);
        dto2.setPreferredVis(allVisId);
        dto2.setUserInfo(userInfoList);
        dto2.setPol(Polarization.H_V);
        dto2.setSizeV(400);
        dto2.setSizeH(400);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:22:10", "right", "SAT_1");
        dto3.setTimePerformance(false);
        dto3.setPreferredVis(allVisId);
        dto3.setUserInfo(userInfoList);
        dto3.setPol(Polarization.H_V);
        dto3.setSizeV(400);
        dto3.setSizeH(400);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.filterTasksForMh(allTasks, this.droolsParams);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }

        List<Task> tasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        this.sessionId = "downloadTest_Partial_initPlan_doublePol_InitPlan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        Visibility vis4 = stub.createVisibility(3, "SAT_1", "MAT", null, "10/10/2017 19:30:00", "10/10/2017 19:59:00");
        allVis = new ArrayList<>(Arrays.asList(vis2, vis3, vis4));
        this.droolsParams.setAllVisibilities(allVis);
        this.droolsParams.getCurrentMH().setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        this.droolsParams.getCurrentMH().setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, tasksAsList, null, this.sessionId, this.currentKieSession, true);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 18:21:20", "10/10/2017 18:22:10", "right", "SAT_1");
        dto4.setTimePerformance(false);
        dto4.setPreferredVis(allVisId);
        dto4.setUserInfo(userInfoList);
        dto4.setPol(Polarization.H_V);
        dto4.setSizeV(400);
        dto4.setSizeH(400);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        for (Map.Entry<String, Task> elements : allTasks.entrySet())
        {
            System.out.println("task : " + elements.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void startInsideMhAndEndOutSide_R() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:22:00", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
    }

    @Test
    public void startInsideMhAndEndOutSide_L() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:22:00", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
    }

    @Test
    public void B_TestOverlapInitPlan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:55:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:55:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            allPlannedTasksAsList.add(allTasks.getValue());
        }

        this.currentKieSession = 3;
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId, this.currentKieSession, true);

        DTO dto3 = this.du.createSingleDto("10/10/2017 12:54:00", "10/10/2017 12:55:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);
    }

    @Test
    public void C_TestAcceptAcquisition() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : C_TestAcceptAcquisition \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:30", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        assertEquals(0, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(0, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        System.out.println("acquisition and storage correctly created.");

        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

        assertEquals(1, acqFunction.size());
        TreeMap<Long, ComplexPdht> droolsFunction = resourceFunctions.getPDHTTemporalFunctionSat1();
        System.out.println("I assume that the date will be : " + this.droolsParams.getAllVisibilities().get(4).getStartTime());
        for (Map.Entry<Long, ComplexPdht> entry : droolsFunction.entrySet())
        {
            Date date = new Date(entry.getKey());
            System.out.println(date + " => " + entry.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void E_Test_Insert_reject() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : A_Test_Overlap_Acq --\n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:00:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.PINGPONG + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("-- The dto is accepted.");

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:58:00", "10/10/2017 15:00:00", "right", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto2);

        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistances = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "minDistanceMap");
        double minDistancePingPong_Strip = minDistances.get(TypeOfAcquisition.PINGPONG).get(TypeOfAcquisition.STRIPMAP);
        System.out.println(" minimum distance between " + TypeOfAcquisition.PINGPONG + " and " + TypeOfAcquisition.STRIPMAP + " is : " + minDistancePingPong_Strip);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 14:55:00", "10/10/2017 14:56:00", "right", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSizeH(400);
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto2);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        for (int i = 0; i < allAcq.size(); i++)
        {
            System.out.println("acq : " + allAcq.get(i));
        }

        // dto4 is in overlap with dto1 -> rejected
        DTO dto4 = this.du.createSingleDto("10/10/2017 15:55:20", "10/10/2017 15:56:00", "right", "SAT_1");
        dto4.setPol(Polarization.HH);
        dto4.setSizeH(400);
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto2);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, null);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        dto1 = this.du.createSingleDto("10/10/2017 14:55:00", "10/10/2017 15:00:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.PINGPONG + " : " + dto1);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        for (int i = 0; i < allAcq.size(); i++)
        {
            System.out.println("acq : " + allAcq.get(i));
        }

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void F_Test_Overlap_Acq() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : A_Test_Overlap_Acq --\n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:00:00", "right", "SAT_1");
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.PINGPONG + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("-- The dto is accepted.");

        DTO dto2 = this.du.createSingleDto("10/10/2017 14:58:00", "10/10/2017 15:00:00", "left", "SAT_1");
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto2);

        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistances = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "minDistanceMap");
        double minDistancePingPong_Strip = minDistances.get(TypeOfAcquisition.PINGPONG).get(TypeOfAcquisition.STRIPMAP);
        System.out.println(" minimum distance between " + TypeOfAcquisition.PINGPONG + " and " + TypeOfAcquisition.STRIPMAP + " is : " + minDistancePingPong_Strip);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 12:01:00", "10/10/2017 12:02:00", "left", "SAT_1");
        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.STRIPMAP + " : " + dto2);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, null);
        List<Acquisition> allAcq = this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1");
        for (int i = 0; i < allAcq.size(); i++)
        {
            System.out.println("acq : " + allAcq.get(i));
        }

        TaskPlanned taskPlanned = new TaskPlanned();
        List<Maneuver> allMan = taskPlanned.receiveAllManeuvers(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        for (int i = 0; i < allMan.size(); i++)
        {
            System.out.println("man : " + allMan.get(i));
        }

        // assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        /*
         * boolean found =
         * du.checkIfContainsTheExpectedReason(dto2,rejectedElements,
         * ReasonOfReject.overlapWithAcquisition);
         * System.out.println("found ? "+found); assertTrue(found);
         */
        // System.out.println("-- The dto is rejected because : " +
        // rejectedElements.get(dto2.getDtoId()).getReasonOfReject());
    }

    @Test
    public void G_Test_invalid_Size() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : A_Test_Overlap_Acq --\n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 16:00:00", "right", "SAT_1");
        dto1.setSizeH(0);
        dto1.setSizeV(0);

        System.out.println("-- I'm inserting a new dto with sensorMode " + TypeOfAcquisition.PINGPONG + " : " + dto1);
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        // assertFalse(accepted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.invalidDTOSize);
        System.out.println("found ? " + found);
        assertTrue(found);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void H_Test_Minimum_Distance_Too_Short_With_Previous() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : B_Test_Minimum_Distance_Too_Short_With_Previous --\n\n");
        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistances = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "minDistanceMap");
        double minDistancePingPong_Strip = minDistances.get(TypeOfAcquisition.PINGPONG).get(TypeOfAcquisition.STRIPMAP);
        System.out.println("minimum distance from pingpong to stripmap is :" + minDistancePingPong_Strip + " seconds.");
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:52:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:49:02", "10/10/2017 08:49:58", "left", "SAT_1");
        dto2.setDtoId("100_PR-ITA-001-HP_AR-001_DTO-222");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);

        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        assertEquals(false, accepted);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("dto : " + dto2.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");

        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void I_Test_Minimum_Distance_Too_Short_With_Next() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : B_Test_Minimum_Distance_Too_Short_With_Previous --\n\n");
        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistances = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "minDistanceMap");
        double minDistancePingPong_Strip = minDistances.get(TypeOfAcquisition.PINGPONG).get(TypeOfAcquisition.STRIPMAP);
        System.out.println("minimum distance from pingpong to stripmap is :" + minDistancePingPong_Strip + " seconds.");
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:52:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);

        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:52:02", "10/10/2017 08:55:00", "left", "SAT_1");
        dto2.setDtoId("100_PR-ITA-001-HP_AR-001_DTO-222");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);

        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        assertEquals(false, accepted);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("dto : " + dto1.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");

        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void L_Test_Minimum_Distance_Too_Short_With_Previous_case_5_Dto() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : B_Test_Minimum_Distance_Too_Short_With_Previous --\n\n");
        Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>> minDistances = (Map<TypeOfAcquisition, Map<TypeOfAcquisition, Double>>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "minDistanceMap");
        double minDistancePingPong_Strip = minDistances.get(TypeOfAcquisition.PINGPONG).get(TypeOfAcquisition.STRIPMAP);
        System.out.println("minimum distance from pingpong to stripmap is :" + minDistancePingPong_Strip + " seconds.");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:52:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setDtoId("dto1");
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:52:02", "10/10/2017 08:55:00", "left", "SAT_1");
        dto2.setDtoId("dto2");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:52:00", "left", "SAT_1");
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setDtoId("dto3");
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        DTO dto4 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:52:00", "left", "SAT_2");
        dto4.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto4.setDtoId("dto4");
        System.out.println("I'm inserting dto : " + dto4.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto5 = this.du.createSingleDto("10/10/2017 08:50:00", "10/10/2017 08:52:00", "left", "SAT_1");
        dto5.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto5.setDtoId("dto5");
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejecteed elements : ");

        System.out.println("rejected elements size: " + this.rejectedElements.size());
        System.out.println("rejected elements : " + this.rejectedElements);

        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("dto : " + dto1.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");
        System.out.println(this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1"));
        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());
    }

    @Test
    public void M_Test_Acq_With_Same_Time_On_Different_Satellite() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : C_Test_Acq_With_Same_Time_On_Different_Satellite --\n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:45:00", "10/10/2017 08:48:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:45:00", "10/10/2017 08:48:00", "right", "SAT_2");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        System.out.println("dto : " + dto2.getDtoId() + " is accepted.\n");
        assertTrue(accepted);

        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_2").size());

        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_2").size());

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("All Accepted tasks : ");
        for (Map.Entry<String, Task> allElementsInMap : allAcceptedTasks.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

    }

    @Test
    public void N_Test_Acq_With_Same_Start_Time() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("\n\n  -- I'm running test for " + TestAcqOverlapRule.class.getSimpleName() + " : D_Test_Acq_With_Same_Start_Time --\n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 08:45:00", "10/10/2017 08:48:00", "left", "SAT_1");
        dto1.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto1.setPol(Polarization.HV);
        dto1.setSizeV(300);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");

        DTO dto2 = this.du.createSingleDto("10/10/2017 08:45:00", "10/10/2017 08:48:00", "left", "SAT_1");
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());
    }

    @Test
    public void O_Test_Insert_An_Acquisition_Two_Times() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : G_Test_Insert_An_Acquisition_Two_Times \n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 06:30:00", "10/10/2017 06:35:00", "right", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        // I'm trying to insert the same dto once again
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);
    }

    @Test
    public void P_Test_Reject_Acquisition_For_Overlap_Acquisition_VU() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_Test_Reject_Acquisition_For_Overlap_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "right", "SAT_1");
        dto1.setPrType(PRType.HP);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");
        PDHT PDHTBeforeInsertNewAcq = this.droolsParams.getAllPDHT().get(0);

        // I'm inserting a new acquisition with the same start time of the
        // previous one
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:08:00", "right", "SAT_1");
        dto2.setPrType(PRType.VU);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        // the dto will be rejected by Drools
        // assertEquals(true, accepted);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejectedElements" + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("dto : " + dto1.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");

        // test to check that, into the drools engine, there aren't new
        // acquisition/storage related to the dto rejected
        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

        PDHT PDHTAfterInsertNewAcq = this.droolsParams.getAllPDHT().get(0);

        // test to check that the PDHT wasn't decremented after the insert of
        // the dto that is rejected
        assertEquals(PDHTBeforeInsertNewAcq, PDHTAfterInsertNewAcq);

    }

    @Test
    public void P_Test_Reject_Acquisition_For_Overlap_Acquisition() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_Test_Reject_Acquisition_For_Overlap_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "right", "SAT_1");
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");
        PDHT PDHTBeforeInsertNewAcq = this.droolsParams.getAllPDHT().get(0);

        // I'm inserting a new acquisition with the same start time of the
        // previous one
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:08:00", "left", "SAT_1");
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        // the dto will be rejected by Drools
        assertEquals(false, accepted);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("dto : " + dto1.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");

        // test to check that, into the drools engine, there aren't new
        // acquisition/storage related to the dto rejected
        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

        PDHT PDHTAfterInsertNewAcq = this.droolsParams.getAllPDHT().get(0);

        // test to check that the PDHT wasn't decremented after the insert of
        // the dto that is rejected
        assertEquals(PDHTBeforeInsertNewAcq, PDHTAfterInsertNewAcq);

    }

    @Test
    public void P_Test_Reject_Acquisition_For_Overlap_Acquisition2() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_Test_Reject_Acquisition_For_Overlap_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto0 = this.du.createSingleDto("10/10/2017 09:55:00", "10/10/2017 09:56:00", "right", "SAT_1");
        System.out.println("I'm inserting dto : " + dto0.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto0, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto0.getDtoId(), this.sessionId, this.currentKieSession, null);
        // I'm inserting the same dto inserted in the previous test
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "right", "SAT_1");
        System.out.println("I'm inserting dto : " + dto1.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");
        PDHT PDHTBeforeInsertNewAcq = this.droolsParams.getAllPDHT().get(0);

        // I'm inserting a new acquisition with the same start time of the
        // previous one
        DTO dto2 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:08:00", "left", "SAT_1");
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        // the dto will be rejected by Drools
        assertEquals(false, accepted);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println(this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("dto : " + dto1.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");

        // test to check that, into the drools engine, there aren't new
        // acquisition/storage related to the dto rejected
        assertEquals(1, this.droolsInstance.receiveAllAcquisitions(this.sessionId, this.currentKieSession, "SAT_1").size());
        assertEquals(1, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

        PDHT PDHTAfterInsertNewAcq = this.droolsParams.getAllPDHT().get(0);

        // test to check that the PDHT wasn't decremented after the insert of
        // the dto that is rejected
        assertEquals(PDHTBeforeInsertNewAcq, PDHTAfterInsertNewAcq);

    }

    @Test
    public void Q_Test_Reject_Acquisition_For_Overlap_Acquisition_2() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_Test_Reject_Acquisition_For_Overlap_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto2 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:01:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        System.out.println("I'm inserting dto : " + dto2.toString());
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:59:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        System.out.println("I'm inserting dto : " + dto1.toString());
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");

        DTO dto3 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:56:00", "right", "SAT_1");
        dto3.setDtoId("dto3");
        System.out.println("I'm inserting dto : " + dto3.toString());
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();
        boolean found = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("Elements rejected " + this.rejectedElements);
        System.out.println("dto : " + dto3.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");
        Map<String, Task> alltAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        System.out.println("All Accepted tasks : ");
        for (Map.Entry<String, Task> allElementsInMap : alltAcceptedTasks.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        Map<String, Acquisition> allRejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("All allRejectedElements tasks : ");
        for (Map.Entry<String, Acquisition> allElementsInMap : allRejectedElements.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        assertEquals(2, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

    }

    @Test
    public void Q_Test_Reject_Acquisition_VU() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_Test_Reject_Acquisition_For_Overlap_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto2 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:01:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        System.out.println("I'm inserting dto : " + dto2.toString());
        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:59:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        System.out.println("I'm inserting dto : " + dto1.toString());
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:56:00", "right", "SAT_1");
        dto3.setDtoId("dto3");
        dto3.setPrType(PRType.VU);
        System.out.println("I'm inserting dto : " + dto3.toString());
        inserted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTFalse(inserted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        String expectedReasonOfReject = ReasonOfReject.acqOverlapWithAcquisition.toString();
        boolean found = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        assertTrue(found);

        System.out.println("Elements rejected " + this.rejectedElements);
        System.out.println("dto : " + dto3.getDtoId() + " is rejected because " + expectedReasonOfReject + ".");
        Map<String, Task> alltAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        System.out.println("All Accepted tasks : ");
        for (Map.Entry<String, Task> allElementsInMap : alltAcceptedTasks.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        Map<String, Acquisition> allRejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("All allRejectedElements tasks : ");
        for (Map.Entry<String, Acquisition> allElementsInMap : allRejectedElements.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        assertEquals(2, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

    }

    private void assertTFalse(boolean inserted)
    {
        // TODO Auto-generated method stub

    }

    @Test
    public void Q_Test_Reject_Acquisition_VU_no_overlap() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_Test_Reject_Acquisition_For_Overlap_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto2 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:01:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        System.out.println("I'm inserting dto : " + dto2.toString());
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 17:57:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        System.out.println("I'm inserting dto : " + dto1.toString());
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        System.out.println("dto : " + dto1.getDtoId() + " is accepted.\n");

        DTO dto3 = this.du.createSingleDto("10/10/2017 17:59:00", "10/10/2017 17:59:30", "right", "SAT_1");
        dto3.setDtoId("dto3");
        dto3.setPrType(PRType.VU);
        System.out.println("I'm inserting dto : " + dto3.toString());
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        Map<String, Task> alltAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        System.out.println("All Accepted tasks : ");
        for (Map.Entry<String, Task> allElementsInMap : alltAcceptedTasks.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        Map<String, Acquisition> allRejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("All allRejectedElements tasks : ");
        for (Map.Entry<String, Acquisition> allElementsInMap : allRejectedElements.entrySet())
        {
            System.out.println("Task ID : " + allElementsInMap.getKey());
            System.out.println("Task  : " + allElementsInMap.getValue());
        }

        assertEquals(3, this.droolsInstance.receiveAllStorages(this.sessionId, this.currentKieSession, "SAT_1").size());

    }

    @Test
    public void R_Test_Reject_Acquisition_For_Unavailability_Of_Satellite() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : E_Test_Reject_Acquisition_For_Unavailability_Of_Satellite \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto1 = this.du.createSingleDto("10/10/2017 15:19:00", "10/10/2017 15:23:00", "left", "SAT_1");
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // the dto, as before, will be accepted by Drools
        assertEquals(false, accepted);
        System.out.println("accepted = false");

        /*
         * TreeMap<Long, EssAssociated> expectedOrbitThreshold =
         * droolsInstance.receiveOrbit1Threshold(currentKieSession);
         * assertEquals(expectedOrbitThreshold, orbit1ThresholdFunction);
         */
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.satelliteUnavailability);
        assertTrue(found);
    }

    @Test
    public void S_Test_Reject_Acquisition() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : E_Test_Reject_Acquisition \n\n");

        // I'm inserting the same dto inserted in the previous test
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:19:00", "10/10/2017 12:20:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto1.setSizeH(4000);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:18:00", "10/10/2017 12:18:56", "left", "SAT_1");
        dto2.setPol(Polarization.HH);
        dto2.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto2.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, Maneuver> allManRes = resFunc.getAllManeuversSat1();
        TreeMap<Long, RampCMGA> allRampRes = resFunc.getAllRampsSat1();
        TreeMap<Long, EnergyAssociatedToTask> allEssRes = resFunc.getEssFunctionSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all sil res : " + resFunc.getSilentFunctionSat1());
        System.out.println("all ramp res : " + allRampRes);
        System.out.println("all ess res : " + allEssRes);

        DTO dto3 = this.du.createSingleDto("10/10/2017 12:18:02", "10/10/2017 12:18:10", "left", "SAT_1");
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto3.setSizeH(4000);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        allManRes = resFunc.getAllManeuversSat1();
        allRampRes = resFunc.getAllRampsSat1();
        allEssRes = resFunc.getEssFunctionSat1();
        System.out.println("res function : " + resFunc);
        System.out.println("all man res : " + allManRes);
        System.out.println("all sil res : " + resFunc.getSilentFunctionSat1());
        System.out.println("all ramp res : " + allRampRes);
        System.out.println("all ess res : " + allEssRes);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("acceepted tasks : " + allAcceptedTasks);

        System.out.println("rejected : " + this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void T_testExcludeUnremovableTasks() throws ParseException, Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : E_Test_Reject_Acquisition \n\n");

        DTO dto1 = this.du.createSingleDto("10/10/2017 15:55:00", "10/10/2017 15:55:20", "right", "SAT_1");
        dto1.setSizeH(100);
        dto1.setPol(Polarization.HH);
        dto1.setPrType(PRType.VU); // so the reated acq will be unremovable

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 15:55:50", "10/10/2017 15:56:20", "right", "SAT_1");
        dto2.setPrType(PRType.HP); // so the reated acq will be removable
        dto2.setSizeH(100);
        dto2.setPol(Polarization.HH);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:55:10", "10/10/2017 15:55:58", "right", "SAT_1");
        dto3.setPrType(PRType.HP); // so the reated acq will be removable
        dto3.setSizeH(100);
        dto3.setPol(Polarization.HH);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        Map<String, Acquisition> allRejectedElements = (Map<String, Acquisition>) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "rejected");
        Acquisition acqRelativeToDto3 = allRejectedElements.get(dto3.getDtoId());

        System.out.println(allRejectedElements);
        System.out.println(acqRelativeToDto3);
        assertEquals(1, acqRelativeToDto3.getReasonOfReject().size());
    }
}
