
package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

public class TestRestoreExtraCostLeft
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "RestoreExtraCost";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 0;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void test_RestoreExtraCost_acq_left_no_neo() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : RestoreExtraCost");

        double extraCostLeft = 10;
        double imageBic = 11;
        double maxBic = 8;
        double maxNeoBic = 14;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // set extra cost for test
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        // extract partners to link to acq
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner firstAssocPartner = allPartners.get(0);
        Partner secondAssocPartner = allPartners.get(2);

        // set max bic and max neo for partners
        firstAssocPartner.setMaxBICAvailable(maxBic);
        firstAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        secondAssocPartner.setMaxBICAvailable(maxBic);
        secondAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        // setUp drools session
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // ResourceFunctions resources = (ResourceFunctions)
        // this.droolsInstance.getGlobal(this.currentKieSession,
        // "resourceFunctions");

        // creating an userInfo list that is linked to new dto
        List<UserInfo> usersAssociatedToAcq = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, firstAssocPartner.getPartnerId(), firstAssocPartner.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, secondAssocPartner.getPartnerId(), secondAssocPartner.getUgsId());
        usersAssociatedToAcq.add(userInfo1);
        usersAssociatedToAcq.add(userInfo2);

        // creating a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017 17:02:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBic);
        dto1.setUserInfo(usersAssociatedToAcq);
        dto1.setNeoAvailable(false);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // the dto is accepted
        assertTrue(accepted);

        // extract the acquisition derived from the inserted dto
        Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        // both partners are still valid
        assertEquals(2, acq.getUserInfo().size());

        System.out.println("partners before restore 1: " + firstAssocPartner);
        System.out.println("partners before restore 2: " + secondAssocPartner);

        double exectedUsedBicPartnersBeforeRestore = ((imageBic - extraCostLeft) + acq.getExtraLeft()) / acq.getUserInfo().size();

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);

        // invoke the method for restore image bic to partner
        this.droolsInstance.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);

        double exectedUsedBicPartnersAfterRestore = exectedUsedBicPartnersBeforeRestore - ((extraCostLeft) / acq.getUserInfo().size());

        System.out.println("partners after restore 1: " + firstAssocPartner);
        System.out.println("partners after restore 2: " + secondAssocPartner);
        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);

        // check consistence after retract acq
        DroolsOperations.retractSingleAcq(this.droolsParams, acq.getIdTask(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(0, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);
    }

    @Test
    public void test_RestoreExtraCost_acq_right_no_neo() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_RestoreExtraCost_acq_right_no_neo");

        double extraCostLeft = 10;
        double imageBic = 1;
        double maxBic = 8;
        double maxNeoBic = 14;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // set extra cost for test
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        // extract partners to link to acq
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner firstAssocPartner = allPartners.get(0);
        Partner secondAssocPartner = allPartners.get(2);

        // set max bic and max neo for partners
        firstAssocPartner.setMaxBICAvailable(maxBic);
        firstAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        secondAssocPartner.setMaxBICAvailable(maxBic);
        secondAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        // setUp drools session
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // creating an userInfo list that is linked to new dto
        List<UserInfo> usersAssociatedToAcq = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, firstAssocPartner.getPartnerId(), firstAssocPartner.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, secondAssocPartner.getPartnerId(), secondAssocPartner.getUgsId());
        usersAssociatedToAcq.add(userInfo1);
        usersAssociatedToAcq.add(userInfo2);

        // creating a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017 17:02:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBic);
        dto1.setUserInfo(usersAssociatedToAcq);
        dto1.setNeoAvailable(false);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // the dto is accepted
        assertTrue(accepted);

        // extract the acquisition derived from the inserted dto
        Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        // both partners are still valid
        assertEquals(2, acq.getUserInfo().size());

        System.out.println("partners before restore 1: " + firstAssocPartner);
        System.out.println("partners before restore 2: " + secondAssocPartner);

        double exectedUsedBicPartnersBeforeRestore = (imageBic) / acq.getUserInfo().size();

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);

        // invoke the method for restore image bic to partner
        this.droolsInstance.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);

        double exectedUsedBicPartnersAfterRestore = exectedUsedBicPartnersBeforeRestore;

        System.out.println("partners after restore 1: " + firstAssocPartner);
        System.out.println("partners after restore 2: " + secondAssocPartner);
        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);

        // check consistence after retract acq
        DroolsOperations.retractSingleAcq(this.droolsParams, acq.getIdTask(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(0, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);
    }

    @Test
    public void test_RestoreExtraCost_acq_right_neo() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_RestoreExtraCost_acq_right_neo");

        double extraCostLeft = 10;
        double imageBic = 1;
        double maxBic = 8;
        double maxNeoBic = 14;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // set extra cost for test
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        // extract partners to link to acq
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner firstAssocPartner = allPartners.get(0);
        Partner secondAssocPartner = allPartners.get(2);

        // set max bic and max neo for partners
        firstAssocPartner.setMaxBICAvailable(maxBic);
        firstAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        secondAssocPartner.setMaxBICAvailable(maxBic);
        secondAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        // setUp drools session
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // creating an userInfo list that is linked to new dto
        List<UserInfo> usersAssociatedToAcq = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, firstAssocPartner.getPartnerId(), firstAssocPartner.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, secondAssocPartner.getPartnerId(), secondAssocPartner.getUgsId());
        usersAssociatedToAcq.add(userInfo1);
        usersAssociatedToAcq.add(userInfo2);

        // creating a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017 17:02:00", "right", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBic);
        dto1.setUserInfo(usersAssociatedToAcq);
        dto1.setNeoAvailable(true);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // the dto is accepted
        assertTrue(accepted);

        // extract the acquisition derived from the inserted dto
        Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        // both partners are still valid
        assertEquals(2, acq.getUserInfo().size());

        System.out.println("partners before restore 1: " + firstAssocPartner);
        System.out.println("partners before restore 2: " + secondAssocPartner);

        double exectedUsedBicPartnersBeforeRestore = (imageBic) / acq.getUserInfo().size();

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedNeoBic(), 0);

        // invoke the method for restore image bic to partner
        this.droolsInstance.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);

        double exectedUsedBicPartnersAfterRestore = exectedUsedBicPartnersBeforeRestore;

        System.out.println("partners after restore 1: " + firstAssocPartner);
        System.out.println("partners after restore 2: " + secondAssocPartner);
        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedNeoBic(), 0);

        // check consistence after retract acq
        DroolsOperations.retractSingleAcq(this.droolsParams, acq.getIdTask(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(0, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);
    }

    @Test
    public void test_RestoreExtraCost_acq_left_neo() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_RestoreExtraCost_acq_left_neo");

        double extraCostLeft = 10;
        double imageBic = 11;
        double maxBic = 8;
        double maxNeoBic = 14;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // set extra cost for test
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        // extract partners to link to acq
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner firstAssocPartner = allPartners.get(0);
        Partner secondAssocPartner = allPartners.get(2);

        // set max bic and max neo for partners
        firstAssocPartner.setMaxBICAvailable(maxBic);
        firstAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        secondAssocPartner.setMaxBICAvailable(maxBic);
        secondAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        // setUp drools session
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // ResourceFunctions resources = (ResourceFunctions)
        // this.droolsInstance.getGlobal(this.currentKieSession,
        // "resourceFunctions");

        // creating an userInfo list that is linked to new dto
        List<UserInfo> usersAssociatedToAcq = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, firstAssocPartner.getPartnerId(), firstAssocPartner.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, secondAssocPartner.getPartnerId(), secondAssocPartner.getUgsId());
        usersAssociatedToAcq.add(userInfo1);
        usersAssociatedToAcq.add(userInfo2);

        // creating a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017 17:02:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBic);
        dto1.setUserInfo(usersAssociatedToAcq);
        dto1.setNeoAvailable(true);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // the dto is accepted
        assertTrue(accepted);

        // extract the acquisition derived from the inserted dto
        Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);

        // both partners are still valid
        System.out.println("acq : " + acq);
        assertEquals(2, acq.getUserInfo().size());

        System.out.println("partners before restore 1: " + firstAssocPartner);
        System.out.println("partners before restore 2: " + secondAssocPartner);

        double exectedUsedBicPartnersBeforeRestore = (imageBic) / acq.getUserInfo().size();

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedNeoBic(), 0);

        // invoke the method for restore image bic to partner
        this.droolsInstance.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);

        double exectedUsedBicPartnersAfterRestore = exectedUsedBicPartnersBeforeRestore - ((extraCostLeft) / acq.getUserInfo().size());

        System.out.println("partners after restore 1: " + firstAssocPartner);
        System.out.println("partners after restore 2: " + secondAssocPartner);
        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedNeoBic(), 0);

        // check consistence after retract acq
        DroolsOperations.retractSingleAcq(this.droolsParams, acq.getIdTask(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(0, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);
    }

    @Test
    public void test_RestoreExtraCost_acq_left_neo_with_loan() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_RestoreExtraCost_acq_left_neo_with_loan");

        double extraCostLeft = 10;
        double imageBic = 12;
        double maxBic = 3;
        double maxNeoBic = 14;

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);

        // set extra cost for test
        this.droolsParams.setExtraCostLeft(extraCostLeft);

        // extract partners to link to acq
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        Partner firstAssocPartner = allPartners.get(0);
        Partner secondAssocPartner = allPartners.get(2);

        Partner otherPartner1 = allPartners.get(1);
        otherPartner1.setFinished(true);
        otherPartner1.setBorrowingBic(new ArrayList<>(Arrays.asList(firstAssocPartner.getPartnerId(), secondAssocPartner.getPartnerId())));

        Partner otherPartner2 = allPartners.get(3);
        otherPartner2.setFinished(true);
        otherPartner2.setBorrowingBic(new ArrayList<>(Arrays.asList(secondAssocPartner.getPartnerId())));

        // set max bic and max neo for partners
        firstAssocPartner.setMaxBICAvailable(maxBic);
        firstAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        secondAssocPartner.setMaxBICAvailable(maxBic);
        secondAssocPartner.setMaxNEOBicAvailable(maxNeoBic);

        // setUp drools session
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // creating an userInfo list that is linked to new dto
        List<UserInfo> usersAssociatedToAcq = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, firstAssocPartner.getPartnerId(), firstAssocPartner.getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, secondAssocPartner.getPartnerId(), secondAssocPartner.getUgsId());
        usersAssociatedToAcq.add(userInfo1);
        usersAssociatedToAcq.add(userInfo2);

        // creating a dto
        DTO dto1 = this.du.createSingleDto("10/10/2017 17:00:00", "10/10/2017 17:02:00", "left", "SAT_1");
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBic);
        dto1.setUserInfo(usersAssociatedToAcq);
        dto1.setNeoAvailable(true);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        // the dto is accepted
        assertTrue(accepted);

        // extract the acquisition derived from the inserted dto
        Acquisition acq = this.droolsInstance.receiveAcceptedAcquisitionWithId(dto1.getDtoId(), this.sessionId, this.currentKieSession);
        System.out.println("acq : " + acq);
        // both partners are still valid
        assertEquals(2, acq.getUserInfo().size());

        System.out.println("partners before restore 1: " + firstAssocPartner);
        System.out.println("partners before restore 2: " + secondAssocPartner);

        double exectedUsedBicPartnersBeforeRestore = 6;

        double totalLoanPartner1 = firstAssocPartner.getTotalLoan();
        double totalLoanPartner2 = secondAssocPartner.getTotalLoan();

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedBIC() + totalLoanPartner1, 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedBIC() + totalLoanPartner2, 0);

        assertEquals(exectedUsedBicPartnersBeforeRestore, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(exectedUsedBicPartnersBeforeRestore, secondAssocPartner.getUsedNeoBic(), 0);

        System.out.println("others partners : ");
        System.out.println("p2 : " + otherPartner1);
        System.out.println("p4 : " + otherPartner2);

        assertEquals(1, firstAssocPartner.getLoanList().size());

        // invoke the method for restore image bic to partner
        this.droolsInstance.restoreExtraCostLeftAcq(this.sessionId, this.currentKieSession, this.droolsParams);

        double exectedUsedBicPartnersAfterRestore = exectedUsedBicPartnersBeforeRestore - ((extraCostLeft) / acq.getUserInfo().size());

        System.out.println("partners after restore 1: " + firstAssocPartner);
        System.out.println("partners after restore 2: " + secondAssocPartner);
        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(exectedUsedBicPartnersAfterRestore, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(exectedUsedBicPartnersAfterRestore, secondAssocPartner.getUsedNeoBic(), 0);

        // check consistence after retract acq
        DroolsOperations.retractSingleAcq(this.droolsParams, acq.getIdTask(), this.sessionId, this.currentKieSession, null);

        assertEquals(0, firstAssocPartner.getUsedBIC(), 0);
        assertEquals(0, secondAssocPartner.getUsedBIC(), 0);

        assertEquals(0, firstAssocPartner.getUsedNeoBic(), 0);
        assertEquals(0, secondAssocPartner.getUsedNeoBic(), 0);
    }
}
