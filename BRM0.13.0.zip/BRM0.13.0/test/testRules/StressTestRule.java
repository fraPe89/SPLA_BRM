/**
*
* MODULE FILE NAME:	StressTest.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		24 nov 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 24 nov 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resources.PDHT;

/**
 * @author fpedrola
 *
 */
public class StressTestRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "Test_1000_dto";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void test_StressTest_50_Dto() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_StressTest_300_Dto");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_.txt");
        Logger logger = DroolsParameters.getLogger();
        logger.debug("current date before setup : " + new Date());
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        PDHT initialPdht_Sat1 = this.droolsInstance.getPDHTStatus(this.droolsParams.getCurrentMH().getStart(), "SAT_1", this.sessionId, this.currentKieSession);
        PDHT initialPdht_Sat2 = this.droolsInstance.getPDHTStatus(this.droolsParams.getCurrentMH().getStart(), "SAT_2", this.sessionId, this.currentKieSession);
        assertEquals(initialPdht_Sat1, this.droolsInstance.receivePDHTFunction(this.sessionId, this.currentKieSession, "SAT_1").firstEntry().getValue().getPdht());
        assertEquals(initialPdht_Sat2, this.droolsInstance.receivePDHTFunction(this.sessionId, this.currentKieSession, "SAT_2").firstEntry().getValue().getPdht());
//
//        List<DTO> generatedDto = this.du.generateListOfDto(300, this.droolsParams);
//        System.out.println("generatedDto " + generatedDto);
//        this.droolsInstance.insertListDto(generatedDto, this.sessionId, this.currentKieSession, this.droolsParams);
//        logger.debug("current date after setup : " + new Date());
//
//        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
//        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
//
//        int contAcceptedAcq = 0;
//        for (Map.Entry<String, Task> allElementsInMap : allAcceptedTasks.entrySet())
//        {
//            if (allElementsInMap.getValue() instanceof Acquisition)
//            {
//                contAcceptedAcq++;
//            }
//        }
//
//        System.out.println("All Accepted tasks : " + contAcceptedAcq);
//        System.out.println("All Rejected tasks : " + this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession).size());
//        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
//
//        List<Task> allTasksAsList = new ArrayList<>();
//        for (Map.Entry<String, Task> allAccTaskList : allAcceptedTasks.entrySet())
//        {
//            allTasksAsList.add(allAccTaskList.getValue());
//        }
//
//        this.droolsInstance.initPlan(this.droolsParams, allTasksAsList, null, this.sessionId, this.currentKieSession, false);
//
//        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

}
