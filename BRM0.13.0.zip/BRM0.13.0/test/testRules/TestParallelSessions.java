
package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.SessionHandler;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

public class TestParallelSessions
{

    private String sessionId = null;
    private int parallelSession1 = 0;
    private int parallelSession2 = 1;
    private Long PDHTMaxMemory = 0l;

    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "ParallelSession";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.parallelSession1, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.parallelSession1);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void test_InitPlan() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();

        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.parallelSession1, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.parallelSession1);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.parallelSession1);
        assertTrue(accepted);

        System.out.println("inserting dto 1 in session 1 ");

        List<Task> allTasks = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.parallelSession1, this.droolsParams, dto1.getSatelliteId());
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession1, "resourceFunctions");
        System.out.println("all tasks : " + allTasks);
        System.out.println("all man : " + resFunc.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc.getAllRampsSat1());
        System.out.println("all acq : " + resFunc.getEssFunctionSat1());

        System.out.println("switching to another session ");
        System.out.println("drools params current sessions : " + SessionHandler.getKieSessionsMap());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.parallelSession2, "_");

        List<Task> allTasks2 = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.parallelSession2, this.droolsParams, dto1.getSatelliteId());
        ResourceFunctions resFunc2 = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession2, "resourceFunctions");

        System.out.println("all tasks : " + allTasks2);
        System.out.println("all man : " + resFunc2.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc2.getAllRampsSat1());
        System.out.println("all acq : " + resFunc2.getEssFunctionSat1());

        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:55:00", "10/10/2017 07:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.parallelSession2);
        assertTrue(accepted);

        System.out.println("inserting dto 2 in session 2 ");
        allTasks2 = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.parallelSession2, this.droolsParams, dto1.getSatelliteId());
        resFunc2 = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession2, "resourceFunctions");
        System.out.println("all tasks : " + allTasks2);
        System.out.println("all man : " + resFunc2.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc2.getAllRampsSat1());
        System.out.println("all acq : " + resFunc2.getEssFunctionSat1());

        System.out.println("switch back to session 1");

        allTasks2 = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.parallelSession1, this.droolsParams, dto1.getSatelliteId());

        resFunc2 = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession1, "resourceFunctions");
        System.out.println("all tasks : " + allTasks2);
        System.out.println("all man : " + resFunc2.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc2.getAllRampsSat1());
        System.out.println("all acq : " + resFunc2.getEssFunctionSat1());
        assertEquals(1, resFunc2.getEssFunctionSat1().size());
    }

    @Test
    public void test_InitPlan_2() throws IOException, ParseException, Exception
    {
        DroolsOperations droolsInstance1 = null;

        DroolsOperations droolsInstance2 = null;

        droolsInstance1 = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.parallelSession1, this.PDHTMaxMemory, 100, 3);

        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, droolsInstance1);
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();

        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        droolsInstance1 = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, droolsInstance1, this.parallelSession1, "_");
        Map<String, Acquisition> rejected = droolsInstance1.receiveDtoRejected(this.sessionId, this.parallelSession1);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = droolsInstance1.insertDto(this.droolsParams, dto1, this.sessionId, this.parallelSession1);
        assertTrue(accepted);

        System.out.println("inserting dto 1 in session 1 ");

        List<Task> allTasks = droolsInstance1.receiveDtoAccepted(this.sessionId, this.parallelSession1, this.droolsParams, dto1.getSatelliteId());
        ResourceFunctions resFunc = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession1, "resourceFunctions");
        System.out.println("all tasks : " + allTasks);
        System.out.println("all man : " + resFunc.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc.getAllRampsSat1());
        System.out.println("all acq : " + resFunc.getEssFunctionSat1());

        // switch to another session
        System.out.println("switching to another session ");
        System.out.println("drools params current sessions : " + SessionHandler.getKieSessionsMap());

        droolsInstance2 = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.parallelSession2, this.PDHTMaxMemory, 100, 3);
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);

        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getSatelliteState().clear();
        this.droolsParams.getAllPAWS().clear();

        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, droolsInstance2);
        droolsInstance2 = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, droolsInstance2, this.parallelSession2, "_");

        List<Task> allTasks2 = droolsInstance2.receiveDtoAccepted(this.sessionId, this.parallelSession2, this.droolsParams, dto1.getSatelliteId());
        ResourceFunctions resFunc2 = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession2, "resourceFunctions");

        System.out.println("all tasks : " + allTasks2);
        System.out.println("all man : " + resFunc2.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc2.getAllRampsSat1());
        System.out.println("all acq : " + resFunc2.getEssFunctionSat1());

        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:55:00", "10/10/2017 07:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = droolsInstance2.insertDto(this.droolsParams, dto2, this.sessionId, this.parallelSession2);
        assertTrue(accepted);

        System.out.println("inserting dto 2 in session 2 ");
        allTasks2 = droolsInstance2.receiveDtoAccepted(this.sessionId, this.parallelSession2, this.droolsParams, dto1.getSatelliteId());
        resFunc2 = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession2, "resourceFunctions");
        System.out.println("all tasks : " + allTasks2);
        System.out.println("all man : " + resFunc2.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc2.getAllRampsSat1());
        System.out.println("all acq : " + resFunc2.getEssFunctionSat1());

        System.out.println("switch back to session 1");

        List<Task> allTasks1 = droolsInstance1.receiveDtoAccepted(this.sessionId, this.parallelSession1, this.droolsParams, dto1.getSatelliteId());

        ResourceFunctions resFunc1 = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.parallelSession1, "resourceFunctions");

        System.out.println("for session 1 ");
        System.out.println("all tasks : " + allTasks1);
        System.out.println("all man : " + resFunc1.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc1.getAllRampsSat1());
        System.out.println("all acq : " + resFunc1.getEssFunctionSat1());

        System.out.println("for session 2 ");
        System.out.println("all tasks : " + allTasks2);
        System.out.println("all man : " + resFunc2.getAllManeuversSat1());
        System.out.println("all ramps : " + resFunc2.getAllRampsSat1());
        System.out.println("all acq : " + resFunc2.getEssFunctionSat1());

        assertEquals(1, resFunc2.getEssFunctionSat1().size());
    }
}
