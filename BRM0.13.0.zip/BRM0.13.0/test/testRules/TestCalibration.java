/**
*
* MODULE FILE NAME:	TestCalibration.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		04 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 04 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.Task;

/**
 * @author francesca
 *
 */
public class TestCalibration
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private Map<String, Acquisition> rejectedElements = null;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private StubResources stub = new StubResources();

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "Test_Calibration";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.rejectedElements = new HashMap<>();
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testInsert_TRCAL() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:59:00", "10/10/2017 08:01:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        dto1.setSensorMode(TypeOfAcquisition.TRCAL);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is partially included inside paw of type CAl at end ->
        // rejected
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:08:00", "10/10/2017 08:10:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        dto2.setSensorMode(TypeOfAcquisition.TRCAL);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally outside paw of type CAl -> rejected
        DTO dto3 = this.du.createSingleDto("10/10/2017 07:58:00", "10/10/2017 07:59:00", "right", "SAT_1");
        dto3.setDtoId("dto3");
        dto3.setSensorMode(TypeOfAcquisition.TRCAL);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto3.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally included inside paw of type different from CAL
        // (STOCCULTATION) -> rejected
        DTO dto4 = this.du.createSingleDto("10/10/2017 09:01:00", "10/10/2017 09:02:00", "right", "SAT_1");
        dto4.setDtoId("dto4");
        dto4.setSensorMode(TypeOfAcquisition.TRCAL);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto4.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally included inside paw of type CAl -> accepted
        DTO dto5 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:02:00", "right", "SAT_1");
        dto5.setDtoId("dto5");
        dto5.setSensorMode(TypeOfAcquisition.TRCAL);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is totally included inside paw of type CAl -> accepted
        DTO dto6 = this.du.createSingleDto("10/10/2017 08:01:50", "10/10/2017 08:03:00", "right", "SAT_1");
        dto6.setDtoId("dto6");
        dto6.setSensorMode(TypeOfAcquisition.TRCAL);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto6.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        System.out.println("found ? " + found);
        assertTrue(found);
    }

    @Test
    public void testInsert_POC2048_ok() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));
        this.sessionId = "2340";
        this.currentKieSession = 0;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:59:00", "10/10/2017 08:01:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        dto1.setSensorMode(TypeOfAcquisition.POC2048);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is partially included inside paw of type CAl at end ->
        // rejected
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:08:00", "10/10/2017 08:10:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        dto2.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally outside paw of type CAl -> accepted
        DTO dto3 = this.du.createSingleDto("10/10/2017 07:58:00", "10/10/2017 07:59:00", "right", "SAT_1");
        dto3.setDtoId("dto3");
        dto3.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is totally included inside paw of type different from CAL
        // (STOCCULTATION) -> rejected
        DTO dto4 = this.du.createSingleDto("10/10/2017 09:01:00", "10/10/2017 09:02:00", "right", "SAT_1");
        dto4.setDtoId("dto4");
        dto4.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto4.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally included inside paw of type CAl -> accepted
        DTO dto5 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:02:00", "right", "SAT_1");
        dto5.setDtoId("dto5");
        dto5.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is totally included inside paw of type CAl -> accepted
        DTO dto6 = this.du.createSingleDto("10/10/2017 08:01:50", "10/10/2017 08:03:00", "right", "SAT_1");
        dto6.setDtoId("dto6");
        dto6.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto6.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        System.out.println("found ? " + found);
        assertTrue(found);
    }

    @Test
    public void testInsert_POC2048() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO dto1 = this.du.createSingleDto("10/10/2017 07:59:00", "10/10/2017 08:01:00", "right", "SAT_1");
        dto1.setDtoId("dto1");
        dto1.setSensorMode(TypeOfAcquisition.POC2048);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(dto1.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is partially included inside paw of type CAl at end ->
        // rejected
        DTO dto2 = this.du.createSingleDto("10/10/2017 08:08:00", "10/10/2017 08:10:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        dto2.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally outside paw of type CAl -> accepted
        DTO dto3 = this.du.createSingleDto("10/10/2017 07:58:00", "10/10/2017 07:59:00", "right", "SAT_1");
        dto3.setDtoId("dto3");
        dto3.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is totally included inside paw of type different from CAL
        // (STOCCULTATION) -> rejected
        DTO dto4 = this.du.createSingleDto("10/10/2017 09:01:00", "10/10/2017 09:02:00", "right", "SAT_1");
        dto4.setDtoId("dto4");
        dto4.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto4.getDtoId(), this.rejectedElements, ReasonOfReject.cannotPerformCalibration);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is totally included inside paw of type CAl -> accepted
        DTO dto5 = this.du.createSingleDto("10/10/2017 08:00:00", "10/10/2017 08:02:00", "right", "SAT_1");
        dto5.setDtoId("dto5");
        dto5.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is totally included inside paw of type CAl -> accepted
        DTO dto6 = this.du.createSingleDto("10/10/2017 08:01:50", "10/10/2017 08:03:00", "right", "SAT_1");
        dto6.setDtoId("dto6");
        dto6.setSensorMode(TypeOfAcquisition.POC2048);

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        System.out.println("rejected elements : " + this.rejectedElements);
        found = this.du.checkIfContainsTheExpectedReason(dto6.getDtoId(), this.rejectedElements, ReasonOfReject.acqOverlapWithAcquisition);
        System.out.println("found ? " + found);
        assertTrue(found);
    }

    @Test
    public void testInsert_BITE() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is totally included inside paw of type CAl at start ->
        // accepted
        DTO dto1 = this.du.createSingleDto("10/10/2017 08:01:00", "10/10/2017 08:01:10", "right", "SAT_1");
        dto1.setDtoId("dto1");
        dto1.setSensorMode(TypeOfAcquisition.BITE);

        Bite bite = new Bite(2, "moduleId", "prova", "ps1");
        dto1.setAssociatedBite(bite);

        boolean inserted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(inserted);
        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        System.out.println("tasks accepted " + alltasksAccepted);

        System.out.println("rejected elements : " + this.rejectedElements);
        assertEquals(0, this.rejectedElements.size());

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO dto2 = this.du.createSingleDto("10/10/2017 07:59:00", "10/10/2017 08:01:00", "right", "SAT_1");
        dto2.setDtoId("dto2");
        dto2.setSensorMode(TypeOfAcquisition.BITE);

        Bite bite2 = new Bite(2, "moduleId", "prova", "ps1");
        dto2.setAssociatedBite(bite2);

        inserted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertFalse(inserted);

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO dto3 = this.du.createSingleDto("10/10/2017 08:08:00", "10/10/2017 08:09:45", "right", "SAT_1");
        dto3.setDtoId("dto3");
        dto3.setSensorMode(TypeOfAcquisition.BITE);

        Bite bite3 = new Bite(3, "moduleId", "prova", "ps1");
        dto3.setAssociatedBite(bite3);

        inserted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertFalse(inserted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

    }
}
