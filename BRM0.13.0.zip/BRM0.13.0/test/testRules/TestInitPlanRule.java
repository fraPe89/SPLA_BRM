/**
*
* MODULE FILE NAME:	TestMaxNumberPrType.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		17 ott 2017
*
* AUTHORS:		fpedrola
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 17 ott 2017          | fpedrola    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.TaskPlanned;
import com.nais.spla.brm.library.main.ontology.enums.Actuator;
import com.nais.spla.brm.library.main.ontology.enums.DownlinkStrategy;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.ComplexPdht;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.UserInfo;
import com.nais.spla.brm.library.main.ontology.resources.Partner;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Bite;
import com.nais.spla.brm.library.main.ontology.tasks.Download;
import com.nais.spla.brm.library.main.ontology.tasks.Maneuver;
import com.nais.spla.brm.library.main.ontology.tasks.StoreAUX;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author fpedrola
 *
 */
public class TestInitPlanRule
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private TaskPlanned taskPlanned = null;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "initPlan";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.taskPlanned = new TaskPlanned();
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void A_initPlanAcq() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getAllVisibilities().clear();
        DTO dto1 = this.du.createSingleDto("10/10/2017 12:08:03", "10/10/2017 12:09:00", "left", "SAT_1");
        double imageBicDto1 = 2;
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 13:08:03", "10/10/2017 13:09:00", "left", "SAT_1");
        double imageBicDto2 = 12;
        dto2.setPol(Polarization.HH);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("PLANNED TASKS : " + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }

        this.currentKieSession = 3;

        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsInstance.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId, this.currentKieSession, true);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:55:00", "10/10/2017 10:56:00", "left", "SAT_1");
        double imageBicDto3 = 12;
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.HP);
        dto3.setImageBIC(imageBicDto3);
        // dto1.setPartnersAssociatedToDto(partnersAssociated);
        System.out.println("I'm inserting dto : " + dto3.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
    }

    @Test
    public void B_initPlanSto() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

    }

    @Test
    public void C_initPlanMan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Maneuver man1 = this.du.createManeuver("", "", "", "10/10/2017 12:50:00", "10/10/2017 12:54:00", "SAT_1", Actuator.ReactionWheels);

        List<Task> previousTasks = new ArrayList<>();
        previousTasks.add(man1);
        this.droolsInstance.initPlan(this.droolsParams, previousTasks, null, this.sessionId, this.currentKieSession, true);

    }

    @Test
    public void D_initPlanMan_withMan() throws Exception
    {
        this.sessionId = "D_initPlanMan_withMan";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 12:39:00", "10/10/2017 12:40:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> previousTasks = new ArrayList<>();
        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> prevTasks : alltasksAccepted.entrySet())
        {
            previousTasks.add(prevTasks.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        this.currentKieSession = 5;
        Date newMhStart = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date newMhStop = DroolsUtils.createDate("11/10/2017 08:21:00");

        MissionHorizon mh = new MissionHorizon(newMhStart, newMhStop);

        this.droolsParams.setCurrentMH(mh);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, previousTasks, null, this.sessionId, this.currentKieSession, true);

        DTO dto2 = this.du.createSingleDto("11/10/2017 04:39:00", "11/10/2017 04:40:00", "right", "SAT_1");
        double imageBicDto2 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> prevTasks : alltasksAccepted.entrySet())
        {
            System.out.println(prevTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void D_initPlan_lastAcqInTheMiddleOfMh() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:20:50", "10/10/2017 18:22:00", "left", "SAT_1");
        double imageBicDto1 = 1;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> previousTasks = new ArrayList<>();
        Map<String, Task> alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> prevTasks : alltasksAccepted.entrySet())
        {
            previousTasks.add(prevTasks.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        this.currentKieSession = 5;
        Date newMhStart = DroolsUtils.createDate("10/10/2017 18:22:00");
        Date newMhStop = DroolsUtils.createDate("11/10/2017 08:21:00");

        MissionHorizon mh = new MissionHorizon(newMhStart, newMhStop);
        this.droolsParams.getSatWithId("SAT_1").setInitialLookSide("left");
        this.droolsParams.setCurrentMH(mh);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.initPlan(this.droolsParams, previousTasks, null, this.sessionId, this.currentKieSession, true);

        DTO dto2 = this.du.createSingleDto("11/10/2017 04:39:00", "11/10/2017 04:40:00", "right", "SAT_1");
        double imageBicDto2 = 1;
        dto2.setPol(Polarization.HH);
        dto2.setSizeH(400);
        dto2.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto2.setPrType(PRType.HP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        alltasksAccepted = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> prevTasks : alltasksAccepted.entrySet())
        {
            System.out.println(prevTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void H_initPlanBite() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Date biteStart = DroolsUtils.createDate("11/10/2017 04:39:00");
        Date biteEnd = DroolsUtils.createDate("11/10/2017 04:39:50");
        Bite bite = new Bite();
        bite.setIdTask("biteId");
        bite.setModuleId("biteForTest");
        bite.setFillerWord("fillerWord");
        bite.setSatelliteId("sat_1");
        bite.setStartTime(biteStart);
        bite.setEndTime(biteEnd);

        List<Task> previousTasks = new ArrayList<>();
        previousTasks.add(bite);
        this.droolsInstance.initPlan(this.droolsParams, previousTasks, null, this.sessionId, this.currentKieSession, true);
    }

    @Test
    public void I_initPlanDwl() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Download dwl = this.du.createDownload("SAT_1", "11/10/2017 04:39:00", "11/10/2017 04:49:00", DownlinkStrategy.RETAIN, false);
        dwl.setRelatedTaskId("GPS_5");
        List<Task> previousTasks = new ArrayList<>();
        previousTasks.add(dwl);
        this.droolsInstance.initPlan(this.droolsParams, previousTasks, null, this.sessionId, this.currentKieSession, true);
    }

    @Test
    public void I_initPlanStoreAux() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        Date start = DroolsUtils.createDate("10/10/2017 18:00:00");
        Date end = DroolsUtils.createDate("10/10/2017 18:00:00");

        StoreAUX storeAux = new StoreAUX(false, "1");
        storeAux.setIdTask("storeAuxId");
        storeAux.setStartTime(start);
        storeAux.setEndTime(end);
        storeAux.setSatelliteId("SAT_1");

        List<Task> previousTasks = new ArrayList<>();
        previousTasks.add(storeAux);
        this.droolsInstance.initPlan(this.droolsParams, previousTasks, null, this.sessionId, this.currentKieSession, true);
    }

    @Test
    public void B_TestOverlapInitPlan() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getAllPAWS().clear();

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";

        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:01:30", "right", satelliteId);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:55:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            allPlannedTasksAsList.add(allTasks.getValue());
        }

        this.currentKieSession = 3;

        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsInstance.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId, this.currentKieSession, true);

        DTO dto3 = this.du.createSingleDto("10/10/2017 12:54:00", "10/10/2017 12:55:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(false, accepted);
    }

    @Test
    public void test_InitPlan() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_1_.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:50:10", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:55:00", "10/10/2017 06:56:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto3 = 2;
        DTO dto3 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:02:00", "left", "SAT_1");
        dto3.setPrType(PRType.PP);
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setImageBIC(imageBicDto3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto4 = 1;
        DTO dto4 = this.du.createSingleDto("10/10/2017 14:55:00", "10/10/2017 14:57:00", "right", "SAT_1");
        dto4.setPrType(PRType.CIVILIAN_HP);
        dto4.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto4.setImageBIC(imageBicDto4);
        dto4.setRevolutionNumber(3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // TODO : rimettere acq5 a left e capire come viene calcolato tempo
        // right che � decisamente molto pi� di quanto dovrebbe essere
        double imageBicDto5 = 4;
        DTO dto5 = this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:56:00", "right", "SAT_1");
        dto5.setPrType(PRType.PP);
        dto5.setImageBIC(imageBicDto5);
        dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        dto5.setRevolutionNumber(4);
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto6 = 2;
        DTO dto6 = this.du.createSingleDto("10/10/2017 06:30:00", "10/10/2017 06:32:00", "right", "SAT_1");
        dto6.setPrType(PRType.PP);
        dto6.setImageBIC(imageBicDto6);
        dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        dto6.setRevolutionNumber(4);
        System.out.println("I'm inserting dto (Print): " + dto6.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> allAccepted = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);

        System.out.println("changing the current session from : " + this.currentKieSession);
        this.currentKieSession = 3;
        System.out.println("to : " + this.currentKieSession);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_2_.txt");
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourcesForSecondSession = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = resourcesForSecondSession.getEssFunctionSat1();
        TreeMap<Long, ComplexPdht> pdhtFunctionSat1 = resourcesForSecondSession.getPDHTTemporalFunctionSat1();
        TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1 = resourcesForSecondSession.getSilentFunctionSat1();
        TreeMap<Long, Maneuver> manFunctionSat1 = resourcesForSecondSession.getAllManeuversSat1();
        System.out.println("ESS FUNCTION BEFORE: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION BEFORE: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION BEFORE: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION BEFORE: " + manFunctionSat1.size());
        for (int i = 0; i < allAccepted.size(); i++)
        {
            /*
             * if(allAccepted.get(i) instanceof Maneuver) {
             * System.out.println("REMOVED FOR TEST A DOWNLOAD : "+allAccepted.
             * get(i)); allAccepted.remove(i); }
             */
        }
        this.droolsInstance.initPlan(this.droolsParams, allAccepted, null, this.sessionId, this.currentKieSession, true);

        DTO newDto = this.du.createSingleDto("10/10/2017 06:30:00", "10/10/2017 06:32:00", "right", "SAT_1");
        newDto.setPrType(PRType.PP);
        newDto.setImageBIC(2);
        newDto.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        newDto.setRevolutionNumber(4);
        System.out.println("I'm inserting dto (Print): " + newDto.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, newDto, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        Map<String, Acquisition> rejected2 = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejectedElements ");
        for (Map.Entry<String, Acquisition> rejectedElements : rejected2.entrySet())
        {
            System.out.println(rejectedElements.getKey() + " ....................... " + rejectedElements.getValue().getReasonOfReject());
        }
        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println(" acquisitions accepted as Map : " + allAcq);

        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("ESS FUNCTION AFTER: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION AFTER: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION AFTER: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION AFTER: " + manFunctionSat1.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void test_InitPlan_simple_case() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_1_.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        this.droolsParams.getAllPAWS().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, allPartners.get(1).getPartnerId(), allPartners.get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, allPartners.get(2).getPartnerId(), allPartners.get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> allAccepted = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        System.out.println("changing the current session from : " + this.currentKieSession);
        this.currentKieSession = 3;
        System.out.println("to : " + this.currentKieSession);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_2_.txt");
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourcesForSecondSession = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = resourcesForSecondSession.getEssFunctionSat1();
        TreeMap<Long, ComplexPdht> pdhtFunctionSat1 = resourcesForSecondSession.getPDHTTemporalFunctionSat1();
        TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1 = resourcesForSecondSession.getSilentFunctionSat1();
        TreeMap<Long, Maneuver> manFunctionSat1 = resourcesForSecondSession.getAllManeuversSat1();
        System.out.println("ESS FUNCTION BEFORE: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION BEFORE: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION BEFORE: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION BEFORE: " + manFunctionSat1.size());

        System.out.println("all accepted : " + allAccepted);

        this.droolsInstance.initPlan(this.droolsParams, allAccepted, null, this.sessionId, this.currentKieSession, true);

        DTO newDto = this.du.createSingleDto("10/10/2017 17:52:00", "10/10/2017 17:54:00", "left", "SAT_1");
        newDto.setPrType(PRType.PP);
        newDto.setImageBIC(2);
        newDto.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        newDto.setRevolutionNumber(4);
        System.out.println("I'm inserting dto (Print): " + newDto.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, newDto, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        Map<String, Acquisition> rejected2 = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejectedElements ");
        for (Map.Entry<String, Acquisition> rejectedElements : rejected2.entrySet())
        {
            System.out.println(rejectedElements.getKey() + " ....................... " + rejectedElements.getValue().getReasonOfReject());
        }
        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println(" acquisitions : " + allAcq);

        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("ESS FUNCTION AFTER: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION AFTER: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION AFTER: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION AFTER: " + manFunctionSat1.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void test_InitPlan2() throws IOException, Exception
    {
        this.sessionId = "INITPLAN2_";
        System.out.println("\n\n\n\nRUNNING TEST : InitPlan");
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_TerniInitPlan.txt");
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        this.droolsParams.getHpExclusionList().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversRW(0);
        this.droolsParams.getSatWithId("SAT_1").getSatelliteProperties().getAllChecksOnOrbits().get(1.0).setMaxManeuversCMGA(10);

        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:50:00", "10/10/2017 17:52:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        dto1.setSizeH(400);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);
        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto2 = 9;
        DTO dto2 = this.du.createSingleDto("10/10/2017 06:55:00", "10/10/2017 07:00:00", "right", "SAT_1");
        dto2.setPrType(PRType.HP);
        dto2.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto2.setImageBIC(imageBicDto2);
        System.out.println("I'm inserting dto : " + dto2.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        double imageBicDto3 = 2;
        DTO dto3 = this.du.createSingleDto("10/10/2017 11:00:00", "10/10/2017 11:02:00", "left", "SAT_1");
        dto3.setPrType(PRType.PP);
        dto3.setPol(Polarization.HH);
        dto3.setSensorMode(TypeOfAcquisition.PINGPONG);
        dto3.setImageBIC(imageBicDto3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        double imageBicDto4 = 1;
        DTO dto4 = this.du.createSingleDto("10/10/2017 14:55:00", "10/10/2017 14:57:00", "right", "SAT_1");
        dto4.setPrType(PRType.CIVILIAN_HP);
        dto4.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto4.setImageBIC(imageBicDto4);
        dto4.setRevolutionNumber(3);
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        double imageBicDto5 = 4;
        DTO dto5 = this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:56:00", "left", "SAT_1");
        dto5.setPrType(PRType.PP);
        dto5.setImageBIC(imageBicDto5);
        dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2A);
        dto5.setRevolutionNumber(4);
        System.out.println("I'm inserting dto : " + dto5.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        double imageBicDto6 = 2;
        DTO dto6 = this.du.createSingleDto("10/10/2017 06:30:00", "10/10/2017 06:30:10", "right", "SAT_1");
        dto6.setPrType(PRType.PP);
        dto6.setImageBIC(imageBicDto6);
        dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        dto6.setRevolutionNumber(4);
        System.out.println("I'm inserting dto (Print): " + dto6.toString());
        accepted = this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);
        // assertTrue(accepted);

        List<Task> allAccepted = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);

        System.out.println("changing the current session from : " + this.currentKieSession);
        this.currentKieSession = 3;
        System.out.println("to : " + this.currentKieSession);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_2_.txt");
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        ResourceFunctions resourcesForSecondSession = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = resourcesForSecondSession.getEssFunctionSat1();
        TreeMap<Long, ComplexPdht> pdhtFunctionSat1 = resourcesForSecondSession.getPDHTTemporalFunctionSat1();
        TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1 = resourcesForSecondSession.getSilentFunctionSat1();
        TreeMap<Long, Maneuver> manFunctionSat1 = resourcesForSecondSession.getAllManeuversSat1();
        System.out.println("ESS FUNCTION BEFORE: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION BEFORE: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION BEFORE: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION BEFORE: " + manFunctionSat1.size());

        this.droolsInstance.initPlan(this.droolsParams, allAccepted, null, this.sessionId, this.currentKieSession, true);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        /*
         *
         * DTO newDto = this.du.createSingleDto("10/10/2017 06:30:00",
         * "10/10/2017 06:32:00", "right", "SAT_1");
         * newDto.setPrType(PRType.PP); newDto.setImageBIC(2);
         * newDto.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
         * newDto.setRevolutionNumber(4);
         * System.out.println("I'm inserting dto (Print): " +
         * newDto.toString()); accepted =
         * this.droolsInstance.insertDto(this.droolsParams, newDto,
         * this.sessionId, this.currentKieSession); // assertTrue(accepted);
         *
         * Map<String, Acquisition> rejected2 =
         * this.droolsInstance.receiveDtoRejected(this.sessionId,
         * this.currentKieSession); System.out.println("rejectedElements "); for
         * (Map.Entry<String, Acquisition> rejectedElements :
         * rejected2.entrySet()) { System.out.println(rejectedElements.getKey()
         * + " ....................... " +
         * rejectedElements.getValue().getReasonOfReject()); } Map<String,
         * Acquisition> allAcq =
         * this.taskPlanned.receiveAllAcquisitionsAsMap(sessionId,
         * this.currentKieSession, this.droolsParams, "SAT_1");
         *
         * System.out.println(" acquisitions accepted as Map : " + allAcq);
         *
         * rejected = this.droolsInstance.receiveDtoRejected(this.sessionId,
         * this.currentKieSession); System.out.println("ESS FUNCTION AFTER: " +
         * essFunctionSat1.size()); System.out.println("PDHT FUNCTION AFTER: " +
         * pdhtFunctionSat1.size());
         * System.out.println("SILENT FUNCTION AFTER: " +
         * silentFunctionSat1.size());
         * System.out.println("MANEUVER FUNCTION AFTER: " +
         * manFunctionSat1.size()); this.droolsInstance.writeToFile(sessionId,
         * this.currentKieSession, this.droolsParams);
         *
         */
    }

    @Test
    public void test_InitPlan_StartFromDtoWithPrevProcTrue() throws IOException, Exception
    {
        System.out.println("\n\n\n\nRUNNING TEST : test_InitPlan_StartFromDtoWithPrevProcTrue");
        this.sessionId = "test_InitPlan_StartFromDtoWithPrevProcTrue";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        int maxNumberPrTypeForTest = 2;
        this.droolsParams.setPrTypeMaxNumber(maxNumberPrTypeForTest);
        List<Partner> allPartners = this.droolsParams.getAllPartners();
        this.droolsParams.getAllPAWS().clear();
        System.out.println("max number of prType " + this.droolsParams.getPrTypeMaxNumber());
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        Map<String, Acquisition> rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        assertEquals(0, rejected.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:55:00", "10/10/2017 18:00:00", "left", "SAT_1");
        double imageBicDto1 = 12;
        dto1.setPol(Polarization.HH);
        // dto1.setPreviouslyProcessed(true);
        dto1.setDecrementBic(false);
        dto1.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto1.setPrType(PRType.HP);
        dto1.setImageBIC(imageBicDto1);

        List<UserInfo> userInfoList = new ArrayList<>();
        UserInfo userInfo1 = new UserInfo(null, false, allPartners.get(1).getPartnerId(), allPartners.get(1).getUgsId());
        UserInfo userInfo2 = new UserInfo(null, false, allPartners.get(2).getPartnerId(), allPartners.get(2).getUgsId());
        userInfoList.add(userInfo1);
        userInfoList.add(userInfo2);
        dto1.setUserInfo(userInfoList);

        System.out.println("I'm inserting dto : " + dto1.toString());
        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        List<Task> allAccepted = this.droolsInstance.receiveDtoAccepted(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        System.out.println("changing the current session from : " + this.currentKieSession);
        this.currentKieSession = 3;
        System.out.println("to : " + this.currentKieSession);
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.setResponceFile("C:/opt/SPLA/BRM/testReports/test_2_.txt");
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        ResourceFunctions resourcesForSecondSession = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> essFunctionSat1 = resourcesForSecondSession.getEssFunctionSat1();
        TreeMap<Long, ComplexPdht> pdhtFunctionSat1 = resourcesForSecondSession.getPDHTTemporalFunctionSat1();
        TreeMap<Long, EnergyAssociatedToTask> silentFunctionSat1 = resourcesForSecondSession.getSilentFunctionSat1();
        TreeMap<Long, Maneuver> manFunctionSat1 = resourcesForSecondSession.getAllManeuversSat1();
        System.out.println("ESS FUNCTION BEFORE: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION BEFORE: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION BEFORE: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION BEFORE: " + manFunctionSat1.size());

        System.out.println("all accepted : " + allAccepted);

        this.droolsInstance.initPlan(this.droolsParams, allAccepted, null, this.sessionId, this.currentKieSession, true);

        /*
         * DTO newDto = this.du.createSingleDto("10/10/2017 17:52:00",
         * "10/10/2017 17:54:00", "left", "SAT_1"); newDto.setPrType(PRType.PP);
         * newDto.setImageBIC(2);
         * newDto.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
         * newDto.setRevolutionNumber(4);
         * System.out.println("I'm inserting dto (Print): " +
         * newDto.toString()); accepted =
         * this.droolsInstance.insertDto(this.droolsParams, newDto,
         * this.sessionId, this.currentKieSession); // assertTrue(accepted);
         */
        Map<String, Acquisition> rejected2 = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("rejectedElements ");
        for (Map.Entry<String, Acquisition> rejectedElements : rejected2.entrySet())
        {
            System.out.println(rejectedElements.getKey() + " ....................... " + rejectedElements.getValue().getReasonOfReject());
        }
        Map<String, Acquisition> allAcq = this.taskPlanned.receiveAllAcquisitionsAsMap(this.sessionId, this.currentKieSession, this.droolsParams, "SAT_1");

        System.out.println(" acquisitions : " + allAcq);

        rejected = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        System.out.println("ESS FUNCTION AFTER: " + essFunctionSat1.size());
        System.out.println("PDHT FUNCTION AFTER: " + pdhtFunctionSat1.size());
        System.out.println("SILENT FUNCTION AFTER: " + silentFunctionSat1.size());
        System.out.println("MANEUVER FUNCTION AFTER: " + manFunctionSat1.size());
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }
}
