/**
*
* MODULE FILE NAME:	TestStereopair.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		04 giu 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 04 giu 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PAWType;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.PAW;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;

/**
 * @author francesca
 *
 */
public class TestStereopair
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private Map<String, Acquisition> rejectedElements = null;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;
    private StubResources stub = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "TestStereopair";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 500000L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.stub = new StubResources();
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.rejectedElements = new HashMap<>();
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testStereopair_rejectFirst() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO firstStereopair = this.du.createSingleDto("10/10/2017 07:59:00", "10/10/2017 08:01:00", "right", "SAT_1");
        firstStereopair.setDtoId("dto1");
        firstStereopair.setStereopair(true);
        firstStereopair.setLinkedDtoId("dto2");
        firstStereopair.setSensorMode(TypeOfAcquisition.STRIPMAP);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, firstStereopair, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);
        boolean found = this.du.checkIfContainsTheExpectedReason(firstStereopair.getDtoId(), this.rejectedElements, ReasonOfReject.acqPartialOverlapPAW);
        System.out.println("found ? " + found);
        assertTrue(found);

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO secondStereopair = this.du.createSingleDto("10/10/2017 09:59:00", "10/10/2017 10:01:00", "right", "SAT_1");
        secondStereopair.setDtoId("dto2");
        secondStereopair.setStereopair(true);
        secondStereopair.setLinkedDtoId("dto1");
        secondStereopair.setSensorMode(TypeOfAcquisition.STRIPMAP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, secondStereopair, this.sessionId, this.currentKieSession);
        assertFalse(accepted);
        //
        // this.rejectedElements =
        // this.droolsInstance.receiveDtoRejected(this.sessionId,
        // this.currentKieSession);
        //
        // System.out.println("rejected elements : " + this.rejectedElements);
        // found =
        // this.du.checkIfContainsTheExpectedReason(secondStereopair.getDtoId(),
        // this.rejectedElements, ReasonOfReject.cannotPerformStereopair);
        // System.out.println("found ? " + found);
        // assertTrue(found);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
    }

    @Test
    public void testStereopair_rejectSecond() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO firstStereopair = this.du.createSingleDto("10/10/2017 07:20:00", "10/10/2017 07:21:00", "right", "SAT_1");
        firstStereopair.setDtoId("firstStereopair");
        firstStereopair.setStereopair(true);
        firstStereopair.setLinkedDtoId("secondStereopair");
        firstStereopair.setSensorMode(TypeOfAcquisition.PINGPONG);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, firstStereopair, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO secondStereopair = this.du.createSingleDto("10/10/2017 07:59:00", "10/10/2017 08:01:00", "right", "SAT_1");
        secondStereopair.setDtoId("secondStereopair");
        secondStereopair.setStereopair(true);
        secondStereopair.setLinkedDtoId("firstStereopair");
        secondStereopair.setSensorMode(TypeOfAcquisition.PINGPONG);

        accepted = this.droolsInstance.insertDto(this.droolsParams, secondStereopair, this.sessionId, this.currentKieSession);
        assertFalse(accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);

        System.out.println("rejected elements : " + this.rejectedElements);

        // boolean found =
        // this.du.checkIfContainsTheExpectedReason(firstStereopair.getDtoId(),
        // this.rejectedElements, ReasonOfReject.cannotPerformStereopair);
        // System.out.println("found ? " + found);
        // assertTrue(found);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void testStereopair_acceptBoth() throws Exception
    {
        this.droolsParams.getAllPAWS().clear();
        this.droolsParams.getSatelliteState().clear();
        PAW paw1 = this.stub.createPaw(1, "SAT_1", "10/10/2017 09:00:00", "10/10/2017 09:15:00", PAWType.STTOCCULTATION);
        PAW paw2 = this.stub.createPaw(2, "SAT_1", "10/10/2017 14:21:00", "10/10/2017 14:45:00", PAWType.GENERIC);
        PAW paw3 = this.stub.createPaw(1, "SAT_2", "10/10/2017 18:00:00", "10/10/2017 18:07:00", PAWType.KCR);
        PAW paw4 = this.stub.createPaw(2, "SAT_2", "10/10/2017 07:00:00", "10/10/2017 07:09:00", PAWType.GENERIC);
        PAW paw5 = this.stub.createPaw(2, "SAT_1", "10/10/2017 08:00:00", "10/10/2017 08:09:00", PAWType.CAL);
        this.droolsParams.getAllPAWS().addAll(Arrays.asList(paw1, paw2, paw3, paw4, paw5));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO firstStereopair = this.du.createSingleDto("10/10/2017 07:20:00", "10/10/2017 07:21:00", "right", "SAT_1");
        firstStereopair.setDtoId("firstStereopair");
        firstStereopair.setStereopair(true);
        firstStereopair.setLinkedDtoId("secondStereopair");
        firstStereopair.setSensorMode(TypeOfAcquisition.PINGPONG);

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, firstStereopair, this.sessionId, this.currentKieSession);
        assertTrue(accepted);

        // this DTO is partially included inside paw of type CAl at start ->
        // rejected
        DTO secondStereopair = this.du.createSingleDto("10/10/2017 07:50:00", "10/10/2017 07:51:00", "right", "SAT_1");
        secondStereopair.setDtoId("secondStereopair");
        secondStereopair.setStereopair(true);
        secondStereopair.setLinkedDtoId("firstStereopair");
        secondStereopair.setSensorMode(TypeOfAcquisition.STRIPMAP);

        accepted = this.droolsInstance.insertDto(this.droolsParams, secondStereopair, this.sessionId, this.currentKieSession);
        assertTrue(accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }
}
