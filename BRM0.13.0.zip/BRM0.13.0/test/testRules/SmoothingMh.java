/**
*
* MODULE FILE NAME:	SmoothingMh.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		23 lug 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 23 lug 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.drools.utils.StubResources;
import com.nais.spla.brm.library.main.ontology.enums.PRType;
import com.nais.spla.brm.library.main.ontology.enums.Polarization;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.enums.TypeOfAcquisition;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.resourceData.MissionHorizon;
import com.nais.spla.brm.library.main.ontology.resourceData.Visibility;
import com.nais.spla.brm.library.main.ontology.tasks.Acquisition;
import com.nais.spla.brm.library.main.ontology.tasks.Task;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author francesca
 *
 */
public class SmoothingMh
{

    private String sessionId = null;
    private Map<String, Acquisition> rejectedElements = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws ParseException
    {
        this.sessionId = "initPlan";
        this.droolsParams = new DroolsParameters();
        this.rejectedElements = new HashMap<>();
        this.PDHTMaxMemory = 49146L;
        this.currentKieSession = 1;
        double maxBicForTest = 100;
        this.du = new DroolsUtils();
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);

    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeSession(this.sessionId, this.currentKieSession);
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void A_smoothingUnranked() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:22:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : B_TestOverlapInitPlan \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 18:00:00", "10/10/2017 18:00:30", "right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 18:20:00", "10/10/2017 18:20:30", "left", satelliteId);
        dto2.setImageBIC(2);
        dto2.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        assertEquals(false, accepted);

        this.rejectedElements = this.droolsInstance.receiveDtoRejected(this.sessionId, this.currentKieSession);
        boolean containsExpectedReason = this.du.checkIfContainsTheExpectedReason(dto2.getDtoId(), this.rejectedElements, ReasonOfReject.smoothingEssUnranked);
        assertEquals(true, containsExpectedReason);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:20:50", "10/10/2017 18:21:20", "right", satelliteId);
        dto3.setImageBIC(4);
        dto3.setSizeH(1500);
        dto3.setPrType(PRType.VU);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);

        DTO dto4 = this.du.createSingleDto("10/10/2017 16:50:00", "10/10/2017 16:50:20", "right", satelliteId);
        dto4.setImageBIC(4);
        dto4.setSizeH(3000);
        dto4.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto4.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);

        DTO dto5 = this.du.createSingleDto("10/10/2017 09:20:50", "10/10/2017 09:21:20", "right", satelliteId);
        dto5.setImageBIC(4);
        dto5.setPrType(PRType.UNRANKED_ROUTINE);
        System.out.println("I'm inserting dto : " + dto5.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        assertEquals(true, accepted);

        allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        this.currentKieSession = 3;

        Date startTimeNewMh = DroolsUtils.createDate("10/10/2017 18:21:00");
        Date endTimeNewMh = DroolsUtils.createDate("11/10/2017 06:21:00");
        this.droolsParams.getCurrentMH().setStart(startTimeNewMh);
        this.droolsParams.getCurrentMH().setStop(endTimeNewMh);

        Visibility vis10 = stub.createVisibility(9, "SAT_1", "PDR", null, "10/10/2017 20:00:00", "10/10/2017 22:50:00");

        this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsParams.getAllVisibilities().add(vis10);
        this.droolsParams.getCurrentMH().setStart(startTimeNewMh);
        this.droolsParams.getCurrentMH().setStop(endTimeNewMh);
        //
        this.droolsParams.getSatWithId(satelliteId).setInitialLookSide("left");
        this.droolsInstance.initPlan(this.droolsParams, allPlannedTasksAsList, null, this.sessionId, this.currentKieSession, true);
        allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        //
        // DTO dto6 = this.du.createSingleDto("10/10/2017 21:54:00", "10/10/2017
        // 21:55:30", "right", satelliteId);
        // System.out.println("I'm inserting dto : " + dto6.toString());
        //
        // accepted = this.droolsInstance.insertDto(this.droolsParams, dto6,
        // this.sessionId, this.currentKieSession);
        // assertEquals(true, accepted);

        allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted : " + allTasks.getValue());
        }

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test555Left() throws Exception
    {
        this.sessionId = "A_Test555Left";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test555 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:33.906", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        allDto.add(dto1);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
        dto2.setImageBIC(2);
        dto2.setPrType(PRType.HP);
        allDto.add(dto2);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
        dto2.setImageBIC(2);
        dto3.setPrType(PRType.HP);
        allDto.add(dto3);

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test557() throws Exception
    {
        this.sessionId = "A_Test557";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test555 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        allDto.add(dto1);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);

        dto2.setImageBIC(2);
        dto2.setPrType(PRType.HP);
        allDto.add(dto2);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
        dto2.setImageBIC(2);
        dto3.setPrType(PRType.HP);
        allDto.add(dto3);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", satelliteId);
        dto4.setImageBIC(2);
        dto4.setPrType(PRType.HP);
        allDto.add(dto4);

        DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", satelliteId);
        dto5.setImageBIC(2);
        dto5.setPrType(PRType.HP);
        allDto.add(dto5);

        DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", satelliteId);
        dto6.setImageBIC(2);
        dto6.setPrType(PRType.HP);
        allDto.add(dto6);

        DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", satelliteId);
        dto7.setImageBIC(2);
        dto7.setPrType(PRType.HP);
        allDto.add(dto7);

        DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
        dto8.setImageBIC(2);
        dto8.setPrType(PRType.HP);
        allDto.add(dto8);

        DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
        dto9.setImageBIC(2);
        dto9.setPrType(PRType.HP);
        allDto.add(dto9);

        DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
        dto10.setImageBIC(2);
        dto10.setPrType(PRType.HP);
        allDto.add(dto10);

        DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
        dto11.setImageBIC(2);
        dto11.setPrType(PRType.HP);
        allDto.add(dto11);

        DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", satelliteId);
        dto12.setImageBIC(2);
        dto12.setPrType(PRType.HP);
        allDto.add(dto12);

        DTO dto13 = this.du.createSingleDto("10/10/2017 11:44:14", "10/10/2017 11:44:21", "Right", satelliteId);
        dto13.setImageBIC(2);
        dto13.setPrType(PRType.PP);
        allDto.add(dto13);

        DTO dto141 = this.du.createSingleDto("10/10/2017 11:23:22.652", "10/10/2017 11:23:32.836", "Left", satelliteId);
        dto141.setImageBIC(2);
        dto141.setPrType(PRType.PP);
        allDto.add(dto141);

        DTO dto14 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
        dto14.setImageBIC(2);
        dto14.setPrType(PRType.PP);
        allDto.add(dto14);

        DTO dto15 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", satelliteId);
        dto15.setImageBIC(2);
        dto15.setPrType(PRType.PP);
        allDto.add(dto15);

        DTO dto16 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
        dto16.setImageBIC(2);
        dto16.setPrType(PRType.PP);
        allDto.add(dto16);

        DTO dto17 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
        dto17.setImageBIC(2);
        dto17.setPrType(PRType.PP);
        allDto.add(dto17);

        DTO dto18 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
        dto18.setImageBIC(2);
        dto18.setPrType(PRType.PP);
        allDto.add(dto18);

        DTO dto19 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
        dto19.setImageBIC(2);
        dto19.setPrType(PRType.PP);
        allDto.add(dto19);

        DTO dto20 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", satelliteId);
        dto20.setImageBIC(2);
        dto20.setPrType(PRType.PP);
        allDto.add(dto20);

        DTO dto21 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
        dto21.setImageBIC(2);
        dto21.setPrType(PRType.PP);
        allDto.add(dto21);

        DTO dto22 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
        dto22.setImageBIC(2);
        dto22.setPrType(PRType.PP);
        allDto.add(dto22);

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        List<Task> prevProcTask = DroolsUtils.fromTreemapToList(allAcceptedTasks);
        this.sessionId = "initSmoothing";
        this.currentKieSession = 4;
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        allDto = new ArrayList<>();
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("AKK TASKS ACCEPTED " + allAcceptedTasks.size());
        int allTaskBefore = allAcceptedTasks.size();
        this.droolsInstance.initPlan(this.droolsParams, prevProcTask, null, this.sessionId, this.currentKieSession, true);
        allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        int allTaskafter = allAcceptedTasks.size();
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        // assertEquals(allTaskBefore,allTaskafter);

    }

    @Test
    public void A_Test555() throws Exception
    {
        this.sessionId = "A_Test555";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test555 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        allDto.add(dto1);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);

        dto2.setImageBIC(2);
        dto2.setPrType(PRType.HP);
        allDto.add(dto2);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
        dto2.setImageBIC(2);
        dto3.setPrType(PRType.HP);
        allDto.add(dto3);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", satelliteId);
        dto4.setImageBIC(2);
        dto4.setPrType(PRType.HP);
        allDto.add(dto4);

        DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", satelliteId);
        dto5.setImageBIC(2);
        dto5.setPrType(PRType.HP);
        allDto.add(dto5);

        DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", satelliteId);
        dto6.setImageBIC(2);
        dto6.setPrType(PRType.HP);
        allDto.add(dto6);

        DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", satelliteId);
        dto7.setImageBIC(2);
        dto7.setPrType(PRType.HP);
        allDto.add(dto7);

        DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
        dto8.setImageBIC(2);
        dto8.setPrType(PRType.HP);
        allDto.add(dto8);

        DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
        dto9.setImageBIC(2);
        dto9.setPrType(PRType.HP);
        allDto.add(dto9);

        DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
        dto10.setImageBIC(2);
        dto10.setPrType(PRType.HP);
        allDto.add(dto10);

        DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
        dto11.setImageBIC(2);
        dto11.setPrType(PRType.HP);
        allDto.add(dto11);

        DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", satelliteId);
        dto12.setImageBIC(2);
        dto12.setPrType(PRType.HP);
        allDto.add(dto12);

        DTO dto13 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
        dto13.setImageBIC(2);
        dto13.setPrType(PRType.PP);
        allDto.add(dto13);

        DTO dto141 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", satelliteId);
        dto141.setImageBIC(2);
        dto141.setPrType(PRType.PP);
        allDto.add(dto141);

        DTO dto14 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
        dto14.setImageBIC(2);
        dto14.setPrType(PRType.PP);
        allDto.add(dto14);

        DTO dto15 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
        dto15.setImageBIC(2);
        dto15.setPrType(PRType.PP);
        allDto.add(dto15);

        DTO dto16 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
        dto16.setImageBIC(2);
        dto16.setPrType(PRType.PP);
        allDto.add(dto16);

        DTO dto17 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
        dto17.setImageBIC(2);
        dto17.setPrType(PRType.PP);
        allDto.add(dto17);

        DTO dto18 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", satelliteId);
        dto18.setImageBIC(2);
        dto18.setPrType(PRType.PP);
        allDto.add(dto18);

        DTO dto19 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
        dto19.setImageBIC(2);
        dto19.setPrType(PRType.PP);
        allDto.add(dto19);

        DTO dto20 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
        dto20.setImageBIC(2);
        dto20.setPrType(PRType.PP);
        allDto.add(dto20);
        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test635() throws Exception
    {
        this.sessionId = "A_Test635";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test555 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 17:20:24.629", "10/10/2017 17:20:40.393", "Right", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        allDto.add(dto1);

        DTO dto2 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.085", "Left", satelliteId);
        dto2.setImageBIC(2);
        dto2.setPrType(PRType.HP);
        allDto.add(dto2);

        DTO dto3 = this.du.createSingleDto("10/10/2017 15:25:09.4", "10/10/2017 15:25:16.591", "Right", satelliteId);
        dto2.setImageBIC(2);
        dto3.setPrType(PRType.HP);
        allDto.add(dto3);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.746", "10/10/2017 11:55:13.257", "Right", satelliteId);
        dto4.setImageBIC(2);
        dto4.setPrType(PRType.HP);
        allDto.add(dto4);

        DTO dto5 = this.du.createSingleDto("10/10/2017 09:39:04.429", "10/10/2017 09:39:09.57", "Right", "SAT_2");
        dto5.setImageBIC(2);
        dto5.setPrType(PRType.HP);
        allDto.add(dto5);

        DTO dto6 = this.du.createSingleDto("10/10/2017 13:12:10.654", "10/10/2017 13:12:20.302", "Left", "SAT_2");
        dto6.setImageBIC(2);
        dto6.setPrType(PRType.HP);
        allDto.add(dto6);

        DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:33.391", "10/10/2017 13:07:40.593", "Left", "SAT_2");
        dto7.setImageBIC(2);
        dto7.setPrType(PRType.HP);
        allDto.add(dto7);

        DTO dto8 = this.du.createSingleDto("10/10/2017 18:00:04.974", "10/10/2017 18:00:14.045", "Right", "SAT_2");
        dto8.setImageBIC(2);
        dto8.setPrType(PRType.HP);
        allDto.add(dto8);

        DTO dto9 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);
        dto9.setImageBIC(2);
        dto9.setPrType(PRType.HP);
        allDto.add(dto9);

        DTO dto10 = this.du.createSingleDto("10/10/2017 11:36:28.804", "10/10/2017 11:36:39.154", "Right", satelliteId);
        dto10.setImageBIC(2);
        dto10.setPrType(PRType.HP);
        allDto.add(dto10);

        DTO dto11 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
        dto11.setImageBIC(2);
        dto11.setPrType(PRType.PP);
        allDto.add(dto11);

        DTO dto12 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
        dto12.setImageBIC(2);
        dto12.setPrType(PRType.HP);
        allDto.add(dto12);

        DTO dto13 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
        dto13.setImageBIC(2);
        dto13.setPrType(PRType.PP);
        allDto.add(dto13);

        DTO dto1411 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
        dto1411.setImageBIC(2);
        dto1411.setPrType(PRType.PP);
        allDto.add(dto1411);

        DTO dto142 = this.du.createSingleDto("10/10/2017 11:42:48", "10/10/2017 11:43:04", "Left", satelliteId);
        dto142.setImageBIC(2);
        dto142.setPrType(PRType.PP);
        allDto.add(dto142);

        DTO dto143 = this.du.createSingleDto("10/10/2017 11:44:14", "10/10/2017 11:44:21", "Right", satelliteId);
        dto143.setImageBIC(2);
        dto143.setPrType(PRType.PP);
        allDto.add(dto143);

        DTO dto144 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
        dto144.setImageBIC(2);
        dto144.setPrType(PRType.PP);
        allDto.add(dto144);
        DTO dto141 = this.du.createSingleDto("10/10/2017 11:50:13", "10/10/2017 11:50:44", "Right", satelliteId);
        dto141.setImageBIC(2);
        dto141.setPrType(PRType.PP);
        allDto.add(dto141);

        DTO dto14 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
        dto14.setImageBIC(2);
        dto14.setPrType(PRType.PP);
        allDto.add(dto14);

        DTO dto15 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
        dto15.setImageBIC(2);
        dto15.setPrType(PRType.PP);
        allDto.add(dto15);

        DTO dto16 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
        dto16.setImageBIC(2);
        dto16.setPrType(PRType.PP);
        allDto.add(dto16);

        DTO dto17 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
        dto17.setImageBIC(2);
        dto17.setPrType(PRType.PP);
        allDto.add(dto17);

        DTO dto18 = this.du.createSingleDto("10/10/2017 18:19:30", "10/10/2017 18:19:43", "Right", satelliteId);
        dto18.setImageBIC(2);
        dto18.setPrType(PRType.PP);
        allDto.add(dto18);

        DTO dto19 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
        dto19.setImageBIC(2);
        dto19.setPrType(PRType.PP);
        allDto.add(dto19);

        DTO dto20 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
        dto20.setImageBIC(2);
        dto20.setPrType(PRType.PP);
        allDto.add(dto20);

        DTO dto21 = this.du.createSingleDto("10/10/2017 16:00:48", "10/10/2017 16:00:58", "Right", "SAT_2");
        dto21.setImageBIC(2);
        dto21.setPrType(PRType.PP);
        allDto.add(dto21);

        DTO dto22 = this.du.createSingleDto("10/10/2017 18:08:45", "10/10/2017 18:08:52", "Right", "SAT_2");
        dto22.setImageBIC(2);
        dto22.setPrType(PRType.PP);
        allDto.add(dto22);

        DTO dto23 = this.du.createSingleDto("10/10/2017 18:00:30", "10/10/2017 18:00:40", "Right", "SAT_2");
        dto23.setImageBIC(2);
        dto23.setPrType(PRType.PP);
        allDto.add(dto23);

        DTO dto24 = this.du.createSingleDto("10/10/2017 17:20:19", "10/10/2017 17:20:26", "Right", satelliteId);
        dto24.setImageBIC(2);
        dto24.setPrType(PRType.PP);
        allDto.add(dto24);

        DTO dto25 = this.du.createSingleDto("10/10/2017 07:13:09", "10/10/2017 07:13:25", "Left", "SAT_2");
        dto25.setImageBIC(2);
        dto25.setPrType(PRType.PP);
        allDto.add(dto25);

        DTO dto26 = this.du.createSingleDto("10/10/2017 17:24:48", "10/10/2017 17:25:00", "Right", satelliteId);
        dto26.setImageBIC(2);
        dto26.setPrType(PRType.PP);
        allDto.add(dto26);

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test553() throws Exception
    {
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getAllPAWS().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:18:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test553 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 11:01:57.32", "10/10/2017 11:02:28.693", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setPrType(PRType.HP);
        allDto.add(dto1);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:45:42.494", "10/10/2017 11:45:58.458", "Right", satelliteId);
        dto2.setImageBIC(2);
        dto2.setPrType(PRType.HP);
        allDto.add(dto2);

        DTO dto3 = this.du.createSingleDto("10/10/2017 10:22:03.906", "10/10/2017 10:22:11.084", "Left", satelliteId);
        dto2.setImageBIC(2);
        dto3.setPrType(PRType.HP);
        allDto.add(dto3);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:55:05.743", "10/10/2017 11:55:13.26", "Right", satelliteId);
        dto4.setImageBIC(2);
        dto4.setPrType(PRType.HP);
        allDto.add(dto4);

        DTO dto5 = this.du.createSingleDto("10/10/2017 11:34:01.593", "10/10/2017 11:34:10.391", "Right", satelliteId);
        dto5.setImageBIC(2);
        dto5.setPrType(PRType.HP);
        allDto.add(dto5);

        DTO dto6 = this.du.createSingleDto("10/10/2017 15:25:09.398", "10/10/2017 15:25:16.593", "Right", satelliteId);
        dto6.setImageBIC(2);
        dto6.setPrType(PRType.HP);
        allDto.add(dto6);

        DTO dto7 = this.du.createSingleDto("10/10/2017 11:36:28.799", "10/10/2017 11:36:39.159", "Right", satelliteId);
        dto7.setImageBIC(2);
        dto7.setPrType(PRType.HP);
        allDto.add(dto7);

        DTO dto8 = this.du.createSingleDto("10/10/2017 11:23:22", "10/10/2017 11:23:32", "Left", satelliteId);
        dto8.setImageBIC(2);
        dto8.setPrType(PRType.HP);
        dto8.setPol(Polarization.HV);
        dto8.setSizeH(100);
        dto8.setSizeV(100);

        allDto.add(dto8);

        DTO dto9 = this.du.createSingleDto("10/10/2017 11:34:59", "10/10/2017 11:35:07", "Right", satelliteId);
        dto9.setImageBIC(2);
        dto9.setPol(Polarization.HV);
        dto9.setPrType(PRType.HP);
        dto9.setSizeH(100);
        dto9.setSizeV(100);
        allDto.add(dto9);

        DTO dto10 = this.du.createSingleDto("10/10/2017 11:38:01", "10/10/2017 11:38:11", "Right", satelliteId);
        dto10.setImageBIC(2);
        dto10.setPrType(PRType.HP);
        allDto.add(dto10);

        DTO dto11 = this.du.createSingleDto("10/10/2017 11:41:09", "10/10/2017 11:41:14", "Right", satelliteId);
        dto11.setImageBIC(2);
        dto11.setPrType(PRType.HP);
        allDto.add(dto11);

        DTO dto12 = this.du.createSingleDto("10/10/2017 11:42:49", "10/10/2017 11:43:05", "Left", satelliteId);
        dto12.setImageBIC(2);
        dto12.setPrType(PRType.HP);
        allDto.add(dto12);

        DTO dto13 = this.du.createSingleDto("10/10/2017 11:47:15", "10/10/2017 11:47:31", "Right", satelliteId);
        dto13.setImageBIC(2);
        dto13.setPrType(PRType.PP);
        allDto.add(dto13);

        DTO dto14 = this.du.createSingleDto("10/10/2017 11:53:30", "10/10/2017 11:53:37", "Right", satelliteId);
        dto14.setImageBIC(2);
        dto14.setPrType(PRType.PP);
        allDto.add(dto14);

        DTO dto15 = this.du.createSingleDto("10/10/2017 11:56:35", "10/10/2017 11:56:42", "Right", satelliteId);
        dto15.setImageBIC(2);
        dto15.setPrType(PRType.PP);
        allDto.add(dto15);

        DTO dto16 = this.du.createSingleDto("10/10/2017 11:33:15", "10/10/2017 11:33:26", "Left", satelliteId);
        dto16.setImageBIC(2);
        dto16.setPrType(PRType.PP);
        allDto.add(dto16);

        DTO dto17 = this.du.createSingleDto("10/10/2017 11:12:36", "10/10/2017 11:12:44", "Left", satelliteId);
        dto17.setImageBIC(2);
        dto17.setPrType(PRType.PP);
        allDto.add(dto17);

        DTO dto18 = this.du.createSingleDto("10/10/2017 18:18:52", "10/10/2017 18:19:43", "Right", satelliteId);
        dto18.setImageBIC(2);
        dto18.setPrType(PRType.PP);
        allDto.add(dto18);

        DTO dto19 = this.du.createSingleDto("10/10/2017 17:24:50", "10/10/2017 17:24:58", "Right", satelliteId);
        dto19.setImageBIC(2);
        dto19.setPrType(PRType.PP);
        allDto.add(dto19);

        DTO dto20 = this.du.createSingleDto("10/10/2017 17:24:53", "10/10/2017 17:25:01", "Right", satelliteId);
        dto20.setImageBIC(2);
        dto20.setPrType(PRType.PP);
        allDto.add(dto20);
        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allAcceptedTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        List<Task> allPlannedTasksAsList = new ArrayList<>();

        for (Map.Entry<String, Task> allTasks : allAcceptedTasks.entrySet())
        {
            System.out.println("accepted ;" + allTasks.getValue());
            allPlannedTasksAsList.add(allTasks.getValue());
        }
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test693List() throws Exception
    {
        this.sessionId = "BUG693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getHpExclusionList().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test553 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:13:11", "10/10/2017 07:13:27", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setDtoId("100_3084_1_1_");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto1.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:00:50", "10/10/2017 16:01:00", "Right", satelliteId);
        dto2.setImageBIC(3);
        dto2.setDtoId("100_3080_1_1_");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        dto2.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:08:47", "10/10/2017 18:08:55", "Right", satelliteId);
        dto3.setImageBIC(3);
        dto3.setDtoId("100_3094_1_1_");
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:01:59", "10/10/2017 11:02:30", "Left", satelliteId);
        dto4.setImageBIC(3);
        dto4.setDtoId("200_630_1_2_");
        dto4.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto4.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 13:12:13", "10/10/2017 13:12:22", "Left", satelliteId);
        dto5.setImageBIC(3);
        dto5.setDtoId("200_635_1_1_");
        dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto5.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 09:39:06", "10/10/2017 09:39:11", "Right", satelliteId);
        dto6.setImageBIC(3);
        dto6.setDtoId("200_639_1_1_");
        dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2C);
        dto6.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:35.891", "10/10/2017 13:07:43.093", "Left", satelliteId);
        dto7.setImageBIC(3);
        dto7.setDtoId("200_634_1_1_");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto7.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 13:14:52", "10/10/2017 13:15:03", "Left", satelliteId);
        dto8.setImageBIC(3);
        dto8.setDtoId("200_647_1_2_");
        dto8.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto8.setPrType(PRType.HP);

        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        for (int i = 0; i < allDto.size(); i++)
        {
            allDto.get(i).setPreviousSession(true);
        }

        this.sessionId = "INITPLAN693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        DTO dto9 = this.du.createSingleDto("10/10/2017 17:14:52", "10/10/2017 17:15:03", "Right", satelliteId);
        dto9.setImageBIC(3);
        dto9.setDtoId("200_6499_1_2_");
        dto9.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto9.setPrType(PRType.HP);

        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test693ListRetain() throws Exception
    {
        this.sessionId = "BUG693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getHpExclusionList().clear();

        List<DTO> allDto = new ArrayList<>();

        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test553 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:13:11", "10/10/2017 07:13:27", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setDtoId("100_3084_1_1_");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto1.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:00:50", "10/10/2017 16:01:00", "Right", satelliteId);
        dto2.setImageBIC(3);
        dto2.setDtoId("100_3080_1_1_");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        dto2.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:08:47", "10/10/2017 18:08:55", "Right", satelliteId);
        dto3.setImageBIC(3);
        dto3.setDtoId("100_3094_1_1_");
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:01:59", "10/10/2017 11:02:30", "Left", satelliteId);
        dto4.setImageBIC(3);
        dto4.setDtoId("200_630_1_2_");
        dto4.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto4.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 13:12:13", "10/10/2017 13:12:22", "Left", satelliteId);
        dto5.setImageBIC(3);
        dto5.setDtoId("200_635_1_1_");
        dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto5.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 09:39:06", "10/10/2017 09:39:11", "Right", satelliteId);
        dto6.setImageBIC(3);
        dto6.setDtoId("200_639_1_1_");
        dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2C);
        dto6.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:35.891", "10/10/2017 13:07:43.093", "Left", satelliteId);
        dto7.setImageBIC(3);
        dto7.setDtoId("200_634_1_1_");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto7.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 13:14:52", "10/10/2017 13:15:03", "Left", satelliteId);
        dto8.setImageBIC(3);
        dto8.setDtoId("200_647_1_2_");
        dto8.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto8.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        allDto.addAll(Arrays.asList(dto1, dto2, dto3, dto4, dto5, dto6, dto7, dto8));

        for (int i = 0; i < allDto.size(); i++)
        {
            allDto.get(i).setPreviousSession(true);
        }

        this.sessionId = "INITPLAN693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        DTO dto9 = this.du.createSingleDto("10/10/2017 17:14:52", "10/10/2017 17:15:03", "Right", satelliteId);
        dto9.setImageBIC(3);
        dto9.setDtoId("200_6499_1_2_");
        dto9.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto9.setPrType(PRType.HP);

        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test693ListRetainNewMh() throws Exception
    {
        this.sessionId = "BUG693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getHpExclusionList().clear();

        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test553 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:13:11", "10/10/2017 07:13:27", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setDtoId("100_3084_1_1_");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto1.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:00:50", "10/10/2017 16:01:00", "Right", satelliteId);
        dto2.setImageBIC(3);
        dto2.setDtoId("100_3080_1_1_");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        dto2.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:08:47", "10/10/2017 18:08:55", "Right", satelliteId);
        dto3.setImageBIC(3);
        dto3.setDtoId("100_3094_1_1_");
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.PP);
        this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:01:59", "10/10/2017 11:02:30", "Left", satelliteId);
        dto4.setImageBIC(3);
        dto4.setDtoId("200_630_1_2_");
        dto4.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto4.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto4, this.sessionId, this.currentKieSession);

        DTO dto5 = this.du.createSingleDto("10/10/2017 13:12:13", "10/10/2017 13:12:22", "Left", satelliteId);
        dto5.setImageBIC(3);
        dto5.setDtoId("200_635_1_1_");
        dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto5.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto5, this.sessionId, this.currentKieSession);

        DTO dto6 = this.du.createSingleDto("10/10/2017 09:39:06", "10/10/2017 09:39:11", "Right", satelliteId);
        dto6.setImageBIC(3);
        dto6.setDtoId("200_639_1_1_");
        dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2C);
        dto6.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto6, this.sessionId, this.currentKieSession);

        DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:35.891", "10/10/2017 13:07:43.093", "Left", satelliteId);
        dto7.setImageBIC(3);
        dto7.setDtoId("200_634_1_1_");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto7.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto7, this.sessionId, this.currentKieSession);

        DTO dto8 = this.du.createSingleDto("10/10/2017 13:14:52", "10/10/2017 13:15:03", "Left", satelliteId);
        dto8.setImageBIC(3);
        dto8.setDtoId("200_647_1_2_");
        dto8.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto8.setPrType(PRType.HP);
        this.droolsInstance.insertDto(this.droolsParams, dto8, this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        Map<String, Task> allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);

        List<Task> allTasksAsList = DroolsUtils.fromTreemapToList(allTasks);
        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasksAsList = DroolsUtils.fromTreemapToList(allTasks);

        for (int i = 0; i < allTasksAsList.size(); i++)
        {
            System.out.println(allTasksAsList.get(i));
        }

        this.sessionId = "INITPLAN693";

        MissionHorizon mh = new MissionHorizon();
        mh.setStart(DroolsUtils.createDate("10/10/2017 18:21:00"));
        mh.setStop(DroolsUtils.createDate("11/10/2017 06:21:00"));

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.setCurrentMH(mh);

        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        this.droolsInstance.initPlan(this.droolsParams, allTasksAsList, null, this.sessionId, this.currentKieSession, true);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);

        allTasks = this.droolsInstance.getAllTasksAcceptedAsMap(this.droolsParams, this.sessionId, this.currentKieSession);
        allTasksAsList = DroolsUtils.fromTreemapToList(allTasks);

        for (int i = 0; i < allTasksAsList.size(); i++)
        {
            System.out.println(allTasksAsList.get(i));
        }

        // DTO dto9 = this.du.createSingleDto("10/10/2017 17:14:52", "10/10/2017
        // 17:15:03", "Right", satelliteId);
        // dto9.setImageBIC(3);
        // dto9.setDtoId("200_6499_1_2_");
        // dto9.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        // dto9.setPrType(PRType.HP);
        //
        // this.droolsInstance.insertDto(this.droolsParams, dto9,
        // this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

    @Test
    public void A_Test693() throws Exception
    {
        this.sessionId = "BUG693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        StubResources stub = new StubResources();
        this.droolsParams.getHpExclusionList().clear();

        List<DTO> allDto = new ArrayList<>();
        Visibility vis11 = stub.createVisibility(11, "SAT_1", "PDR", null, "10/10/2017 18:00:00", "10/10/2017 18:30:00");
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        System.out.println("Running Test : A_Test553 \n\n");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 07:13:11", "10/10/2017 07:13:27", "Left", satelliteId);
        dto1.setImageBIC(3);
        dto1.setDtoId("100_3084_1_1_");
        dto1.setSensorMode(TypeOfAcquisition.SCANSAR_1);
        dto1.setPrType(PRType.PP);
        allDto.add(dto1);

        DTO dto2 = this.du.createSingleDto("10/10/2017 16:00:50", "10/10/2017 16:01:00", "Right", satelliteId);
        dto2.setImageBIC(3);
        dto2.setDtoId("100_3080_1_1_");
        dto2.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2B);
        dto2.setPrType(PRType.PP);
        allDto.add(dto2);

        DTO dto3 = this.du.createSingleDto("10/10/2017 18:08:47", "10/10/2017 18:08:55", "Right", satelliteId);
        dto3.setImageBIC(3);
        dto3.setDtoId("100_3094_1_1_");
        dto3.setSensorMode(TypeOfAcquisition.QUADPOL);
        dto3.setPrType(PRType.PP);
        allDto.add(dto3);

        DTO dto4 = this.du.createSingleDto("10/10/2017 11:01:59", "10/10/2017 11:02:30", "Left", satelliteId);
        dto4.setImageBIC(3);
        dto4.setDtoId("200_630_1_2_");
        dto4.setSensorMode(TypeOfAcquisition.SCANSAR_2);
        dto4.setPrType(PRType.HP);
        allDto.add(dto4);

        DTO dto5 = this.du.createSingleDto("10/10/2017 13:12:13", "10/10/2017 13:12:22", "Left", satelliteId);
        dto5.setImageBIC(3);
        dto5.setDtoId("200_635_1_1_");
        dto5.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto5.setPrType(PRType.HP);
        allDto.add(dto5);

        DTO dto6 = this.du.createSingleDto("10/10/2017 09:39:06", "10/10/2017 09:39:11", "Right", satelliteId);
        dto6.setImageBIC(3);
        dto6.setDtoId("200_639_1_1_");
        dto6.setSensorMode(TypeOfAcquisition.SPOTLIGHT_2C);
        dto6.setPrType(PRType.HP);
        allDto.add(dto6);

        DTO dto7 = this.du.createSingleDto("10/10/2017 13:07:35.891", "10/10/2017 13:07:43.093", "Left", satelliteId);
        dto7.setImageBIC(3);
        dto7.setDtoId("200_634_1_1_");
        dto7.setSensorMode(TypeOfAcquisition.STRIPMAP);
        dto7.setPrType(PRType.HP);
        allDto.add(dto7);

        DTO dto8 = this.du.createSingleDto("10/10/2017 13:14:52", "10/10/2017 13:15:03", "Left", satelliteId);
        dto8.setImageBIC(3);
        dto8.setDtoId("200_647_1_2_");
        dto8.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto8.setPrType(PRType.HP);
        allDto.add(dto8);

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        for (int i = 0; i < allDto.size(); i++)
        {
            allDto.get(i).setPreviousSession(true);
        }

        this.sessionId = "INITPLAN693";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsParams.getAllVisibilities().add(vis11);
        this.droolsParams.getHpExclusionList().clear();
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");

        this.droolsInstance.insertListDto(allDto, this.sessionId, this.currentKieSession, this.droolsParams);
        this.droolsInstance.processDownloadsFromPrevSession(this.droolsParams, this.sessionId, this.currentKieSession);
        DTO dto9 = this.du.createSingleDto("10/10/2017 17:14:52", "10/10/2017 17:15:03", "Right", satelliteId);
        dto9.setImageBIC(3);
        dto9.setDtoId("200_6499_1_2_");
        dto9.setSensorMode(TypeOfAcquisition.SPOTLIGHT_1A);
        dto9.setPrType(PRType.HP);

        this.droolsInstance.insertDto(this.droolsParams, dto9, this.sessionId, this.currentKieSession);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

    }

}
