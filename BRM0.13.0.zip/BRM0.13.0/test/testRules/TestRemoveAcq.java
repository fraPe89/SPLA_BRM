/**
*
* MODULE FILE NAME:	TestRemoveAcq.java
*
* MODULE TYPE:		Class definition
*
* FUNCTION:		<Functional description of the DDC>
*
* PURPOSE:
*
* CREATION DATE:		16 set 2018
*
* AUTHORS:		francesca
*
* DESIGN ISSUE:		1.0
*
* INTERFACES:
*
* SUBORDINATES:
*
* MODIFICATION HISTORY:
*
*  Date            |  Name      | New ver.    | Description
* -----------------+------------+-------------+-------------------------------
* 16 set 2018          | francesca    | 1.0         | first issue
* -----------------+------------+-------------+-------------------------------
*
*/

package testRules;

import static org.junit.Assert.assertEquals;

import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nais.spla.brm.library.main.drools.DroolsOperations;
import com.nais.spla.brm.library.main.drools.DroolsParameters;
import com.nais.spla.brm.library.main.drools.ResourceFunctions;
import com.nais.spla.brm.library.main.drools.utils.DroolsUtils;
import com.nais.spla.brm.library.main.ontology.enums.ReasonOfReject;
import com.nais.spla.brm.library.main.ontology.enums.SessionType;
import com.nais.spla.brm.library.main.ontology.resourceData.DTO;
import com.nais.spla.brm.library.main.ontology.utils.EnergyAssociatedToTask;

/**
 * @author francesca
 *
 */
public class TestRemoveAcq
{

    private String sessionId = null;
    private int currentKieSession = 0;
    private Long PDHTMaxMemory = 0l;
    private DroolsParameters droolsParams = null;
    private DroolsOperations droolsInstance = null;
    private DroolsUtils du = null;

    @Before
    public void setUp() throws Exception
    {
        this.sessionId = "testRemoveAcq";
        this.droolsParams = new DroolsParameters();
        this.PDHTMaxMemory = 5000000L;
        this.currentKieSession = 1;
        this.du = new DroolsUtils();
        double maxBicForTest = 100;
        double extraCostLeft = 10;
        this.droolsInstance = this.du.setUpSessionForTest(this.sessionId, this.droolsParams, this.currentKieSession, this.PDHTMaxMemory, maxBicForTest, extraCostLeft);
    }

    /*
     * after each test, all the sessions of Drools will be closed
     */
    @After
    public void tearDown()
    {
        this.droolsInstance.closeAllInstancesForSession(this.sessionId);
    }

    @Test
    public void testRemoveAcq() throws Exception
    {
        this.sessionId = "testRemoveAcq_singleAcq";
        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:55:00", "10/10/2017 10:55:30", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);
        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);
        DroolsOperations.retractSingleAcq(this.droolsParams, dto1.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        // assertEquals(0, resourceFunctions.getAllCmgAxisRecSat1().size());
        System.out.println(resourceFunctions.getAllManeuversSat1());
        // assertEquals(0, resourceFunctions.getAllManeuversSat1().size());
        assertEquals(0, resourceFunctions.getAllStoSat1().size());
        assertEquals(0, resourceFunctions.getEssFunctionSat1().size());
        assertEquals(0, resourceFunctions.getBicHpPeakOrbitFunctionSat1().size());
        assertEquals(0, resourceFunctions.getSilentFunctionSat1().size());
    }

    @Test
    public void testRemoveAcq_LRL() throws Exception
    {
        this.sessionId = "testRemoveAcq_LRL";

        this.du.setUpDrools(this.sessionId, this.droolsParams, this.droolsInstance);
        this.droolsInstance = this.du.setUpSession(this.sessionId, SessionType.premium, this.droolsParams, this.droolsInstance, this.currentKieSession, "_");
        String satelliteId = "SAT_1";
        ResourceFunctions resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");
        TreeMap<Long, EnergyAssociatedToTask> acqFunction = resourceFunctions.getEssFunctionAssociatedToSat(satelliteId);
        assertEquals(0, acqFunction.size());

        DTO dto1 = this.du.createSingleDto("10/10/2017 10:55:00", "10/10/2017 10:55:30", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto1.toString());

        boolean accepted = this.droolsInstance.insertDto(this.droolsParams, dto1, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto2 = this.du.createSingleDto("10/10/2017 11:10:00", "10/10/2017 11:10:30", "right", satelliteId);
        System.out.println("I'm inserting dto : " + dto2.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto2, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        DTO dto3 = this.du.createSingleDto("10/10/2017 12:55:00", "10/10/2017 12:55:30", "left", satelliteId);
        System.out.println("I'm inserting dto : " + dto3.toString());

        accepted = this.droolsInstance.insertDto(this.droolsParams, dto3, this.sessionId, this.currentKieSession);
        assertEquals(true, accepted);

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        DroolsOperations.retractSingleAcq(this.droolsParams, dto2.getDtoId(), this.sessionId, this.currentKieSession, ReasonOfReject.acqInconsistentWithPaw);
        resourceFunctions = (ResourceFunctions) this.droolsInstance.getGlobal(this.sessionId, this.currentKieSession, "resourceFunctions");

        this.droolsInstance.writeToFile(this.sessionId, this.currentKieSession, this.droolsParams);

        // assertEquals(0,resourceFunctions.getAllCmgAxisRecSat1().size());
        // assertEquals(0,resourceFunctions.getAllManeuversSat1().size());
        // assertEquals(0,resourceFunctions.getAllStoSat1().size());
        // assertEquals(0,resourceFunctions.getEssFunctionSat1().size());
        // assertEquals(0,resourceFunctions.getBicHpPeakOrbitFunctionSat1().size());
        // assertEquals(0,resourceFunctions.getSilentFunctionSat1().size());
    }

}
